# shellcheck shell=sh
# Quasar shell prompt (mockup: mint user@host, dim path)
if [ -n "$BASH_VERSION" ] && [ -n "$PS1" ]; then
    PS1='\[\e[38;2;140;245;176m\]\u@\h\[\e[0m\] \[\e[38;2;125;133;152m\]\w $\[\e[0m\] '
fi
