# shellcheck shell=sh
# Quasar developer tools for login shells (SSH, text consoles) and the desktop session script: the same
# PATH and privacy defaults the desktop gets from systemd (60-quasar-dev and 60-quasar-privacy.conf).
# Installed to /etc/profile.d/quasar-dev.sh.
for _q in "$HOME/.dotnet/tools" "$HOME/go/bin" "$HOME/.cargo/bin" "$HOME/.local/bin" "$HOME/.local/share/mise/shims"; do
    case ":$PATH:" in *":$_q:"*) ;; *) PATH="$_q:$PATH" ;; esac
done
export PATH
export MISE_DOTNET_ROOT="${MISE_DOTNET_ROOT:-$HOME/.dotnet}"
if [ -z "${DOTNET_ROOT:-}" ] && [ -x "$HOME/.dotnet/dotnet" ]; then export DOTNET_ROOT="$HOME/.dotnet"; fi

# Privacy defaults: one NAME=value per line in the systemd file; a value already set wins.
if [ -r /usr/lib/environment.d/60-quasar-privacy.conf ]; then
    while IFS='=' read -r _q _v; do
        case "$_q" in
            ''|\#*) continue ;;
            *[!A-Z0-9_]*) continue ;;
        esac
        eval "[ -n \"\${$_q+x}\" ] || export $_q=\"\$_v\""
    done < /usr/lib/environment.d/60-quasar-privacy.conf
fi
unset _q _v
