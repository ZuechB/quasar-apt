# shellcheck shell=sh
# Quasar: on a text console (Ctrl+Alt+F2), say how to get the desktop back when it isn't showing, and open
# the repair menu (quasar-repair) once per boot when the desktop failed. Sourced by login shells
# (/etc/profile.d); quiet everywhere else (terminals inside the desktop, SSH, scripts).

quasar_repair_hint() {
    case "$(tty 2>/dev/null)" in /dev/tty[0-9]*) ;; *) return 0 ;; esac
    [ -z "${WAYLAND_DISPLAY:-}" ] || return 0
    [ "$(id -u)" -ge 1000 ] 2>/dev/null || return 0
    command -v quasar-repair >/dev/null 2>&1 || return 0
    q="${XDG_RUNTIME_DIR:-/run/user/$(id -u)}/quasar"
    if systemctl --user is-failed --quiet quasar-shell.service 2>/dev/null || [ -e "$q/shell-failed" ]; then
        state=failed
    elif systemctl --user is-active --quiet quasar-session.target 2>/dev/null; then
        # Signed in, but the shell never drew its first frame (shell-rescue's guard is on it, or gave up).
        [ -e "$q/shell-ready" ] && return 0
        state=failed
    else
        state=none
    fi
    echo
    if [ "$state" = none ]; then
        echo "  Quasar's desktop isn't running. If it won't start, type: quasar-repair"
        echo
        return 0
    fi
    echo "  Quasar's desktop isn't showing. The repair menu can fix that (later: type quasar-repair)."
    echo
    # Once per boot, so that leaving the menu leaves you at the prompt.
    if [ ! -e "$q/repair-opened" ] && mkdir -p "$q" 2>/dev/null && : > "$q/repair-opened"; then
        quasar-repair
    fi
}
quasar_repair_hint
unset -f quasar_repair_hint
