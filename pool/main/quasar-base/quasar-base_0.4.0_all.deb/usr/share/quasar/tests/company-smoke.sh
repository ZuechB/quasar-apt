#!/bin/sh
# Company environments smoke test. Installed to /usr/share/quasar/tests/company-smoke.sh; run it in a
# Personal terminal of a live ISO (the live session's polkit rule allows the company helpers without a
# password), e.g. from tools/qemu-boot-test.sh:
#   --type '120:sh /usr/share/quasar/tests/company-smoke.sh 2>&1 | sudo tee /dev/ttyS0\n'
# Creates the companies "acme" and "beta" (deleting earlier ones), checks that Personal, acme and beta
# each get their own localhost:3000, that companies have internet but can't reach Personal or each
# other's files, and that a company plays sound. Prints PASS/FAIL lines and a RESULT line.
set -u
ADMIN="pkexec /usr/libexec/quasar/quasar-company-admin"
pass=0 fail=0
ok()  { echo "PASS $*"; pass=$((pass + 1)); }
bad() { echo "FAIL $*"; fail=$((fail + 1)); }
expect() { name=$1 want=$2; shift 2; got=$("$@" 2>&1 | tail -n 1); if [ "$got" = "$want" ]; then ok "$name"; else bad "$name (got: $got)"; fi; }
works()  { name=$1; shift; if "$@" >/dev/null 2>&1; then ok "$name"; else bad "$name"; fi; }
refused() { name=$1; shift; if "$@" >/dev/null 2>&1; then bad "$name"; else ok "$name"; fi; }

echo "== company smoke test ($(date -u +%H:%M:%S))"
for id in acme beta; do $ADMIN delete "$id" >/dev/null 2>&1; done
works "create acme" $ADMIN create acme "Acme Corp"
works "create beta" $ADMIN create beta "Beta Labs"
works "start acme" quasar-company start acme
works "start beta" quasar-company start beta
expect "acme agent answers" "RUNNING" quasar-company status acme

# Three servers on port 3000 at once: Personal (this account), acme and beta.
mkdir -p /tmp/smoke-p && echo P > /tmp/smoke-p/who
(cd /tmp/smoke-p && exec python3 -m http.server 3000 >/dev/null 2>&1) &
quasar-company run acme -- sh -c 'mkdir -p ~/smoke && echo A > ~/smoke/who && cd ~/smoke && exec python3 -m http.server 3000'
quasar-company run beta -- sh -c 'mkdir -p ~/smoke && echo B > ~/smoke/who && cd ~/smoke && exec python3 -m http.server 3000'
sleep 3
GET='import sys, urllib.request; print(urllib.request.urlopen(sys.argv[1], timeout=5).read().decode().strip())'
expect "Personal localhost:3000" P python3 -c "$GET" http://127.0.0.1:3000/who
expect "acme localhost:3000" A quasar-company exec acme -- python3 -c "$GET" http://127.0.0.1:3000/who
expect "beta localhost:3000" B quasar-company exec beta -- python3 -c "$GET" http://127.0.0.1:3000/who

# Internet through pasta; Personal's services stay out of reach (the gateway isn't this PC).
# DNS goes to this PC's resolver through pasta's forwarder (169.254.1.53, the company's resolv.conf).
expect "acme resolv.conf names pasta's forwarder" "nameserver 169.254.1.53" quasar-company exec acme -- sh -c 'grep "^nameserver" /etc/resolv.conf'
works "acme looks up names" quasar-company exec acme -- getent hosts deb.debian.org
works "acme internet" quasar-company exec acme -- python3 -c 'import urllib.request; urllib.request.urlopen("https://deb.debian.org/", timeout=15)'
gw=$(quasar-company exec acme -- sh -c "ip -4 route show default | awk '{print \$3; exit}'")
if [ -n "$gw" ]; then
    refused "acme can't reach Personal via the gateway" quasar-company exec acme -- python3 -c "$GET" "http://$gw:3000/who"
fi

# Files: companies can't read Personal or each other; Personal can read companies.
refused "acme can't list Personal's home" quasar-company exec acme -- ls "$HOME"
refused "acme can't list beta's home" quasar-company exec acme -- ls /home/companies/beta
works "Personal can list acme's home" ls /home/companies/acme/smoke
touch /tmp/smoke-personal-marker
refused "acme has its own /tmp" quasar-company exec acme -- test -e /tmp/smoke-personal-marker

# Environment inside the company.
expect "acme sees its company id" acme quasar-company exec acme -- sh -c 'echo "$QUASAR_COMPANY"'
expect "acme has the Wayland session type" wayland quasar-company exec acme -- sh -c 'echo "$XDG_SESSION_TYPE"'
works "acme has a display socket" quasar-company exec acme -- sh -c 'test -S "$XDG_RUNTIME_DIR/wayland-0"'

# Sound through the owner's restricted companies server.
if quasar-company exec acme -- sh -c 'command -v paplay' >/dev/null 2>&1; then
    quasar-company exec acme -- python3 -c '
import math, struct, wave
w = wave.open("/tmp/beep.wav", "wb"); w.setnchannels(1); w.setsampwidth(2); w.setframerate(48000)
w.writeframes(b"".join(struct.pack("<h", int(12000 * math.sin(2 * math.pi * 660 * i / 48000))) for i in range(48000)))
w.close()' && works "acme plays sound" quasar-company exec acme -- paplay /tmp/beep.wav
else
    echo "SKIP sound (paplay isn't installed)"
fi

# A terminal window in acme (check the screenshot: it opens on acme's desktop).
works "acme terminal" quasar-company terminal acme
sleep 3

# The shell's side: one desktop per company, both companies tracked as running, acme's terminal is
# acme's window, and switching to acme works (the screenshot after this shows acme's desktop).
SHELL_IPC="qs --path /usr/share/quasar/shell ipc call company"
state() { $SHELL_IPC state 2>/dev/null | tail -n 1; }
check_state() {   # name, python expression over s (the shell's company state)
    if state | python3 -c "import json, sys; s = json.loads(sys.stdin.read()); sys.exit(0 if ($2) else 1)" 2>/dev/null; then
        ok "$1"; else bad "$1 (state: $(state))"; fi
}
check_state "shell has a desktop per company" "s['desktops'][:3] == ['personal', 'acme', 'beta']"
check_state "shell tracks acme and beta as running" "set(s['running']) >= {'acme', 'beta'}"
check_state "acme's terminal belongs to acme" "any(o == 'acme' for _, o in s['owners'])"
$SHELL_IPC go 2 >/dev/null 2>&1
sleep 2
check_state "switched to acme" "s['active'] == 'acme'"

echo "RESULT pass=$pass fail=$fail"
[ "$fail" -eq 0 ]
