#!/usr/bin/env python3
"""A stand-in for a Unity game server (Animal Go's server app), for testing Services without Unity.

It behaves the way the real one does where Quasar can see it:
  - takes Animal Go's flags: -port N (7770), -name NAME, -maxplayers N; -batchmode, -nographics and
    -logFile are accepted and ignored;
  - binds UDP N on IPv4 and IPv6 (FishNet's Tugboat with IPv6 on), and UDP 47770 for LAN discovery,
    answering "ANIMALGO_DISCOVER|1" with "ANIMALGO_SERVER|1|<instance>|<port>|<players>|<max>|<name>";
  - logs like it: "[AnimalGo Server] Running.", "NAME (ip) joined. 3/10 playing.", "Stopped." on SIGTERM;
  - fails like it when its port is taken: "Could not open UDP port N. Is another server already using it?"

Test extras on the game port: "join NAME" / "leave NAME" change the player count; anything else is
answered with "pong <what you sent>", so a test can check the port is reachable from somewhere.
--probe logs one "probe:" line about the sandbox it runs in (tests/services-e2e checks it).

`fake-game-server.py --write-assembly PATH [STRING…]` writes a minimal .NET assembly whose #US heap holds
the strings (default: Animal Go's flags plus a few literals that aren't flags), the way a Unity build's
Assembly-CSharp.dll carries the flags its scripts read. Services' inspect reads them
(quasar_services/clr.py); tests/services imports assembly() for its parser tests.
"""
import os
import select
import signal
import socket
import struct
import sys
import uuid

DISCOVERY = 47770

# What Animal Go's scripts compare their command line against (Assets/Scripts: ServerApp, ServerWindow,
# PlayerIdentity, Season, LoadingScreenController…), in source order, with literals around them that
# aren't flags: an interpolated message's "-difficulty " (trailing space), a lone dash, a time format.
ANIMAL_GO_STRINGS = [
    "Animal Go Server", "-padstarts", "-lineup", "-finishwindow", "-maxrace", "-lockbuilding", "-difficulty",
    "-difficulty ", " isn't a level: use easy, normal, hard or extreme.", "-bots", "-lockbots", "-botsalways",
    "-botsalone", "-novote", "-vote", "-votetime", "-poserate", "-theme", "-theme ", "-name", "-port",
    "-maxplayers", "-games", "-playername", "-animal", "-join", "-skiptitle", "-", "--:--.--",
    "[AnimalGo Server] ",
]


def _compressed(n):
    """ECMA-335 II.23.2 compressed unsigned integer."""
    if n < 0x80:
        return bytes([n])
    if n < 0x4000:
        return bytes([0x80 | (n >> 8), n & 0xFF])
    return bytes([0xC0 | (n >> 24), (n >> 16) & 0xFF, (n >> 8) & 0xFF, n & 0xFF])


def assembly(strings, pe32plus=False):
    """A minimal .NET assembly whose #US heap holds `strings`: DOS header, PE32 (or PE32+) headers, one
    .text section with the CLI header and a metadata root ("BSJB", streams #~ and #US). Enough for
    Services' reader; .NET itself couldn't load it."""
    us = bytearray(b"\x00")                           # the heap starts with the empty entry
    for s in strings:
        data = s.encode("utf-16-le") + b"\x00"         # the text, then its one trailing byte
        us += _compressed(len(data)) + data
    while len(us) % 4:
        us.append(0)
    streams = [(b"#~", b"\x00" * 24), (b"#US", bytes(us))]
    version = b"v4.0.30319\x00\x00"                     # padded to 4 bytes
    named = [name + b"\x00" * (((len(name) + 1 + 3) & ~3) - len(name)) for name, _ in streams]
    root_len = 16 + len(version) + 4 + sum(8 + len(n) for n in named)
    root = struct.pack("<IHHII", 0x424A5342, 1, 1, 0, len(version)) + version + struct.pack("<HH", 0, len(streams))
    body, offset = b"", root_len
    for (_, data), name in zip(streams, named):
        root += struct.pack("<II", offset, len(data)) + name
        body += data
        offset += len(data)
    metadata = root + body
    text_rva, text_raw = 0x2000, 0x200
    cli = struct.pack("<IHHII", 72, 2, 5, text_rva + 72, len(metadata)) + b"\x00" * 56
    text = cli + metadata
    raw_size = (len(text) + 0x1FF) & ~0x1FF
    text += b"\x00" * (raw_size - len(text))
    lfanew = 0x80
    dos = b"MZ" + b"\x00" * 58 + struct.pack("<I", lfanew) + b"\x00" * (lfanew - 0x40)
    opt_size, dirs_at = (0xF0, 112) if pe32plus else (0xE0, 96)
    coff = b"PE\x00\x00" + struct.pack("<HHIIIHH", 0x8664 if pe32plus else 0x14C, 1, 0, 0, 0, opt_size, 0x2022)
    opt = bytearray(opt_size)
    struct.pack_into("<H", opt, 0, 0x20B if pe32plus else 0x10B)
    struct.pack_into("<I", opt, dirs_at - 4, 16)                       # NumberOfRvaAndSizes
    struct.pack_into("<II", opt, dirs_at + 14 * 8, text_rva, 72)       # directory 14: the CLI header
    section = b".text\x00\x00\x00" + struct.pack("<IIII", len(text), text_rva, raw_size, text_raw) + b"\x00" * 16
    headers = dos + coff + bytes(opt) + section
    return headers + b"\x00" * (text_raw - len(headers)) + text


def say(line):
    print("[AnimalGo Server] " + line, flush=True)


def value(args, flag, default):
    for i, a in enumerate(args):
        if a.lower() == flag and i + 1 < len(args):
            return args[i + 1]
    return default


def probe(port, args):
    """What a server can reach from inside Services' sandbox, in one line."""
    lower = [a.lower() for a in args]
    facts = ["headless=%s" % ("yes" if "-batchmode" in lower and "-nographics" in lower else "no")]

    def attempt(label, fn, yes, no):
        try:
            fn()
            facts.append("%s=%s" % (label, yes))
        except OSError:
            facts.append("%s=%s" % (label, no))
    attempt("unix", lambda: socket.socket(socket.AF_UNIX, socket.SOCK_STREAM).close(), "allowed", "denied")
    attempt("home", lambda: os.listdir("/home"), "visible", "hidden")
    attempt("app", lambda: open(os.path.join(os.getcwd(), ".write-test"), "w").close(), "writable", "readonly")
    attempt("save", lambda: open(os.path.join(os.path.expanduser("~"), ".write-test"), "w").close(), "writable", "readonly")
    sid = os.environ.get("QUASAR_SERVICE", "x")
    attempt("definition", lambda: open("/etc/quasar/services/%s.json" % sid).close(), "readable", "hidden")

    def other_port():
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.bind(("0.0.0.0", port + 1))
        finally:
            s.close()
    attempt("otherport", other_port, "bindable", "denied")
    try:
        st = os.stat(os.getcwd())
        facts.append("appowner=%s" % ("me" if st.st_uid == os.getuid() else st.st_uid))
    except OSError:
        facts.append("appowner=?")
    facts.append("cwd=%s" % os.getcwd())
    say("probe: " + " ".join(facts))


def main(args):
    if args and args[0] == "--write-assembly":
        if len(args) < 2:
            print("usage: fake-game-server.py --write-assembly PATH [STRING…]", file=sys.stderr)
            return 2
        with open(args[1], "wb") as f:
            f.write(assembly(args[2:] or ANIMAL_GO_STRINGS))
        return 0
    port = int(value(args, "-port", "7770"))
    if "--probe" in args:
        probe(port, args)
    name = value(args, "-name", "Fake Server").replace("|", "")
    cap = int(value(args, "-maxplayers", "10"))
    instance = uuid.uuid4().hex[:8]
    say('Starting "%s" on UDP %d…' % (name, port))
    socks = []
    try:
        s4 = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s4.bind(("0.0.0.0", port))
        socks.append(s4)
        if socket.has_ipv6 and "--no-ipv6" not in args:
            s6 = socket.socket(socket.AF_INET6, socket.SOCK_DGRAM)
            s6.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 1)
            try:
                s6.bind(("::", port))
                socks.append(s6)
            except OSError:
                s6.close()
    except OSError as e:
        say("Could not open UDP port %d. Is another server already using it? (%s)" % (port, e.strerror))
        return 1
    disc = None
    try:
        disc = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        disc.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        disc.bind(("0.0.0.0", DISCOVERY))
    except OSError as e:
        say("LAN discovery is off (%s). Players can still join by typing an address." % e.strerror)
        disc = None
    say('Running. Players on your network will see "%s" in their list.' % name)
    players = []
    running = [True]

    def stop(*_):
        running[0] = False
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    watched = socks + ([disc] if disc else [])
    while running[0]:
        try:
            ready, _, _ = select.select(watched, [], [], 1.0)
        except InterruptedError:
            continue
        for s in ready:
            try:
                data, peer = s.recvfrom(2048)
            except OSError:
                continue
            text = data.decode("utf-8", "replace").strip()
            if s is disc:
                if text == "ANIMALGO_DISCOVER|1":
                    s.sendto(("ANIMALGO_SERVER|1|%s|%d|%d|%d|%s" % (instance, port, len(players), cap, name)).encode(),
                             peer)
                continue
            if text.startswith("join "):
                who = text[5:][:24] or "PLAYER"
                if len(players) < cap:
                    players.append(who)
                    say("%s (%s) joined. %d/%d playing." % (who, peer[0], len(players), cap))
            elif text.startswith("leave "):
                who = text[6:][:24]
                if who in players:
                    players.remove(who)
                    say("%s left. %d/%d playing." % (who, len(players), cap))
            else:
                s.sendto(b"pong " + data[:200], peer)
    say("Stopping…")
    for s in watched:
        s.close()
    say("Stopped.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
