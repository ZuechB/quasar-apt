#!/bin/sh
# Per-company Docker smoke test. Installed to /usr/share/quasar/tests/company-docker-smoke.sh; run it in
# a Personal terminal of a live ISO after company-smoke.sh (which creates and starts acme and beta).
# Test-only: installs Docker from its feed directly, because the Store refuses Docker on the live USB.
# Each company then turns on its own rootless engine (the Containers app's setup) and runs a web server
# on port 8080 that answers only on that company's localhost. Prints PASS/FAIL lines and a RESULT line.
set -u
pass=0 fail=0
ok()  { echo "PASS $*"; pass=$((pass + 1)); }
bad() { echo "FAIL $*"; fail=$((fail + 1)); }
expect() { name=$1 want=$2; shift 2; got=$("$@" 2>&1 | tail -n 1); if [ "$got" = "$want" ]; then ok "$name"; else bad "$name (got: $got)"; fi; }
works()  { name=$1; shift; if out=$("$@" 2>&1); then ok "$name"; else bad "$name: $(printf '%s' "$out" | tail -n 3 | tr '\n' ' ')"; fi; }
refused() { name=$1; shift; if "$@" >/dev/null 2>&1; then bad "$name"; else ok "$name"; fi; }

echo "== company docker smoke test ($(date -u +%H:%M:%S))"
# Docker from its own feed, as quasar-pkg installs it (with the rootless parts companies use).
sudo install -m 0644 /usr/share/quasar/apt/feeds/docker.sources /etc/apt/sources.list.d/quasar-docker.sources
sudo install -D -m 0644 /usr/share/quasar/apt/feeds/docker.pref /etc/apt/preferences.d/quasar-docker.pref
sudo apt-get -q update >/dev/null 2>&1
works "docker installed" sudo env DEBIAN_FRONTEND=noninteractive apt-get -q -y --no-install-recommends install \
    docker-ce docker-ce-cli containerd.io docker-ce-rootless-extras uidmap slirp4netns iptables

# Each company's own engine: the same setup the Containers app runs ("Turn on Docker").
SETUP='set -e
if [ "$(stat -f -c %T "$HOME")" = overlayfs ] && [ ! -f ~/.config/docker/daemon.json ]; then
  mkdir -p ~/.config/docker
  printf "{ \"features\": { \"containerd-snapshotter\": false }, \"storage-driver\": \"vfs\" }\n" > ~/.config/docker/daemon.json
fi
dockerd-rootless-setuptool.sh install --force >&2
docker context use rootless >/dev/null 2>&1 || true
mkdir -p ~/.config/environment.d
printf "DOCKER_HOST=unix://%s/docker.sock\n" "$XDG_RUNTIME_DIR" > ~/.config/environment.d/50-quasar-docker.conf
systemctl --user enable docker.service >&2'
for co in acme beta; do
    works "$co has its own Docker engine" quasar-company exec "$co" -- sh -c "$SETUP"
done
expect "acme's engine is rootless" rootless quasar-company exec acme -- sh -c 'docker info --format "{{range .SecurityOptions}}{{println .}}{{end}}" | grep -o rootless | head -n 1'

# The same port in both companies' Docker, each answering with its own letter.
for co in acme beta; do
    letter=$(echo "$co" | cut -c1 | tr a-z A-Z)
    works "$co runs a container on :8080" quasar-company exec "$co" -- docker run -d --name who -p 8080:8080 busybox \
        sh -c "mkdir -p /www && echo $letter > /www/who && exec httpd -f -p 8080 -h /www"
done
sleep 3
GET='import sys, urllib.request; print(urllib.request.urlopen(sys.argv[1], timeout=5).read().decode().strip())'
expect "acme's container on acme's localhost:8080" A quasar-company exec acme -- python3 -c "$GET" http://127.0.0.1:8080/who
expect "beta's container on beta's localhost:8080" B quasar-company exec beta -- python3 -c "$GET" http://127.0.0.1:8080/who
refused "nothing on Personal's localhost:8080" python3 -c "$GET" http://127.0.0.1:8080/who
refused "acme can't use the system Docker" quasar-company exec acme -- docker -H unix:///var/run/docker.sock ps

echo "RESULT pass=$pass fail=$fail"
[ "$fail" -eq 0 ]
