#!/bin/sh
# Services smoke test, inside a running Quasar (the live USB in QEMU with an empty scratch disk, or an
# installed PC with a spare disk). Run as the desktop user (it uses sudo for the root steps; the helpers
# get PKEXEC_UID like pkexec gives them). Prints PASS/FAIL/INFO lines and "RESULT pass=N fail=M".
#   sh /usr/share/quasar/tests/services-smoke.sh
#   SVCSMOKE_DISK=/dev/vda   a disk it may format (the live session's own files are overlayfs, which
#                            servers refuse); SVCSMOKE_DISK=none uses SVCSMOKE_DIR instead
# The "server" is tools/fake-game-server.py laid out like a Unity Linux build (Animal Go's names), the way a
# zip made on Windows leaves it (the program not executable), with an Assembly-CSharp.dll holding Animal Go's
# flags (fake-game-server.py --write-assembly) for inspect to find.
# A pretend home network (veth qsvh0 here, qsvp0 in the "qsvlan" namespace at 192.168.77.2) and "the
# internet" (203.0.113.9 arriving on the same cable, as a router's port forward delivers it).
P=0; F=0
pass() { P=$((P+1)); echo "PASS $*"; }
fail() { F=$((F+1)); echo "FAIL $*"; }
info() { echo "INFO $*"; }
check() { if eval "$2"; then pass "$1"; else fail "$1"; fi; }
U=$(id -u)
Q=/usr/libexec/quasar/services-query
ROUTINE="sudo env PKEXEC_UID=$U /usr/libexec/quasar/quasar-services"
ADMIN="sudo env PKEXEC_UID=$U /usr/libexec/quasar/quasar-services-admin"
FW=/usr/libexec/quasar/quasar-firewall
FAKE=${SVCSMOKE_FAKE:-/usr/share/quasar/tests/fake-game-server.py}
DISK=${SVCSMOKE_DISK:-/dev/vda}
LAN="sudo ip netns exec qsvlan"
W=/tmp/svcsmoke
ID=animal-go-server
UNIT=quasar-svc@$ID.service
rm -rf $W; mkdir -p $W

last() {  # the last result/error line of a helper's output, as JSON
    python3 -c '
import json, sys
d = {}
for l in sys.stdin:
    try:
        o = json.loads(l)
    except ValueError:
        continue
    if isinstance(o, dict) and o.get("type") in ("result", "error"):
        d = o
print(json.dumps(d))'
}
get() { python3 -c 'import json,sys; d=json.load(sys.stdin); print(eval(sys.argv[1], {}, {"d": d}))' "$1" 2>/dev/null; }
udp() {  # udp [ns] [source] host port message -> the answer, or "" after 2 s
    python3 - "$@" <<'EOF'
import socket, sys
src, host, port, msg = sys.argv[1], sys.argv[2], int(sys.argv[3]), sys.argv[4]
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
if src != "-":
    s.bind((src, 0))
s.settimeout(2)
s.sendto(msg.encode(), (host, port))
try:
    print(s.recvfrom(2048)[0].decode("utf-8", "replace"))
except OSError:
    print("")
EOF
}
cleanup() {
    $ADMIN remove $ID >/dev/null 2>&1
    $ADMIN remove linked >/dev/null 2>&1
    sudo ip route del 203.0.113.9/32 2>/dev/null
    [ -n "$UUID" ] && { sudo $FW home off "$UUID" >/dev/null 2>&1; sudo nmcli connection delete uuid "$UUID" >/dev/null 2>&1; }
    sudo ip netns del qsvlan 2>/dev/null
}
trap cleanup EXIT

# ---- 0. the pieces --------------------------------------------------------------------------------------------
sudo touch /run/quasar/services-allow-live
check "systemd has the unit template" 'systemctl cat quasar-svc@x.service >/dev/null 2>&1'
check "firewall is on" '[ "$(systemctl is-active quasar-firewall.service)" = active ]'
check "netguard is on" '[ "$(systemctl is-active quasar-netguard.service)" = active ]'
info "versions: $(systemctl --version | head -1), $(mount --version)"

# ---- 1. a server folder on a real disk, owned by this account -------------------------------------------------------
if [ "$DISK" != none ]; then
    sudo mkfs.ext4 -q -F "$DISK" && sudo mkdir -p /mnt/svcdisk && sudo mount "$DISK" /mnt/svcdisk
    BASE=/mnt/svcdisk/Servers
else
    BASE=${SVCSMOKE_DIR:?SVCSMOKE_DIR}
fi
sudo mkdir -p "$BASE" && sudo chown "$(id -un):$(id -gn)" "$BASE" && sudo chmod 755 "$BASE"
G="$BASE/Animal Go Server"
mkdir -p "$G/Animal Go Server_Data/Managed" "$G/MonoBleedingEdge"
# Copied over from Windows: the program has lost its execute permission (Services gives it back).
cp "$FAKE" "$G/Animal Go Server.x86_64" && chmod 644 "$G/Animal Go Server.x86_64"
touch "$G/UnityPlayer.so" "$G/Animal Go Server_Data/Managed/FishNet.Runtime.dll" && chmod 644 "$G/UnityPlayer.so"
python3 "$FAKE" --write-assembly "$G/Animal Go Server_Data/Managed/Assembly-CSharp.dll"   # the game's own flags
printf 'DestroyGamesVR\nAnimal Go Server\n' > "$G/Animal Go Server_Data/app.info"
chmod 755 "$G"
info "folder: $G on $(findmnt -no FSTYPE -T "$G")"

# ---- 2. what Services sees in it ------------------------------------------------------------------------------------
$Q inspect "$G" | last > $W/inspect.json
check "inspect: a Unity server" '[ "$(get "d[\"kind\"]" < $W/inspect.json)" = unity ]'
check "inspect: FishNet's UDP 7770, home network first" '[ "$(get "str(d[\"ports\"][0])" < $W/inspect.json)" = "{'"'"'proto'"'"': '"'"'udp'"'"', '"'"'port'"'"': 7770, '"'"'label'"'"': '"'"'Game'"'"', '"'"'reach'"'"': '"'"'home'"'"'}" ]'
check "inspect: no problems" '[ "$(get "len(d[\"problems\"])" < $W/inspect.json)" = 0 ]'
check "inspect: sees the program lost its execute bit" '[ "$(get "d[\"executable\"]" < $W/inspect.json)" = False ]'
check "inspect: the game's own flags, port and name first ($(get "len(d[\"flags\"])" < $W/inspect.json) found)" \
    '[ "$(get "\",\".join(f[\"flag\"] for f in d[\"flags\"][:3])" < $W/inspect.json)" = "-port,-name,-maxplayers" ]'
check "inspect: -port and -name filled in" '[ "$(get "\"|\".join(d[\"args\"])" < $W/inspect.json)" = "-port|7770|-name|Animal Go Server" ]'

# ---- 3. a pretend home network -------------------------------------------------------------------------------------
sudo nmcli connection add type veth con-name qsv-smoke ifname qsvh0 veth.peer qsvp0 \
    ipv4.method manual ipv4.addresses 192.168.77.1/24 ipv4.gateway 192.168.77.2 ipv4.route-metric 900 \
    ipv6.method link-local >/dev/null
UUID=$(nmcli -g connection.uuid connection show qsv-smoke 2>/dev/null)
sudo ip netns add qsvlan
for i in $(seq 1 20); do ip link show qsvp0 >/dev/null 2>&1 && break; sleep 0.5; done
sudo ip link set qsvp0 netns qsvlan
$LAN sh -c 'ip link set lo up; ip addr add 192.168.77.2/24 dev qsvp0; ip addr add 203.0.113.9/32 dev qsvp0; ip link set qsvp0 up'
sudo nmcli connection up uuid "$UUID" >/dev/null 2>&1
sleep 3
sudo $FW home on "$UUID" >/dev/null 2>&1
sudo ip route replace 203.0.113.9/32 via 192.168.77.2 dev qsvh0
sleep 1
check "home network recognized" 'grep -q "\"state\": \"home\"" /run/quasar/firewall-net.json'

# ---- 4. add it -------------------------------------------------------------------------------------------------------
python3 - "$G" > $W/spec.json <<'EOF'
import json, sys
print(json.dumps({"name": "Animal Go Server", "kind": "unity", "path": sys.argv[1], "exec": "Animal Go Server.x86_64",
                  "args": ["-port", "7770", "-name", "E2E", "--probe"],      # svc-run adds -batchmode -nographics
                  "ports": [{"proto": "udp", "port": 7770, "label": "Game", "reach": "internet"},
                            {"proto": "udp", "port": 47770, "label": "Nearby servers", "reach": "home"}],
                  "public": {"name": "animalgo.zuech.io", "via": "ha.zuech.io"},
                  "players": {"regex": r"(\d+)/(\d+) playing"}, "label": "Unity server", "facts": ["FishNet", "Mono"]}))
EOF
$ADMIN add < $W/spec.json | last > $W/add.json
check "added: $(get "d.get(\"message\") or d[\"service\"][\"status\"]" < $W/add.json)" '[ "$(get "d[\"service\"][\"status\"]" < $W/add.json)" = running ]'
check "starts with the PC" '[ "$(systemctl is-enabled $UNIT 2>/dev/null)" = enabled ]'
check "added although its program had lost its execute bit: now $(stat -c %a "$G/Animal Go Server.x86_64")" \
    '[ "$(stat -c "%a %U" "$G/Animal Go Server.x86_64")" = "755 $(id -un)" ]'
check "…and nothing else in the folder was touched" '[ "$(stat -c %a "$G/UnityPlayer.so")" = 644 ]'
pid=$(systemctl show -p MainPID --value $UNIT)
check "runs as its own account" '[ "$(ps -o user= -p "$pid" | tr -d " ")" = "svc-$ID" ]'
check "runs headless, with the log on stdout: $(ps -o args= -p "$pid" | cut -c1-140)" \
    'ps -o args= -p "$pid" | grep -q -- "-batchmode -nographics -port 7770 -name E2E --probe -logFile -"'
sleep 2
check "listening on UDP 7770, IPv4 and IPv6 ($(ss -Hlun "sport = :7770" | wc -l) sockets)" '[ "$(ss -Hlun "sport = :7770" | wc -l)" -ge 2 ]'
check "listening on UDP 47770 (LAN discovery)" '[ "$(ss -Hlun "sport = :47770" | wc -l)" -ge 1 ]'
info "last start: $(sudo cat /run/quasar/svc/$ID/last-start.json 2>/dev/null)"
info "mount: $(findmnt -no TARGET,VFS-OPTIONS /run/quasar/svc-mnt/$ID/app 2>/dev/null)"
probe=$(sudo journalctl -u $UNIT -o cat --no-pager | grep 'probe:' | tail -1)
info "$probe"
for want in headless=yes unix=denied home=hidden app=readonly save=writable definition=hidden otherport=denied cwd=/srv/app; do
    check "sandbox: $want" 'echo "$probe" | grep -q " $want\( \|$\)"'
done
case "$(sudo cat /run/quasar/svc/$ID/last-start.json 2>/dev/null)" in
    *idmapped*) check "idmapped: the folder looks like the server's own" 'echo "$probe" | grep -q "appowner=me"' ;;
    *) info "plain bind (no idmapped mount on this filesystem)" ;;
esac
if command -v getfacl >/dev/null; then
    check "the owner may open its save folder" 'sudo getfacl -pn /var/lib/quasar-svc/$ID 2>/dev/null | grep -q "^user:$U:rwx"'
else
    info "no getfacl here: the save folder's ACL isn't checked"
fi
$Q stats $ID | last > $W/statsnow.json
check "stats: memory and tasks ($(get "d.get(\"memory\")" < $W/statsnow.json) bytes)" '[ "$(get "(d.get(\"memory\") or 0) > 0 and (d.get(\"tasks\") or 0) > 0" < $W/statsnow.json)" = True ]'
check "check-port: 7770 is taken by it" '[ "$($Q check-port udp 7770 | last | get "d[\"by\"]")" = "Animal Go Server" ]'
check "check-port: …but free for itself" '[ "$($Q check-port udp 7770 $ID | last | get "d[\"free\"]")" = True ]'
sudo $FW status > $W/firewall.json 2>&1
check "the firewall has its managed entry, open to the internet" 'grep -q "svc:$ID" $W/firewall.json && grep -q "\"internet\"" $W/firewall.json'

# ---- 5. who can reach it -----------------------------------------------------------------------------------------------
home7770=$($LAN python3 -c "import socket; s=socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.settimeout(2); s.bind(('192.168.77.2', 0)); s.sendto(b'ping', ('192.168.77.1', 7770)); print(s.recvfrom(100)[0].decode())" 2>/dev/null)
check "home network reaches the game port (got '$home7770')" '[ "$home7770" = "pong ping" ]'
homedisc=$($LAN python3 -c "import socket; s=socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.settimeout(2); s.bind(('192.168.77.2', 0)); s.sendto(b'ANIMALGO_DISCOVER|1', ('192.168.77.1', 47770)); print(s.recvfrom(200)[0].decode())" 2>/dev/null)
check "home network finds it (Nearby servers)" 'echo "$homedisc" | grep -q "^ANIMALGO_SERVER|1|.*|7770|0|10|E2E"'
$Q stats $ID | last > $W/stats0.json
before=$(get "(d.get(\"wan\") or {}).get(\"packets\", 0)" < $W/stats0.json)
out7770=$($LAN python3 -c "import socket; s=socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.settimeout(2); s.bind(('203.0.113.9', 0)); s.sendto(b'hello', ('192.168.77.1', 7770)); print(s.recvfrom(100)[0].decode())" 2>/dev/null)
check "the internet reaches the game port (got '$out7770')" '[ "$out7770" = "pong hello" ]'
outdisc=$($LAN python3 -c "import socket; s=socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.settimeout(2); s.bind(('203.0.113.9', 0)); s.sendto(b'ANIMALGO_DISCOVER|1', ('192.168.77.1', 47770)); print(s.recvfrom(200)[0].decode())" 2>/dev/null)
check "the internet can't reach LAN discovery (got '$outdisc')" '[ -z "$outdisc" ]'
$Q stats $ID | last > $W/stats1.json
after=$(get "(d.get(\"wan\") or {}).get(\"packets\", 0)" < $W/stats1.json)
check "packets from outside are counted ($before -> $after)" '[ "${after:-0}" -gt "${before:-0}" ]'

# ---- 6. players, logs, the command line, the live watch ------------------------------------------------------------------
udp - 127.0.0.1 7770 "join TESTER" >/dev/null
sleep 1
$Q logs $ID > $W/logs.txt
check "its log reaches Services" 'grep -q "TESTER (127.0.0.1) joined. 1/10 playing" $W/logs.txt'
check "players are counted (1 of 10)" 'grep -q "\"type\":\"players\",\"now\":1,\"max\":10" $W/logs.txt'
check "quasar-service status" 'quasar-service status $ID | grep -q "running"'
check "quasar-service list" 'quasar-service list | grep -q "^$ID "'
$Q watch --summary > $W/watch.txt 2>&1 &
wpid=$!
sleep 2
$ROUTINE stop $ID | last > $W/stop.json
sleep 2
$ROUTINE start $ID | last > $W/start.json
sleep 2
kill $wpid 2>/dev/null
check "stop, then start" '[ "$(get "d[\"status\"]" < $W/stop.json)" = stopped ] && [ "$(get "d[\"status\"]" < $W/start.json)" = running ]'
check "the live watch followed both ($(grep -c summary $W/watch.txt) updates)" '[ "$(grep -c "\"type\":\"summary\"" $W/watch.txt)" -ge 3 ]'

# ---- 6b. consoles: any service's log, live (journal), and every service on the PC (units) ---------------------------------
# Followers get </dev/null: a stream that waits on stdin ends when its stdin pipe closes (the app's way to stop it).
$Q journal svc:$ID -n 50 </dev/null > $W/journal.txt
check "journal: the server's lines, then live" 'grep -q "TESTER (127.0.0.1) joined" $W/journal.txt && grep -q "\"type\":\"live\"" $W/journal.txt'
$Q journal svc:$ID -n 0 -f </dev/null > $W/journal-f.txt 2>&1 &
jpid=$!
sleep 2
udp - 127.0.0.1 7770 "join FOLLOWER" >/dev/null
sleep 2
kill $jpid 2>/dev/null; wait $jpid 2>/dev/null
check "journal -f: a line written after it started" 'grep -q "FOLLOWER (127.0.0.1) joined" $W/journal-f.txt'
sleep 1
check "journal -f: its journalctl went with it" '! pgrep -u "$U" -f "journalctl.*quasar-svc@$ID" >/dev/null'
$Q journal --all -n 400 </dev/null > $W/journal-all.txt
check "journal --all: the server's lines, under its unit" 'grep -q "\"unit\":\"$UNIT\"" $W/journal-all.txt'
$Q units </dev/null > $W/units.txt
check "units: every service, systemd's own too ($(grep -o '"key":' $W/units.txt | wc -l))" \
    'grep -q "\"service:systemd-journald.service\"" $W/units.txt && grep -q "\"service:$UNIT\"" $W/units.txt'
check "units: svc-prepare's helper unit stays out" '! grep -q "quasar-svc-folder@" $W/units.txt'
$Q units -f </dev/null > $W/units-f.txt 2>&1 &
upid=$!
sleep 2
$ROUTINE stop $ID >/dev/null
sleep 3
$ROUTINE start $ID >/dev/null
sleep 3
kill $upid 2>/dev/null; wait $upid 2>/dev/null
check "units -f: the server's stop and start arrive as changes" \
    'grep "\"gone\"" $W/units-f.txt | grep "$UNIT" | grep -q "\"status\":\"stopped\"" && grep "\"gone\"" $W/units-f.txt | grep "$UNIT" | grep -q "\"status\":\"running\""'
# A standard account (not in adm) can't read system services' logs: Services says so instead of showing nothing.
sudo useradd -m -s /bin/sh qsvstd 2>/dev/null
sudo -u qsvstd -H $Q journal svc:$ID -n 5 </dev/null > $W/noaccess.txt 2>&1
check "a standard account is told it can't read the log" 'grep -q "\"code\":\"no-access\"" $W/noaccess.txt'
sudo userdel -r qsvstd 2>/dev/null

# ---- 6c. the watch stays idle: systemd signals its own probes of units that aren't loaded -----------------------------------
# The tray's `watch --summary` used to react to the UnitNew/UnitRemoved its own `systemctl show` caused (Docker and the
# AI engine aren't installed here) and recompute forever. CPU of it and its children over 20 quiet seconds:
$Q watch --summary </dev/null > $W/watch-idle.txt 2>&1 &
wp=$!
sleep 3
t0=$(awk '{print $14+$15+$16+$17}' /proc/$wp/stat)
systemctl show -p Id docker.service quasar-ollama.service >/dev/null 2>&1      # what set the loop off
sleep 20
t1=$(awk '{print $14+$15+$16+$17}' /proc/$wp/stat)
kill $wp 2>/dev/null; wait $wp 2>/dev/null
check "watch stays idle: $(( t1 - t0 )) ticks of CPU in 20 s" '[ $(( t1 - t0 )) -lt 100 ]'

# ---- 7. updating it the owner's way: stop, replace the files, start ---------------------------------------------------
$ROUTINE stop $ID >/dev/null
cp "$FAKE" "$G/Animal Go Server.x86_64.new" && mv -f "$G/Animal Go Server.x86_64.new" "$G/Animal Go Server.x86_64"
chmod 644 "$G/Animal Go Server.x86_64"         # what a zip made on Windows does
$ROUTINE start $ID | last > $W/noexec.json
check "a new build that lost its execute bit starts anyway ($(get "d.get(\"status\") or d.get(\"code\")" < $W/noexec.json))" \
    '[ "$(get "d.get(\"status\")" < $W/noexec.json)" = running ] && [ "$(stat -c %a "$G/Animal Go Server.x86_64")" = 755 ]'
check "…and svc-prepare says so in its log" \
    'sudo journalctl -u quasar-svc-folder@$ID.service -o cat --no-pager | grep -q "marked Animal Go Server.x86_64 as a program"'
$ROUTINE stop $ID >/dev/null
chmod 644 "$G/Animal Go Server.x86_64"
printf '#!/bin/sh\nexec sudo env PKEXEC_UID=%s /usr/libexec/quasar/quasar-services "$@"\n' "$U" > $W/routine && chmod 755 $W/routine
QUASAR_SERVICES_HELPER=$W/routine quasar-service start $ID > $W/cli-start.txt 2>&1
check "quasar-service start does the same ($(tail -1 $W/cli-start.txt))" \
    '[ "$(systemctl is-active $UNIT)" = active ] && [ "$(stat -c %a "$G/Animal Go Server.x86_64")" = 755 ]'
# What isn't a Linux program is refused in words, and left as it was.
$ROUTINE stop $ID >/dev/null
printf 'MZ\220\000\003' > "$G/Server.exe" && chmod 644 "$G/Server.exe"
printf '{"exec": "Server.exe"}\n' | $ROUTINE set $ID >/dev/null
$ROUTINE start $ID | last > $W/pe.json
check "a Windows program is refused ($(get "d.get(\"code\")" < $W/pe.json)) and left as it was" \
    '[ "$(get "d.get(\"code\")" < $W/pe.json)" = windows-build ] && [ "$(stat -c %a "$G/Server.exe")" = 644 ]'
textmode=$(stat -c %a "$G/Animal Go Server_Data/app.info")      # whatever this session's umask made it
printf '{"exec": "Animal Go Server_Data/app.info"}\n' | $ROUTINE set $ID >/dev/null
$ROUTINE start $ID | last > $W/text.json
check "a text file is refused ($(get "d.get(\"code\")" < $W/text.json)) and left as it was ($textmode)" \
    '[ "$(get "d.get(\"code\")" < $W/text.json)" = not-a-program ] && [ "$(stat -c %a "$G/Animal Go Server_Data/app.info")" = "$textmode" ]'
printf '{"exec": "Animal Go Server.x86_64"}\n' | $ROUTINE set $ID >/dev/null
rm -f "$G/Server.exe"
$ROUTINE start $ID | last > $W/again.json
check "back on its own program" '[ "$(get "d.get(\"status\")" < $W/again.json)" = running ]'

# ---- 8. what it may not do ---------------------------------------------------------------------------------------------
printf '{"args": ["-batchmode", "-nographics", "-port", "7771", "-name", "E2E"]}\n' | $ROUTINE set $ID >/dev/null
$ROUTINE restart $ID | last > $W/port7771.json
check "a port it doesn't list can't be opened (the server stops: $(get "d[\"code\"]" < $W/port7771.json))" '[ "$(get "d[\"code\"]" < $W/port7771.json)" = start-failed ]'
check "…and says so in its log" 'sudo journalctl -u $UNIT -o cat --no-pager | grep -q "Could not open UDP port 7771"'
$Q journal svc:$ID -n 80 </dev/null > $W/journal-fail.txt
check "…and its console shows systemd's own line about it, as an error" \
    'grep -o "{[^{}]*\"src\":\"systemd\"[^{}]*}" $W/journal-fail.txt | grep -q "\"lvl\":\"err\""'
printf '{"args": ["-batchmode", "-nographics", "-port", "7770", "-name", "E2E"]}\n' | $ROUTINE set $ID >/dev/null
$ROUTINE restart $ID | last > $W/back.json
check "back on its own port" '[ "$(get "d[\"status\"]" < $W/back.json)" = running ]'
ln -s "$G" "$BASE/link"
sed -e "s|$G|$BASE/link|" -e 's|"Animal Go Server"|"Linked"|' $W/spec.json > $W/spec2.json
$ADMIN add < $W/spec2.json | last > $W/symlink.json
check "a folder reached through a symlink is refused" '[ "$(get "d[\"code\"]" < $W/symlink.json)" = symlink ]'
check "…and leaves nothing behind" '! getent passwd svc-linked >/dev/null && [ ! -e /etc/quasar/services/linked.json ]'
printf '{"ports": [{"proto": "udp", "port": 7770, "label": "Game", "reach": "internet"}, {"proto": "udp", "port": 47770, "label": "Nearby servers", "reach": "this-pc"}]}\n' \
    | $ADMIN update $ID | last > $W/update.json
homedisc2=$($LAN python3 -c "import socket; s=socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.settimeout(2); s.bind(('192.168.77.2', 0)); s.sendto(b'ANIMALGO_DISCOVER|1', ('192.168.77.1', 47770)); print(s.recvfrom(200)[0].decode())" 2>/dev/null)
check "This PC only: the home network can't find it any more" '[ -z "$homedisc2" ]'
info "dns-check: $($Q dns-check one.one.one.one | last)"

# ---- 9. remove it ----------------------------------------------------------------------------------------------------------
$ADMIN remove $ID | last > $W/remove.json
check "removed" '[ "$(get "d[\"removed\"]" < $W/remove.json)" = True ]'
check "no account, unit, definition or save folder left" '! getent passwd svc-$ID >/dev/null && [ ! -e /etc/quasar/services/$ID.json ] && [ ! -e /var/lib/quasar-svc/$ID ] && [ "$(systemctl is-enabled $UNIT 2>/dev/null)" != enabled ]'
check "its ports are closed in the firewall" '! sudo $FW status | grep -q "svc:$ID"'
check "nothing is listening on 7770" '[ "$(ss -Hlun "sport = :7770" | wc -l)" = 0 ]'
check "the owner's folder is untouched" '[ -f "$G/Animal Go Server.x86_64" ]'
check "the folder is no longer mounted" '! findmnt /run/quasar/svc-mnt/$ID/app >/dev/null'

echo "RESULT pass=$P fail=$F"
