#!/bin/sh
# Firewall smoke test, inside a running Quasar (live USB in QEMU, or an installed PC). Run as the desktop
# user (it uses sudo for the root steps); prints PASS/FAIL/INFO lines and "RESULT pass=N fail=M".
#   sh /usr/share/quasar/tests/firewall-smoke.sh 2>&1 | sudo tee /dev/ttyS0
# A pretend home network: NetworkManager brings up a veth pair (qfwh0 here, qfwp0 in the "qfwlan"
# namespace, which plays the router at 192.168.77.2 and every other device). Leaves nothing behind.
#   FWSMOKE_SHOT=FILE       screenshot of the desktop while it shows the "wants to receive connections" card
#   FWSMOKE_FROM_REPO=1     the firewall was restarted after boot (code installed by hand): skip the boot order
#   FWSMOKE_VT=N            the text console to switch back to after a screenshot (default 2)
P=0; F=0
pass() { P=$((P+1)); echo "PASS $*"; }
fail() { F=$((F+1)); echo "FAIL $*"; }
check() { if eval "$2"; then pass "$1"; else fail "$1"; fi; }
FW=/usr/libexec/quasar/quasar-firewall
U=$(id -u)
LAN="sudo ip netns exec qfwlan"
W=/tmp/fwsmoke
mkdir -p $W/www && head -c 3000000 /dev/urandom > $W/www/big.bin && echo hi > $W/www/index.html

# Scopes named the way the shell's launcher names them (app-quasar-<id>-<ms>), so netguard sees app:<id>.
scope() { n=$1; shift; systemd-run --user --scope --quiet --collect --slice=app.slice --unit="app-quasar-$n-$(date +%s%3N)" -- "$@" & sleep 1.5; }
stopscope() { systemctl --user stop "app-quasar-$1-*.scope" 2>/dev/null; }
langet() { $LAN curl -s -m 3 -o /dev/null -w '%{http_code}' "$1" 2>/dev/null; }
# A screenshot of the desktop: from a text console the compositor draws nothing (grim would wait for a
# frame forever), so switch to its VT first (greetd's vt7), then back.
shot() {
    [ -n "$1" ] && command -v grim >/dev/null || return 0
    sudo chvt 7; sleep 2
    WAYLAND_DISPLAY=${WAYLAND_DISPLAY:-wayland-0} XDG_RUNTIME_DIR=${XDG_RUNTIME_DIR:-/run/user/$U} timeout 10 grim "$1" 2>/dev/null
    sudo chvt "${FWSMOKE_VT:-2}"
}
ng() {  # ng '{"op": …}' -> the answer line (netguard's socket, as this user)
    python3 - "$1" <<'EOF'
import json, socket, sys
s = socket.socket(socket.AF_UNIX); s.settimeout(5); s.connect("/run/quasar/netguard.sock")
s.sendall(sys.argv[1].encode() + b"\n"); buf = b""
while b"\n" not in buf:
    d = s.recv(65536)
    if not d: break
    buf += d
print(buf.split(b"\n")[0].decode())
EOF
}
cleanup() {
    for n in fwsmoke-app fwsmoke-port fwsmoke-curl fwsmoke-prompt fwsmoke-wan fwsmoke-other; do stopscope $n; done
    systemctl --user stop quasar-vnc.service 2>/dev/null
    sudo $FW unallow app:quasar-vnc >/dev/null 2>&1
    sudo ip route del 203.0.113.9/32 2>/dev/null
    sudo ip route del 192.168.3.0/24 2>/dev/null
    [ -n "$UUID" ] && sudo nmcli connection delete uuid "$UUID" >/dev/null 2>&1
    sudo ip netns del qfwlan 2>/dev/null
    for id in $(sudo $FW status | python3 -c 'import json,sys; print(" ".join(a["id"] for a in json.load(sys.stdin)["allowed"] if "fwsmoke" in a["name"].lower()))' 2>/dev/null); do
        sudo $FW unallow "$id"
    done
    rm -rf $W
}
trap cleanup EXIT

# ---- 1. it's up, and up first --------------------------------------------------------------------------
check "firewall unit active" '[ "$(systemctl is-active quasar-firewall.service)" = active ]'
check "firewall table loaded" 'sudo nft list table inet quasar >/dev/null 2>&1'
fw_t=$(systemctl show -p ActiveEnterTimestampMonotonic --value quasar-firewall.service)
nm_t=$(systemctl show -p ActiveEnterTimestampMonotonic --value NetworkManager.service)
if [ "$FWSMOKE_FROM_REPO" = 1 ]; then
    echo "INFO firewall restarted after boot (repo code installed): boot order not checked"
else
    check "firewall up before NetworkManager ($fw_t < $nm_t)" '[ "$fw_t" -gt 0 ] && [ "$fw_t" -lt "$nm_t" ]'
fi
check "netguard active" '[ "$(systemctl is-active quasar-netguard.service)" = active ]'
check "netguard table loaded" 'sudo nft list table inet quasar_apps >/dev/null 2>&1'
check "netguard answers" 'ng "{\"op\": \"ping\"}" | grep -q "\"ok\":true"'
check "Debian's nftables.service is masked" '[ "$(systemctl is-enabled nftables.service 2>/dev/null)" = masked ]'

# ---- 2. a pretend home network ---------------------------------------------------------------------------
sudo nmcli connection add type veth con-name qfw-smoke ifname qfwh0 veth.peer qfwp0 \
    ipv4.method manual ipv4.addresses 192.168.77.1/24 ipv4.gateway 192.168.77.2 ipv4.route-metric 900 \
    ipv6.method link-local >/dev/null
UUID=$(nmcli -g connection.uuid connection show qfw-smoke 2>/dev/null)
sudo ip netns add qfwlan
for i in $(seq 1 20); do ip link show qfwp0 >/dev/null 2>&1 && break; sleep 0.5; done
sudo ip link set qfwp0 netns qfwlan
$LAN sh -c 'ip link set lo up; ip addr add 192.168.77.2/24 dev qfwp0; ip link set qfwp0 up'
sudo nmcli connection up uuid "$UUID" >/dev/null 2>&1
sleep 3
check "test network is up ($UUID)" 'nmcli -t -f UUID connection show --active | grep -q "$UUID"'

scope fwsmoke-app python3 -m http.server 8088 --bind 0.0.0.0 --directory $W/www
scope fwsmoke-port python3 -m http.server 8089 --bind 0.0.0.0 --directory $W/www
c=$(langet http://192.168.77.1:8088/); check "a listener is blocked from the network (got $c)" '[ "$c" != 200 ]'

out=$(sudo $FW home on "$UUID" 2>&1); [ -n "$out" ] && echo "INFO home on: $out"
sleep 1
check "home network recognized by connection and router" 'grep -q "\"state\": \"home\"" /run/quasar/firewall-net.json'
check "home interface in the firewall" 'sudo nft list set inet quasar home_ifaces | grep -q qfwh0'
c=$(langet http://192.168.77.1:8088/); check "home network, nothing allowed: still blocked (got $c)" '[ "$c" != 200 ]'

# ---- 3. allowing an app, and a port ---------------------------------------------------------------------------
echo '{"app": "fwsmoke-app", "name": "Fwsmoke app"}' | sudo $FW allow >/dev/null
sleep 1
n=$(sudo nft -j list set inet quasar allow_app5 | python3 -c 'import json,sys; print(sum(len(x["set"].get("elem", [])) for x in json.load(sys.stdin)["nftables"] if "set" in x))')
check "netguard put the allowed app's scope in the firewall ($n)" '[ "${n:-0}" -ge 1 ]'
c=$(langet http://192.168.77.1:8088/); check "allowed app reachable from the home network (got $c)" '[ "$c" = 200 ]'
c=$(langet http://192.168.77.1:8089/); check "another app stays blocked (got $c)" '[ "$c" != 200 ]'
echo '{"name": "Fwsmoke port", "tcp": "8089"}' | sudo $FW allow >/dev/null
c=$(langet http://192.168.77.1:8089/); check "allowed port reachable (got $c)" '[ "$c" = 200 ]'
sudo $FW home off "$UUID" >/dev/null
sleep 1
c=$(langet http://192.168.77.1:8088/); check "not a home network any more: app blocked again (got $c)" '[ "$c" != 200 ]'
c=$(langet http://192.168.77.1:8089/); check "…and the port (got $c)" '[ "$c" != 200 ]'
# Settings' "Allow a port" while the network isn't home (2026-11-24: such a port never answered). The spec now
# carries the networks the dialog offered, so the network becomes home and the port answers in one step.
echo "{\"name\": \"Fwsmoke port\", \"tcp\": \"8089\", \"home\": [\"$UUID\"]}" | sudo env PKEXEC_UID=$U $FW allow >/dev/null
sleep 1
check "allow with home: the network is a home network again" 'grep -q "\"state\": \"home\"" /run/quasar/firewall-net.json'
c=$(langet http://192.168.77.1:8089/); check "allow with home: the port answers in one step (got $c)" '[ "$c" = 200 ]'
sudo $FW home on "$UUID" >/dev/null
sleep 1

# ---- 3b. a port open to the internet (Services' managed entries) ---------------------------------------------------
# "The internet" = an address outside the home network's prefix, arriving on the same cable (what a router's
# port forward delivers), with a route back so a real connection works.
$LAN ip addr add 203.0.113.9/32 dev qfwp0
sudo ip route replace 203.0.113.9/32 via 192.168.77.2 dev qfwh0
outget() { $LAN curl -s -m 3 --interface 203.0.113.9 -o /dev/null -w '%{http_code}' "$1" 2>/dev/null; }
wanpk() { ng '{"op": "wan"}' | python3 -c 'import json,sys; print(next((e["packets"] for e in json.load(sys.stdin).get("entries", []) if e["id"] == "svc:fwsmoke"), 0))'; }
WANSPEC='{"id": "svc:fwsmoke", "name": "Fwsmoke internet", "tcp": "8092", "by": "services", "internet": {"tcp": "8092"}}'
scope fwsmoke-wan python3 -m http.server 8092 --bind 0.0.0.0 --directory $W/www
c=$(outget http://192.168.77.1:8089/); check "a port allowed at home isn't reachable from outside (got $c)" '[ "$c" != 200 ]'
c=$(outget http://192.168.77.1:8092/); check "nothing open to the internet yet (got $c)" '[ "$c" != 200 ]'
check "only Quasar itself may open a port to the internet" '! echo "$WANSPEC" | sudo env PKEXEC_UID=$U $FW allow >/dev/null 2>&1'
echo "$WANSPEC" | sudo $FW allow >/dev/null
c=$(outget http://192.168.77.1:8092/); check "open to the internet: reachable from outside (got $c)" '[ "$c" = 200 ]'
n1=$(wanpk); check "netguard reports the packets from outside ($n1)" '[ "${n1:-0}" -gt 0 ]'
c=$(langet http://192.168.77.1:8092/); check "…and from home (got $c)" '[ "$c" = 200 ]'
n2=$(wanpk); check "home traffic isn't counted as outside ($n1 -> $n2)" '[ "$n2" = "$n1" ]'
c=$(outget http://192.168.77.1:8089/); check "the home-only port stays closed to outsiders (got $c)" '[ "$c" != 200 ]'
sudo $FW unallow svc:fwsmoke >/dev/null
c=$(outget http://192.168.77.1:8092/); check "closed to the internet again (got $c)" '[ "$c" != 200 ]'
check "its counter is gone" '! sudo nft list counter inet quasar wan-svc-fwsmoke >/dev/null 2>&1'
stopscope fwsmoke-wan
sudo ip route del 203.0.113.9/32 2>/dev/null
$LAN ip addr del 203.0.113.9/32 dev qfwp0

# ---- 3c. the home router's VPN (Settings › Firewall › Router VPN) ---------------------------------------------------
# A VPN client of the router (192.168.3.7) arrives through the home cable from its own range, routed by the router.
$LAN ip addr add 192.168.3.7/32 dev qfwp0
sudo ip route replace 192.168.3.0/24 via 192.168.77.2 dev qfwh0
vpnget() { $LAN curl -s -m 3 --interface 192.168.3.7 -o /dev/null -w '%{http_code}' "$1" 2>/dev/null; }
c=$(vpnget http://192.168.77.1:8088/); check "a router-VPN device isn't home by itself (got $c)" '[ "$c" != 200 ]'
out=$(echo '{"vpn": ["192.168.3.0/24"]}' | sudo $FW home vpn "$UUID" 2>&1); [ -n "$out" ] && echo "INFO home vpn: $out"
check "the VPN range is in the firewall's home sources" 'sudo nft list set inet quasar home_src4 | grep -q 192.168.3.0/24'
check "…and in firewall-net.json for Command Deck" 'grep -q "192.168.3.0/24" /run/quasar/firewall-net.json'
c=$(vpnget http://192.168.77.1:8088/); check "router VPN: the allowed app answers (got $c)" '[ "$c" = 200 ]'
c=$(vpnget http://192.168.77.1:8089/); check "router VPN: the allowed port answers (got $c)" '[ "$c" = 200 ]'
check "a VPN range that is the home network itself is refused" \
    '! echo "{\"vpn\": [\"192.168.77.0/25\"]}" | sudo $FW home vpn "$UUID" >/dev/null 2>&1'
echo '{"vpn": []}' | sudo $FW home vpn "$UUID" >/dev/null
c=$(vpnget http://192.168.77.1:8088/); check "VPN range removed: blocked again (got $c)" '[ "$c" != 200 ]'
sudo ip route del 192.168.3.0/24 2>/dev/null
$LAN ip addr del 192.168.3.7/32 dev qfwp0

# ---- 3d. Remote desktop's entry lets in its own service only (app:quasar-vnc = quasar-vnc.service) ---------------
systemd-run --user --quiet --collect --unit=quasar-vnc.service python3 -m http.server 5907 --bind 0.0.0.0 --directory $W/www
scope fwsmoke-other python3 -m http.server 5908 --bind 0.0.0.0 --directory $W/www
sleep 1.5
echo '{"app": "quasar-vnc", "name": "Remote desktop", "by": "vnc"}' | sudo $FW allow >/dev/null
sleep 1
c=$(langet http://192.168.77.1:5907/); check "Remote desktop's service answers at home (got $c)" '[ "$c" = 200 ]'
c=$(langet http://192.168.77.1:5908/); check "another program doesn't get in on its entry (got $c)" '[ "$c" != 200 ]'
check "Settings can't take Remote desktop's entry away" '! sudo env PKEXEC_UID=$U $FW unallow app:quasar-vnc >/dev/null 2>&1'
sudo $FW unallow app:quasar-vnc >/dev/null
c=$(langet http://192.168.77.1:5907/); check "entry removed: closed (got $c)" '[ "$c" != 200 ]'
systemctl --user stop quasar-vnc.service 2>/dev/null; stopscope fwsmoke-other

# ---- 4. per-app internet use and blocking -------------------------------------------------------------------------
$LAN sh -c "cd $W/www && exec python3 -m http.server 8090 --bind 0.0.0.0" >/dev/null 2>&1 &
sleep 1.5
scope fwsmoke-curl sh -c "curl -s -m 20 -o /dev/null http://192.168.77.2:8090/big.bin; echo \$? > $W/curl1"
for i in $(seq 1 30); do [ -s $W/curl1 ] && break; sleep 0.5; done
check "download in an app scope worked" '[ "$(cat $W/curl1 2>/dev/null)" = 0 ]'
rx=$(ng '{"op": "usage"}' | python3 -c 'import json,sys; r=json.load(sys.stdin); print(next((x["rx"] for x in r["rows"] if x["key"]=="app:fwsmoke-curl"), 0))')
check "netguard counted it for that app (rx=$rx)" '[ "${rx:-0}" -gt 2500000 ]'
check "blocking an app is the user's own call" 'ng "{\"op\": \"block\", \"key\": \"app:fwsmoke-curl\"}" | grep -q "\"ok\":true"'
# A new copy of the blocked app: like any app it starts up before it connects (netguard registers a new
# scope within milliseconds of its creation).
scope fwsmoke-curl sh -c "sleep 0.3; s=\$(date +%s%N); curl -s -m 10 -o /dev/null http://192.168.77.2:8090/index.html; echo \"\$? \$(( (\$(date +%s%N) - s) / 1000000 ))\" > $W/curl2"
for i in $(seq 1 30); do [ -s $W/curl2 ] && break; sleep 0.5; done
read rc2 ms2 < $W/curl2
check "a blocked app fails at once (curl rc=$rc2 in ${ms2} ms)" '[ "${rc2:-0}" != 0 ] && [ "${ms2:-99999}" -lt 3000 ]'
ng '{"op": "unblock", "key": "app:fwsmoke-curl"}' >/dev/null
scope fwsmoke-curl sh -c "sleep 0.3; curl -s -m 10 -o /dev/null http://192.168.77.2:8090/index.html; echo \$? > $W/curl3"
for i in $(seq 1 30); do [ -s $W/curl3 ] && break; sleep 0.5; done
check "unblocked: it works again" '[ "$(cat $W/curl3 2>/dev/null)" = 0 ]'
sudo ip netns pids qfwlan 2>/dev/null | xargs -r sudo kill 2>/dev/null

# ---- 5. the prompt ---------------------------------------------------------------------------------------------------
python3 - > $W/prompt.out 2>&1 <<'EOF' &
import json, socket, time
s = socket.socket(socket.AF_UNIX); s.settimeout(15); s.connect("/run/quasar/netguard.sock")
s.sendall(b'{"op": "subscribe"}\n')
end, buf = time.time() + 15, b""
while time.time() < end:
    try:
        d = s.recv(65536)
    except socket.timeout:
        break
    if not d:
        break
    buf += d
    for line in buf.split(b"\n")[:-1]:
        m = json.loads(line)
        if m.get("event") == "prompt":
            print(json.dumps(m)); raise SystemExit
    buf = buf.split(b"\n")[-1]
EOF
sub=$!
sleep 1.5
scope fwsmoke-prompt python3 -m http.server 8091 --bind 0.0.0.0 --directory $W/www
langet http://192.168.77.1:8091/ >/dev/null
shot "$FWSMOKE_SHOT"           # the desktop's shell shows the same prompt as a card
wait $sub
check "a refused connection to a listening app becomes a prompt" 'grep -q "\"key\": \"app:fwsmoke-prompt\"" $W/prompt.out && grep -q "\"port\": 8091" $W/prompt.out'
check "…naming the network" 'grep -q "qfw-smoke" $W/prompt.out'
check "Recently blocked lists it" 'ng "{\"op\": \"recent\"}" | grep -q "fwsmoke-prompt"'

# ---- 6. off and on -----------------------------------------------------------------------------------------------------
sudo $FW off >/dev/null
c=$(langet http://192.168.77.1:8091/); check "firewall off: reachable (got $c)" '[ "$c" = 200 ]'
check "off survives a restart (unit disabled)" '[ "$(systemctl is-enabled quasar-firewall.service)" = disabled ]'
sudo $FW on >/dev/null
sleep 1
c=$(langet http://192.168.77.1:8091/); check "firewall on again: blocked (got $c)" '[ "$c" != 200 ]'
c=$(langet http://192.168.77.1:8088/); check "…and the allowed app is reachable again (got $c)" '[ "$c" = 200 ]'
check "status says so" 'sudo $FW status | grep -q "\"active\": true"'

echo "RESULT pass=$P fail=$F"
[ $F -eq 0 ]
