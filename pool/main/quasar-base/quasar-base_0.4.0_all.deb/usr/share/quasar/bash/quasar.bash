# Quasar interactive bash. Sourced from /etc/bash.bashrc (bash only — never from /etc/profile.d,
# where dash would parse it). Runs in every interactive shell, so it never forks.
#
#  * Folders and commands ignore case, like Windows:
#      cd music        enters ~/Music (also documents/WORK, ~/downloads, /USR/share …)
#      cd mu<Tab>      completes to Music/
#      ls *.jpg        finds photo.JPG
#      LS, Ls -la      run ls;  CD, Cd work like cd;  cd.. goes up;  cls clears
#    An exact name always wins. If two folders differ only in case (Music and music) and neither
#    matches exactly, cd says it's ambiguous instead of guessing.
#    Turn it off with QUASAR_SHELL_NOCASE=0 (Terminal › Settings › "Ignore case in folders and
#    commands" sets it for the Terminal's shells).
#  * Shell integration for terminals that understand it (not the Linux console):
#      OSC 7    the working folder, so a new tab opens where you are
#      OSC 133  prompt marks (A at the prompt, B where typing starts)
#      OSC 2    the window/tab title: the folder (~/Music); a program's own title lasts until
#               the next prompt

[ -n "$BASH_VERSION" ] || return 0
case $- in *i*) ;; *) return 0 ;; esac
[ -z "${__quasar_bash:-}" ] || return 0
__quasar_bash=1

# ---- case-insensitive folders and commands ---------------------------------------------------------
if [ "${QUASAR_SHELL_NOCASE:-1}" != 0 ]; then
    bind 'set completion-ignore-case on' 2>/dev/null
    bind 'set completion-map-case on' 2>/dev/null          # with it, - and _ match each other
    bind 'set show-all-if-ambiguous on' 2>/dev/null        # one Tab lists Desktop Documents Downloads
    bind 'set mark-symlinked-directories on' 2>/dev/null
    shopt -s nocaseglob cdspell dirspell 2>/dev/null

    # __quasar_casepath PATH — REPLY = PATH with every component that doesn't exist replaced by the
    # one folder whose name differs only in case. Returns 1 when a component has no such folder,
    # 2 when it has several (and says so).
    __quasar_casepath() {
        local path=$1 rest=$1 out= comp dir cand lc hit n list nullglob_was=0
        [[ $rest == /* ]] && out=/
        shopt -q nullglob && nullglob_was=1
        shopt -s nullglob
        while [ -n "$rest" ]; do
            comp=${rest%%/*}
            if [[ $rest == */* ]]; then rest=${rest#*/}; else rest=; fi
            [ -n "$comp" ] || continue                     # leading, doubled or trailing /
            dir=${out:-.}
            if [ ! -d "$dir/$comp" ]; then
                lc=${comp,,} hit= n=0 list=
                # Hidden folders only match when the dot is typed (as with ls).
                if [[ $comp == .* ]]; then set -- "$dir"/.*; else set -- "$dir"/*; fi
                for cand; do
                    cand=${cand##*/}
                    [ "${cand,,}" = "$lc" ] && [ -d "$dir/$cand" ] || continue
                    hit=$cand n=$((n + 1)) list=${list:+$list, }$cand
                done
                if [ "$n" -ne 1 ]; then
                    [ "$nullglob_was" = 1 ] || shopt -u nullglob
                    if [ "$n" -gt 1 ]; then
                        printf 'bash: cd: %s: ambiguous (%s)\n' "$path" "$list" >&2
                        return 2
                    fi
                    return 1
                fi
                comp=$hit
            fi
            case $out in '') out=$comp ;; /) out=/$comp ;; *) out=$out/$comp ;; esac
        done
        [ "$nullglob_was" = 1 ] || shopt -u nullglob
        case $out in /* | . | .. | ./* | ../*) ;; *) out=./$out ;; esac     # keeps $CDPATH out of it
        REPLY=$out
    }

    # Would the builtin find $1 through $CDPATH? (Then it's not ours to correct.)
    __quasar_cdpath_hit() {
        [ -n "${CDPATH:-}" ] && [[ $1 != /* && $1 != ./* && $1 != ../* ]] || return 1
        local d rest=$CDPATH:
        while [ -n "$rest" ]; do
            d=${rest%%:*}; rest=${rest#*:}
            [ -d "${d:-.}/$1" ] && return 0
        done
        return 1
    }

    # Only the plain `cd PATH` form is corrected, and only when PATH doesn't exist as typed:
    # `cd`, `cd -`, options and existing paths go straight to the builtin, so behaviour (and $?)
    # is unchanged for everything that already worked. Typos the case can't explain still get
    # bash's own spelling correction (cdspell) and error message.
    if ! declare -F cd >/dev/null; then
        cd() {
            if [ $# -eq 1 ] && [ -n "$1" ] && [[ $1 != -* ]] && [ ! -d "$1" ] && ! __quasar_cdpath_hit "$1"; then
                __quasar_casepath "$1"
                case $? in
                    0) builtin cd -- "$REPLY"; return ;;
                    2) return 1 ;;
                esac
            fi
            builtin cd "$@"
        }
    fi
    CD() { cd "$@"; }
    Cd() { cd "$@"; }
    cD() { cd "$@"; }
    alias cd..='cd ..' cls=clear

    # A command that isn't found under the typed case runs under its lowercase name (LS → ls,
    # with ls's alias). Bash runs this handler in a child process, so it costs nothing until a
    # name is actually missing — and it can't change this shell (hence the CD functions above).
    if declare -F command_not_found_handle >/dev/null; then
        __quasar_cnf_def=$(declare -f command_not_found_handle)     # keep a handler installed before us
        eval "__quasar_cnf_prev${__quasar_cnf_def#command_not_found_handle}"
        unset __quasar_cnf_def
    fi
    command_not_found_handle() {
        local lc=${1,,}
        if [ "$lc" != "$1" ]; then
            case $(type -t -- "$lc") in
                alias) eval "${BASH_ALIASES[$lc]}"' "${@:2}"'; return ;;
                function | builtin | file) "$lc" "${@:2}"; return ;;
            esac
        fi
        if declare -F __quasar_cnf_prev >/dev/null; then __quasar_cnf_prev "$@"; return; fi
        printf 'bash: %s: command not found\n' "$1" >&2
        return 127
    }
fi

# ---- shell integration (OSC 7 / 133 / 2) ----------------------------------------------------------
# The Linux console prints unknown OSC sequences as text, so only terminals that skip them get them.
case ${TERM:-dumb} in
    linux | dumb | vt[0-9]* | cons*) ;;
    *)
        __quasar_osc() {
            local status=$? url=$PWD title
            # OSC 7 wants a file:// URL: percent-encode byte by byte (C locale) whatever isn't safe.
            if [[ $url == *[!A-Za-z0-9/._~-]* ]]; then
                local LC_ALL=C i c enc=
                for ((i = 0; i < ${#url}; i++)); do
                    c=${url:i:1}
                    case $c in
                        [A-Za-z0-9/._~-]) enc+=$c ;;
                        *) printf -v c '%%%02X' "'$c"; enc+=$c ;;
                    esac
                done
                url=$enc
            fi
            if [ "$PWD" = "$HOME" ]; then title='~'
            elif [[ $PWD == "$HOME"/* ]]; then title="~${PWD#"$HOME"}"
            else title=$PWD
            fi
            title=${title//[[:cntrl:]]/?}                  # a folder name can't inject escapes
            printf '\e]133;A\a\e]7;file://%s%s\e\\\e]2;%s\a' "${HOSTNAME:-}" "$url" "$title"
            # B marks where typing starts. ~/.bashrc (re)sets PS1 after us, so check every prompt.
            [[ $PS1 == *'133;B'* ]] || PS1+='\[\e]133;B\a\]'
            return "$status"
        }
        PROMPT_COMMAND="__quasar_osc${PROMPT_COMMAND:+;$PROMPT_COMMAND}"
        ;;
esac
