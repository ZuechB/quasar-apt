// SVG path data, 24×24 viewBox, stroke icons. Most are verbatim from ui/Quasar/Icons.qml (the mockup's
// ic() dictionary); the few phone-only ones (pause, next, trackpad, …) are drawn in the same style.
export const I = {
  home: "M3 11l9-7l9 7M5 10v10h14V10",
  grid: "M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z",
  layers: "M12 3l9 4.5l-9 4.5l-9-4.5zM3 12l9 4.5l9-4.5M3 16.5l9 4.5l9-4.5",
  monitor: "M3 5h18v11H3zM8 20h8M12 16v4",
  more: "M5 12h.01M12 12h.01M19 12h.01",
  dots: "M12 5h.01M12 12h.01M12 19h.01",
  power: "M12 3v9M6.4 6.4a8 8 0 1 0 11.2 0",
  lock: "M6 11h12v10H6zM8.5 11V8a3.5 3.5 0 0 1 7 0v3",
  unlock: "M6 11h12v10H6zM8.5 11V8a3.5 3.5 0 0 1 6.8-1.2",
  moon: "M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z",
  cycle: "M20 12a8 8 0 0 1-14.3 4.9M4 12a8 8 0 0 1 14.3-4.9M18.6 3.4v3.8h-3.8M5.4 20.6v-3.8h3.8",
  refresh: "M20 11a8 8 0 1 0-2.3 5.7M20 4v7h-7",
  logout: "M10 4H5v16h5M14 8l4 4l-4 4M18 12H9",
  vol: "M4 9h4l5-4v14l-5-4H4zM16.5 8.5a5 5 0 0 1 0 7M19 6a8.5 8.5 0 0 1 0 12",
  volLow: "M4 9h4l5-4v14l-5-4H4zM16.5 8.5a5 5 0 0 1 0 7",
  mute: "M4 9h4l5-4v14l-5-4H4zM16 9.5l5 5M21 9.5l-5 5",
  play: "M8 5l11 7l-11 7z",
  pause: "M8 5v14M16 5v14",
  next: "M5 5l10 7l-10 7zM19 5v14",
  prev: "M19 5L9 12l10 7zM5 5v14",
  music: "M9 18V6l10-2v12M9 18a2.5 2.5 0 1 1-5 0a2.5 2.5 0 1 1 5 0zM19 16a2.5 2.5 0 1 1-5 0a2.5 2.5 0 1 1 5 0z",
  send: "M4 12l16-8l-6 16l-2-7z",
  upload: "M12 16V4M7 9l5-5l5 5M5 20h14",
  download: "M12 4v11M7 10l5 5l5-5M5 20h14",
  image: "M4 5h16v14H4zM4 16l5-5l4 4l3-3l4 4M15.5 8a1.5 1.5 0 1 0 0 3a1.5 1.5 0 1 0 0-3z",
  file: "M6 3h9l4 4v14H6zM14 3v5h5",
  folder: "M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",
  phone: "M7.5 3h9A1.5 1.5 0 0 1 18 4.5v15a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 6 19.5v-15A1.5 1.5 0 0 1 7.5 3zM11 18h2",
  mouse: "M12 3a6 6 0 0 1 6 6v6a6 6 0 0 1-12 0V9a6 6 0 0 1 6-6zM12 7v3",
  trackpad: "M5 4h14a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1zM4 15h16M12 15v5",
  touch: "M9 11.5V6a1.5 1.5 0 0 1 3 0v5M12 10.5a1.5 1.5 0 0 1 3 0V12M15 11.5a1.5 1.5 0 0 1 3 0V16a5 5 0 0 1-5 5h-1.2a5 5 0 0 1-4.1-2.1L5.3 15.5a1.5 1.5 0 0 1 2.3-1.9L9 15",
  keyboard: "M3 6h18v12H3zM7 10h.01M11 10h.01M15 10h.01M7 14h10",
  keys: "M4 7h4v4H4zM10 7h4v4h-4zM16 7h4v4h-4zM4 14h16v3H4z",
  x: "M6 6l12 12M18 6L6 18",
  check: "M5 12.5l4.5 4.5L19 7",
  chev: "M6 9l6 6l6-6",
  chevUp: "M6 15l6-6l6 6",
  back: "M15 6l-6 6l6 6",
  fwd: "M9 6l6 6l-6 6",
  search: "M11 4a7 7 0 1 0 0 14a7 7 0 1 0 0-14zM20 20l-4-4",
  minus: "M6 12h18",
  minimize: "M6 12h12",
  square: "M5 5h14v14H5z",
  info: "M12 3a9 9 0 1 0 0 18a9 9 0 1 0 0-18zM12 11v6M12 7.5h.01",
  alert: "M12 3.5l9.5 16.5h-19zM12 10v4.5M12 17.5h.01",
  shield: "M12 3l7 3v6c0 4.5-3 7.5-7 9c-4-1.5-7-4.5-7-9V6zM9 12l2 2l4-4",
  wifi: "M2.5 9a14 14 0 0 1 19 0M5.5 12.5a9.5 9.5 0 0 1 13 0M8.5 16a5 5 0 0 1 7 0M12 19.5h.01",
  wifiOff: "M2.5 9a14 14 0 0 1 5-3M12 5.5a14 14 0 0 1 9.5 3.5M5.5 12.5a9.5 9.5 0 0 1 3.5-2.2M8.5 16a5 5 0 0 1 7 0M12 19.5h.01M3 3l18 18",
  link: "M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1",
  trash: "M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13",
  sliders: "M4 7h9M17 7h3M4 17h3M11 17h9M15 4.5v5M9 14.5v5",
  expand: "M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5",
  shrink: "M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5",
  fit: "M8 4H4v4M16 4h4v4M8 20H4v-4M16 20h4v-4M9 9h6v6H9z",
  orbit: "M12 10a2 2 0 1 0 0 4a2 2 0 1 0 0-4zM3 12c0-2 4-4 9-4s9 2 9 4s-4 4-9 4s-9-2-9-4z",
  user: "M12 4a4 4 0 1 0 0 8a4 4 0 1 0 0-8zM4 21a8 8 0 0 1 16 0",
  brief: "M4 8h16v11H4zM9 8V5h6v3M4 13h16",
  plus: "M12 5v14M5 12h14",
  arrowL: "M19 12H5M11 6l-6 6l6 6",
  arrowR: "M5 12h14M13 6l6 6l-6 6",
  arrowU: "M12 19V5M6 11l6-6l6 6",
  arrowD: "M12 5v14M6 13l6 6l6-6",
  backspace: "M9 5h11v14H9l-6-7zM12 9l6 6M18 9l-6 6",
  enter: "M20 5v7a3 3 0 0 1-3 3H5M9 11l-4 4l4 4",
  help: "M12 3a9 9 0 1 0 0 18a9 9 0 1 0 0-18zM9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.6.3-1 .9-1 1.6v.6M12 17.5h.01",
  hand: "M8 13V6.5a1.5 1.5 0 0 1 3 0V12M11 11V5a1.5 1.5 0 0 1 3 0v6M14 11.5V7a1.5 1.5 0 0 1 3 0v8a6 6 0 0 1-6 6h-.5a6 6 0 0 1-5-2.7L3.8 15.5a1.5 1.5 0 0 1 2.4-1.8L8 15.5",
  quality: "M12 3a9 9 0 1 0 0 18a9 9 0 1 0 0-18zM12 3v18M12 7.5h5.5M12 12h9M12 16.5h5.5",
};

/** One SVG element for a path (stroke icon). */
export function svg(path, size = 20, stroke = 1.9) {
  const NS = "http://www.w3.org/2000/svg";
  const s = document.createElementNS(NS, "svg");
  s.setAttribute("width", size);
  s.setAttribute("height", size);
  s.setAttribute("viewBox", "0 0 24 24");
  s.setAttribute("fill", "none");
  s.setAttribute("stroke", "currentColor");
  s.setAttribute("stroke-width", stroke);
  s.setAttribute("stroke-linecap", "round");
  s.setAttribute("stroke-linejoin", "round");
  s.setAttribute("aria-hidden", "true");
  const p = document.createElementNS(NS, "path");
  p.setAttribute("d", I[path] || path || I.grid);
  s.appendChild(p);
  return s;
}
