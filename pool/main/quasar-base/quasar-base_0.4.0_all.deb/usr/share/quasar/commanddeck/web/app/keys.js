// The phone's keyboard for the remote screen and the trackpad.
// - A hidden <textarea> raises the soft keyboard. What's typed is found by diffing its value after
//   every `input` event (works with IMEs, autocorrect, swipe typing and Android's keyCode 229), and
//   goes out as {t:"text"} plus BackSpace taps. A two-space sentinel lets Backspace on an "empty"
//   field still produce an event. Hardware keys (Enter, arrows, Ctrl+…) are taken from keydown.
// - The key bar: sticky Ctrl/Alt/Shift/Super (tap = once, tap again = locked, again = off), Esc, Tab,
//   arrows, Home/End, PgUp/PgDn, F-keys, the launcher (Super) key. It sits above the soft keyboard
//   (visualViewport), and its buttons never take focus away from the textarea.
import { h, svg, vibrate } from "./ui.js";

const SENT = "  ";
const PUNCT = {
  " ": "space", "-": "minus", "=": "equal", "[": "bracketleft", "]": "bracketright", "\\": "backslash", ";": "semicolon",
  "'": "apostrophe", ",": "comma", ".": "period", "/": "slash", "`": "grave", "!": "exclam", "@": "at", "#": "numbersign",
  "$": "dollar", "%": "percent", "^": "asciicircum", "&": "ampersand", "*": "asterisk", "(": "parenleft", ")": "parenright",
  "_": "underscore", "+": "plus", "{": "braceleft", "}": "braceright", "|": "bar", ":": "colon", "\"": "quotedbl", "<": "less",
  ">": "greater", "?": "question", "~": "asciitilde",
};
const SPECIAL = {
  Enter: "Return", Backspace: "BackSpace", Tab: "Tab", Escape: "Escape", ArrowLeft: "Left", ArrowRight: "Right", ArrowUp: "Up",
  ArrowDown: "Down", Home: "Home", End: "End", PageUp: "Page_Up", PageDown: "Page_Down", Delete: "Delete", Insert: "Insert",
  ContextMenu: "Menu", PrintScreen: "Print",
};
for (let i = 1; i <= 12; i++) SPECIAL["F" + i] = "F" + i;

/** xkb keysym name for one typed character (letters lowercase: Shift is a modifier). */
export function keysymFor(ch) {
  if (/^[a-zA-Z0-9]$/.test(ch)) return ch.toLowerCase();
  return PUNCT[ch] || null;
}

const MODS = ["ctrl", "alt", "shift", "super"];
const REPEAT = new Set(["Left", "Right", "Up", "Down", "BackSpace", "Delete", "Page_Up", "Page_Down"]);

// [label or {icon}, keysym or "mod:<name>" or "page" or "hide", extra class]
const ROW1 = [["Esc", "Escape"], ["Tab", "Tab"], ["Ctrl", "mod:ctrl"], ["Alt", "mod:alt"], ["Shift", "mod:shift"], ["Super", "mod:super"],
  [{ icon: "grid", label: "Launcher (Super)" }, "Super_L", "accent"], [{ icon: "enter", label: "Enter" }, "Return"], [{ icon: "chev", label: "Hide keyboard" }, "hide"]];
const PAGES = [
  [[{ icon: "arrowL", label: "Left" }, "Left"], [{ icon: "arrowU", label: "Up" }, "Up"], [{ icon: "arrowD", label: "Down" }, "Down"],
    [{ icon: "arrowR", label: "Right" }, "Right"], ["Home", "Home"], ["End", "End"], [{ icon: "backspace", label: "Backspace" }, "BackSpace"], ["Del", "Delete"]],
  [["F1", "F1"], ["F2", "F2"], ["F3", "F3"], ["F4", "F4"], ["F5", "F5"], ["F6", "F6"], ["PgUp", "Page_Up"], ["PgDn", "Page_Down"]],
  [["F7", "F7"], ["F8", "F8"], ["F9", "F9"], ["F10", "F10"], ["F11", "F11"], ["F12", "F12"], ["PrtSc", "Print"], ["Ins", "Insert"]],
];

export class KeyInput {
  /** send(cmd) gets engine commands ({t:"text"} / {t:"tap"}); onChange({keyboard, bar}) when what's shown changes. */
  constructor({ send, host, onChange }) {
    this.send = send;
    this.onChange = onChange || (() => {});
    this.mods = { ctrl: 0, alt: 0, shift: 0, super: 0 };
    this.page = 0;
    this.barShown = false;
    this.kbOpen = false;
    this.composing = false;
    this.prev = SENT;

    this.sink = h("textarea.kb-sink", {
      "aria-label": "Type on the PC", autocomplete: "off", autocorrect: "off", autocapitalize: "off", spellcheck: "false",
      inputmode: "text", enterkeyhint: "enter", rows: "1", tabindex: "-1",
    });
    this.sink.value = SENT;
    this.bar = h("div.keybar.docked", { role: "toolbar", "aria-label": "Keys" });
    this.bar.hidden = true;
    this.row1 = h("div.keyrow");
    this.row2 = h("div.keyrow");
    this.bar.append(this.row1, this.row2);
    this.modKeys = {};
    for (const k of ROW1) this.row1.appendChild(this._key(k));
    this._paintPage();
    host.append(this.sink, this.bar);

    this._wire();
  }

  // ---- keys ------------------------------------------------------------------------------------------
  _key([label, action, cls]) {
    const b = h("button.key" + (cls ? "." + cls : ""), { type: "button", tabindex: "-1", "data-press": "off" });
    if (typeof label === "string") b.textContent = label; else { b.appendChild(svg(label.icon, 18, 2)); b.setAttribute("aria-label", label.label); }
    if (action.startsWith("mod:")) {
      const m = action.slice(4);
      b.classList.add("mod");
      b.dataset.state = "0";
      this.modKeys[m] = b;
    }
    let repeatT = 0, repeatI = 0, fired = false;
    const fire = () => {
      fired = true;
      if (action === "hide") { this.hide(); return; }
      if (action === "page") { this.page = (this.page + 1) % PAGES.length; this._paintPage(); return; }
      if (action.startsWith("mod:")) { this._cycleMod(action.slice(4)); return; }
      this.tap(action);
    };
    b.addEventListener("pointerdown", (e) => {
      e.preventDefault();                       // keep the soft keyboard (focus stays in the textarea)
      b.classList.add("is-pressed");
      fired = false;
      vibrate(4);
      if (REPEAT.has(action)) {
        fire();
        repeatT = setTimeout(() => { repeatI = setInterval(() => this.tap(action), 70); }, 420);
      }
    });
    const end = (e, ok) => {
      b.classList.remove("is-pressed");
      clearTimeout(repeatT); clearInterval(repeatI);
      if (ok && !fired) fire();
    };
    b.addEventListener("pointerup", (e) => end(e, true));
    b.addEventListener("pointercancel", (e) => end(e, false));
    b.addEventListener("pointerleave", (e) => { if (b.classList.contains("is-pressed")) end(e, false); });
    b.addEventListener("click", (e) => { if (e.detail === 0) fire(); });   // keyboard activation (Enter/Space)
    b.addEventListener("contextmenu", (e) => e.preventDefault());
    return b;
  }

  _paintPage() {
    while (this.row2.firstChild) this.row2.firstChild.remove();
    for (const k of PAGES[this.page]) this.row2.appendChild(this._key(k));
    const more = this._key([this.page === 0 ? "F1–12" : this.page === 1 ? "More" : "Arrows", "page"]);
    more.classList.add("accent");
    more.setAttribute("aria-label", "More keys");
    this.row2.appendChild(more);
  }

  _cycleMod(m) {
    this.mods[m] = (this.mods[m] + 1) % 3;
    this._paintMods();
  }
  _paintMods() { for (const m of MODS) if (this.modKeys[m]) this.modKeys[m].dataset.state = String(this.mods[m]); }
  _activeMods() { return MODS.filter((m) => this.mods[m] > 0); }
  _spendMods() {
    let changed = false;
    for (const m of MODS) if (this.mods[m] === 1) { this.mods[m] = 0; changed = true; }
    if (changed) this._paintMods();
  }

  /** Press and release one key (keysym name) with the sticky modifiers, plus `extra` ones. */
  tap(k, extra = []) {
    const mods = [...new Set([...this._activeMods(), ...extra])];
    this.send(mods.length ? { t: "tap", k, mods } : { t: "tap", k });
    this._spendMods();
  }

  _typed(text) {
    if (!text) return;
    const parts = text.split("\n");
    parts.forEach((p, i) => {
      if (i > 0) this.tap("Return");
      if (!p) return;
      if (this._activeMods().some((m) => m !== "shift") || (this.mods.shift && p.length === 1)) {
        for (const ch of p) { const k = keysymFor(ch); if (k) this.tap(k); else { this.send({ t: "text", s: ch }); this._spendMods(); } }
      } else {
        this.send({ t: "text", s: p });
      }
    });
  }

  // ---- the textarea ----------------------------------------------------------------------------------
  _wire() {
    const s = this.sink;
    s.addEventListener("compositionstart", () => { this.composing = true; });
    s.addEventListener("compositionend", () => { this.composing = false; this._diff(); this._maybeReset(); });
    s.addEventListener("input", () => { this._diff(); if (!this.composing) this._maybeReset(); });
    s.addEventListener("keydown", (e) => {
      if (e.isComposing || e.keyCode === 229) return;          // the IME: wait for `input`
      const extra = [];
      if (e.ctrlKey) extra.push("ctrl");
      if (e.altKey) extra.push("alt");
      if (e.metaKey) extra.push("super");
      const special = SPECIAL[e.key];
      if (special) {
        e.preventDefault();
        if (e.shiftKey) extra.push("shift");
        this.tap(special, extra);
        return;
      }
      if (extra.length && e.key.length === 1) {               // a shortcut from a hardware keyboard
        e.preventDefault();
        if (e.shiftKey) extra.push("shift");
        const k = keysymFor(e.key);
        if (k) this.tap(k, extra);
      }
    });
    s.addEventListener("focus", () => { this.kbOpen = true; this._show(true); this._emit(); });
    s.addEventListener("blur", () => { this.kbOpen = false; this._emit(); if (!this.barShown) this._show(false); });
    // keep the caret at the end, or the diff loses track (iOS lets the space bar move it)
    document.addEventListener("selectionchange", this._sel = () => {
      if (document.activeElement !== s || this.composing) return;
      const end = s.value.length;
      if (s.selectionStart !== end || s.selectionEnd !== end) s.setSelectionRange(end, end);
    });
    // sit above the soft keyboard
    const vv = window.visualViewport;
    this._vv = () => {
      if (!vv) return;
      const bottom = Math.max(0, window.innerHeight - vv.height - vv.offsetTop);
      this.bar.style.bottom = bottom + "px";
      this.bar.classList.toggle("docked", bottom < 40);
    };
    if (vv) { vv.addEventListener("resize", this._vv); vv.addEventListener("scroll", this._vv); }
  }

  _diff() {
    const v = this.sink.value, p = this.prev;
    if (v === p) return;
    let i = 0;
    const n = Math.min(v.length, p.length);
    while (i < n && v.charCodeAt(i) === p.charCodeAt(i)) i++;
    const del = p.length - i;
    const ins = v.slice(i);
    for (let k = 0; k < del; k++) this.tap("BackSpace");
    this._typed(ins);
    this.prev = v;
  }

  _maybeReset() {
    const v = this.sink.value;
    if (v.length < SENT.length || !v.startsWith(SENT) || v.length > 48 || v.includes("\n")) {
      this.sink.value = SENT;
      this.prev = SENT;
      try { this.sink.setSelectionRange(SENT.length, SENT.length); } catch { /* */ }
    }
  }

  _show(on) {
    this.bar.hidden = !on;
    if (on) this._vv();
  }
  _emit() { this.onChange({ keyboard: this.kbOpen, bar: !this.bar.hidden }); }

  // ---- public ----------------------------------------------------------------------------------------
  /** Raise the soft keyboard. Call it straight from a tap handler (iOS only allows focus there). */
  open() {
    this.sink.value = SENT; this.prev = SENT;
    this.sink.focus({ preventScroll: true });
    try { this.sink.setSelectionRange(SENT.length, SENT.length); } catch { /* */ }
    this._show(true);
    this._emit();
  }
  /** Show or hide just the key bar (no soft keyboard). */
  toggleBar() {
    this.barShown = !this.barShown;
    if (!this.barShown) { this.hide(); return; }
    this._show(true);
    this._emit();
  }
  hide() {
    this.barShown = false;
    this.sink.blur();
    this._show(false);
    this._emit();
  }
  get visible() { return !this.bar.hidden; }
  destroy() {
    document.removeEventListener("selectionchange", this._sel);
    const vv = window.visualViewport;
    if (vv) { vv.removeEventListener("resize", this._vv); vv.removeEventListener("scroll", this._vv); }
    this.sink.remove(); this.bar.remove();
  }
}
