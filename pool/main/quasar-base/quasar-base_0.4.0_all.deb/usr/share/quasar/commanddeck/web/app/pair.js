// Pairing and the phone's key (PROTOCOL.md §1 "Pairing").
// The phone makes an X25519 key pair for each PC (pcId), so two PCs that show up at the same address never
// share a key. The QR token (or the 6-digit code) is the shared secret: it never crosses the network. The
// phone sends its public key with a MAC made from it, and stores nothing until the PC's answer carries a MAC
// made from it too (so each side knows the other saw the code on the PC's screen).
import { idbGet, idbPut, idbDelete } from "./idb.js";
import { b64u, unb64u, pairMac, pairedMac, sameMac, shared } from "./seal.js";

const INFO_KEY = "deck.info";

/** Everything the app needs: NaCl (app/vendor/nacl-fast.min.js), a random source, IndexedDB. */
export function cryptoReady() {
  return !!(self.nacl && self.nacl.box && self.nacl.secretbox && self.crypto && typeof crypto.getRandomValues === "function" && "indexedDB" in self);
}

/** GET /api/info; remembered so the app can still say which PC it can't reach. */
export async function getInfo({ timeout = 6000 } = {}) {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), timeout);
  try {
    const r = await fetch("/api/info", { cache: "no-store", signal: ctl.signal });
    if (!r.ok) throw new Error("http " + r.status);
    const info = await r.json();
    if (!info || typeof info.pcId !== "string") throw new Error("bad info");
    try { localStorage.setItem(INFO_KEY, JSON.stringify({ pcId: info.pcId, name: info.name })); } catch { /* private mode */ }
    return info;
  } finally {
    clearTimeout(t);
  }
}
export function cachedInfo() {
  try { return JSON.parse(localStorage.getItem(INFO_KEY) || "null"); } catch { return null; }
}

const isKey = (x) => x instanceof Uint8Array && x.length === 32;

/** This phone's record for a PC: {pcId, deviceId, name, secret, pcPub, paired}. Records from before
 *  sealing (an ECDSA CryptoKey, no secret/pcPub) don't count: those phones simply pair again. */
export async function loadDevice(pcId) {
  try {
    const d = await idbGet("devices", pcId);
    return d && typeof d.deviceId === "string" && d.deviceId && isKey(d.secret) && isKey(d.pcPub) ? d : null;
  } catch { return null; }
}
export async function forgetDevice(pcId) {
  try { await idbDelete("devices", pcId); } catch { /* nothing stored */ }
}

/** A fresh X25519 key pair: {secret: Uint8Array(32), pub: base64url}. */
export function makeKey() {
  const kp = self.nacl.box.keyPair();
  return { secret: kp.secretKey, pub: b64u(kp.publicKey) };
}

export class PairError extends Error {
  constructor(code, message) { super(message || code); this.code = code; }
}

/** POST /api/pair with a MAC made from the QR token or the 6-digit code (neither is sent). Checks the
 *  PC's answer, then stores and returns the device record. */
export async function pair({ pcId, token, code, name, model, keyPair }) {
  const kp = keyPair || makeKey();
  const secretText = token || code || "";
  if (!pcId || !secretText) throw new PairError("failed", "That didn't work. Try again.");
  const body = { via: token ? "qr" : "code", name, model, pub: kp.pub, mac: pairMac(secretText, pcId, kp.pub, name, model) };
  let r, data = null;
  try {
    r = await fetch("/api/pair", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body), cache: "no-store" });
    data = await r.json().catch(() => null);
  } catch {
    throw new PairError("offline", "Can't reach the PC.");
  }
  if (!r.ok || !data || !data.ok) {
    const c = (data && data.code) || (r.status === 429 ? "slow-down" : "failed");
    throw new PairError(c, data && data.error);
  }
  // Only the PC that showed the code can make this MAC: it covers our key, the device id and its own key.
  const dev = data.device || {};
  const pcPub = unb64u(data.pcPub, 32);
  const ok = typeof dev.id === "string" && !!dev.id && !!pcPub && (!data.pcId || data.pcId === pcId)
    && sameMac(data.mac, pairedMac(secretText, pcId, kp.pub, dev.id, data.pcPub)) && !!shared(kp.secret, pcPub);
  if (!ok) throw new PairError("bad-pc", "Something on this network changed the PC's answer. Try again.");
  const rec = { pcId, deviceId: dev.id, name: typeof dev.name === "string" && dev.name ? dev.name : name, secret: kp.secret, pcPub, paired: Date.now() };
  await idbPut("devices", rec);
  return rec;
}

/** A friendly default name for this phone ("iPhone", "Pixel 8") and a model string. */
export async function guessName() {
  const ua = navigator.userAgent || "";
  let name = "Phone", model = "";
  if (/iPhone/.test(ua)) {
    const v = /OS (\d+)[_.](\d+)/.exec(ua);
    name = "iPhone"; model = "iPhone" + (v ? " (iOS " + v[1] + "." + v[2] + ")" : "");
  } else if (/iPad/.test(ua) || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1)) {
    name = "iPad"; model = "iPad";
  } else if (/Android/.test(ua)) {
    let m = "";
    try {
      // (HTTPS only: over plain HTTP userAgentData is missing and the user agent string has to do)
      if (navigator.userAgentData && navigator.userAgentData.getHighEntropyValues) {
        const hv = await navigator.userAgentData.getHighEntropyValues(["model"]);
        m = (hv.model || "").trim();
      }
    } catch { /* not offered */ }
    if (!m) { const x = /Android [\d.]+; ([^;)]+)/.exec(ua); m = x ? x[1].trim() : ""; }
    if (m === "K" || /^wv$/.test(m)) m = "";
    model = m || "Android";
    name = !m ? "Android phone" : /^SM-/.test(m) ? "Samsung Galaxy" : m;
  } else {
    const b = /Edg\//.test(ua) ? "Edge" : /Firefox\//.test(ua) ? "Firefox" : /Chrome\//.test(ua) ? "Chrome" : /Safari\//.test(ua) ? "Safari" : "Browser";
    const os = /Windows/.test(ua) ? "Windows" : /Mac OS/.test(ua) ? "Mac" : /Linux/.test(ua) ? "Linux" : "";
    name = b + (os ? " on " + os : ""); model = name;
  }
  return { name: name.slice(0, 40), model: model.slice(0, 40) };
}
