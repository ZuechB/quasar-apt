// The Command Deck UI kit: small DOM helpers in Quasar's design language (ui/Quasar components on a
// phone). Pure DOM, no framework. CSP forbids inline style attributes, so styles are only ever set
// through el.style.* (never setAttribute("style") or innerHTML with style=).
import { I, svg } from "./icons.js";

export { I, svg };

// ---- DOM ---------------------------------------------------------------------------------------
/** h("button.btn.primary", {onclick, "aria-label": "…", style: {…}}, ...children) */
export function h(sel, props, ...kids) {
  const [tag, ...classes] = sel.split(".");
  const el = document.createElement(tag || "div");
  if (classes.length) el.className = classes.join(" ");
  if (props && (typeof props !== "object" || props instanceof Node || Array.isArray(props))) {
    kids.unshift(props);
    props = null;
  }
  if (props) {
    for (const [k, v] of Object.entries(props)) {
      if (v === undefined || v === null || v === false) continue;
      if (k === "style") Object.assign(el.style, v);
      else if (k === "class") el.className += (el.className ? " " : "") + v;
      else if (k === "text") el.textContent = v;
      else if (k === "dataset") Object.assign(el.dataset, v);
      else if (k.startsWith("on") && typeof v === "function") el.addEventListener(k.slice(2), v);
      else if (k === "ref") v(el);
      else if (v === true) el.setAttribute(k, "");
      else el.setAttribute(k, v);
    }
  }
  append(el, kids);
  return el;
}

export function append(el, kids) {
  for (const k of kids.flat(Infinity)) {
    if (k === null || k === undefined || k === false) continue;
    el.appendChild(k instanceof Node ? k : document.createTextNode(String(k)));
  }
  return el;
}

export function clear(el) { while (el.firstChild) el.removeChild(el.firstChild); return el; }
export function icon(name, size = 20, stroke = 1.9) { return svg(name, size, stroke); }

// ---- small utilities --------------------------------------------------------------------------
export function vibrate(ms = 10) { try { navigator.vibrate && navigator.vibrate(ms); } catch { /* not allowed */ } }
export const reduceMotion = () => matchMedia("(prefers-reduced-motion: reduce)").matches;
export function debounce(fn, ms) {
  let t = 0;
  const d = (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
  d.cancel = () => clearTimeout(t);
  return d;
}
/** Calls fn at most every `ms`, always delivering the last value. */
export function throttle(fn, ms) {
  let last = 0, timer = 0, args = null;
  return (...a) => {
    args = a;
    const now = performance.now();
    if (now - last >= ms) { last = now; fn(...args); return; }
    clearTimeout(timer);
    timer = setTimeout(() => { last = performance.now(); fn(...args); }, ms - (now - last));
  };
}
export function formatBytes(n) {
  if (!Number.isFinite(n)) return "";
  if (n < 1000) return n + " B";
  const u = ["KB", "MB", "GB", "TB"];
  let i = -1;
  do { n /= 1000; i++; } while (n >= 1000 && i < u.length - 1);
  return (n >= 100 ? Math.round(n) : n.toFixed(1)) + " " + u[i];
}
export function formatTime(s) {
  s = Math.max(0, Math.floor(s || 0));
  const m = Math.floor(s / 60), r = s % 60;
  return m >= 60 ? Math.floor(m / 60) + ":" + String(m % 60).padStart(2, "0") + ":" + String(r).padStart(2, "0")
    : m + ":" + String(r).padStart(2, "0");
}

// Pressed state for every tappable thing (iOS Safari doesn't run :active reliably on touch).
let pressed = null, pressX = 0, pressY = 0;
const PRESSABLE = "button, [data-press], .tappable";
function unpress() { if (pressed) { pressed.classList.remove("is-pressed"); pressed = null; } }
document.addEventListener("pointerdown", (e) => {
  const t = e.target instanceof Element ? e.target.closest(PRESSABLE) : null;
  unpress();
  if (!t || t.disabled || t.dataset.press === "off") return;
  pressed = t; pressX = e.clientX; pressY = e.clientY;
  t.classList.add("is-pressed");
}, { passive: true });
document.addEventListener("pointermove", (e) => {
  if (pressed && Math.hypot(e.clientX - pressX, e.clientY - pressY) > 12) unpress();
}, { passive: true });
for (const ev of ["pointerup", "pointercancel", "scroll", "blur"]) addEventListener(ev, unpress, { passive: true, capture: true });
document.addEventListener("touchstart", () => {}, { passive: true });   // lets iOS apply :active

// ---- the Quasar mark ---------------------------------------------------------------------------
let markSvg = null;
const markLoad = fetch("/icons/mark.svg").then((r) => r.text()).then((t) => { markSvg = t; }).catch(() => {});
/** QuasarMark.qml at rest (icons/mark.svg, inlined so its glow can breathe while `busy`). */
export function mark(size = 48, { busy = false, dim = false } = {}) {
  const el = h("div.mark" + (busy ? ".busy" : "") + (dim ? ".dim" : ""), { "aria-hidden": "true" });
  el.style.width = el.style.height = size + "px";
  const fill = () => {
    if (!markSvg) return;
    const doc = new DOMParser().parseFromString(markSvg, "image/svg+xml");
    const s = doc.documentElement;
    s.removeAttribute("width"); s.removeAttribute("height");
    el.appendChild(document.importNode(s, true));
  };
  if (markSvg) fill(); else markLoad.then(fill);
  return el;
}

// ---- buttons -----------------------------------------------------------------------------------
export function button({ label, icon: ic, kind = "", onClick, small, block, disabled, busy, aria, type = "button" } = {}) {
  const b = h("button.btn", { type, "aria-label": aria, disabled: !!disabled });
  for (const k of [kind, small && "small", block && "block"]) if (k) for (const c of k.split(" ")) b.classList.add(c);
  const draw = (l, ic2, spin) => {
    clear(b);
    if (spin) b.appendChild(h("span.spinner"));
    else if (ic2) b.appendChild(svg(ic2, small ? 16 : 18, 2));
    if (l) b.appendChild(h("span", l));
  };
  draw(label, ic, busy);
  if (onClick) b.addEventListener("click", onClick);
  b.setBusy = (v, l = label) => { b.disabled = !!v; draw(l, ic, v); };
  b.setLabel = (l) => { label = l; draw(l, ic, false); };
  return b;
}

export function iconButton({ icon: ic, label, onClick, filled, on, size = 20, cls = "" } = {}) {
  const b = h("button.icon-btn" + (filled ? ".filled" : "") + (on ? ".on" : "") + (cls ? "." + cls : ""),
    { type: "button", "aria-label": label, title: label }, svg(ic, size, 2));
  if (onClick) b.addEventListener("click", onClick);
  b.setIcon = (n) => { clear(b); b.appendChild(svg(n, size, 2)); };
  return b;
}

// ---- rows, groups, cards ---------------------------------------------------------------------------
/** A list row (SettingsRow). `lead` is an icon name or an element. */
export function row({ lead, leadColor, title, sub, trail, chevron, onClick, danger, cls = "", aria } = {}) {
  const tag = onClick ? "button.row" : "div.row";
  const r = h(tag + (danger ? ".danger" : "") + (cls ? "." + cls : ""), onClick ? { type: "button", "aria-label": aria } : null);
  if (lead) {
    const l = typeof lead === "string" ? h("span.lead", svg(lead, 19)) : lead;
    if (typeof lead === "string" && leadColor) l.style.color = leadColor;
    r.appendChild(l);
  }
  const body = h("span.body", h("span.title", title));
  if (sub) body.appendChild(h("span.sub", sub));
  r.appendChild(body);
  const tr = h("span.trail");
  if (trail) append(tr, [trail]);
  if (chevron) tr.appendChild(svg("fwd", 18, 2));
  if (tr.childNodes.length) r.appendChild(tr);
  if (onClick) r.addEventListener("click", onClick);
  r.setSub = (s) => {
    let el = body.querySelector(".sub");
    if (!el) { el = h("span.sub"); body.appendChild(el); }
    el.textContent = s;
  };
  return r;
}
export function group(...rows) { return h("div.group", ...rows); }
export function card(...kids) { return h("div.card", ...kids); }
export function sectionLabel(text, action) {
  const el = h("div.section-label", h("span.grow", text));
  if (action) el.appendChild(h("button.link", { type: "button", onclick: action.onClick }, action.label));
  return el;
}
export function pageHead({ title, sub, back, trailing } = {}) {
  const el = h("header.page-head");
  if (back) el.appendChild(iconButton({ icon: "back", label: "Back", onClick: back, cls: "back" }));
  const t = h("div.grow", h("h1.page-title", title));
  if (sub) t.appendChild(h("p.page-sub", sub));
  el.appendChild(t);
  if (trailing) append(el, [trailing]);
  return el;
}

// ---- tiles ---------------------------------------------------------------------------------------
/** A quick-settings tile. Returns the button; .set({label, sub, on, icon, disabled}). */
export function tile({ icon: ic, label, sub, on, onClick, span, disabled } = {}) {
  const chip = h("span.chip", svg(ic, 20));
  const lbl = h("span.lbl", label), sb = h("span.sub", sub || "");
  const b = h("button.tile" + (span === 2 ? ".span2" : ""), { type: "button" }, chip, h("span.tx", lbl, sb));
  b.set = (o = {}) => {
    if (o.label !== undefined) lbl.textContent = o.label;
    if (o.sub !== undefined) sb.textContent = o.sub;
    if (o.icon) { clear(chip); chip.appendChild(svg(o.icon, 20)); }
    if (o.on !== undefined) { b.classList.toggle("on", !!o.on); b.setAttribute("aria-pressed", String(!!o.on)); }
    if (o.disabled !== undefined) b.setAttribute("aria-disabled", String(!!o.disabled));
  };
  b.set({ on: !!on, disabled: !!disabled });
  if (onClick) b.addEventListener("click", (e) => { if (b.getAttribute("aria-disabled") !== "true") onClick(e); });
  return b;
}

// ---- switch ------------------------------------------------------------------------------------
export function switchEl({ checked, onChange, label } = {}) {
  const s = h("button.switch", { type: "button", role: "switch", "aria-label": label, "aria-checked": String(!!checked) }, h("span.knob"));
  s.addEventListener("click", () => { const v = s.getAttribute("aria-checked") !== "true"; s.set(v); onChange && onChange(v); });
  s.set = (v) => s.setAttribute("aria-checked", String(!!v));
  return s;
}

// ---- fill slider (FillSlider.qml / Quick settings) --------------------------------------------------
/** A touch-friendly 0..100 slider. Horizontal drags adjust; vertical swipes still scroll the page. */
export function fillSlider({ value = 0, icon: ic = "vol", label = "Volume", onInput, onChange, showValue = true } = {}) {
  const fill = h("div.fill");
  const ico = h("span.ico", svg(ic, 20, 2));
  const val = h("span.val");
  const el = h("div.fill-slider", { role: "slider", tabindex: "0", "aria-label": label, "aria-valuemin": "0", "aria-valuemax": "100" }, fill, ico, showValue ? val : null);
  let v = 0, dragging = false, startX = 0, startY = 0, decided = false, id = null, startV = 0;
  const draw = () => {
    fill.style.transform = "scaleX(" + v / 100 + ")";
    val.textContent = Math.round(v) + "%";
    el.setAttribute("aria-valuenow", String(Math.round(v)));
  };
  el.set = (nv) => { if (!dragging) { v = Math.max(0, Math.min(100, Number(nv) || 0)); draw(); } };
  el.setIcon = (n) => { clear(ico); ico.appendChild(svg(n, 20, 2)); };
  el.setMuted = (m) => el.classList.toggle("muted", !!m);
  el.value = () => v;
  const fromX = (x) => { const r = el.getBoundingClientRect(); return Math.max(0, Math.min(100, ((x - r.left) / r.width) * 100)); };
  el.addEventListener("pointerdown", (e) => {
    id = e.pointerId; startX = e.clientX; startY = e.clientY; decided = e.pointerType === "mouse"; startV = v;
    if (decided) { dragging = true; el.setPointerCapture(id); el.classList.add("dragging"); v = fromX(e.clientX); draw(); onInput && onInput(Math.round(v)); }
  });
  el.addEventListener("pointermove", (e) => {
    if (e.pointerId !== id) return;
    if (!decided) {
      const dx = Math.abs(e.clientX - startX), dy = Math.abs(e.clientY - startY);
      if (dx < 6 && dy < 6) return;
      decided = true;
      if (dy > dx) { id = null; return; }                    // a page scroll: let it go
      dragging = true; el.setPointerCapture(id); el.classList.add("dragging");
    }
    if (!dragging) return;
    // relative drag from where the finger went down (no jump), like the desktop's FillSlider
    const r = el.getBoundingClientRect();
    v = Math.max(0, Math.min(100, startV + ((e.clientX - startX) / r.width) * 100));
    draw(); onInput && onInput(Math.round(v));
  });
  const end = (e, commit) => {
    if (e.pointerId !== id) return;
    if (!decided && commit) { v = fromX(e.clientX); draw(); onInput && onInput(Math.round(v)); dragging = true; }
    if (dragging) { dragging = false; el.classList.remove("dragging"); if (commit) onChange && onChange(Math.round(v)); }
    id = null;
  };
  el.addEventListener("pointerup", (e) => end(e, true));
  el.addEventListener("pointercancel", (e) => end(e, false));
  el.addEventListener("keydown", (e) => {
    const d = { ArrowRight: 5, ArrowUp: 5, ArrowLeft: -5, ArrowDown: -5, PageUp: 10, PageDown: -10 }[e.key];
    if (d === undefined) return;
    e.preventDefault();
    v = Math.max(0, Math.min(100, v + d)); draw();
    onInput && onInput(Math.round(v)); onChange && onChange(Math.round(v));
  });
  el.set(value);
  return el;
}

// ---- segmented ----------------------------------------------------------------------------------
export function segmented({ options, value, onChange, label } = {}) {
  const pill = h("div.seg-pill");
  const el = h("div.segmented", { role: "group", "aria-label": label }, pill);
  const btns = options.map((o) => {
    const b = h("button", { type: "button", "aria-pressed": "false" }, o.icon ? svg(o.icon, 16, 2) : null, o.label);
    b.addEventListener("click", () => { if (value !== o.id) { el.set(o.id); onChange && onChange(o.id); } });
    el.appendChild(b);
    return b;
  });
  pill.style.width = "calc((100% - 6px) / " + options.length + ")";
  el.set = (v) => {
    value = v;
    const i = Math.max(0, options.findIndex((o) => o.id === v));
    pill.style.transform = "translateX(" + i * 100 + "%)";
    btns.forEach((b, j) => b.setAttribute("aria-pressed", String(j === i)));
  };
  el.set(value);
  return el;
}

// ---- states ---------------------------------------------------------------------------------------
export function spinner(big) { return h("span.spinner" + (big ? ".big" : ""), { role: "progressbar", "aria-label": "Loading" }); }
export function progress(v = 0) {
  const bar = h("i");
  const el = h("div.progress", { role: "progressbar", "aria-valuemin": "0", "aria-valuemax": "100" }, bar);
  el.set = (p) => { p = Math.max(0, Math.min(1, p)); bar.style.transform = "scaleX(" + p + ")"; el.setAttribute("aria-valuenow", String(Math.round(p * 100))); };
  el.set(v);
  return el;
}
export function banner({ kind = "", icon: ic = "info", title, body, onClose } = {}) {
  const el = h("div.banner" + (kind ? "." + kind : ""), { role: "status" },
    h("span.bi", svg(ic, 20)), h("div.grow", title ? h("div.bt", title) : null, body ? h("div.bs", body) : null));
  if (onClose) el.appendChild(iconButton({ icon: "x", label: "Dismiss", onClick: onClose, cls: "bx", size: 16 }));
  return el;
}
export function empty({ icon: ic = "info", title, body, actions = [], full } = {}) {
  return h("div.empty" + (full ? ".full" : ""), h("div.eico", svg(ic, 28, 1.8)), h("div.et", title), body ? h("div.eb", body) : null,
    actions.length ? h("div.ea", ...actions) : null);
}
export function errorState({ title = "Something went wrong", body, retry } = {}) {
  return empty({ icon: "alert", title, body, actions: retry ? [button({ label: "Try again", icon: "refresh", kind: "primary", onClick: retry })] : [] });
}
export function skeletonRows(n = 4) {
  return group(...Array.from({ length: n }, () => h("div.skel-row", h("div.skel.a"), h("div.grow", h("div.skel.b"), h("div.skel.c")))));
}

// ---- app icons ------------------------------------------------------------------------------------
// The icon image comes from the PC over the control socket (app.js: loader(name) → blob: URL | null,
// loader.peek(name) for what's already known, so a list redraw doesn't flicker).
let iconLoader = null;
export function setIconLoader(fn) { iconLoader = fn; }
function hueGlow(hue) {
  const m = /^#?([0-9a-f]{6})$/i.exec(String(hue || ""));
  if (!m) return null;
  const n = parseInt(m[1], 16);
  return "rgba(" + (n >> 16) + "," + ((n >> 8) & 255) + "," + (n & 255) + ",.4)";
}
/** An app's icon: its theme icon (the `icon` op), else Quasar's own glyph on a tile, else a monogram. */
export function appIcon(app, size = 44) {
  const el = h("span.app-ico.s" + size, { "aria-hidden": "true" });
  const hue = app && app.hue;
  if (hue) { el.style.setProperty("--hue", hue); const g = hueGlow(hue); if (g) el.style.setProperty("--hue-glow", g); }
  const fallback = () => {
    clear(el);
    el.classList.add("tile-bg");
    if (app && app.glyph) el.appendChild(svg(app.glyph, Math.round(size * 0.52), 1.8));
    else el.appendChild(h("span.mono", ((app && (app.letter || app.name)) || "?").trim().charAt(0).toUpperCase()));
  };
  const show = (url) => {
    if (!url) { fallback(); return; }
    const img = h("img", { alt: "", decoding: "async", draggable: "false" });
    img.addEventListener("error", fallback, { once: true });
    img.src = url;
    clear(el).appendChild(img);
  };
  const name = app && app.icon;
  if (name && iconLoader) {
    const known = iconLoader.peek ? iconLoader.peek(name) : undefined;
    if (known !== undefined) show(known);
    else iconLoader(name).then(show, fallback);
  } else fallback();
  return el;
}

// ---- layers: sheets, confirm (Android back closes them) ------------------------------------------------
const layers = [];
let layerSeq = 0, ignorePops = 0, popWaiters = [];
addEventListener("popstate", (e) => {
  if (ignorePops > 0) {
    ignorePops--;
    if (!ignorePops) { popWaiters.forEach((r) => r()); popWaiters = []; }
    return;
  }
  const top = layers[layers.length - 1];
  if (top && !(e.state && e.state.layer === top.id)) { layers.pop(); top.close(true); }
});
function pushLayer(close) {
  const id = ++layerSeq;
  layers.push({ id, close });
  try { history.pushState({ ...(history.state || {}), layer: id }, ""); } catch { /* sandboxed */ }
  return id;
}
function dropLayer(id) {
  const i = layers.findIndex((l) => l.id === id);
  if (i < 0) return;
  layers.splice(i, 1);
  if (history.state && history.state.layer === id) { ignorePops++; history.back(); }
}
/** Close every sheet (before navigating); resolves once history has settled. */
export function closeLayers() {
  for (const l of layers.slice().reverse()) l.close(false);
  return ignorePops ? new Promise((r) => popWaiters.push(r)) : Promise.resolve();
}
export function hasLayers() { return layers.length > 0; }

/** A bottom sheet (Panel). Returns {el, body, close}. Drag the handle down, tap outside or press Back to close. */
export function sheet({ title, body, onClose, cls = "", trailing } = {}) {
  const prevFocus = document.activeElement;
  const scrim = h("div.scrim");
  const grab = h("div.grab");
  const head = title ? h("div.sheet-head", h("h2.sheet-title", title), trailing || null) : null;
  const bodyEl = h("div.sheet-body", body || null);
  const el = h("div.sheet" + (cls ? "." + cls : ""), { role: "dialog", "aria-modal": "true", "aria-label": title || "Sheet", tabindex: "-1" }, grab, head, bodyEl);
  let closed = false, id = 0;
  const finish = (fromBack) => {
    if (closed) return;
    closed = true;
    if (!fromBack) dropLayer(id);
    scrim.classList.add("out");
    el.classList.remove("dragging");
    el.style.transform = "";
    el.classList.add("out");
    setTimeout(() => { scrim.remove(); el.remove(); }, reduceMotion() ? 0 : 260);
    document.removeEventListener("keydown", onKey);
    if (prevFocus && prevFocus.focus && document.contains(prevFocus)) try { prevFocus.focus({ preventScroll: true }); } catch { /* gone */ }
    onClose && onClose();
  };
  const onKey = (e) => { if (e.key === "Escape") { e.preventDefault(); finish(false); } };
  scrim.addEventListener("click", () => finish(false));
  document.addEventListener("keydown", onKey);
  // drag to dismiss from the handle / title
  let y0 = 0, dy = 0, t0 = 0, pid = null;
  const dragZone = [grab, head].filter(Boolean);
  for (const z of dragZone) {
    z.addEventListener("pointerdown", (e) => { pid = e.pointerId; y0 = e.clientY; dy = 0; t0 = performance.now(); z.setPointerCapture(pid); el.classList.add("dragging"); });
    z.addEventListener("pointermove", (e) => { if (e.pointerId !== pid) return; dy = Math.max(0, e.clientY - y0); el.style.transform = "translateY(" + dy + "px)"; });
    const up = (e) => {
      if (e.pointerId !== pid) return;
      pid = null; el.classList.remove("dragging");
      const v = dy / Math.max(1, performance.now() - t0);
      if (dy > 110 || v > 0.6) finish(false);
      else { el.style.transition = "transform var(--d-panel) var(--spring)"; el.style.transform = ""; setTimeout(() => { el.style.transition = ""; }, 600); }
    };
    z.addEventListener("pointerup", up);
    z.addEventListener("pointercancel", up);
  }
  document.body.append(scrim, el);
  id = pushLayer(finish);
  requestAnimationFrame(() => {
    const f = el.querySelector("[autofocus]") || el;
    try { f.focus({ preventScroll: true }); } catch { /* old browser */ }
  });
  return { el, body: bodyEl, close: () => finish(false) };
}

/** Ask before doing something. Resolves true when the action button is pressed. */
export function confirm({ title, body, action = "OK", cancel = "Cancel", danger = false, icon: ic } = {}) {
  return new Promise((resolve) => {
    let answered = false;
    const ok = button({ label: action, kind: danger ? "danger" : "primary", block: true });
    const no = button({ label: cancel, kind: "ghost", block: true });
    const content = h("div",
      ic ? h("div.confirm-icon", svg(ic, 26)) : null,
      h("h2.sheet-title", title),
      body ? h("p.sheet-text", body) : null,
      h("div.actions", ok, no));
    content.firstChild && (content.style.paddingTop = "4px");
    const s = sheet({ body: content, cls: "confirm" + (danger ? " danger" : ""), onClose: () => { if (!answered) resolve(false); } });
    s.el.setAttribute("aria-label", title);
    ok.addEventListener("click", () => { answered = true; resolve(true); s.close(); });
    no.addEventListener("click", () => { answered = true; resolve(false); s.close(); });
    requestAnimationFrame(() => { try { no.focus({ preventScroll: true }); } catch { /* */ } });
  });
}

// ---- toasts ---------------------------------------------------------------------------------------------
let toastBox = null;
const TOAST_ICON = { ok: "check", error: "alert", warn: "alert", info: "info", send: "send", power: "power", lock: "lock", app: "grid" };
export function toast(text, kind = "info", { icon: ic, ms = 3200 } = {}) {
  if (!toastBox) { toastBox = h("div.toasts", { "aria-live": "polite" }); document.body.appendChild(toastBox); }
  while (toastBox.children.length >= 3) toastBox.firstChild.remove();
  const t = h("div.toast." + (kind || "info"), { role: kind === "error" ? "alert" : "status" },
    h("span.ti", svg(ic || TOAST_ICON[kind] || "info", 18)), h("span.tt", text));
  const close = () => { if (!t.isConnected) return; t.classList.add("out"); setTimeout(() => t.remove(), 230); };
  t.appendChild(iconButton({ icon: "x", label: "Dismiss", onClick: close, size: 14 }));
  toastBox.appendChild(t);
  setTimeout(close, ms);
  return close;
}
