// The remote screen and trackpad engine (PROTOCOL.md §1 "Screen WebSocket" and §3).
//   ScreenLink     /ws/screen: sign in, {t:"start"}, binary 'H' hello + 'F' frames, acks, input, reconnects.
//   FrameRenderer  decodes a frame's JPEG tiles in parallel, draws them in one animation frame, then acks.
//   Viewport       fits the PC's screen into the phone, pinch-zoom and pan by CSS transform (no redraw).
//   Gestures       touch mode (tap = click where you tap) and trackpad mode (relative pointer).

const enc = new TextDecoder();

// ---- the socket -----------------------------------------------------------------------------------------
export class ScreenLink extends EventTarget {
  /** ctx: the module ctx (openSocket). opts: {mode: "screen"|"trackpad", width(): px, output, quality} */
  constructor(ctx, opts) {
    super();
    this.ctx = ctx;
    this.opts = opts;
    this.ws = null;
    this.closed = false;
    this.state = "idle";
    this.backoff = 600;
    this.timer = 0;
    this.hello = null;
    this.locked = false;
    this.lastWidth = 0;
  }

  _status(state, extra = {}) {
    this.state = state;
    this.dispatchEvent(new CustomEvent("status", { detail: { state, ...extra } }));
  }

  async connect() {
    this.paused = false;
    if (this.closed || this.ws || this.connecting) return;
    clearTimeout(this.timer);
    this._status(this.hello ? "reconnecting" : "connecting");
    let sock;
    this.connecting = true;
    try {
      sock = await this.ctx.openSocket("/ws/screen", {
        onMessage: (ev) => this._message(ev),
        onClose: () => this._closed(sock),
      });
    } catch (e) {
      this.connecting = false;
      if (this.closed) return;
      if (e.code === "denied") { this._status("stopped", { reason: "denied" }); return; }
      this._retry();
      return;
    }
    this.connecting = false;
    if (this.closed || this.paused) { try { sock.ws.close(1000); } catch { /* */ } return; }
    this.ws = sock.ws;
    this.backoff = 600;
    this.locked = !!sock.ready.locked;
    this.dispatchEvent(new CustomEvent("locked", { detail: this.locked }));
    const width = Math.round(this.opts.width());
    this.lastWidth = width;
    const start = { t: "start", mode: this.opts.mode, width };
    if (this.opts.output) start.output = this.opts.output;
    this._send(start);
    if (this.opts.quality) this._send({ t: "quality", q: this.opts.quality });
    this._status("open");
  }

  _closed(sock) {
    if (!sock || this.ws !== sock.ws) return;
    this.ws = null;
    if (this.closed || this.paused || this.state === "stopped") return;
    this._retry();
  }

  _retry() {
    if (this.closed) return;
    this._status(this.hello ? "reconnecting" : "connecting");
    clearTimeout(this.timer);
    this.timer = setTimeout(() => this.connect(), this.backoff);
    this.backoff = Math.min(5000, Math.round(this.backoff * 1.6));
  }

  _message(ev) {
    if (typeof ev.data === "string") {
      let m;
      try { m = JSON.parse(ev.data); } catch { return; }
      if (m.t === "stopped") {
        this._status("stopped", { reason: m.reason || "ended", message: m.message });
        const ws = this.ws;
        this.ws = null;
        try { ws && ws.close(1000); } catch { /* */ }
      } else if (m.t === "engine") {
        if (m.error) this.dispatchEvent(new CustomEvent("engine-error", { detail: m }));
        else this.dispatchEvent(new CustomEvent("engine-info", { detail: m }));
      } else if (m.t === "locked") {
        this.locked = !!m.locked;
        this.dispatchEvent(new CustomEvent("locked", { detail: this.locked }));
      }
      return;
    }
    let buf = ev.data;
    if (!(buf instanceof ArrayBuffer) || buf.byteLength < 2) return;
    let u8 = new Uint8Array(buf);
    // tolerate the engine's u32 length prefix, should a relay ever pass it through
    if (u8[0] !== 0x48 && u8[0] !== 0x46 && buf.byteLength > 5 && new DataView(buf).getUint32(0) === buf.byteLength - 4) {
      buf = buf.slice(4); u8 = new Uint8Array(buf);
    }
    if (u8[0] === 0x48) {            // 'H'
      try {
        this.hello = JSON.parse(enc.decode(u8.subarray(1)));
        this.dispatchEvent(new CustomEvent("hello", { detail: this.hello }));
      } catch { /* malformed */ }
    } else if (u8[0] === 0x46) {     // 'F'
      const f = parseFrame(buf);
      if (f) this.dispatchEvent(new CustomEvent("frame", { detail: f }));
    } else if (u8[0] === 0x45) {     // 'E' (deckd sends these as text; accept binary too)
      try {
        const m = JSON.parse(enc.decode(u8.subarray(1)));
        this.dispatchEvent(new CustomEvent(m.error ? "engine-error" : "engine-info", { detail: m }));
      } catch { /* */ }
    }
  }

  _send(obj) {
    if (!this.ws || this.ws.readyState !== 1) return false;
    try { this.ws.send(JSON.stringify(obj)); return true; } catch { return false; }
  }
  get open() { return !!this.ws && this.ws.readyState === 1; }
  ack(seq) { this._send({ t: "ack", seq }); }
  /** One engine input command (move, rel, btn, scroll, key, tap, text, release). */
  input(cmd) { return this._send({ t: "in", cmd }); }
  view(width) {
    width = Math.round(width);
    if (!width || Math.abs(width - this.lastWidth) / Math.max(1, this.lastWidth) < 0.08) return;
    this.lastWidth = width;
    this._send({ t: "view", width });
  }
  output(name) { this.opts.output = name; this._send({ t: "output", name }); }
  quality(q) { this.opts.quality = q; this._send({ t: "quality", q }); }
  refresh() { this._send({ t: "refresh" }); }
  /** Start again after "stopped" (the Start again / Try again buttons). */
  restart() { this.closed = false; this.backoff = 600; this.hello = null; this._status("connecting"); this.connect(); }
  close() {
    this.closed = true;
    clearTimeout(this.timer);
    const ws = this.ws;
    this.ws = null;
    if (ws) {
      try { if (ws.readyState === 1) ws.send(JSON.stringify({ t: "in", cmd: { t: "release" } })); } catch { /* */ }
      try { ws.close(1000); } catch { /* */ }
    }
  }
  /** Close for now (page hidden); connect() picks up again. */
  pause() {
    this.paused = true;
    clearTimeout(this.timer);
    const ws = this.ws;
    this.ws = null;
    if (ws) { try { ws.send(JSON.stringify({ t: "in", cmd: { t: "release" } })); ws.close(1000); } catch { /* */ } }
    this._status("paused");
  }
}

/** 'F' + u32 seq, u16 w, u16 h, u16 count, then count × (u16 x, u16 y, u16 tw, u16 th, u32 len, JPEG). Big-endian. */
export function parseFrame(buf) {
  if (buf.byteLength < 11) return null;
  const dv = new DataView(buf);
  let o = 1;
  const seq = dv.getUint32(o); o += 4;
  const w = dv.getUint16(o); o += 2;
  const h = dv.getUint16(o); o += 2;
  const n = dv.getUint16(o); o += 2;
  const tiles = [];
  for (let i = 0; i < n; i++) {
    if (o + 12 > buf.byteLength) return null;
    const x = dv.getUint16(o), y = dv.getUint16(o + 2), tw = dv.getUint16(o + 4), th = dv.getUint16(o + 6), len = dv.getUint32(o + 8);
    o += 12;
    if (o + len > buf.byteLength) return null;
    tiles.push({ x, y, tw, th, bytes: new Uint8Array(buf, o, len) });
    o += len;
  }
  return { seq, w, h, tiles };
}

// ---- drawing ----------------------------------------------------------------------------------------------
const canBitmap = typeof createImageBitmap === "function";
function decodeTile(bytes) {
  const blob = new Blob([bytes], { type: "image/jpeg" });
  if (canBitmap) return createImageBitmap(blob);
  return new Promise((resolve, reject) => {             // old Safari: an <img> per tile
    const url = URL.createObjectURL(blob);
    const img = new Image();
    img.onload = () => { URL.revokeObjectURL(url); resolve(img); };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error("decode")); };
    img.src = url;
  });
}
const nextFrame = () => new Promise((r) => requestAnimationFrame(r));

export class FrameRenderer {
  constructor(canvas, { onDrawn, onSize } = {}) {
    this.canvas = canvas;
    this.g = canvas.getContext("2d", { alpha: false });
    this.chain = Promise.resolve();
    this.onDrawn = onDrawn || (() => {});
    this.onSize = onSize || (() => {});
    this.frames = 0;
    this.stopped = false;
  }
  /** Resize the backing store to a frame's size, keeping the old picture (scaled) until new tiles land. */
  size(w, h) {
    const c = this.canvas;
    if (!w || !h || (c.width === w && c.height === h)) return;
    let keep = null;
    if (this.frames && c.width && c.height) {
      keep = document.createElement("canvas");
      keep.width = c.width; keep.height = c.height;
      keep.getContext("2d").drawImage(c, 0, 0);
    }
    c.width = w; c.height = h;
    this.g = c.getContext("2d", { alpha: false });
    if (keep) { this.g.imageSmoothingQuality = "high"; this.g.drawImage(keep, 0, 0, w, h); }
    this.onSize(w, h);
  }
  push(f) {
    // decode now, in parallel with the previous frame's drawing; draw strictly in order
    const decoded = Promise.all(f.tiles.map((t) => decodeTile(t.bytes).catch(() => null)));
    this.chain = this.chain.then(async () => {
      const bmps = await decoded;
      if (this.stopped) { bmps.forEach((b) => b && b.close && b.close()); return; }
      await nextFrame();
      this.size(f.w, f.h);
      let bad = 0;
      for (let i = 0; i < bmps.length; i++) {
        const b = bmps[i], t = f.tiles[i];
        if (!b) { bad++; continue; }
        this.g.drawImage(b, t.x, t.y, t.tw, t.th);
        if (b.close) b.close();
      }
      this.frames++;
      this.onDrawn(f.seq, bad);
    }).catch((e) => console.error(e));
  }
  stop() { this.stopped = true; }
}

// ---- the view ------------------------------------------------------------------------------------------------
export class Viewport {
  constructor(stage, layer) {
    this.stage = stage;
    this.layer = layer;
    this.srcW = 16; this.srcH = 9;
    this.W = 0; this.H = 0; this.fw = 0; this.fh = 0;
    this.z = 1; this.x = 0; this.y = 0;
    this.onChange = () => {};
  }
  get zoomed() { return this.z > 1.02; }
  get maxZ() { return Math.max(2, Math.min(8, (this.srcW / Math.max(1, this.fw)) * 2)); }
  setSource(w, h) {
    if (!w || !h) return;
    if (w === this.srcW && h === this.srcH) return;
    this.srcW = w; this.srcH = h;
    this.layout(true);
  }
  layout(reset) {
    const r = this.stage.getBoundingClientRect();
    const W = r.width, H = r.height;
    if (!W || !H) return;
    // keep the point at the view's center where it is when the size changes
    const cx = this.fw ? (W / 2 - this.x) / (this.fw * this.z) : 0.5, cy = this.fh ? (H / 2 - this.y) / (this.fh * this.z) : 0.5;
    this.W = W; this.H = H;
    const s = Math.min(W / this.srcW, H / this.srcH);
    this.fw = Math.round(this.srcW * s); this.fh = Math.round(this.srcH * s);
    this.layer.style.width = this.fw + "px";
    this.layer.style.height = this.fh + "px";
    if (reset || !this.zoomed) { this.z = 1; this.x = (W - this.fw) / 2; this.y = (H - this.fh) / 2; }
    else { this.x = W / 2 - cx * this.fw * this.z; this.y = H / 2 - cy * this.fh * this.z; }
    this.clamp(); this.apply();
  }
  clamp() {
    const sw = this.fw * this.z, sh = this.fh * this.z;
    this.x = sw <= this.W ? (this.W - sw) / 2 : Math.min(0, Math.max(this.W - sw, this.x));
    this.y = sh <= this.H ? (this.H - sh) / 2 : Math.min(0, Math.max(this.H - sh, this.y));
  }
  apply() {
    this.layer.style.transform = "translate3d(" + this.x.toFixed(2) + "px," + this.y.toFixed(2) + "px,0) scale(" + this.z.toFixed(4) + ")";
    this.onChange();
  }
  /** Zoom so the stage point (sx, sy) of the start (x0, y0, z0) follows the fingers' midpoint (mx, my). */
  pinch(z0, x0, y0, sx, sy, k, mx, my) {
    const z = Math.max(1, Math.min(this.maxZ, z0 * k));
    // the content point under (sx, sy) at the start
    const px = (sx - x0) / z0, py = (sy - y0) / z0;
    this.z = z;
    this.x = mx - px * z; this.y = my - py * z;
    this.clamp(); this.apply();
  }
  panBy(dx, dy) { this.x += dx; this.y += dy; this.clamp(); this.apply(); }
  fit(animate = true) {
    if (animate) {
      this.layer.style.transition = "transform 420ms var(--soft)";
      setTimeout(() => { this.layer.style.transition = ""; }, 450);
    }
    this.z = 1; this.clamp(); this.apply();
  }
  /** Client point -> {x, y} on the PC's display, 0..1, and whether it was on it. */
  toNorm(cx, cy) {
    const r = this.stage.getBoundingClientRect();
    const x = (cx - r.left - this.x) / (this.fw * this.z), y = (cy - r.top - this.y) / (this.fh * this.z);
    return { x: Math.max(0, Math.min(1, x)), y: Math.max(0, Math.min(1, y)), inside: x >= 0 && x <= 1 && y >= 0 && y <= 1 };
  }
  /** The width the PC's screen is shown at, in CSS px (what the frame width should match). */
  get shownWidth() { return this.fw * this.z; }
}

// ---- gestures ----------------------------------------------------------------------------------------------------
const HOLD_MS = 240, LONG_MS = 650, TOL = 9, TAP_MS = 280, DTAP_MS = 400, DTAP_PX = 30, SCROLL_PX = 34;

/**
 * Turns touches on `target` into engine input.
 *   o.mode()        "touch" | "trackpad"
 *   o.send(cmd)     engine command; returns false when control is off
 *   o.viewport      a Viewport (screen page) or null (trackpad page)
 *   o.fx            element for the press ring and tap dots (positioned like `target`)
 *   o.speed()       trackpad speed factor (default 1)
 *   o.onActivity()  any touch (hides hints)
 *   o.onView()      the zoom changed (ask for a new frame width)
 */
export class Gestures {
  constructor(target, o) {
    this.t = target;
    this.o = o;
    this.P = new Map();
    this.g = null;
    this.lastTap = null;
    this.pending = { move: null, rx: 0, ry: 0, sx: 0, sy: 0, rremX: 0, rremY: 0 };
    this.raf = 0;
    this.ring = this._ring();
    this._down = (e) => this.down(e);
    this._move = (e) => this.move(e);
    this._up = (e) => this.up(e, false);
    this._cancel = (e) => this.up(e, true);
    this._wheel = (e) => this.wheel(e);
    this._ctx = (e) => e.preventDefault();
    target.addEventListener("pointerdown", this._down);
    target.addEventListener("pointermove", this._move);
    target.addEventListener("pointerup", this._up);
    target.addEventListener("pointercancel", this._cancel);
    target.addEventListener("wheel", this._wheel, { passive: false });
    target.addEventListener("contextmenu", this._ctx);
  }
  destroy() {
    const t = this.t;
    t.removeEventListener("pointerdown", this._down);
    t.removeEventListener("pointermove", this._move);
    t.removeEventListener("pointerup", this._up);
    t.removeEventListener("pointercancel", this._cancel);
    t.removeEventListener("wheel", this._wheel);
    t.removeEventListener("contextmenu", this._ctx);
    cancelAnimationFrame(this.raf);
    this._timers();
    this.ring.remove();
  }

  // ---- feedback ----
  _ring() {
    const NS = "http://www.w3.org/2000/svg";
    const el = document.createElement("div");
    el.className = "press-ring";
    const s = document.createElementNS(NS, "svg");
    s.setAttribute("viewBox", "0 0 64 64");
    const bg = document.createElementNS(NS, "circle");
    bg.setAttribute("cx", "32"); bg.setAttribute("cy", "32"); bg.setAttribute("r", "28"); bg.setAttribute("class", "bg");
    const arc = document.createElementNS(NS, "circle");
    arc.setAttribute("cx", "32"); arc.setAttribute("cy", "32"); arc.setAttribute("r", "28"); arc.setAttribute("class", "arc");
    s.append(bg, arc);
    el.appendChild(s);
    this.o.fx.appendChild(el);
    return el;
  }
  _fxPoint(cx, cy) { const r = this.o.fx.getBoundingClientRect(); return [cx - r.left, cy - r.top]; }
  _ringShow(cx, cy) {
    const [x, y] = this._fxPoint(cx, cy);
    const r = this.ring;
    r.className = "press-ring";
    r.style.left = x + "px"; r.style.top = y + "px";
    void r.offsetWidth;
    r.classList.add("show", "fill");
  }
  _ringMove(cx, cy) { const [x, y] = this._fxPoint(cx, cy); this.ring.style.left = x + "px"; this.ring.style.top = y + "px"; }
  _ringHide() { this.ring.className = "press-ring"; }
  _dot(cx, cy, right) {
    const [x, y] = this._fxPoint(cx, cy);
    const d = document.createElement("div");
    d.className = "tap-dot" + (right ? " right" : "");
    d.style.left = x + "px"; d.style.top = y + "px";
    this.o.fx.appendChild(d);
    setTimeout(() => d.remove(), 420);
  }

  // ---- output (coalesced to one message per animation frame) ----
  _flushSoon() { if (!this.raf) this.raf = requestAnimationFrame(() => this._flush()); }
  _flush() {
    this.raf = 0;
    const p = this.pending;
    if (p.move) { this.o.send({ t: "move", x: +p.move.x.toFixed(5), y: +p.move.y.toFixed(5) }); p.move = null; }
    const rx = Math.trunc(p.rx), ry = Math.trunc(p.ry);
    if (rx || ry) { this.o.send({ t: "rel", dx: rx, dy: ry }); p.rx -= rx; p.ry -= ry; }
    const sx = Math.round(p.sx * 100) / 100, sy = Math.round(p.sy * 100) / 100;
    if (sx || sy) { this.o.send({ t: "scroll", dx: sx, dy: sy }); p.sx -= sx; p.sy -= sy; }
  }
  _now(cmd) { this._flush(); this.o.send(cmd); }
  _absMove(cx, cy) {
    const n = this.o.viewport.toNorm(cx, cy);
    this.pending.move = n;
    this._flushSoon();
    return n;
  }
  _rel(dx, dy, dt) {
    const v = Math.hypot(dx, dy) / Math.max(1, dt);           // px per ms
    const gain = (this.o.speed ? this.o.speed() : 1) * (1.1 + Math.min(v, 2.5) * 1.5);
    const z = this.o.viewport ? this.o.viewport.z : 1;
    this.pending.rx += (dx * gain) / z;
    this.pending.ry += (dy * gain) / z;
    this._flushSoon();
  }
  _scroll(dx, dy) {
    // natural scrolling: content follows the fingers
    const k = this.o.viewport ? Math.max(1, this.o.viewport.z) : 1;
    this.pending.sx += -dx / (SCROLL_PX * k);
    this.pending.sy += -dy / (SCROLL_PX * k);
    this._flushSoon();
  }
  click(cx, cy, button = "left") {
    const touch = this.o.mode() === "touch" && this.o.viewport;
    if (touch) {
      let n = this.o.viewport.toNorm(cx, cy);
      const now = performance.now();
      // a second tap close to the first lands on the same spot, so the PC sees a double-click
      if (button === "left" && this.lastTap && now - this.lastTap.t < DTAP_MS && Math.hypot(cx - this.lastTap.cx, cy - this.lastTap.cy) < DTAP_PX) n = this.lastTap.n;
      if (button === "left") this.lastTap = { t: now, cx, cy, n };
      this.pending.move = null;
      this._now({ t: "move", x: +n.x.toFixed(5), y: +n.y.toFixed(5) });
    }
    this._now({ t: "btn", b: button, down: true });
    this._now({ t: "btn", b: button, down: false });
    this._dot(cx, cy, button === "right");
  }

  _timers() { clearTimeout(this.holdT); clearTimeout(this.longT); }

  // ---- pointer events ----
  down(e) {
    if (e.pointerType === "mouse") { this._mouseDown(e); return; }
    e.preventDefault();
    try { this.t.setPointerCapture(e.pointerId); } catch { /* */ }
    this.o.onActivity && this.o.onActivity();
    const now = performance.now();
    this.P.set(e.pointerId, { x: e.clientX, y: e.clientY, t: now });
    if (this.P.size === 1) {
      this.g = { n: 1, kind: "pending", t0: now, x0: e.clientX, y0: e.clientY, lx: e.clientX, ly: e.clientY, lt: now, armed: false };
      const g = this.g;
      this.holdT = setTimeout(() => { if (this.g === g && g.kind === "pending") { g.armed = true; this._ringShow(g.x0, g.y0); } }, HOLD_MS);
      this.longT = setTimeout(() => {
        if (this.g === g && g.kind === "pending") {
          g.kind = "done";
          this.ring.classList.add("done");
          setTimeout(() => this._ringHide(), 300);
          navigator.vibrate && navigator.vibrate(10);
          this.click(g.x0, g.y0, "right");
        }
      }, LONG_MS);
    } else if (this.P.size === 2) {
      this._timers(); this._ringHide();
      if (this.g && this.g.kind === "drag") this._now({ t: "btn", b: "left", down: false });
      const [a, b] = [...this.P.values()];
      const vp = this.o.viewport;
      const r = this.t.getBoundingClientRect();
      const mx = (a.x + b.x) / 2 - r.left, my = (a.y + b.y) / 2 - r.top;
      this.g = { n: 2, kind: "two", mode: null, t0: now, d0: Math.hypot(a.x - b.x, a.y - b.y), mx0: mx, my0: my, lmx: mx, lmy: my,
        z0: vp ? vp.z : 1, x0: vp ? vp.x : 0, y0: vp ? vp.y : 0, cx: (a.x + b.x) / 2, cy: (a.y + b.y) / 2, max: 2 };
    } else if (this.g) {
      this.g.max = Math.max(this.g.max || 0, this.P.size);
      if (this.P.size === 3 && this.g.kind === "two" && !this.g.mode) this.g.kind = "three";
    }
  }

  move(e) {
    if (e.pointerType === "mouse") { this._mouseMove(e); return; }
    const p = this.P.get(e.pointerId);
    if (!p || !this.g) return;
    const now = performance.now();
    p.x = e.clientX; p.y = e.clientY;
    const g = this.g;
    const touch = this.o.mode() === "touch" && this.o.viewport;
    if (g.n === 1 && this.P.size === 1) {
      if (g.kind === "pending") {
        if (Math.hypot(e.clientX - g.x0, e.clientY - g.y0) < TOL) return;
        this._timers();
        if (g.armed) {
          g.kind = "drag";
          this.ring.classList.add("grab");
          navigator.vibrate && navigator.vibrate(6);
          if (touch) { const n = this.o.viewport.toNorm(g.x0, g.y0); this._now({ t: "move", x: n.x, y: n.y }); }
          this._now({ t: "btn", b: "left", down: true });
        } else {
          this._ringHide();
          g.kind = touch ? (this.o.viewport.zoomed ? "pan" : "scroll") : "rel";
        }
      }
      const dx = e.clientX - g.lx, dy = e.clientY - g.ly, dt = now - g.lt;
      g.lx = e.clientX; g.ly = e.clientY; g.lt = now;
      if (g.kind === "drag") {
        this._ringMove(e.clientX, e.clientY);
        if (touch) this._absMove(e.clientX, e.clientY); else this._rel(dx, dy, dt);
      } else if (g.kind === "pan") this.o.viewport.panBy(dx, dy);
      else if (g.kind === "scroll") this._scroll(dx, dy);
      else if (g.kind === "rel") this._rel(dx, dy, dt);
      return;
    }
    if (g.kind === "two" && this.P.size === 2) {
      const [a, b] = [...this.P.values()];
      const r = this.t.getBoundingClientRect();
      const mx = (a.x + b.x) / 2 - r.left, my = (a.y + b.y) / 2 - r.top;
      const d = Math.hypot(a.x - b.x, a.y - b.y);
      const vp = this.o.viewport;
      if (!g.mode) {
        if (vp && Math.abs(d - g.d0) > 30) g.mode = "pinch";
        else if (Math.hypot(mx - g.mx0, my - g.my0) > 10) g.mode = "scroll";
        else return;
      }
      if (g.mode === "pinch") vp.pinch(g.z0, g.x0, g.y0, g.mx0, g.my0, d / g.d0, mx, my);
      else this._scroll(mx - g.lmx, my - g.lmy);
      g.lmx = mx; g.lmy = my;
    }
  }

  up(e, cancel) {
    if (e.pointerType === "mouse") { this._mouseUp(e); return; }
    if (!this.P.has(e.pointerId)) return;
    this.P.delete(e.pointerId);
    const g = this.g;
    if (!g) return;
    const now = performance.now();
    if (g.n === 1) {
      this._timers();
      if (g.kind === "pending" && !cancel) {
        this._ringHide();
        this.click(g.x0, g.y0, "left");
      } else if (g.kind === "drag") {
        this._flush();
        this._now({ t: "btn", b: "left", down: false });
        this._ringHide();
      } else this._ringHide();
      this.g = null;
      return;
    }
    if (this.P.size === 0) {
      if (!cancel && now - g.t0 < TAP_MS + 120) {
        if (g.kind === "three") this.click(g.cx, g.cy, "middle");
        else if (g.kind === "two" && !g.mode) this.click(g.cx, g.cy, "right");
      }
      if (g.mode === "pinch") {
        if (this.o.viewport.z < 1.08) this.o.viewport.fit(true);
        this.o.onView && this.o.onView();
      }
      this.g = null;
    }
  }

  // ---- a mouse (testing on a laptop; tablets with a mouse) ----
  _mouseDown(e) {
    try { this.t.setPointerCapture(e.pointerId); } catch { /* */ }
    const b = e.button === 2 ? "right" : e.button === 1 ? "middle" : "left";
    if (this.o.viewport && this.o.mode() === "touch") this._absMove(e.clientX, e.clientY);
    this._now({ t: "btn", b, down: true });
    this.mouseLast = { x: e.clientX, y: e.clientY, t: performance.now() };
  }
  _mouseMove(e) {
    if (this.o.viewport && this.o.mode() === "touch") this._absMove(e.clientX, e.clientY);
    else if (this.mouseLast || e.buttons === 0) {
      const l = this.mouseLast || { x: e.clientX, y: e.clientY, t: performance.now() };
      this._rel(e.clientX - l.x, e.clientY - l.y, performance.now() - l.t);
      this.mouseLast = { x: e.clientX, y: e.clientY, t: performance.now() };
    }
  }
  _mouseUp(e) {
    const b = e.button === 2 ? "right" : e.button === 1 ? "middle" : "left";
    this._flush();
    this._now({ t: "btn", b, down: false });
  }
  wheel(e) {
    e.preventDefault();
    const vp = this.o.viewport;
    if (e.ctrlKey && vp) {               // pinch on a laptop trackpad / Ctrl+wheel: zoom the view
      const r = this.t.getBoundingClientRect();
      const sx = e.clientX - r.left, sy = e.clientY - r.top;
      vp.pinch(vp.z, vp.x, vp.y, sx, sy, Math.exp(-e.deltaY / 200), sx, sy);
      this.o.onView && this.o.onView();
      return;
    }
    const k = e.deltaMode === 1 ? 1 / 3 : e.deltaMode === 2 ? 3 : 1 / 100;
    this.pending.sx += e.deltaX * k;
    this.pending.sy += e.deltaY * k;
    this._flushSoon();
  }
}
