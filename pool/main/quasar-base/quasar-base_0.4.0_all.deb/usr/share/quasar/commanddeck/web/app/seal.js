// Command Deck's own encryption, the phone's half (PROTOCOL.md §1 "Crypto"). The page is plain HTTP, so
// everything after sign-in is sealed here with NaCl: tweetnacl (app/vendor/nacl-fast.min.js, a classic
// script that sets self.nacl) on the phone, libsodium on the PC. The PC's half is
// linux/system/commanddeck/quasar_deck/seal.py; tools/test-deck-seal.mjs checks this file against its
// test vectors (tests/commanddeck/vectors.json), byte for byte.
//   H32(key, msg) = HMAC-SHA-512(key, msg), first 32 bytes; strings are UTF-8; base64 is URL-safe, unpadded.
//   A sealed message = secretbox(plain, nonce(dir, n), sk): byte 0 of the nonce is the direction (1 = PC to
//   phone, 2 = phone to PC), bytes 16..23 the message counter (big-endian), from 0 per direction per socket.
export const FROM_PC = 1, FROM_PHONE = 2;

const te = new TextEncoder();
const td = new TextDecoder();
const nacl = () => self.nacl;

/** Uint8Array view of a string (UTF-8), ArrayBuffer or typed array. */
export function bytes(x) {
  if (typeof x === "string") return te.encode(x);
  if (x instanceof Uint8Array) return x;
  if (x instanceof ArrayBuffer) return new Uint8Array(x);
  if (ArrayBuffer.isView(x)) return new Uint8Array(x.buffer, x.byteOffset, x.byteLength);
  throw new TypeError("not bytes");
}

export function b64u(x) {
  const b = bytes(x);
  let s = "";
  for (let i = 0; i < b.length; i += 0x8000) s += String.fromCharCode.apply(null, b.subarray(i, i + 0x8000));
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

/** Strict URL-safe base64 (no padding); null when it isn't, or isn't `size` bytes. */
export function unb64u(s, size) {
  if (typeof s !== "string" || !s || s.length > 4096 || !/^[A-Za-z0-9_-]+$/.test(s) || s.length % 4 === 1) return null;
  let bin;
  try { bin = atob(s.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((s.length + 3) % 4)); } catch { return null; }
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  if (size !== undefined && out.length !== size) return null;
  return out;
}

// ---- HMAC-SHA-512 on nacl.hash (SHA-512, block size 128) -------------------------------------------------
export function hmac512(key, msg) {
  const hash = nacl().hash;
  let k = bytes(key);
  if (k.length > 128) k = hash(k);
  const m = bytes(msg);
  const inner = new Uint8Array(128 + m.length);
  const outer = new Uint8Array(128 + 64);
  for (let i = 0; i < 128; i++) {
    const c = i < k.length ? k[i] : 0;
    inner[i] = c ^ 0x36;
    outer[i] = c ^ 0x5c;
  }
  inner.set(m, 128);
  outer.set(hash(inner), 128);
  return hash(outer);
}
export const h32 = (key, msg) => hmac512(key, msg).slice(0, 32);

// ---- pairing and sign-in (seal.py: pair_mac, paired_mac, session_key, proof) --------------------------------
export const pairMac = (secretText, pcId, pub, name, model) =>
  b64u(h32(secretText, "pair\n" + pcId + "\n" + pub + "\n" + name + "\n" + model));
export const pairedMac = (secretText, pcId, pub, deviceId, pcPub) =>
  b64u(h32(secretText, "paired\n" + pcId + "\n" + pub + "\n" + deviceId + "\n" + pcPub));
export const sessionKey = (k, nonce, cnonce, origin) => h32(k, "session\n" + nonce + "\n" + cnonce + "\n" + origin);
export const proof = (sk) => b64u(h32(sk, "phone"));

/** Two base64url MACs, compared in constant time (false for anything that isn't 32 bytes). */
export function sameMac(a, b) {
  const x = unb64u(a, 32), y = unb64u(b, 32);
  return !!(x && y && nacl().verify(x, y));
}

/** crypto_box_beforenm(theirPub, mySecret); null for a key that can't be used (like libsodium, which
 *  refuses a low-order point: an all-zero X25519 result). */
export function shared(mySecret, theirPub) {
  try {
    const sec = bytes(mySecret), pub = bytes(theirPub);
    if (sec.length !== 32 || pub.length !== 32) return null;
    let any = 0;
    for (const c of nacl().scalarMult(sec, pub)) any |= c;
    return any ? nacl().box.before(pub, sec) : null;
  } catch { return null; }
}

export function nonce(dir, n) {
  const out = new Uint8Array(24);
  out[0] = dir;
  const v = new DataView(out.buffer);
  v.setUint32(16, Math.floor(n / 0x100000000));
  v.setUint32(20, n >>> 0);
  return out;
}

/** One socket's key and counters; `me` is the side this end speaks for. */
export class Channel {
  constructor(key, me = FROM_PHONE) {
    this.key = bytes(key);
    this.outDir = me;
    this.inDir = me === FROM_PHONE ? FROM_PC : FROM_PHONE;
    this.sent = 0;
    this.got = 0;
  }
  seal(plain) {
    const box = nacl().secretbox(bytes(plain), nonce(this.outDir, this.sent), this.key);
    this.sent++;
    return box;
  }
  /** The plaintext, or null (wrong key, tampered, replayed, dropped or out of order). */
  open(box) {
    const b = bytes(box);
    if (b.length < 16) return null;
    const plain = nacl().secretbox.open(b, nonce(this.inDir, this.got), this.key);
    if (!plain) return null;
    this.got++;
    return plain;
  }
}

/** Plaintext → what a WebSocket message event would carry: a string for JSON ("{…"), else an ArrayBuffer. */
export function asData(plain) {
  if (plain.length && plain[0] === 0x7b) return td.decode(plain);
  return plain.buffer.slice(plain.byteOffset, plain.byteOffset + plain.byteLength);
}

/** A signed-in WebSocket that the rest of the app uses like a WebSocket: send(string | bytes),
 *  close(), readyState, bufferedAmount, onmessage({data}), onclose(event). Every frame on the wire is a
 *  binary secretbox. A message that doesn't open ends the socket. (Browsers may only close with 1000 or
 *  3000–4999, so the phone's "1008" is 4008.) */
export class SealedSocket {
  constructor(ws, key) {
    this.ws = ws;
    this.ch = new Channel(key, FROM_PHONE);
    this.onmessage = null;
    this.onclose = null;
    this.broken = false;
    ws.binaryType = "arraybuffer";
  }
  /** Start delivering: from here on the raw socket's messages and close go through this object. */
  attach() {
    this.ws.onmessage = (ev) => this.receive(ev.data);
    this.ws.onclose = (e) => { if (this.onclose) this.onclose(e); };
    this.ws.onerror = () => { /* onclose follows */ };
  }
  get readyState() { return this.ws.readyState; }
  get bufferedAmount() { return this.ws.bufferedAmount; }
  send(data) {
    if (this.ws.readyState !== 1 || this.broken) return;        // like a WebSocket that's closing: dropped
    this.ws.send(this.ch.seal(typeof data === "string" ? te.encode(data) : bytes(data)));
  }
  close(code = 1000, reason) {
    try { if (reason === undefined) this.ws.close(code); else this.ws.close(code, reason); } catch { try { this.ws.close(); } catch { /* */ } }
  }
  /** Opens one wire message; returns its data (string | ArrayBuffer) or null after breaking the socket. */
  openData(data) {
    if (this.broken) return null;
    const plain = typeof data === "string" ? null : this.ch.open(data);   // nothing travels unsealed now
    if (!plain) { this.broken = true; this.close(4008, "unsealed"); return null; }
    return asData(plain);
  }
  receive(data) {
    const d = this.openData(data);
    if (d !== null && this.onmessage) this.onmessage({ data: d });
  }
}
