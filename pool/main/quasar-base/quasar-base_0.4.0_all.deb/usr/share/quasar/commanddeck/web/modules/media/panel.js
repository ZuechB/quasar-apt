// Media: what's playing on the PC (art, title, play/pause, next, previous) and its volume.
import { artSrc } from "../home/panel.js";

function seconds(v) {
  const n = Number(v) || 0;
  return n > 1e5 ? n / 1e6 : n;          // MPRIS microseconds, if a shell ever sends them raw
}

/** The volume row: a fill slider and a mute button. Shared by the page and the Home tile. */
function volumeRow(ctx) {
  const { h, fillSlider, iconButton, throttle } = ctx.ui;
  let muted = false;
  const send = throttle((v) => ctx.run("volume", { value: v }, { quiet: true }), 120);
  const slider = fillSlider({ label: "Volume", icon: "vol", onInput: (v) => { send(v); slider.setIcon(v === 0 ? "mute" : v < 50 ? "volLow" : "vol"); },
    onChange: (v) => ctx.run("volume", { value: v }) });
  const mute = iconButton({ icon: "mute", label: "Mute", onClick: () => {
    muted = !muted; paint(); ctx.run("mute", { on: muted });
  } });
  const paint = () => {
    mute.classList.toggle("on", muted);
    mute.setAttribute("aria-pressed", String(muted));
    mute.setAttribute("aria-label", muted ? "Unmute" : "Mute");
    slider.setMuted(muted);
  };
  const el = h("div.vol-row", slider, mute);
  el.update = (sys) => {
    if (!sys) return;
    muted = !!sys.muted;
    const v = Number(sys.volume) || 0;
    slider.set(v);
    slider.setIcon(muted || v === 0 ? "mute" : v < 50 ? "volLow" : "vol");
    paint();
  };
  return el;
}

export function mount(el, ctx) {
  const { h, clear, svg, iconButton, sectionLabel, empty, formatTime } = ctx.ui;
  el.appendChild(h("header.page-head", h("div.grow", h("h1.page-title", "Media"), h("p.page-sub", "On " + ctx.pc.name))));
  const top = h("div");
  const vol = volumeRow(ctx);
  el.append(top, sectionLabel("Volume"), vol);

  let player = null, lastArt = null, posAt = 0, timer = 0;
  const art = h("div.media-art", svg("music", 56, 1.4));
  const title = h("h2.media-title"), artist = h("p.media-artist"), from = h("p.media-player");
  const bar = ctx.ui.progress(0);
  const tNow = h("span"), tLen = h("span");
  const timeBox = h("div", bar, h("div.media-time", tNow, tLen));
  const prev = iconButton({ icon: "prev", label: "Previous", size: 24, onClick: () => ctx.run("media", { action: "previous" }) });
  const play = h("button.icon-btn.big", { type: "button", "aria-label": "Play" }, svg("play", 30, 2.2));
  play.addEventListener("click", () => {
    if (player) { player.playing = !player.playing; paintPlay(); }     // feels instant; the topic confirms
    ctx.run("media", { action: "playPause" });
  });
  const next = iconButton({ icon: "next", label: "Next", size: 24, onClick: () => ctx.run("media", { action: "next" }) });
  const playerBox = h("div", art, title, artist, from, h("div", { style: { margin: "18px 4px 0" } }, timeBox), h("div.transport", prev, play, next));

  function paintPlay() {
    clear(play).appendChild(svg(player && player.playing ? "pause" : "play", 30, 2.2));
    play.setAttribute("aria-label", player && player.playing ? "Pause" : "Play");
  }
  function tick() {
    if (!player) return;
    const len = seconds(player.length);
    let pos = seconds(player.position);
    if (player.playing) pos += (performance.now() - posAt) / 1000;
    if (len > 0) pos = Math.min(pos, len);
    timeBox.hidden = !(len > 0);
    bar.set(len > 0 ? pos / len : 0);
    tNow.textContent = formatTime(pos);
    tLen.textContent = formatTime(len);
  }

  ctx.subscribe("media", (m) => {
    player = m && m.player ? { ...m.player } : null;
    posAt = performance.now();
    clearInterval(timer);
    clear(top);
    if (!player) {
      top.appendChild(empty({ icon: "music", title: "Nothing is playing", body: "Play music or a video on " + ctx.pc.name + " and it shows up here." }));
      return;
    }
    top.appendChild(playerBox);
    title.textContent = player.title || player.name || "Playing";
    artist.textContent = [player.artist, player.album].filter(Boolean).join(" · ");
    from.textContent = player.name ? "in " + player.name : "";
    const want = player.art || "";
    if (want !== lastArt) {
      lastArt = want;
      clear(art).appendChild(svg("music", 56, 1.4));
      artSrc(want, ctx).then((src) => {
        if (!src || lastArt !== want) return;              // the track changed meanwhile
        const img = h("img", { alt: "", decoding: "async" });
        img.addEventListener("load", () => { if (lastArt === want) clear(art).appendChild(img); }, { once: true });
        img.src = src;
      });
    }
    prev.disabled = player.canPrev === false;
    next.disabled = player.canNext === false;
    play.disabled = player.canPlay === false;
    paintPlay();
    tick();
    timer = setInterval(tick, 1000);
  });
  ctx.subscribe("system", (s) => vol.update(s));
  return () => clearInterval(timer);
}

/** Home tile: the volume, two tiles wide (module.json tileSpan: 2). */
export function tile(el, ctx) {
  const vol = volumeRow(ctx);
  el.appendChild(vol);
  ctx.subscribe("system", (s) => vol.update(s));
}
