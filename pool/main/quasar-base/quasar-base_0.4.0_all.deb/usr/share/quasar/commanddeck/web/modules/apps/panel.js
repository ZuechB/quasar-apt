// Apps: every app on the PC, searchable; a tap opens it on the PC.
export function mount(el, ctx) {
  const { h, clear, svg, appIcon, iconButton, empty, banner, toast } = ctx.ui;

  const input = h("input", { type: "search", placeholder: "Search apps", "aria-label": "Search apps", autocomplete: "off", autocapitalize: "off", spellcheck: "false", enterkeyhint: "search" });
  const clearBtn = iconButton({ icon: "x", label: "Clear search", cls: "clear", size: 16, onClick: () => { input.value = ""; paint(); input.focus(); } });
  clearBtn.hidden = true;
  const search = h("label.search", svg("search", 18, 2), input, clearBtn);
  const title = h("header.page-head", h("div.grow", h("h1.page-title", "Apps"), h("p.page-sub")));
  el.append(title, h("div.sticky-top", search));
  const note = h("div", { style: { margin: "4px 0 12px" } });
  const lockNote = h("div", { style: { margin: "4px 0 12px" } });
  const grid = h("div.app-grid", { role: "list" });
  el.append(lockNote, note, grid);

  let data = null;
  const fold = (s) => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();

  function paint() {
    const q = fold(input.value.trim());
    clearBtn.hidden = !q;
    clear(grid);
    if (!data) {
      for (let i = 0; i < 16; i++) grid.appendChild(h("div.app-cell", h("span.skel", { style: { width: "56px", height: "56px", borderRadius: "16px" } }), h("span.skel", { style: { width: "48px", height: "9px" } })));
      return;
    }
    const all = (data.apps || []).slice().sort((a, b) => String(a.name).localeCompare(String(b.name), undefined, { sensitivity: "base" }));
    title.querySelector(".page-sub").textContent = all.length ? all.length + " apps on " + ctx.pc.name : "";
    const list = q ? all.filter((a) => fold(a.name).includes(q) || fold(a.id).includes(q) || (a.keywords && fold(a.keywords).includes(q))) : all;
    if (!all.length) { grid.appendChild(empty({ icon: "grid", title: "No apps yet", body: "Apps installed on " + ctx.pc.name + " show up here." })); return; }
    if (!list.length) { grid.appendChild(empty({ icon: "search", title: "No apps match “" + input.value.trim() + "”", body: "Try a shorter name." })); return; }
    const frag = document.createDocumentFragment();
    list.forEach((a, i) => {
      const b = h("button.app-cell", { type: "button", role: "listitem", "aria-label": "Open " + a.name }, appIcon(a, 56), h("span.nm", a.name));
      if (!q && i < 24) { b.style.animation = "pop var(--d-pop) var(--spring) backwards"; b.style.animationDelay = i * 18 + "ms"; }
      b.addEventListener("click", () => launch(a, b));
      frag.appendChild(b);
    });
    grid.appendChild(frag);
  }

  async function launch(a, b) {
    b.classList.add("launching");
    toast("Opening " + a.name + "…", "info", { icon: "grid", ms: 2200 });
    await ctx.run("launch", { id: a.id });
    setTimeout(() => b.classList.remove("launching"), 900);
  }

  input.addEventListener("input", paint);
  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      const first = grid.querySelector(".app-cell");
      if (first && input.value.trim()) { first.click(); input.blur(); }
    }
  });
  paint();
  ctx.subscribe("apps", (d) => {
    data = d || { apps: [] };
    const c = data.desk && data.desk.company;
    clear(note);
    if (c) note.appendChild(banner({ kind: "accent", icon: "brief", title: "Apps open in " + (data.desk.name || c), body: "That's the environment shown on " + ctx.pc.name + " right now." }));
    paint();
  });
  ctx.subscribe("system", (s) => {
    clear(lockNote);
    if (s && s.locked) lockNote.appendChild(banner({ kind: "amber", icon: "lock", title: "PC is locked", body: "Unlock it at the PC to open apps." }));
  });
}
