// Command Deck: boot, pairing, the router, bottom navigation, connection overlays and the module ctx.
// Modules live in /modules/<id>/ (module.json + panel.js); see linux/session/commanddeck/MODULES.md.
import * as ui from "./ui.js";
import { h, clear, svg, mark, button, iconButton, row, group, sectionLabel, pageHead, empty, toast, confirm, closeLayers } from "./ui.js";
import { Conn, authSocket } from "./conn.js";
import { getInfo, cachedInfo, loadDevice, forgetDevice, cryptoReady } from "./pair.js";
import { showPairing, showUnsupported, showNoPc } from "./pairview.js";

const root = document.getElementById("app");
const S = {
  info: null, pcId: null, pcName: "your PC", device: null, conn: null,
  modules: [], byId: new Map(), panels: new Map(),
  route: null, current: null, navToken: 0,
  view: null, nav: null, navItems: new Map(), navPill: null, overlay: null, pill: null,
  caps: loadJson("deck.caps") || null, system: null, installPrompt: null,
};

function loadJson(k) { try { return JSON.parse(localStorage.getItem(k) || "null"); } catch { return null; } }
function saveJson(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* private mode */ } }

// Plain words for failed calls (deckd's codes, PROTOCOL.md §1).
export function errorText(err, pc = S.pcName) {
  const c = err && err.code;
  return ({
    locked: pc + " is locked. Unlock it at the PC first.",
    shell: "The desktop on " + pc + " isn't answering. Try again in a moment.",
    timeout: pc + " took too long to answer.",
    offline: "Not connected to " + pc + ".",
    "unknown-op": pc + " can't do that yet.",
    "bad-args": "That didn't work. Try again.",
    off: "That's turned off on " + pc + ".",
  })[c] || (err && err.detail) || (err && err.message) || "That didn't work.";
}

// ---- boot --------------------------------------------------------------------------------------------
addEventListener("beforeinstallprompt", (e) => { e.preventDefault(); S.installPrompt = e; });

async function boot() {
  if (!cryptoReady()) { showUnsupported(root); return; }

  // The pairing token lives only in memory: drop it from the address bar and history at once.
  let token = null;
  const m = /^#p=([A-Za-z0-9_-]{8,128})/.exec(location.hash);
  if (m) { token = m[1]; history.replaceState(null, "", location.pathname + location.search + "#home"); }

  let info = null;
  try { info = await getInfo(); } catch { info = null; }
  const known = info || cachedInfo();
  if (!known) { showNoPc(root, () => boot()); return; }
  S.info = info;
  S.pcId = known.pcId;
  S.pcName = known.name || "your PC";

  const device = await loadDevice(S.pcId);
  if (device) { start(device); return; }
  if (!info) { showNoPc(root, () => boot()); return; }
  showPairing(root, { info, token, onPaired: (d) => start(d) });
}

// `forget`: drop this phone's key for the PC. Not for "denied": it arrives before sign-in, unsealed, so a
// device on the network could fake it; a new pairing overwrites the key anyway.
function toPairing(message, { forget = true } = {}) {
  const old = S.conn;
  S.conn = null;
  S.navToken++;                                   // drop any page that's still loading
  removeEventListener("hashchange", route);
  if (old) old.suspend();
  if (S.current && S.current.unmount) try { S.current.unmount(); } catch { /* */ }
  S.current = null;
  (forget ? forgetDevice(S.pcId) : Promise.resolve()).then(async () => {
    let info = S.info;
    try { info = await getInfo(); } catch { /* keep what we had */ }
    S.info = info;
    if (info) { S.pcId = info.pcId; S.pcName = info.name || S.pcName; }
    document.body.classList.remove("nav-hidden");
    showPairing(root, { info: info || { name: S.pcName, pcId: S.pcId }, message, onPaired: (d) => start(d) });
  });
}

// ---- the running app -------------------------------------------------------------------------------
async function start(device) {
  S.device = device;
  icons.clear();
  arts.clear();
  clear(root);
  S.view = h("div", { id: "view" });
  S.nav = h("nav.nav", { "aria-label": "Sections" });
  root.append(S.view, S.nav);

  const conn = new Conn({ pcId: S.pcId, device });
  S.conn = conn;
  conn.addEventListener("status", (e) => { if (S.conn === conn) onStatus(e.detail); });
  conn.addEventListener("ready", (e) => { if (S.conn === conn) onReady(e.detail); });
  conn.addEventListener("caps", (e) => { if (S.conn === conn) setCaps(e.detail); });
  conn.addEventListener("denied", (e) => {
    if (S.conn !== conn) return;
    const r = e.detail.reason;
    toPairing(r === "other-pc"
      ? "A different PC answers at this address now. Connect this phone to it with its code."
      : "This phone isn't connected to " + S.pcName + " anymore. Connect it again with the code in Settings › Command Deck.",
      { forget: false });
  });
  conn.addEventListener("bye", (e) => {
    if (S.conn !== conn) return;
    if (e.detail.reason === "removed") toPairing("This phone was removed from " + S.pcName + ". Connect it again with the code in Settings › Command Deck.");
  });
  conn.subscribe("system", (sys) => {
    S.system = sys || {};
    if (sys && sys.pcName) S.pcName = sys.pcName;
    document.body.classList.toggle("pc-locked", !!(sys && sys.locked));
  });

  await loadModules();
  buildNav();
  addEventListener("hashchange", route);
  conn.start();
  route();
}

async function loadModules() {
  let ids = [];
  try { ids = await (await fetch("/modules/index.json", { cache: "no-cache" })).json(); } catch { ids = ["home", "apps", "running", "screen", "trackpad", "media", "power", "files"]; }
  const mods = await Promise.all(ids.map((id) => fetchModule(id, false)));
  S.modules = mods.filter(Boolean);
  // built-in shell pages
  S.modules.push({ id: "more", name: "More", glyph: "M5 12h.01M12 12h.01M19 12h.01", order: 1000, surfaces: ["page"], nav: true, builtin: true, description: "" });
  S.modules.push({ id: "about", name: "About", glyph: "info", order: 1001, surfaces: ["page"], nav: false, builtin: true, hidden: true });
  sortModules();
}
async function fetchModule(id, server) {
  if (!/^[a-z][a-z0-9-]{0,31}$/.test(id)) return null;
  try {
    const m = await (await fetch("/modules/" + id + "/module.json", { cache: "no-cache" })).json();
    if (!m || m.id !== id) return null;
    return { surfaces: ["page"], needs: [], nav: false, order: 500, hue: "#7AE7FF", ...m, server: server || m.server === true };
  } catch { return null; }
}
function sortModules() {
  S.modules.sort((a, b) => (a.order || 0) - (b.order || 0));
  S.byId = new Map(S.modules.map((m) => [m.id, m]));
}
async function addServerModules(list) {
  const fresh = (list || []).filter((m) => m && m.id && !S.byId.has(m.id));
  if (!fresh.length) return;
  const mods = (await Promise.all(fresh.map((m) => fetchModule(m.id, true)))).filter(Boolean);
  if (!mods.length) return;
  S.modules.push(...mods);
  sortModules();
  buildNav();
}

function onReady(ready) {
  setCaps(ready.caps || {});
  if (ready.pc && ready.pc.name) S.pcName = ready.pc.name;
  addServerModules(ready.modules);
}
function setCaps(caps) {
  const changed = JSON.stringify(caps) !== JSON.stringify(S.caps);
  S.caps = caps;
  saveJson("deck.caps", caps);
  if (!changed) return;
  buildNav();
  document.dispatchEvent(new CustomEvent("deck:caps", { detail: caps }));
  // the page on show may now be (un)available
  if (S.current && S.current.mod && S.current.mod.needs && S.current.mod.needs.length) route(true);
}
function available(mod) {
  if (!mod.needs || !mod.needs.length || !S.caps) return true;
  return mod.needs.every((n) => S.caps[n] !== false);
}

// ---- navigation ---------------------------------------------------------------------------------------
function navModules() { return S.modules.filter((m) => m.nav && (m.surfaces || []).includes("page")).slice(0, 4).concat(S.byId.get("more")).filter(Boolean); }
function moreModules() {
  const inNav = new Set(navModules().map((m) => m.id));
  return S.modules.filter((m) => !inNav.has(m.id) && !m.hidden && (m.surfaces || []).includes("page"));
}

function buildNav() {
  if (!S.nav) return;
  clear(S.nav);
  S.navItems.clear();
  const inner = h("div.nav-inner");
  S.navPill = h("div.nav-pill");
  inner.appendChild(S.navPill);
  for (const m of navModules()) {
    const b = h("button.nav-item", { type: "button", "aria-label": m.name },
      h("span.ico", svg(m.glyph, 22, 1.9)), h("span.lbl", m.name));
    b.addEventListener("click", () => navigate(m.id, {}, { tab: true }));
    S.navItems.set(m.id, b);
    inner.appendChild(b);
  }
  S.nav.appendChild(inner);
  markNav();
}
function markNav() {
  if (!S.route) return;
  let id = S.route.id;
  if (!S.navItems.has(id)) id = "more";                     // pages reached from More light up More
  let active = null;
  for (const [k, b] of S.navItems) {
    const on = k === id;
    if (on) { b.setAttribute("aria-current", "page"); active = b; } else b.removeAttribute("aria-current");
  }
  if (active && S.navPill) {
    requestAnimationFrame(() => {
      const w = 56;
      const x = active.offsetLeft + (active.offsetWidth - w) / 2;
      S.navPill.style.width = w + "px";
      S.navPill.style.transform = "translateX(" + x + "px)";
    });
  }
}

function parseHash() {
  const raw = decodeURIComponent((location.hash || "").replace(/^#\/?/, ""));
  const [id, q] = raw.split("?");
  const params = {};
  if (q) for (const [k, v] of new URLSearchParams(q)) params[k] = v;
  return { id: id || "home", params };
}

/** Go to a module page. Tabs (bottom navigation) replace the history entry; other pages push one. */
export async function navigate(id, params = {}, { tab = false, replace = false } = {}) {
  if (ui.hasLayers()) await closeLayers();
  const q = new URLSearchParams(params).toString();
  const hash = "#" + id + (q ? "?" + q : "");
  if (location.hash === hash) { route(true); return; }
  if (tab || replace) {
    const depth = (history.state && history.state.depth) || 0;
    history.replaceState({ depth }, "", hash);
    route();
  } else {
    const depth = ((history.state && history.state.depth) || 0) + 1;
    history.pushState({ depth }, "", hash);
    route();
  }
}
export function back() {
  if (history.state && history.state.depth > 0) history.back();
  else navigate("home", {}, { replace: true });
}

async function route(force) {
  if (!S.conn) return;
  const r = parseHash();
  let mod = S.byId.get(r.id);
  if (!mod) { history.replaceState(history.state, "", "#home"); r.id = "home"; mod = S.byId.get("home"); }
  if (!force && S.route && S.route.id === r.id && JSON.stringify(S.route.params) === JSON.stringify(r.params) && S.current) return;
  S.route = r;
  const token = ++S.navToken;
  if (S.current && S.current.unmount) { try { S.current.unmount(); } catch (e) { console.error(e); } }
  if (S.current && S.current.ctx) S.current.ctx._cleanup();
  S.current = null;
  markNav();

  const bare = mod.chrome === "bare" && available(mod);
  document.body.classList.toggle("nav-hidden", bare);
  S.nav.classList.toggle("hide", bare);
  const el = h("main.page" + (bare ? ".bare" : ""), { "data-page": mod.id });
  clear(S.view).appendChild(el);
  window.scrollTo(0, 0);

  const ctx = makeCtx(mod, r.params);
  S.current = { mod, ctx, el, unmount: null };
  try {
    if (mod.id === "more") { S.current.unmount = mountMore(el, ctx); return; }
    if (mod.id === "about") { S.current.unmount = mountAbout(el, ctx); return; }
    if (!available(mod)) { mountOff(el, mod); return; }
    const panel = await loadPanel(mod);
    if (token !== S.navToken || !S.current || S.current.ctx !== ctx) return;
    const u = panel.mount(el, ctx);
    S.current.unmount = typeof u === "function" ? u : null;
  } catch (e) {
    console.error(e);
    if (token !== S.navToken) return;
    clear(el).appendChild(ui.errorState({ title: "This page didn't load", body: String(e && e.message || e), retry: () => route(true) }));
  }
}

function loadPanel(mod) {
  if (!S.panels.has(mod.id)) {
    const p = import("/modules/" + mod.id + "/panel.js");
    p.catch(() => S.panels.delete(mod.id));
    S.panels.set(mod.id, p);
  }
  return S.panels.get(mod.id);
}

function mountOff(el, mod) {
  el.append(pageHead({ title: mod.name }), empty({
    icon: mod.glyph || "info", title: "Turned off on " + S.pcName,
    body: mod.offText || ("Someone at " + S.pcName + " turned this off. It can be turned back on in Settings › Command Deck."),
    actions: [button({ label: "Back to Home", kind: "primary", onClick: () => navigate("home", {}, { tab: true }) })],
  }));
}

// ---- icons and album art ------------------------------------------------------------------------------------
// They come over the control socket (ops `icon {name}` / `art {key}` → {type, b64}) and become blob: URLs,
// kept in memory per name/key. Many tiles asking for one icon share one call; a few calls at a time, so a
// tap's call never waits behind a page of icons. Only a definite "no" from the PC is remembered as none.
const IMAGE_TYPES = /^image\/(png|jpeg|gif|webp|avif|bmp|svg\+xml|x-icon|vnd\.microsoft\.icon)$/;
const TRANSIENT = new Set(["offline", "timeout", "shell", "locked"]);
function b64Blob(b64, type) {
  // standard or URL-safe, padded or not
  const s = String(b64).replace(/[\s=]+/g, "").replace(/-/g, "+").replace(/_/g, "/");
  const bin = atob(s + "===".slice((s.length + 3) % 4));
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return new Blob([out], { type });
}
function blobCache(op, arg, max) {
  const done = new Map();          // key -> blob URL | null (the PC has none), oldest first
  const flight = new Map();        // key -> Promise
  const queue = [];
  let running = 0;
  const remember = (key, url) => {
    done.set(key, url);
    while (done.size > max) {
      const [k, u] = done.entries().next().value;
      done.delete(k);
      if (u) URL.revokeObjectURL(u);
    }
  };
  const next = () => {
    while (running < 4 && queue.length) {
      const job = queue.shift();
      running++;
      job().finally(() => { running--; next(); });
    }
  };
  const get = (key) => {
    if (!key || typeof key !== "string") return Promise.resolve(null);
    if (done.has(key)) { const u = done.get(key); done.delete(key); done.set(key, u); return Promise.resolve(u); }
    if (flight.has(key)) return flight.get(key);
    const conn = S.conn;
    const p = new Promise((resolve) => {
      queue.push(() => (conn ? conn.call(op, { [arg]: key }, { timeout: 12000 }) : Promise.reject(Object.assign(new Error("offline"), { code: "offline" })))
        .then((d) => {
          if (!d || typeof d.b64 !== "string" || !IMAGE_TYPES.test(String(d.type || ""))) throw Object.assign(new Error("bad"), { code: "bad" });
          const url = URL.createObjectURL(b64Blob(d.b64, d.type));
          if (S.conn === conn) remember(key, url);
          resolve(url);
        })
        .catch((e) => {
          if (S.conn === conn && !TRANSIENT.has(e && e.code)) remember(key, null);
          resolve(null);
        })
        .finally(() => { if (flight.get(key) === p) flight.delete(key); }));
      next();
    });
    flight.set(key, p);
    return p;
  };
  get.peek = (key) => done.get(key);           // undefined: not asked yet; null: the PC has none
  // (calls still queued finish on their own connection, which is gone: they answer null and remember nothing)
  get.clear = () => { for (const u of done.values()) if (u) URL.revokeObjectURL(u); done.clear(); flight.clear(); };
  return get;
}
const icons = blobCache("icon", "name", 400);
const arts = blobCache("art", "key", 24);
ui.setIconLoader(icons);

// ---- ctx ------------------------------------------------------------------------------------------------
function makeCtx(mod, params) {
  const cleanups = [];
  const conn = S.conn;
  const ctx = {
    module: mod,
    params,
    ui,
    call: (op, args = {}, opts = {}) => conn.call(op, args, { mod: mod.server ? mod.id : undefined, ...opts }),
    /** call + a toast in plain words when it fails; resolves the data or null. */
    run: async (op, args = {}, { ok, quiet } = {}) => {
      try {
        const d = await ctx.call(op, args);
        if (ok) toast(ok, "ok");
        return d === undefined ? true : d;
      } catch (e) {
        if (!quiet) toast(errorText(e), e.code === "locked" ? "warn" : "error", { icon: e.code === "locked" ? "lock" : undefined });
        return null;
      }
    },
    subscribe: (topic, cb) => { const u = conn.subscribe(topic, cb); cleanups.push(u); return u; },
    state: (topic) => conn.get(topic),
    navigate: (id, p, o) => navigate(id, p, o),
    back,
    toast: (text, kind, o) => toast(text, kind, o),
    confirm: (o) => confirm(o),
    get caps() { return (conn.ready && conn.ready.caps) || S.caps || {}; },
    get device() { return (conn.ready && conn.ready.device) || { id: S.device && S.device.deviceId, name: S.device && S.device.name }; },
    get pc() { return { name: S.pcName, id: S.pcId, ...((conn.ready && conn.ready.pc) || {}), ...(S.system && S.system.pcName ? { name: S.system.pcName } : {}) }; },
    get connected() { return conn.state === "ready"; },
    /** An app's or window's icon (its `icon` name) as a blob: URL; null when the PC has none. */
    icon: (name) => icons(name),
    /** Local album art (`art:<key>` in the media topic) as a blob: URL; null when there's none. */
    art: (key) => arts(key),
    errorText: (e) => errorText(e),
    /** Open another signed-in, sealed socket (/ws/screen, /ws/files): {ws, ready}; ws.send(string | bytes). */
    openSocket: (path, handlers) => authSocket(path, { pcId: S.pcId, device: S.device, ...handlers }),
    onConnection: (cb) => {
      const f = (e) => cb(e.detail.state, e.detail);
      conn.addEventListener("status", f);
      cleanups.push(() => conn.removeEventListener("status", f));
      return () => conn.removeEventListener("status", f);
    },
    onCaps: (cb) => {
      const f = (e) => cb(e.detail);
      document.addEventListener("deck:caps", f);
      cleanups.push(() => document.removeEventListener("deck:caps", f));
    },
    onVisibility: (cb) => {
      const f = () => cb(document.visibilityState === "visible");
      document.addEventListener("visibilitychange", f);
      cleanups.push(() => document.removeEventListener("visibilitychange", f));
    },
    /** Modules that offer a Home tile, in order (for the Home page). */
    tileModules: () => S.modules.filter((m) => (m.surfaces || []).includes("tile") && m.id !== mod.id)
      .sort((a, b) => (a.tileOrder ?? a.order ?? 0) - (b.tileOrder ?? b.order ?? 0)),
    available: (m) => available(typeof m === "string" ? S.byId.get(m) || {} : m),
    /** Mount module `id`'s tile(el, ctx) into el. Returns its unmount. */
    mountTile: async (id, el) => {
      const m = S.byId.get(id);
      if (!m) return null;
      const panel = await loadPanel(m);
      if (typeof panel.tile !== "function" || S.conn !== conn || !el.isConnected) return null;
      const tctx = makeCtx(m, {});
      const u = panel.tile(el, tctx);
      const off = () => { if (typeof u === "function") try { u(); } catch { /* */ } tctx._cleanup(); };
      cleanups.push(off);
      return off;
    },
    _cleanup: () => { while (cleanups.length) { try { cleanups.pop()(); } catch { /* */ } } },
  };
  return ctx;
}

// ---- connection overlays -------------------------------------------------------------------------------
let pillTimer = 0;
function onStatus({ state, attempting, kind, reason }) {
  clearTimeout(pillTimer);
  if (state === "ready" || state === "suspended") { hidePill(); hideOverlay(); return; }
  if (state === "connecting") { hideOverlay(); pillTimer = setTimeout(() => showPill("Connecting to " + S.pcName + "…"), 700); return; }
  if (state === "reconnecting") { hideOverlay(); showPill("Reconnecting…"); return; }
  if (state === "unreachable") {
    hidePill();
    showOverlay({
      title: "Can't reach " + S.pcName,
      body: "It may be asleep, off, or not on your home Wi-Fi.",
      action: attempting ? "Trying…" : "Retry", busy: attempting,
      onAction: () => S.conn && S.conn.retry(),
    });
    return;
  }
  if (state === "ended" && kind === "bye" && reason !== "removed") {
    hidePill();
    const t = {
      disconnected: [S.pcName + " disconnected this phone", "Someone at the PC chose Disconnect phones. You can connect again whenever you like."],
      off: ["Command Deck was turned off on " + S.pcName, "It can be turned on again in Settings › Command Deck on the PC."],
      network: [S.pcName + " left your home network", "Command Deck only works on your home network. It reconnects once the PC is back on it."],
    }[reason] || [S.pcName + " ended the connection", "You can connect again whenever you like."];
    showOverlay({ title: t[0], body: t[1], action: "Reconnect", onAction: () => { hideOverlay(); S.conn && S.conn.restart(); } });
  }
}
function showPill(text) {
  if (!S.pill) { S.pill = h("div.conn-pill", { role: "status" }); document.body.appendChild(S.pill); }
  clear(S.pill).append(h("span.spinner"), h("span", text));
}
function hidePill() { if (S.pill) { S.pill.remove(); S.pill = null; } }
function showOverlay({ title, body, action, onAction, busy }) {
  const fresh = !S.overlay;
  if (fresh) { S.overlay = h("div.overlay", { role: "alertdialog", "aria-modal": "true" }); document.body.appendChild(S.overlay); }
  const b = button({ label: action, kind: "primary", block: true, busy, onClick: onAction });
  const other = button({ label: "About this connection", kind: "ghost", block: true, onClick: () => { hideOverlay(); navigate("about"); } });
  clear(S.overlay).append(mark(84, { busy: !!busy, dim: !busy }), h("div.ot", title), h("div.ob", body), h("div.oa", b, other));
  if (fresh) requestAnimationFrame(() => { try { b.focus({ preventScroll: true }); } catch { /* */ } });
}
function hideOverlay() { if (S.overlay) { S.overlay.remove(); S.overlay = null; } }

// ---- More + About (shell pages) ---------------------------------------------------------------------------
function mountMore(el, ctx) {
  el.appendChild(pageHead({ title: "More", sub: S.pcName }));
  const rows = moreModules().map((m) => {
    const lead = h("span.lead", svg(m.glyph, 19));
    lead.style.color = m.hue || "";
    const r = row({ lead, title: m.name, sub: available(m) ? (m.description || "") : "Turned off on " + S.pcName, chevron: true, onClick: () => navigate(m.id) });
    return r;
  });
  el.append(group(...rows), sectionLabel("This phone"),
    group(row({ lead: h("span.lead", svg("phone", 19)), title: "About this phone and PC", sub: (ctx.device.name || "This phone") + " · " + S.pcName, chevron: true, onClick: () => navigate("about") })));
  const redraw = () => route(true);
  document.addEventListener("deck:caps", redraw);
  return () => document.removeEventListener("deck:caps", redraw);
}

function mountAbout(el, ctx) {
  const conn = S.conn;
  el.appendChild(pageHead({ title: "About", back }));
  const status = h("span.v");
  const paintStatus = () => {
    status.textContent = { ready: "Connected", connecting: "Connecting…", reconnecting: "Reconnecting…", unreachable: "Can't reach it", suspended: "Paused", ended: "Disconnected" }[conn.state] || conn.state;
  };
  paintStatus();
  ctx.onConnection(paintStatus);
  const kv = (k, v, mono) => h("div.kv", h("span.k", k), v instanceof Node ? v : h("span.v" + (mono ? ".mono" : ""), v));
  const paired = S.device && S.device.paired ? new Date(S.device.paired).toLocaleDateString(undefined, { day: "numeric", month: "long", year: "numeric" }) : "—";
  el.append(
    h("div.card", { style: { display: "flex", alignItems: "center", gap: "14px" } }, mark(52),
      h("div", h("div", { style: { font: "500 19px var(--font-display)" } }, "Command Deck"), h("div.muted", { style: { fontSize: "13.5px", marginTop: "2px" } }, "Your phone as a remote for " + S.pcName))),
    sectionLabel("PC"),
    h("div.group", kv("Name", S.pcName), kv("Address", location.host, true), kv("Connection", status),
      kv("Security", "Encrypted, home network only")),
    sectionLabel("This phone"),
    h("div.group", kv("Name", ctx.device.name || (S.device && S.device.name) || "This phone"), kv("Connected since", paired)),
  );
  // install
  const isIos = /iPhone|iPad/.test(navigator.userAgent) || (/Macintosh/.test(navigator.userAgent) && navigator.maxTouchPoints > 1);
  const isAndroid = /Android/.test(navigator.userAgent);
  const standalone = matchMedia("(display-mode: standalone)").matches || navigator.standalone;
  if (!standalone && (S.installPrompt || isIos || isAndroid)) {
    el.appendChild(sectionLabel("Home screen"));
    if (S.installPrompt) {
      el.appendChild(group(row({ lead: "download", title: "Add to Home screen", sub: "Open Command Deck like an app", chevron: true,
        onClick: async () => { const p = S.installPrompt; S.installPrompt = null; p.prompt(); try { await p.userChoice; } catch { /* */ } route(true); } })));
    } else if (isIos) {
      el.appendChild(ui.banner({ kind: "accent", icon: "download", title: "Add it to your Home Screen", body: "In Safari, tap Share, then Add to Home Screen. You'll need the 6-digit code once more there." }));
    } else {
      el.appendChild(ui.banner({ kind: "accent", icon: "download", title: "Add it to your Home screen", body: "In Chrome, tap the menu (three dots), then Add to Home screen." }));
    }
  }
  const forget = button({ label: "Forget " + S.pcName, icon: "trash", kind: "danger-soft", block: true, onClick: async () => {
    const yes = await confirm({ title: "Forget " + S.pcName + "?", icon: "trash", danger: true, action: "Forget",
      body: "This phone stops connecting to " + S.pcName + " and the PC forgets it too. To use it again you'll need the code from Settings › Command Deck." });
    if (!yes) return;
    // Ask the PC to drop this phone first (it then closes our sockets); offline, the PC keeps it listed.
    try { if (S.conn && S.conn.ready) await S.conn.call("forget", {}, { timeout: 4000 }); } catch { /* offline: forget locally */ }
    toPairing(null);
  } });
  el.append(h("div", { style: { marginTop: "22px" } }, forget), h("p.footer-note", "Command Deck works only on your home network. Nothing is sent anywhere else."));
  return null;
}

boot();
