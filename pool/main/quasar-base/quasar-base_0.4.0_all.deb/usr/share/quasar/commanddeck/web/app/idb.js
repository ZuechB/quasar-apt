// A tiny IndexedDB wrapper. Database "quasar-deck":
//   devices: one record per PC, keyed by pcId: {pcId, deviceId, name, secret, pcPub, paired}
//            (secret = this phone's X25519 secret key for that PC, pcPub = the PC's public key)
// Version 2 drops "shares" (the service worker's share-target inbox; there's no service worker over HTTP).
const DB = "quasar-deck", VERSION = 2;
let dbp = null;

export function openDb() {
  if (dbp) return dbp;
  dbp = new Promise((resolve, reject) => {
    if (!("indexedDB" in self)) { reject(new Error("no-indexeddb")); return; }
    const req = indexedDB.open(DB, VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains("devices")) db.createObjectStore("devices", { keyPath: "pcId" });
      if (db.objectStoreNames.contains("shares")) db.deleteObjectStore("shares");
    };
    req.onsuccess = () => {
      const db = req.result;
      db.onversionchange = () => { db.close(); dbp = null; };
      resolve(db);
    };
    req.onerror = () => { dbp = null; reject(req.error); };
    req.onblocked = () => { dbp = null; reject(new Error("blocked")); };
  });
  return dbp;
}

function tx(store, mode, fn) {
  return openDb().then((db) => new Promise((resolve, reject) => {
    const t = db.transaction(store, mode);
    const s = t.objectStore(store);
    let out;
    const r = fn(s);
    if (r && "onsuccess" in r) r.onsuccess = () => { out = r.result; };
    t.oncomplete = () => resolve(out);
    t.onerror = () => reject(t.error);
    t.onabort = () => reject(t.error);
  }));
}

export const idbGet = (store, key) => tx(store, "readonly", (s) => s.get(key));
export const idbPut = (store, value) => tx(store, "readwrite", (s) => s.put(value));
export const idbDelete = (store, key) => tx(store, "readwrite", (s) => s.delete(key));
export const idbAll = (store) => tx(store, "readonly", (s) => s.getAll());
export const idbClear = (store) => tx(store, "readwrite", (s) => s.clear());
