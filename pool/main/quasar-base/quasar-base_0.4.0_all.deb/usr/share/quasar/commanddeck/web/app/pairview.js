// The pairing screen: the QR code's token (#p=…) or the 6-digit code shown under it in
// Settings › Command Deck. Errors from deckd: wrong, expired, slow-down, bad-key; from the phone's own check of
// the answer: bad-pc.
import { h, clear, mark, button, banner, vibrate } from "./ui.js";
import { pair, makeKey, guessName, PairError } from "./pair.js";

const ERRORS = {
  wrong: "That code didn't match. Check the 6 digits on the PC and try again.",
  expired: "That code has expired. Use the one the PC shows now.",
  "slow-down": "Too many tries. Wait a minute, then try again.",
  "bad-key": "This browser couldn't make a secure key. Try another browser.",
  "bad-pc": "Something on this network changed the PC's answer. Try again.",
  offline: "Can't reach the PC. Make sure this phone is on your home Wi-Fi.",
};

export function showPairing(root, { info, token, message, onPaired }) {
  const pcName = (info && info.name) || "your PC";
  let mode = token ? "token" : "code";
  let keyPair = null, busy = false, guessed = null;
  const keyReady = Promise.resolve().then(makeKey).then((k) => { keyPair = k; }).catch(() => {});

  clear(root);
  const page = h("div.pair");
  root.appendChild(page);

  const nameInput = h("input.input", { type: "text", autocomplete: "off", autocapitalize: "words", spellcheck: "false", maxlength: "40", "aria-label": "This phone's name" });
  guessName().then((g) => { guessed = g; if (!nameInput.value) nameInput.value = g.name; });

  const msg = h("div.msg", { role: "status", "aria-live": "polite" });
  const setMsg = (text, err) => { msg.textContent = text || ""; msg.classList.toggle("err", !!err); };

  const logo = mark(76, { busy: false });
  const title = h("h1.pt");
  const body = h("p.pb");
  const form = h("form", { novalidate: true });
  page.append(logo, title, body);
  if (message) page.appendChild(h("div", { style: { width: "100%", marginTop: "18px", textAlign: "left" } }, banner({ kind: "amber", icon: "info", body: message })));
  page.append(form, h("p.foot", "Command Deck only works on your home network, and it never sends anything anywhere else."));

  // ---- the 6-digit code ----
  const cells = Array.from({ length: 6 }, () => h("span.cell"));
  const codeInput = h("input", {
    type: "text", inputmode: "numeric", pattern: "[0-9]*", autocomplete: "one-time-code", maxlength: "6",
    "aria-label": "6-digit code from the PC", enterkeyhint: "go",
  });
  const codeBox = h("div.code", ...cells, codeInput);
  const paint = (err) => {
    const v = codeInput.value;
    cells.forEach((c, i) => {
      c.textContent = v[i] || "";
      c.classList.toggle("cur", document.activeElement === codeInput && i === Math.min(v.length, 5) && !err);
      c.classList.toggle("err", !!err);
    });
  };
  codeInput.addEventListener("input", () => {
    const digits = codeInput.value.replace(/\D/g, "").slice(0, 6);
    if (digits !== codeInput.value) codeInput.value = digits;
    setMsg("");
    paint();
    if (digits.length === 6) submit();
  });
  codeInput.addEventListener("focus", () => paint());
  codeInput.addEventListener("blur", () => paint());
  codeBox.addEventListener("click", () => codeInput.focus());

  const connectBtn = button({ label: "Connect", kind: "primary", block: true, type: "submit" });

  const render = () => {
    clear(form);
    if (mode === "token") {
      title.textContent = "Connect to " + pcName;
      body.textContent = "This phone will be able to open apps, see the screen and control " + pcName + " while you're both on your home Wi-Fi.";
      form.append(h("label.field", h("span", "This phone's name"), nameInput), connectBtn, msg);
    } else {
      title.textContent = info && info.name ? "Connect to " + pcName : "Connect this phone";
      body.textContent = "Open Settings › Command Deck on your PC and scan the code, or type the 6 digits shown under it.";
      connectBtn.disabled = false;
      form.append(h("label.field", h("span", "Code from the PC"), codeBox), h("label.field", h("span", "This phone's name"), nameInput), msg);
      paint();
      if (info && info.pairing === false) setMsg("Your PC isn't showing a code right now. Open Settings › Command Deck on it.");
    }
  };

  async function submit(e) {
    if (e) e.preventDefault();
    if (busy) return;
    const code = codeInput.value;
    if (mode === "code" && code.length !== 6) { codeInput.focus(); return; }
    busy = true;
    logo.classList.add("busy");
    connectBtn.setBusy(true, "Connecting…");
    codeInput.disabled = true;
    setMsg(mode === "code" ? "Checking…" : "");
    try {
      await keyReady;
      const name = (nameInput.value || "").trim() || (guessed && guessed.name) || "Phone";
      const device = await pair({ pcId: info && info.pcId, token: mode === "token" ? token : null, code: mode === "code" ? code : null,
        name, model: guessed ? guessed.model : "", keyPair });
      setMsg("Connected", false);
      cells.forEach((c) => c.classList.remove("err"));
      vibrate(10);
      onPaired(device);
    } catch (err) {
      const c = err instanceof PairError ? err.code : "failed";
      busy = false;
      logo.classList.remove("busy");
      connectBtn.setBusy(false, "Connect");
      codeInput.disabled = false;
      if (mode === "token" && (c === "expired" || c === "wrong")) {
        mode = "code";
        token = null;
        render();
        setMsg("That QR code has expired. Type the 6 digits shown under it, or scan it again.", true);
        return;
      }
      setMsg(ERRORS[c] || (err && err.message) || "That didn't work. Try again.", true);
      if (mode === "code") {
        paint(true);
        codeBox.classList.remove("shake");
        void codeBox.offsetWidth;
        codeBox.classList.add("shake");
        vibrate(30);
        if (c === "wrong" || c === "expired" || c === "bad-pc") setTimeout(() => { codeInput.value = ""; paint(); codeInput.focus(); }, 650);
      }
    }
  }
  form.addEventListener("submit", submit);
  render();
  if (mode === "code") setTimeout(() => { try { codeInput.focus({ preventScroll: true }); } catch { /* */ } }, 350);
}

/** Shown when this browser lacks what the app needs (its encryption code, random numbers or storage). */
export function showUnsupported(root) {
  clear(root);
  root.appendChild(h("div.pair", mark(76, { dim: true }), h("h1.pt", "This browser can't connect"),
    h("p.pb", "Command Deck needs a browser that can keep its keys. Open the link in Chrome or Safari, not in a private window.")));
}

/** Shown when /api/info can't be reached and no PC is remembered. */
export function showNoPc(root, retry) {
  clear(root);
  const b = button({ label: "Try again", icon: "refresh", kind: "primary", block: true, onClick: () => { b.setBusy(true, "Trying…"); retry(); } });
  root.appendChild(h("div.pair", mark(76, { dim: true }), h("h1.pt", "Can't reach your PC"),
    h("p.pb", "It may be asleep, off, or not on your home Wi-Fi. Command Deck also has to be turned on in Settings › Command Deck."),
    h("div", { style: { width: "100%", marginTop: "28px" } }, b)));
}
