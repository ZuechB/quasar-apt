// Send files: photos and files to the PC's Downloads. One file at a time from a queue, with progress and
// cancel, over one signed-in, sealed /ws/files socket (PROTOCOL.md §1): {t:"file"} → go → 'D' + up to
// 64 KiB per message, at most 2 MiB the PC hasn't acknowledged → done. Cancelling closes the socket (the PC
// removes the partial file). The queue outlives the page, so leaving it doesn't stop a transfer.
const CHUNK = 64 << 10, WINDOW = 2 << 20, READ = 512 << 10;
const Q = { items: [], active: null, seq: 0, listeners: new Set(), open: null, link: null, waitReady: null, wake: null, pcName: "the PC" };
const emit = () => { for (const f of Q.listeners) f(); };

const ERR = {
  auth: "The connection changed. Trying again…",
  denied: "This phone isn't connected to the PC anymore.",
  locked: "The PC is locked. Unlock it, then send again.",
  "too-big": "That file is too big (8 GB at most).",
  "no-space": "There isn't enough free space on the PC.",
  off: "Sending files is turned off on the PC.",
  bad: "The PC couldn't take that file.",
  read: "This phone couldn't read the file. Pick it again.",
  cancelled: "Stopped before it finished.",
  network: "The connection dropped. Send it again.",
};

function enqueue(files, from) {
  for (const f of files) {
    if (!f || typeof f.size !== "number") continue;
    const it = { id: ++Q.seq, file: f, name: f.name || "File", size: f.size, type: f.type || "", state: "queued", sent: 0, error: "", tries: 0, from, thumb: null, at: Date.now() };
    if (/^image\//.test(it.type) && f.size < 40e6) { try { it.thumb = URL.createObjectURL(f); } catch { /* */ } }
    Q.items.push(it);
  }
  emit();
  pump();
}

async function wakeLock(on) {
  try {
    if (on && !Q.wake && navigator.wakeLock) Q.wake = await navigator.wakeLock.request("screen");
    else if (!on && Q.wake) { await Q.wake.release(); Q.wake = null; }
  } catch { Q.wake = null; }
}

async function pump() {
  if (Q.active) return;
  const it = Q.items.find((x) => x.state === "queued");
  if (!it) { wakeLock(false); dropLink(); return; }
  Q.active = it;
  it.state = "sending";
  it.sent = 0;
  emit();
  wakeLock(true);
  try { if (Q.waitReady) await Q.waitReady(); } catch { /* try anyway: the server says no if it must */ }
  const res = it.stopped ? { ok: false, code: "abort" } : await send(it);
  Q.active = null;
  it.stop = null;
  if (res.ok) {
    it.state = "done"; it.sent = it.size; it.saved = res.name || it.name; it.file = null;
  } else if (res.code === "abort") {
    it.state = "cancelled";
    Q.items = Q.items.filter((x) => x !== it);
    if (it.thumb) URL.revokeObjectURL(it.thumb);
  } else if (res.code === "auth" && it.tries < 2) {
    it.tries++; it.state = "queued";
    await new Promise((r) => setTimeout(r, 1200));
  } else {
    it.state = "failed"; it.error = ERR[res.code] || res.error || "That didn't work.";
  }
  emit();
  pump();
}

// ---- the socket: one for the whole queue, closed when it's empty -------------------------------------------
async function link() {
  if (Q.link && !Q.link.closed) return Q.link;
  if (!Q.open) throw Object.assign(new Error("closed"), { code: "closed" });
  const L = { ws: null, closed: false, onmsg: null, onclose: null };
  const { ws } = await Q.open("/ws/files", {
    onMessage: (ev) => { if (L.onmsg) L.onmsg(ev); },
    onClose: () => { L.closed = true; if (Q.link === L) Q.link = null; if (L.onclose) L.onclose(); },
  });
  L.ws = ws;
  Q.link = L;
  return L;
}
function dropLink(L = Q.link) {
  if (!L) return;
  L.closed = true;
  if (Q.link === L) Q.link = null;
  try { L.ws.close(1000); } catch { /* */ }
}

function send(it) {
  return new Promise((resolve) => {
    let L = null, sent = 0, got = 0, going = false, finished = false, lastPaint = 0;
    const finish = (r) => {
      if (finished) return;
      finished = true;
      if (L) { L.onmsg = null; L.onclose = null; }
      resolve(r);
    };
    // Stop = close the socket mid-file; the PC throws the partial file away.
    it.stop = () => { if (L) dropLink(L); finish({ ok: false, code: "abort" }); };
    const progress = (n) => {
      it.sent = Math.min(it.size, n);
      const now = performance.now();
      if (now - lastPaint > 100) { lastPaint = now; emit(); }
    };
    // Reads the file a block at a time and sends it in 'D' messages while < 2 MiB is unacknowledged.
    const pushData = async () => {
      if (going || finished) return;
      going = true;
      try {
        while (!finished && sent < it.size) {
          const room = WINDOW - (sent - got);
          if (room <= 0) break;
          const want = Math.min(READ, it.size - sent, room);
          const buf = new Uint8Array(await it.file.slice(sent, sent + want).arrayBuffer());
          if (finished) break;
          if (buf.length !== want) throw new Error("short read");
          for (let o = 0; o < buf.length && !finished; o += CHUNK) {
            const part = buf.subarray(o, Math.min(buf.length, o + CHUNK));
            const msg = new Uint8Array(1 + part.length);
            msg[0] = 0x44;                                   // 'D'
            msg.set(part, 1);
            if (L.closed || L.ws.readyState !== 1) throw new Error("closed");
            L.ws.send(msg);
            sent += part.length;
          }
        }
      } catch {
        if (!finished) {
          const code = L.closed || L.ws.readyState !== 1 ? "network" : "read";
          dropLink(L);
          finish({ ok: false, code });
        }
      } finally {
        going = false;
      }
    };
    link().then((l) => {
      if (finished) return;
      L = l;
      L.onclose = () => finish({ ok: false, code: "network" });
      L.onmsg = (ev) => {
        if (typeof ev.data !== "string") return;
        let m;
        try { m = JSON.parse(ev.data); } catch { return; }
        if (m.t === "go") pushData();
        else if (m.t === "ack") { got = Math.max(got, Number(m.got) || 0); progress(got); pushData(); }
        else if (m.t === "done") finish({ ok: true, name: m.name });
        else if (m.t === "refused" || m.t === "failed") finish({ ok: false, code: m.code || "failed", error: m.error });
      };
      L.ws.send(JSON.stringify({ t: "file", name: it.name, size: it.size }));
    }, (e) => finish({ ok: false, code: e && e.code === "denied" ? "denied" : "auth" }));
  });
}

function cancel(it) {
  if (it.state === "sending") { it.stopped = true; if (it.stop) it.stop(); return; }
  Q.items = Q.items.filter((x) => x !== it);
  if (it.thumb) URL.revokeObjectURL(it.thumb);
  emit();
}

export function mount(el, ctx) {
  const { h, clear, svg, button, iconButton, row, sectionLabel, banner, progress, formatBytes, toast } = ctx.ui;
  Q.open = ctx.openSocket;
  // polls ctx.connected (the connection outlives this page; its listeners don't)
  Q.waitReady = () => new Promise((res) => {
    if (ctx.connected) { res(); return; }
    const t0 = Date.now();
    const t = setInterval(() => { if (ctx.connected || Date.now() - t0 > 20000) { clearInterval(t); res(); } }, 400);
  });
  Q.pcName = ctx.pc.name;

  el.appendChild(h("header.page-head", h("div.grow", h("h1.page-title", "Send files"), h("p.page-sub", "To Downloads on " + ctx.pc.name))));
  const lockNote = h("div");
  el.appendChild(lockNote);

  // pickers
  const pickPhotos = h("input", { type: "file", accept: "image/*,video/*", multiple: true, hidden: true });
  const pickFiles = h("input", { type: "file", multiple: true, hidden: true });
  for (const p of [pickPhotos, pickFiles]) p.addEventListener("change", () => { enqueue([...p.files], "pick"); p.value = ""; });
  const drop = h("div.drop",
    h("div.di", svg("upload", 28, 1.9)),
    h("div.dt", "Send to " + ctx.pc.name),
    h("div.ds", "Pick photos, videos or any file. They're saved in the Downloads folder."),
    h("div.da",
      button({ label: "Photos", icon: "image", kind: "primary", onClick: () => pickPhotos.click() }),
      button({ label: "Files", icon: "file", onClick: () => pickFiles.click() })),
    pickPhotos, pickFiles);
  drop.addEventListener("dragover", (e) => { e.preventDefault(); drop.classList.add("over"); });
  drop.addEventListener("dragleave", () => drop.classList.remove("over"));
  drop.addEventListener("drop", (e) => { e.preventDefault(); drop.classList.remove("over"); enqueue([...(e.dataTransfer && e.dataTransfer.files || [])], "drop"); });
  el.appendChild(drop);

  const queueBox = h("div"), doneBox = h("div");
  el.append(queueBox, doneBox);
  const rowsById = new Map();

  function itemRow(it) {
    let r = rowsById.get(it.id);
    if (!r) {
      const lead = h("span.lead");
      const icon = () => svg(/^image\//.test(it.type) ? "image" : "file", 19);
      if (it.thumb) {
        const img = h("img", { src: it.thumb, alt: "" });
        img.addEventListener("error", () => { clear(lead).appendChild(icon()); }, { once: true });
        lead.appendChild(img);
      } else lead.appendChild(icon());
      const title = h("span.title", it.name), sub = h("span.sub"), bar = progress(0);
      const x = iconButton({ icon: "x", label: "Stop sending " + it.name, size: 16, onClick: () => cancel(it) });
      const again = iconButton({ icon: "refresh", label: "Send " + it.name + " again", size: 16, onClick: () => { it.state = "queued"; it.error = ""; it.tries = 0; emit(); pump(); } });
      const body = h("span.body", title, sub, bar);
      const el2 = h("div.row.file-row", lead, body, h("span.trail", x, again));
      r = { el: el2, lead, sub, bar, x, again };
      rowsById.set(it.id, r);
    }
    r.el.classList.toggle("done", it.state === "done");
    r.el.classList.toggle("failed", it.state === "failed");
    r.bar.hidden = it.state !== "sending";
    r.x.hidden = !(it.state === "sending" || it.state === "queued");
    r.again.hidden = !(it.state === "failed" && it.file);
    if (it.state === "sending") { const p = it.size ? it.sent / it.size : 0; r.bar.set(p); r.sub.textContent = formatBytes(it.sent) + " of " + formatBytes(it.size) + " · " + Math.round(p * 100) + "%"; }
    else if (it.state === "queued") r.sub.textContent = "Waiting · " + formatBytes(it.size);
    else if (it.state === "done") {
      r.sub.textContent = (it.saved && it.saved !== it.name ? "Saved as " + it.saved : "Saved in Downloads") + " · " + formatBytes(it.size);
      if (!it.thumb && !r.lead.querySelector(".ok")) { clear(r.lead).appendChild(svg("check", 19, 2.2)); }
    } else if (it.state === "failed") r.sub.textContent = it.error;
    return r.el;
  }

  function paint() {
    const going = Q.items.filter((x) => x.state === "sending" || x.state === "queued" || x.state === "failed");
    const done = Q.items.filter((x) => x.state === "done").reverse();
    clear(queueBox);
    if (going.length) {
      const busy = going.filter((x) => x.state !== "failed").length;
      queueBox.append(sectionLabel(busy ? "Sending " + busy + (busy === 1 ? " item" : " items") : "Didn't send",
        busy > 1 ? { label: "Stop all", onClick: () => { for (const it of going) if (it.state !== "failed") cancel(it); } } : null),
        h("div.group", ...going.map(itemRow)));
    }
    clear(doneBox);
    if (done.length) {
      doneBox.append(sectionLabel("Sent this time", { label: "Clear", onClick: () => {
        for (const it of done) { if (it.thumb) URL.revokeObjectURL(it.thumb); rowsById.delete(it.id); }
        Q.items = Q.items.filter((x) => x.state !== "done"); emit();
      } }), h("div.group", ...done.map(itemRow)));
    } else if (!going.length) {
      doneBox.appendChild(h("p.footer-note", "Files go straight to " + ctx.pc.name + " over your home Wi-Fi. Nothing is uploaded anywhere else."));
    }
  }
  let lastDone = Q.items.filter((x) => x.state === "done").length;
  const onChange = () => {
    paint();
    const d = Q.items.filter((x) => x.state === "done").length;
    if (d > lastDone && !Q.items.some((x) => x.state === "sending" || x.state === "queued")) toast(d - lastDone === 1 ? "Sent to " + ctx.pc.name : "Sent " + (d - lastDone) + " files to " + ctx.pc.name, "ok", { icon: "check" });
    if (!Q.items.some((x) => x.state === "sending" || x.state === "queued")) lastDone = d;
  };
  Q.listeners.add(onChange);
  paint();

  ctx.subscribe("system", (s) => {
    clear(lockNote);
    if (s && s.locked) lockNote.appendChild(h("div", { style: { marginBottom: "12px" } }, banner({ kind: "amber", icon: "lock", title: "PC is locked", body: "Files can be sent once it's unlocked at the PC." })));
  });
  return () => Q.listeners.delete(onChange);
}
