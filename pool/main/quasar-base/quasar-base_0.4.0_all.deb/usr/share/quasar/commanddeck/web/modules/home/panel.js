// Home: the PC at a glance — its name and connection, a "PC is locked" banner, what's playing,
// pinned apps, what's running, and the quick tiles other modules offer (module.json surfaces: "tile").
export function mount(el, ctx) {
  const { h, clear, svg, mark, appIcon, iconButton, sectionLabel, banner, toast } = ctx.ui;

  // ---- header ----
  const name = h("h1.pc-name");
  const pill = h("span.status-pill", h("i"), h("span"));
  const company = h("span.status-pill.company", { hidden: true }, h("i"), h("span"));
  el.appendChild(h("header.home-head", mark(46), h("div.pc", name, h("div", pill, company)),
    iconButton({ icon: "info", label: "About this phone and PC", onClick: () => ctx.navigate("about") })));
  const paintName = () => { name.textContent = ctx.pc.name; };
  paintName();
  const paintConn = (state) => {
    const ok = state === "ready";
    pill.classList.toggle("wait", !ok);
    pill.lastChild.textContent = ok ? "Connected" : state === "unreachable" ? "Can't reach it" : state === "ended" ? "Disconnected" : state === "reconnecting" ? "Reconnecting…" : "Connecting…";
  };
  paintConn(ctx.connected ? "ready" : "connecting");
  ctx.onConnection((s) => paintConn(s));

  // ---- locked ----
  const lockSlot = h("div", { style: { marginBottom: "12px" } });
  lockSlot.hidden = true;
  lockSlot.appendChild(banner({ kind: "amber", icon: "lock", title: "PC is locked",
    body: "Unlock it at the PC to open apps or control it. Music, volume and power still work." }));
  el.appendChild(lockSlot);

  // ---- now playing ----
  const npSlot = h("div");
  el.appendChild(npSlot);

  // ---- pinned apps ----
  const pinLabel = sectionLabel("Pinned", { label: "All apps", onClick: () => ctx.navigate("apps", {}, { tab: true }) });
  const pinStrip = h("div.strip", { role: "list", "aria-label": "Pinned apps" });
  el.append(pinLabel, pinStrip);

  // ---- running ----
  const runLabel = sectionLabel("Running", { label: "See all", onClick: () => ctx.navigate("running", {}, { tab: true }) });
  const runStrip = h("div.strip", { role: "list", "aria-label": "Running apps" });
  el.append(runLabel, runStrip);

  // ---- quick tiles from modules ----
  const tiles = h("div.tiles.home");
  el.append(sectionLabel("Quick"), tiles);
  ctx.tileModules().forEach((m, i) => {
    const slot = h("div.slot");
    if (m.tileWide) slot.classList.add("wide");
    slot.style.animationDelay = 40 * i + "ms";
    tiles.appendChild(slot);
    ctx.mountTile(m.id, slot);
  });

  // ---- data ----
  let apps = null, windows = null;
  const appById = (id) => (apps && apps.apps || []).find((a) => a.id === id);
  const launch = async (a) => {
    toast("Opening " + a.name + "…", "info", { icon: "grid", ms: 2200 });
    await ctx.run("launch", { id: a.id });
  };

  function paintPinned() {
    clear(pinStrip);
    const list = apps ? (apps.apps || []).filter((a) => a.pinned) : null;
    if (!list) { for (let i = 0; i < 5; i++) pinStrip.appendChild(h("div.strip-item", h("span.skel", { style: { width: "56px", height: "56px", borderRadius: "16px" } }), h("span.skel", { style: { width: "44px", height: "9px" } }))); return; }
    pinLabel.hidden = pinStrip.hidden = !list.length;
    list.forEach((a, i) => {
      const b = h("button.strip-item", { type: "button", role: "listitem", "aria-label": "Open " + a.name }, appIcon(a, 56), h("span.nm", a.name));
      b.style.animationDelay = Math.min(i, 8) * 35 + "ms";
      b.addEventListener("click", () => launch(a));
      pinStrip.appendChild(b);
    });
  }

  function paintRunning() {
    clear(runStrip);
    if (!windows) { for (let i = 0; i < 3; i++) runStrip.appendChild(h("div.strip-item", h("span.skel", { style: { width: "56px", height: "56px", borderRadius: "16px" } }))); return; }
    const groups = new Map();
    for (const w of windows.windows || []) {
      const k = w.app || w.title || String(w.wid);
      if (!groups.has(k)) groups.set(k, []);
      groups.get(k).push(w);
    }
    if (!groups.size) {
      runStrip.appendChild(h("div.muted", { style: { fontSize: "14px", padding: "6px 4px 2px" } }, "Nothing is open on " + ctx.pc.name + " right now."));
      return;
    }
    let i = 0;
    for (const [k, ws] of groups) {
      const a = appById(k) || {};
      const w0 = ws.find((w) => w.focused) || ws[0];
      const look = { icon: w0.icon || a.icon, glyph: w0.glyph || a.glyph, hue: w0.hue || a.hue, letter: w0.letter || a.letter, name: a.name || w0.title };
      const wrap = h("span.icon-wrap", appIcon(look, 56));
      if (ws.length > 1) wrap.appendChild(h("span.badge", String(ws.length)));
      const b = h("button.strip-item" + (ws.some((w) => w.focused) ? ".focused" : ""), { type: "button", role: "listitem", "aria-label": look.name + (ws.length > 1 ? ", " + ws.length + " windows" : "") },
        wrap, h("span.nm", look.name || "Window"));
      b.style.animationDelay = Math.min(i++, 8) * 35 + "ms";
      b.addEventListener("click", async () => {
        if (ws.length > 1) { ctx.navigate("running", { app: k }, { tab: true }); return; }
        await ctx.run("focus", { wid: w0.wid });
      });
      runStrip.appendChild(b);
    }
  }

  function paintNowPlaying(media) {
    clear(npSlot);
    const p = media && media.player;
    if (!p || !(p.title || p.name)) return;
    const art = h("span.art", svg("music", 22));
    artSrc(p.art, ctx).then((src) => {
      if (!src) return;
      const img = h("img", { alt: "", decoding: "async" });
      img.addEventListener("load", () => { clear(art); art.appendChild(img); }, { once: true });
      img.src = src;
    });
    const play = h("button.icon-btn.playbtn", { type: "button", "aria-label": p.playing ? "Pause" : "Play" }, svg(p.playing ? "pause" : "play", 20, 2.2));
    play.addEventListener("click", (e) => { e.stopPropagation(); ctx.run("media", { action: "playPause" }); });
    if (p.canPlay === false) play.disabled = true;
    const card = h("div.card.tappable.np", { role: "button", tabindex: "0", "aria-label": "Now playing: " + (p.title || "") },
      art, h("div.meta", h("div.t1", p.title || p.name), h("div.t2", [p.artist, p.album].filter(Boolean).join(" · ") || p.name || "")), play);
    card.addEventListener("click", () => ctx.navigate("media"));
    card.addEventListener("keydown", (e) => { if (e.key === "Enter") ctx.navigate("media"); });
    npSlot.append(sectionLabel("Now playing"), card);
  }

  paintPinned();
  paintRunning();
  ctx.subscribe("apps", (d) => { apps = d || { apps: [] }; paintPinned(); paintRunning(); paintCompany(); });
  ctx.subscribe("windows", (d) => { windows = d || { windows: [] }; paintRunning(); });
  ctx.subscribe("media", paintNowPlaying);
  ctx.subscribe("system", (s) => {
    lockSlot.hidden = !(s && s.locked);
    paintName();
    paintCompany(s);
  });
  function paintCompany(s) {
    const desk = (apps && apps.desk) || (s && s.desk) || (ctx.state("system") || {}).desk;
    const c = desk && (desk.company || (typeof desk === "string" ? desk : null));
    company.hidden = !c;
    if (c) company.lastChild.textContent = typeof c === "string" ? c : desk.name || "Company";
  }
}

/** Album art → Promise of an image URL or null: an http(s) URL as the player gave it, or `art:<key>` for
 *  local cover art, which comes over the control socket (ctx.art). */
export function artSrc(art, ctx) {
  if (!art || typeof art !== "string") return Promise.resolve(null);
  if (/^https?:\/\//i.test(art)) return Promise.resolve(art);
  if (art.startsWith("art:") && art.length > 4) return ctx.art(art.slice(4));
  return Promise.resolve(null);
}
