// Trackpad: the phone as a touchpad and keyboard for the PC, without the picture (a PC on a TV).
// Slide = move, tap = click, two-finger tap = right-click, hold then slide = drag, two fingers or the
// strip on the right = scroll. The buttons at the bottom press and hold like a laptop's.
import { ScreenLink, Gestures } from "/app/remote.js";
import { KeyInput } from "/app/keys.js";

const get = (k, d) => { try { const v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch { return d; } };
const put = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* */ } };

export function mount(el, ctx) {
  const { h, clear, svg, iconButton, button, sheet, fillSlider, banner, toast, vibrate } = ctx.ui;
  const pc = ctx.pc.name;
  let locked = !!(ctx.state("system") || {}).locked, inputOk = true, lastWarn = 0, stoppedNow = false;

  const status = h("span", "Connecting…");
  const kbBtn = iconButton({ icon: "keyboard", label: "Keyboard", onClick: () => (keys.kbOpen ? keys.hide() : keys.open()) });
  const keysBtn = iconButton({ icon: "keys", label: "Keys: Esc, Ctrl, arrows…", onClick: () => keys.toggleBar() });
  const head = h("header.tp-head",
    iconButton({ icon: "back", label: "Back", onClick: () => ctx.back() }),
    h("div.tt", h("b", "Trackpad"), status), kbBtn, keysBtn,
    iconButton({ icon: "sliders", label: "Pointer speed", onClick: speedSheet }));
  const note = h("div");
  const hint = h("div.pad-hint", svg("trackpad", 34, 1.5), h("b", "Slide to move the pointer"), h("span", "Tap to click · two fingers to scroll or right-click"));
  const strip = h("div.scroll-strip", { "aria-label": "Scroll" });
  const fx = h("div", { style: { position: "absolute", inset: "0", pointerEvents: "none" } });
  const pad = h("div.pad", { role: "application", "aria-label": "Trackpad for " + pc }, hint, fx, strip);
  const left = h("button.mbtn", { type: "button", "aria-label": "Left button" }, "Left");
  const right = h("button.mbtn", { type: "button", "aria-label": "Right button" }, "Right");
  const tp = h("div.tp", head, note, pad, h("div.tp-buttons", left, right));
  el.appendChild(tp);

  // ---- the socket (input only: no picture) ----
  const link = new ScreenLink(ctx, { mode: "trackpad", width: () => 640 });
  link.addEventListener("status", (e) => {
    const { state, reason } = e.detail;
    stoppedNow = state === "stopped";
    status.textContent = state === "open" ? (locked ? "Locked: control is off" : pc)
      : state === "reconnecting" ? "Reconnecting…" : state === "connecting" ? "Connecting…" : state === "stopped" ? "Stopped" : status.textContent;
    pad.classList.toggle("active", state === "open" && !locked);
    if (state === "stopped") showStopped(reason);
    else if (state === "open") paintNote();
  });
  link.addEventListener("hello", (e) => { inputOk = e.detail.input !== false; paintNote(); });
  link.addEventListener("engine-error", (e) => {
    const m = e.detail;
    clear(note).appendChild(banner({ kind: "danger", icon: "alert", title: m.code === "no-virtual-pointer" ? pc + " can't be controlled from a phone" : "Control ran into a problem", body: m.error || "" }));
  });
  link.addEventListener("locked", (e) => { locked = e.detail; paintNote(); });

  function showStopped(reason) {
    const t = {
      "stopped-by-pc": [pc + " stopped phone control", "Someone at the PC stopped it.", true],
      off: ["Control from a phone is turned off on " + pc, "It can be turned on in Settings › Command Deck.", false],
      busy: ["Too many phones are connected", "Try again when one of them stops.", true],
      missing: ["Phone control isn't installed on " + pc, "", false],
      unsupported: [pc + " can't be controlled from a phone", "Its desktop doesn't accept pointer control from apps.", false],
    }[reason] || ["Control stopped", "You can start it again.", true];
    clear(note).appendChild(h("div.banner.danger", h("span.bi", svg("alert", 20)), h("div.grow", h("div.bt", t[0]), t[1] ? h("div.bs", t[1]) : null,
      t[2] ? h("div", { style: { marginTop: "10px" } }, button({ label: "Start again", icon: "refresh", small: true, kind: "primary", onClick: () => { clear(note); link.restart(); } })) : null)));
  }
  function paintNote() {
    if (stoppedNow) return;
    clear(note);
    if (locked) note.appendChild(banner({ kind: "amber", icon: "lock", title: "PC is locked", body: "Control is off until it's unlocked at the PC." }));
    else if (!inputOk) note.appendChild(banner({ kind: "accent", icon: "info", title: "View only", body: pc + " doesn't accept control from a phone." }));
    if (link.state === "open") status.textContent = locked ? "Locked: control is off" : pc;
    pad.classList.toggle("active", link.state === "open" && !locked);
  }

  function send(cmd) {
    if (locked || !inputOk) {
      const now = Date.now();
      if (now - lastWarn > 4000) { lastWarn = now; toast(locked ? "Control is off while " + pc + " is locked" : pc + " doesn't accept control from a phone", "warn", { icon: "lock" }); }
      return false;
    }
    return link.input(cmd);
  }

  // ---- the pad ----
  const gestures = new Gestures(pad, {
    mode: () => "trackpad", send, viewport: null, fx,
    speed: () => get("deck.tpSpeed", 1),
    onActivity: () => hint.classList.add("gone"),
  });
  // the scroll strip: one finger up and down
  let sid = null, sy = 0, acc = 0;
  strip.addEventListener("pointerdown", (e) => { e.stopPropagation(); sid = e.pointerId; sy = e.clientY; acc = 0; strip.setPointerCapture(sid); strip.classList.add("active"); });
  strip.addEventListener("pointermove", (e) => {
    if (e.pointerId !== sid) return;
    e.stopPropagation();
    acc += -(e.clientY - sy) / 30;
    sy = e.clientY;
    const d = Math.round(acc * 100) / 100;
    if (Math.abs(d) >= 0.2) { send({ t: "scroll", dx: 0, dy: d }); acc -= d; }
  });
  const sEnd = (e) => { if (e.pointerId === sid) { sid = null; strip.classList.remove("active"); } };
  strip.addEventListener("pointerup", sEnd);
  strip.addEventListener("pointercancel", sEnd);

  // ---- the buttons: press and hold ----
  for (const [b, name] of [[left, "left"], [right, "right"]]) {
    let held = null;
    b.addEventListener("pointerdown", (e) => {
      e.preventDefault();
      held = e.pointerId;
      b.setPointerCapture(held);
      b.classList.add("down");
      vibrate(6);
      send({ t: "btn", b: name, down: true });
    });
    const up = (e) => {
      if (e.pointerId !== held) return;
      held = null;
      b.classList.remove("down");
      link.input({ t: "btn", b: name, down: false });
    };
    b.addEventListener("pointerup", up);
    b.addEventListener("pointercancel", up);
    b.addEventListener("contextmenu", (e) => e.preventDefault());
    b.addEventListener("click", (e) => { if (e.detail === 0) { send({ t: "btn", b: name, down: true }); send({ t: "btn", b: name, down: false }); } });
  }

  // ---- keyboard ----
  const keys = new KeyInput({ send, host: tp, onChange: ({ keyboard, bar }) => {
    kbBtn.classList.toggle("on", keyboard);
    keysBtn.classList.toggle("on", bar && !keyboard);
    tp.classList.toggle("kb-open", bar);
    fitKeyboard();
  } });
  // Keep the pad and its buttons above the soft keyboard and the key bar.
  const vv = window.visualViewport;
  let kbRaf = 0;
  function fitKeyboard() {
    cancelAnimationFrame(kbRaf);
    kbRaf = requestAnimationFrame(() => {
      const on = keys.visible;
      tp.style.top = on && vv ? vv.offsetTop + "px" : "";
      tp.style.bottom = on && vv ? "auto" : "";
      tp.style.height = on && vv ? vv.height + "px" : "";
      tp.style.paddingBottom = on ? (keys.bar.offsetHeight + 10) + "px" : "";
    });
  }
  if (vv) { vv.addEventListener("resize", fitKeyboard); vv.addEventListener("scroll", fitKeyboard); }

  function speedSheet() {
    const v = get("deck.tpSpeed", 1);
    const s = fillSlider({ value: Math.round(((v - 0.4) / 2.1) * 100), icon: "mouse", label: "Pointer speed", showValue: false,
      onInput: (p) => put("deck.tpSpeed", +(0.4 + (p / 100) * 2.1).toFixed(2)) });
    sheet({ title: "Pointer speed", body: h("div", s, h("div", { style: { display: "flex", justifyContent: "space-between", fontSize: "12.5px", color: "var(--dim)", margin: "8px 4px 6px" } }, h("span", "Slower"), h("span", "Faster")),
      h("p.muted", { style: { fontSize: "13px", margin: "10px 4px 6px" } }, "Quick slides move further than slow ones, like a laptop's touchpad.")) });
  }

  let hiddenT = 0;
  ctx.onVisibility((visible) => {
    clearTimeout(hiddenT);
    if (!visible) { link.input({ t: "release" }); hiddenT = setTimeout(() => link.pause(), 30000); }
    else if (link.state === "paused") link.connect();
  });
  ctx.subscribe("system", (s) => { const l = !!(s && s.locked); if (l !== locked) { locked = l; paintNote(); } });
  link.connect();

  return () => {
    clearTimeout(hiddenT);
    cancelAnimationFrame(kbRaf);
    if (vv) { vv.removeEventListener("resize", fitKeyboard); vv.removeEventListener("scroll", fitKeyboard); }
    gestures.destroy();
    keys.destroy();
    link.close();
  };
}

/** Home tile. */
export function tile(el, ctx) {
  const t = ctx.ui.tile({ icon: "trackpad", label: "Trackpad", sub: "Mouse & keys", onClick: () => ctx.navigate("trackpad") });
  el.appendChild(t);
  const paint = () => { const ok = ctx.available("trackpad"); t.set({ sub: ok ? "Mouse & keys" : "Turned off", disabled: !ok }); };
  paint();
  ctx.onCaps(paint);
}
