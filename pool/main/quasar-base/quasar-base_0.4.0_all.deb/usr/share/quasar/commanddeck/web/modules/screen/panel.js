// Screen: the PC's screen on the phone, and control of it.
//   Touch mode: tap = click there, tap twice = double-click, hold = right-click, hold then drag = drag,
//   swipe or two fingers = scroll, pinch = zoom, swipe when zoomed = move around.
//   Trackpad mode: the phone is a touchpad for the PC's own pointer.
// A floating toolbar (keyboard, keys, mode, fit, more) tucks itself away; the handle brings it back.
import { ScreenLink, FrameRenderer, Viewport, Gestures } from "/app/remote.js";
import { KeyInput } from "/app/keys.js";

const QUALITY = [{ id: 85, label: "Sharp" }, { id: 70, label: "Balanced" }, { id: 50, label: "Fast" }];
const get = (k, d) => { try { const v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch { return d; } };
const put = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* private mode */ } };

const STOPPED = {
  "stopped-by-pc": (pc) => [pc + " stopped screen sharing", "Someone at the PC stopped it.", "Start again"],
  off: (pc) => ["Screen sharing is turned off on " + pc, "It can be turned on in Settings › Command Deck on the PC.", null],
  busy: () => ["Too many phones are watching", "Three phones are already looking at this screen. Try again when one of them stops.", "Try again"],
  missing: (pc) => ["Screen sharing isn't installed on " + pc, "It comes with Quasar's Command Deck; an update may bring it back.", null],
  unsupported: (pc) => [pc + " can't share its screen", "Its desktop doesn't let apps capture the screen or move the pointer.", null],
  "no-display": (pc) => [pc + " has no screen to show", "Its display may be off or asleep. Wake it at the PC, then try again.", "Try again"],
  denied: (pc) => ["This phone isn't allowed in", "Connect it to " + pc + " again from Home.", null],
};
const ENGINE = {
  "no-screencopy": (pc) => [pc + " can't show its screen", "Its desktop doesn't offer screen capture. You can still use the trackpad."],
  "no-virtual-pointer": (pc) => [pc + " can't be controlled from a phone", "Its desktop doesn't accept pointer control from apps."],
  "no-virtual-keyboard": (pc) => ["Typing isn't available", "The desktop on " + pc + " doesn't accept a keyboard from apps."],
};

export function mount(el, ctx) {
  const { h, clear, svg, iconButton, button, sheet, segmented, row, group, sectionLabel, banner, spinner, toast, debounce } = ctx.ui;
  const pc = ctx.pc.name;
  let mode = get("deck.screenMode", "touch");
  let locked = !!(ctx.state("system") || {}).locked;
  let hello = null, inputOk = true, gotFrame = false, lastWarn = 0, ended = false;

  // ---- structure ----
  const canvas = h("canvas", { "aria-label": "The screen of " + pc, role: "img" });
  const layer = h("div.layer.empty", canvas);
  const stage = h("div.stage", layer);
  const fx = h("div", { style: { position: "absolute", inset: "0", pointerEvents: "none", zIndex: "5" } });
  const topSlot = h("div");
  const stateBox = h("div.state", { role: "status" });
  stateBox.hidden = true;
  const remote = h("div.remote", stage, fx, topSlot, stateBox);
  el.appendChild(remote);

  // ---- view + drawing ----
  const vp = new Viewport(stage, layer);
  const dpr = () => Math.min(3, window.devicePixelRatio || 1);
  const widthFn = () => Math.min(1920, Math.max(320, Math.round((vp.shownWidth || window.innerWidth) * dpr())));
  let refreshT = 0;
  const renderer = new FrameRenderer(canvas, {
    onDrawn: (seq, bad) => {
      link.ack(seq);
      if (!gotFrame) { gotFrame = true; layer.classList.remove("empty"); hideState(); }
      if (bad && !refreshT) refreshT = setTimeout(() => { refreshT = 0; link.refresh(); }, 800);
    },
  });

  // ---- the socket ----
  const link = new ScreenLink(ctx, { mode: "screen", width: widthFn, output: get("deck.output." + ctx.pc.id, null) || undefined, quality: get("deck.quality", 70) });
  link.addEventListener("status", (e) => {
    const { state, reason, message } = e.detail;
    if (state === "connecting") showState({ busy: true, title: "Connecting to the screen…" });
    else if (state === "reconnecting") showState({ busy: true, title: "Reconnecting…", body: "The connection to " + pc + " dropped for a moment.", soft: true });
    else if (state === "open" && !gotFrame) showState({ busy: true, title: "Starting…" });
    else if (state === "stopped") stopped(reason, message);
  });
  link.addEventListener("hello", (e) => {
    hello = e.detail;
    vp.setSource(hello.srcW || hello.w, hello.srcH || hello.h);      // the canvas takes its size from the frames
    inputOk = hello.input !== false;
    paintBanner();
    if (hello.capture === false) {
      showState({ title: pc + " can't show its screen here", body: "You can still move its pointer and type with the trackpad.",
        actions: [button({ label: "Use the trackpad", icon: "trackpad", kind: "primary", onClick: () => ctx.navigate("trackpad", {}, { replace: true }) })] });
    }
  });
  link.addEventListener("frame", (e) => renderer.push(e.detail));
  link.addEventListener("engine-error", (e) => {
    const m = e.detail, t = ENGINE[m.code];
    const [title, body] = t ? t(pc) : ["Screen sharing ran into a problem", m.error || "Try again in a moment."];
    if (m.code === "no-virtual-keyboard") { toast(body, "warn"); return; }
    const first = m.code === "no-screencopy"
      ? button({ label: "Use the trackpad", icon: "trackpad", kind: "primary", onClick: () => ctx.navigate("trackpad", {}, { replace: true }) })
      : button({ label: "Try again", icon: "refresh", kind: "primary", onClick: restart });
    showState({ title, body, actions: [first, backBtn()] });
  });
  link.addEventListener("locked", (e) => { if (e.detail !== locked) { locked = e.detail; paintBanner(); } });

  function restart() { gotFrame = false; ended = false; layer.classList.add("empty"); link.restart(); }
  function backBtn() { return button({ label: "Close", kind: "ghost", onClick: () => ctx.back() }); }
  function stopped(reason, message) {
    ended = true;
    const t = (STOPPED[reason] || ((p) => ["Screen sharing ended", "You can start it again whenever you like.", "Start again"]))(pc);
    const actions = [];
    if (t[2]) actions.push(button({ label: t[2], icon: "refresh", kind: "primary", onClick: restart }));
    actions.push(button({ label: t[2] ? "Close" : "Back", kind: t[2] ? "ghost" : "primary", onClick: () => ctx.back() }));
    showState({ title: t[0], body: message && reason === "missing" ? message : t[1], actions });
  }
  function showState({ busy, title, body, actions = [], soft }) {
    clear(stateBox);
    stateBox.hidden = false;
    stateBox.style.background = soft && gotFrame ? "rgba(5,6,10,.55)" : "";
    if (busy) stateBox.appendChild(spinner(true));
    stateBox.append(h("div.st", title), body ? h("div.sb", body) : "");
    if (actions.length) stateBox.appendChild(h("div.sa", ...actions));
  }
  function hideState() { stateBox.hidden = true; }

  // ---- banners: locked, view only, the first-time hint ----
  function paintBanner() {
    clear(topSlot);
    if (locked) topSlot.appendChild(banner({ kind: "amber top-banner", icon: "lock", title: "PC is locked",
      body: "You can see the lock screen, but control is off until it's unlocked at the PC." }));
    else if (hello && hello.input === false) topSlot.appendChild(banner({ kind: "accent top-banner", icon: "info", title: "View only", body: pc + " doesn't accept control from a phone." }));
    else if (!get("deck.screenHint", false)) topSlot.appendChild(hintCard());
  }
  function hintCard() {
    const close = () => { put("deck.screenHint", true); paintBanner(); };
    return h("div.hint-card", h("div.ht", "Tap where you want to click"),
      h("ul", ...helpItems("touch").slice(0, 5).map(([k, v]) => h("li", h("b", k), v))),
      button({ label: "Got it", kind: "primary", small: true, onClick: close }));
  }
  function helpItems(m) {
    return m === "touch"
      ? [["Tap", "Click"], ["Tap twice", "Double-click"], ["Hold", "Right-click"], ["Hold, then drag", "Drag"], ["Two fingers", "Scroll, or pinch to zoom"],
        ["Swipe", "Scroll (move around when zoomed)"], ["Two-finger tap", "Right-click"]]
      : [["Slide one finger", "Move the pointer"], ["Tap", "Click"], ["Two-finger tap", "Right-click"], ["Hold, then slide", "Drag"],
        ["Two fingers", "Scroll"], ["Three-finger tap", "Middle-click"], ["Pinch", "Zoom the picture"]];
  }

  // ---- input ----
  function send(cmd) {
    if (locked || !inputOk) {
      const now = Date.now();
      if (now - lastWarn > 4000) { lastWarn = now; toast(locked ? "Control is off while " + pc + " is locked" : pc + " doesn't accept control from a phone", "warn", { icon: "lock" }); }
      return false;
    }
    return link.input(cmd);
  }
  const requestView = debounce(() => link.view(widthFn()), 350);
  const gestures = new Gestures(stage, {
    mode: () => mode, send, viewport: vp, fx,
    speed: () => get("deck.tpSpeed", 1),
    onActivity: () => { if (topSlot.querySelector(".hint-card")) { put("deck.screenHint", true); paintBanner(); } },
    onView: requestView,
  });

  // ---- keyboard ----
  const keys = new KeyInput({ send, host: remote, onChange: ({ keyboard, bar }) => {
    kbBtn.classList.toggle("on", keyboard);
    keysBtn.classList.toggle("on", bar && !keyboard);
    if (bar) tuck(true); else showBar();
    fitKeyboard();
  } });
  // With the soft keyboard up, show the PC's screen in what's left above it and the key bar.
  const vv = window.visualViewport;
  let kbRaf = 0;
  function fitKeyboard() {
    cancelAnimationFrame(kbRaf);
    kbRaf = requestAnimationFrame(() => {
      if (keys.visible && vv) {
        remote.style.top = vv.offsetTop + "px";
        remote.style.bottom = "auto";
        remote.style.height = vv.height + "px";
        stage.style.bottom = keys.bar.offsetHeight + "px";
      } else {
        remote.style.top = remote.style.bottom = remote.style.height = stage.style.bottom = "";
      }
      vp.layout();
    });
  }
  if (vv) { vv.addEventListener("resize", fitKeyboard); vv.addEventListener("scroll", fitKeyboard); }

  // ---- toolbar ----
  const kbBtn = iconButton({ icon: "keyboard", label: "Keyboard", onClick: () => (keys.kbOpen ? keys.hide() : keys.open()) });
  const keysBtn = iconButton({ icon: "keys", label: "Keys: Esc, Ctrl, arrows…", onClick: () => keys.toggleBar() });
  const touchBtn = h("button", { type: "button", "aria-label": "Touch: tap where you want to click" }, svg("touch", 18, 2));
  const padBtn = h("button", { type: "button", "aria-label": "Trackpad: move the pointer like a touchpad" }, svg("trackpad", 18, 2));
  const modeBox = h("div.mode", { role: "group", "aria-label": "How touches work" }, touchBtn, padBtn);
  const fitBtn = iconButton({ icon: "fit", label: "Fit the whole screen", onClick: () => { vp.fit(); requestView(); } });
  fitBtn.hidden = true;
  const fsBtn = iconButton({ icon: "expand", label: "Full screen", onClick: () => toggleFullscreen() });
  fsBtn.hidden = !document.fullscreenEnabled;
  const moreBtn = iconButton({ icon: "more", label: "More", onClick: moreSheet });
  const closeBtn = iconButton({ icon: "x", label: "Close the screen", onClick: () => ctx.back() });
  const toolbar = h("div.toolbar", { role: "toolbar", "aria-label": "Screen controls" }, closeBtn, h("span.sep"), kbBtn, keysBtn, modeBox, fitBtn, fsBtn, moreBtn);
  const grip = h("button.grip", { type: "button", "aria-label": "Show controls" }, h("i"));
  remote.append(h("div.toolbar-wrap", toolbar), grip);
  const paintMode = () => {
    touchBtn.setAttribute("aria-pressed", String(mode === "touch"));
    padBtn.setAttribute("aria-pressed", String(mode === "trackpad"));
  };
  const setMode = (m) => {
    if (m === mode) return;
    mode = m; put("deck.screenMode", m); paintMode();
    link.input({ t: "release" });
    toast(m === "touch" ? "Touch: tap where you want to click" : "Trackpad: slide to move the pointer, tap to click", "info", { icon: m === "touch" ? "touch" : "trackpad", ms: 2600 });
  };
  touchBtn.addEventListener("click", () => setMode("touch"));
  padBtn.addEventListener("click", () => setMode("trackpad"));
  paintMode();

  let tuckT = 0;
  function tuck(now) {
    clearTimeout(tuckT);
    if (now) { toolbar.classList.add("tucked"); grip.classList.toggle("show", !keys.visible); return; }
    tuckT = setTimeout(() => { if (!keys.visible) { toolbar.classList.add("tucked"); grip.classList.add("show"); } }, 4500);
  }
  function showBar() { toolbar.classList.remove("tucked"); grip.classList.remove("show"); tuck(false); }
  grip.addEventListener("click", showBar);
  toolbar.addEventListener("pointerdown", () => tuck(false));
  vp.onChange = () => { fitBtn.hidden = !vp.zoomed; };
  tuck(false);

  // ---- more ----
  function moreSheet() {
    clearTimeout(tuckT);
    const body = h("div");
    const outs = (hello && hello.outputs) || [];
    if (outs.length > 1) {
      body.appendChild(sectionLabel("Display"));
      body.appendChild(group(...outs.map((o) => row({
        lead: "monitor", title: o.description || o.name, sub: o.name + " · " + o.w + " × " + o.h,
        trail: (hello.output === o.name) ? svg("check", 20, 2.2) : null,
        onClick: () => { put("deck.output." + ctx.pc.id, o.name); link.output(o.name); s.close(); toast("Showing " + (o.description || o.name), "info", { icon: "monitor" }); },
      }))));
    }
    body.appendChild(sectionLabel("Picture"));
    body.appendChild(segmented({ options: QUALITY, value: link.opts.quality || 70, label: "Picture quality", onChange: (q) => { put("deck.quality", q); link.quality(q); } }));
    body.appendChild(h("p.muted", { style: { fontSize: "13px", margin: "8px 4px 0" } }, "Sharp looks best. Fast keeps up better on slow Wi-Fi."));
    const rows = [];
    if (vp.zoomed) rows.push(row({ lead: "fit", title: "Fit the whole screen", onClick: () => { s.close(); vp.fit(); requestView(); } }));
    if (document.fullscreenEnabled) rows.push(row({ lead: document.fullscreenElement ? "shrink" : "expand", title: document.fullscreenElement ? "Leave full screen" : "Full screen", sub: document.fullscreenElement ? "" : "Turns sideways for a wide screen", onClick: () => { s.close(); toggleFullscreen(); } }));
    rows.push(row({ lead: "refresh", title: "Refresh the picture", onClick: () => { s.close(); link.refresh(); } }));
    rows.push(row({ lead: "help", title: "How touches work", onClick: () => { s.close(); helpSheet(); } }));
    body.append(h("div", { style: { height: "14px" } }), group(...rows), h("div", { style: { height: "6px" } }));
    const s = sheet({ title: "Screen", body, onClose: () => tuck(false) });
  }
  function helpSheet() {
    const list = (m) => h("ul.help-list", ...helpItems(m).map(([k, v]) => h("li", h("b", k), h("span", v))));
    sheet({ title: "How touches work", body: h("div", sectionLabel("Touch"), list("touch"), sectionLabel("Trackpad"), list("trackpad"), h("div", { style: { height: "8px" } })) });
  }

  // ---- full screen + rotation ----
  let wentFull = false;
  async function toggleFullscreen() {
    try {
      if (document.fullscreenElement) { await document.exitFullscreen(); return; }
      await document.documentElement.requestFullscreen({ navigationUI: "hide" });
      wentFull = true;
      const wide = hello ? (hello.srcW || hello.w) > (hello.srcH || hello.h) : true;
      if (wide && screen.orientation && screen.orientation.lock) screen.orientation.lock("landscape").catch(() => {});
    } catch { toast("Full screen isn't available here", "warn"); }
  }
  const onFs = () => {
    fsBtn.setIcon(document.fullscreenElement ? "shrink" : "expand");
    fsBtn.setAttribute("aria-label", document.fullscreenElement ? "Leave full screen" : "Full screen");
    if (!document.fullscreenElement && screen.orientation && screen.orientation.unlock) try { screen.orientation.unlock(); } catch { /* */ }
    setTimeout(() => { vp.layout(); requestView(); }, 120);
  };
  document.addEventListener("fullscreenchange", onFs);

  // ---- size, visibility, lock ----
  const onResize = () => { vp.layout(); requestView(); };
  addEventListener("resize", onResize);
  let hiddenT = 0;
  ctx.onVisibility((visible) => {
    clearTimeout(hiddenT);
    if (!visible) { link.input({ t: "release" }); hiddenT = setTimeout(() => link.pause(), 30000); }
    else if (link.state === "paused" && !ended) { gotFrame = false; link.connect(); }
  });
  ctx.subscribe("system", (s) => { const l = !!(s && s.locked); if (l !== locked) { locked = l; paintBanner(); } });

  requestAnimationFrame(() => { vp.layout(true); paintBanner(); link.connect(); });

  return () => {
    clearTimeout(tuckT); clearTimeout(hiddenT); clearTimeout(refreshT);
    requestView.cancel && requestView.cancel();
    removeEventListener("resize", onResize);
    if (vv) { vv.removeEventListener("resize", fitKeyboard); vv.removeEventListener("scroll", fitKeyboard); }
    cancelAnimationFrame(kbRaf);
    document.removeEventListener("fullscreenchange", onFs);
    if (wentFull && document.fullscreenElement) document.exitFullscreen().catch(() => {});
    gestures.destroy();
    keys.destroy();
    renderer.stop();
    link.close();
  };
}

/** Home tile. */
export function tile(el, ctx) {
  const t = ctx.ui.tile({ icon: "monitor", label: "Screen", sub: "View & control", onClick: () => ctx.navigate("screen", {}, { tab: true }) });
  el.appendChild(t);
  const paint = () => { const ok = ctx.available("screen"); t.set({ sub: ok ? "View & control" : "Turned off", disabled: !ok }); };
  paint();
  ctx.onCaps(paint);
}
