// Power: lock, sleep, sign out, restart, shut down. Everything but Lock asks first.
const ACTIONS = [
  { id: "lock", label: "Lock", sub: "Locks the screen now", icon: "lock", hue: "#7AE7FF", wide: true, done: "Locked" },
  { id: "sleep", label: "Sleep", sub: "Wake it at the PC", icon: "moon", hue: "#B9A4FF", done: "Going to sleep…",
    ask: (pc) => ({ title: "Put " + pc + " to sleep?", body: "You'll need to wake it at the PC. Command Deck reconnects once it's awake.", action: "Sleep" }) },
  { id: "logout", label: "Sign out", sub: "Closes your apps", icon: "logout", hue: "#C9CFDC", done: "Signing out…",
    ask: (pc) => ({ title: "Sign out of " + pc + "?", body: "Your apps close, and anything you haven't saved may be lost.", action: "Sign out", danger: true }) },
  { id: "reboot", label: "Restart", sub: "Back in a minute", icon: "cycle", hue: "#FFB86B", done: "Restarting…",
    ask: (pc) => ({ title: "Restart " + pc + "?", body: "Your apps close, and anything you haven't saved may be lost. Command Deck reconnects after it starts again.", action: "Restart", danger: true }) },
  { id: "poweroff", label: "Shut down", sub: "Turn it on at the PC", icon: "power", hue: "#FF9B9B", done: "Shutting down…",
    ask: (pc) => ({ title: "Shut down " + pc + "?", body: "Your apps close, and anything you haven't saved may be lost. You'll need to turn it on at the PC.", action: "Shut down", danger: true }) },
];

async function doPower(ctx, a) {
  if (a.ask) {
    const q = a.ask(ctx.pc.name);
    if (!(await ctx.confirm({ ...q, icon: a.icon }))) return false;
  }
  const ok = await ctx.run("power", { action: a.id });
  if (ok) ctx.toast(a.done, "ok", { icon: a.icon });
  return !!ok;
}

export function mount(el, ctx) {
  const { h, svg, banner, clear } = ctx.ui;
  el.appendChild(h("header.page-head", h("div.grow", h("h1.page-title", "Power"), h("p.page-sub", ctx.pc.name))));
  const lockNote = h("div", { style: { marginBottom: "12px" } });
  const grid = h("div.power-grid");
  el.append(lockNote, grid);
  const lockBtn = {};
  ACTIONS.forEach((a, i) => {
    const chip = h("span.chip", svg(a.icon, 22));
    chip.style.color = a.hue;
    const lbl = h("span.lbl", a.label), sub = h("span.sub", a.sub);
    const b = h("button.power-btn" + (a.wide ? ".wide" : ""), { type: "button" }, chip, h("span", lbl, h("br"), sub));
    b.style.animationDelay = i * 45 + "ms";
    b.addEventListener("click", () => doPower(ctx, a));
    if (a.id === "lock") Object.assign(lockBtn, { b, lbl, sub });
    grid.appendChild(b);
  });
  el.appendChild(h("p.footer-note", "Sleep, restart and shut down work like the power menu on the PC: apps that have unsaved work may ask first, on the PC."));
  ctx.subscribe("system", (s) => {
    const locked = !!(s && s.locked);
    clear(lockNote);
    if (locked) lockNote.appendChild(banner({ kind: "amber", icon: "lock", title: "PC is locked", body: "Power still works while it's locked." }));
    lockBtn.lbl.textContent = locked ? "Locked" : "Lock";
    lockBtn.sub.textContent = locked ? "Unlock it at the PC" : "Locks the screen now";
    lockBtn.b.disabled = locked;
  });
}

/** Home tile: Lock. */
export function tile(el, ctx) {
  const t = ctx.ui.tile({ icon: "lock", label: "Lock", sub: "Lock it now", onClick: () => doPower(ctx, ACTIONS[0]) });
  el.appendChild(t);
  ctx.subscribe("system", (s) => {
    const locked = !!(s && s.locked);
    t.set({ label: locked ? "Locked" : "Lock", sub: locked ? "At the PC" : "Lock it now", on: locked, disabled: locked });
  });
}
