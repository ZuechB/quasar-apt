// The control connection to deckd (PROTOCOL.md §1, GET /ws): sign-in with the key made at pairing, then a
// sealed socket (app/seal.js) for request/response calls, topic subscriptions that survive reconnects, a
// 30 s ping (deckd drops sockets silent for 75 s), backoff reconnects (0.5 s → 5 s), and closing while the
// page is hidden for more than 30 s.
import { b64u, shared, sessionKey, proof, SealedSocket } from "./seal.js";

export function wsUrl(path) {
  return (location.protocol === "https:" ? "wss://" : "ws://") + location.host + path;
}

// K for a device record (one X25519 multiplication; kept for the page's lifetime).
const keys = new WeakMap();
function deviceKey(device) {
  let k = keys.get(device);
  if (!k) { k = shared(device.secret, device.pcPub); if (k) keys.set(device, k); }
  return k;
}

/** Open a socket and sign in: hello → auth (text) → the first sealed message, `ready`. Resolves
 *  {ws, ready}: ws is a SealedSocket (send/close/readyState/bufferedAmount like a WebSocket). Rejects with
 *  {code: "denied", reason} or {code: "closed" | "timeout"}. After `ready`, every message goes to
 *  onMessage({data}) and the close to onClose(event). */
export function authSocket(path, { pcId, device, onMessage, onClose, timeout = 9000 }) {
  return new Promise((resolve, reject) => {
    let ws, sealed = null, stage = "hello", done = false;
    const fail = (code, reason) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      try { ws.close(); } catch { /* already */ }
      reject(Object.assign(new Error(code), { code, reason }));
    };
    try { ws = new WebSocket(wsUrl(path)); } catch { fail("closed"); return; }
    ws.binaryType = "arraybuffer";
    const timer = setTimeout(() => fail("timeout"), timeout);
    ws.onmessage = (ev) => {
      if (done) return;
      if (typeof ev.data === "string") {
        let m;
        try { m = JSON.parse(ev.data); } catch { return; }
        if (m.t === "denied") { fail("denied", m.reason || "unknown"); return; }
        if (m.t !== "hello" || stage !== "hello") return;
        if (m.pcId && m.pcId !== pcId) { fail("denied", "other-pc"); return; }     // another PC at this address
        const k = device && deviceKey(device);
        if (!k || typeof m.nonce !== "string") { fail("denied", "no-key"); return; }
        const cnonce = b64u(self.nacl.randomBytes(24));
        const sk = sessionKey(k, m.nonce, cnonce, "http://" + location.host);
        sealed = new SealedSocket(ws, sk);
        stage = "auth";
        ws.send(JSON.stringify({ t: "auth", device: device.deviceId, cnonce, proof: proof(sk) }));
        return;
      }
      // The first sealed message: `ready`, which only a PC that knows K could have sealed.
      if (stage !== "auth" || !sealed) { fail("closed"); return; }
      const d = sealed.openData(ev.data);
      let m = null;
      try { m = typeof d === "string" ? JSON.parse(d) : null; } catch { /* not JSON */ }
      if (!m || m.t !== "ready") { fail("closed", "unsealed"); return; }
      stage = "open"; done = true;
      clearTimeout(timer);
      sealed.onmessage = (e) => onMessage && onMessage(e);
      sealed.onclose = (e) => onClose && onClose(e);
      sealed.attach();
      resolve({ ws: sealed, ready: m });
    };
    ws.onclose = (e) => fail(e.code === 4401 ? "denied" : "closed", e.code === 4401 ? "unknown" : undefined);
    ws.onerror = () => { /* onclose follows */ };
  });
}

const BACKOFF0 = 500, BACKOFF_MAX = 5000, UNREACHABLE_MS = 15000, HIDDEN_MS = 30000, PING_MS = 30000, PONG_MS = 10000;

export class Conn extends EventTarget {
  constructor({ pcId, device }) {
    super();
    this.pcId = pcId;
    this.device = device;
    this.ws = null;
    this.ready = null;              // the last `ready` message (device, pc, caps, modules)
    this.state = "connecting";      // connecting | ready | reconnecting | unreachable | suspended | ended
    this.attempting = false;
    this.endReason = null;
    this.subs = new Map();          // topic -> Set(cb)
    this.cache = new Map();         // topic -> last data
    this.pending = new Map();       // call id -> {resolve, reject, timer}
    this.seq = 0;
    this.backoff = BACKOFF0;
    this.retryTimer = 0;
    this.lostAt = 0;
    this.unreachTimer = 0;
    this.pingTimer = 0;
    this.pongTimer = 0;
    this.hiddenTimer = 0;
    this._onVis = () => this._visibility();
    this._onOnline = () => { if (this.state === "reconnecting" || this.state === "unreachable") this.retry(); };
    document.addEventListener("visibilitychange", this._onVis);
    addEventListener("online", this._onOnline);
    addEventListener("pageshow", (e) => { if (e.persisted) this._visibility(); });
  }

  // ---- lifecycle -----------------------------------------------------------------------------------
  start() { this.lostAt = performance.now(); this._armUnreachable(); this._open(); }

  _setState(state, extra = {}) {
    this.state = state;
    this.dispatchEvent(new CustomEvent("status", { detail: { state, attempting: this.attempting, ...extra } }));
  }

  async _open() {
    if (this.state === "ended" || this.state === "suspended" || this.attempting || this.ws) return;
    clearTimeout(this.retryTimer);
    this.attempting = true;
    this._setState(this.state);
    try {
      const { ws, ready } = await authSocket("/ws", {
        pcId: this.pcId, device: this.device,
        onMessage: (ev) => this._message(ev),
        onClose: () => this._closed(ws),
      });
      this.attempting = false;
      if (this.state === "ended" || this.state === "suspended") { try { ws.close(1000); } catch { /* */ } return; }
      this.ws = ws;
      this.ready = ready;
      this.backoff = BACKOFF0;
      clearTimeout(this.unreachTimer);
      this._setState("ready");
      this.dispatchEvent(new CustomEvent("ready", { detail: ready }));
      const topics = [...this.subs.keys()];
      if (topics.length) this._send({ t: "sub", topics });
      this._ping();
    } catch (e) {
      this.attempting = false;
      if (e.code === "denied") { this._end("denied", e.reason || "unknown"); return; }
      this._scheduleRetry();
    }
  }

  _closed(ws) {
    if (this.ws !== ws) return;
    this.ws = null;
    clearTimeout(this.pingTimer); clearTimeout(this.pongTimer);
    for (const [, p] of this.pending) { clearTimeout(p.timer); p.reject(Object.assign(new Error("Not connected"), { code: "offline" })); }
    this.pending.clear();
    if (this.state === "ended" || this.state === "suspended") return;
    this.lostAt = performance.now();
    this._armUnreachable();
    this._scheduleRetry();
  }

  _scheduleRetry() {
    if (this.state === "ended" || this.state === "suspended") return;
    if (this.state !== "unreachable") this._setState(this.state === "connecting" ? "connecting" : "reconnecting");
    clearTimeout(this.retryTimer);
    this.retryTimer = setTimeout(() => this._open(), this.backoff);
    this.backoff = Math.min(BACKOFF_MAX, Math.round(this.backoff * 1.6));
  }

  _armUnreachable() {
    clearTimeout(this.unreachTimer);
    this.unreachTimer = setTimeout(() => {
      if (this.state === "connecting" || this.state === "reconnecting") this._setState("unreachable");
    }, Math.max(0, UNREACHABLE_MS - (performance.now() - this.lostAt)));
  }

  /** Try again now (the Retry button, the page becoming visible, the network coming back). */
  retry() {
    if (this.state === "ended") return;
    this.backoff = BACKOFF0;
    clearTimeout(this.retryTimer);
    if (this.state === "suspended") { this.state = "reconnecting"; this.lostAt = performance.now(); this._armUnreachable(); }
    if (!this.ws) this._open();
  }

  /** Start over after an `ended` state (Reconnect after "disconnected" / "off"). */
  restart() {
    this.endReason = null;
    this.state = "connecting";
    this.backoff = BACKOFF0;
    this.lostAt = performance.now();
    this._armUnreachable();
    this._setState("connecting");
    this._open();
  }

  suspend() {
    if (this.state === "ended") return;
    clearTimeout(this.retryTimer); clearTimeout(this.unreachTimer);
    this.state = "suspended";
    const ws = this.ws;
    this.ws = null;
    clearTimeout(this.pingTimer); clearTimeout(this.pongTimer);
    if (ws) try { ws.close(1000, "hidden"); } catch { /* */ }
    this._setState("suspended");
  }

  _visibility() {
    clearTimeout(this.hiddenTimer);
    if (document.visibilityState === "hidden") {
      this.hiddenTimer = setTimeout(() => this.suspend(), HIDDEN_MS);
      this.dispatchEvent(new Event("hidden"));
    } else {
      if (this.state === "suspended" || this.state === "reconnecting" || this.state === "unreachable") this.retry();
      else if (this.ws) this._ping(true);           // check the socket survived the phone's sleep
      this.dispatchEvent(new Event("visible"));
    }
  }

  _end(kind, reason) {
    this.state = "ended";
    this.endReason = { kind, reason };
    clearTimeout(this.retryTimer); clearTimeout(this.unreachTimer); clearTimeout(this.pingTimer); clearTimeout(this.pongTimer);
    const ws = this.ws;
    this.ws = null;
    if (ws) try { ws.close(1000); } catch { /* */ }
    this._setState("ended", { kind, reason });
    this.dispatchEvent(new CustomEvent(kind, { detail: { reason } }));
  }

  // ---- traffic ---------------------------------------------------------------------------------------
  _send(obj) {
    if (!this.ws || this.ws.readyState !== 1) return false;
    try { this.ws.send(JSON.stringify(obj)); return true; } catch { return false; }
  }

  _ping(now = false) {
    clearTimeout(this.pingTimer);
    const go = () => {
      if (!this._send({ t: "ping" })) return;
      clearTimeout(this.pongTimer);
      const ws = this.ws;
      this.pongTimer = setTimeout(() => { if (this.ws === ws && ws) { try { ws.close(); } catch { /* */ } this._closed(ws); } }, PONG_MS);
      this.pingTimer = setTimeout(go, PING_MS);
    };
    if (now) go(); else this.pingTimer = setTimeout(go, PING_MS);
  }

  _message(ev) {
    if (typeof ev.data !== "string") return;
    let m;
    try { m = JSON.parse(ev.data); } catch { return; }
    switch (m.t) {
      case "ev": {
        this.cache.set(m.topic, m.data);
        const set = this.subs.get(m.topic);
        if (set) for (const cb of [...set]) { try { cb(m.data); } catch (e) { console.error(e); } }
        break;
      }
      case "res": {
        const p = this.pending.get(m.id);
        if (!p) break;
        this.pending.delete(m.id);
        clearTimeout(p.timer);
        if (m.ok) p.resolve(m.data);
        else p.reject(Object.assign(new Error(m.error || m.code || "failed"), { code: m.code || "failed", detail: m.error }));
        break;
      }
      case "caps":
        if (this.ready) this.ready = { ...this.ready, caps: m.caps || {} };
        this.dispatchEvent(new CustomEvent("caps", { detail: m.caps || {} }));
        break;
      case "pong":
        clearTimeout(this.pongTimer);
        break;
      case "bye":
        // "removed": this phone was removed in Settings; "disconnected": Disconnect phones;
        // "off": Command Deck turned off; "network": the PC left its home network.
        this._end("bye", m.reason || "disconnected");
        break;
      case "denied":
        this._end("denied", m.reason || "unknown");
        break;
    }
  }

  /** Wait (briefly) for the connection; rejects with code "offline". */
  whenReady(ms = 4000) {
    if (this.state === "ready" && this.ws) return Promise.resolve();
    return new Promise((resolve, reject) => {
      const t = setTimeout(() => { this.removeEventListener("ready", ok); reject(Object.assign(new Error("Not connected"), { code: "offline" })); }, ms);
      const ok = () => { clearTimeout(t); resolve(); };
      this.addEventListener("ready", ok, { once: true });
    });
  }

  /** Run an op on the PC. Resolves with `data`; rejects with {code, message}. `mod` names a server-side module. */
  async call(op, args = {}, { mod, timeout = 15000 } = {}) {
    await this.whenReady();
    return new Promise((resolve, reject) => {
      const id = ++this.seq;
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(Object.assign(new Error("The PC took too long to answer."), { code: "timeout" }));
      }, timeout);
      this.pending.set(id, { resolve, reject, timer });
      const msg = { t: "call", id, op, args };
      if (mod) msg.mod = mod;
      if (!this._send(msg)) {
        clearTimeout(timer);
        this.pending.delete(id);
        reject(Object.assign(new Error("Not connected"), { code: "offline" }));
      }
    });
  }

  /** Follow a topic: cb(data) now (if known) and on every change. Returns unsubscribe(). */
  subscribe(topic, cb) {
    let set = this.subs.get(topic);
    if (!set) {
      set = new Set();
      this.subs.set(topic, set);
      this._send({ t: "sub", topics: [topic] });
    }
    set.add(cb);
    if (this.cache.has(topic)) { try { cb(this.cache.get(topic)); } catch (e) { console.error(e); } }
    return () => {
      const s = this.subs.get(topic);
      if (!s) return;
      s.delete(cb);
      if (!s.size) {
        // keep the topic a little while: pages come and go, and a resubscribe costs a round trip
        setTimeout(() => {
          const s2 = this.subs.get(topic);
          if (s2 && !s2.size) { this.subs.delete(topic); this.cache.delete(topic); this._send({ t: "unsub", topics: [topic] }); }
        }, 10000);
      }
    };
  }

  get(topic) { return this.cache.get(topic); }
}
