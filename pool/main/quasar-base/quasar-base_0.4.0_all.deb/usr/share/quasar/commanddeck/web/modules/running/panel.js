// Running: the PC's windows grouped by app. Tap a window to bring it to the front; swipe it left (or
// use its ⋯ button) to minimize or close it.
export function mount(el, ctx) {
  const { h, clear, svg, appIcon, iconButton, row, empty, banner, button, sheet, toast } = ctx.ui;

  const sub = h("p.page-sub");
  el.appendChild(h("header.page-head", h("div.grow", h("h1.page-title", "Running"), sub)));
  const lockNote = h("div", { style: { marginBottom: "12px" } });
  const list = h("div");
  el.append(lockNote, list);

  let apps = null, windows = null, openWid = null, firstPaint = true;
  const rows = new Map();          // wid -> {el, front, title, sub, w}
  const appById = (id) => (apps && apps.apps || []).find((a) => a.id === id);

  function closeSwipes(except) {
    for (const [wid, r] of rows) if (wid !== except) { r.front.style.transform = ""; r.el.classList.remove("open"); }
    if (!except) openWid = null;
  }

  async function act(op, w, label) {
    closeSwipes();
    const r = rows.get(w.wid);
    if (op === "close" && r) r.el.classList.add("leaving");
    const ok = await ctx.run(op, { wid: w.wid });
    if (!ok && r) r.el.classList.remove("leaving");
    else if (op === "minimize") toast("Minimized " + label, "ok", { icon: "minimize", ms: 1800 });
  }

  function actions(w, label) {
    const s = sheet({ title: label, body: h("div",
      h("div.group",
        row({ lead: "square", title: "Bring to front", onClick: () => { s.close(); ctx.run("focus", { wid: w.wid }); } }),
        row({ lead: "minimize", title: "Minimize", onClick: () => { s.close(); act("minimize", w, label); } }),
        row({ lead: "x", title: "Close", sub: "The app asks first if anything is unsaved", danger: true, onClick: () => { s.close(); act("close", w, label); } })),
      h("div", { style: { height: "8px" } })) });
  }

  function makeRow(w) {
    const titleEl = h("span.title"), subEl = h("span.sub");
    const more = iconButton({ icon: "more", label: "More actions" });
    const front = h("div.front", h("div.row.tappable", { role: "button", tabindex: "0" }, h("span.body", titleEl, subEl), h("span.trail", more)));
    const acts = h("div.acts",
      h("button.min", { type: "button", "aria-label": "Minimize" }, svg("minimize", 20, 2), "Minimize"),
      h("button.close", { type: "button", "aria-label": "Close" }, svg("x", 20, 2), "Close"));
    const el2 = h("div.swipe.win-row", acts, front);
    const r = { el: el2, front, titleEl, subEl, w };
    acts.children[0].addEventListener("click", () => act("minimize", r.w, label(r.w)));
    acts.children[1].addEventListener("click", () => act("close", r.w, label(r.w)));
    more.addEventListener("click", (e) => { e.stopPropagation(); actions(r.w, label(r.w)); });
    front.firstChild.addEventListener("keydown", (e) => { if (e.key === "Enter") ctx.run("focus", { wid: r.w.wid }); });

    // swipe to reveal
    const OPEN = -152;
    let id = null, x0 = 0, y0 = 0, base = 0, x = 0, decided = false, horiz = false;
    front.addEventListener("pointerdown", (e) => {
      if (e.target.closest(".icon-btn")) return;
      id = e.pointerId; x0 = e.clientX; y0 = e.clientY; decided = false; horiz = false;
      base = openWid === r.w.wid ? OPEN : 0; x = base;
    });
    front.addEventListener("pointermove", (e) => {
      if (e.pointerId !== id) return;
      const dx = e.clientX - x0, dy = e.clientY - y0;
      if (!decided) {
        if (Math.abs(dx) < 8 && Math.abs(dy) < 8) return;
        decided = true;
        horiz = Math.abs(dx) > Math.abs(dy) * 1.2;
        if (!horiz) { id = null; return; }
        front.setPointerCapture(id);
        front.classList.add("dragging");
        closeSwipes(r.w.wid);
      }
      x = Math.max(OPEN - 30, Math.min(0, base + dx));
      front.style.transform = "translateX(" + x + "px)";
    });
    const up = (e, cancel) => {
      if (e.pointerId !== id) return;
      id = null;
      front.classList.remove("dragging");
      if (!decided) {
        if (cancel) return;
        if (openWid) { closeSwipes(); return; }
        ctx.run("focus", { wid: r.w.wid });
        return;
      }
      const open = x < OPEN / 2;
      front.style.transform = open ? "translateX(" + OPEN + "px)" : "";
      openWid = open ? r.w.wid : null;
      if (open) ctx.ui.vibrate(8);
    };
    front.addEventListener("pointerup", (e) => up(e, false));
    front.addEventListener("pointercancel", (e) => up(e, true));
    return r;
  }

  function label(w) { return w.title || (appById(w.app) || {}).name || "Window"; }

  function paint() {
    if (!windows) { clear(list).appendChild(ctx.ui.skeletonRows(4)); return; }
    const ws = windows.windows || [];
    sub.textContent = ws.length ? ws.length + (ws.length === 1 ? " window on " : " windows on ") + ctx.pc.name : "";
    if (!ws.length) {
      rows.clear();
      clear(list).appendChild(empty({ icon: "layers", title: "Nothing is open", body: "Apps you open on " + ctx.pc.name + " show up here.",
        actions: [button({ label: "Open an app", icon: "grid", kind: "primary", onClick: () => ctx.navigate("apps", {}, { tab: true }) })] }));
      return;
    }
    const groups = new Map();
    for (const w of ws) {
      const k = w.app || label(w);
      if (!groups.has(k)) groups.set(k, []);
      groups.get(k).push(w);
    }
    const seen = new Set();
    const frag = document.createDocumentFragment();
    let gi = 0;
    for (const [k, gws] of groups) {
      const a = appById(k) || {};
      const w0 = gws[0];
      const look = { icon: w0.icon || a.icon, glyph: w0.glyph || a.glyph, hue: w0.hue || a.hue, letter: w0.letter || a.letter, name: a.name || w0.title };
      const head = h("div.win-group-head", appIcon(look, 28), h("span.grow.ellipsis", look.name || "App"), gws.length > 1 ? h("span.count", gws.length + " windows") : null);
      const box = h("div.group");
      for (const w of gws) {
        seen.add(w.wid);
        let r = rows.get(w.wid);
        if (!r) { r = makeRow(w); rows.set(w.wid, r); }
        r.w = w;
        r.titleEl.textContent = label(w);
        clear(r.subEl);
        const bits = [];
        if (w.focused) bits.push("In front");
        if (w.minimized) bits.push("Minimized");
        if (bits.length) r.subEl.appendChild(document.createTextNode(bits.join(" · ")));
        if (w.company) { if (bits.length) r.subEl.appendChild(document.createTextNode("  ")); r.subEl.appendChild(h("span.tag.violet", String(w.company))); }
        if (!bits.length && !w.company) r.subEl.textContent = look.name && look.name !== label(w) ? look.name : "Open";
        r.el.classList.toggle("focused", !!w.focused);
        r.el.classList.toggle("minimized", !!w.minimized);
        r.el.classList.remove("leaving");
        r.front.firstChild.setAttribute("aria-label", label(w) + (w.focused ? ", in front" : "") + (w.minimized ? ", minimized" : ""));
        box.appendChild(r.el);
      }
      const g = h("section.win-group", head, box);
      if (firstPaint) { g.style.animation = "rowIn var(--d-row) var(--soft) backwards"; g.style.animationDelay = Math.min(gi, 8) * 45 + "ms"; }
      if (ctx.params.app === k) g.dataset.target = "1";
      gi++;
      frag.appendChild(g);
    }
    for (const wid of [...rows.keys()]) if (!seen.has(wid)) rows.delete(wid);
    if (openWid && !rows.has(openWid)) openWid = null;
    clear(list).appendChild(frag);
    if (firstPaint) {
      const t = list.querySelector("[data-target]");
      if (t) requestAnimationFrame(() => t.scrollIntoView({ block: "center", behavior: "smooth" }));
    }
    firstPaint = false;
  }

  const onDocDown = (e) => { if (openWid && !e.target.closest(".swipe")) closeSwipes(); };
  document.addEventListener("pointerdown", onDocDown, { passive: true });
  paint();
  ctx.subscribe("apps", (d) => { apps = d; if (windows) paint(); });
  ctx.subscribe("windows", (d) => { windows = d || { windows: [] }; paint(); });
  ctx.subscribe("system", (s) => {
    clear(lockNote);
    if (s && s.locked) lockNote.appendChild(banner({ kind: "amber", icon: "lock", title: "PC is locked", body: "Unlock it at the PC to switch or close windows." }));
  });
  return () => document.removeEventListener("pointerdown", onDocDown);
}
