"""Who uses what: the cgroup tree walked into Task Manager's groups, and reading processes.

Keys come from quasar-netguard's classifier (quasar_netguard/cgroups.py: app_key, system_key, label), so a
group's key is the key netguard counts its traffic under. When netguard's package isn't there (a dev box),
a small copy of its naming rules stands in.
"""
import json
import os
import pwd
import re
import time

from . import paths
from .paths import read

try:
    from quasar_netguard import cgroups as _ngc       # /usr/lib/quasar/netguard (sys.path set by the entry)
except Exception:                                    # noqa: BLE001 — any import trouble: use the fallback
    _ngc = None

USER_UNIT = (".service", ".scope")
SESSION_SCOPE = re.compile(r"^session-[A-Za-z0-9]+\.scope$")
DOCKER_SCOPE = re.compile(r"^docker-[0-9a-f]{12,}\.scope$")
UNIT_NAMES = {"unit:quasar-shell": "Quasar desktop", "unit:user-manager": "Service manager",
              "unit:session": "Desktop session", "sys:init": "System (systemd)", "sys:kernel": "Kernel"}


def _unit_base(unit):
    u = re.sub(r"\\x([0-9a-fA-F]{2})", lambda m: chr(int(m.group(1), 16)), unit)
    for suffix in (".service", ".scope", ".slice", ".socket"):
        if u.endswith(suffix):
            return u[:-len(suffix)]
    return u


def app_key(unit):
    if _ngc is not None:
        return _ngc.app_key(unit)
    for rx in (r"^app-quasar-(.+)-(\d+)\.scope$", r"^app-flatpak-(.+)-(\d+)\.scope$", r"^app-(.+)@autostart\.service$"):
        m = re.match(rx, unit)
        if m:
            return "app:" + _unit_base(m.group(1))
    return "unit:" + re.sub(r"[^A-Za-z0-9@._:-]", "_", _unit_base(unit))[:128]


def system_key(unit):
    if DOCKER_SCOPE.match(unit):
        return "sys:docker"
    if _ngc is not None:
        return _ngc.system_key(unit)
    return "sys:" + re.sub(r"[^A-Za-z0-9@._:-]", "_", _unit_base(unit).split("@", 1)[0])[:128]


def key_label(key):
    if key in UNIT_NAMES:
        return UNIT_NAMES[key]
    if _ngc is not None:
        try:
            return _ngc.label(key)
        except Exception:                            # noqa: BLE001
            pass
    return key.partition(":")[2] or key


_users = {}


def user_name(uid):
    if uid not in _users:
        try:
            _users[uid] = pwd.getpwuid(uid).pw_name
        except KeyError:
            _users[uid] = str(uid)
    return _users[uid]


def user_label(name):
    if name in ("_greetd", "greeter"):
        return "Sign-in screen"
    try:
        gecos = pwd.getpwnam(name).pw_gecos.split(",")[0].strip()
    except KeyError:
        gecos = ""
    return gecos or name


class AppNames:
    """An app's name from its desktop entry (Name=, or Name[lang]), remembered for a minute."""

    def __init__(self):
        self.cache = {}

    @staticmethod
    def dirs():
        if paths.ROOT:
            return [paths.p("/usr/share/applications")]
        home = os.path.expanduser("~")
        out = [os.environ.get("XDG_DATA_HOME") or home + "/.local/share"]
        out += [d for d in (os.environ.get("XDG_DATA_DIRS") or "/usr/local/share:/usr/share").split(":") if d]
        out += ["/var/lib/flatpak/exports/share", home + "/.local/share/flatpak/exports/share"]
        seen, res = set(), []
        for d in out:
            a = d.rstrip("/") + "/applications"
            if a not in seen:
                seen.add(a)
                res.append(a)
        return res

    def name(self, app_id):
        now = time.monotonic()
        hit = self.cache.get(app_id)
        if hit and now - hit[0] < 60:
            return hit[1]
        found = None
        if re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}", app_id or ""):
            for d in self.dirs():
                text = read(d + "/" + app_id + ".desktop")
                if text is not None:
                    found = self._parse(text)
                    if found:
                        break
        self.cache[app_id] = (now, found)
        return found

    @staticmethod
    def _parse(text):
        lang = (os.environ.get("LC_MESSAGES") or os.environ.get("LANG") or "").split(".")[0]
        wanted = [k for k in ("Name[%s]" % lang, "Name[%s]" % lang.split("_")[0]) if lang and lang != "C"] + ["Name"]
        in_entry, vals = False, {}
        for line in text.splitlines():
            s = line.strip()
            if s.startswith("["):
                in_entry = s == "[Desktop Entry]"
                continue
            if in_entry and "=" in s:
                k, _, v = s.partition("=")
                vals.setdefault(k.strip(), v.strip())
        for k in wanted:
            if vals.get(k):
                return vals[k][:80]
        return None


class Unit:
    __slots__ = ("rel", "key", "kind", "unit", "company", "user", "label", "units", "merge")

    def __init__(self, rel, key, kind, unit=None, company=None, user=None, label=None, units=None, merge=False):
        self.rel, self.key, self.kind, self.unit = rel, key, kind, unit
        self.company, self.user, self.label, self.units, self.merge = company, user, label, units, merge


class Walker:
    """The cgroup tree -> [Unit]. This account's user units one by one; each company this account owns and
    each other account as one unit (their whole user-UID.slice); system services one by one."""

    def __init__(self, uid):
        self.uid = uid
        self._comp_stamp = None
        self._companies = {}

    def companies(self):
        """{company account uid: {"id", "name"}} for the companies this account owns."""
        try:
            st = os.stat(paths.COMPANIES)
            stamp = (st.st_mtime_ns, st.st_size)
        except OSError:
            self._comp_stamp, self._companies = None, {}
            return self._companies
        if stamp != self._comp_stamp:
            out = {}
            try:
                data = json.loads(read(paths.COMPANIES) or "{}")
                for c in data.get("companies") or []:
                    try:
                        if int(c.get("owner", -1)) == self.uid and re.fullmatch(r"[a-z0-9-]{1,24}", str(c.get("id", ""))):
                            out[int(c["uid"])] = {"id": c["id"], "name": str(c.get("name") or c["id"])[:60]}
                    except (TypeError, ValueError, KeyError):
                        continue
            except (ValueError, AttributeError):
                out = {}
            self._comp_stamp, self._companies = stamp, out
        return self._companies

    def walk(self):
        out = []
        comps = self.companies()
        my_ids = {c["id"] for c in comps.values()}
        for d in subdirs("user.slice"):
            m = re.fullmatch(r"user-(\d+)\.slice", d)
            if not m:
                continue
            u = int(m.group(1))
            rel = "user.slice/" + d
            if u == self.uid:
                for child in subdirs(rel):
                    crel = rel + "/" + child
                    if child == "user@%d.service" % u:
                        self._manager(crel, out)
                    elif SESSION_SCOPE.match(child):
                        out.append(Unit(crel, "unit:session", "session", child))
            elif u in comps:
                c = comps[u]
                names = [n for n in subdirs(rel + "/user@%d.service/app.slice" % u) if n.endswith(USER_UNIT)]
                out.append(Unit(rel, "company:" + c["id"], "company", None, company=c["id"], label=c["name"], units=names))
            else:
                name = user_name(u)
                out.append(Unit(rel, "user:" + name, "user", None, user=name, label=user_label(name)))
        top = set(subdirs(""))
        self._system("system.slice", out, my_ids)
        if "init.scope" in top:
            out.append(Unit("init.scope", "sys:init", "system", "init.scope"))
        if "machine.slice" in top:
            self._system("machine.slice", out, my_ids)
        return out

    def _manager(self, rel, out):
        for child in subdirs(rel):
            crel = rel + "/" + child
            if child == "init.scope":
                out.append(Unit(crel, "unit:user-manager", "unit", child))
            elif child.endswith(".slice"):
                self._user_slice(crel, out, 0)
            elif child.endswith(USER_UNIT):
                out.append(self._user_unit(crel, child))

    def _user_slice(self, rel, out, depth):
        for child in subdirs(rel):
            crel = rel + "/" + child
            if child.endswith(".slice"):
                if depth < 4:
                    self._user_slice(crel, out, depth + 1)
            elif child.endswith(USER_UNIT):
                out.append(self._user_unit(crel, child))

    @staticmethod
    def _user_unit(rel, unit):
        key = app_key(unit)
        return Unit(rel, key, "app" if key.startswith("app:") else "unit", unit)

    def _system(self, rel, out, my_ids, depth=0):
        for child in subdirs(rel):
            crel = rel + "/" + child
            if child.endswith(".slice"):
                if depth < 3:
                    self._system(crel, out, my_ids, depth + 1)
            elif child.endswith(USER_UNIT):
                key = system_key(child)
                if key.startswith("company:"):
                    if key[8:] in my_ids:
                        out.append(Unit(crel, key, "company", child, company=key[8:], merge=True))
                        continue
                    key = "sys:quasar-company-pasta"
                out.append(Unit(crel, key, "system", child))


def subdirs(rel):
    """Sorted names of the cgroups directly below rel (d_type: no stat per entry; cgroupfs folders hold ~50
    control files each)."""
    path = paths.CGROUP + ("/" + rel if rel else "")
    try:
        with os.scandir(path) as it:
            return sorted(e.name for e in it if e.is_dir(follow_symlinks=False))
    except OSError:
        return []


# ------------------------------------------------------------------------------------------------ cgroups
def unit_numbers(rel):
    """(cpu usage µs, memory without page cache, [pids]) of a cgroup and everything below it."""
    base = paths.CGROUP + "/" + rel
    usage = None
    for line in (read(base + "/cpu.stat", 4096) or "").splitlines():
        if line.startswith("usage_usec "):
            try:
                usage = int(line.split()[1])
            except (ValueError, IndexError):
                pass
            break
    # Memory without page cache, from memory.stat alone (one read less per unit: memory.current minus
    # "file" is anon + kernel + sock). Kernels before 5.18 have no "kernel" line: its parts then.
    mem = None
    vals = dict(MEM_LINE.findall(read(base + "/memory.stat", 16384) or ""))
    if "anon" in vals:
        kernel = int(vals["kernel"]) if "kernel" in vals else \
            sum(int(vals.get(k, 0)) for k in ("kernel_stack", "pagetables", "percpu", "slab", "vmalloc"))
        mem = int(vals["anon"]) + kernel + int(vals.get("sock", 0))
    return usage, mem, cgroup_pids(base, leaf=rel.endswith(".scope"))


MEM_LINE = re.compile(r"^(anon|kernel|sock|kernel_stack|pagetables|percpu|slab|vmalloc) (\d+)$", re.M)


def cgroup_pids(base, depth=0, budget=None, leaf=False):
    """The processes of a cgroup and of the cgroups below it. Scopes (apps, sessions, containers) have none
    below; a service has some only when cgroup.stat's nr_descendants says so (delegated: user@, a rootless
    container engine); a slice is always looked into. A big tree stops after 256 folders."""
    budget = budget if budget is not None else [256]
    pids = [int(x) for x in (read(base + "/cgroup.procs", 1 << 20) or "").split() if x.isdigit()]
    if leaf or depth >= 8:
        return pids
    if base.endswith(".service"):
        m = re.search(r"^nr_descendants (\d+)", read(base + "/cgroup.stat", 1024) or "", re.M)
        if m is not None and int(m.group(1)) == 0:
            return pids
    try:
        with os.scandir(base) as it:
            kids = [e for e in it if e.is_dir(follow_symlinks=False)]
    except OSError:
        kids = []
    for k in kids:
        if budget[0] <= 0:
            break
        budget[0] -= 1
        pids.extend(cgroup_pids(k.path, depth + 1, budget, leaf=k.name.endswith(".scope")))
    return pids


def root_pids():
    """Processes in the root cgroup: kernel threads (and anything started before systemd sorted it)."""
    return [int(x) for x in (read(paths.CGROUP + "/cgroup.procs", 1 << 20) or "").split() if x.isdigit()]


def top_usage():
    """cpu.stat usage of every top-level cgroup together (everything that isn't the kernel's own)."""
    total = 0
    for d in subdirs(""):
        for line in (read(paths.CGROUP + "/" + d + "/cpu.stat", 4096) or "").splitlines():
            if line.startswith("usage_usec "):
                try:
                    total += int(line.split()[1])
                except (ValueError, IndexError):
                    pass
                break
    return total


# ------------------------------------------------------------------------------------------------ /proc
CLK_TCK = os.sysconf("SC_CLK_TCK") if hasattr(os, "sysconf") else 100
PF_KTHREAD = 0x00200000


def proc_stat(pid):
    """{name, state, ppid, flags, ticks (utime+stime), threads, start} or None."""
    text = read(paths.PROC + "/%d/stat" % pid, 4096)
    if not text:
        return None
    l, r = text.find("("), text.rfind(")")
    if l < 0 or r < l:
        return None
    f = text[r + 2:].split()
    try:
        return {"name": text[l + 1:r], "state": f[0], "ppid": int(f[1]), "flags": int(f[6]),
                "ticks": int(f[11]) + int(f[12]), "threads": int(f[17]), "start": int(f[19])}
    except (ValueError, IndexError):
        return None


def proc_uid(pid):
    try:
        return os.stat(paths.PROC + "/%d" % pid).st_uid
    except OSError:
        return None


def proc_mem(pid):
    """Resident memory that is the process's own: RssAnon + RssShmem (VmRSS when those aren't there)."""
    text = read(paths.PROC + "/%d/status" % pid, 8192) or ""
    vals = dict(re.findall(r"^(RssAnon|RssShmem|VmRSS):\s+(\d+) kB", text, re.M))
    if "RssAnon" in vals:
        return (int(vals["RssAnon"]) + int(vals.get("RssShmem", 0))) * 1024
    return int(vals.get("VmRSS", 0)) * 1024


def proc_cmd(pid):
    raw = read(paths.PROC + "/%d/cmdline" % pid, 4096)
    if not raw:
        return ""
    return " ".join(a for a in raw.split("\0") if a)[:300]


def proc_io(pid):
    """read_bytes + write_bytes (storage, not the page cache), or None when it can't be read (others')."""
    text = read(paths.PROC + "/%d/io" % pid, 4096)
    if text is None:
        return None
    vals = dict(re.findall(r"^(read_bytes|write_bytes):\s+(\d+)$", text, re.M))
    if not vals:
        return None
    return int(vals.get("read_bytes", 0)) + int(vals.get("write_bytes", 0))
