"""Per-app network use from quasar-netguard (/run/quasar/netguard.sock, {"op":"usage"}: today's bytes per key,
the asking account's own keys plus shared ones). Rates come from the difference between two answers, asked
at most every 2 s over one kept connection. Without netguard (firewall off, a dev box) every rate is None."""
import json
import socket
import time

from . import paths

EVERY = 2.0


class NetUsage:
    def __init__(self, path=None, clock=time.monotonic):
        self.path = path or paths.NETGUARD_SOCK
        self.clock = clock
        self.sock = None
        self.buf = b""
        self.asked_at = None
        self.prev = None          # (t, {key: bytes})
        self.rates = {}
        self.ok = False

    def _close(self):
        if self.sock is not None:
            try:
                self.sock.close()
            except OSError:
                pass
        self.sock, self.buf = None, b""

    def _ask(self):
        try:
            if self.sock is None:
                s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                try:
                    s.settimeout(0.5)
                    s.connect(self.path)
                except OSError:
                    s.close()
                    raise
                self.sock = s
            self.sock.sendall(b'{"op":"usage"}\n')
            while b"\n" not in self.buf:
                chunk = self.sock.recv(65536)
                if not chunk:
                    raise OSError("closed")
                self.buf += chunk
                if len(self.buf) > (4 << 20):
                    raise OSError("answer too long")
            line, _, self.buf = self.buf.partition(b"\n")
            ans = json.loads(line)
        except (OSError, ValueError):
            self._close()
            return None
        if not isinstance(ans, dict) or not ans.get("ok"):
            return None
        out = {}
        for r in ans.get("rows") or []:
            try:
                out[str(r["key"])] = int(r.get("rx", 0)) + int(r.get("tx", 0))
            except (KeyError, TypeError, ValueError):
                continue
        return out

    def poll(self):
        now = self.clock()
        if self.asked_at is not None and now - self.asked_at < EVERY:
            return
        self.asked_at = now
        totals = self._ask()
        if totals is None:
            self.ok, self.prev, self.rates = False, None, {}
            return
        if self.prev is not None and now > self.prev[0]:
            dt = now - self.prev[0]
            old = self.prev[1]
            # A new day (netguard keeps only today's counts) makes totals smaller: no negative rates.
            self.rates = {k: int(max(0, v - old.get(k, v)) / dt) for k, v in totals.items()}
        self.prev = (now, totals)
        self.ok = True

    def rate(self, key):
        if not self.ok:
            return None
        return self.rates.get(key, 0)

    def close(self):
        self._close()
