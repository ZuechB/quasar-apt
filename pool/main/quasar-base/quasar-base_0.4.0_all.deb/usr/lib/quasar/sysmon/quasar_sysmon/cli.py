"""sysmon watch | end (see the protocol in __init__)."""
import argparse
import json
import os
import re
import selectors
import signal
import subprocess
import sys
import time

from . import groups, paths

OK, FAILED, BAD, GONE, REFUSED = 0, 1, 2, 3, 4
UNIT_NAME = re.compile(r"^[A-Za-z0-9@._:\\-]{1,250}\.(scope|service)$")


def emit(obj):
    sys.stdout.write(json.dumps(obj, ensure_ascii=False, separators=(",", ":")) + "\n")
    sys.stdout.flush()


# ------------------------------------------------------------------------------------------------ watch
def cmd_watch(args):
    from .monitor import Monitor
    interval = max(0.01 if args.once else 0.2, args.interval / 1000.0)
    mon = Monitor()
    first = mon.info_if_changed()
    if first:
        emit(first)
    mon.step()
    if args.once:
        time.sleep(interval)
        info = mon.info_if_changed()
        if info:
            emit(info)
        emit(mon.step())
        return OK

    sel = selectors.DefaultSelector()
    fd = sys.stdin.fileno()
    try:
        os.set_blocking(fd, False)
        sel.register(fd, selectors.EVENT_READ)
    except (OSError, ValueError):
        return OK                       # no stdin to watch: nothing would ever stop us
    buf = b""
    due = time.monotonic() + interval
    while True:
        for _key, _ev in sel.select(max(0.0, due - time.monotonic())):
            try:
                data = os.read(fd, 65536)
            except BlockingIOError:
                continue
            except OSError:
                return OK
            if not data:
                return OK               # stdin closed: Task Manager went away
            buf += data
            if len(buf) > (1 << 20):
                buf = b""
            while b"\n" in buf:
                line, _, buf = buf.partition(b"\n")
                try:
                    req = json.loads(line)
                except ValueError:
                    continue
                if isinstance(req, dict) and isinstance(req.get("expand"), list):
                    mon.set_expand(req["expand"])
        now = time.monotonic()
        if now >= due:
            info = mon.info_if_changed()
            if info:
                emit(info)
            tick = mon.step()
            if tick:
                emit(tick)
            due += interval
            if due < time.monotonic():
                due = time.monotonic() + interval


# ------------------------------------------------------------------------------------------------ end
def result(ok=True, code=None, message=""):
    if ok:
        emit({"type": "result", "ok": True})
        return OK
    emit({"type": "error", "code": code, "message": message})
    return {"gone": GONE, "changed": REFUSED, "refused": REFUSED, "bad": BAD}.get(code, FAILED)


def _systemctl(*args):
    exe = (None if paths.IS_ROOT else os.environ.get("SYSMON_SYSTEMCTL")) or "systemctl"
    try:
        return subprocess.run([exe, "--user", *args], capture_output=True, text=True, timeout=15)
    except (OSError, subprocess.SubprocessError) as e:
        return subprocess.CompletedProcess([exe], 1, "", str(e))


def _active(units):
    r = _systemctl("is-active", "--", *units)
    states = (r.stdout or "").split()
    return [u for u, s in zip(units, states) if s in ("active", "activating", "deactivating", "reloading")]


def end_units(units, grace):
    for u in units:
        if not UNIT_NAME.match(u):
            return result(False, "bad", "That isn't a unit name: %s" % u)
    alive = _active(units)
    if not alive:
        return result(False, "gone", "It has already ended.")
    r = _systemctl("kill", "--signal=SIGTERM", "--", *alive)
    if r.returncode != 0 and not _active(alive):
        return result()
    deadline = time.monotonic() + max(0.0, grace)
    while time.monotonic() < deadline:
        alive = _active(alive)
        if not alive:
            return result()
        time.sleep(0.25)
    alive = _active(alive)
    if alive:
        r = _systemctl("kill", "--signal=SIGKILL", "--", *alive)
        time.sleep(0.3)
        if _active(alive) and r.returncode != 0:
            return result(False, "failed", (r.stderr or "").strip()[:300] or "It didn't stop.")
    return result()


def end_pid(pid, start, sig):
    st = groups.proc_stat(pid)
    if st is None:
        return result(False, "gone", "It has already ended.")
    if groups.proc_uid(pid) != os.getuid():
        return result(False, "refused", "That program belongs to another account.")
    if st["start"] != start:
        return result(False, "changed", "That program has ended; another one has its number now.")
    try:
        os.kill(pid, signal.SIGKILL if sig == "KILL" else signal.SIGTERM)
    except ProcessLookupError:
        return result(False, "gone", "It has already ended.")
    except PermissionError:
        return result(False, "refused", "That program can't be ended from here.")
    return result()


def cmd_end(args):
    if args.unit and args.pid is not None:
        return result(False, "bad", "Give units or a process, not both.")
    if args.unit:
        return end_units(args.unit, args.grace)
    if args.pid is None or args.start is None or args.pid <= 1:
        return result(False, "bad", "usage: sysmon end --unit UNIT… | --pid PID --start T")
    return end_pid(args.pid, args.start, args.signal)


def main(argv):
    signal.signal(signal.SIGPIPE, signal.SIG_DFL)
    ap = argparse.ArgumentParser(prog="sysmon")
    sub = ap.add_subparsers(dest="cmd")
    w = sub.add_parser("watch")
    w.add_argument("--interval", type=int, default=1000)
    w.add_argument("--once", action="store_true", help="the info line and one tick, then exit")
    e = sub.add_parser("end")
    e.add_argument("--unit", action="append")
    e.add_argument("--grace", type=float, default=5.0)
    e.add_argument("--pid", type=int)
    e.add_argument("--start", type=int)
    e.add_argument("--signal", choices=("TERM", "KILL"), default="TERM")
    try:
        args = ap.parse_args(argv)
    except SystemExit as ex:
        return BAD if ex.code else OK
    try:
        if args.cmd == "watch":
            return cmd_watch(args)
        if args.cmd == "end":
            return cmd_end(args)
    except (BrokenPipeError, KeyboardInterrupt):
        return OK
    ap.print_usage(sys.stderr)
    return BAD
