"""Two samples -> one tick (see the protocol in __init__)."""
import os
import time

from . import gpu, groups, system
from .netusage import NetUsage

OWN_KINDS = ("app", "unit", "session")
MAX_PROCS = 400
MAX_EXPAND = 64


def _r(x):
    return round(float(x), 1)


class Monitor:
    def __init__(self, clock=time.monotonic, wall=time.time, uid=None, netusage=None):
        self.clock, self.wall = clock, wall
        self.uid = os.getuid() if uid is None else uid
        self.hwmon = system.Hwmon()
        self.ssids = system.Ssids()
        self.gpus = gpu.Gpus()
        self.walker = groups.Walker(self.uid)
        self.names = groups.AppNames()
        self.net = netusage if netusage is not None else NetUsage(clock=clock)
        self.expand = set()
        self.prev = None
        self.proc_prev = {}           # pid -> (start, ticks)
        self.cmd_cache = {}           # (pid, start) -> command line
        self.mounts, self.mounts_at = {}, None
        self.cpuinfo = None
        self.devices = None           # (disks, nets, gpus) as last sent in an info line
        self.disks, self.nets = [], []

    # ---------------------------------------------------------------------------------------- devices
    def _devices(self, now):
        disks = system.disk_list()
        nets = system.net_list(list(system.net_counters()))
        gpus = self.gpus.refresh_list(now)
        return disks, nets, gpus

    def info_if_changed(self):
        """The info line when the device set differs from the last one sent (always the first time)."""
        now = self.clock()
        disks, nets, gpus = self._devices(now)
        sig = (tuple((d["key"], d["size"]) for d in disks), tuple((n["key"], n["kind"]) for n in nets),
               tuple((g["key"], g["slot"], g["driver"]) for g in gpus))
        self.disks, self.nets = disks, nets
        if sig == self.devices:
            return None
        self.devices = sig
        if self.cpuinfo is None:
            self.cpuinfo = system.cpu_info()
        return {"type": "info", "uid": self.uid, "cpu": self.cpuinfo,
                "memory": {"total": system.meminfo().get("MemTotal", 0)},
                "gpus": [{"key": g["key"], "name": g["name"], "vendor": g["vendor"], "driver": g["driver"],
                          "slot": g["slot"], "vramTotal": g["vramTotal"]} for g in gpus],
                "disks": disks, "nets": nets}

    def set_expand(self, keys):
        self.expand = {str(k)[:200] for k in keys[:MAX_EXPAND] if isinstance(k, str)}

    # ---------------------------------------------------------------------------------------- sampling
    def _collect(self):
        now = self.clock()
        units = []
        own = set()
        for u in self.walker.walk():
            usage, mem, pids = groups.unit_numbers(u.rel)
            units.append((u, usage, mem, pids))
            if u.kind in OWN_KINDS:
                own.update(pids)
        # Storage I/O of this account's processes. Keyed by PID alone: a number taken over by a new process
        # within one tick only makes that tick's difference negative, which counts as nothing.
        io = {}
        for pid in own:
            b = groups.proc_io(pid)
            if b is not None:
                io[pid] = b
        return {"t": now, "cpu": system.cpu_times(), "disks": system.disk_counters([d["key"] for d in self.disks]),
                "nets": system.net_counters(), "units": units, "top": groups.top_usage(), "own": own, "io": io}

    def step(self):
        """Sample now; return a tick when there is an earlier sample to compare with, else None."""
        cur = self._collect()
        prev, self.prev = self.prev, cur
        if prev is None or cur["t"] <= prev["t"]:
            # Still read the GPU clients once, so the next tick has a baseline.
            self.gpus.sample(cur["own"], cur["t"], int(cur["t"] * 1e9))
            self.net.poll()
            return None
        return self._tick(prev, cur)

    def _tick(self, prev, cur):
        dt = cur["t"] - prev["t"]
        ncpu = max(1, len(cur["cpu"]) - 1)
        tick = {"type": "tick", "t": int(self.wall() * 1000)}

        # CPU
        total = system.cpu_percent(prev["cpu"][0], cur["cpu"][0]) if prev["cpu"] and cur["cpu"] else 0.0
        cores = [system.cpu_percent(a, b) for a, b in zip(prev["cpu"][1:], cur["cpu"][1:])]
        procs, threads, uptime = system.counts()
        tick["cpu"] = {"total": total, "cores": cores, "mhz": system.cpu_mhz(), "procs": procs, "threads": threads,
                       "uptime": uptime, "tempC": self.hwmon.cpu_temp(cur["t"])}
        tick["mem"] = system.memory()

        # Disks
        if self.mounts_at is None or cur["t"] - self.mounts_at > 10:
            self.mounts, self.mounts_at = system.mount_map(), cur["t"]
        disks = []
        for d in self.disks:
            a, b = prev["disks"].get(d["key"]), cur["disks"].get(d["key"])
            if a and b:
                rd, wr = max(0, b[0] - a[0]) / dt, max(0, b[1] - a[1]) / dt
                busy = min(100.0, max(0.0, (b[2] - a[2]) / (dt * 1000.0) * 100.0))
            else:
                rd = wr = busy = 0.0
            used, free = system.disk_space(self.mounts.get(d["key"], []))
            disks.append({"key": d["key"], "readBps": int(rd), "writeBps": int(wr), "busy": _r(busy),
                          "used": used, "free": free})
        tick["disks"] = disks

        # Network adapters
        nets = []
        for n in self.nets:
            a, b = prev["nets"].get(n["key"]), cur["nets"].get(n["key"])
            rx = max(0, b[0] - a[0]) / dt if a and b else 0.0
            tx = max(0, b[1] - a[1]) / dt if a and b else 0.0
            up = system.net_up(n["key"])
            nets.append({"key": n["key"], "rxBps": int(rx), "txBps": int(tx), "up": up,
                         "ipv4": system.ipv4(n["key"]) if up else None,
                         "ssid": self.ssids.get(n["key"], cur["t"]) if (up and n["kind"] == "wifi") else None})
        tick["nets"] = nets

        # GPUs (and each process's share, used by the groups below)
        gpus, per_pid = self.gpus.sample(cur["own"], cur["t"], int(cur["t"] * 1e9))
        tick["gpus"] = gpus

        # Groups
        self.net.poll()
        prev_usage = {u.rel: usage for (u, usage, _m, _p) in prev["units"]}
        grouped = {}
        for u, usage, mem, pids in cur["units"]:
            g = grouped.get(u.key)
            if g is None:
                g = grouped[u.key] = {"key": u.key, "kind": u.kind, "label": u.label, "unit_list": [],
                                      "company": u.company, "user": u.user, "us": 0, "mem": 0, "mem_ok": False,
                                      "pids": []}
            if u.merge:
                pass                                   # a company's network service: counted, not listed
            elif u.units is not None:
                g["unit_list"].extend(u.units)
            elif u.unit:
                g["unit_list"].append(u.unit)
            old = prev_usage.get(u.rel)
            if usage is not None and old is not None:
                g["us"] += max(0, usage - old)
            if mem is not None:
                g["mem"] += mem
                g["mem_ok"] = True
            g["pids"].extend(pids)

        scale = 100.0 / (dt * 1e6 * ncpu)
        out = []
        for key, g in grouped.items():
            own = g["kind"] in OWN_KINDS
            mem = g["mem"] if g["mem_ok"] else sum(groups.proc_mem(p) for p in g["pids"][:MAX_PROCS])
            disk = None
            if own:
                total_io = 0
                for pid in g["pids"]:
                    b, a = cur["io"].get(pid), prev["io"].get(pid)
                    if b is not None and a is not None:
                        total_io += max(0, b - a)
                disk = int(total_io / dt)
            gp = [per_pid[p] for p in g["pids"] if p in per_pid]
            gpu_pct = _r(min(100.0, sum(gp))) if gp else (0.0 if own else None)
            label = g["label"]
            app_id = key[4:] if g["kind"] == "app" else None
            if not label:
                label = (self.names.name(app_id) if app_id else None) or groups.key_label(key)
            out.append({"key": key, "kind": g["kind"], "label": label, "appId": app_id,
                        "units": sorted(set(g["unit_list"])), "company": g["company"], "user": g["user"], "own": own,
                        "cpu": _r(min(100.0, g["us"] * scale)), "mem": int(mem), "disk": disk,
                        "net": None if g["kind"] == "user" else self.net.rate(key), "gpu": gpu_pct,
                        "pids": len(set(g["pids"]))})

        # The kernel: whatever the CPU did that no cgroup accounts for (kernel threads, interrupts).
        kernel_pids = groups.root_pids()
        top_pct = max(0, cur["top"] - prev["top"]) * scale
        out.append({"key": "sys:kernel", "kind": "system", "label": groups.key_label("sys:kernel"), "appId": None,
                    "units": [], "company": None, "user": None, "own": False,
                    "cpu": _r(max(0.0, min(100.0, total - top_pct))), "mem": 0, "disk": None, "net": None,
                    "gpu": None, "pids": len(kernel_pids)})
        out.sort(key=lambda r: r["key"])
        tick["groups"] = out

        # Processes of the expanded groups
        procs = {}
        if self.expand:
            pidlists = {k: grouped[k]["pids"] for k in self.expand if k in grouped}
            if "sys:kernel" in self.expand:
                pidlists["sys:kernel"] = kernel_pids
            seen = set()
            for key, pids in pidlists.items():
                rows = []
                for pid in list(dict.fromkeys(pids))[:MAX_PROCS]:
                    row = self._proc(pid, dt, ncpu, cur, prev, per_pid)
                    if row:
                        rows.append(row)
                        seen.add(pid)
                rows.sort(key=lambda r: (-r["cpu"], -r["mem"], r["pid"]))
                procs[key] = rows
            self.proc_prev = {p: v for p, v in self.proc_prev.items() if p in seen}
            self.cmd_cache = {k: v for k, v in self.cmd_cache.items() if k[0] in seen}
        else:
            self.proc_prev, self.cmd_cache = {}, {}
        tick["procs"] = procs
        return tick

    def _proc(self, pid, dt, ncpu, cur, prev, per_pid):
        st = groups.proc_stat(pid)
        if st is None:
            return None
        uid = groups.proc_uid(pid)
        old = self.proc_prev.get(pid)
        cpu = 0.0
        if old and old[0] == st["start"]:
            cpu = max(0, st["ticks"] - old[1]) / (groups.CLK_TCK * dt * ncpu) * 100.0
        self.proc_prev[pid] = (st["start"], st["ticks"])
        kthread = bool(st["flags"] & groups.PF_KTHREAD)
        ck = (pid, st["start"])
        if ck not in self.cmd_cache:
            self.cmd_cache[ck] = "" if kthread else groups.proc_cmd(pid)
        disk = None
        if uid == self.uid:
            b, a = cur["io"].get(pid), prev["io"].get(pid)
            if b is not None and a is not None:
                disk = int(max(0, b - a) / dt)
            elif b is not None:
                disk = 0
        g = per_pid.get(pid)
        return {"pid": pid, "start": st["start"], "name": st["name"], "cmd": self.cmd_cache[ck],
                "user": groups.user_name(uid) if uid is not None else "", "cpu": _r(min(100.0, cpu)),
                "mem": 0 if kthread else groups.proc_mem(pid), "disk": disk,
                "gpu": g if g is not None else (0.0 if uid == self.uid else None), "threads": st["threads"]}
