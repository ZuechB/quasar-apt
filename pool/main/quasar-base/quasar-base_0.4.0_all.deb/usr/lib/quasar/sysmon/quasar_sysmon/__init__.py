"""quasar-sysmon: what Task Manager shows (apps/taskmanager). Runs as the user; Python standard library +
ctypes (NVML for NVIDIA cards). Entry point: /usr/libexec/quasar/sysmon.

  sysmon watch [--interval MS] [--once]
      JSON lines on stdout while Task Manager is open; ends on stdin EOF. Reads JSON lines on stdin.
  sysmon end --unit UNIT [--unit UNIT…] [--grace S]
  sysmon end --pid PID --start T [--signal TERM|KILL]
      Ends something of this account's (also run inside a company: quasar-company exec ID -- sysmon end …).

watch: the first line, and again whenever the set of devices changes (a disk, adapter or GPU comes or goes):
  {"type":"info","uid":int,"cpu":{"model":str,"cores":int,"threads":int,"maxMHz":float|null},
   "memory":{"total":bytes},
   "gpus":[{"key":"gpu0","name":str,"vendor":str,"driver":str,"slot":str|null,"vramTotal":bytes|null}],
   "disks":[{"key":"nvme0n1","name":str,"size":bytes,"removable":bool}],
   "nets":[{"key":"wlp2s0","kind":"wifi"|"ethernet"|"vpn"|"other","name":str}]}
then one line per tick (the first one an interval later: rates need two samples):
  {"type":"tick","t":epoch_ms,
   "cpu":{"total":pct,"cores":[pct…],"mhz":float|null,"procs":int,"threads":int,"uptime":seconds,"tempC":float|null},
   "mem":{"total":b,"used":b,"available":b,"cached":b,"swapTotal":b,"swapUsed":b,"zram":{"orig":b,"compr":b}|null},
   "disks":[{"key","readBps","writeBps","busy":pct,"used":b|null,"free":b|null}],
   "nets":[{"key","rxBps","txBps","up":bool,"ipv4":str|null,"ssid":str|null}],
   "gpus":[{"key","busy":pct|null,"vramUsed":b|null,"vramTotal":b|null,"tempC":float|null}],
   "groups":[{"key":str,"kind":"app"|"unit"|"session"|"company"|"system"|"user","label":str,"appId":str|null,
              "units":[str…],"company":str|null,"user":str|null,"own":bool,
              "cpu":pct,"mem":b,"disk":Bps|null,"net":Bps|null,"gpu":pct|null,"pids":int}],
   "procs":{"<group key>":[{"pid":int,"start":int,"name":str,"cmd":str,"user":str,"cpu":pct,"mem":b,
                            "disk":Bps|null,"gpu":pct|null,"threads":int}]}}
stdin: {"expand":["app:firefox","sys:NetworkManager",…]}: the following ticks carry "procs" for exactly
those groups (the newest line replaces the set). Other lines are ignored.

Percentages are of the whole machine (all logical CPUs together), rounded to 0.1. Group keys are
quasar-netguard's (quasar_netguard/cgroups.py), so the network column joins its per-app counters:
  app:<desktop id>   an app's scopes (Quasar's launcher, Flatpak, autostart); one group for all of them
  unit:<name>        another part of this account's session (unit:quasar-shell = "Quasar desktop")
  unit:session       the logind session scope: labwc and what its keybinds start (kind "session")
  unit:user-manager  this account's systemd --user
  company:<id>       a company environment this account owns (its whole account + its network service)
  sys:<name>         a system service (sys:init = PID 1, sys:kernel = kernel threads and interrupts)
  user:<name>        everything another account runs (the sign-in screen, someone else signed in)
"own": ended without a password by this account (app, unit, session). Companies are ended through their
agent (quasar-company exec ID -- sysmon end …); system and user groups through pkexec quasar-proc-admin.
"disk" (bytes read + written per second, /proc/PID/io) is only known for this account's processes; "gpu"
from NVML (NVIDIA), DRM fdinfo (this account's processes) or amdgpu's sysfs; "net" from netguard (null
when netguard isn't running). "mem" is memory.current without page cache (0 for sys:kernel: not measured).

end prints one line, {"type":"result","ok":true} or {"type":"error","code":"gone"|"changed"|"refused"|
"failed"|"bad","message":…}; exit 0 ok, 2 bad request, 3 gone, 4 refused or changed, 1 failed.

Tests: SYSMON_ROOT (a fake tree with proc/, sys/, run/, etc/, usr/) and QUASAR_NETGUARD_ROOT, honored only
when not root; SYSMON_NO_NVML=1 keeps NVML unloaded; SYSMON_NETGUARD_SOCK points at another socket.
"""
import sys


def main(argv=None):
    from . import cli
    return cli.main(sys.argv[1:] if argv is None else argv)
