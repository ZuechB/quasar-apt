"""Graphics cards: which there are, how busy, how much video memory, how hot, and per process.

- amdgpu: sysfs (gpu_busy_percent, mem_info_vram_used/total, hwmon).
- NVIDIA's driver: NVML through ctypes (libnvidia-ml.so.1, package libnvidia-ml1): utilization, memory,
  temperature, and per process (nvmlDeviceGetProcessUtilization). No library = no numbers, never an error.
- Everything else (i915, xe, nouveau, v3d, amdgpu per process…): DRM fdinfo of this account's processes
  (drm-engine-<name> busy nanoseconds, xe's drm-cycles-/drm-total-cycles-, drm-engine-capacity-), each
  client counted once (drm-client-id), assigned to a card by drm-pdev (else by driver). A card's own busy
  percentage then is its busiest engine summed over the clients this account can see.
"""
import ctypes
import json
import os
import re

from . import paths
from .paths import listdir, read, read_int, read_line, realname
from .system import device_temp

__all__ = ["Gpus", "Nvml", "DrmClients", "discover", "parse_fdinfo", "engine_utils"]

VENDORS = {"0x10de": "nvidia", "0x1002": "amd", "0x8086": "intel"}
NAMES = {"nvidia": "NVIDIA graphics", "amd": "AMD graphics", "intel": "Intel graphics"}
DRIVER_NAMES = {"simpledrm": "Basic display adapter", "efifb": "Basic display adapter",
                "virtio_gpu": "Virtual display", "virtio-gpu": "Virtual display", "bochs-drm": "Virtual display",
                "hyperv_drm": "Virtual display (Hyper-V)", "vmwgfx": "Virtual display (VMware)",
                "qxl": "Virtual display (QXL)", "v3d": "VideoCore graphics (V3D)", "vc4": "VideoCore display"}
PCI_SLOT = re.compile(r"^[0-9a-f]{4}:[0-9a-f]{2}:[0-9a-f]{2}\.[0-9a-f]$")


def _hardware():
    try:
        return {g.get("slot"): g for g in json.loads(read(paths.HARDWARE) or "{}").get("gpus") or [] if isinstance(g, dict)}
    except (ValueError, AttributeError):
        return {}


def discover():
    """[{key, card, dev, slot, driver, vendor, name, vramTotal}] — cards that render (have a render node);
    when none does, the first card (a basic display adapter) so the page isn't empty."""
    base = paths.SYS + "/class/drm"
    cards = sorted((c for c in listdir(base) if re.fullmatch(r"card\d+", c)), key=lambda c: int(c[4:]))
    hw = _hardware()
    found, seen = [], set()
    for c in cards:
        dev = base + "/" + c + "/device"
        if not os.path.exists(dev):
            continue
        try:
            real = os.path.realpath(dev)
        except OSError:
            real = dev
        slot = os.path.basename(real)
        slot = slot if PCI_SLOT.match(slot) else None
        ident = slot or real
        if ident in seen:
            continue
        seen.add(ident)
        render = any(n.startswith("renderD") for n in listdir(dev + "/drm")) or \
            any(n.startswith("renderD") for n in listdir(base) if os.path.realpath(base + "/" + n + "/device") == real)
        driver = realname(dev + "/driver")
        info = hw.get(slot) if slot else None
        if info is None and not slot:
            info = hw.get(c)
        vendor = (info or {}).get("vendor") or VENDORS.get(read_line(dev + "/vendor") or "", "other")
        name = (info or {}).get("name") or DRIVER_NAMES.get(driver) or NAMES.get(vendor) or (driver or "Graphics")
        vram = None
        if (info or {}).get("vramMB"):
            try:
                vram = int(info["vramMB"]) * 1024 * 1024
            except (TypeError, ValueError):
                vram = None
        t = read_int(dev + "/mem_info_vram_total")
        if t:
            vram = t
        found.append({"card": c, "dev": dev, "slot": slot, "driver": driver, "vendor": vendor, "name": name,
                      "vramTotal": vram, "render": render})
    out = [g for g in found if g["render"]] or found[:1]
    for i, g in enumerate(out):
        g["key"] = "gpu%d" % i
    return out


# ------------------------------------------------------------------------------------------------ NVML
class _Util(ctypes.Structure):
    _fields_ = [("gpu", ctypes.c_uint), ("memory", ctypes.c_uint)]


class _Mem(ctypes.Structure):
    _fields_ = [("total", ctypes.c_ulonglong), ("free", ctypes.c_ulonglong), ("used", ctypes.c_ulonglong)]


class _Pci(ctypes.Structure):
    _fields_ = [("busIdLegacy", ctypes.c_char * 16), ("domain", ctypes.c_uint), ("bus", ctypes.c_uint),
                ("device", ctypes.c_uint), ("pciDeviceId", ctypes.c_uint), ("pciSubSystemId", ctypes.c_uint),
                ("busId", ctypes.c_char * 32)]


class _ProcSample(ctypes.Structure):
    _fields_ = [("pid", ctypes.c_uint), ("timeStamp", ctypes.c_ulonglong), ("smUtil", ctypes.c_uint),
                ("memUtil", ctypes.c_uint), ("encUtil", ctypes.c_uint), ("decUtil", ctypes.c_uint)]


class Nvml:
    """NVIDIA's management library, loaded only when a card runs NVIDIA's driver. Every failure turns it off."""

    def __init__(self):
        self.lib = None
        self.handles = {}          # PCI slot -> handle
        self.last_seen = {}        # slot -> timestamp of the newest process sample
        if paths.NO_NVML:
            return
        try:
            lib = ctypes.CDLL("libnvidia-ml.so.1")
            if lib.nvmlInit_v2() != 0:
                return
            n = ctypes.c_uint(0)
            if lib.nvmlDeviceGetCount_v2(ctypes.byref(n)) != 0:
                return
            for i in range(n.value):
                h = ctypes.c_void_p()
                if lib.nvmlDeviceGetHandleByIndex_v2(i, ctypes.byref(h)) != 0:
                    continue
                pci = _Pci()
                if lib.nvmlDeviceGetPciInfo_v3(h, ctypes.byref(pci)) != 0:
                    continue
                bus = pci.busId.decode("ascii", "replace").lower()
                self.handles[bus[-12:]] = h            # "00000000:01:00.0" -> "0000:01:00.0"
            self.lib = lib
        except (OSError, AttributeError):
            self.lib = None

    def stats(self, slot):
        h = self.handles.get(slot) if self.lib else None
        if h is None:
            return None
        busy = used = total = temp = None
        try:
            u = _Util()
            if self.lib.nvmlDeviceGetUtilizationRates(h, ctypes.byref(u)) == 0:
                busy = float(u.gpu)
            m = _Mem()
            if self.lib.nvmlDeviceGetMemoryInfo(h, ctypes.byref(m)) == 0:
                used, total = int(m.used), int(m.total)
            t = ctypes.c_uint(0)
            if self.lib.nvmlDeviceGetTemperature(h, 0, ctypes.byref(t)) == 0:
                temp = float(t.value)
        except (OSError, AttributeError):
            return None
        return busy, used, total, temp

    def procs(self, slot):
        """{pid: percent} since the last call (NVML keeps a short history per process)."""
        h = self.handles.get(slot) if self.lib else None
        if h is None:
            return {}
        try:
            fn = self.lib.nvmlDeviceGetProcessUtilization
            count = ctypes.c_uint(0)
            last = ctypes.c_ulonglong(self.last_seen.get(slot, 0))
            r = fn(h, None, ctypes.byref(count), last)
            if r not in (0, 7) or count.value == 0:          # 7 = NVML_ERROR_INSUFFICIENT_SIZE
                return {}
            arr = (_ProcSample * count.value)()
            if fn(h, arr, ctypes.byref(count), last) != 0:
                return {}
            out = {}
            newest = last.value
            for s in arr[:count.value]:
                out[int(s.pid)] = max(out.get(int(s.pid), 0.0), float(s.smUtil))
                newest = max(newest, int(s.timeStamp))
            self.last_seen[slot] = newest
            return out
        except (OSError, AttributeError):
            return {}


# ------------------------------------------------------------------------------------------------ fdinfo
FDINFO_LINE = re.compile(r"^(drm-[a-z0-9_-]+):\s*(.*)$", re.M)


def parse_fdinfo(text):
    """One DRM file's fdinfo -> {"driver", "pdev", "client", "engines": {name: (kind, value, capacity)}}
    (kind "ns": busy nanoseconds; "cycles": (busy, total) cycles) or None when it isn't a DRM client."""
    kv = dict(FDINFO_LINE.findall(text or ""))
    if "drm-driver" not in kv or "drm-client-id" not in kv:
        return None
    engines = {}
    caps = {}
    for k, v in kv.items():
        if k.startswith("drm-engine-capacity-"):
            try:
                caps[k[len("drm-engine-capacity-"):]] = max(1, int(v.split()[0]))
            except (ValueError, IndexError):
                pass
    for k, v in kv.items():
        if k.startswith("drm-engine-") and not k.startswith("drm-engine-capacity-"):
            name = k[len("drm-engine-"):]
            try:
                engines[name] = ("ns", int(v.split()[0]), caps.get(name, 1))
            except (ValueError, IndexError):
                pass
        elif k.startswith("drm-cycles-"):
            name = k[len("drm-cycles-"):]
            tot = kv.get("drm-total-cycles-" + name)
            try:
                engines[name] = ("cycles", (int(v.split()[0]), int(tot.split()[0])), caps.get(name, 1))
            except (ValueError, IndexError, AttributeError):
                pass
    return {"driver": kv["drm-driver"].strip(), "pdev": kv.get("drm-pdev", "").strip() or None,
            "client": kv["drm-client-id"].strip(), "engines": engines}


def engine_utils(prev, cur, dt_ns):
    """{engine: busy fraction} of one client between two readings."""
    out = {}
    for name, (kind, val, cap) in cur["engines"].items():
        old = prev["engines"].get(name)
        if not old or old[0] != kind:
            continue
        if kind == "ns" and dt_ns > 0:
            f = (val - old[1]) / (dt_ns * cap)
        elif kind == "cycles":
            d_busy, d_total = val[0] - old[1][0], val[1] - old[1][1]
            f = d_busy / (d_total * cap) if d_total > 0 else 0.0
        else:
            continue
        out[name] = max(0.0, min(1.0, f))
    return out


class DrmClients:
    """This account's GPU clients. Which descriptors of a process are DRM devices is remembered and looked at
    again every 5 s (new processes first, at most RESCAN processes per tick), so a tick reads a few fdinfo
    files instead of every descriptor of every process."""

    RESCAN = 16
    STALE = 5.0

    def __init__(self):
        self.fds = {}            # pid -> (scanned at, [fd numbers])
        self.prev = {}           # (card ident, client id) -> (pid, parsed, t_ns)

    def _scan(self, pid):
        fds = []
        base = paths.PROC + "/%d/fd" % pid
        for fd in listdir(base):
            try:
                if os.readlink(base + "/" + fd).startswith("/dev/dri/"):
                    fds.append(int(fd))
            except (OSError, ValueError):
                continue
        return fds

    def refresh(self, pids, now):
        """pids: this account's processes. A number reused by a new process within 5 s keeps the old list of
        descriptors until the next look; a descriptor that isn't a DRM client there just reads as nothing."""
        for pid in list(self.fds):
            if pid not in pids:
                del self.fds[pid]
        fresh = [p for p in pids if p not in self.fds]
        stale = sorted((self.fds[p][0], p) for p in pids if p in self.fds and now - self.fds[p][0] > self.STALE)
        for pid in fresh:
            self.fds[pid] = (now, self._scan(pid))
        for _t, pid in stale[:self.RESCAN]:
            self.fds[pid] = (now, self._scan(pid))

    def read(self, t_ns):
        """-> ({card ident: {engine: busy fraction summed over clients}}, {pid: busy fraction}) since the last
        read. Card ident = drm-pdev, else "driver:<name>"."""
        cur = {}
        for pid, (_at, fds) in self.fds.items():
            for fd in fds:
                parsed = parse_fdinfo(read(paths.PROC + "/%d/fdinfo/%d" % (pid, fd), 8192))
                if not parsed:
                    continue
                ident = parsed["pdev"] or "driver:" + parsed["driver"]
                key = (ident, parsed["client"])
                if key not in cur or pid < cur[key][0]:
                    cur[key] = (pid, parsed)
        cards, per_pid = {}, {}
        for key, (pid, parsed) in cur.items():
            old = self.prev.get(key)
            if old:
                dt = t_ns - old[2]
                eu = engine_utils(old[1], parsed, dt)
                card = cards.setdefault(key[0], {})
                for e, f in eu.items():
                    card[e] = card.get(e, 0.0) + f
                if eu:
                    per_pid[pid] = per_pid.get(pid, 0.0) + max(eu.values())
            else:
                cards.setdefault(key[0], {})
        self.prev = {k: (pid, parsed, t_ns) for k, (pid, parsed) in cur.items()}
        return cards, per_pid


class Gpus:
    def __init__(self):
        self.list = []
        self.found_at = None
        self.nvml = None
        self.drm = DrmClients()

    def refresh_list(self, now):
        if self.found_at is None or now - self.found_at > 5:
            self.list = discover()
            self.found_at = now
            if self.nvml is None and any(g["driver"] == "nvidia" for g in self.list):
                self.nvml = Nvml()
        return self.list

    def sample(self, own_pids, now, t_ns):
        """-> ([{key, busy, vramUsed, vramTotal, tempC}], {pid: percent})."""
        self.drm.refresh(own_pids, now)
        cards, per_pid = self.drm.read(t_ns)
        per_pid = {p: round(min(100.0, 100.0 * f), 1) for p, f in per_pid.items()}
        out = []
        for g in self.list:
            busy = used = None
            total = g["vramTotal"]
            temp = device_temp(g["dev"])
            if g["driver"] == "amdgpu":
                b = read_int(g["dev"] + "/gpu_busy_percent")
                busy = float(b) if b is not None else None
                used = read_int(g["dev"] + "/mem_info_vram_used")
                total = read_int(g["dev"] + "/mem_info_vram_total") or total
            elif g["driver"] == "nvidia" and self.nvml is not None:
                st = self.nvml.stats(g["slot"])
                if st:
                    busy, used, total, temp = st[0], st[1], st[2] or total, st[3] if st[3] is not None else temp
                for pid, pct in self.nvml.procs(g["slot"]).items():
                    per_pid[pid] = round(max(per_pid.get(pid, 0.0), pct), 1)
            if busy is None:
                engines = cards.get(g["slot"]) if g["slot"] else None
                if engines is None:
                    engines = cards.get("driver:" + g["driver"])
                if engines is not None:
                    busy = min(100.0, 100.0 * max(engines.values())) if engines else 0.0
            out.append({"key": g["key"], "busy": round(busy, 1) if busy is not None else None, "vramUsed": used,
                        "vramTotal": total, "tempC": temp})
        return out, per_pid
