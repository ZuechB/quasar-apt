"""Where sysmon reads, and small readers that never raise.

Tests point SYSMON_ROOT at a fake tree (proc/, sys/, run/, etc/, usr/, home/); it is ignored when running as
root (nobody redirects a root process), like quasar-netguard's QUASAR_NETGUARD_ROOT.
"""
import os

IS_ROOT = hasattr(os, "geteuid") and os.geteuid() == 0
ROOT = "" if IS_ROOT else os.environ.get("SYSMON_ROOT", "").rstrip("/")


def p(path):
    return ROOT + path if ROOT else path


PROC = p("/proc")
SYS = p("/sys")
CGROUP = p("/sys/fs/cgroup")
HARDWARE = p("/run/quasar/hardware.json")
COMPANIES = p("/etc/quasar/companies.json")
NETGUARD_SOCK = (None if IS_ROOT else os.environ.get("SYSMON_NETGUARD_SOCK")) or p("/run/quasar/netguard.sock")
NO_NVML = bool(os.environ.get("SYSMON_NO_NVML")) or bool(ROOT)


def read(path, limit=1 << 16):
    try:
        with open(path, "rb") as f:
            return f.read(limit).decode("utf-8", "replace")
    except OSError:
        return None


def read_line(path):
    t = read(path, 4096)
    return t.strip() if t is not None else None


def read_int(path, default=None):
    t = read_line(path)
    try:
        return int(t) if t else default
    except ValueError:
        return default


def listdir(path):
    try:
        return os.listdir(path)
    except OSError:
        return []


def realname(path):
    """basename of what a sysfs link points at ('' when it isn't there). Test trees may keep a plain file
    holding the name instead of a link (as hw-detect's do)."""
    try:
        if os.path.islink(path):
            return os.path.basename(os.readlink(path).rstrip("/"))
        if os.path.isfile(path):
            return (read_line(path) or "").strip()
        if os.path.isdir(path):
            return os.path.basename(os.path.realpath(path))
    except OSError:
        pass
    return ""
