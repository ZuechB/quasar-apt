"""Whole-machine numbers: CPU, memory, disks, network adapters, temperatures."""
import fcntl
import os
import platform
import re
import socket
import struct
import subprocess

from . import paths
from .paths import listdir, read, read_int, read_line


def _rnd(x):
    return round(float(x), 1)


# ------------------------------------------------------------------------------------------------ hwmon
class Hwmon:
    """Temperature sensors, found once (and again every 30 s): which file holds the CPU's temperature, and
    each GPU's (by the hwmon folder under its PCI device)."""

    def __init__(self):
        self.cpu_file = None
        self.found_at = None

    def _find_cpu(self):
        best = None           # (rank, path)
        base = paths.SYS + "/class/hwmon"
        for h in sorted(listdir(base)):
            d = os.path.join(base, h)
            name = read_line(os.path.join(d, "name")) or ""
            inputs = sorted(f for f in listdir(d) if re.fullmatch(r"temp\d+_input", f))
            labels = {f: (read_line(os.path.join(d, f.replace("_input", "_label"))) or "") for f in inputs}

            def pick(*wanted):
                for w in wanted:
                    for f, lab in labels.items():
                        if lab == w or (w.endswith("*") and lab.startswith(w[:-1])):
                            return f
                return None

            cand = None
            if name in ("k10temp", "zenpower"):
                cand, rank = pick("Tctl", "Tdie") or (inputs[0] if inputs else None), 0
            elif name == "coretemp":
                cand, rank = pick("Package id*") or (inputs[0] if inputs else None), 0
            elif name in ("cpu_thermal", "cpu-thermal", "soc_thermal"):
                cand, rank = (inputs[0] if inputs else None), 1
            elif name == "acpitz":
                cand, rank = (inputs[0] if inputs else None), 2
            else:
                continue
            if cand and (best is None or rank < best[0]):
                best = (rank, os.path.join(d, cand))
        return best[1] if best else None

    def cpu_temp(self, now):
        if self.found_at is None or now - self.found_at > 30:
            self.cpu_file = self._find_cpu()
            self.found_at = now
        if not self.cpu_file:
            return None
        v = read_int(self.cpu_file)
        return _rnd(v / 1000.0) if v is not None else None


def device_temp(dev_dir):
    """The first temperature of the hwmon folder under a device (amdgpu's edge, nouveau's)."""
    base = os.path.join(dev_dir, "hwmon")
    for h in sorted(listdir(base)):
        v = read_int(os.path.join(base, h, "temp1_input"))
        if v is not None:
            return _rnd(v / 1000.0)
    return None


# ------------------------------------------------------------------------------------------------ CPU
def cpu_times():
    """[(busy, total) for the whole machine, then each CPU] in clock ticks, from /proc/stat."""
    out = []
    text = read(paths.PROC + "/stat") or ""
    for line in text.splitlines():
        if not line.startswith("cpu"):
            break
        f = line.split()
        try:
            v = [int(x) for x in f[1:9]]          # user nice system idle iowait irq softirq steal
        except ValueError:
            continue
        v += [0] * (8 - len(v))
        total = sum(v)
        idle = v[3] + v[4]
        out.append((total - idle, total))
    return out


def cpu_percent(prev, cur):
    db, dt = cur[0] - prev[0], cur[1] - prev[1]
    return _rnd(max(0.0, min(100.0, 100.0 * db / dt))) if dt > 0 else 0.0


def cpu_info():
    text = read(paths.PROC + "/cpuinfo", 1 << 20) or ""
    model, cores, threads = "", set(), 0
    phys = core = None
    for line in text.splitlines():
        k, _, v = line.partition(":")
        k, v = k.strip(), v.strip()
        if k == "processor":
            threads += 1
            phys = core = None
        elif k in ("model name", "Model", "Hardware", "cpu model") and not model:
            model = v
        elif k == "physical id":
            phys = v
        elif k == "core id":
            core = v
            cores.add((phys, core))
    logical = len(cpu_times()) - 1
    if logical <= 0:
        logical = threads or os.cpu_count() or 1
    if not cores:
        topo = set()
        for c in listdir(paths.SYS + "/devices/system/cpu"):
            if re.fullmatch(r"cpu\d+", c):
                t = paths.SYS + "/devices/system/cpu/" + c + "/topology/"
                cid, pid = read_line(t + "core_id"), read_line(t + "physical_package_id")
                if cid is not None:
                    topo.add((pid, cid))
        cores = topo
    mx = read_int(paths.SYS + "/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq")
    return {"model": re.sub(r"\s+", " ", model) or platform.machine() or "Processor",
            "cores": len(cores) or logical, "threads": logical,
            "maxMHz": _rnd(mx / 1000.0) if mx else None}


def cpu_mhz():
    base = paths.SYS + "/devices/system/cpu"
    vals = []
    for c in listdir(base):
        if re.fullmatch(r"cpu\d+", c):
            v = read_int(base + "/" + c + "/cpufreq/scaling_cur_freq")
            if v:
                vals.append(v)
    if vals:
        return _rnd(sum(vals) / len(vals) / 1000.0)
    mhz = [float(m) for m in re.findall(r"^cpu MHz\s*:\s*([\d.]+)", read(paths.PROC + "/cpuinfo", 1 << 20) or "", re.M)]
    return _rnd(sum(mhz) / len(mhz)) if mhz else None


def counts():
    """(processes, threads, uptime seconds)."""
    procs = sum(1 for d in listdir(paths.PROC) if d.isdigit())
    threads = 0
    la = (read_line(paths.PROC + "/loadavg") or "").split()
    if len(la) >= 4 and "/" in la[3]:
        try:
            threads = int(la[3].split("/")[1])
        except ValueError:
            pass
    up = (read_line(paths.PROC + "/uptime") or "0").split()
    try:
        uptime = int(float(up[0]))
    except (ValueError, IndexError):
        uptime = 0
    return procs, threads, uptime


# ------------------------------------------------------------------------------------------------ memory
def meminfo():
    out = {}
    for line in (read(paths.PROC + "/meminfo") or "").splitlines():
        k, _, v = line.partition(":")
        f = v.split()
        if f:
            try:
                out[k.strip()] = int(f[0]) * (1024 if len(f) > 1 and f[1] == "kB" else 1)
            except ValueError:
                pass
    return out


def memory():
    m = meminfo()
    total = m.get("MemTotal", 0)
    avail = m.get("MemAvailable", m.get("MemFree", 0) + m.get("Cached", 0))
    # Cache that could be handed back: page cache + buffers + reclaimable slab, minus shared memory (which
    # lives in the page cache but can't be dropped).
    cached = max(0, m.get("Cached", 0) + m.get("Buffers", 0) + m.get("SReclaimable", 0) - m.get("Shmem", 0))
    swap_total = m.get("SwapTotal", 0)
    zram = None
    orig = compr = 0
    found = False
    for d in listdir(paths.SYS + "/block"):
        if d.startswith("zram"):
            f = (read_line(paths.SYS + "/block/" + d + "/mm_stat") or "").split()
            if len(f) >= 2:
                try:
                    orig += int(f[0])
                    compr += int(f[1])
                    found = True
                except ValueError:
                    pass
    if found:
        zram = {"orig": orig, "compr": compr}
    return {"total": total, "used": max(0, total - avail), "available": avail, "cached": cached,
            "swapTotal": swap_total, "swapUsed": max(0, swap_total - m.get("SwapFree", 0)), "zram": zram}


# ------------------------------------------------------------------------------------------------ disks
SKIP_DISK = re.compile(r"^(loop|ram|zram|dm-|md|sr|fd|nbd|mtdblock|nullb|ublkb)")
PSEUDO_FS = {"proc", "sysfs", "tmpfs", "devtmpfs", "devpts", "cgroup", "cgroup2", "securityfs", "pstore", "bpf",
             "debugfs", "tracefs", "configfs", "fusectl", "mqueue", "hugetlbfs", "autofs", "binfmt_misc",
             "efivarfs", "nsfs", "ramfs", "rpc_pipefs", "overlay", "squashfs", "fuse.portal", "fuse.gvfsd-fuse"}


def disk_list():
    out = []
    base = paths.SYS + "/block"
    for d in sorted(listdir(base)):
        if SKIP_DISK.match(d):
            continue
        size = (read_int(base + "/" + d + "/size", 0) or 0) * 512
        if size <= 0:
            continue
        name = ""
        for f in ("device/model", "device/name", "device/product"):
            name = (read_line(base + "/" + d + "/" + f) or "").strip()
            if name:
                break
        vendor = (read_line(base + "/" + d + "/device/vendor") or "").strip()
        if vendor and name and not name.lower().startswith(vendor.lower()) and vendor.upper() != "ATA":
            name = vendor + " " + name
        try:
            usb = "/usb" in os.path.realpath(base + "/" + d)
        except OSError:
            usb = False
        removable = read_line(base + "/" + d + "/removable") == "1" or usb
        out.append({"key": d, "name": re.sub(r"\s+", " ", name) or d, "size": size, "removable": removable})
    return out


def disk_counters(keys):
    """{disk: (bytes read, bytes written, busy ms)}."""
    out = {}
    for d in keys:
        f = (read_line(paths.SYS + "/block/" + d + "/stat") or "").split()
        if len(f) >= 10:
            try:
                out[d] = (int(f[2]) * 512, int(f[6]) * 512, int(f[9]))
            except ValueError:
                pass
    return out


def _unescape_mount(s):
    return re.sub(r"\\([0-7]{3})", lambda m: chr(int(m.group(1), 8)), s)


def _parent_disks(name, depth=0):
    """The physical disks a block device sits on: a partition's disk, dm-crypt/LVM/RAID's slaves."""
    if depth > 8 or not name:
        return set()
    cls = paths.SYS + "/class/block/" + name
    if SKIP_DISK.match(name) and not name.startswith(("dm-", "md")):
        return set()
    if os.path.exists(cls + "/partition"):
        try:
            return {os.path.basename(os.path.dirname(os.path.realpath(cls)))}
        except OSError:
            return set()
    slaves = listdir(cls + "/slaves")
    if slaves:
        out = set()
        for s in slaves:
            out |= _parent_disks(s, depth + 1)
        return out
    if os.path.isdir(paths.SYS + "/block/" + name) and not SKIP_DISK.match(name):
        return {name}
    return set()


def mount_map():
    """{disk: [(source, mount point)…]}: one entry per mounted filesystem (btrfs subvolumes once)."""
    out = {}
    seen = set()
    for line in (read(paths.PROC + "/self/mountinfo", 1 << 20) or "").splitlines():
        left, sep, right = line.partition(" - ")
        if not sep:
            continue
        lf, rf = left.split(), right.split()
        if len(lf) < 5 or len(rf) < 2:
            continue
        majmin, mnt, fstype, source = lf[2], _unescape_mount(lf[4]), rf[0], rf[1]
        if fstype in PSEUDO_FS:
            continue
        dev = ""
        if not majmin.startswith("0:"):
            dev = paths.realname(paths.SYS + "/dev/block/" + majmin)
        if not dev and source.startswith("/dev/"):
            try:
                dev = os.path.basename(os.path.realpath(paths.p(source)))
            except OSError:
                dev = ""
        if not dev or dev in seen:
            continue
        seen.add(dev)
        for disk in _parent_disks(dev):
            out.setdefault(disk, []).append((dev, mnt))
    return out


def disk_space(mounts):
    used = free = 0
    ok = False
    for _dev, mnt in mounts:
        try:
            st = os.statvfs(paths.p(mnt))
        except OSError:
            continue
        used += (st.f_blocks - st.f_bfree) * st.f_frsize
        free += st.f_bavail * st.f_frsize
        ok = True
    return (used, free) if ok else (None, None)


# ------------------------------------------------------------------------------------------------ network
SKIP_NET = re.compile(r"^(lo$|docker\d|veth|br-|virbr|vnet|sit\d|ip6tnl|tunl|gre\d|gretap|erspan|ip_vti|ip6_vti|"
                      r"ip6gre|ifb|dummy|nlmon|teql|bonding_masters)")


def net_counters():
    """{interface: (rx bytes, tx bytes)} from /proc/net/dev."""
    out = {}
    for line in (read(paths.PROC + "/net/dev") or "").splitlines()[2:]:
        name, _, rest = line.partition(":")
        name = name.strip()
        f = rest.split()
        if not name or len(f) < 9 or SKIP_NET.match(name):
            continue
        try:
            out[name] = (int(f[0]), int(f[8]))
        except ValueError:
            pass
    return out


def net_kind(ifname):
    d = paths.SYS + "/class/net/" + ifname
    if os.path.exists(d + "/wireless") or os.path.exists(d + "/phy80211"):
        return "wifi"
    if ifname.startswith(("wg", "tun", "tap", "ppp")) or read_line(d + "/type") == "65534":
        return "vpn"
    if read_line(d + "/type") == "1" and os.path.exists(d + "/device"):
        return "ethernet"
    return "other"


def net_list(names):
    kinds = {n: net_kind(n) for n in names}
    label = {"wifi": "Wi-Fi", "ethernet": "Ethernet", "vpn": "VPN"}
    per = {}
    for k in kinds.values():
        per[k] = per.get(k, 0) + 1
    out = []
    for n in sorted(names, key=lambda x: ({"ethernet": 0, "wifi": 1, "vpn": 2}.get(kinds[x], 3), x)):
        k = kinds[n]
        base = label.get(k, n)
        out.append({"key": n, "kind": k, "name": base if (k not in label or per[k] == 1) else "%s (%s)" % (base, n)})
    return out


def net_up(ifname):
    d = paths.SYS + "/class/net/" + ifname
    state = read_line(d + "/operstate")
    try:
        flags = int(read_line(d + "/flags") or "0", 16)
    except ValueError:
        flags = 0
    return state == "up" or (state == "unknown" and bool(flags & 1))


SIOCGIFADDR = 0x8915


def ipv4(ifname):
    if paths.ROOT:
        return read_line(paths.SYS + "/class/net/" + ifname + "/quasar-test-ipv4") or None
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            r = fcntl.ioctl(s.fileno(), SIOCGIFADDR, struct.pack("256s", ifname[:15].encode()))
        return socket.inet_ntoa(r[20:24])
    except OSError:
        return None


class Ssids:
    """The Wi-Fi network each wireless adapter is on: `iw dev IF link` (nmcli's connection name when iw isn't
    there), asked at most every 10 s per adapter."""

    def __init__(self):
        self.cache = {}            # ifname -> (asked at, ssid)

    def get(self, ifname, now):
        hit = self.cache.get(ifname)
        if hit and now - hit[0] < 10:
            return hit[1]
        ssid = None if paths.ROOT else self._ask(ifname)
        self.cache[ifname] = (now, ssid)
        return ssid

    @staticmethod
    def _ask(ifname):
        for cmd, rx in ((["/usr/sbin/iw", "dev", ifname, "link"], r"^\s*SSID:\s*(.+)$"),
                        (["nmcli", "-t", "-f", "GENERAL.CONNECTION", "device", "show", ifname],
                         r"^GENERAL\.CONNECTION:(.+)$")):
            if cmd[0].startswith("/") and not os.path.exists(cmd[0]):
                continue
            try:
                r = subprocess.run(cmd, capture_output=True, text=True, timeout=1.5)
            except (OSError, subprocess.SubprocessError):
                continue
            m = re.search(rx, r.stdout or "", re.M)
            if m and m.group(1).strip() and m.group(1).strip() != "--":
                return m.group(1).strip()
        return None
