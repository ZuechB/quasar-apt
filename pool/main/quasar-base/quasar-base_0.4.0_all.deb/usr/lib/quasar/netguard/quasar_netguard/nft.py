"""nftables for netguard: libnftables through ctypes (no process per change), `nft` as a fallback.

netguard owns `inet quasar_apps`:
    out5/in5, out3/in3, out2/in2   verdict maps: a cgroup (by its level-5/3/2 ancestor) -> goto that
                                   app's chain. `goto`, so a packet is counted once.
    a<N>o / a<N>i                  one pair per (uid, key): `counter name "c<N>o"` (+ a refusal while the
                                   user has blocked that app; only outgoing, which also stops replies)
    other_o/other_i, cont_o/cont_i traffic no app owns, and containers (forwarded through docker0/br-*)
Loopback isn't counted or blocked: it never leaves this PC. The firewall's table (`inet quasar`) runs
first (priority filter), so connections it refused never reach these counters.
It also keeps the firewall's `allow_app5` set: the cgroups of allowed apps' running scopes.
"""
import ctypes
import json
import subprocess

APPS = "inet quasar_apps"
FIREWALL = "inet quasar"
NFT_CTX_OUTPUT_JSON = 1 << 4
LEVELS = (5, 3, 2)

TABLE = """table inet quasar_apps
delete table inet quasar_apps
table inet quasar_apps {
	map out5 { typeof socket cgroupv2 level 5 : verdict; }
	map in5 { typeof socket cgroupv2 level 5 : verdict; }
	map out3 { typeof socket cgroupv2 level 3 : verdict; }
	map in3 { typeof socket cgroupv2 level 3 : verdict; }
	map out2 { typeof socket cgroupv2 level 2 : verdict; }
	map in2 { typeof socket cgroupv2 level 2 : verdict; }
	counter other_o { }
	counter other_i { }
	counter cont_o { }
	counter cont_i { }
	chain output {
		type filter hook output priority filter + 10; policy accept;
		oif lo accept
		socket cgroupv2 level 5 vmap @out5
		socket cgroupv2 level 3 vmap @out3
		socket cgroupv2 level 2 vmap @out2
		counter name "other_o"
	}
	chain input {
		type filter hook input priority filter + 10; policy accept;
		iif lo accept
		socket cgroupv2 level 5 vmap @in5
		socket cgroupv2 level 3 vmap @in3
		socket cgroupv2 level 2 vmap @in2
		counter name "other_i"
	}
	chain forward {
		type filter hook forward priority filter + 10; policy accept;
		iifname "docker0" counter name "cont_o" accept
		iifname "br-*" counter name "cont_o" accept
		oifname "docker0" counter name "cont_i" accept
		oifname "br-*" counter name "cont_i" accept
	}
}
"""


def quote(path):
    """A cgroup path as an nft string (paths come from cgroupfs, but never trust a quote)."""
    return '"%s"' % path.replace("\\", "").replace('"', "")


class Nft:
    def __init__(self, binary="/usr/sbin/nft"):
        self.binary = binary
        self.lib = None
        try:
            lib = ctypes.CDLL("libnftables.so.1")
            lib.nft_ctx_new.restype = ctypes.c_void_p
            lib.nft_ctx_new.argtypes = [ctypes.c_uint32]
            lib.nft_ctx_buffer_output.argtypes = [ctypes.c_void_p]
            lib.nft_ctx_buffer_error.argtypes = [ctypes.c_void_p]
            lib.nft_ctx_get_output_buffer.restype = ctypes.c_char_p
            lib.nft_ctx_get_output_buffer.argtypes = [ctypes.c_void_p]
            lib.nft_ctx_get_error_buffer.restype = ctypes.c_char_p
            lib.nft_ctx_get_error_buffer.argtypes = [ctypes.c_void_p]
            lib.nft_ctx_output_set_flags.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
            lib.nft_run_cmd_from_buffer.argtypes = [ctypes.c_void_p, ctypes.c_char_p]
            lib.nft_run_cmd_from_buffer.restype = ctypes.c_int
            self.ctx = lib.nft_ctx_new(0)
            lib.nft_ctx_buffer_output(self.ctx)
            lib.nft_ctx_buffer_error(self.ctx)
            self.lib = lib
        except (OSError, AttributeError):
            self.lib = None

    def run(self, script, json_out=False):
        """-> (ok, stdout, stderr)"""
        if self.lib:
            self.lib.nft_ctx_output_set_flags(self.ctx, NFT_CTX_OUTPUT_JSON if json_out else 0)
            rc = self.lib.nft_run_cmd_from_buffer(self.ctx, script.encode())
            out = (self.lib.nft_ctx_get_output_buffer(self.ctx) or b"").decode("utf-8", "replace")
            err = (self.lib.nft_ctx_get_error_buffer(self.ctx) or b"").decode("utf-8", "replace")
            return rc == 0, out, err
        cmd = [self.binary] + (["-j"] if json_out else []) + ["-f", "-"]
        try:
            r = subprocess.run(cmd, input=script, capture_output=True, text=True, timeout=20)
        except (OSError, subprocess.SubprocessError) as e:
            return False, "", str(e)
        return r.returncode == 0, r.stdout, r.stderr

    # ---- the table
    def create(self):
        return self.run(TABLE)

    def exists(self, table=APPS):
        return self.run("list table %s" % table)[0]

    def delete(self):
        return self.run("delete table %s" % APPS)

    def slot_script(self, n, blocked):
        """Commands that (re)define slot N's chains and counters. A blocked app gets a refusal, not
        a silent drop: TCP ignores a local drop of its SYN and the app would hang until it times out
        (seen: 10 s); a reset makes connect() fail at once, and ICMP does the same for UDP."""
        lines = [
            "add counter %s c%do" % (APPS, n), "add counter %s c%di" % (APPS, n),
            "add chain %s a%do" % (APPS, n), "add chain %s a%di" % (APPS, n),
            "flush chain %s a%do" % (APPS, n), "flush chain %s a%di" % (APPS, n),
            "add rule %s a%do counter name \"c%do\"" % (APPS, n, n),
            "add rule %s a%di counter name \"c%di\"" % (APPS, n, n),
        ]
        if blocked:
            lines += ["add rule %s a%do meta l4proto tcp reject with tcp reset" % (APPS, n),
                      "add rule %s a%do reject with icmpx admin-prohibited" % (APPS, n)]
        return "\n".join(lines) + "\n"

    def element_script(self, op, level, path, n):
        return ("%s element %s out%d { %s : goto a%do }\n%s element %s in%d { %s : goto a%di }\n"
                % (op, APPS, level, quote(path), n, op, APPS, level, quote(path), n))

    def wan_counters(self):
        """{name: (packets, bytes)} of the firewall's internet counters (wan-<entry id> in inet quasar),
        read only when asked (Services' "From outside your home"). {} while the firewall is off."""
        ok, out, _ = self.run("list counters table %s" % FIREWALL, json_out=True)
        res = {}
        if not ok:
            return res
        try:
            for item in json.loads(out or "{}").get("nftables", []):
                c = item.get("counter")
                if c and c.get("table") == "quasar" and str(c.get("name", "")).startswith("wan-"):
                    res[c["name"]] = (int(c.get("packets", 0)), int(c.get("bytes", 0)))
        except (ValueError, AttributeError, TypeError):
            pass
        return res

    def counters(self, reset=False):
        """{name: bytes} of every named counter in our table."""
        ok, out, _ = self.run("%s counters table %s" % ("reset" if reset else "list", APPS), json_out=True)
        res = {}
        if not ok:
            return res
        try:
            for item in json.loads(out or "{}").get("nftables", []):
                c = item.get("counter")
                if c and c.get("table") == "quasar_apps":
                    res[c["name"]] = int(c.get("bytes", 0))
        except (ValueError, AttributeError):
            pass
        return res
