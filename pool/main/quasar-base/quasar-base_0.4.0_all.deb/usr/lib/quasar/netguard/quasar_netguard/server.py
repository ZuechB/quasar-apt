"""/run/quasar/netguard.sock: JSON lines for Settings (Network monitor) and the shell (prompts).

Every request is one JSON object on one line; every answer too. Who is asking comes from the kernel
(SO_PEERCRED), never from the request: a user only ever sees and changes their own apps.
Requests:
    {"op": "ping"}                              -> {"ok": true, "version": 1}
    {"op": "usage"}                             -> {"ok": true, "date", "rows": [...]}
    {"op": "block"|"unblock", "key": "app:ID"}  -> {"ok": true}            (your own apps; no password)
    {"op": "recent"}                            -> {"ok": true, "rows": [...]}  (refused connections)
    {"op": "subscribe"}                         -> {"ok": true}, then {"event": "prompt", ...} lines
    {"op": "snooze", "key": "app:ID"}           -> {"ok": true}            ("Not now")
    {"op": "wan"}                               -> {"ok": true, "type": "wan", "entries": [{"id": "svc:ID",
                                                    "packets", "bytes"}]}  (from outside the home network,
                                                    per firewall entry open to the internet: Services)
    {"op": "resync"}                            -> {"ok": true}            (root only)
Company accounts are turned away: their apps live in their own network and are counted as the company.
"""
import grp
import json
import os
import pwd
import socket
import struct
import time

MAX_CLIENTS = 32
MAX_LINE = 4096
MAX_OUT = 256 << 10
RATE = 20          # requests per second per client, on average


class Client:
    def __init__(self, sock, pid, uid, gid):
        self.sock, self.pid, self.uid, self.gid = sock, pid, uid, gid
        self.inbuf = b""
        self.outbuf = b""
        self.subscribed = False
        self.tokens = float(RATE)
        self.last = time.monotonic()

    def fileno(self):
        return self.sock.fileno()

    def allow_request(self):
        now = time.monotonic()
        self.tokens = min(float(RATE), self.tokens + (now - self.last) * RATE)
        self.last = now
        if self.tokens < 1:
            return False
        self.tokens -= 1
        return True


def _company_gid():
    try:
        return grp.getgrnam("quasar-companies").gr_gid
    except KeyError:
        return None


def is_company_account(uid, gid):
    try:
        pw = pwd.getpwuid(uid)
    except KeyError:
        return False
    if pw.pw_name.startswith("quasar-co-"):
        return True
    cg = _company_gid()
    return cg is not None and cg in os.getgrouplist(pw.pw_name, gid)


class Server:
    def __init__(self, path, handler, on_close=None):
        """handler(client, request) -> answer dict (or None for no answer)."""
        self.path = path
        self.handler = handler
        self.on_close = on_close
        self.clients = {}
        try:
            os.unlink(path)
        except FileNotFoundError:
            pass
        os.makedirs(os.path.dirname(path), exist_ok=True)
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM | socket.SOCK_NONBLOCK | socket.SOCK_CLOEXEC)
        self.sock.bind(path)
        os.chmod(path, 0o666)       # anyone may ask; answers depend on who asks (SO_PEERCRED)
        self.sock.listen(16)

    def fileno(self):
        return self.sock.fileno()

    def accept(self):
        try:
            s, _ = self.sock.accept()
        except (BlockingIOError, InterruptedError):
            return None
        s.setblocking(False)
        pid, uid, gid = struct.unpack("3i", s.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, struct.calcsize("3i")))
        if len(self.clients) >= MAX_CLIENTS or (uid != 0 and is_company_account(uid, gid)):
            s.close()
            return None
        c = Client(s, pid, uid, gid)
        self.clients[s.fileno()] = c
        return c

    def readable(self, c):
        try:
            data = c.sock.recv(8192)
        except (BlockingIOError, InterruptedError):
            return
        except OSError:
            data = b""
        if not data:
            self.close(c)
            return
        c.inbuf += data
        while b"\n" in c.inbuf:
            line, c.inbuf = c.inbuf.split(b"\n", 1)
            if len(line) > MAX_LINE:
                self.close(c)
                return
            if not line.strip():
                continue
            if not c.allow_request():
                self.send(c, {"ok": False, "error": "busy"})
                continue
            try:
                req = json.loads(line)
                if not isinstance(req, dict):
                    raise ValueError
            except ValueError:
                self.send(c, {"ok": False, "error": "bad request"})
                continue
            try:
                ans = self.handler(c, req)
            except Exception as e:        # one bad request must not take the service down
                ans = {"ok": False, "error": "internal error"}
                import sys
                print("netguard: request %r failed: %r" % (req.get("op"), e), file=sys.stderr, flush=True)
            if ans is not None:
                if "id" in req and isinstance(req["id"], (int, str)):
                    ans = dict(ans, id=req["id"])
                self.send(c, ans)
        if len(c.inbuf) > MAX_LINE:
            self.close(c)

    def send(self, c, obj):
        if c.sock.fileno() < 0:
            return
        c.outbuf += (json.dumps(obj, separators=(",", ":")) + "\n").encode()
        if len(c.outbuf) > MAX_OUT:
            self.close(c)
            return
        self.flush(c)

    def flush(self, c):
        while c.outbuf:
            try:
                n = c.sock.send(c.outbuf)
            except (BlockingIOError, InterruptedError):
                return
            except OSError:
                self.close(c)
                return
            c.outbuf = c.outbuf[n:]

    def broadcast(self, uid, obj):
        for c in list(self.clients.values()):
            if c.subscribed and c.uid == uid:
                self.send(c, obj)

    def subscribers(self, uid):
        return any(c.subscribed and c.uid == uid for c in self.clients.values())

    def flush_all(self):
        for c in list(self.clients.values()):
            if c.outbuf:
                self.flush(c)

    def close(self, c):
        fd = c.sock.fileno()
        if fd < 0:
            return
        self.clients.pop(fd, None)
        if self.on_close:
            self.on_close(c)          # while the socket is still open (the event loop unregisters it)
        try:
            c.sock.close()
        except OSError:
            pass

    def shutdown(self):
        for c in list(self.clients.values()):
            self.close(c)
        self.sock.close()
        try:
            os.unlink(self.path)
        except OSError:
            pass
