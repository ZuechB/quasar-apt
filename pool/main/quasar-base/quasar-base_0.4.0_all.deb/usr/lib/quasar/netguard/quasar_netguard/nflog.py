"""NFLOG: the packets the firewall refused, handed to us instead of the kernel log.

The firewall's input chain ends with
    meta l4proto { tcp, udp } fib daddr type local ct state new limit rate 30/minute … log group 7 snaplen 64
so every new connection to this PC that nothing allowed (rate-limited) arrives here with its first 64
bytes: enough for the addresses and ports. Nothing is written anywhere; netguard keeps the last few in
memory ("Recently blocked") and asks the user when an app is listening for them.
"""
import os
import select
import socket
import struct

NETLINK_NETFILTER = 12
NFNL_SUBSYS_ULOG = 4
NFULNL_MSG_PACKET, NFULNL_MSG_CONFIG = 0, 1
NFULA_CFG_CMD, NFULA_CFG_MODE = 1, 2
NFULNL_CFG_CMD_BIND = 1
NFULNL_COPY_PACKET = 2
NFULA_PACKET_HDR, NFULA_IFINDEX_INDEV, NFULA_PAYLOAD = 1, 4, 9
NLM_F_REQUEST, NLM_F_ACK = 1, 4
NLMSG_ERROR = 2
GROUP = 7


def _attr(t, payload):
    ln = 4 + len(payload)
    return struct.pack("=HH", ln, t) + payload + b"\0" * ((4 - ln % 4) % 4)


def _msg(mtype, flags, family, res_id, attrs, seq):
    body = struct.pack("=BBH", family, 0, socket.htons(res_id)) + attrs
    return struct.pack("=IHHII", 16 + len(body), mtype, flags, seq, 0) + body


def parse_attrs(data):
    out, i = {}, 0
    while i + 4 <= len(data):
        ln, t = struct.unpack_from("=HH", data, i)
        if ln < 4:
            break
        out[t & 0x3FFF] = data[i + 4:i + ln]
        i += (ln + 3) & ~3
    return out


def parse_packet(family, payload):
    """The IPv4/IPv6 + TCP/UDP header bytes -> {proto, src, dst, sport, dport}, or None."""
    p = payload
    if family == socket.AF_INET and len(p) >= 20 and p[0] >> 4 == 4:
        ihl = (p[0] & 15) * 4
        proto = p[9]
        src = socket.inet_ntop(socket.AF_INET, p[12:16])
        dst = socket.inet_ntop(socket.AF_INET, p[16:20])
        l4 = p[ihl:]
    elif family == socket.AF_INET6 and len(p) >= 40 and p[0] >> 4 == 6:
        proto = p[6]
        src = socket.inet_ntop(socket.AF_INET6, p[8:24])
        dst = socket.inet_ntop(socket.AF_INET6, p[24:40])
        l4 = p[40:]
    else:
        return None
    if proto not in (6, 17) or len(l4) < 4:
        return None
    sport, dport = struct.unpack_from("!HH", l4, 0)
    return {"proto": "tcp" if proto == 6 else "udp", "src": src, "dst": dst, "sport": sport, "dport": dport}


def parse_messages(data):
    """Netlink datagram -> list of packets ({…, "ifindex"}); acks and errors are skipped."""
    out, i = [], 0
    while i + 16 <= len(data):
        ln, mtype, _flags, _seq, _pid = struct.unpack_from("=IHHII", data, i)
        if ln < 16 or i + ln > len(data):
            break
        body = data[i + 16:i + ln]
        if mtype == (NFNL_SUBSYS_ULOG << 8) | NFULNL_MSG_PACKET and len(body) >= 4:
            family = body[0]
            a = parse_attrs(body[4:])
            pkt = parse_packet(family, a.get(NFULA_PAYLOAD, b""))
            if pkt:
                pkt["ifindex"] = struct.unpack("!I", a[NFULA_IFINDEX_INDEV])[0] if len(a.get(NFULA_IFINDEX_INDEV, b"")) == 4 else 0
                out.append(pkt)
        i += (ln + 3) & ~3
    return out


class Reader:
    """A bound NFLOG group. fileno() for the event loop, read() -> [packets]."""

    def __init__(self, group=GROUP):
        self.sock = socket.socket(socket.AF_NETLINK, socket.SOCK_RAW | socket.SOCK_NONBLOCK | socket.SOCK_CLOEXEC,
                                  NETLINK_NETFILTER)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 256 << 10)
        self.sock.bind((0, 0))
        mt = (NFNL_SUBSYS_ULOG << 8) | NFULNL_MSG_CONFIG
        self.sock.send(_msg(mt, NLM_F_REQUEST | NLM_F_ACK, socket.AF_UNSPEC, group,
                            _attr(NFULA_CFG_CMD, struct.pack("=B", NFULNL_CFG_CMD_BIND) + b"\0\0\0"), 1))
        self.sock.send(_msg(mt, NLM_F_REQUEST | NLM_F_ACK, socket.AF_UNSPEC, group,
                            _attr(NFULA_CFG_MODE, struct.pack("!IBB", 64, NFULNL_COPY_PACKET, 0)), 2))
        self._check_acks(2)

    def _check_acks(self, want):
        """Both config messages must be acknowledged with 0 (EPERM without CAP_NET_ADMIN, EBUSY when
        another program holds the group)."""
        got = 0
        while got < want:
            r, _, _ = select.select([self.sock], [], [], 1.0)
            if not r:
                raise OSError(110, "NFLOG didn't answer")
            data = self.sock.recv(65536)
            i = 0
            while i + 16 <= len(data):
                ln, mtype = struct.unpack_from("=IH", data, i)
                if ln < 16:
                    break
                if mtype == NLMSG_ERROR:
                    err = struct.unpack_from("=i", data, i + 16)[0]
                    if err:
                        self.sock.close()
                        raise OSError(-err, "NFLOG group %d: %s" % (GROUP, os.strerror(-err)))
                    got += 1
                i += (ln + 3) & ~3

    def fileno(self):
        return self.sock.fileno()

    def read(self):
        out = []
        while True:
            try:
                data = self.sock.recv(65536)
            except (BlockingIOError, InterruptedError):
                return out
            except OSError:           # ENOBUFS: we fell behind; what's lost is lost
                return out
            out.extend(parse_messages(data))

    def close(self):
        self.sock.close()
