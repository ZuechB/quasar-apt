"""Where quasar-netguard reads and keeps things.

Tests point QUASAR_NETGUARD_ROOT at a temporary folder (and QUASAR_NETGUARD_SOCK at a socket of their
own). Both are ignored when running as root: nobody redirects a root service.
"""
import os


def _is_root():
    geteuid = getattr(os, "geteuid", None)
    return geteuid is not None and geteuid() == 0


IS_ROOT = _is_root()
ROOT = "" if IS_ROOT else os.environ.get("QUASAR_NETGUARD_ROOT", "").rstrip("/")


def p(path):
    return ROOT + path if ROOT else path


CGROUP = p("/sys/fs/cgroup")
PROC = p("/proc")
STATE_DIR = p("/var/lib/quasar/netguard")
TODAY = STATE_DIR + "/today.json"          # today's totals per user and app (root only)
BLOCKED = STATE_DIR + "/blocked.json"      # apps each user blocked
RUN = p("/run/quasar")
SOCK = RUN + "/netguard.sock" if IS_ROOT else os.environ.get("QUASAR_NETGUARD_SOCK", RUN + "/netguard.sock")
INDEX = RUN + "/netguard-index.json"       # nft chain number -> (uid, app), for a restart after a crash
FIREWALL_DIR = p("/etc/quasar/firewall")
FIREWALL_CONFIG = FIREWALL_DIR + "/config.json"
FIREWALL_NET = RUN + "/firewall-net.json"
COMPANIES = p("/etc/quasar/companies.json")
COMPANY_CONF = p("/etc/quasar/companies")
SERVICES = p("/etc/quasar/services")       # Services' definitions (<id>.json): a server's name
FIREWALL_HELPER = "/usr/libexec/quasar/quasar-firewall"
