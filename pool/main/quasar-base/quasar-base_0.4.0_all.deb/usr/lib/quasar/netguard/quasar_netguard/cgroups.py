"""Which app a cgroup belongs to, and a watcher that sees scopes come and go (inotify on cgroupfs).

The shell starts every app in its own scope (shell/services/Apps.qml):
    user.slice/user-UID.slice/user@UID.service/app.slice/app-quasar-<desktop id>-<ms>.scope   level 5
Flatpak moves its apps into app-flatpak-<app id>-<pid>.scope next to it, and desktop autostart runs
app-<id>@autostart.service. Other user units (the shell itself, foot's server, portals) sit at level 5
too; the logind session (labwc and what its keybinds start) is user-UID.slice/session-N.scope, level 3.
System services are system.slice/X.service (level 2), or system.slice/system-T.slice/T@I.service for
template instances (level 3): a company's pasta, a site's slots, a server added in Services.

A key names what traffic is counted under:
    app:<desktop id>     an app (the only kind a user can block)
    unit:<name>          another part of the user's session
    sys:<name>           a system service (shared by everyone on this PC): sys:site:<id> a site,
                         sys:svc:<id> a server added in Services (quasar-svc@<id>)
    company:<id>         a company environment (all its traffic leaves through its pasta)
"""
import ctypes
import json
import os
import pwd
import re
import struct

from . import paths

APP_SCOPE = re.compile(r"^app-quasar-(.+)-(\d+)\.scope$")
APP_SCOPE_PLAIN = re.compile(r"^app-quasar-(.+)\.scope$")       # started by hand without the launcher's number
FLATPAK_SCOPE = re.compile(r"^app-flatpak-(.+)-(\d+)\.scope$")
AUTOSTART = re.compile(r"^app-(.+)@autostart\.service$")
# Quasar's own user services that act as an app (allow/block like one). Command Deck's server and
# Remote desktop's wayvnc: the firewall lets only them in from home networks (allow_app5), not anything
# else that takes their port.
SERVICE_APPS = {"quasar-commanddeck.service": "quasar-commanddeck", "quasar-vnc.service": "quasar-vnc"}
APP_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
SERVICE_ID = r"[a-z][a-z0-9-]{0,24}[a-z0-9]"        # Services' ids (svc-<id> fits useradd)
KEY_RE = re.compile(r"^(app:[A-Za-z0-9][A-Za-z0-9._-]{0,127}|unit:[A-Za-z0-9@._:-]{1,128}|"
                    r"sys:[A-Za-z0-9@._:-]{1,128}|company:[a-z0-9-]{1,24}|containers|other)$")

# Apps whose one scope runs everything a user types: an "allow" for them is a port, not the app.
TERMINALS = {"quasar-terminal", "foot", "footclient", "org.codeberg.dnkl.foot", "org.codeberg.dnkl.footclient"}

SYSTEM_LABELS = {
    "NetworkManager": "Network connection", "NetworkManager-dispatcher": "Network connection",
    "wpa_supplicant": "Wi-Fi", "avahi-daemon": "Device discovery", "cups": "Printing",
    "cups-browsed": "Printing", "ipp-usb": "Printing", "flatpak-system-helper": "App installs",
    "packagekit": "App installs", "quasar-sites-proxy": "Sites", "docker": "Docker", "containerd": "Docker",
    "bluetooth": "Bluetooth", "systemd-timesyncd": "Time", "fwupd": "Firmware updates",
    "ollama": "Quasar AI engine", "apt": "System updates",
}
UNIT_LABELS = {
    "quasar-shell": "Quasar shell", "foot-server": "Terminal", "session": "Desktop session",
    "dbus": "Desktop services", "pipewire": "Sound", "pipewire-pulse": "Sound", "wireplumber": "Sound",
    "xdg-desktop-portal": "Desktop portals", "xdg-desktop-portal-gtk": "Desktop portals",
    "xdg-desktop-portal-wlr": "Desktop portals", "gvfs-daemon": "Files", "quasar-driver-offer": "Drivers",
}
APP_LABELS = {"quasar-ai": "Quasar AI", "quasar-commanddeck": "Command Deck", "quasar-vnc": "Remote desktop"}


def unescape(name):
    """systemd unit-name escaping: \\x2d is '-'."""
    return re.sub(r"\\x([0-9a-fA-F]{2})", lambda m: chr(int(m.group(1), 16)), name)


def _unit_base(unit):
    u = unescape(unit)
    for suffix in (".service", ".scope", ".slice", ".socket"):
        if u.endswith(suffix):
            return u[:-len(suffix)]
    return u


def is_company_uid(uid):
    try:
        return pwd.getpwuid(uid).pw_name.startswith("quasar-co-")
    except KeyError:
        return False


def is_service_uid(uid):
    """The account of a server added in Services (svc-<id>, a system account)."""
    try:
        return re.fullmatch("svc-" + SERVICE_ID, pwd.getpwuid(uid).pw_name) is not None
    except KeyError:
        return False


def app_key(unit):
    """The key of a level-5 user unit, from its name."""
    if unit in SERVICE_APPS:
        return "app:" + SERVICE_APPS[unit]
    for rx in (APP_SCOPE, FLATPAK_SCOPE, AUTOSTART, APP_SCOPE_PLAIN):
        m = rx.match(unit)
        if m:
            app = unescape(m.group(1))
            if APP_ID.match(app):
                return "app:" + app
    base = _unit_base(unit)
    if base.startswith("app-"):                               # another launcher's app-…-<random>.scope
        return "unit:" + re.sub(r"[^A-Za-z0-9@._:-]", "_", base)[:128]
    return "unit:" + re.sub(r"[^A-Za-z0-9@._:-]", "_", base)[:128]


def system_key(unit):
    """The key of a system service (level 2) or template instance (level 3)."""
    base = _unit_base(unit)
    m = re.match(r"^quasar-company-pasta@([a-z0-9-]{1,24})$", base)
    if m:
        return "company:" + m.group(1)
    m = re.match(r"^quasar-site-(?:a|b|deploy|build)@(.+)$", base)
    if m:
        return "sys:site:" + re.sub(r"[^A-Za-z0-9._-]", "_", m.group(1))[:60]
    m = re.match(r"^quasar-svc@(%s)$" % SERVICE_ID, base)
    if m:
        return "sys:svc:" + m.group(1)
    if base.startswith("quasar-ollama"):
        return "sys:ollama"
    if base.startswith("apt-daily"):
        return "sys:apt"
    base = base.split("@", 1)[0]
    return "sys:" + re.sub(r"[^A-Za-z0-9@._:-]", "_", base)[:128]


def classify(rel):
    """A cgroup path (relative to the cgroup root) -> (level, uid, key), or None when it's not counted.
    uid is 0 for system services and companies (they're shared)."""
    parts = rel.strip("/").split("/")
    if len(parts) >= 3 and parts[0] == "user.slice":
        m = re.fullmatch(r"user-(\d+)\.slice", parts[1])
        if not m:
            return None
        uid = int(m.group(1))
        if uid < 1000 or is_company_uid(uid):
            return None
        if len(parts) >= 5 and parts[2] == "user@%d.service" % uid and parts[3].endswith(".slice"):
            return 5, uid, app_key(parts[4])
        if len(parts) == 3 and re.fullmatch(r"session-[A-Za-z0-9]+\.scope", parts[2]):
            return 3, uid, "unit:session"
        return None
    if len(parts) >= 2 and parts[0] == "system.slice":
        if len(parts) == 2 and parts[1].endswith(".service"):
            return 2, 0, system_key(parts[1])
        if len(parts) == 3 and parts[1].startswith("system-") and parts[1].endswith(".slice") \
                and parts[2].endswith(".service"):
            return 3, 0, system_key(parts[2])
    return None


FILE_APP = re.compile(r"^file\.(.+)\.[0-9a-f]{6}$")
_service_names = {}          # id -> (mtime, name): the definitions change rarely, labels are asked often


def service_name(sid):
    """A Services server's name, from its definition (root reads it); its id when that can't be read."""
    if not re.fullmatch(SERVICE_ID, sid):
        return sid
    path = os.path.join(paths.SERVICES, sid + ".json")
    try:
        mtime = os.stat(path).st_mtime
    except OSError:
        _service_names.pop(sid, None)
        return sid
    hit = _service_names.get(sid)
    if hit and hit[0] == mtime:
        return hit[1]
    try:
        with open(path, encoding="utf-8") as f:
            name = json.load(f).get("name")
    except (OSError, ValueError, AttributeError):
        name = None
    name = "".join(ch for ch in str(name or "") if ch.isprintable()).strip()[:60] or sid
    _service_names[sid] = (mtime, name)
    return name


def label(key):
    kind, _, name = key.partition(":")
    if kind == "app":
        # A program run from a file (program run: scope app-quasar-file.<name>.<hash>-<ms>): its name.
        m = FILE_APP.match(name)
        if m:
            return m.group(1)
        return APP_LABELS.get(name, name)
    if kind == "unit":
        return UNIT_LABELS.get(name, name)
    if kind == "sys":
        if name.startswith("site:"):
            return "Site " + name[5:]
        if name.startswith("svc:"):
            return service_name(name[4:])
        return SYSTEM_LABELS.get(name, name)
    if kind == "company":
        return name
    return {"containers": "Containers", "other": "Other"}.get(key, key)


def blockable(key):
    return key.startswith("app:")


def port_allow_only(key):
    """Terminal-like apps (everything typed runs in one scope) and non-apps get a port allow."""
    return not key.startswith("app:") or key[4:] in TERMINALS


# ---------------------------------------------------------------------------------------- watching
IN_CREATE, IN_DELETE, IN_DELETE_SELF, IN_IGNORED, IN_Q_OVERFLOW = 0x100, 0x200, 0x400, 0x8000, 0x4000
IN_ISDIR, IN_ONLYDIR = 0x40000000, 0x01000000
IN_NONBLOCK, IN_CLOEXEC = os.O_NONBLOCK, os.O_CLOEXEC


class Watcher:
    """inotify over the parts of the cgroup tree where counted units appear.
    on_add(rel) / on_remove(rel) get cgroup paths relative to the root."""

    def __init__(self, root, on_add, on_remove):
        self.root = root.rstrip("/")
        self.on_add, self.on_remove = on_add, on_remove
        self.libc = ctypes.CDLL(None, use_errno=True)
        self.fd = self.libc.inotify_init1(IN_NONBLOCK | IN_CLOEXEC)
        if self.fd < 0:
            raise OSError(ctypes.get_errno(), "inotify_init1")
        self.wds = {}           # wd -> rel dir
        self.dirs = {}          # rel dir -> wd

    def fileno(self):
        return self.fd

    def _watch(self, rel):
        if rel in self.dirs:
            return
        path = os.path.join(self.root, rel) if rel else self.root
        wd = self.libc.inotify_add_watch(self.fd, path.encode(), IN_CREATE | IN_DELETE | IN_ONLYDIR)
        if wd >= 0:
            self.wds[wd] = rel
            self.dirs[rel] = wd

    def _kind(self, rel):
        """What a directory is to us: 'watch' (look inside), 'unit' (counted), or None."""
        parts = rel.split("/")
        if parts[0] == "user.slice":
            if len(parts) == 1:
                return "watch"
            if len(parts) == 2:
                return "watch" if re.fullmatch(r"user-\d+\.slice", parts[1]) else None
            m = re.fullmatch(r"user-(\d+)\.slice", parts[1])
            if not m:
                return None
            uid = int(m.group(1))
            if len(parts) == 3:
                if parts[2] == "user@%d.service" % uid:
                    return "watch"
                return "unit" if parts[2].startswith("session-") else None
            if len(parts) == 4 and parts[2] == "user@%d.service" % uid:
                return "watch" if parts[3].endswith(".slice") else None
            if len(parts) == 5 and parts[2] == "user@%d.service" % uid:
                return "unit"
            return None
        if parts[0] == "system.slice":
            if len(parts) == 1:
                return "watch"
            if len(parts) == 2:
                if parts[1].endswith(".service"):
                    return "unit"
                return "watch" if parts[1].startswith("system-") and parts[1].endswith(".slice") else None
            if len(parts) == 3 and parts[2].endswith(".service"):
                return "unit"
        return None

    def _scan(self, rel):
        """Watch rel and report every unit below it (start, or a directory we just learned about)."""
        kind = self._kind(rel) if rel else "watch"
        if kind == "unit":
            self.on_add(rel)
            return
        if kind != "watch":
            return
        self._watch(rel)
        try:
            names = sorted(e.name for e in os.scandir(os.path.join(self.root, rel)) if e.is_dir(follow_symlinks=False))
        except OSError:
            return
        for n in names:
            child = rel + "/" + n if rel else n
            if self._kind(child):
                self._scan(child)

    def start(self):
        for top in ("user.slice", "system.slice"):
            if os.path.isdir(os.path.join(self.root, top)):
                self._scan(top)

    def read(self):
        """Handle what's waiting. Returns True when events were lost (the caller rescans)."""
        try:
            buf = os.read(self.fd, 65536)
        except BlockingIOError:
            return False
        i, lost = 0, False
        while i + 16 <= len(buf):
            wd, mask, _cookie, ln = struct.unpack_from("=iIII", buf, i)
            name = buf[i + 16:i + 16 + ln].rstrip(b"\0").decode("utf-8", "replace")
            i += 16 + ln
            if mask & IN_Q_OVERFLOW:
                lost = True
                continue
            if mask & IN_IGNORED:
                rel = self.wds.pop(wd, None)
                if rel is not None:
                    self.dirs.pop(rel, None)
                continue
            parent = self.wds.get(wd)
            if parent is None or not name:
                continue
            rel = parent + "/" + name
            kind = self._kind(rel)
            if mask & IN_CREATE and kind:
                self._scan(rel)
            elif mask & IN_DELETE and kind == "unit":
                self.on_remove(rel)
        return lost

    def rescan(self):
        self.start()

    def close(self):
        os.close(self.fd)
