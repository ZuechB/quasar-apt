"""Today's internet use per user and app, and the apps each user blocked.

Only today is kept: at local midnight the counts start over, and nothing older is stored anywhere.
The kernel counts in nftables named counters (one pair per (uid, key)), from when netguard created its
table. today.json holds `base` (what earlier tables counted) and `snap` (the current table's counters
when last saved), so nothing is lost or counted twice:
  * netguard restarted after a crash: its table survived, so base + the table's counters now;
  * the PC restarted: the table is gone, so base + the last snapshot.
"""
import json
import os
import time

from . import paths


def today(now=None):
    return time.strftime("%Y-%m-%d", time.localtime(now))


def _write_private(path, obj):
    os.makedirs(os.path.dirname(path), mode=0o700, exist_ok=True)
    tmp = path + ".tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(obj, f)
    os.replace(tmp, path)


def _pack(d):
    out = {}
    for (uid, key), (rx, tx) in d.items():
        if rx or tx:
            out.setdefault(str(uid), {})[key] = [rx, tx]
    return out


def _unpack(d):
    out = {}
    for uid, keys in (d or {}).items():
        if not isinstance(keys, dict):
            continue
        for key, v in keys.items():
            try:
                out[(int(uid), str(key))] = [int(v[0]), int(v[1])]
            except (ValueError, TypeError, IndexError):
                continue
    return out


class Usage:
    def __init__(self, clock=time.time):
        self.clock = clock
        self.date = today(clock())
        self.base = {}          # (uid, key) -> [rx, tx] counted by earlier tables today

    def load(self, survivors=None):
        """Today's file. survivors: the counters of a table that outlived the last run (a crash);
        None when there's no such table (then the last snapshot stands in for it)."""
        try:
            with open(paths.TODAY, encoding="utf-8") as f:
                d = json.load(f)
        except (OSError, ValueError):
            d = {}
        if d.get("date") != self.date:
            d = {}
        self.base = _unpack(d.get("base"))
        extra = survivors if survivors is not None else _unpack(d.get("snap"))
        for k, (rx, tx) in extra.items():
            self.add(k[0], k[1], rx, tx)

    def add(self, uid, key, rx, tx):
        b = self.base.setdefault((uid, key), [0, 0])
        b[0] += rx
        b[1] += tx

    def totals(self, live):
        """base + the live counters ({(uid, key): [rx, tx]})."""
        out = {k: list(v) for k, v in self.base.items()}
        for k, (rx, tx) in live.items():
            b = out.setdefault(k, [0, 0])
            b[0] += rx
            b[1] += tx
        return out

    def save(self, live):
        _write_private(paths.TODAY, {"date": self.date, "base": _pack(self.base), "snap": _pack(live)})

    def fold(self, live):
        """The table goes away (clean stop): its counts become part of base."""
        for k, (rx, tx) in live.items():
            self.add(k[0], k[1], rx, tx)

    def rolled_over(self):
        """True (once) when the local date changed: the caller resets the kernel counters."""
        d = today(self.clock())
        if d == self.date:
            return False
        self.date = d
        self.base = {}
        return True


class Blocked:
    """{uid: set(keys)}: what each user blocked (their own choice, persisted)."""

    def __init__(self):
        self.by_uid = {}

    def load(self):
        try:
            with open(paths.BLOCKED, encoding="utf-8") as f:
                d = json.load(f)
            self.by_uid = {int(u): set(k for k in keys if isinstance(k, str)) for u, keys in d.items()}
        except (OSError, ValueError, AttributeError, TypeError):
            self.by_uid = {}

    def save(self):
        _write_private(paths.BLOCKED, {str(u): sorted(k) for u, k in self.by_uid.items() if k})

    def has(self, uid, key):
        return key in self.by_uid.get(uid, ())

    def set(self, uid, key, on):
        s = self.by_uid.setdefault(uid, set())
        changed = (key in s) != on
        (s.add if on else s.discard)(key)
        return changed
