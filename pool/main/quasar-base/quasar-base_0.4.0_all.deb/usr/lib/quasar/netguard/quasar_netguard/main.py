"""quasar-netguard: the service (quasar-netguard.service, root). See the package docstring.

  quasar-netguard [serve]

One event loop, idle in poll() until something happens: an app scope appears or goes (inotify on
cgroupfs), the firewall refuses a connection (NFLOG), the firewall's config changes (inotify), an
address changes on a home network (rtnetlink), or Settings / the shell ask something on the socket.
"""
import ctypes
import json
import os
import selectors
import signal
import socket
import struct
import subprocess
import sys
import time
from collections import deque

from . import cgroups, listeners, nflog, paths
from . import nft as nftmod
from .server import Server
from .usage import Blocked, Usage

PERSIST_EVERY = 900          # seconds between saves of today's totals
REBUILD_DELAY = 1.0          # after a scope ends, rebuild the maps (batched)
NET_DELAY = 2.0              # after an address change on a home network, re-run net-changed
PROMPT_REPEAT = 600          # don't ask about the same app and port more often than this
SNOOZE = 12 * 3600           # "Not now" lasts until the session ends, at most this long
APPS = nftmod.APPS


def log(msg):
    print("netguard: " + msg, file=sys.stderr, flush=True)


def sd_notify(msg):
    addr = os.environ.get("NOTIFY_SOCKET")
    if not addr:
        return
    if addr.startswith("@"):
        addr = "\0" + addr[1:]
    try:
        with socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM) as s:
            s.sendto(msg.encode(), addr)
    except OSError:
        pass


class DirWatch:
    """inotify on one directory for files written or moved into it."""
    IN_CLOSE_WRITE, IN_MOVED_TO, IN_CREATE = 0x8, 0x80, 0x100

    def __init__(self, path):
        self.libc = ctypes.CDLL(None, use_errno=True)
        self.fd = self.libc.inotify_init1(os.O_NONBLOCK | os.O_CLOEXEC)
        if self.fd < 0:
            raise OSError(ctypes.get_errno(), "inotify_init1")
        os.makedirs(path, exist_ok=True)
        self.wd = self.libc.inotify_add_watch(self.fd, path.encode(), self.IN_CLOSE_WRITE | self.IN_MOVED_TO | self.IN_CREATE)

    def fileno(self):
        return self.fd

    def names(self):
        try:
            buf = os.read(self.fd, 16384)
        except BlockingIOError:
            return []
        out, i = [], 0
        while i + 16 <= len(buf):
            _wd, _mask, _cookie, ln = struct.unpack_from("=iIII", buf, i)
            out.append(buf[i + 16:i + 16 + ln].rstrip(b"\0").decode("utf-8", "replace"))
            i += 16 + ln
        return out


class Rtnl:
    """Address changes (rtnetlink): SLAAC renumbering of a home network has no NetworkManager event."""
    RTMGRP_IPV4_IFADDR, RTMGRP_IPV6_IFADDR = 0x10, 0x100
    RTM_NEWADDR, RTM_DELADDR = 20, 21

    def __init__(self):
        self.sock = socket.socket(socket.AF_NETLINK, socket.SOCK_RAW | socket.SOCK_NONBLOCK | socket.SOCK_CLOEXEC,
                                  socket.NETLINK_ROUTE)
        self.sock.bind((0, self.RTMGRP_IPV4_IFADDR | self.RTMGRP_IPV6_IFADDR))

    def fileno(self):
        return self.sock.fileno()

    def ifindexes(self):
        out = set()
        while True:
            try:
                data = self.sock.recv(65536)
            except (BlockingIOError, InterruptedError):
                return out
            except OSError:
                return out
            i = 0
            while i + 24 <= len(data):
                ln, mtype = struct.unpack_from("=IH", data, i)
                if ln < 16:
                    break
                if mtype in (self.RTM_NEWADDR, self.RTM_DELADDR):
                    out.add(struct.unpack_from("=I", data, i + 16 + 4)[0])
                i += (ln + 3) & ~3


class Daemon:
    def __init__(self, nft=None, clock=time.time, mono=time.monotonic):
        self.nft = nft or nftmod.Nft()
        self.clock, self.mono = clock, mono
        self.usage = Usage(clock)
        self.blocked = Blocked()
        self.slots = {}            # (uid, key) -> chain number
        self.next_slot = 1
        self.cgroups = {}          # cgroup path -> (level, uid, key)
        self.allowed_apps = set()
        self.wan_ids = []          # firewall entries open to the internet (Services), in config order
        self.recent = deque(maxlen=50)
        self.prompted = {}         # (uid, key, port) -> when
        self.snoozed = {}          # (uid, key) -> until
        self.seen = {}             # (src, sport, dport, proto) -> when (retransmitted SYNs)
        self.rebuild_at = None
        self.net_at = None
        self.net_proc = None
        self.persist_at = None
        self.resync_wanted = False
        self.running = True
        self.sel = selectors.DefaultSelector()
        self.server = self.watcher = self.nflog = self.fwwatch = self.rtnl = None

    # ------------------------------------------------------------------------------------ setup
    def start(self, listen=True):
        self.blocked.load()
        self.usage.load(self.survivors())
        ok, _, err = self.nft.create()
        if not ok:
            raise RuntimeError("couldn't create %s: %s" % (APPS, err.strip()))
        self.slots, self.next_slot = {}, 1
        self.write_index()
        self.usage.save({})
        self.read_firewall_config()
        self.watcher = cgroups.Watcher(paths.CGROUP, self.register, self.unregister)
        self.watcher.start()
        self.sync_allow()
        self.sel.register(self.watcher, selectors.EVENT_READ, self.on_cgroups)
        for name, make, cb in (("NFLOG", nflog.Reader, self.on_nflog), ("firewall config", lambda: DirWatch(paths.FIREWALL_DIR), self.on_fwconfig),
                               ("rtnetlink", Rtnl, self.on_addresses)):
            try:
                obj = make()
                self.sel.register(obj, selectors.EVENT_READ, cb)
                setattr(self, {"NFLOG": "nflog", "firewall config": "fwwatch", "rtnetlink": "rtnl"}[name], obj)
            except OSError as e:
                log("no %s: %s" % (name, e))
        if listen:
            self.server = Server(paths.SOCK, self.handle, self.on_client_close)
            self.sel.register(self.server, selectors.EVENT_READ, self.on_accept)
        self.persist_at = self.mono() + PERSIST_EVERY

    def survivors(self):
        """Counters of a table left behind by a crashed run, by (uid, key); None if there's none."""
        try:
            with open(paths.INDEX, encoding="utf-8") as f:
                index = json.load(f).get("slots", {})
        except (OSError, ValueError):
            return None
        if not self.nft.exists():
            return None
        c = self.nft.counters()
        out = {}
        for n, (uid, key) in index.items():
            rx, tx = c.get("c%si" % n, 0), c.get("c%so" % n, 0)
            if rx or tx:
                out[(int(uid), key)] = [rx, tx]
        for key, i, o in (("other", "other_i", "other_o"), ("containers", "cont_i", "cont_o")):
            if c.get(i) or c.get(o):
                out[(0, key)] = [c.get(i, 0), c.get(o, 0)]
        log("recovered today's counts from the previous run's table")
        return out

    def write_index(self):
        os.makedirs(os.path.dirname(paths.INDEX), exist_ok=True)
        tmp = paths.INDEX + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"slots": {str(n): [uid, key] for (uid, key), n in self.slots.items()}}, f)
        os.chmod(tmp, 0o600)
        os.replace(tmp, paths.INDEX)

    # ------------------------------------------------------------------------------------ cgroups
    def slot(self, uid, key):
        n = self.slots.get((uid, key))
        if n is None:
            n = self.next_slot
            self.next_slot += 1
            self.slots[(uid, key)] = n
            ok, _, err = self.nft.run(self.nft.slot_script(n, self.blocked.has(uid, key)))
            if not ok:
                log("slot %d for %s: %s" % (n, key, err.strip()))
            self.write_index()
        return n

    def register(self, rel):
        c = cgroups.classify(rel)
        if not c:
            return
        level, uid, key = c
        n = self.slot(uid, key)
        ok, _, _ = self.nft.run(self.nft.element_script("add", level, rel, n))
        if not ok:                     # gone again before we got to it
            return
        self.cgroups[rel] = c
        if level == 5 and key.startswith("app:") and key[4:] in self.allowed_apps:
            self.nft.run("add element %s allow_app5 { %s }\n" % (nftmod.FIREWALL, nftmod.quote(rel)))

    def unregister(self, rel):
        if self.cgroups.pop(rel, None) is not None:
            self.rebuild_at = self.rebuild_at or self.mono() + REBUILD_DELAY

    def rebuild_maps(self):
        """A removed cgroup's element can't be named any more: flush the maps and add the live ones."""
        self.rebuild_at = None
        flush = "".join("flush map %s %s%d\n" % (APPS, d, lv) for lv in nftmod.LEVELS for d in ("out", "in"))
        live = []
        for rel, (level, uid, key) in list(self.cgroups.items()):
            if os.path.isdir(os.path.join(paths.CGROUP, rel)):
                live.append((rel, level, self.slots[(uid, key)]))
            else:
                self.cgroups.pop(rel, None)
        ok, _, _ = self.nft.run(flush + "".join(self.nft.element_script("add", lv, rel, n) for rel, lv, n in live))
        if not ok:                     # one vanished meanwhile: one at a time
            self.nft.run(flush)
            for rel, lv, n in live:
                if not self.nft.run(self.nft.element_script("add", lv, rel, n))[0]:
                    self.cgroups.pop(rel, None)
        self.sync_allow()

    def on_cgroups(self):
        if self.watcher.read():
            self.watcher.rescan()

    # ------------------------------------------------------------------------------------ the firewall's allowed apps
    def read_firewall_config(self):
        try:
            with open(paths.FIREWALL_CONFIG, encoding="utf-8") as f:
                conf = json.load(f)
            allowed = [a for a in conf.get("allowed") or [] if isinstance(a, dict)]
            self.allowed_apps = {str(a["app"]) for a in allowed if a.get("app")}
            self.wan_ids = [str(a["id"]) for a in allowed if a.get("internet") and a.get("id")]
        except (OSError, ValueError, KeyError, AttributeError):
            self.allowed_apps = set()
            self.wan_ids = []

    def wan(self):
        """Packets and bytes from outside the home network, per firewall entry open to the internet (the
        firewall's named counters wan-<entry id>; quasar-firewall's counter_name)."""
        counters = self.nft.wan_counters()
        rows = []
        for eid in self.wan_ids:
            hit = counters.get("wan-" + eid.replace(":", "-"))
            if hit:
                rows.append({"id": eid, "packets": hit[0], "bytes": hit[1]})
        return rows

    def sync_allow(self):
        if not self.nft.exists(nftmod.FIREWALL):
            return
        rels = [rel for rel, (level, _uid, key) in self.cgroups.items()
                if level == 5 and key.startswith("app:") and key[4:] in self.allowed_apps]
        script = "flush set %s allow_app5\n" % nftmod.FIREWALL
        if rels:
            script += "add element %s allow_app5 { %s }\n" % (nftmod.FIREWALL, ", ".join(nftmod.quote(r) for r in rels))
        if not self.nft.run(script)[0]:
            self.nft.run("flush set %s allow_app5\n" % nftmod.FIREWALL)
            for r in rels:
                self.nft.run("add element %s allow_app5 { %s }\n" % (nftmod.FIREWALL, nftmod.quote(r)))

    def on_fwconfig(self):
        if "config.json" in self.fwwatch.names():
            self.read_firewall_config()
            self.sync_allow()

    def resync(self):
        self.read_firewall_config()
        self.blocked.load()
        for (uid, key), n in self.slots.items():
            self.nft.run(self.nft.slot_script(n, self.blocked.has(uid, key)))
        self.watcher.rescan()
        self.rebuild_maps()

    # ------------------------------------------------------------------------------------ usage
    def live_counters(self):
        c = self.nft.counters()
        out = {}
        for (uid, key), n in self.slots.items():
            rx, tx = c.get("c%di" % n, 0), c.get("c%do" % n, 0)
            if rx or tx:
                out[(uid, key)] = [rx, tx]
        for key, i, o in (("other", "other_i", "other_o"), ("containers", "cont_i", "cont_o")):
            if c.get(i) or c.get(o):
                out[(0, key)] = [c.get(i, 0), c.get(o, 0)]
        return out

    def company_owner(self, cid):
        try:
            with open(os.path.join(paths.COMPANY_CONF, cid + ".conf"), encoding="utf-8") as f:
                for line in f:
                    if line.startswith("OWNER_UID="):
                        return int(line.split("=", 1)[1].strip().strip('"'))
        except (OSError, ValueError):
            pass
        return None

    def rows(self, uid):
        running = {(u, k) for (_lv, u, k) in self.cgroups.values()}
        out = {}
        for (u, key), (rx, tx) in self.usage.totals(self.live_counters()).items():
            mine = u == uid and key.split(":", 1)[0] in ("app", "unit")
            shared = u == 0 and (key.startswith("sys:") or key in ("containers", "other"))
            company = u == 0 and key.startswith("company:") and self.company_owner(key[8:]) == uid
            if mine or shared or company:
                out[key] = {"key": key, "kind": key.split(":", 1)[0], "id": key.split(":", 1)[1] if ":" in key else key,
                            "label": cgroups.label(key), "rx": rx, "tx": tx, "blocked": self.blocked.has(uid, key),
                            "blockable": mine and cgroups.blockable(key), "running": (u, key) in running,
                            "system": shared or company}
        for key in self.blocked.by_uid.get(uid, ()):
            if key not in out:
                out[key] = {"key": key, "kind": "app", "id": key[4:], "label": cgroups.label(key), "rx": 0, "tx": 0,
                            "blocked": True, "blockable": True, "running": (uid, key) in running, "system": False}
        return sorted(out.values(), key=lambda r: -(r["rx"] + r["tx"]))

    def set_blocked(self, uid, key, on):
        if self.blocked.set(uid, key, on):
            self.blocked.save()
        n = self.slots.get((uid, key))
        if n is not None:
            self.nft.run(self.nft.slot_script(n, on))

    def persist(self):
        self.persist_at = self.mono() + PERSIST_EVERY
        if self.usage.rolled_over():
            self.nft.counters(reset=True)          # yesterday's counts go; nothing older is kept
            self.usage.save({})
            return
        self.usage.save(self.live_counters())

    # ------------------------------------------------------------------------------------ refused connections
    def network_for(self, iface):
        try:
            with open(paths.FIREWALL_NET, encoding="utf-8") as f:
                conns = json.load(f).get("connections") or []
        except (OSError, ValueError, AttributeError):
            return None
        for c in conns:
            if isinstance(c, dict) and c.get("device") == iface:
                return {"uuid": c.get("uuid", ""), "name": c.get("name", ""), "home": bool(c.get("home")),
                        "state": c.get("state", "public")}
        return None

    def on_blocked(self, pkt):
        now = self.mono()
        sig = (pkt["src"], pkt["sport"], pkt["dport"], pkt["proto"])
        if now - self.seen.get(sig, -1e9) < 10:
            return
        self.seen[sig] = now
        if len(self.seen) > 512:
            self.seen = {k: t for k, t in self.seen.items() if now - t < 10}
        iface = listeners.ifname(pkt.get("ifindex", 0))
        net = self.network_for(iface)
        entry = {"time": int(self.clock()), "from": pkt["src"], "port": pkt["dport"], "proto": pkt["proto"],
                 "iface": iface, "network": net["name"] if net else "", "key": "", "label": "", "uid": None}
        c = None
        hit = listeners.find_listener(pkt["proto"], pkt["dport"], pkt["dst"])
        if hit:
            uid, inode = hit
            if uid >= 1000 or cgroups.is_service_uid(uid):     # a Services server: named, never prompted
                pid = listeners.pid_of_socket(uid, inode)
                rel = listeners.cgroup_of(pid) if pid else ""
                c = cgroups.classify(rel) if rel else None
            entry["key"] = c[2] if c else "sys:system"
            entry["label"] = cgroups.label(c[2]) if c else "A system service"
            entry["uid"] = c[1] if c else 0
        self.recent.appendleft(entry)
        if c and c[1] >= 1000:
            self.maybe_prompt(c[1], c[2], pkt, iface)

    def maybe_prompt(self, uid, key, pkt, iface):
        if not self.server or not self.server.subscribers(uid) or self.blocked.has(uid, key):
            return
        now = self.mono()
        if self.snoozed.get((uid, key), 0) > now:
            return
        k = (uid, key, pkt["dport"])
        if now - self.prompted.get(k, -1e9) < PROMPT_REPEAT:
            return
        self.prompted[k] = now
        self.server.broadcast(uid, {
            "event": "prompt", "key": key, "label": cgroups.label(key), "app": key[4:] if key.startswith("app:") else "",
            "kind": "port" if cgroups.port_allow_only(key) else "app", "port": pkt["dport"], "proto": pkt["proto"],
            "from": pkt["src"], "network": self.network_for(iface), "allowed": key[4:] in self.allowed_apps})

    def on_nflog(self):
        for pkt in self.nflog.read():
            self.on_blocked(pkt)

    def on_addresses(self):
        changed = self.rtnl.ifindexes()
        if not changed:
            return
        try:
            with open(paths.FIREWALL_NET, encoding="utf-8") as f:
                homes = {c.get("device") for c in json.load(f).get("connections") or [] if c.get("home")}
        except (OSError, ValueError, AttributeError):
            return
        if {listeners.ifname(i) for i in changed} & homes:
            self.net_at = self.net_at or self.mono() + NET_DELAY

    def run_net_changed(self):
        self.net_at = None
        if self.net_proc and self.net_proc.poll() is None:
            self.net_at = self.mono() + NET_DELAY      # one at a time
            return
        try:
            self.net_proc = subprocess.Popen([paths.FIREWALL_HELPER, "net-changed"], stdin=subprocess.DEVNULL,
                                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except OSError as e:
            log("net-changed: %s" % e)

    # ------------------------------------------------------------------------------------ the socket
    def handle(self, c, req):
        op = req.get("op")
        if op == "ping":
            return {"ok": True, "version": 1}
        if op == "usage":
            return {"ok": True, "date": self.usage.date, "rows": self.rows(c.uid)}
        if op in ("block", "unblock"):
            key = str(req.get("key", ""))
            if c.uid == 0 or not cgroups.KEY_RE.match(key) or not cgroups.blockable(key):
                return {"ok": False, "error": "That can't be blocked."}
            self.set_blocked(c.uid, key, op == "block")
            return {"ok": True}
        if op == "recent":
            return {"ok": True, "rows": [dict(r, mine=r.get("uid") == c.uid) for r in self.recent]}
        if op == "wan":
            # Shared like sys: rows (what this PC offers the internet isn't private to one account).
            return {"ok": True, "type": "wan", "entries": self.wan()}
        if op == "subscribe":
            c.subscribed = True
            return {"ok": True}
        if op == "snooze":
            key = str(req.get("key", ""))
            if not cgroups.KEY_RE.match(key):
                return {"ok": False, "error": "bad key"}
            self.snoozed[(c.uid, key)] = self.mono() + SNOOZE
            return {"ok": True}
        if op == "resync":
            if c.uid != 0:
                return {"ok": False, "error": "not allowed"}
            self.resync_wanted = True
            return {"ok": True}
        return {"ok": False, "error": "unknown request"}

    def on_accept(self):
        cl = self.server.accept()
        if cl:
            self.sel.register(cl.sock, selectors.EVENT_READ, lambda cl=cl: self.server.readable(cl))

    def on_client_close(self, cl):
        try:
            self.sel.unregister(cl.sock)
        except (KeyError, ValueError):
            pass
        if cl.subscribed and not any(o.subscribed and o.uid == cl.uid for o in self.server.clients.values()):
            self.snoozed = {k: t for k, t in self.snoozed.items() if k[0] != cl.uid}      # the session ended

    # ------------------------------------------------------------------------------------ loop
    def timeout(self):
        now = self.mono()
        due = [t for t in (self.rebuild_at, self.net_at, self.persist_at) if t is not None]
        return max(0.0, min([60.0] + [t - now for t in due]))

    def tick(self):
        now = self.mono()
        if self.rebuild_at is not None and now >= self.rebuild_at:
            self.rebuild_maps()
        if self.net_at is not None and now >= self.net_at:
            self.run_net_changed()
        if self.persist_at is not None and now >= self.persist_at:
            self.persist()
        elif self.usage.date != time.strftime("%Y-%m-%d", time.localtime(self.clock())):
            self.persist()
        if self.resync_wanted:
            self.resync_wanted = False
            self.resync()
        if self.net_proc and self.net_proc.poll() is not None:
            self.net_proc = None
        if self.server:
            self.server.flush_all()

    def loop(self):
        rfd, wfd = os.pipe2(os.O_NONBLOCK | os.O_CLOEXEC)
        signal.set_wakeup_fd(wfd)
        self.sel.register(rfd, selectors.EVENT_READ, lambda: os.read(rfd, 512))

        def stop(*_):
            self.running = False

        def hup(*_):
            self.resync_wanted = True
        signal.signal(signal.SIGTERM, stop)
        signal.signal(signal.SIGINT, stop)
        signal.signal(signal.SIGHUP, hup)
        while self.running:
            for key, _ in self.sel.select(self.timeout()):
                key.data()
            self.tick()
        self.stop()

    def stop(self):
        """Clean stop: today's counts are kept, the table goes (blocks are lifted while we're away)."""
        try:
            self.usage.fold(self.live_counters())
            self.usage.save({})
        except OSError as e:
            log("couldn't save today's counts: %s" % e)
        self.nft.delete()
        try:
            os.unlink(paths.INDEX)
        except OSError:
            pass
        if self.server:
            self.server.shutdown()


def main(argv):
    if argv not in ([], ["serve"]):
        sys.stderr.write(__doc__)
        return 64
    d = Daemon()
    try:
        d.start()
    except (RuntimeError, OSError) as e:
        log("can't start: %s" % e)
        return 1
    sd_notify("READY=1")
    log("running")
    d.loop()
    return 0
