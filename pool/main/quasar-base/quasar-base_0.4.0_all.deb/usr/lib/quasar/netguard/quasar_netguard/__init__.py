"""quasar-netguard: the per-app half of Quasar's firewall (Settings › Network & Internet).

  * which app used how much of the internet today (Network monitor), counted per app scope;
  * blocking an app from the network (the user's own apps, no password: it only restricts);
  * keeping the firewall's "allowed apps" set current (allowed apps are matched by the cgroup of
    their running scopes, which come and go);
  * asking the user when the firewall stopped a connection an app on this PC was waiting for.

A root service (quasar-netguard.service). It owns the nftables table `inet quasar_apps` and talks to
Settings and the shell over /run/quasar/netguard.sock (JSON lines). Python standard library only.
"""
