"""Who is listening for a refused connection: socket -> owner uid -> process -> cgroup.

Only looked up when the firewall refused something (rate-limited by the ruleset), never polled.
"""
import ipaddress
import os
import socket

from . import paths

TCP_LISTEN, UDP_UNCONNECTED = "0A", "07"


def _addr(hexaddr):
    """/proc/net/tcp's address column -> an ipaddress object."""
    raw = bytes.fromhex(hexaddr)
    if len(raw) == 4:
        return ipaddress.IPv4Address(raw[::-1])
    # IPv6: four 32-bit words, each in host (little-endian) order
    words = [raw[i:i + 4][::-1] for i in range(0, 16, 4)]
    return ipaddress.IPv6Address(b"".join(words))


def parse_proc_net(text, state):
    """Lines of /proc/net/{tcp,udp}{,6} in `state` -> [(ip, port, uid, inode)]."""
    out = []
    for line in text.splitlines()[1:]:
        f = line.split()
        if len(f) < 10 or f[3] != state:
            continue
        ip, port = f[1].split(":")
        try:
            out.append((_addr(ip), int(port, 16), int(f[7]), int(f[9])))
        except ValueError:
            continue
    return out


def find_listener(proto, port, dst):
    """The socket that would have taken a connection to dst:port -> (uid, inode) or None.
    A loopback-only listener doesn't count (the network can't reach it anyway)."""
    try:
        want = ipaddress.ip_address(dst)
    except ValueError:
        want = None
    state = TCP_LISTEN if proto == "tcp" else UDP_UNCONNECTED
    best = None
    for name in (proto, proto + "6"):
        try:
            with open(os.path.join(paths.PROC, "net", name), encoding="ascii") as f:
                rows = parse_proc_net(f.read(), state)
        except OSError:
            continue
        for ip, p, uid, inode in rows:
            if p != port or inode == 0 or ip.is_loopback:
                continue
            exact = want is not None and (ip == want or (ip.version == 6 and ip.ipv4_mapped == want))
            if exact or ip.is_unspecified:
                if exact or best is None:
                    best = (uid, inode)
    return best


def pid_of_socket(uid, inode):
    """The process holding socket:[inode], looking only at that user's processes."""
    target = "socket:[%d]" % inode
    try:
        pids = [e.name for e in os.scandir(paths.PROC) if e.name.isdigit()]
    except OSError:
        return None
    for pid in pids:
        base = os.path.join(paths.PROC, pid)
        try:
            if os.stat(base).st_uid != uid:
                continue
            with os.scandir(os.path.join(base, "fd")) as fds:
                for fd in fds:
                    try:
                        if os.readlink(fd.path) == target:
                            return int(pid)
                    except OSError:
                        continue
        except OSError:
            continue
    return None


def cgroup_of(pid):
    """The pid's cgroup path relative to the cgroup root (cgroup v2), or ''."""
    try:
        with open(os.path.join(paths.PROC, str(pid), "cgroup"), encoding="utf-8") as f:
            for line in f:
                if line.startswith("0::"):
                    return line[3:].strip().lstrip("/")
    except OSError:
        pass
    return ""


def ifname(index):
    try:
        return socket.if_indextoname(index) if index else ""
    except OSError:
        return ""
