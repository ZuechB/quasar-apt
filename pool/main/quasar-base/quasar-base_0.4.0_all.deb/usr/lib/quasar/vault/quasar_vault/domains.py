"""Sites and domains: which saved logins belong to a page, and which relying party a passkey may name.

Uses the Public Suffix List from Debian's `publicsuffix` package, so "github.io" and "co.uk" are
treated as public suffixes (alice.github.io and bob.github.io are different sites).
"""
import ipaddress
import os
import urllib.parse

PSL_PATHS = ("/usr/share/publicsuffix/public_suffix_list.dat",)
_rules = None


def _load():
    global _rules
    if _rules is not None:
        return _rules
    rules = {"normal": set(), "wild": set(), "except": set()}
    path = os.environ.get("QUASAR_VAULT_PSL") or next((p for p in PSL_PATHS if os.path.exists(p)), None)
    if path:
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("//"):
                    continue
                rule = line.split()[0].lower()
                if rule.startswith("!"):
                    rules["except"].add(rule[1:])
                elif rule.startswith("*."):
                    rules["wild"].add(rule[2:])
                else:
                    rules["normal"].add(rule)
    _rules = rules
    return rules


def public_suffix(host):
    """The public suffix of host ("co.uk" for "a.b.co.uk"). Without a list: the last label."""
    host = host.lower().strip(".")
    labels = host.split(".")
    rules = _load()
    if not (rules["normal"] or rules["wild"]):
        return labels[-1]
    best = labels[-1]
    for i in range(len(labels)):
        cand = ".".join(labels[i:])
        if cand in rules["except"]:
            return ".".join(labels[i + 1:])
        parent = ".".join(labels[i + 1:])
        if cand in rules["normal"] or (parent and parent in rules["wild"]):
            return cand
    return best


def is_ip(host):
    try:
        ipaddress.ip_address(host.strip("[]"))
        return True
    except ValueError:
        return False


def site(host):
    """The registrable domain ("github.com" for "gist.github.com"); IPs and localhost stay as they are."""
    host = (host or "").lower().strip(".")
    if not host or is_ip(host) or "." not in host:
        return host
    suffix = public_suffix(host)
    if host == suffix:
        return host
    rest = host[: -len(suffix) - 1].split(".")
    return rest[-1] + "." + suffix


def host_of(url):
    """The host of a page address; "" when it isn't a web address."""
    if not url:
        return ""
    if "://" not in url:
        url = "https://" + url
    try:
        parts = urllib.parse.urlsplit(url)
    except ValueError:
        return ""
    if parts.scheme not in ("http", "https"):
        return ""
    return (parts.hostname or "").lower()


def origin_host(origin):
    """(scheme, host) of a WebAuthn origin, or None when it can't be used for passkeys: https only,
    except http://localhost (the browsers' own rule)."""
    try:
        parts = urllib.parse.urlsplit(origin or "")
    except ValueError:
        return None
    host = (parts.hostname or "").lower()
    if not host:
        return None
    if parts.scheme == "https" or (parts.scheme == "http" and (host == "localhost" or host.endswith(".localhost"))):
        return parts.scheme, host
    return None


def rp_id_allowed(rp_id, host):
    """WebAuthn: the RP ID must be the origin's host or a parent of it, and not a public suffix."""
    rp_id = (rp_id or "").lower().strip(".")
    if not rp_id or is_ip(host) and rp_id != host:
        return False
    if rp_id != host and not host.endswith("." + rp_id):
        return False
    # A public suffix ("com", "github.io") can't be a relying party, unless it is the page's own host
    # ("localhost" for a site you're building).
    if public_suffix(rp_id) == rp_id and rp_id != host:
        return False
    return True
