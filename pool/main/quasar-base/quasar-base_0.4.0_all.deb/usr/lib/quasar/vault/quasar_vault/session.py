"""vaultd session: JSON lines for the Vault app (apps/vault/services/VaultSession.qml).

Each request is one line {"id": N, "op": "...", ...}; each answer one line {"id": N, "ok": true, ...}
or {"id": N, "ok": false, "error": "...", "code": "locked|wrong|missing|failed"}.
The app opens locked: only `status` and `verify` work until your account password has been checked
(PAM); `lock` (the window closed or went idle) locks it again.

  status                               {available, live, locked (the keyring), verified}
  verify {password}                    checks it; also unlocks the keyring after automatic sign-in
  lock
  list                                 {logins: [...no passwords], passkeys: [...], browsers, sites}
  get {uuid}                           a login with its password and notes
  save {uuid?, url, username, password, title, notes}   -> {uuid}
  delete {uuid} | delete-passkey {uuid} | forget-browser {id} | forget-site {site}
  generate {length?}                   -> {password}
  copy {uuid, field: "password"|"username"}   to the clipboard; cleared after 30 s if still there
  import {path} -> {count} · export {path} -> {count}  (CSV; export writes 0600)
  browsers -> {browsers} · setup {id} -> {state} · store-page {id}
"""
import json
import os
import subprocess
import sys
import threading
import time

from . import browsers, csvio, kpxc, pam
from .keyring import Keyring, KeyringError
from .store import Store

CLIP_SECONDS = 30


def live():
    return os.path.isdir("/run/live") and os.environ.get("QUASAR_VAULT_ALLOW_LIVE") != "1"


class Session:
    def __init__(self):
        self.verified = False
        self.kr = None

    def keyring(self):
        if self.kr is None:
            self.kr = Keyring()
        return self.kr

    def store(self):
        kr = self.keyring()
        if kr.is_locked():
            raise KeyringError("locked", "Your passwords are locked.")
        return Store(kr)

    # ---- ops ------------------------------------------------------------------------------------------
    def op_status(self, req):
        out = {"live": live(), "verified": self.verified, "available": True, "locked": True}
        try:
            out["locked"] = self.keyring().is_locked()
        except KeyringError:
            out["available"] = False
        return out

    def op_verify(self, req):
        password = req.get("password")
        if not isinstance(password, str) or not pam.check(password):
            raise SessionError("wrong", "That password isn't right")
        kr = self.keyring()
        if kr.is_locked() and not kr.unlock_with_password(password):
            raise SessionError("locked", "Your keyring didn't open with this password. If an administrator reset "
                                         "your password, type your old one in the keyring's own window.")
        self.verified = True
        return {}

    def op_lock(self, req):
        self.verified = False
        return {}

    def op_list(self, req):
        st = self.store()
        return {"logins": st.logins(), "passkeys": st.passkeys(), "browsers": st.browsers(), "sites": st.allowed_sites()}

    def op_get(self, req):
        rec = self.store().login(str(req.get("uuid") or ""), with_secret=True)
        if not rec:
            raise SessionError("failed", "That login is gone")
        return {"login": rec}

    def op_save(self, req):
        url = str(req.get("url") or "").strip()
        if url and "://" not in url:
            url = "https://" + url
        uid = self.store().save_login(url, str(req.get("username") or ""), str(req.get("password") or ""),
                                      title=str(req.get("title") or ""), notes=str(req.get("notes") or ""),
                                      uid=req.get("uuid") or None)
        return {"uuid": uid}

    def op_delete(self, req):
        return {"deleted": self.store().delete_login(str(req.get("uuid") or ""))}

    def op_delete_passkey(self, req):
        return {"deleted": self.store().delete_passkey(str(req.get("uuid") or ""))}

    def op_forget_browser(self, req):
        self.store().forget_browser(str(req.get("id") or ""))
        return {}

    def op_forget_site(self, req):
        self.store().allow_site(str(req.get("site") or ""), allowed=False)
        return {}

    def op_generate(self, req):
        n = req.get("length")
        return {"password": kpxc.generate_password(max(8, min(64, int(n))) if isinstance(n, int) else 20)}

    def op_copy(self, req):
        rec = self.store().login(str(req.get("uuid") or ""), with_secret=True)
        if not rec:
            raise SessionError("failed", "That login is gone")
        value = rec.get("username" if req.get("field") == "username" else "password", "")
        subprocess.run(["wl-copy", "--", value], timeout=10, check=False)
        if req.get("field") != "username":
            threading.Thread(target=self._clear_later, args=(value,), daemon=True).start()
        return {"seconds": CLIP_SECONDS}

    def _clear_later(self, value):
        time.sleep(CLIP_SECONDS)
        try:
            now = subprocess.run(["wl-paste", "--no-newline"], capture_output=True, text=True, timeout=5).stdout
            if now == value:
                subprocess.run(["wl-copy", "--clear"], timeout=5, check=False)
        except (OSError, subprocess.TimeoutExpired):
            pass

    def op_import(self, req):
        path = str(req.get("path") or "")
        with open(path, encoding="utf-8-sig", errors="replace") as f:
            rows = csvio.parse(f.read())
        st = self.store()
        for r in rows:
            st.save_login(r["url"], r["username"], r["password"], title=r["title"], notes=r["notes"])
        return {"count": len(rows)}

    def op_export(self, req):
        path = str(req.get("path") or "")
        st = self.store()
        rows = [st.login(r["uuid"], with_secret=True) for r in st.logins()]
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(csvio.export([r for r in rows if r]))
        return {"count": len(rows)}

    def op_browsers(self, req):
        return {"browsers": browsers.list_browsers()}

    def op_setup(self, req):
        return {"state": browsers.setup(str(req.get("id") or ""))}

    def op_store_page(self, req):
        browsers.open_store_page(str(req.get("id") or ""))
        return {}

    OPEN = {"status", "verify", "lock", "browsers", "store-page"}

    def handle(self, req):
        op = str(req.get("op") or "")
        fn = getattr(self, "op_" + op.replace("-", "_"), None)
        if fn is None:
            raise SessionError("failed", "Unknown request " + op)
        if op not in self.OPEN and op != "setup" and not self.verified:
            raise SessionError("locked", "Vault is locked")
        if live() and op not in ("status", "browsers"):
            raise SessionError("live", "Vault keeps passwords on an installed Quasar. The live USB forgets "
                                       "everything when it restarts.")
        return fn(req)


class SessionError(Exception):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


def main():
    s = Session()
    for line in sys.stdin:
        try:
            req = json.loads(line)
        except ValueError:
            continue
        if not isinstance(req, dict):
            continue
        out = {"id": req.get("id")}
        try:
            out.update(s.handle(req))
            out["ok"] = True
        except SessionError as e:
            out.update(ok=False, error=str(e), code=e.code)
        except KeyringError as e:
            out.update(ok=False, error=str(e), code=e.kind)
        except (OSError, ValueError) as e:
            out.update(ok=False, error=str(e), code="failed")
        print(json.dumps(out), flush=True)
    return 0
