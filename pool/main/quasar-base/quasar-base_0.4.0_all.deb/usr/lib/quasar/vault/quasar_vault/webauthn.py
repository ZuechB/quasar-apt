"""A WebAuthn authenticator in software: makes passkeys and signs with them.

The browser extension (KeePassXC-Browser) passes the page's PublicKeyCredentialCreationOptions /
RequestOptions and its origin; this builds the PublicKeyCredential JSON the extension hands back to the
page, in the same shape KeePassXC uses (base64url without padding, attestation "none", sign count 0).
Keys: ES256 (P-256), EdDSA (Ed25519) or RS256, the first one the site lists that is supported.
"""
import base64
import hashlib
import json
import os
import struct

from . import domains

ES256, EDDSA, RS256 = -7, -8, -257
SUPPORTED = (ES256, EDDSA, RS256)
# Vault's own authenticator id (sites may show "Quasar Vault" for passkeys made here).
AAGUID = b"QuasarVault-Pass"                    # 16 bytes
FLAG_UP, FLAG_UV, FLAG_BE, FLAG_BS, FLAG_AT, FLAG_ED = 0x01, 0x04, 0x08, 0x10, 0x40, 0x80


class WebAuthnError(Exception):
    """code: the KeePassXC error number the extension understands (20-33)."""
    def __init__(self, code, message=""):
        super().__init__(message or str(code))
        self.code = code


ATTESTATION_NOT_SUPPORTED, CREDENTIAL_IS_EXCLUDED, REQUEST_CANCELED = 20, 21, 22
INVALID_USER_VERIFICATION, EMPTY_PUBLIC_KEY, INVALID_URL, ORIGIN_NOT_ALLOWED = 23, 24, 25, 26
DOMAIN_NOT_VALID, DOMAIN_RPID_MISMATCH, NO_SUPPORTED_ALGORITHMS, UNKNOWN_ERROR = 27, 28, 29, 31
INVALID_CHALLENGE, INVALID_USER_ID = 32, 33


# ---- encodings ------------------------------------------------------------------------------------
def b64url(data):
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()


def unb64url(text):
    if isinstance(text, (bytes, bytearray)):
        return bytes(text)
    text = str(text or "")
    return base64.urlsafe_b64decode(text + "=" * (-len(text) % 4))


def as_bytes(value):
    """Option values arrive as base64url strings, or as {"0": 12, "1": 34…} / lists from a JSON-ified
    ArrayBuffer view."""
    if value is None:
        return b""
    if isinstance(value, str):
        return unb64url(value)
    if isinstance(value, list):
        return bytes(value)
    if isinstance(value, dict):
        return bytes(value[k] for k in sorted(value, key=lambda x: int(x)))
    return bytes(value)


def cbor(value):
    """Minimal canonical CBOR (RFC 8949): ints, bytes, text, lists, maps, bools."""
    def head(major, n):
        if n < 24:
            return bytes([major << 5 | n])
        if n < 0x100:
            return bytes([major << 5 | 24, n])
        if n < 0x10000:
            return bytes([major << 5 | 25]) + struct.pack(">H", n)
        if n < 0x100000000:
            return bytes([major << 5 | 26]) + struct.pack(">I", n)
        return bytes([major << 5 | 27]) + struct.pack(">Q", n)
    if value is True:
        return b"\xf5"
    if value is False:
        return b"\xf4"
    if isinstance(value, int):
        return head(0, value) if value >= 0 else head(1, -1 - value)
    if isinstance(value, (bytes, bytearray)):
        return head(2, len(value)) + bytes(value)
    if isinstance(value, str):
        raw = value.encode()
        return head(3, len(raw)) + raw
    if isinstance(value, list):
        return head(4, len(value)) + b"".join(cbor(v) for v in value)
    if isinstance(value, dict):
        items = sorted(((cbor(k), cbor(v)) for k, v in value.items()), key=lambda kv: (len(kv[0]), kv[0]))
        return head(5, len(items)) + b"".join(k + v for k, v in items)
    raise TypeError(f"can't CBOR-encode {type(value).__name__}")


# ---- keys -------------------------------------------------------------------------------------------
def new_key(alg):
    from cryptography.hazmat.primitives.asymmetric import ec, ed25519, rsa
    if alg == ES256:
        return ec.generate_private_key(ec.SECP256R1())
    if alg == EDDSA:
        return ed25519.Ed25519PrivateKey.generate()
    return rsa.generate_private_key(public_exponent=65537, key_size=2048)


def key_pem(key):
    from cryptography.hazmat.primitives import serialization
    return key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                             serialization.NoEncryption()).decode()


def load_key(pem):
    from cryptography.hazmat.primitives import serialization
    return serialization.load_pem_private_key(pem.encode(), password=None)


def cose_key(key, alg):
    pub = key.public_key()
    if alg == ES256:
        n = pub.public_numbers()
        return {1: 2, 3: ES256, -1: 1, -2: n.x.to_bytes(32, "big"), -3: n.y.to_bytes(32, "big")}
    if alg == EDDSA:
        from cryptography.hazmat.primitives import serialization
        raw = pub.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        return {1: 1, 3: EDDSA, -1: 6, -2: raw}
    n = pub.public_numbers()
    return {1: 3, 3: RS256, -1: n.n.to_bytes((n.n.bit_length() + 7) // 8, "big"),
            -2: n.e.to_bytes((n.e.bit_length() + 7) // 8, "big")}


def spki(key):
    from cryptography.hazmat.primitives import serialization
    return key.public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)


def sign(key, alg, data):
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.asymmetric import ec, padding
    if alg == ES256:
        return key.sign(data, ec.ECDSA(hashes.SHA256()))
    if alg == EDDSA:
        return key.sign(data)
    return key.sign(data, padding.PKCS1v15(), hashes.SHA256())


# ---- the ceremony -------------------------------------------------------------------------------------
def client_data(kind, challenge, origin):
    # The browser's field order: type, challenge, origin, crossOrigin.
    return json.dumps({"type": kind, "challenge": b64url(challenge), "origin": origin, "crossOrigin": False},
                      separators=(",", ":")).encode()


def check_origin(origin, rp_id):
    """(host, rp_id) after the WebAuthn origin rules, or raises with KeePassXC's codes."""
    oh = domains.origin_host(origin)
    if not oh:
        raise WebAuthnError(INVALID_URL, "That page can't use passkeys (it isn't https).")
    host = oh[1]
    rp = (rp_id or host).lower()
    if not domains.rp_id_allowed(rp, host):
        raise WebAuthnError(DOMAIN_RPID_MISMATCH, f"{origin} can't make passkeys for {rp}.")
    return host, rp


def auth_data(rp_id, flags, attested=b""):
    return hashlib.sha256(rp_id.encode()).digest() + bytes([flags]) + struct.pack(">I", 0) + attested


def register(options, origin):
    """-> (credential JSON for the page, passkey record to store). Doesn't ask anyone: the caller
    has already checked excludeCredentials (see excluded()) and verified the user."""
    if not isinstance(options, dict) or not options:
        raise WebAuthnError(EMPTY_PUBLIC_KEY, "The page sent no passkey options.")
    challenge = as_bytes(options.get("challenge"))
    if len(challenge) < 16:
        raise WebAuthnError(INVALID_CHALLENGE, "The page's challenge is too short.")
    rp = options.get("rp") or {}
    user = options.get("user") or {}
    user_id = as_bytes(user.get("id"))
    if not 1 <= len(user_id) <= 64:
        raise WebAuthnError(INVALID_USER_ID, "The page sent no valid user id.")
    _host, rp_id = check_origin(origin, rp.get("id"))
    params = options.get("pubKeyCredParams") or []
    algs = [p.get("alg") for p in params if isinstance(p, dict) and p.get("type", "public-key") == "public-key"]
    alg = next((a for a in algs if a in SUPPORTED), None) if algs else ES256
    if alg is None:
        raise WebAuthnError(NO_SUPPORTED_ALGORITHMS, "The page asks for a key type Vault can't make.")

    key = new_key(alg)
    cred_id = os.urandom(32)
    attested = AAGUID + struct.pack(">H", len(cred_id)) + cred_id + cbor(cose_key(key, alg))
    data = auth_data(rp_id, FLAG_UP | FLAG_UV | FLAG_AT, attested)
    cdata = client_data("webauthn.create", challenge, origin)
    attestation = cbor({"fmt": "none", "attStmt": {}, "authData": data})
    credential = {
        "authenticatorAttachment": "platform",
        "id": b64url(cred_id),
        "rawId": b64url(cred_id),
        "type": "public-key",
        "response": {
            "attestationObject": b64url(attestation),
            "clientDataJSON": b64url(cdata),
            "authenticatorData": b64url(data),
            "publicKey": b64url(spki(key)),
            "publicKeyAlgorithm": alg,
            "transports": ["internal"],
        },
        "clientExtensionResults": {"credProps": {"rk": True}} if (options.get("extensions") or {}).get("credProps") else {},
    }
    record = {
        "rpId": rp_id, "credentialId": b64url(cred_id), "userHandle": b64url(user_id),
        "username": str(user.get("name") or ""), "displayName": str(user.get("displayName") or user.get("name") or ""),
        "alg": alg, "key": key_pem(key),
    }
    return credential, record


def excluded(options, stored_ids):
    ids = {b64url(as_bytes(c.get("id"))) for c in (options.get("excludeCredentials") or []) if isinstance(c, dict)}
    return bool(ids & set(stored_ids))


def candidates(options, origin, passkeys):
    """The stored passkeys this sign-in may use: the page's rpId, narrowed to allowCredentials."""
    _host, rp_id = check_origin(origin, options.get("rpId"))
    allow = {b64url(as_bytes(c.get("id"))) for c in (options.get("allowCredentials") or []) if isinstance(c, dict)}
    return rp_id, [p for p in passkeys if p.get("rpId") == rp_id and (not allow or p.get("credentialId") in allow)]


def assertion(options, origin, record):
    challenge = as_bytes(options.get("challenge"))
    if len(challenge) < 16:
        raise WebAuthnError(INVALID_CHALLENGE, "The page's challenge is too short.")
    _host, rp_id = check_origin(origin, options.get("rpId"))
    if rp_id != record["rpId"]:
        raise WebAuthnError(DOMAIN_RPID_MISMATCH, "That passkey belongs to another site.")
    key = load_key(record["key"])
    data = auth_data(rp_id, FLAG_UP | FLAG_UV)
    cdata = client_data("webauthn.get", challenge, origin)
    signature = sign(key, int(record["alg"]), data + hashlib.sha256(cdata).digest())
    return {
        "authenticatorAttachment": "platform",
        "id": record["credentialId"],
        "rawId": record["credentialId"],
        "type": "public-key",
        "response": {
            "authenticatorData": b64url(data),
            "clientDataJSON": b64url(cdata),
            "signature": b64url(signature),
            "userHandle": record["userHandle"],
        },
        "clientExtensionResults": {},
    }
