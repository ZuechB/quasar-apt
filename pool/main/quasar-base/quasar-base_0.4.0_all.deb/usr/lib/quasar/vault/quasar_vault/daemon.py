"""vaultd daemon: the browsers' side of Vault (systemd --user: quasar-vault.socket starts it).

  %t/quasar-vault/browser.sock  native-messaging frames (4-byte native-endian length + JSON), relayed
                                unchanged by vault-relay from the KeePassXC-Browser extension. A relay
                                first sends {"quasar-relay": {"flatpak": APP_ID, "args": [...]}}.
  %t/quasar-vault/answer.sock   the shell's answers (`vaultd answer`): one JSON line in, one out.

Questions go to the shell over IPC (`qs ipc call vault ask BASE64-JSON`): its VaultPrompt sheet takes
your account password. The answer comes back on answer.sock; this process checks the password with
PAM (and unlocks the keyring with it when it's locked) before anything is filled, saved or signed.
Exits after 10 idle minutes; the socket unit starts it again.
"""
import base64
import json
import os
import socket
import struct
import subprocess
import sys
import threading
import time
import uuid

from . import kpxc, pam
from .keyring import Keyring, KeyringError
from .store import Store

IDLE_EXIT = 600
ASK_TIMEOUT = 120
SHELL = ["qs", "ipc", "--any-display", "--path", "/usr/share/quasar/shell", "call", "vault"]
# QUASAR_VAULT_ASK=PROGRAM: who gets the questions instead of the shell (tests: tests/vault/e2e.sh).
if os.environ.get("QUASAR_VAULT_ASK"):
    SHELL = [os.environ["QUASAR_VAULT_ASK"]]


def runtime_dir():
    return os.path.join(os.environ.get("XDG_RUNTIME_DIR") or f"/run/user/{os.getuid()}", "quasar-vault")


def log(msg):
    print("vaultd: " + msg, file=sys.stderr, flush=True)


class Daemon:
    def __init__(self, shell_cmd=None):
        self.shell_cmd = shell_cmd or SHELL
        self.lock = threading.Lock()
        self.pending = {}                    # id -> {"kind", "event", "answer"}
        self.conns = set()
        self.last_activity = time.monotonic()
        self.user = pam.me()
        self.db_hash = kpxc.database_hash(self.user)

    # ---- asking the shell ----------------------------------------------------------------------------
    def ask(self, kind, info):
        rid = uuid.uuid4().hex[:12]
        req = {"kind": kind, "event": threading.Event(), "answer": None}
        with self.lock:
            self.pending[rid] = req
        payload = dict(info or {}, id=rid, kind=kind)
        data = base64.b64encode(json.dumps(payload).encode()).decode()
        try:
            subprocess.run(self.shell_cmd + ["ask", data], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=10)
        except (OSError, subprocess.TimeoutExpired) as e:
            log(f"can't reach the shell: {e}")
        req["event"].wait(ASK_TIMEOUT)
        with self.lock:
            self.pending.pop(rid, None)
        if not req["event"].is_set():
            try:
                subprocess.run(self.shell_cmd + ["cancel", rid], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=10)
            except (OSError, subprocess.TimeoutExpired):
                pass
        if kind == "unlock" and req["answer"] and req["answer"].get("ok"):
            self.broadcast({"action": "database-unlocked"})
        return req["answer"]

    def answer(self, msg):
        """An answer from the shell -> "ok" | "wrong" | "gone"."""
        rid = str(msg.get("id") or "")
        with self.lock:
            req = self.pending.get(rid)
        if req is None:
            return "gone"
        if not msg.get("ok"):
            req["answer"] = {"ok": False}
            req["event"].set()
            return "ok"
        password = msg.get("password")
        if not isinstance(password, str) or not pam.check(password):
            return "wrong"
        # The keyring after automatic sign-in: open it with the password just checked.
        try:
            kr = Keyring()
            try:
                if kr.is_locked():
                    kr.unlock_with_password(password)
            finally:
                kr.close()
        except KeyringError:
            pass
        req["answer"] = {"ok": True, "choice": msg.get("choice")}
        req["event"].set()
        return "ok"

    def notify(self, title, text):
        try:
            subprocess.Popen(["notify-send", "-a", "Vault", "-i", "dialog-password", title, text],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except OSError:
            pass

    # ---- browsers ------------------------------------------------------------------------------------
    def broadcast(self, obj):
        for c in list(self.conns):
            c.send(obj)

    def serve_browser(self, sock):
        conn = BrowserConn(self, sock)
        self.conns.add(conn)
        try:
            conn.run()
        finally:
            self.conns.discard(conn)
            self.last_activity = time.monotonic()

    def serve_answer(self, sock):
        try:
            f = sock.makefile("rwb")
            line = f.readline(65536)
            try:
                msg = json.loads(line.decode("utf-8"))
            except (ValueError, UnicodeDecodeError):
                msg = None
            result = self.answer(msg) if isinstance(msg, dict) else "gone"
            f.write((json.dumps({"result": result}) + "\n").encode())
            f.flush()
        except OSError:
            pass
        finally:
            sock.close()

    # ---- sockets -------------------------------------------------------------------------------------
    def sockets(self):
        """Sockets from systemd (LISTEN_FDS, named by FileDescriptorName), else bound here."""
        found = {}
        if os.environ.get("LISTEN_PID") == str(os.getpid()):
            # All sockets of one unit share a FileDescriptorName: tell them apart by their path.
            for i in range(int(os.environ.get("LISTEN_FDS") or 0)):
                s = socket.socket(fileno=3 + i)
                name = os.path.basename(str(s.getsockname())).replace(".sock", "")
                found[name] = s
        rdir = runtime_dir()
        os.makedirs(rdir, mode=0o700, exist_ok=True)
        for name in ("browser", "answer"):
            if name not in found:
                path = os.path.join(rdir, name + ".sock")
                try:
                    os.unlink(path)
                except FileNotFoundError:
                    pass
                s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                s.bind(path)
                os.chmod(path, 0o600)
                s.listen(8)
                found[name] = s
        return found

    def run(self):
        socks = self.sockets()

        def accept_loop(listener, handler):
            while True:
                try:
                    s, _ = listener.accept()
                except OSError:
                    return
                self.last_activity = time.monotonic()
                threading.Thread(target=handler, args=(s,), daemon=True).start()

        threading.Thread(target=accept_loop, args=(socks["answer"], self.serve_answer), daemon=True).start()
        threading.Thread(target=accept_loop, args=(socks["browser"], self.serve_browser), daemon=True).start()
        while True:
            time.sleep(15)
            with self.lock:
                busy = bool(self.conns) or bool(self.pending)
            if not busy and time.monotonic() - self.last_activity > IDLE_EXIT:
                return 0


class BrowserConn:
    def __init__(self, daemon, sock):
        self.d, self.sock = daemon, sock
        self.wlock = threading.Lock()
        self.kr = None
        self.proto = kpxc.Connection(self.store, daemon.ask, daemon.notify, daemon.db_hash)

    def store(self):
        if self.kr is None:
            self.kr = Keyring()
        if self.kr.is_locked():
            raise KeyringError("locked", "Your passwords are locked.")
        return Store(self.kr)

    def recv_exact(self, n):
        data = b""
        while len(data) < n:
            chunk = self.sock.recv(n - len(data))
            if not chunk:
                return None
            data += chunk
        return data

    def recv(self):
        head = self.recv_exact(4)
        if head is None:
            return None
        (n,) = struct.unpack("=I", head)
        if n > 4 * 1024 * 1024:
            return None
        body = self.recv_exact(n)
        if body is None:
            return None
        try:
            return json.loads(body.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            return {}

    def send(self, obj):
        data = json.dumps(obj).encode()
        with self.wlock:
            try:
                self.sock.sendall(struct.pack("=I", len(data)) + data)
            except OSError:
                pass

    def run(self):
        try:
            while True:
                msg = self.recv()
                if msg is None:
                    return
                if isinstance(msg, dict) and "quasar-relay" in msg:
                    self.proto.browser = kpxc.browser_name(msg["quasar-relay"])
                    continue
                self.d.last_activity = time.monotonic()
                try:
                    reply = self.proto.handle(msg)
                except KeyringError as e:
                    reply = self.proto.error(msg.get("action", "") if isinstance(msg, dict) else "", kpxc.DATABASE_NOT_OPENED)
                    log(f"keyring: {e}")
                except Exception as e:                  # noqa: BLE001 (never take the browser down)
                    log(f"error handling {msg.get('action') if isinstance(msg, dict) else '?'}: {e!r}")
                    reply = self.proto.error(msg.get("action", "") if isinstance(msg, dict) else "", kpxc.INCORRECT_ACTION)
                self.send(reply)
        finally:
            if self.kr:
                self.kr.close()
            self.sock.close()


def answer_cli():
    """vaultd answer: one JSON line on stdin -> the daemon; prints {"result": ...}."""
    line = sys.stdin.readline(65536)
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    try:
        s.connect(os.path.join(runtime_dir(), "answer.sock"))
        s.sendall(line.encode() if line.endswith("\n") else (line + "\n").encode())
        reply = s.makefile("rb").readline(4096).decode().strip()
    except OSError:
        reply = json.dumps({"result": "gone"})
    finally:
        s.close()
    print(reply or json.dumps({"result": "gone"}), flush=True)
    return 0


def main():
    return Daemon().run()
