"""Vault's records in the login keyring. Every item carries `quasar-vault` = its kind, so Vault never
touches other programs' secrets (Wi-Fi, Quasar AI keys, Chromium's own key).

  password  attributes: uuid, site (registrable domain, how pages find it), url, username, title,
            created, modified        secret: {"password", "notes"}
  passkey   attributes: uuid, rp, credential, userhandle, username, displayname, alg, created, used
            secret: {"key": PKCS#8 PEM}
  browser   a connected browser (KeePassXC-Browser's association): id      secret: its public key
  sites     the sites you allowed to fill passwords: secret {"sites": [...]}
Times are seconds since 1970 as text (attributes are strings).
"""
import json
import time
import uuid as uuidlib

from . import domains

KIND = "quasar-vault"


def now():
    return str(int(time.time()))


class Store:
    def __init__(self, keyring):
        self.kr = keyring

    # ---- generic --------------------------------------------------------------------------------
    def _find(self, kind, **attrs):
        q = {KIND: kind}
        q.update({k: v for k, v in attrs.items() if v is not None})
        return self.kr.search(q)

    def _records(self, kind, **attrs):
        out = []
        for path in self._find(kind, **attrs):
            try:
                a = self.kr.attributes(path)
            except Exception:                           # noqa: BLE001 (deleted meanwhile)
                continue
            a["_path"] = path
            out.append(a)
        return out

    def _secret_json(self, path):
        try:
            data = json.loads(self.kr.secret(path).decode("utf-8") or "{}")
            return data if isinstance(data, dict) else {}
        except (ValueError, UnicodeDecodeError):
            return {}

    def _by_uuid(self, kind, uid):
        paths = self._find(kind, uuid=uid)
        return paths[0] if paths else None

    # ---- passwords --------------------------------------------------------------------------------
    @staticmethod
    def _public(a):
        return {k: v for k, v in a.items() if not k.startswith("_") and k != KIND and not k.startswith("xdg:")}

    def logins(self, site=None):
        return [self._public(a) for a in self._records("password", site=site)]

    def login(self, uid, with_secret=False):
        path = self._by_uuid("password", uid)
        if not path:
            return None
        rec = self._public(self.kr.attributes(path))
        if with_secret:
            s = self._secret_json(path)
            rec["password"] = str(s.get("password") or "")
            rec["notes"] = str(s.get("notes") or "")
        return rec

    def save_login(self, url, username, password, title="", notes="", uid=None):
        """Adds a login, or updates the one with this uuid. Returns its uuid."""
        host = domains.host_of(url)
        site = domains.site(host) if host else ""
        title = (title or "").strip() or site or url
        path = self._by_uuid("password", uid) if uid else None
        if path:
            old = self.kr.attributes(path)
            attrs = dict(old)
            attrs.update(url=url, site=site, username=username, title=title, modified=now())
            self.kr.set_attributes(path, attrs)
            self.kr.set_label(path, "Vault: " + title)
            self.kr.set_secret(path, json.dumps({"password": password, "notes": notes}).encode())
            return attrs["uuid"]
        uid = uuidlib.uuid4().hex
        attrs = {"xdg:schema": "org.quasar.vault.Password", KIND: "password", "uuid": uid, "url": url,
                 "site": site, "username": username, "title": title, "created": now(), "modified": now()}
        self.kr.create("Vault: " + title, attrs, json.dumps({"password": password, "notes": notes}).encode())
        return uid

    def delete_login(self, uid):
        path = self._by_uuid("password", uid)
        if path:
            self.kr.delete(path)
        return bool(path)

    def logins_for(self, url):
        """Saved logins for a page: same site, the same host first. With secrets."""
        host = domains.host_of(url)
        if not host:
            return []
        site = domains.site(host)
        out = []
        for a in self._records("password", site=site):
            rec = self._public(a)
            s = self._secret_json(a["_path"])
            rec["password"] = str(s.get("password") or "")
            out.append(rec)
        out.sort(key=lambda r: (domains.host_of(r.get("url", "")) != host, r.get("title", "").lower()))
        return out

    # ---- passkeys --------------------------------------------------------------------------------------
    def passkeys(self, rp=None):
        out = []
        for a in self._records("passkey", rp=rp):
            out.append({"uuid": a.get("uuid", ""), "rpId": a.get("rp", ""), "credentialId": a.get("credential", ""),
                        "userHandle": a.get("userhandle", ""), "username": a.get("username", ""),
                        "displayName": a.get("displayname", ""), "alg": a.get("alg", ""),
                        "created": a.get("created", ""), "used": a.get("used", "")})
        return out

    def passkey_secret(self, uid):
        path = self._by_uuid("passkey", uid)
        if not path:
            return None
        rec = next((p for p in self.passkeys() if p["uuid"] == uid), None)
        if rec is None:
            return None
        rec["key"] = str(self._secret_json(path).get("key") or "")
        return rec

    def save_passkey(self, record):
        uid = uuidlib.uuid4().hex
        attrs = {"xdg:schema": "org.quasar.vault.Passkey", KIND: "passkey", "uuid": uid, "rp": record["rpId"],
                 "credential": record["credentialId"], "userhandle": record["userHandle"],
                 "username": record.get("username", ""), "displayname": record.get("displayName", ""),
                 "alg": str(record["alg"]), "created": now(), "used": ""}
        label = "Vault passkey: %s (%s)" % (record["rpId"], record.get("username") or record.get("displayName") or "")
        self.kr.create(label, attrs, json.dumps({"key": record["key"]}).encode())
        return uid

    def passkey_used(self, uid):
        path = self._by_uuid("passkey", uid)
        if path:
            attrs = self.kr.attributes(path)
            attrs["used"] = now()
            self.kr.set_attributes(path, attrs)

    def delete_passkey(self, uid):
        path = self._by_uuid("passkey", uid)
        if path:
            self.kr.delete(path)
        return bool(path)

    # ---- browsers and allowed sites --------------------------------------------------------------------
    def browser_key(self, name):
        paths = self._find("browser", id=name)
        return self.kr.secret(paths[0]).decode() if paths else ""

    def save_browser(self, name, key):
        self.forget_browser(name)
        attrs = {"xdg:schema": "org.quasar.vault.Browser", KIND: "browser", "id": name, "created": now()}
        self.kr.create("Vault: browser " + name, attrs, key.encode(), "text/plain")

    def browsers(self):
        return [{"id": a.get("id", ""), "created": a.get("created", "")} for a in self._records("browser")]

    def forget_browser(self, name):
        for path in self._find("browser", id=name):
            self.kr.delete(path)

    def allowed_sites(self):
        paths = self._find("sites")
        if not paths:
            return []
        sites = self._secret_json(paths[0]).get("sites")
        return [s for s in sites if isinstance(s, str)] if isinstance(sites, list) else []

    def allow_site(self, site, allowed=True):
        sites = [s for s in self.allowed_sites() if s != site]
        if allowed:
            sites.append(site)
        attrs = {"xdg:schema": "org.quasar.vault.Sites", KIND: "sites"}
        self.kr.create("Vault: sites allowed to fill passwords", attrs, json.dumps({"sites": sorted(sites)}).encode(),
                       replace=True)
