"""Checks your account password with PAM (libpam through ctypes, no extra package).

Service /etc/pam.d/quasar-vault: common-auth (pam_unix checks the password through its unix_chkpwd
helper, which only answers for the account that runs it, and waits ~2 s after a wrong one) plus
pam_gnome_keyring, which unlocks your login keyring with the same password when it's still locked.
QUASAR_VAULT_PAM=NAME uses another service; QUASAR_VAULT_TEST_PASSWORD=x (tests only, with
QUASAR_TEST=1) replaces PAM with a fixed password.
"""
import ctypes
import ctypes.util
import os
import pwd

PAM_PROMPT_ECHO_OFF, PAM_PROMPT_ECHO_ON = 1, 2
PAM_SUCCESS = 0


class PamMessage(ctypes.Structure):
    _fields_ = [("msg_style", ctypes.c_int), ("msg", ctypes.c_char_p)]


class PamResponse(ctypes.Structure):
    _fields_ = [("resp", ctypes.c_void_p), ("resp_retcode", ctypes.c_int)]


CONV_FUNC = ctypes.CFUNCTYPE(ctypes.c_int, ctypes.c_int, ctypes.POINTER(ctypes.POINTER(PamMessage)),
                             ctypes.POINTER(ctypes.POINTER(PamResponse)), ctypes.c_void_p)


class PamConv(ctypes.Structure):
    _fields_ = [("conv", CONV_FUNC), ("appdata_ptr", ctypes.c_void_p)]


def me():
    return pwd.getpwuid(os.getuid()).pw_name


def check(password, user=None, service=None):
    """True when `password` is this account's password."""
    if os.environ.get("QUASAR_TEST") == "1" and "QUASAR_VAULT_TEST_PASSWORD" in os.environ:
        return password == os.environ["QUASAR_VAULT_TEST_PASSWORD"]
    if not isinstance(password, str) or not password or "\0" in password:
        return False
    service = service or os.environ.get("QUASAR_VAULT_PAM") or "quasar-vault"
    user = user or me()
    libpam = ctypes.CDLL(ctypes.util.find_library("pam") or "libpam.so.0")
    libc = ctypes.CDLL(ctypes.util.find_library("c") or "libc.so.6")
    libc.calloc.restype = ctypes.c_void_p
    libc.calloc.argtypes = [ctypes.c_size_t, ctypes.c_size_t]
    libc.strdup.restype = ctypes.c_void_p
    libc.strdup.argtypes = [ctypes.c_char_p]
    secret = password.encode("utf-8")

    @CONV_FUNC
    def conv(n, messages, responses, _data):
        # PAM frees what we hand back, so it must come from malloc (calloc/strdup).
        arr = libc.calloc(n, ctypes.sizeof(PamResponse))
        if not arr:
            return 5                                      # PAM_BUF_ERR
        resp = ctypes.cast(arr, ctypes.POINTER(PamResponse))
        for i in range(n):
            if messages[i].contents.msg_style in (PAM_PROMPT_ECHO_OFF, PAM_PROMPT_ECHO_ON):
                resp[i].resp = libc.strdup(secret)
            resp[i].resp_retcode = 0
        responses[0] = resp
        return PAM_SUCCESS

    handle = ctypes.c_void_p()
    libpam.pam_start.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.POINTER(PamConv), ctypes.POINTER(ctypes.c_void_p)]
    libpam.pam_authenticate.argtypes = [ctypes.c_void_p, ctypes.c_int]
    libpam.pam_acct_mgmt.argtypes = [ctypes.c_void_p, ctypes.c_int]
    libpam.pam_end.argtypes = [ctypes.c_void_p, ctypes.c_int]
    conversation = PamConv(conv, None)
    rc = libpam.pam_start(service.encode(), user.encode(), ctypes.byref(conversation), ctypes.byref(handle))
    if rc != PAM_SUCCESS:
        return False
    try:
        rc = libpam.pam_authenticate(handle, 0)
        if rc == PAM_SUCCESS:
            rc = libpam.pam_acct_mgmt(handle, 0)
        return rc == PAM_SUCCESS
    finally:
        libpam.pam_end(handle, rc)
