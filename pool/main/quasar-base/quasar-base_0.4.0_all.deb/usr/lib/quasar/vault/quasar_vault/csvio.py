"""Importing passwords from other password managers' CSV exports, and exporting Vault's.

Recognised by their header row: Chrome, Brave and Edge (name,url,username,password,note), Firefox
(url,username,password,…), Bitwarden (login_uri,login_username,login_password,…), KeePassXC
("Title","Username","Password","URL","Notes",…) and 1Password (Title,Url,Username,Password,…).
Export writes Chrome's format, which all of them import.
"""
import csv
import io

URL_COLS = ("url", "login_uri", "website", "web site", "login url")
USER_COLS = ("username", "login_username", "user name", "login", "email")
PASS_COLS = ("password", "login_password")
TITLE_COLS = ("name", "title")
NOTE_COLS = ("note", "notes", "extra", "comments")


def _pick(row, cols):
    for c in cols:
        if c in row and row[c]:
            return row[c].strip()
    return ""


def parse(text):
    """-> [{url, username, password, title, notes}] (rows without a password are skipped)."""
    reader = csv.DictReader(io.StringIO(text.lstrip("﻿")))
    if not reader.fieldnames:
        return []
    reader.fieldnames = [(f or "").strip().lower() for f in reader.fieldnames]
    if not any(c in reader.fieldnames for c in PASS_COLS):
        raise ValueError("That file has no password column")
    out = []
    for raw in reader:
        row = {k: (v or "") for k, v in raw.items() if k}
        password = _pick(row, PASS_COLS)
        if not password:
            continue
        url = _pick(row, URL_COLS)
        if url and "://" not in url and "." in url:
            url = "https://" + url
        out.append({"url": url, "username": _pick(row, USER_COLS), "password": password,
                    "title": _pick(row, TITLE_COLS), "notes": _pick(row, NOTE_COLS)})
    return out


def export(rows):
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(["name", "url", "username", "password", "note"])
    for r in rows:
        w.writerow([r.get("title", ""), r.get("url", ""), r.get("username", ""), r.get("password", ""), r.get("notes", "")])
    return buf.getvalue()
