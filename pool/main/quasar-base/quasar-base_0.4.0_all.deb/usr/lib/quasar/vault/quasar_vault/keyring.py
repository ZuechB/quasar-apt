"""The login keyring through the Secret Service D-Bus API (gnome-keyring), with jeepney.

Vault keeps everything here: gnome-keyring encrypts the keyring file with your account password, PAM
unlocks it when you sign in, and passwd (Settings > Change your password) re-keys it. After automatic
sign-in it stays locked; unlock_with_password() opens it with the password Vault has just checked
through PAM (gnome-keyring's own interface for that), so no second, foreign prompt appears.
QUASAR_VAULT_BUS=ADDRESS uses another bus (tests run a fake keyring on a private dbus-daemon).
"""
import os

SS_NAME = "org.freedesktop.secrets"
SS_PATH = "/org/freedesktop/secrets"
SS_IFACE = "org.freedesktop.Secret.Service"
ITEM_IFACE = "org.freedesktop.Secret.Item"
LOGIN = "/org/freedesktop/secrets/collection/login"
GUILTY = "org.gnome.keyring.InternalUnsupportedGuiltRiddenInterface"


class KeyringError(Exception):
    """kind: "locked" (it stayed locked), "missing" (no Secret Service), "failed"."""
    def __init__(self, kind, message):
        super().__init__(message)
        self.kind = kind


class Keyring:
    def __init__(self, bus=None):
        try:
            from jeepney import DBusAddress
            from jeepney.io.blocking import open_dbus_connection
        except ImportError:
            raise KeyringError("missing", "python3-jeepney is missing")
        self._addr = DBusAddress
        try:
            self.conn = open_dbus_connection(bus=bus or os.environ.get("QUASAR_VAULT_BUS", "SESSION"))
            self.service = DBusAddress(SS_PATH, bus_name=SS_NAME, interface=SS_IFACE)
            self.session = self.call(self.service, "OpenSession", "sv", ("plain", ("s", "")))[1]
        except KeyringError:
            raise
        except Exception as e:                          # noqa: BLE001
            raise KeyringError("missing", f"No keyring: {e}")

    def close(self):
        try:
            self.conn.close()
        except Exception:                               # noqa: BLE001
            pass

    def call(self, addr, method, sig="", body=(), timeout=20):
        from jeepney import new_method_call
        from jeepney.wrappers import unwrap_msg
        return unwrap_msg(self.conn.send_and_get_reply(new_method_call(addr, method, sig, body), timeout=timeout))

    def obj(self, path, iface):
        return self._addr(path, bus_name=SS_NAME, interface=iface)

    # ---- locking ---------------------------------------------------------------------------------
    def collection(self):
        try:
            path = self.call(self.service, "ReadAlias", "s", ("default",))[0]
        except Exception:                               # noqa: BLE001
            path = "/"
        return path if path and path != "/" else LOGIN

    def is_locked(self):
        props = self.obj(self.collection(), "org.freedesktop.DBus.Properties")
        try:
            return bool(self.call(props, "Get", "ss", ("org.freedesktop.Secret.Collection", "Locked"))[0][1])
        except Exception:                               # noqa: BLE001
            return True

    def unlock_with_password(self, password):
        """gnome-keyring: unlock the login collection with its password (no prompt). True on success."""
        coll = self.collection()
        try:
            self.call(self.obj(SS_PATH, GUILTY), "UnlockWithMasterPassword", "o(oayays)",
                      (coll, (self.session, b"", password.encode(), "text/plain")))
        except Exception:                               # noqa: BLE001 (a wrong password, or not gnome-keyring)
            return False
        return not self.is_locked()

    def prompt(self, path):
        if path == "/":
            return None
        from jeepney import MatchRule, message_bus
        from jeepney.wrappers import unwrap_msg
        rule = MatchRule(type="signal", interface="org.freedesktop.Secret.Prompt", member="Completed", path=path)
        unwrap_msg(self.conn.send_and_get_reply(message_bus.AddMatch(rule)))
        with self.conn.filter(rule) as q:
            self.call(self.obj(path, "org.freedesktop.Secret.Prompt"), "Prompt", "s", ("",))
            msg = self.conn.recv_until_filtered(q, timeout=180)
        dismissed, result = msg.body
        if dismissed:
            raise KeyringError("locked", "The keyring stayed locked.")
        return result

    def ensure_unlocked(self, interactive=False):
        if not self.is_locked():
            return
        if not interactive:
            raise KeyringError("locked", "Your passwords are locked.")
        unlocked, prompt = self.call(self.service, "Unlock", "ao", ([self.collection()],))
        if prompt != "/":
            self.prompt(prompt)
        if self.is_locked():
            raise KeyringError("locked", "Your passwords are locked.")

    # ---- items -------------------------------------------------------------------------------------------
    def search(self, attrs):
        unlocked, locked = self.call(self.service, "SearchItems", "a{ss}", (dict(attrs),))
        return list(unlocked) + list(locked)

    def attributes(self, path):
        props = self.obj(path, "org.freedesktop.DBus.Properties")
        return dict(self.call(props, "Get", "ss", (ITEM_IFACE, "Attributes"))[0][1])

    def secret(self, path):
        secrets = self.call(self.service, "GetSecrets", "aoo", ([path], self.session))[0]
        for _p, (_session, _params, value, _ctype) in secrets.items():
            return bytes(value)
        return b""

    def create(self, label, attrs, value, content_type="application/json", replace=False):
        coll = self.collection()
        props = {
            "org.freedesktop.Secret.Item.Label": ("s", label),
            "org.freedesktop.Secret.Item.Attributes": ("a{ss}", dict(attrs)),
        }
        secret = (self.session, b"", value, content_type)
        item, prompt = self.call(self.obj(coll, "org.freedesktop.Secret.Collection"), "CreateItem",
                                 "a{sv}(oayays)b", (props, secret, replace))
        if prompt != "/":
            res = self.prompt(prompt)
            item = res[1] if res else item
        return item

    def set_attributes(self, path, attrs):
        props = self.obj(path, "org.freedesktop.DBus.Properties")
        self.call(props, "Set", "ssv", (ITEM_IFACE, "Attributes", ("a{ss}", dict(attrs))))

    def set_label(self, path, label):
        props = self.obj(path, "org.freedesktop.DBus.Properties")
        self.call(props, "Set", "ssv", (ITEM_IFACE, "Label", ("s", label)))

    def set_secret(self, path, value, content_type="application/json"):
        self.call(self.obj(path, ITEM_IFACE), "SetSecret", "(oayays)", ((self.session, b"", value, content_type),))

    def delete(self, path):
        prompt = self.call(self.obj(path, ITEM_IFACE), "Delete")[0]
        self.prompt(prompt)
