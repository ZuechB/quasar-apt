"""The KeePassXC-Browser protocol, with Vault in KeePassXC's place (one Connection per browser).

Wire format, as KeePassXC 2.7 speaks it (src/browser/BrowserAction.cpp, BrowserMessageBuilder.cpp):
- change-public-keys is plain: the extension sends its session public key, Vault answers with its own.
- Every other request is {action, message, nonce, clientID[, requestID, triggerUnlock]}: `message` is
  NaCl crypto_box (X25519 + XSalsa20-Poly1305) of a JSON object that repeats `action`, sealed with the
  extension's key pair and opened with Vault's. Answers are {action, message, nonce} with the request
  nonce incremented (libsodium's little-endian increment); inside: version, success "true", nonce and
  the action's fields. Errors are plain {action, errorCode (as text), error}.
- Base64 is standard with padding, except the passkey fields (base64url, no padding).
Asking you happens through `ask(kind, info)`, which returns the shell's answer (or None); the daemon
checks the password before it returns.
"""
import base64
import hashlib
import json
import secrets
import string
import uuid as uuidlib

from . import domains, webauthn
from .keyring import KeyringError

VERSION = "2.7.10"          # KeePassXC-Browser offers passkeys from 2.7.7
ROOT_UUID = uuidlib.uuid5(uuidlib.NAMESPACE_URL, "quasar-vault").hex

DATABASE_NOT_OPENED, DATABASE_HASH_NOT_RECEIVED, CLIENT_PUBLIC_KEY_NOT_RECEIVED = 1, 2, 3
CANNOT_DECRYPT_MESSAGE, ACTION_CANCELLED_OR_DENIED, CANNOT_ENCRYPT_MESSAGE = 4, 6, 7
ASSOCIATION_FAILED, INCORRECT_ACTION, EMPTY_MESSAGE_RECEIVED, NO_URL_PROVIDED = 8, 12, 13, 14
NO_LOGINS_FOUND, NO_GROUPS_FOUND, NO_VALID_UUID_PROVIDED, ACCESS_TO_ALL_ENTRIES_DENIED = 15, 16, 18, 19
MESSAGES = {
    1: "Database not opened", 2: "Database hash not available", 3: "Client public key not received",
    4: "Cannot decrypt message", 6: "Action cancelled or denied", 7: "Message encryption failed.",
    8: "KeePassXC association failed, try again", 12: "Incorrect action", 13: "Empty message received",
    14: "No URL provided", 15: "No logins found", 16: "No groups found", 18: "No valid UUID provided",
    19: "Access to all entries is denied",
}
FLATPAK_NAMES = {"org.mozilla.firefox": "Firefox", "com.brave.Browser": "Brave", "org.chromium.Chromium": "Chromium",
                 "com.google.Chrome": "Chrome", "com.microsoft.Edge": "Edge", "io.gitlab.librewolf-community": "LibreWolf",
                 "app.zen_browser.zen": "Zen", "com.vivaldi.Vivaldi": "Vivaldi", "com.opera.Opera": "Opera"}


def increment(nonce):
    """libsodium's sodium_increment: the nonce as a little-endian number, plus one."""
    n = bytearray(nonce)
    carry = 1
    for i in range(len(n)):
        carry += n[i]
        n[i] = carry & 0xFF
        carry >>= 8
    return bytes(n)


def b64(data):
    return base64.b64encode(data).decode()


def unb64(text):
    return base64.b64decode(text or "", validate=False)


def generate_password(length=20):
    alphabet = string.ascii_letters + string.digits + "-_.!@#%+="
    while True:
        pw = "".join(secrets.choice(alphabet) for _ in range(length))
        if (any(c.islower() for c in pw) and any(c.isupper() for c in pw) and any(c.isdigit() for c in pw)
                and any(not c.isalnum() for c in pw)):
            return pw


class Connection:
    def __init__(self, store_factory, ask, notify, database_hash, browser=""):
        """store_factory() -> Store (raises KeyringError("locked") when the keyring is locked).
        ask(kind, info) -> dict | None. notify(title, text): a desktop notification."""
        self.store_factory, self.ask, self.notify = store_factory, ask, notify
        self.database_hash = database_hash
        self.browser = browser                      # "Firefox", from the relay's hello
        self.client_pk = None
        self.box = None
        self.associated = False

    # ---- envelope ----------------------------------------------------------------------------------
    def error(self, action, code):
        return {"action": action, "errorCode": str(code), "error": MESSAGES.get(code, "Error")}

    def seal(self, action, nonce, params):
        nxt = increment(nonce)
        inner = {"version": VERSION, "success": "true", "nonce": b64(nxt)}
        inner.update(params)
        inner.setdefault("action", action)
        cipher = self.box.encrypt(json.dumps(inner).encode(), nxt).ciphertext
        return {"action": action, "message": b64(cipher), "nonce": b64(nxt)}

    def handle(self, req):
        if not isinstance(req, dict) or not req:
            return self.error("", EMPTY_MESSAGE_RECEIVED)
        action = req.get("action")
        if not isinstance(action, str) or not action:
            return self.error("", INCORRECT_ACTION)
        if action == "change-public-keys":
            return self.change_keys(req)
        if self.box is None:
            return self.error(action, CLIENT_PUBLIC_KEY_NOT_RECEIVED)
        try:
            nonce = unb64(req.get("nonce"))
            plain = self.box.decrypt(unb64(req.get("message")), nonce)
            inner = json.loads(plain.decode("utf-8"))
        except Exception:                               # noqa: BLE001 (bad key, nonce or JSON)
            return self.error(action, CANNOT_DECRYPT_MESSAGE)
        if not isinstance(inner, dict):
            return self.error(action, CANNOT_DECRYPT_MESSAGE)
        handler = HANDLERS.get(action)
        if handler is None:
            return self.error(action, INCORRECT_ACTION)
        try:
            store = None if action in ("generate-password", "request-autotype") else self.store_factory()
        except KeyringError as e:
            if e.kind == "locked" and str(req.get("triggerUnlock")) == "true":
                self.ask("unlock", {"browser": self.browser})
            return self.error(action, DATABASE_NOT_OPENED)
        result = handler(self, store, inner, req)
        if isinstance(result, tuple):                   # (error code,)
            return self.error(action, result[0])
        return self.seal(action, nonce, result)

    def change_keys(self, req):
        from nacl.public import Box, PrivateKey, PublicKey
        try:
            client = PublicKey(unb64(req.get("publicKey")))
            nonce = unb64(req.get("nonce"))
        except Exception:                               # noqa: BLE001
            return self.error("change-public-keys", CLIENT_PUBLIC_KEY_NOT_RECEIVED)
        if len(nonce) != 24:
            return self.error("change-public-keys", CLIENT_PUBLIC_KEY_NOT_RECEIVED)
        mine = PrivateKey.generate()
        self.client_pk = bytes(client)
        self.box = Box(mine, client)
        self.associated = False
        return {"action": "change-public-keys", "version": VERSION, "publicKey": b64(bytes(mine.public_key)),
                "success": "true", "nonce": b64(increment(nonce))}

    # ---- association ---------------------------------------------------------------------------------
    def known(self, store, keys):
        for k in keys or []:
            if isinstance(k, dict) and k.get("id") and k.get("key") and store.browser_key(k["id"]) == k["key"]:
                return True
        return False


def a_hash(conn, store, inner, req):
    return {"hash": conn.database_hash}


def a_associate(conn, store, inner, req):
    key = inner.get("key")
    if not key or unb64(key) != conn.client_pk:
        return (ASSOCIATION_FAILED,)
    id_key = inner.get("idKey") or key
    answer = conn.ask("connect", {"browser": conn.browser or "A browser"})
    if not answer or not answer.get("ok"):
        return (ACTION_CANCELLED_OR_DENIED,)
    base = conn.browser or "Browser"
    names = {b["id"] for b in store.browsers()}
    name = base if base not in names else next(f"{base} {i}" for i in range(2, 1000) if f"{base} {i}" not in names)
    store.save_browser(name, id_key)
    conn.associated = True
    return {"hash": conn.database_hash, "id": name}


def a_test_associate(conn, store, inner, req):
    if not inner.get("id") or not inner.get("key"):
        return (DATABASE_NOT_OPENED,)
    if store.browser_key(inner["id"]) != inner["key"]:
        return (ASSOCIATION_FAILED,)
    conn.associated = True
    return {"hash": conn.database_hash, "id": inner["id"]}


def entry(rec):
    return {"login": rec.get("username", ""), "name": rec.get("title", ""), "password": rec.get("password", ""),
            "uuid": rec.get("uuid", ""), "group": "Vault", "totp": "", "skipAutoSubmit": "false", "stringFields": []}


def a_get_logins(conn, store, inner, req):
    if not (conn.associated or conn.known(store, inner.get("keys"))):
        return (ASSOCIATION_FAILED,)
    url = inner.get("url") or ""
    if not url:
        return (NO_URL_PROVIDED,)
    host = domains.host_of(url)
    found = store.logins_for(url)
    if not found:
        return (NO_LOGINS_FOUND,)
    site = domains.site(host)
    if site not in store.allowed_sites():
        answer = conn.ask("fill", {"browser": conn.browser, "site": site, "count": len(found)})
        if not answer or not answer.get("ok"):
            return (ACTION_CANCELLED_OR_DENIED,)
        store.allow_site(site)
    return {"count": len(found), "entries": [entry(r) for r in found], "hash": conn.database_hash,
            "id": inner.get("id", "")}


def a_set_login(conn, store, inner, req):
    if not (conn.associated or conn.known(store, inner.get("keys"))):
        return (ASSOCIATION_FAILED,)
    url = inner.get("url") or inner.get("submitUrl") or ""
    if not url:
        return (NO_URL_PROVIDED,)
    login, password = str(inner.get("login") or ""), str(inner.get("password") or "")
    uid = inner.get("uuid") or None
    if uid and not store.login(uid):
        return (NO_VALID_UUID_PROVIDED,)
    title = domains.site(domains.host_of(url)) or url
    store.save_login(url, login, password, title=title, uid=uid)
    store.allow_site(domains.site(domains.host_of(url)))
    conn.notify("Saved in Vault", f"{login or 'Your login'} for {title}")
    return {"count": None, "entries": None, "error": "success", "hash": conn.database_hash}


def a_generate(conn, store, inner, req):
    return {"password": generate_password(), "requestID": req.get("requestID") or inner.get("requestID") or ""}


def a_groups(conn, store, inner, req):
    if not (conn.associated or conn.known(store, inner.get("keys"))):
        return (ASSOCIATION_FAILED,)
    return {"defaultGroup": "Vault", "defaultGroupAlwaysAllow": False,
            "groups": {"groups": [{"name": "Vault", "uuid": ROOT_UUID, "children": []}]}}


def a_new_group(conn, store, inner, req):
    return {"name": "Vault", "uuid": ROOT_UUID}


def a_lock(conn, store, inner, req):
    return {}


def a_totp(conn, store, inner, req):
    return (NO_VALID_UUID_PROVIDED,)


def a_delete(conn, store, inner, req):
    if not (conn.associated or conn.known(store, inner.get("keys"))):
        return (ASSOCIATION_FAILED,)
    rec = store.login(inner.get("uuid") or "")
    if not rec:
        return (NO_VALID_UUID_PROVIDED,)
    answer = conn.ask("delete", {"browser": conn.browser, "site": rec.get("title", ""), "username": rec.get("username", "")})
    ok = bool(answer and answer.get("ok")) and store.delete_login(rec["uuid"])
    return {"success": "true" if ok else "false"}


def a_autotype(conn, store, inner, req):
    return {}


def a_entries(conn, store, inner, req):
    return (ACCESS_TO_ALL_ENTRIES_DENIED,)


def passkey_error(code):
    return {"response": {"errorCode": code}}


def a_passkeys_register(conn, store, inner, req):
    if not (conn.associated or conn.known(store, inner.get("keys"))):
        return (ASSOCIATION_FAILED,)
    options, origin = inner.get("publicKey") or {}, inner.get("origin") or ""
    try:
        _host, rp_id = webauthn.check_origin(origin, (options.get("rp") or {}).get("id"))
        mine = store.passkeys(rp=rp_id)
        if webauthn.excluded(options, [p["credentialId"] for p in mine]):
            return passkey_error(webauthn.CREDENTIAL_IS_EXCLUDED)
        user = options.get("user") or {}
        answer = conn.ask("passkey-save", {"browser": conn.browser, "site": rp_id,
                                           "username": str(user.get("name") or user.get("displayName") or "")})
        if not answer or not answer.get("ok"):
            return passkey_error(webauthn.REQUEST_CANCELED)
        credential, record = webauthn.register(options, origin)
    except webauthn.WebAuthnError as e:
        return passkey_error(e.code)
    store.save_passkey(record)
    conn.notify("Passkey saved in Vault", f"{record['username'] or record['displayName']} on {record['rpId']}")
    return {"response": credential}


def a_passkeys_get(conn, store, inner, req):
    if not (conn.associated or conn.known(store, inner.get("keys"))):
        return (ASSOCIATION_FAILED,)
    options, origin = inner.get("publicKey") or {}, inner.get("origin") or ""
    try:
        rp_id, found = webauthn.candidates(options, origin, store.passkeys())
        if not found:
            return passkey_error(NO_LOGINS_FOUND)
        answer = conn.ask("passkey-use", {"browser": conn.browser, "site": rp_id,
                                          "accounts": [{"key": p["uuid"], "label": p["username"] or p["displayName"] or "Passkey",
                                                        "sub": p["displayName"]} for p in found]})
        if not answer or not answer.get("ok"):
            return passkey_error(webauthn.REQUEST_CANCELED)
        uid = answer.get("choice") or found[0]["uuid"]
        record = store.passkey_secret(uid)
        if not record or record["rpId"] != rp_id:
            return passkey_error(webauthn.REQUEST_CANCELED)
        credential = webauthn.assertion(options, origin, record)
    except webauthn.WebAuthnError as e:
        return passkey_error(e.code)
    store.passkey_used(uid)
    return {"response": credential}


HANDLERS = {
    "get-databasehash": a_hash, "associate": a_associate, "test-associate": a_test_associate,
    "get-logins": a_get_logins, "set-login": a_set_login, "generate-password": a_generate,
    "get-database-groups": a_groups, "create-new-group": a_new_group, "lock-database": a_lock,
    "get-totp": a_totp, "delete-entry": a_delete, "request-autotype": a_autotype,
    "get-database-entries": a_entries, "passkeys-register": a_passkeys_register, "passkeys-get": a_passkeys_get,
}


def database_hash(user):
    return hashlib.sha256(("quasar-vault:" + user).encode()).hexdigest()


def browser_name(hello):
    fp = (hello or {}).get("flatpak") or ""
    if fp in FLATPAK_NAMES:
        return FLATPAK_NAMES[fp]
    args = " ".join((hello or {}).get("args") or [])
    if "keepassxc-browser@keepassxc.org" in args or "mozilla" in args:
        return "Firefox"
    return "Browser"

