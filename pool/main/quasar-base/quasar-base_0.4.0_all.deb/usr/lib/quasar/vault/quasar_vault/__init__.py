"""Vault: Quasar's passwords and passkeys, kept in your login keyring (gnome-keyring, unlocked by your
account password). /usr/libexec/quasar/vaultd is the entry point (cli.py):

  vaultd daemon     the browsers' side (systemd --user socket unit quasar-vault.socket): speaks the
                    KeePassXC-Browser protocol to the extension through vault-relay, makes and uses
                    passkeys, asks you through the shell (each passkey use and each new site needs
                    your account password, checked here with PAM)
  vaultd session    JSON lines for the Vault app (apps/vault)
  vaultd answer     the shell's reply to a question vaultd asked (one JSON line on stdin)
"""
