"""Browsers and the KeePassXC-Browser extension: finding them and connecting them to Vault.

Flathub browsers run sandboxed: they start a native-messaging host from inside their sandbox, so Vault
puts a small relay there (vault-relay: stdin/stdout <-> $XDG_RUNTIME_DIR/quasar-vault/browser.sock),
writes the host manifest into the browser's own folder, and lets the browser see that one socket
folder (flatpak override --user --filesystem=xdg-run/quasar-vault). Nothing needs root. A manifest
with another path belongs to KeePassXC itself: setting up Vault again takes the browser back.
"""
import json
import os
import shutil
import subprocess

HOST = "org.keepassxc.keepassxc_browser"
FIREFOX_EXT = "keepassxc-browser@keepassxc.org"
CHROME_ORIGINS = ["chrome-extension://oboonakemofpalcgghocfoadofidjkkk/",
                  "chrome-extension://pdffhmdngciaglkoonimfcmckehcpafo/"]
RELAY = os.environ.get("QUASAR_VAULT_RELAY") or "/usr/lib/quasar/vault/vault-relay"
AMO = "https://addons.mozilla.org/firefox/addon/keepassxc-browser/"
CWS = "https://chromewebstore.google.com/detail/keepassxc-browser/oboonakemofpalcgghocfoadofidjkkk"
EDGE = "https://microsoftedge.microsoft.com/addons/detail/keepassxcbrowser/pdffhmdngciaglkoonimfcmckehcpafo"

# Flatpak id -> (name, family, manifest folder inside ~/.var/app/<id>, extension store page)
KNOWN = {
    "org.mozilla.firefox": ("Firefox", "firefox", ".mozilla/native-messaging-hosts", AMO),
    "io.gitlab.librewolf-community": ("LibreWolf", "firefox", ".librewolf/native-messaging-hosts", AMO),
    "org.chromium.Chromium": ("Chromium", "chromium", "config/chromium/NativeMessagingHosts", CWS),
    "com.brave.Browser": ("Brave", "chromium", "config/BraveSoftware/Brave-Browser/NativeMessagingHosts", CWS),
    "com.google.Chrome": ("Chrome", "chromium", "config/google-chrome/NativeMessagingHosts", CWS),
    "com.vivaldi.Vivaldi": ("Vivaldi", "chromium", "config/vivaldi/NativeMessagingHosts", CWS),
    "com.microsoft.Edge": ("Edge", "chromium", "config/microsoft-edge/NativeMessagingHosts", EDGE),
}


def home():
    return os.environ.get("HOME") or os.path.expanduser("~")


def installed_flatpaks():
    out = set()
    for scope in ("--user", "--system"):
        try:
            r = subprocess.run(["flatpak", "list", scope, "--app", "--columns=application"],
                               capture_output=True, text=True, timeout=20)
            out.update(l.strip() for l in r.stdout.splitlines() if l.strip())
        except (OSError, subprocess.TimeoutExpired):
            pass
    return out


def app_dir(app_id):
    return os.path.join(home(), ".var", "app", app_id)


def manifest_path(app_id):
    return os.path.join(app_dir(app_id), KNOWN[app_id][2], HOST + ".json")


def relay_path(app_id):
    return os.path.join(app_dir(app_id), "data", "quasar-vault-relay")


def state(app_id):
    """"ready" (Vault answers it) | "keepassxc" (another program's host) | "off"."""
    try:
        with open(manifest_path(app_id), encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return "off"
    if data.get("path") == relay_path(app_id) and os.access(relay_path(app_id), os.X_OK):
        return "ready"
    return "keepassxc"


def list_browsers():
    apps = installed_flatpaks()
    out = []
    for app_id, (name, family, _folder, store) in KNOWN.items():
        if app_id in apps:
            out.append({"id": app_id, "name": name, "family": family, "state": state(app_id), "store": store})
    return out


def setup(app_id):
    if app_id not in KNOWN:
        raise ValueError("Vault doesn't know that browser")
    name, family, _folder, _store = KNOWN[app_id]
    if not os.access(RELAY, os.X_OK):
        raise OSError("Vault's browser relay is missing")
    rp = relay_path(app_id)
    os.makedirs(os.path.dirname(rp), exist_ok=True)
    tmp = rp + ".tmp"
    shutil.copyfile(RELAY, tmp)
    os.chmod(tmp, 0o755)
    os.replace(tmp, rp)
    manifest = {"name": HOST, "description": "Quasar Vault (answers KeePassXC-Browser)", "path": rp, "type": "stdio"}
    if family == "firefox":
        manifest["allowed_extensions"] = [FIREFOX_EXT]
    else:
        manifest["allowed_origins"] = CHROME_ORIGINS
    mp = manifest_path(app_id)
    os.makedirs(os.path.dirname(mp), exist_ok=True)
    with open(mp + ".tmp", "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)
    os.replace(mp + ".tmp", mp)
    r = subprocess.run(["flatpak", "override", "--user", "--filesystem=xdg-run/quasar-vault", app_id],
                       capture_output=True, text=True, timeout=30)
    if r.returncode != 0:
        raise OSError("flatpak override failed: " + (r.stderr.strip() or str(r.returncode)))
    return state(app_id)


def open_store_page(app_id):
    _name, _family, _folder, store = KNOWN[app_id]
    subprocess.Popen(["flatpak", "run", app_id, store], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                     start_new_session=True)
