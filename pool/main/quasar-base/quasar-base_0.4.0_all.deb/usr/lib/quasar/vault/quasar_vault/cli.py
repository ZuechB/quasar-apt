"""Entry point for /usr/libexec/quasar/vaultd (see __init__.py)."""
import sys


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    mode = argv[0] if argv else ""
    if mode == "daemon":
        from . import daemon
        return daemon.main()
    if mode == "session":
        from . import session
        return session.main()
    if mode == "answer":
        from . import daemon
        return daemon.answer_cli()
    print("usage: vaultd daemon | session | answer", file=sys.stderr)
    return 64
