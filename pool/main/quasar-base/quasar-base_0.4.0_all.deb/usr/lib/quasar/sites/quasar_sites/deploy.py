"""The deploy runner: `sitesd deploy-run <id>` inside quasar-site-deploy@<id>.service.

Steps (the mockup's): get the code -> install/restore -> build -> (first deploy: create the service
and certificate) -> start the new version next to the old one and health-check it -> switch traffic
-> drain and stop the old one. A failure anywhere leaves the old version serving.

Security model:
  * the code is copied and built as the site's OWNER, never as root, and the build runs in a
    transient sandbox (systemd-run): NoNewPrivileges (no sudo), the home folder hidden except the
    site's workspace and read-only SDK folders, read-only system, private /tmp, time and CPU limits;
  * root only ever reads the owner's output through a tar stream it unpacks with tarfile's "data"
    filter (release.py), so it never follows a path the user controls;
  * the result runs as the site's own account in a hardened unit (site-run).
"""
import collections
import json
import os
import re
import shlex
import signal
import stat
import subprocess
import tempfile
import time
import urllib.error
import urllib.request

from . import caddy, datasnap, paths, proc, proxy, release, store, units
from .events import SitesError


class DeployFailed(Exception):
    def __init__(self, message, details=""):
        super().__init__(message)
        self.message, self.details = message, details


class Progress:
    """One run's progress: JSON lines in /run/quasar/sites/<id>/runs/<run>.jsonl (0640, readable by
    the owner's group) and on stdout (the unit's journal)."""

    def __init__(self, sid, owner_gid, run=None):
        self.sid = sid
        # The run id comes from the request (the app already follows it); timers get a fresh one.
        if not (isinstance(run, str) and re.match(r"^\d{8}T\d{6}Z-[0-9a-f]{6}$", run)
                and not os.path.exists(paths.run_file(sid, run))):
            run = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime()) + "-" + os.urandom(3).hex()
        self.run = run
        d = paths.runs(sid)
        os.makedirs(d, mode=0o750, exist_ok=True)
        os.chown(paths.site_run(sid), 0, 0)
        os.chmod(paths.site_run(sid), 0o755)
        os.chown(d, 0, owner_gid)
        os.chmod(d, 0o750)
        fd = os.open(paths.run_file(sid, self.run), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o640)
        os.fchown(fd, 0, owner_gid)
        self.f = os.fdopen(fd, "w", encoding="utf-8", buffering=1)
        store.write_text(paths.current_run(sid), self.run + "\n", mode=0o644)
        self.tail = collections.deque(maxlen=80)
        self.t0 = time.time()
        self._prune(d)

    @staticmethod
    def _prune(d):
        try:
            files = sorted(f for f in os.listdir(d) if f.endswith(".jsonl"))
        except FileNotFoundError:
            return
        for f in files[:-10]:
            try:
                os.unlink(os.path.join(d, f))
            except OSError:
                pass

    def emit(self, kind, **fields):
        rec = {"type": kind, "t": round(time.time(), 3)}
        rec.update(fields)
        line = json.dumps(rec, ensure_ascii=False, separators=(",", ":"))
        try:
            self.f.write(line + "\n")
        except ValueError:
            pass
        print(line, flush=True)

    def plan(self, kind, titles):
        self.emit("plan", run=self.run, kind=kind, steps=titles)

    def step(self, n, title, cmd=""):
        self.emit("step", n=n, title=title, cmd=cmd)

    def line(self, text):
        text = (text or "").rstrip()[:2000]
        if not text:
            return
        self.tail.append(text)
        self.emit("line", text=text)

    def took(self):
        s = max(1, int(time.time() - self.t0))
        return "%ds" % s if s < 60 else "%dm %02ds" % (s // 60, s % 60)

    def done(self, ok, **fields):
        self.emit("done", ok=ok, took=self.took(), **fields)
        try:
            self.f.close()
        except OSError:
            pass


# ---- owner-side helpers -----------------------------------------------------------------------------
def workspace(home, sid):
    return os.path.join(home, ".cache", "quasar", "sites", sid)


def owner_run(uid, cmd, cwd=None, timeout=120, input=None):
    return proc.run(proc.as_user(uid, cmd), check=False, timeout=timeout, env=proc.user_env(uid),
                    cwd=cwd, input=input)


def owner_stream(uid, cmd, on_line, cwd=None):
    return proc.stream(proc.as_user(uid, cmd), on_line, env=proc.user_env(uid), cwd=cwd)


def short_home(path, home):
    return "~" + path[len(home):] if path.startswith(home + "/") or path == home else path


def source_version(uid, home, path, ws):
    """(hash7, message). Git when the project is a repo, a content hash otherwise."""
    if proc.have("git"):
        r = owner_run(uid, ["git", "-C", path, "rev-parse", "--short=7", "HEAD"], timeout=30)
        h = (r.stdout or "").strip()
        if r.returncode == 0 and re.match(r"^[0-9a-f]{7}$", h):
            msg = (owner_run(uid, ["git", "-C", path, "log", "-1", "--format=%s"], timeout=30).stdout or "").strip()
            dirty = (owner_run(uid, ["git", "-C", path, "status", "--porcelain", "--untracked-files=normal"],
                               timeout=60).stdout or "").strip()
            return h, (msg or "Latest commit") + (" + your changes" if dirty else "")
    r = owner_run(uid, ["sh", "-c", "cd \"$1\" && find . -type f ! -path './.git/*' -printf '%P %s %T@\\n' "
                                    "| LC_ALL=C sort | sha1sum", "sh", ws + "/src"], timeout=120)
    h = (r.stdout or "").strip()[:7]
    if not re.match(r"^[0-9a-f]{7}$", h):
        h = os.urandom(4).hex()[:7]
    return h, "Copied from " + short_home(path, home)


# ---- toolchains (resolved as the owner, outside the sandbox) --------------------------------------
def resolve_toolchain(site, uid, home):
    """-> (read-only folders to expose in the sandbox, PATH entries, extra env, node_bin or None)."""
    tool = site.get("tool") or None
    if not tool:
        return [], [], {}, None
    name, spec = tool.get("name"), str(tool.get("spec") or "")
    if name == "node":
        nd = _mise_node(uid, spec)
        if nd and os.path.isfile(os.path.join(nd, "bin", "node")):
            return [nd], [os.path.join(nd, "bin")], {}, os.path.join(nd, "bin")
        if os.path.isfile("/usr/bin/node"):
            return [], [], {}, None
        raise SitesError("This site needs Node.js %s. Install it from the Sites app, then deploy again."
                         % (spec or "LTS"), "missing-sdk")
    if name == "dotnet":
        for root in (os.path.join(home, ".dotnet"), "/usr/lib/dotnet", "/usr/share/dotnet"):
            sdk = os.path.join(root, "sdk")
            try:
                versions = os.listdir(sdk)
            except OSError:
                continue
            if not spec or any(v.split(".")[0] == spec for v in versions):
                if os.access(os.path.join(root, "dotnet"), os.X_OK):
                    ro = [root] if root.startswith(home + "/") else []
                    return ro, [root], {"DOTNET_ROOT": root}, None
        raise SitesError("This site needs the .NET %s SDK. Install it from the Sites app, then deploy again."
                         % spec, "missing-sdk")
    return [], [], {}, None


def pick_version(installs, spec):
    """installs: [(version, path)]. The newest whose major matches spec ("22"), or the newest even
    major (Node's LTS lines) for "lts"/"", or None."""
    def key(v):
        return tuple(int(x) if x.isdigit() else 0 for x in re.split(r"[.+-]", v)[:3])
    cands = sorted(installs, key=lambda iv: key(iv[0]), reverse=True)
    if spec.isdigit():
        cands = [c for c in cands if c[0].split(".")[0] == spec]
    elif spec in ("", "lts"):
        lts = [c for c in cands if c[0].split(".")[0].isdigit() and int(c[0].split(".")[0]) % 2 == 0]
        cands = lts or cands
    return cands[0][1] if cands else None


def _mise_node(uid, spec):
    """The owner's installed Node for spec, from `mise ls --installed --json node` (offline: never
    asks the network which version "lts" is)."""
    if not proc.have("mise"):
        return None
    r = owner_run(uid, ["mise", "ls", "--installed", "--json", "node"], timeout=30)
    try:
        data = json.loads(r.stdout or "[]")
    except ValueError:
        return None
    if isinstance(data, dict):
        data = data.get("node") or []
    installs = [(d.get("version", ""), d.get("install_path", "")) for d in data
                if isinstance(d, dict) and d.get("install_path")]
    return pick_version(installs, spec)


def build_title(cmd):
    c = cmd.strip()
    if re.match(r"^(npm (ci|install|i)\b|pnpm install|yarn( install)?$|bun install)", c):
        return "Install packages"
    if c.startswith("dotnet restore"):
        return "Restore packages"
    if c.startswith("dotnet publish"):
        return "Build and publish"
    return "Build"


def split_build(build):
    return [c.strip() for c in (build or "").split(" && ") if c.strip()]


# A build runs the project's own scripts and every dependency's install scripts: it reaches the internet
# (package registries), never this PC's services or the home network, and never Docker. The owner may be
# in the docker group, which is root in all but name. (ProtectHome=tmpfs already hides /run/user, so a
# rootless engine's socket and the session bus are out of reach too.) DNS goes through resolved's stub.
SANDBOX_LIMITS = ["InaccessiblePaths=-/run/docker.sock", "InaccessiblePaths=-/var/run/docker.sock",
                  "InaccessiblePaths=-/run/containerd", "InaccessiblePaths=-/run/podman",
                  "IPAddressAllow=127.0.0.53", "IPAddressDeny=localhost link-local multicast 10.0.0.0/8 "
                  "172.16.0.0/12 192.168.0.0/16 100.64.0.0/10 fc00::/7"]


def sandbox_cmd(sid, uid, gid, ws, ro_dirs, path_dirs, env_extra, command):
    env = {
        "HOME": ws + "/home", "OUT": ws + "/out", "CI": "1", "LANG": "C.UTF-8",
        "PATH": ":".join(path_dirs + ["/usr/local/bin", "/usr/bin", "/bin"]),
        "NUGET_PACKAGES": ws + "/cache/nuget", "npm_config_cache": ws + "/cache/npm",
        "npm_config_update_notifier": "false", "npm_config_fund": "false", "npm_config_audit": "false",
        "DOTNET_CLI_HOME": ws + "/home", "DOTNET_CLI_TELEMETRY_OPTOUT": "1", "DOTNET_NOLOGO": "1",
        "DOTNET_SKIP_FIRST_TIME_EXPERIENCE": "1", "NEXT_TELEMETRY_DISABLED": "1",
        "ASTRO_TELEMETRY_DISABLED": "1", "GATSBY_TELEMETRY_DISABLED": "1",
    }
    env.update(env_extra)
    props = ["NoNewPrivileges=yes", "ProtectHome=tmpfs", "BindPaths=" + ws, "ProtectSystem=strict",
             "PrivateTmp=yes", "PrivateDevices=yes", "RuntimeMaxSec=2700", "Nice=10",
             "IOSchedulingClass=idle", "WorkingDirectory=" + ws + "/src", "KillMode=mixed",
             "TimeoutStopSec=15"] + ["BindReadOnlyPaths=" + d for d in ro_dirs] + SANDBOX_LIMITS
    cmd = ["systemd-run", "--unit=" + units.build_unit(sid), "--quiet", "--pipe", "--wait", "--collect",
           "--service-type=exec", "--uid=%d" % uid, "--gid=%d" % gid]
    for p in props:
        cmd += ["-p", p]
    for k, v in env.items():
        cmd += ["-E", "%s=%s" % (k, v)]
    return cmd + ["--", "/bin/sh", "-c", command]


def real_dirs(uid, ws, subs=("src", "out", "home", "cache")):
    """A build runs as the owner and could replace a workspace folder with a link (to the owner's home,
    say). The next copy (rsync --delete) would then follow it out of the sandbox, so links go and the
    folders are made again before anything else touches them."""
    for p in [os.path.join(ws, s) for s in subs]:
        if os.path.islink(p):
            owner_run(uid, ["rm", "-f", "--", p])
    for s in subs:
        owner_run(uid, ["mkdir", "-p", os.path.join(ws, s)])


def inside(ws, path):
    """path is ws or a folder below it with no link anywhere on the way (lstat, never followed)."""
    rel = os.path.relpath(path, ws)
    if rel == ".." or rel.startswith(".." + os.sep) or os.path.isabs(rel):
        return False
    cur = ws
    for part in [] if rel == "." else rel.split(os.sep):
        cur = os.path.join(cur, part)
        try:
            st = os.lstat(cur)
        except OSError:
            return False
        if not stat.S_ISDIR(st.st_mode):
            return False
    try:
        return stat.S_ISDIR(os.lstat(ws).st_mode)
    except OSError:
        return False


# ---- health ---------------------------------------------------------------------------------------
class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


def wait_healthy(port, health, host, unit, timeout=60, strict=False):
    """-> HTTP status once the app answers below 500 (strict: with 2xx only, for sites whose health path
    really checks something). Raises DeployFailed otherwise."""
    opener = urllib.request.build_opener(_NoRedirect)
    deadline = time.time() + timeout
    last = ""
    while time.time() < deadline:
        if units.is_failed(unit) or not units.is_active(unit):
            raise DeployFailed("The new version stopped while starting.", units.journal_tail([unit], 40))
        req = urllib.request.Request("http://127.0.0.1:%d%s" % (port, health), headers={"Host": host})
        try:
            with opener.open(req, timeout=3) as r:
                return r.status
        except urllib.error.HTTPError as e:
            if e.code < 500 and not (strict and not 200 <= e.code < 300):
                return e.code
            last = "GET %s returned %d" % (health, e.code)
        except (urllib.error.URLError, OSError) as e:
            last = str(getattr(e, "reason", e))
        time.sleep(0.5)
    raise DeployFailed("The new version didn't answer within %d seconds (%s)." % (timeout, last or "no reply"),
                       units.journal_tail([unit], 40))


# ---- the run ----------------------------------------------------------------------------------------
def _site_gid(site):
    import grp
    name = "caddy" if site.get("kind") == "static" else "site-" + site["id"]
    return grp.getgrnam(name).gr_gid


def _read_request(sid):
    path = paths.request_file(sid)
    req = store.read_json(path, {}) or {}
    try:
        os.unlink(path)
    except FileNotFoundError:
        pass
    return req


def _plan(site, first, build_cmds, rollback):
    is_app = caddy.is_app(site)
    if rollback:
        return ["Start the earlier version" if is_app else "Get the files ready", "Switch traffic"]
    titles = ["Copy the project" if first else "Get the latest code"]
    titles += [build_title(c) for c in build_cmds]
    if first:
        titles.append("Create the service and certificate" if is_app else "Create the address and certificate")
    titles += ["Start the new version" if is_app else "Get the files ready", "Switch traffic"]
    return titles


def _record(sid, entry):
    items = store.deploys(sid)
    items.insert(0, entry)
    store.save_deploys(sid, items)


def run(sid):
    """Entry point. Returns an exit code."""
    def on_term(*_):
        raise KeyboardInterrupt()
    signal.signal(signal.SIGTERM, on_term)

    with store.lock("site-" + sid, wait=False):
        site = store.load_site(sid)
        uid = int(site["owner"])
        name, home, ugid = proc.account(uid)
        req = _read_request(sid)
        st = store.site_state(sid)
        prog = Progress(sid, ugid, req.get("run"))
        # A pipeline's release (quasar-sites-release) is already built: it goes live like a rollback.
        handed = req.get("kind") == "release"
        rollback = req.get("kind") in ("rollback", "release")
        first = not st.get("release")
        build_cmds = [] if rollback else split_build(site.get("build"))
        titles = _plan(site, first, build_cmds, rollback)
        if handed:
            titles[0] = "Start the new version" if caddy.is_app(site) else "Get the files ready"
        prog.plan("rollback" if rollback else "deploy", titles)
        n = 0
        started_slot, rel, hash7, msg = None, None, "", ""
        prev_slot_rel = None
        data_snap = None
        try:
            if uid == 0 and not rollback:
                raise DeployFailed("Sites doesn't build sites that belong to root. Create the site from your own "
                                   "account.")
            if rollback:
                rel = req.get("release") or ""
                meta = release.read_meta(sid, rel)
                if not meta:
                    raise DeployFailed("That release is no longer on this PC.")
                hash7, msg = meta.get("hash", rel[-7:]), meta.get("msg", "")
            else:
                ws = workspace(home, sid)
                # 1. the code
                n += 1
                prog.step(n, titles[n - 1])
                real_dirs(uid, ws)
                src = site.get("source") or {}
                if src.get("type") != "folder":
                    raise DeployFailed("Git sources come in a later update. Use a project folder for now.")
                path = src["path"]
                rc = owner_stream(uid, ["rsync", "-a", "--delete", "--filter=:- .gitignore", "--exclude=/.git",
                                        "--exclude=node_modules/", "--exclude=.DS_Store",
                                        path.rstrip("/") + "/", ws + "/src/"], prog.line)
                if rc != 0:
                    raise DeployFailed("Sites couldn't copy the project. Is the folder still there?",
                                       "\n".join(prog.tail))
                hash7, msg = source_version(uid, home, path, ws)
                prog.line("Copied %s (%s)" % (short_home(path, home), hash7))
                # 2. build in the sandbox
                if build_cmds:
                    ro, path_dirs, env_extra, node_bin = resolve_toolchain(site, uid, home)
                    owner_run(uid, ["sh", "-c", 'rm -rf "$1" && mkdir -p "$1"', "sh", ws + "/out"])
                    proc.systemctl("stop", units.build_unit(sid) + ".service", check=False)
                    proc.systemctl("reset-failed", units.build_unit(sid) + ".service", check=False)
                    for cmd in build_cmds:
                        n += 1
                        prog.step(n, titles[n - 1], cmd)
                        rc = proc.stream(sandbox_cmd(sid, uid, ugid, ws, ro, path_dirs, env_extra, cmd),
                                         prog.line)
                        if rc != 0:
                            errs = [l for l in prog.tail if re.search(r"\berror\b|ERR!|failed", l, re.I)]
                            raise DeployFailed("The build failed.", "\n".join((errs or list(prog.tail))[-12:]))
                else:
                    node_bin = None
                    if site.get("tool"):
                        _, _, _, node_bin = resolve_toolchain(site, uid, home)
                if first:
                    n += 1
                    prog.step(n, titles[n - 1])
                    if caddy.is_app(site):
                        units.write_dropins(site)
                        units.daemon_reload()
                        prog.line("Created site-%s" % sid)
                    prog.line("Quasar's certificate covers %s" % site["hostname"])
                # 3. into a release
                rel = _make_release(site, uid, ugid, ws, hash7, msg, node_bin, st, prog)

            # 4. start the new version
            n += 1
            prog.step(n, titles[n - 1])
            if caddy.is_app(site):
                active = st.get("active")
                slot = units.other(active) if active in units.SLOTS else "a"
                prev_slot_rel = st["slots"].get(slot)
                if (site.get("options") or {}).get("stopFirst") and active in units.SLOTS:
                    prog.line("Stopping the running version first (this site asked for that)")
                    units.stop(units.slot_unit(sid, active))
                # btrfs installs: the site's data folder is a subvolume of its own (made before its first
                # start), and its data as it is now is kept before another version goes live.
                if datasnap.ensure(sid) and not first:
                    data_snap = datasnap.before_deploy(sid, rel)
                    if data_snap:
                        prog.line("Kept the site's data as it was before this version (%s)" % data_snap)
                units.write_dropins(site)
                units.daemon_reload()
                st["slots"][slot] = rel
                store.save_site_state(sid, st)
                unit = units.slot_unit(sid, slot)
                units.stop(unit)
                r = units.start(unit)
                started_slot = slot
                if r.returncode != 0:
                    raise DeployFailed("The new version didn't start.", units.journal_tail([unit], 40))
                port = units.port_of(site, slot)
                prog.line("Listening on http://127.0.0.1:%d" % port)
                status = wait_healthy(port, site.get("health") or "/", site["hostname"], unit,
                                      strict=bool((site.get("options") or {}).get("strictHealth")))
                prog.line("GET %s returned %d" % (site.get("health") or "/", status))
            else:
                prog.line("Files ready in /srv/sites/%s" % sid)

            # 5. switch traffic (the commit point)
            n += 1
            prog.step(n, titles[n - 1])
            old = st.get("active")
            if caddy.is_app(site):
                st["active"] = started_slot
            else:
                release.point_current(sid, rel)
            st["release"] = rel
            st["lastFailed"] = False
            st.pop("stopped", None)
            store.save_site_state(sid, st)
            proxy.apply()
            if first:
                prog.line("Live at https://%s" % site["hostname"])
            else:
                prog.line("Proxy now sends %s to the new version" % site["hostname"])
            # 6. drain the old version
            if caddy.is_app(site) and old in units.SLOTS and old != started_slot:
                # Connections on the old version (a game, a chat, an upload) get this long to finish.
                drain = int((site.get("options") or {}).get("drain") or 10)
                if drain > 10:
                    prog.line("Letting the old version finish its connections (%d s)" % drain)
                time.sleep(max(10, min(drain, 600)))
                units.stop(units.slot_unit(sid, old))
                prog.line("Old version drained and stopped")
            release.prune(sid, protect=list(st["slots"].values()) + [rel])
            if not rollback or handed:
                _record(sid, {"release": rel, "hash": hash7, "msg": msg, "at": int(time.time()),
                              "dur": prog.took(), "ok": True, "err": "", "source": req.get("source"),
                              "dataSnapshot": data_snap})
            prog.done(True, release=rel, hash=hash7)
            return 0
        except (DeployFailed, SitesError, KeyboardInterrupt) as e:
            cancelled = isinstance(e, KeyboardInterrupt)
            message = "Cancelled." if cancelled else getattr(e, "message", str(e))
            details = "" if cancelled else getattr(e, "details", "")
            for l in (details or "").splitlines()[-12:]:
                prog.line(l)
            if started_slot:
                units.stop(units.slot_unit(sid, started_slot))
                st = store.site_state(sid)
                if prev_slot_rel:
                    st["slots"][started_slot] = prev_slot_rel
                else:
                    st["slots"].pop(started_slot, None)
                store.save_site_state(sid, st)
            st = store.site_state(sid)
            if (not rollback or handed) and not cancelled:
                st["lastFailed"] = True
                store.save_site_state(sid, st)
                _record(sid, {"release": None, "hash": hash7, "msg": msg or "Deploy", "at": int(time.time()),
                              "dur": prog.took(), "ok": False, "err": (message + "\n" + (details or "")).strip()[-3000:],
                              "source": req.get("source")})
            if rel and not rollback and rel not in st.get("slots", {}).values():
                release.prune(sid, protect=list(st.get("slots", {}).values()) + [st.get("release")])
            prog.done(False, message=message)
            return 1


def _make_release(site, uid, ugid, ws, hash7, msg, node_bin, st, prog):
    sid = site["id"]
    out = site.get("output") or "src"
    base, _, sub = out.partition("/")
    src_dir = os.path.join(ws, "src" if base == "src" else "out", sub) if sub else os.path.join(ws, base)
    rel = release.new_id(hash7)
    final = paths.release(sid, rel)
    partial = final + ".partial"
    os.makedirs(paths.releases(sid), mode=0o750, exist_ok=True)
    gid = _site_gid(site)

    def unpack(cmd, dest, sandboxed=False):
        with tempfile.TemporaryFile() as errf:
            p = subprocess.Popen(cmd if sandboxed else proc.as_user(uid, cmd), stdout=subprocess.PIPE, stderr=errf,
                                 env=None if sandboxed else proc.user_env(uid))
            try:
                release.extract(p.stdout, dest)
            finally:
                p.stdout.close()
                rc = p.wait()
            if rc != 0:
                errf.seek(0)
                raise DeployFailed("Sites couldn't collect the build output from %s." % short_home(src_dir, ws),
                                   errf.read().decode("utf-8", "replace")[-3000:])

    if not os.path.lexists(src_dir):
        raise DeployFailed("The build finished but %s is missing. Check the build's output folder." % out)
    # The output is the build's: a link on the way to it (or the folder itself) could point anywhere the
    # owner can read. Collected by tar inside the same sandbox, which sees only the workspace.
    if not inside(ws, src_dir):
        raise DeployFailed("The build replaced %s with a link. For safety Sites only collects real folders "
                           "from the workspace." % out)
    proc.systemctl("stop", units.build_unit(sid) + ".service", check=False)
    proc.systemctl("reset-failed", units.build_unit(sid) + ".service", check=False)
    unpack(sandbox_cmd(sid, uid, ugid, ws, [], [], {}, "exec tar -C %s --exclude=./.git --exclude=./.quasar "
                       "-cf - ." % shlex.quote(src_dir)), partial, sandboxed=True)
    runtime = None
    if node_bin:
        unpack(["tar", "-C", node_bin, "--dereference", "-cf", "-", "node"],
               os.path.join(partial, ".quasar", "runtime"))
        runtime = "bundled"
    elif site.get("kind") == "node":
        runtime = "system"
    release.write_meta(partial, {"id": rel, "kind": site.get("kind"), "run": site.get("run", ""),
                                 "health": site.get("health") or "/", "hash": hash7, "msg": msg,
                                 "at": int(time.time()), "runtime": runtime,
                                 "framework": site.get("framework", "")}, gid)
    prev = st.get("release")
    saved = release.dedupe(partial, paths.release(sid, prev)) if prev else 0
    release.finish_perms(partial, gid)
    os.rename(partial, final)
    prog.line("Release %s ready%s" % (rel, " (%d MB shared with the last one)" % (saved >> 20) if saved > 1 << 20 else ""))
    return rel


# ---- reconcile / boot ---------------------------------------------------------------------------------
def reconcile(sid):
    """Make one site's units match its state: safe to repeat. Skipped while a deploy runs."""
    if units.is_active(units.deploy_unit(sid)):
        return
    proc.systemctl("stop", units.build_unit(sid) + ".service", check=False)
    try:
        site = store.load_site(sid)
    except SitesError:
        return
    store.private_perms(site)
    st = store.site_state(sid)
    release.prune(sid, protect=list(st.get("slots", {}).values()) + [st.get("release")])
    if not caddy.is_app(site):
        return
    active = st.get("active")
    for slot in units.SLOTS:
        if slot != active and units.is_active(units.slot_unit(sid, slot)):
            units.stop(units.slot_unit(sid, slot))


def boot():
    g = store.global_state()
    if not g.get("active"):
        return 0
    for site in store.list_sites():
        sid = site["id"]
        reconcile(sid)
        st = store.site_state(sid)
        if caddy.is_app(site) and st.get("active") in units.SLOTS and not st.get("stopped") \
                and (site.get("options") or {}).get("boot", True):
            units.write_dropins(site)
    units.daemon_reload()
    for site in store.list_sites():
        st = store.site_state(site["id"])
        if caddy.is_app(site) and st.get("active") in units.SLOTS and not st.get("stopped") \
                and (site.get("options") or {}).get("boot", True):
            units.start(units.slot_unit(site["id"], st["active"]))
    try:
        proxy.apply()
    except SitesError as e:
        print(json.dumps({"type": "error", "message": e.message, "details": e.details}), flush=True)
    return 0
