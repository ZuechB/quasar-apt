"""Secrets with systemd-creds: encrypted with this PC's host key (never written in plain text).

Each secret is /etc/credstore.encrypted/site-<id>.<NAME>; the site's units pick them up with
ImportCredential=site-%i.* and site-run turns them into environment variables. The host key (not
TPM2 PCRs) is used so a firmware update can't lock every site out of its secrets.
"""
import os

from . import paths, proc
from .events import SitesError


def _name(sid, key):
    return "site-%s.%s" % (sid, key)


def put(sid, key, value):
    os.makedirs(paths.CREDSTORE, mode=0o700, exist_ok=True)
    target = paths.cred_file(sid, key)
    tmp = target + ".new"
    p = proc.run(["systemd-creds", "encrypt", "--with-key=host", "--name=" + _name(sid, key), "-", tmp],
                 input=value, check=False, timeout=60)
    if p.returncode != 0:
        try:
            os.unlink(tmp)
        except FileNotFoundError:
            pass
        raise SitesError("The secret couldn't be encrypted.", "creds-failed", details=p.stderr)
    os.chmod(tmp, 0o600)
    os.replace(tmp, target)


def get(sid, key):
    target = paths.cred_file(sid, key)
    if not os.path.exists(target):
        raise SitesError("That secret doesn't exist.", "not-found")
    p = proc.run(["systemd-creds", "decrypt", "--name=" + _name(sid, key), target, "-"], check=False, timeout=60)
    if p.returncode != 0:
        raise SitesError("The secret couldn't be decrypted on this PC.", "creds-failed", details=p.stderr)
    return p.stdout


def remove(sid, key):
    try:
        os.unlink(paths.cred_file(sid, key))
    except FileNotFoundError:
        pass


def remove_all(sid):
    prefix = "site-%s." % sid
    try:
        names = os.listdir(paths.CREDSTORE)
    except FileNotFoundError:
        return
    for n in names:
        if n.startswith(prefix):
            try:
                os.unlink(os.path.join(paths.CREDSTORE, n))
            except FileNotFoundError:
                pass
