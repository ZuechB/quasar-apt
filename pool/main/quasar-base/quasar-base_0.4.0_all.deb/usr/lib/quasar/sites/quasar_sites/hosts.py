"""The managed block in /etc/hosts.

The image has no nss-myhostname, so *.localhost only resolves in browsers. Sites writes its names
here so every program on this PC (curl, .NET, Node) reaches them too, and public domains served
directly resolve to this PC even when the router lacks NAT loopback.
"""
import os

from . import paths, store

BEGIN = "# BEGIN Quasar Sites (managed by the Sites app; edits inside this block are replaced)"
END = "# END Quasar Sites"


def render_block(names):
    names = sorted(dict.fromkeys(n for n in names if n))
    if not names:
        return ""
    out = [BEGIN]
    for i in range(0, len(names), 8):            # keep lines short
        chunk = " ".join(names[i:i + 8])
        out.append("127.0.0.1\t" + chunk)
        out.append("::1\t\t" + chunk)
    out.append(END)
    return "\n".join(out) + "\n"


def strip_block(text):
    out, inside = [], False
    for line in text.splitlines(keepends=True):
        s = line.strip()
        if s == BEGIN:
            inside = True
            continue
        if inside and s == END:
            inside = False
            continue
        if not inside:
            out.append(line)
    return "".join(out)


def merged(text, names):
    base = strip_block(text)
    if base and not base.endswith("\n"):
        base += "\n"
    return base + render_block(names)


def update(names):
    try:
        with open(paths.HOSTS, encoding="utf-8") as f:
            text = f.read()
    except FileNotFoundError:
        text = "127.0.0.1\tlocalhost\n::1\t\tlocalhost ip6-localhost ip6-loopback\n"
    new = merged(text, names)
    if new != text:
        store.write_text(paths.HOSTS, new, mode=0o644)


def clear():
    if os.path.exists(paths.HOSTS):
        update([])
