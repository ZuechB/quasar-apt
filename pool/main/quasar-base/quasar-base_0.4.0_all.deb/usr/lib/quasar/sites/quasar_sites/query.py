"""/usr/libexec/quasar/sites-query: read-only answers for the Sites app. Runs as the user, no pkexec.

  state                    everything the window needs, in one call (polled every 5 s while visible)
  site ID                  one site: definition, live state, deploy history, releases
  scan                     projects found in the usual folders (+ which of those folders exist: roots)
  detect PATH              how a folder would be built and run
  starter                  make the example site's folder (~/Sites/my-site) if needed and detect it
  tools                    SDKs this account has (quasar-dev / mise) and whether git is there
  follow ID RUN            a deploy's progress, as it happens, until it finishes
  logs ID [-f]             app output + requests, merged ({"type":"log"})
  metrics ID [-f]          requests per minute, p95 response time, sparkline (from the access log)
  trust-browsers           add Quasar's CA to this account's Chrome / Flatpak browser stores
"""
import json
import os
import re
import selectors
import subprocess
import sys
import time

from . import caddy, detect, events, paths, proc, release, starter, store, units, validate
from .events import SitesError, emit, result


def _ts(raw):
    raw = (raw or "").strip()
    if raw.startswith("@"):
        try:
            return int(float(raw[1:]))
        except ValueError:
            return None
    return None


def _int(raw):
    try:
        return int(raw)
    except (TypeError, ValueError):
        return None


def summarize(site, st, info):
    sid = site["id"]
    dep = info.get(units.deploy_unit(sid), {})
    deploying = dep.get("ActiveState") in ("active", "activating")
    mem, since = None, None
    if caddy.is_app(site):
        slot = st.get("active")
        u = info.get(units.slot_unit(sid, slot), {}) if slot in units.SLOTS else {}
        a, sub, res = u.get("ActiveState"), u.get("SubState"), u.get("Result")
        if not st.get("release"):
            state = "new"
        elif a == "active":
            state = "live"
            mem = _int(u.get("MemoryCurrent"))
            since = _ts(u.get("ActiveEnterTimestamp"))
        elif a in ("activating", "reloading") or sub == "auto-restart":
            state = "starting"
        elif st.get("stopped"):
            state = "stopped"
        elif a == "failed" or res in ("start-limit-hit", "exit-code", "signal", "core-dump", "timeout",
                                       "oom-kill"):
            state = "crashed"
        else:
            state = "stopped"
    else:
        state = "new" if not st.get("release") else ("stopped" if st.get("stopped") else "live")
    src = site.get("source") or {}
    return {
        "id": sid, "name": site.get("name", sid), "kind": site.get("kind"), "label": site.get("label", ""),
        "framework": site.get("framework", ""), "tool": site.get("tool"), "hostname": site.get("hostname"),
        "port": site.get("port"), "state": state, "deploying": deploying,
        "lastFailed": bool(st.get("lastFailed")), "release": st.get("release"), "slot": st.get("active"),
        "memory": mem, "since": since, "options": site.get("options") or {}, "lan": site.get("lan") or {},
        "public": site.get("public") or {}, "build": site.get("build", ""), "run": site.get("run", ""),
        "health": site.get("health", "/"), "output": site.get("output", ""),
        "source": src.get("path") or src.get("url") or "", "sourceType": src.get("type", "folder"),
        "owner": site.get("owner"), "data": "/var/lib/quasar-site/" + sid if caddy.is_app(site) else "",
        "deployers": site.get("deployers") or [],
    }


def cmd_state(args):
    g = store.global_state()
    sites = store.list_sites()
    names = [units.PROXY]
    for s in sites:
        names.append(units.deploy_unit(s["id"]))
        if caddy.is_app(s):
            names += [units.slot_unit(s["id"], slot) for slot in units.SLOTS]
    info = units.show(names) if g.get("active") else {}
    proxy_state = (info.get(units.PROXY) or {}).get("ActiveState", "inactive")
    result(
        active=bool(g.get("active")), proxy=proxy_state,
        live=os.path.exists(paths.LIVE_MARK) and not os.path.exists(paths.ALLOW_LIVE),
        caddy=proc.have("caddy"), caCode=g.get("caCode", ""), home=g.get("home") or {},
        tunnel=g.get("tunnel") or {}, everywhere=bool(g.get("bindEverywhere")),
        sites=[summarize(s, store.site_state(s["id"]), info) for s in sites],
    )


def cmd_site(args):
    sid = validate.site_id(args[0])
    site = store.load_site(sid)
    st = store.site_state(sid)
    names = [units.deploy_unit(sid)] + ([units.slot_unit(sid, s) for s in units.SLOTS] if caddy.is_app(site) else [])
    info = units.show(names)
    out = summarize(site, st, info)
    out["env"] = site.get("env", [])
    out["secrets"] = site.get("secrets", [])
    out["deploys"] = store.deploys(sid)
    out["releases"] = release.list_releases(sid)
    result(site=out)


def cmd_scan(args):
    home = os.path.expanduser("~")
    used = {(s.get("source") or {}).get("path") for s in store.list_sites()}
    roots = [os.path.join(home, r) for r in detect.SCAN_ROOTS if os.path.isdir(os.path.join(home, r))]
    result(projects=detect.scan(home, exclude=used), roots=roots)


def cmd_detect(args):
    path = os.path.expanduser(" ".join(args)) if args else ""
    if not path.startswith("/"):
        raise SitesError("Pick a project folder.", "invalid", events.USAGE)
    found = detect.detect(path)
    if "error" in found:
        raise SitesError(found["error"], "not-found")
    result(project=found)


def cmd_starter(args):
    home = os.path.expanduser("~")
    path, created = starter.make(home, store.list_sites())
    found = detect.detect(path)
    if "error" in found:
        raise SitesError(found["error"], "not-found")
    result(project=found, created=created)


def cmd_tools(args):
    home = os.path.expanduser("~")
    have = {"mise": proc.have("mise"), "git": proc.have("git"), "node": [], "dotnet": []}
    if os.access("/usr/libexec/quasar/quasar-dev", os.X_OK):
        p = proc.run(["/usr/libexec/quasar/quasar-dev", "status"], check=False, timeout=30,
                     env=proc.base_env({"HOME": home}))
        for line in (p.stdout or "").splitlines():
            if line.startswith("STATUS "):
                try:
                    data = json.loads(line[7:])
                except ValueError:
                    data = {}
                for tool in ("node", "dotnet"):
                    for item in data.get(tool) or []:
                        v = item.get("version") if isinstance(item, dict) else None
                        if v:
                            have[tool].append(v)
    for root in (os.path.join(home, ".dotnet"), "/usr/lib/dotnet", "/usr/share/dotnet"):
        try:
            have["dotnet"] += [v for v in os.listdir(os.path.join(root, "sdk")) if v[:1].isdigit()]
        except OSError:
            pass
    if os.path.isfile("/usr/bin/node"):
        p = proc.run(["/usr/bin/node", "--version"], check=False, timeout=10)
        if p.returncode == 0:
            have["node"].append(p.stdout.strip().lstrip("v"))
    have["node"] = sorted(set(have["node"]), reverse=True)
    have["dotnet"] = sorted(set(have["dotnet"]), reverse=True)
    result(tools=have)


def cmd_follow(args):
    sid = validate.site_id(args[0])
    run = args[1] if len(args) > 1 else ""
    if not run:
        try:
            with open(paths.current_run(sid)) as f:
                run = f.read().strip()
        except OSError:
            raise SitesError("No deploy has run yet.", "not-found")
    if not re.match(r"^\d{8}T\d{6}Z-[0-9a-f]{6}$", run):
        raise SitesError("Unknown deploy.", "usage", events.USAGE)
    path = paths.run_file(sid, run)
    deadline = time.time() + 30
    while not os.path.exists(path):
        if time.time() > deadline:
            emit("done", ok=False, message="The deploy didn't start. Check that Sites is on.")
            return 1
        time.sleep(0.3)
    idle_since = time.time()
    with open(path, encoding="utf-8") as f:
        buf = ""
        while True:
            chunk = f.read()
            if chunk:
                idle_since = time.time()
                buf += chunk
                while "\n" in buf:
                    line, buf = buf.split("\n", 1)
                    if not line.strip():
                        continue
                    sys.stdout.write(line + "\n")
                    sys.stdout.flush()
                    try:
                        if json.loads(line).get("type") == "done":
                            return 0
                    except ValueError:
                        pass
                continue
            if time.time() - idle_since > 5 and not units.is_active(units.deploy_unit(sid)):
                emit("done", ok=False, message="The deploy stopped unexpectedly.")
                return 1
            time.sleep(0.25)


# ---- logs & metrics --------------------------------------------------------------------------------
def _access_line(rec):
    req = rec.get("request") or {}
    ms = rec.get("duration")
    ms = int(round(ms * 1000)) if isinstance(ms, (int, float)) else 0
    return {"type": "log", "t": rec.get("ts"), "src": "req", "status": rec.get("status"),
            "m": "%s %s %s in %d ms" % (req.get("method", "?"), req.get("uri", "/"), rec.get("status", "?"), ms)}


def _tail_bytes(path, nbytes):
    try:
        with open(path, "rb") as f:
            f.seek(0, os.SEEK_END)
            size = f.tell()
            f.seek(max(0, size - nbytes))
            data = f.read()
    except OSError:
        return []
    lines = data.decode("utf-8", "replace").splitlines()
    return lines[1:] if size > nbytes else lines


def _access_records(sid, nbytes=2 << 20):
    out = []
    for line in _tail_bytes(paths.access_log(sid), nbytes):
        try:
            rec = json.loads(line)
        except ValueError:
            continue
        if isinstance(rec, dict) and "request" in rec:
            out.append(rec)
    return out


def _journal_cmd(sid, follow, n):
    cmd = ["journalctl", "--no-pager", "-o", "json", "-n", str(n)]
    if follow:
        cmd.append("-f")
    for slot in units.SLOTS:
        cmd += ["-u", units.slot_unit(sid, slot)]
    return cmd


def _journal_line(raw):
    try:
        rec = json.loads(raw)
    except ValueError:
        return None
    msg = rec.get("MESSAGE")
    if isinstance(msg, list):
        msg = bytes(msg).decode("utf-8", "replace")
    if not msg:
        return None
    try:
        t = int(rec.get("__REALTIME_TIMESTAMP", "0")) / 1e6
    except ValueError:
        t = time.time()
    return {"type": "log", "t": t, "src": "app", "m": str(msg)[:2000]}


def cmd_logs(args):
    sid = validate.site_id(args[0])
    follow = "-f" in args[1:]
    site = store.load_site(sid)
    items = [_access_line(r) for r in _access_records(sid, 256 << 10)][-150:]
    if caddy.is_app(site):
        p = proc.run(_journal_cmd(sid, False, 150), check=False, timeout=20)
        items += [x for x in (_journal_line(l) for l in (p.stdout or "").splitlines()) if x]
    items.sort(key=lambda x: x.get("t") or 0)
    for item in items[-200:]:
        print(json.dumps(item, separators=(",", ":")), flush=True)
    if not follow:
        return 0
    sel = selectors.DefaultSelector()
    jp = None
    if caddy.is_app(site):
        jp = subprocess.Popen(_journal_cmd(sid, True, 0), stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                              text=True, bufsize=1)
        sel.register(jp.stdout, selectors.EVENT_READ)
    log = paths.access_log(sid)
    pos = os.path.getsize(log) if os.path.exists(log) else 0
    try:
        while True:
            for key, _ in sel.select(timeout=0.5):
                line = key.fileobj.readline()
                if not line:
                    sel.unregister(key.fileobj)
                    continue
                item = _journal_line(line)
                if item:
                    print(json.dumps(item, separators=(",", ":")), flush=True)
            try:
                size = os.path.getsize(log)
            except OSError:
                size = 0
            if size < pos:            # rolled over
                pos = 0
            if size > pos:
                with open(log, "rb") as f:
                    f.seek(pos)
                    data = f.read(size - pos)
                pos = size
                for line in data.decode("utf-8", "replace").splitlines():
                    try:
                        rec = json.loads(line)
                    except ValueError:
                        continue
                    if isinstance(rec, dict) and "request" in rec:
                        print(json.dumps(_access_line(rec), separators=(",", ":")), flush=True)
    finally:
        if jp:
            jp.kill()


def metrics_from(records, now=None):
    """rpm (last 60 s), p95 in ms (last 5 min), errors (5xx, last 5 min) and a 16-point sparkline of
    requests per minute in 30 s steps (last 8 min)."""
    now = now or time.time()
    durs, rpm, errors = [], 0, 0
    hist = [0] * 16
    for rec in records:
        ts = rec.get("ts")
        if not isinstance(ts, (int, float)):
            continue
        age = now - ts
        if age < 0 or age > 480:
            continue
        idx = 15 - int(age // 30)
        if 0 <= idx < 16:
            hist[idx] += 2                      # 30 s bucket -> per minute
        if age <= 60:
            rpm += 1
        if age <= 300:
            d = rec.get("duration")
            if isinstance(d, (int, float)):
                durs.append(d * 1000)
            if isinstance(rec.get("status"), int) and rec["status"] >= 500:
                errors += 1
    durs.sort()
    p95 = int(round(durs[min(len(durs) - 1, int(len(durs) * 0.95))])) if durs else None
    return {"rpm": rpm, "p95": p95, "errors": errors, "hist": hist}


def cmd_metrics(args):
    sid = validate.site_id(args[0])
    follow = "-f" in args[1:]
    while True:
        result(metrics=metrics_from(_access_records(sid)))
        if not follow:
            return 0
        time.sleep(5)


def cmd_trust_browsers(args):
    if not proc.have("certutil"):
        raise SitesError("certutil isn't installed.", "missing-tool")
    home = os.path.expanduser("~")
    anchor = paths.TRUST_ANCHOR
    if not os.path.exists(anchor):
        raise SitesError("Turn on Sites first.", "off", events.UNAVAILABLE)
    dbs = [os.path.join(home, ".pki", "nssdb")]
    for app in ("com.google.Chrome", "org.chromium.Chromium", "com.brave.Browser", "com.microsoft.Edge"):
        dbs.append(os.path.join(home, ".var", "app", app, ".pki", "nssdb"))
    import glob
    dbs += glob.glob(os.path.join(home, ".var", "app", "org.mozilla.firefox", ".mozilla", "firefox", "*.*"))
    done = []
    for db in dbs:
        parent = os.path.dirname(db)
        if db.endswith("nssdb") and not os.path.isdir(parent):
            continue
        os.makedirs(db, mode=0o700, exist_ok=True)
        if not os.path.exists(os.path.join(db, "cert9.db")):
            proc.run(["certutil", "-d", "sql:" + db, "-N", "--empty-password"], check=False)
        proc.run(["certutil", "-d", "sql:" + db, "-D", "-n", "Quasar Sites Local CA"], check=False)
        p = proc.run(["certutil", "-d", "sql:" + db, "-A", "-t", "C,,", "-n", "Quasar Sites Local CA",
                      "-i", anchor], check=False)
        if p.returncode == 0:
            done.append(db)
    result(trusted=done)


VERBS = {"state": (cmd_state, 0), "site": (cmd_site, 1), "scan": (cmd_scan, 0), "detect": (cmd_detect, 1),
         "starter": (cmd_starter, 0),
         "tools": (cmd_tools, 0), "follow": (cmd_follow, 1), "logs": (cmd_logs, 1),
         "metrics": (cmd_metrics, 1), "trust-browsers": (cmd_trust_browsers, 0)}


def main(argv):
    def go(argv):
        if not argv or argv[0] not in VERBS:
            events.usage("Usage: sites-query " + "|".join(sorted(VERBS)) + " …")
        fn, nargs = VERBS[argv[0]]
        if len(argv) - 1 < nargs:
            events.usage("%s needs %d argument(s)." % (argv[0], nargs))
        return fn(argv[1:])
    return events.run_main(go, argv)
