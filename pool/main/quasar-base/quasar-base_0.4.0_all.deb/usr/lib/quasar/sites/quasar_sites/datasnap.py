"""A site's own data (its StateDirectory, /var/lib/quasar-site/<id>) on btrfs installs.

The installer puts everything Sites keeps on its own subvolume, @sites, mounted at /var/lib/quasar-sites,
with its data folder bound to /var/lib/quasar-site (so restoring the system never takes a site's data
back). Sites makes each site's folder there a subvolume of its own before the site first starts (systemd
would make a plain folder), and takes a read-only snapshot of it before every deploy: the data as it was
before that version went live, kept for the last KEEP deploys, in /var/lib/quasar-sites/data-snapshots/<id>/.
On other installs (ext4) all of this does nothing.

Paths go through the volume's own mount, not the bind at /var/lib/quasar-site, so a snapshot stays on one
mount. Tests: QUASAR_SITES_ROOT, with QUASAR_SITES_BTRFS=1 standing in for the mount check.
"""
import os
import re
import shutil
import time

from . import paths, proc

VOLUME = paths.p("/var/lib/quasar-sites")
DATA = os.path.join(VOLUME, "data")
SNAPS = os.path.join(VOLUME, "data-snapshots")
KEEP = 5
BTRFS = "/usr/bin/btrfs"
SUBVOLUME_INO = 256              # every btrfs subvolume's root directory has this inode number
NAME_RE = re.compile(r"^\d{8}-\d{6}-[A-Za-z0-9._-]{0,40}$")


def available():
    """Sites' volume is its own btrfs subvolume (a btrfs install)."""
    if paths.ROOT:
        return os.environ.get("QUASAR_SITES_BTRFS") == "1" and os.path.isdir(DATA)
    try:
        with open("/proc/self/mountinfo", encoding="utf-8") as fh:
            for line in fh:
                left, sep, right = line.partition(" - ")
                l, r = left.split(), right.split()
                if sep and len(l) >= 5 and l[4] == VOLUME and r[:1] == ["btrfs"]:
                    return True
    except OSError:
        pass
    return False


def folder(sid):
    return os.path.join(DATA, sid)


def is_subvolume(path):
    try:
        st = os.stat(path)
    except OSError:
        return False
    if paths.ROOT:
        return os.path.exists(os.path.join(path, ".fake-subvol"))
    return st.st_ino == SUBVOLUME_INO


def ensure(sid):
    """Before the site first starts: its data folder as a subvolume of its own. True when it is one (an
    older site's plain folder stays as it is: it just gets no snapshots)."""
    if not available():
        return False
    path = folder(sid)
    if os.path.lexists(path):
        return is_subvolume(path)
    proc.run([BTRFS, "subvolume", "create", path])
    os.chmod(path, 0o700)
    return True


def snapshots(sid):
    try:
        return sorted(n for n in os.listdir(os.path.join(SNAPS, sid)) if NAME_RE.match(n))
    except OSError:
        return []


def before_deploy(sid, label):
    """A read-only snapshot of the site's data as it is now, named for the version about to go live.
    Returns its name, or None when there's nothing to snapshot (not btrfs, an older plain folder)."""
    if not available() or not is_subvolume(folder(sid)):
        return None
    d = os.path.join(SNAPS, sid)
    os.makedirs(d, mode=0o700, exist_ok=True)
    name = time.strftime("%Y%m%d-%H%M%S") + "-" + re.sub(r"[^A-Za-z0-9._-]", "", label or "")[:40]
    target = os.path.join(d, name)
    if os.path.lexists(target):
        return None
    proc.run([BTRFS, "subvolume", "snapshot", "-r", folder(sid), target])
    prune(sid)
    return name


def prune(sid, keep=KEEP):
    for n in snapshots(sid)[:-keep] if keep else snapshots(sid):
        proc.run([BTRFS, "subvolume", "delete", os.path.join(SNAPS, sid, n)], check=False)


def remove(sid):
    """The site is being removed: its data snapshots go too, and its data folder if it's a subvolume."""
    prune(sid, keep=0)
    shutil.rmtree(os.path.join(SNAPS, sid), ignore_errors=True)
    if available() and is_subvolume(folder(sid)):
        proc.run([BTRFS, "subvolume", "delete", folder(sid)], check=False)
