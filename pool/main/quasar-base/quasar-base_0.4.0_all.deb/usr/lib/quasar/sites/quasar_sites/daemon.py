"""/usr/lib/quasar/sites/sitesd: jobs the systemd units run, never called through pkexec.

  deploy-run ID        quasar-site-deploy@ID.service (ExecStart)
  reconcile ID         quasar-site-deploy@ID.service (ExecStopPost): fix half-finished switches
  boot                 quasar-sites-boot.service: start the sites set to start with the PC
  ca-renew             quasar-sites-ca.service: renew the intermediate before it expires
  reset-for-install    the installer, inside the target chroot (removes all Sites state)
  remove-owner UID     quasar-users, when it removes that account: its sites go with it
  release-accept       quasar-sites-release@.service: a deploy agent hands over a built release
"""
import os

from . import admin, ca, deploy, events, incoming, proxy, store, validate
from .events import SitesError


def main(argv):
    def go(argv):
        if os.environ.get("PKEXEC_UID") is not None:
            raise SitesError("sitesd is only run by Quasar's own services.", "usage", events.USAGE)
        if not argv:
            events.usage("Usage: sitesd deploy-run|reconcile|boot|ca-renew|reset-for-install|remove-owner")
        verb = argv[0]
        if verb == "deploy-run":
            return deploy.run(validate.site_id(argv[1]))
        if verb == "reconcile":
            deploy.reconcile(validate.site_id(argv[1]))
            return 0
        if verb == "boot":
            return deploy.boot()
        if verb == "ca-renew":
            # The web server only needs a restart when Sites is on (the CA may be renewed without it).
            if ca.exists() and ca.ensure() and store.global_state().get("active"):
                proxy.apply(force_restart=True)
            return 0
        if verb == "reset-for-install":
            return admin.reset_for_install()
        if verb == "remove-owner" and len(argv) == 2 and argv[1].isdigit() and int(argv[1]) >= 1000:
            return admin.remove_owner(int(argv[1]))
        if verb == "release-accept":
            return incoming.accept(0)
        events.usage("Unknown job %s." % verb)
    return events.run_main(go, argv)
