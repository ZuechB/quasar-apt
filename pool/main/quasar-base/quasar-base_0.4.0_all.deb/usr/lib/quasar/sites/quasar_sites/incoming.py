"""A release handed over by a pipeline: `sitesd release-accept`, run by quasar-sites-release@.service, one
per connection to /run/quasar/sites-release.sock. That socket is mode 0660 and group quasar-deployers,
which only Quasar's deploy agents (quasar-dp-<space>) are in.

Protocol (newline-delimited JSON, then bytes):
  client -> {"site": ID, "commit": "…", "run": "https://dev.azure.com/…", "pipeline": "…", "message": "…"}\\n
  client -> an uncompressed tar of the built site (what the release folder should hold)
  server -> progress lines (the deploy's own JSON lines: step, line, done …)

Checks, in order:
- the caller (SO_PEERCRED, read before anything else) must be in the site's `deployers` (quasar-sites-admin
  deployers);
- Sites must be on, and no deploy may be running;
- the stream may hold at most MAX_BYTES and MAX_FILES, plain tar only (no compression: a small upload
  can't unpack to fill the disk);
- under .quasar/ only the bundled Node runtime is accepted (.quasar/release.json is Sites' own);
- every member goes through tarfile's data filter.

The tree lands in /srv/sites/<id>/incoming/ (pruning never looks there), then moves into releases/ and
goes live through the site's deploy unit: start, health check, switch, drain. A failed one never takes
traffic.
"""
import json
import os
import pwd
import re
import shutil
import socket
import struct
import tarfile
import time

from . import paths, proc, release, store, units, validate
from .events import SitesError

MAX_BYTES = 2 << 30
MAX_FILES = 200000
RUN_URL_RE = re.compile(r"^https://(dev\.azure\.com|[a-z0-9][a-z0-9-]{0,62}\.visualstudio\.com)/[!-~]{1,500}$")
COMMIT_RE = re.compile(r"^[0-9a-f]{7,40}$")
TEXT_RE = re.compile(r"^[^\x00-\x1f\x7f]{0,200}$")


class Refused(Exception):
    def __init__(self, message, code=1):
        super().__init__(message)
        self.code = code


def check_header(h):
    """The client's first line, validated: {site, commit, run, pipeline, message}."""
    if not isinstance(h, dict):
        raise Refused("The request wasn't readable.")
    try:
        sid = validate.site_id(str(h.get("site") or ""))
    except SitesError:
        raise Refused("Unknown site.")
    out = {"site": sid}
    commit = str(h.get("commit") or "").lower()
    out["commit"] = commit if COMMIT_RE.match(commit) else ""
    run = str(h.get("run") or "")
    if run and not RUN_URL_RE.match(run):
        raise Refused("The run address must be an Azure DevOps link.")
    out["run"] = run
    for k, n in (("pipeline", 100), ("message", 200)):
        v = str(h.get(k) or "")[:n]
        out[k] = v if TEXT_RE.match(v) else ""
    return out


def member_allowed(name):
    """Names inside the tar: the site's own files, plus the bundled Node runtime under .quasar/."""
    n = name[2:] if name.startswith("./") else name
    n = n.rstrip("/")
    if n in ("", "."):
        return True
    if n == ".quasar" or n == ".quasar/runtime" or n == ".quasar/runtime/node":
        return True
    return not (n == ".quasar" or n.startswith(".quasar/"))


class Capped:
    """A read-only stream that refuses to give more than `limit` bytes."""

    def __init__(self, f, limit):
        self.f, self.left = f, limit

    def read(self, n=-1):
        if n is None or n < 0:
            n = 1 << 20
        data = self.f.read(min(n, self.left + 1))
        self.left -= len(data)
        if self.left < 0:
            raise Refused("The release is larger than %d GB." % (MAX_BYTES >> 30))
        return data


def peer_uid(sock):
    creds = sock.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, struct.calcsize("3i"))
    return struct.unpack("3i", creds)[1]


def unpack(stream, dest):
    os.makedirs(dest, mode=0o750)
    files = 0
    try:
        with tarfile.open(fileobj=stream, mode="r|") as tf:
            for m in tf:
                files += 1
                if files > MAX_FILES:
                    raise Refused("The release has more than %d files." % MAX_FILES)
                if not member_allowed(m.name):
                    raise Refused("The release contains %s: only the Node runtime may go under .quasar/." % m.name)
                tf.extract(m, dest, filter="data")
    except tarfile.FilterError as e:
        raise Refused("The release contains a file Sites won't copy: %s" % e)
    except (tarfile.TarError, EOFError) as e:
        raise Refused("The release couldn't be read (send an uncompressed tar): %s" % e)
    if files == 0:
        raise Refused("The release is empty.")


def accept(fd=0):
    sock = socket.socket(fileno=fd)
    out = sock.makefile("w", encoding="utf-8", buffering=1)

    def send(**kw):
        try:
            out.write(json.dumps(kw) + "\n")
        except OSError:
            pass

    staging = None
    try:
        uid = peer_uid(sock)
        try:
            account = pwd.getpwuid(uid).pw_name
        except KeyError:
            raise Refused("Unknown caller.", 3)
        sock.settimeout(30)
        rf = sock.makefile("rb")
        line = rf.readline(4097)
        if len(line) > 4096 or not line.endswith(b"\n"):
            raise Refused("The request wasn't readable.")
        try:
            h = check_header(json.loads(line))
        except ValueError:
            raise Refused("The request wasn't readable.")
        sid = h["site"]
        try:
            site = store.load_site(sid)
        except SitesError:
            raise Refused("There's no site called %s." % sid)
        if account not in (site.get("deployers") or []):
            raise Refused("%s may not deploy %s. Allow it in Sites (the site's settings) first." % (account, sid), 3)
        if not store.global_state().get("active"):
            raise Refused("Sites is turned off on this PC.", 5)
        if units.is_active(units.deploy_unit(sid)):
            raise Refused("Another deploy of %s is running. Try again in a moment." % sid, 4)
        send(type="line", text="Receiving the release for %s" % sid)
        rel = release.new_id(h["commit"][:7])
        os.makedirs(paths.incoming(sid), mode=0o750, exist_ok=True)
        staging = os.path.join(paths.incoming(sid), rel + ".partial")
        sock.settimeout(600)
        unpack(Capped(rf, MAX_BYTES), staging)
        gid = _site_gid(site)
        runtime = "bundled" if os.path.isfile(os.path.join(staging, ".quasar", "runtime", "node")) else \
            ("system" if site.get("kind") == "node" else None)
        release.write_meta(staging, {"id": rel, "kind": site.get("kind"), "run": site.get("run", ""),
                                     "health": site.get("health") or "/", "hash": h["commit"][:7] or rel[-7:],
                                     "msg": h["message"] or h["pipeline"] or "Azure Pipelines", "at": int(time.time()),
                                     "runtime": runtime, "framework": site.get("framework", ""), "source": "azure"}, gid)
        st = store.site_state(sid)
        if st.get("release"):
            release.dedupe(staging, paths.release(sid, st["release"]))
        release.finish_perms(staging, gid)
        os.makedirs(paths.releases(sid), mode=0o750, exist_ok=True)
        os.rename(staging, paths.release(sid, rel))
        staging = None
        run = _queue(site, rel, h, account)
        send(type="line", text="Release %s queued; deploying" % rel)
        return _follow(sid, run, send)
    except Refused as e:
        send(type="done", ok=False, message=str(e))
        return e.code
    except (OSError, SitesError) as e:
        send(type="done", ok=False, message="The release couldn't be taken: %s" % getattr(e, "message", e))
        return 1
    finally:
        if staging:
            shutil.rmtree(staging, ignore_errors=True)
        # End of the reply: the client reads until EOF.
        try:
            out.flush()
            sock.shutdown(socket.SHUT_WR)
        except OSError:
            pass


def _site_gid(site):
    import grp
    return grp.getgrnam("caddy" if site.get("kind") == "static" else "site-" + site["id"]).gr_gid


def _queue(site, rel, h, account):
    sid = site["id"]
    run = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime()) + "-" + os.urandom(3).hex()
    req = {"kind": "release", "release": rel, "at": int(time.time()), "run": run,
           "source": {"from": "azure", "by": account, "run": h["run"], "commit": h["commit"], "pipeline": h["pipeline"]}}
    os.makedirs(paths.site_run(sid), mode=0o755, exist_ok=True)
    store.write_json(paths.request_file(sid), req, mode=0o600)
    proc.systemctl("reset-failed", units.deploy_unit(sid), check=False)
    p = proc.systemctl("start", "--no-block", units.deploy_unit(sid), check=False)
    if p.returncode != 0:
        raise Refused("The deploy couldn't start.")
    return run


def _follow(sid, run, send, timeout=3600):
    """Relay the deploy's progress file to the client until it's done; the exit code says how it went."""
    path = paths.run_file(sid, run)
    started = time.time()
    deadline = started + timeout
    pos = 0
    while time.time() < deadline:
        try:
            with open(path, encoding="utf-8") as fh:
                fh.seek(pos)
                for line in fh:
                    if not line.endswith("\n"):
                        break
                    pos += len(line.encode("utf-8"))
                    try:
                        rec = json.loads(line)
                    except ValueError:
                        continue
                    send(**rec)
                    if rec.get("type") == "done":
                        return 0 if rec.get("ok") else 1
        except FileNotFoundError:
            pass
        if time.time() - started > 20 and not os.path.exists(path) and not units.is_active(units.deploy_unit(sid)):
            send(type="done", ok=False, message="The deploy didn't start.")
            return 1
        time.sleep(0.5)
    send(type="done", ok=False, message="The deploy took too long to report back.")
    return 1
