"""Where Quasar Sites keeps things.

Tests point QUASAR_SITES_ROOT at a temporary folder. The override is ignored when running as root,
so nobody can redirect a root helper to another tree.

The constants prefixed with SYS_ are the real system paths that go into generated config (Caddy
and the units run on the real system, never under a test root).
"""
import os


def _is_root():
    geteuid = getattr(os, "geteuid", None)
    return geteuid is not None and geteuid() == 0


IS_ROOT = _is_root()
ROOT = "" if IS_ROOT else os.environ.get("QUASAR_SITES_ROOT", "").rstrip("/")


def p(path):
    """A system path, moved under the test root when one is set."""
    return ROOT + path if ROOT else path


# ---- real system paths (written into Caddy config / units) --------------------------------------
SYS_CONF = "/etc/quasar/sites"
SYS_CA = SYS_CONF + "/ca"
SYS_SRV = "/srv/sites"
SYS_LOGS = "/var/log/quasar-sites"
SYS_LIB = "/usr/lib/quasar/sites"
SYS_TRUST_ANCHOR = "/usr/local/share/ca-certificates/quasar-sites.crt"

# ---- configuration (root-owned) -----------------------------------------------------------------
CONF = p(SYS_CONF)
DEFS = p(SYS_CONF + "/sites")                 # <id>.json: what the user set up (no secrets)
CADDYFILE = p(SYS_CONF + "/Caddyfile")        # generated, never hand-edited
STATE = p(SYS_CONF + "/state.json")           # on/off, sharing, home network, tunnel
TEST_CONF = p(SYS_CONF + "/test.conf")        # root-owned test overrides (Pebble ACME URL …)
CA = p(SYS_CA)
CREDSTORE = p("/etc/credstore.encrypted")     # systemd-creds: site-<id>.<NAME>
HOSTS = p("/etc/hosts")
DROPINS = p("/etc/systemd/system")
TRUST_ANCHOR = p(SYS_TRUST_ANCHOR)
FIREFOX_POLICIES = (p("/etc/firefox/policies/policies.json"),
                    p("/etc/firefox-esr/policies/policies.json"))

# ---- state ---------------------------------------------------------------------------------------
VAR = p("/var/lib/quasar/sites")              # <id>/state.json (live slot/release), deploys.json
SRV = p(SYS_SRV)                              # <id>/releases/<release>/, <id>/current (static)
STATE_DIRS = p("/var/lib/quasar-site")        # StateDirectory=quasar-site/<id>: the app's HOME
RUN = p("/run/quasar/sites")                  # deploy progress, locks, net.json
LOGS = p(SYS_LOGS)                            # Caddy access logs, <id>.log

# ---- live session ---------------------------------------------------------------------------------
LIVE_MARK = p("/run/live")                    # present on the live USB
ALLOW_LIVE = p("/run/quasar/sites-allow-live")  # root-only test flag (QEMU boot tests)


def site_def(sid):
    return os.path.join(DEFS, sid + ".json")


def site_var(sid):
    return os.path.join(VAR, sid)


def site_state(sid):
    return os.path.join(VAR, sid, "state.json")


def site_deploys(sid):
    return os.path.join(VAR, sid, "deploys.json")


def site_srv(sid):
    return os.path.join(SRV, sid)


def releases(sid):
    return os.path.join(SRV, sid, "releases")


def release(sid, rel):
    return os.path.join(SRV, sid, "releases", rel)


def incoming(sid):
    """Releases a pipeline is still handing over (quasar-sites-release): never pruned."""
    return os.path.join(SRV, sid, "incoming")


def current_link(sid):
    return os.path.join(SRV, sid, "current")


def site_run(sid):
    return os.path.join(RUN, sid)


def runs(sid):
    return os.path.join(RUN, sid, "runs")


def run_file(sid, run):
    return os.path.join(RUN, sid, "runs", run + ".jsonl")


def current_run(sid):
    return os.path.join(RUN, sid, "current-run")


def request_file(sid):
    return os.path.join(RUN, sid, "request.json")


def lock_file(name):
    return os.path.join(RUN, "locks", name + ".lock")


def access_log(sid):
    return os.path.join(LOGS, sid + ".log")


def dropin_dir(sid, slot):
    return os.path.join(DROPINS, "quasar-site-%s@%s.service.d" % (slot, sid))


def cred_file(sid, name):
    return os.path.join(CREDSTORE, "site-%s.%s" % (sid, name))


def state_dir(sid):
    return os.path.join(STATE_DIRS, sid)
