"""The example site: ~/Sites/my-site with one index.html. Sites publishes it the first time it's turned
on, and New site's "Example page" card makes another. Runs as the user (sites-query starter).

Never overwrites anything. A folder that already has an index.html is used as it is (someone may have
edited it), an empty folder is filled in, and a folder with other things in it is passed over, as is
one whose name is already a site's or whose path a site already uses. Then my-site-2, my-site-3, ….
"""
import html
import os

from .events import SitesError

FOLDER = "Sites"
NAME = "my-site"

# Self-contained on purpose: no fonts, scripts or images from anywhere else (nothing on the network).
PAGE = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>@@NAME@@</title>
<style>
  :root {
    color-scheme: light dark;
    --bg: #0b0d14; --card: #141826; --text: #eef1f8; --muted: #9aa3b8;
    --accent: #6fe3ff; --accent-soft: rgba(111, 227, 255, .12); --line: rgba(255, 255, 255, .08);
  }
  @media (prefers-color-scheme: light) {
    :root {
      --bg: #f5f7fb; --card: #ffffff; --text: #141826; --muted: #5b6478;
      --accent: #0a7fb0; --accent-soft: rgba(10, 127, 176, .1); --line: rgba(0, 0, 0, .08);
    }
  }
  * { box-sizing: border-box; }
  body {
    margin: 0; min-height: 100vh; display: grid; place-items: center; padding: 40px 20px;
    background: radial-gradient(1100px 560px at 50% -12%, var(--accent-soft), transparent 62%), var(--bg);
    color: var(--text); font: 16px/1.55 system-ui, -apple-system, "Segoe UI", Inter, Roboto, sans-serif;
  }
  main { width: min(640px, 100%); }
  .badge {
    display: inline-flex; align-items: center; gap: 8px; padding: 6px 12px; border-radius: 999px;
    border: 1px solid var(--line); background: var(--card); color: var(--muted); font-size: 13px;
  }
  .dot { width: 8px; height: 8px; border-radius: 50%; background: #4fd99b; box-shadow: 0 0 0 4px rgba(79, 217, 155, .2); }
  h1 { font-size: clamp(32px, 6vw, 48px); line-height: 1.1; letter-spacing: -.02em; margin: 22px 0 12px; }
  .lead { color: var(--muted); font-size: 18px; margin: 0 0 28px; }
  ol { list-style: none; counter-reset: step; padding: 0; margin: 0; display: grid; gap: 12px; }
  li {
    counter-increment: step; display: grid; grid-template-columns: 36px 1fr; gap: 14px; align-items: start;
    padding: 16px 18px; border-radius: 16px; background: var(--card); border: 1px solid var(--line);
  }
  li::before {
    content: counter(step); display: grid; place-items: center; width: 36px; height: 36px;
    border-radius: 12px; background: var(--accent-soft); color: var(--accent); font-weight: 600;
  }
  li b { display: block; margin-bottom: 2px; }
  li span { color: var(--muted); font-size: 14px; }
  code {
    font: 14px/1.4 ui-monospace, "JetBrains Mono", Menlo, Consolas, monospace; word-break: break-all;
    background: rgba(127, 127, 127, .14); padding: 2px 6px; border-radius: 6px;
  }
  footer { margin-top: 28px; color: var(--muted); font-size: 13px; }
</style>
</head>
<body>
<main>
  <span class="badge"><span class="dot"></span>Live on this PC</span>
  <h1>Your site is up.</h1>
  <p class="lead">Quasar serves this page over HTTPS from <code>@@FILE@@</code>. It&rsquo;s yours to change.</p>
  <ol>
    <li><div><b>Open the project folder</b><span>In Sites, press <em>Folder</em> next to Open, or open <code>@@FOLDER@@</code> in Files.</span></div></li>
    <li><div><b>Edit index.html</b><span>Change this text, or add pages, pictures and styles. Plain HTML, CSS and JavaScript all work.</span></div></li>
    <li><div><b>Press Deploy</b><span>Sites copies the folder and switches over with no downtime. Then refresh this page.</span></div></li>
  </ol>
  <footer>Made with Quasar Sites. Only this PC can open it until you share it.</footer>
</main>
</body>
</html>
"""


def short(path, home):
    """~/… for paths in home (what the page and the app show)."""
    home = home.rstrip("/")
    return "~" + path[len(home):] if home and (path == home or path.startswith(home + "/")) else path


def page(path, home):
    folder = short(path, home)
    return (PAGE.replace("@@NAME@@", html.escape(os.path.basename(path)))
                .replace("@@FILE@@", html.escape(folder + "/index.html"))
                .replace("@@FOLDER@@", html.escape(folder)))


def candidates(home):
    base = os.path.join(home, FOLDER)
    yield os.path.join(base, NAME)
    for n in range(2, 100):
        yield os.path.join(base, "%s-%d" % (NAME, n))


def make(home, sites=()):
    """(folder, created): the example's folder, made if needed."""
    ids = {s.get("id") for s in sites}
    used = {os.path.normpath(p) for p in ((s.get("source") or {}).get("path") for s in sites) if p}
    for path in candidates(home):
        if os.path.basename(path) in ids or os.path.normpath(path) in used:
            continue
        index = os.path.join(path, "index.html")
        if os.path.isfile(index):
            return path, False
        if os.path.lexists(path):
            if not os.path.isdir(path) or os.path.islink(path) or os.listdir(path):
                continue
        try:
            os.makedirs(path, mode=0o755, exist_ok=True)
            fd = os.open(index, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o644)
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(page(path, home))
        except OSError as e:
            raise SitesError("The example site's folder couldn't be made in %s." % short(os.path.dirname(path), home),
                             "io", details=str(e))
        return path, True
    raise SitesError("There are too many example sites already.", "exists")
