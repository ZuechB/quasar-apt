"""JSON-lines output shared by every Sites helper, plus the error type and exit codes.

Each line is one object with a "type": phase, progress, step, line, plan, result, need, secret,
done or error. apps/sites/services/*.qml parse them; anything that isn't JSON is kept as log text.
"""
import json
import sys
import traceback

OK, FAILED, USAGE, NOT_OWNER, BUSY, UNAVAILABLE = 0, 1, 2, 3, 4, 5


class SitesError(Exception):
    """A failure the user should read: one plain sentence, a machine code, optional details."""

    def __init__(self, message, code="failed", exit_code=FAILED, details=""):
        super().__init__(message)
        self.message = message
        self.code = code
        self.exit_code = exit_code
        self.details = details or ""


def emit(kind, **fields):
    rec = {"type": kind}
    rec.update(fields)
    sys.stdout.write(json.dumps(rec, ensure_ascii=False, separators=(",", ":")) + "\n")
    sys.stdout.flush()


def phase(text, **fields):
    emit("phase", text=text, **fields)


def progress(percent):
    emit("progress", percent=max(0, min(100, int(percent))))


def result(**data):
    emit("result", **data)


def error(err):
    emit("error", code=err.code, message=err.message, details=err.details[-6000:])


def usage(text):
    raise SitesError(text, "usage", USAGE)


def run_main(fn, argv):
    """Run a helper's main(argv) and turn every failure into one JSON error line + exit code."""
    try:
        rc = fn(argv)
        return OK if rc is None else rc
    except SitesError as e:
        error(e)
        return e.exit_code
    except KeyboardInterrupt:
        emit("error", code="cancelled", message="Cancelled.", details="")
        return FAILED
    except BrokenPipeError:
        return FAILED
    except Exception as e:  # never die with only a traceback on stderr
        emit("error", code="internal", message="Sites ran into a problem: %s" % e,
             details=traceback.format_exc()[-6000:])
        return FAILED
