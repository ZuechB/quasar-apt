"""Quasar's local certificate authority and where this PC trusts it.

ensure() creates a root and a one-year intermediate with openssl. Both are name-constrained to
localhost, .local and loopback/private/ULA/link-local addresses, so a phone that trusts the root can
never be attacked on a public domain with it. The root key stays 0600 root; Caddy only gets the
intermediate (key 0640 root:caddy, or root:root when Caddy isn't installed). quasar-sites-ca.timer
renews the intermediate.

Who uses the CA is recorded in ca/claims/<name> (only "sites" today). Devices that trust the root lose
that trust with a new one, so the CA is deleted only when nothing claims it.
"""
import os
import tempfile
import time

from . import paths, proc, store

NAME_CONSTRAINTS = ",".join([
    "critical",
    "permitted;DNS:localhost",
    "permitted;DNS:local",
    "permitted;IP:127.0.0.0/255.0.0.0",
    "permitted;IP:10.0.0.0/255.0.0.0",
    "permitted;IP:172.16.0.0/255.240.0.0",
    "permitted;IP:192.168.0.0/255.255.0.0",
    "permitted;IP:169.254.0.0/255.255.0.0",
    "permitted;IP:0:0:0:0:0:0:0:1/FFFF:FFFF:FFFF:FFFF:FFFF:FFFF:FFFF:FFFF",
    "permitted;IP:FD00:0:0:0:0:0:0:0/FF00:0:0:0:0:0:0:0",
    "permitted;IP:FE80:0:0:0:0:0:0:0/FFC0:0:0:0:0:0:0:0",
])
ROOT_DAYS = 3650
INT_DAYS = 365
RENEW_BEFORE_DAYS = 60


def files():
    d = paths.CA
    return {"root_crt": os.path.join(d, "root.crt"), "root_key": os.path.join(d, "root.key"),
            "int_crt": os.path.join(d, "int.crt"), "int_key": os.path.join(d, "int.key")}


def intermediate_ext():
    return "\n".join([
        "basicConstraints=critical,CA:TRUE,pathlen:0",
        "keyUsage=critical,keyCertSign,cRLSign",
        "subjectKeyIdentifier=hash",
        "authorityKeyIdentifier=keyid:always",
        "nameConstraints=" + NAME_CONSTRAINTS,
    ]) + "\n"


def _caddy_gid():
    """Caddy reads the intermediate key; without Caddy it stays root-only."""
    import grp
    try:
        return grp.getgrnam("caddy").gr_gid
    except KeyError:
        return 0


def _host_label():
    try:
        return (os.uname().nodename or "this PC").split(".")[0][:40]
    except AttributeError:
        return "this PC"


def exists():
    f = files()
    return os.path.exists(f["root_crt"]) and os.path.exists(f["int_crt"]) and os.path.exists(f["int_key"])


def days_left(cert):
    import calendar
    p = proc.run(["openssl", "x509", "-noout", "-enddate", "-in", cert], check=False)
    for line in (p.stdout or "").strip().splitlines():
        if line.startswith("notAfter="):
            try:
                end = calendar.timegm(time.strptime(" ".join(line[9:].replace(" GMT", "").split()),
                                                    "%b %d %H:%M:%S %Y"))
                return int((end - time.time()) / 86400)
            except ValueError:
                return 0
    return 0


def create_root():
    f = files()
    os.makedirs(paths.CA, mode=0o755, exist_ok=True)
    old = os.umask(0o077)
    try:
        proc.run(["openssl", "req", "-x509", "-newkey", "ec", "-pkeyopt", "ec_paramgen_curve:P-256",
                  "-nodes", "-keyout", f["root_key"], "-out", f["root_crt"], "-days", str(ROOT_DAYS),
                  "-subj", "/O=Quasar/CN=Quasar Local CA (%s)" % _host_label(),
                  "-addext", "basicConstraints=critical,CA:TRUE,pathlen:1",
                  "-addext", "keyUsage=critical,keyCertSign,cRLSign",
                  "-addext", "nameConstraints=" + NAME_CONSTRAINTS])
    finally:
        os.umask(old)
    os.chmod(f["root_key"], 0o600)
    os.chmod(f["root_crt"], 0o644)


def create_intermediate():
    f = files()
    gid = _caddy_gid()
    with tempfile.TemporaryDirectory(prefix="quasar-ca-") as tmp:
        key = os.path.join(tmp, "int.key")
        csr = os.path.join(tmp, "int.csr")
        crt = os.path.join(tmp, "int.crt")
        ext = os.path.join(tmp, "int.ext")
        with open(ext, "w") as fh:
            fh.write(intermediate_ext())
        proc.run(["openssl", "req", "-new", "-newkey", "ec", "-pkeyopt", "ec_paramgen_curve:P-256",
                  "-nodes", "-keyout", key, "-out", csr, "-subj", "/O=Quasar/CN=Quasar Local Intermediate"])
        serial = "0x" + os.urandom(16).hex()
        proc.run(["openssl", "x509", "-req", "-in", csr, "-CA", f["root_crt"], "-CAkey", f["root_key"],
                  "-set_serial", serial, "-days", str(INT_DAYS), "-sha256", "-extfile", ext, "-out", crt])
        with open(key, "rb") as fh:
            key_bytes = fh.read()
        with open(crt, "rb") as fh:
            crt_bytes = fh.read()
    _write_bytes(f["int_key"], key_bytes, 0o640, gid)
    _write_bytes(f["int_crt"], crt_bytes, 0o644, 0)


def _write_bytes(path, data, mode, gid):
    fd, tmp = tempfile.mkstemp(prefix=".tmp-", dir=os.path.dirname(path))
    with os.fdopen(fd, "wb") as fh:
        fh.write(data)
    os.chmod(tmp, mode)
    if paths.IS_ROOT:                      # tests run unprivileged under QUASAR_SITES_ROOT
        os.chown(tmp, 0, gid)
    os.replace(tmp, path)


def ensure():
    """Create the CA when missing and renew the intermediate when it gets close to expiry.
    Returns True when the intermediate changed (Caddy then needs a restart)."""
    f = files()
    if not os.path.exists(f["root_crt"]) or not os.path.exists(f["root_key"]):
        create_root()
        create_intermediate()
        return True
    if not os.path.exists(f["int_crt"]) or days_left(f["int_crt"]) < RENEW_BEFORE_DAYS:
        create_intermediate()
        return True
    return False


# ---- who uses it ------------------------------------------------------------------------------------
CLAIM_RE = ("sites",)


def _claims_dir():
    return os.path.join(paths.CA, "claims")


def claim(name):
    if name not in CLAIM_RE:
        raise ValueError(name)
    os.makedirs(_claims_dir(), mode=0o755, exist_ok=True)
    with open(os.path.join(_claims_dir(), name), "w") as fh:
        fh.write("")


def release(name):
    try:
        os.unlink(os.path.join(_claims_dir(), name))
    except FileNotFoundError:
        pass


def claims():
    try:
        return sorted(n for n in os.listdir(_claims_dir()) if n in CLAIM_RE)
    except OSError:
        return []


def claimed_by_others(name):
    """Claims other than `name`. A CA made before claims existed belongs to Sites."""
    return [c for c in claims() if c != name]


def fingerprint(algo="sha256"):
    p = proc.run(["openssl", "x509", "-noout", "-fingerprint", "-" + algo, "-in", files()["root_crt"]],
                 check=False)
    out = (p.stdout or "").strip()
    return out.split("=", 1)[1] if "=" in out else ""


def short_code(fp):
    hexs = fp.replace(":", "")
    return (hexs[:4] + "-" + hexs[4:8]).upper() if len(hexs) >= 8 else ""


# ---- trust on this PC ------------------------------------------------------------------------------
def install_trust():
    f = files()
    os.makedirs(os.path.dirname(paths.TRUST_ANCHOR), exist_ok=True)
    with open(f["root_crt"], "rb") as fh:
        data = fh.read()
    _write_bytes(paths.TRUST_ANCHOR, data, 0o644, 0)
    proc.run(["update-ca-certificates"], check=False, timeout=120)
    for policy in paths.FIREFOX_POLICIES:
        _firefox_policy(policy, add=True)


def remove_trust():
    try:
        os.unlink(paths.TRUST_ANCHOR)
    except FileNotFoundError:
        pass
    proc.run(["update-ca-certificates", "--fresh"], check=False, timeout=180)
    for policy in paths.FIREFOX_POLICIES:
        _firefox_policy(policy, add=False)


def _firefox_policy(path, add):
    """Merge our root into Firefox's enterprise policy (Certificates.Install), keeping anything
    else that's already there."""
    data = store.read_json(path, None)
    if data is None:
        if not add:
            return
        data = {}
    if not isinstance(data, dict):
        return
    pol = data.setdefault("policies", {})
    certs = pol.setdefault("Certificates", {})
    inst = [x for x in certs.get("Install", []) if x != paths.SYS_TRUST_ANCHOR]
    if add:
        inst.append(paths.SYS_TRUST_ANCHOR)
    if inst:
        certs["Install"] = inst
    else:
        certs.pop("Install", None)
        if not certs:
            pol.pop("Certificates", None)
    store.write_json(path, data)


def root_pem():
    with open(files()["root_crt"], encoding="ascii") as fh:
        return fh.read()
