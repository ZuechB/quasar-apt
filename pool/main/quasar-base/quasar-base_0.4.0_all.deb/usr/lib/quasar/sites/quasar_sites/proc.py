"""Running programs: as root, as another account (setpriv, no PAM), and streaming their output."""
import os
import subprocess

from .events import SitesError

SAFE_PATH = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"


def base_env(extra=None):
    env = {"PATH": SAFE_PATH, "LC_ALL": "C.UTF-8", "LANG": "C.UTF-8"}
    if extra:
        env.update(extra)
    return env


def run(cmd, input=None, timeout=120, check=True, env=None, cwd=None):
    try:
        p = subprocess.run(cmd, input=input, capture_output=True, text=True, timeout=timeout,
                           env=env or base_env(), cwd=cwd)
    except FileNotFoundError:
        if check:
            raise SitesError("%s isn't installed." % os.path.basename(cmd[0]), "missing-tool")
        return subprocess.CompletedProcess(cmd, 127, "", "not installed")
    except subprocess.TimeoutExpired:
        raise SitesError("%s took too long." % os.path.basename(cmd[0]), "timeout")
    if check and p.returncode != 0:
        raise SitesError("%s didn't work." % os.path.basename(cmd[0]), "command-failed",
                         details=((p.stderr or "") + (p.stdout or ""))[-6000:])
    return p


def account(uid):
    """(name, home, gid) of an account."""
    import pwd
    try:
        pw = pwd.getpwuid(uid)
    except KeyError:
        raise SitesError("The account that owns this site no longer exists.", "no-owner")
    return pw.pw_name, pw.pw_dir, pw.pw_gid


def as_user(uid, cmd):
    """Prefix a command so it runs as that account with its own groups (no PAM session)."""
    _, _, gid = account(uid)
    return ["setpriv", "--reuid=%d" % uid, "--regid=%d" % gid, "--init-groups", "--"] + list(cmd)


def user_env(uid, extra=None):
    name, home, _ = account(uid)
    env = base_env({"HOME": home, "USER": name, "LOGNAME": name})
    if extra:
        env.update(extra)
    return env


def stream(cmd, on_line, env=None, cwd=None, stdin=subprocess.DEVNULL, timeout=None):
    """Run cmd, calling on_line(text) for each line of stdout+stderr. Returns the exit code."""
    try:
        p = subprocess.Popen(cmd, stdin=stdin, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                             env=env or base_env(), cwd=cwd, text=True, errors="replace", bufsize=1)
    except FileNotFoundError:
        on_line("%s isn't installed." % os.path.basename(cmd[0]))
        return 127
    try:
        for raw in p.stdout:
            on_line(raw.rstrip("\n"))
        return p.wait(timeout=timeout)
    except BaseException:
        p.kill()
        p.wait()
        raise


def systemctl(*args, check=True, timeout=120):
    return run(["systemctl"] + list(args), check=check, timeout=timeout)


def have(tool):
    for d in SAFE_PATH.split(":"):
        if os.access(os.path.join(d, tool), os.X_OK):
            return True
    return False
