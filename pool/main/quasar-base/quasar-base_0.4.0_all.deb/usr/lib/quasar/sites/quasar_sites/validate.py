"""Input checks. Everything that reaches a root helper, a generated config file or a unit passes
through here first; anything unexpected is refused, never "cleaned up"."""
import ipaddress
import os
import re

from .events import SitesError, USAGE

# site-<id> must fit useradd's 32 characters.
ID_RE = re.compile(r"^[a-z][a-z0-9-]{0,24}[a-z0-9]$")
_LABEL = r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?"
LOCAL_RE = re.compile(r"^(?:%s\.)+localhost$" % _LABEL)
LAN_RE = re.compile(r"^%s\.local$" % _LABEL)             # single label: multi-label .local is unreliable
DOMAIN_RE = re.compile(r"^(?:%s\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$" % _LABEL)
ENV_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]{0,127}$")
HEALTH_RE = re.compile(r"^/[A-Za-z0-9._~/-]{0,200}$")
RELEASE_RE = re.compile(r"^\d{8}T\d{6}Z-[0-9a-f]{7}$")
OUTPUT_RE = re.compile(r"^[A-Za-z0-9._@+-]+(?:/[A-Za-z0-9._@+-]+)*$")
TOOL_SPEC_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._+-]{0,31}$")
KINDS = ("static", "node", "dotnet", "custom")
NOT_PUBLIC = (".localhost", ".local", ".internal", ".lan", ".home", ".home.arpa", ".corp", ".test",
              ".example", ".invalid", ".onion", ".alt")


def _bad(text):
    raise SitesError(text, "invalid", USAGE)


def arg(value, what="argument"):
    """A command-line argument: non-empty, no whitespace or NUL (pkexec joins argv with spaces)."""
    if not isinstance(value, str) or not value or len(value) > 512 or "\x00" in value \
            or any(c.isspace() for c in value):
        _bad("That %s isn't valid." % what)
    return value


def site_id(value):
    if not isinstance(value, str) or not ID_RE.match(value):
        _bad("Site names use 2–26 lowercase letters, digits and dashes, starting with a letter.")
    return value


def local_host(value):
    v = (value or "").strip().lower().rstrip(".")
    if len(v) > 253 or not LOCAL_RE.match(v):
        _bad("The address must end in .localhost, like shop.localhost.")
    return v


def lan_name(value):
    v = (value or "").strip().lower().rstrip(".")
    if len(v) > 69 or not LAN_RE.match(v):
        _bad("Home-network names look like shop.local (one word before .local).")
    return v


def public_domain(value):
    v = (value or "").strip().lower()
    for prefix in ("https://", "http://"):
        if v.startswith(prefix):
            v = v[len(prefix):]
    v = v.split("/", 1)[0].rstrip(".")
    try:
        ipaddress.ip_address(v)
        _bad("Use a domain name like app.example.com, not an IP address.")
    except ValueError:
        pass
    if len(v) > 253 or not DOMAIN_RE.match(v) or any(v.endswith(s) or v == s[1:] for s in NOT_PUBLIC):
        _bad("Enter a domain like app.example.com (without https://).")
    return v


def env_name(value):
    if not isinstance(value, str) or not ENV_RE.match(value):
        _bad("Use letters, numbers and underscores; names can't start with a number.")
    return value


def env_value(value):
    if not isinstance(value, str) or "\x00" in value or len(value) > 32768:
        _bad("That value can't be stored.")
    return value


def health(value):
    v = (value or "/").strip() or "/"
    if not HEALTH_RE.match(v):
        _bad("The health check must be a path like / or /healthz.")
    return v


def command(value, what="command", required=False):
    v = (value or "").strip()
    if required and not v:
        _bad("Enter a %s." % what)
    if len(v) > 2000 or any(c in v for c in "\x00\r\n"):
        _bad("The %s must be a single line." % what)
    return v


def output_dir(value):
    v = (value or ".").strip().strip("/") or "."
    if v == ".":
        return v
    if not OUTPUT_RE.match(v) or any(part in ("..", ".") for part in v.split("/")):
        _bad("The output folder must be a folder inside the project, like dist.")
    return v


def project_path(value):
    if not isinstance(value, str) or not value.startswith("/") or len(value) > 4096 \
            or any(c in value for c in "\x00\r\n"):
        _bad("Pick a project folder.")
    return os.path.normpath(value)


def git_url(value):
    v = (value or "").strip()
    if len(v) > 1024 or any(c.isspace() for c in v) or v.startswith("-") or not (
            re.match(r"^(https://|ssh://|git@)[A-Za-z0-9._~:/?#\[\]@!$&'()*+,;=%-]+$", v)):
        _bad("Enter a Git URL that starts with https://, ssh:// or git@.")
    return v


def git_ref(value):
    v = (value or "").strip()
    if not re.match(r"^[0-9a-f]{7,40}$", v):
        _bad("That isn't a commit.")
    return v


def branch(value):
    v = (value or "main").strip()
    if not re.match(r"^[A-Za-z0-9._/-]{1,100}$", v) or ".." in v or v.startswith(("-", "/")):
        _bad("That isn't a branch name.")
    return v


def release(value):
    if not isinstance(value, str) or not RELEASE_RE.match(value):
        _bad("That isn't one of this site's releases.")
    return value


def tool_spec(value):
    v = (value or "").strip()
    if v and not TOOL_SPEC_RE.match(v):
        _bad("That isn't a version.")
    return v


def slug(name):
    """A site id suggestion from a folder name ("AuthScape.Server" -> "authscape-server")."""
    s = re.sub(r"[^a-z0-9]+", "-", (name or "").lower()).strip("-")
    s = re.sub(r"-{2,}", "-", s)
    if not s or not s[0].isalpha():
        s = "site-" + s if s else "site"
    s = s[:26].rstrip("-")
    if len(s) < 2:
        s = (s + "-site")[:26]
    return s
