"""Reading and writing Sites' files: atomic JSON writes, locks, site definitions and runtime state.

Layout (see paths.py):
  /etc/quasar/sites/sites/<id>.json      the definition: what the user set up, env values included
                                         (0640 root:<owner's group>: the owner and root read it; the
                                         site's own service gets a copy through LoadCredential=)
  /etc/quasar/sites/state.json           global: on/off, home network, tunnel, CA flags
  /var/lib/quasar/sites/<id>/state.json  runtime: active slot, the release each slot runs
  /var/lib/quasar/sites/<id>/deploys.json  history, newest first (0640 root:<owner's group>: a failed
                                         deploy keeps the app's last log lines, which can carry tokens)
"""
import contextlib
import json
import os
import tempfile

from . import paths
from .events import SitesError, BUSY, NOT_OWNER


def read_json(path, default=None):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return default
    except (OSError, ValueError):
        return default


def _atomic(path, write, mode, uid, gid):
    folder = os.path.dirname(path)
    os.makedirs(folder, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=".tmp-", dir=folder)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            write(f)
            f.flush()
            os.fsync(f.fileno())
        os.chmod(tmp, mode)
        if (uid is not None or gid is not None) and hasattr(os, "chown"):
            os.chown(tmp, -1 if uid is None else uid, -1 if gid is None else gid)
        os.replace(tmp, path)
    except BaseException:
        with contextlib.suppress(OSError):
            os.unlink(tmp)
        raise


def write_json(path, data, mode=0o644, uid=None, gid=None):
    def w(f):
        json.dump(data, f, indent=1, ensure_ascii=False)
        f.write("\n")
    _atomic(path, w, mode, uid, gid)


def write_text(path, text, mode=0o644, uid=None, gid=None):
    _atomic(path, lambda f: f.write(text), mode, uid, gid)


@contextlib.contextmanager
def lock(name, wait=True):
    """An exclusive flock. "global" guards the Caddyfile, /etc/hosts and port allocation;
    "site-<id>" guards one site. wait=False raises "busy" instead of waiting."""
    try:
        import fcntl
    except ImportError:          # Windows (unit tests): no locking needed
        yield
        return
    path = paths.lock_file(name)
    os.makedirs(os.path.dirname(path), mode=0o755, exist_ok=True)
    fd = os.open(path, os.O_CREAT | os.O_RDWR, 0o600)
    try:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | (0 if wait else fcntl.LOCK_NB))
        except BlockingIOError:
            raise SitesError("Another change to this site is still running. Try again in a moment.",
                             "busy", BUSY)
        yield
    finally:
        os.close(fd)


# ---- global state -------------------------------------------------------------------------------
def global_state():
    return read_json(paths.STATE, {}) or {}


def save_global_state(state):
    write_json(paths.STATE, state)


def test_conf():
    """Root-owned overrides for boot tests (e.g. {"acme_ca": "https://10.0.2.2:14000/dir"}).
    Only honoured when the file is owned by root, so a user can't plant one."""
    try:
        st = os.stat(paths.TEST_CONF)
    except OSError:
        return {}
    if paths.IS_ROOT and (st.st_uid != 0 or st.st_mode & 0o022):
        return {}
    return read_json(paths.TEST_CONF, {}) or {}


# ---- sites -----------------------------------------------------------------------------------------
def list_ids():
    try:
        names = os.listdir(paths.DEFS)
    except FileNotFoundError:
        return []
    return sorted(n[:-5] for n in names if n.endswith(".json") and not n.startswith("."))


def load_site(sid):
    data = read_json(paths.site_def(sid))
    if not data:
        raise SitesError("There's no site called %s." % sid, "not-found")
    return data


def list_sites():
    out = []
    for sid in list_ids():
        data = read_json(paths.site_def(sid))
        if data:
            out.append(data)
    return out


def owner_gid(site):
    """The owner's own group (Debian gives every account one): files only the owner and root may read.
    None when not running as root (tests) or the account is gone (then root's group: root only)."""
    if not paths.IS_ROOT:
        return None
    try:
        import pwd
        return pwd.getpwuid(int(site.get("owner"))).pw_gid
    except (KeyError, TypeError, ValueError):
        return 0


def save_site(site):
    write_json(paths.site_def(site["id"]), site, mode=0o640, gid=owner_gid(site))


def private_perms(site):
    """Files written before definitions and deploy histories became private: make them so."""
    gid = owner_gid(site)
    if gid is None:
        return
    for path in (paths.site_def(site["id"]), paths.site_deploys(site["id"])):
        try:
            os.chown(path, 0, gid)
            os.chmod(path, 0o640)
        except FileNotFoundError:
            pass


def site_state(sid):
    st = read_json(paths.site_state(sid), {}) or {}
    st.setdefault("slots", {})
    return st


def save_site_state(sid, state):
    write_json(paths.site_state(sid), state)


def deploys(sid):
    return read_json(paths.site_deploys(sid), []) or []


def save_deploys(sid, items):
    site = read_json(paths.site_def(sid), {}) or {}
    write_json(paths.site_deploys(sid), items[:50], mode=0o640, gid=owner_gid(site) if site else (0 if paths.IS_ROOT else None))


def caller_uid():
    """The account that ran pkexec, or None when called directly as root (units, installer)."""
    raw = os.environ.get("PKEXEC_UID")
    if raw is None:
        return None
    try:
        return int(raw)
    except ValueError:
        raise SitesError("Unknown caller.", "usage")


def check_owner(site, uid):
    if uid is not None and site.get("owner") != uid:
        raise SitesError("This site belongs to another account on this PC.", "not-owner", NOT_OWNER)
