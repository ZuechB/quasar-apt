"""systemd: unit names, per-slot drop-ins and batched status.

App sites run as quasar-site-a@<id> / quasar-site-b@<id> (two slots, so a new version starts next to
the old one). Slots are never enabled; quasar-sites-boot.service starts the active slot of every site
set to start with the PC. Static sites have no service.
"""
import os
import re
import shutil

from . import paths, proc, store

SLOTS = ("a", "b")
PROXY = "quasar-sites-proxy.service"
BOOT = "quasar-sites-boot.service"
CA_TIMER = "quasar-sites-ca.timer"
PORT_FIRST, PORT_LAST = 41000, 41998          # even P for slot a, P+1 for slot b


def slot_unit(sid, slot):
    return "quasar-site-%s@%s.service" % (slot, sid)


def deploy_unit(sid):
    return "quasar-site-deploy@%s.service" % sid


def build_unit(sid):
    return "quasar-site-build-%s" % sid


def other(slot):
    return "b" if slot == "a" else "a"


def port_of(site, slot):
    return int(site["port"]) + (1 if slot == "b" else 0)


def render_dropin(site, slot):
    opts = site.get("options") or {}
    lines = ["# Written by Quasar Sites for %s (slot %s). Rewritten on every change." % (site["id"], slot),
             "[Service]",
             "Restart=%s" % ("on-failure" if opts.get("crashRestart", True) else "no"),
             # Only this slot's port may be bound, so nothing else can take over a stopped site's
             # address (and its visitors' cookies).
             "SocketBindAllow=tcp:%d" % port_of(site, slot),
             "SocketBindDeny=any"]
    mem = str(opts.get("memoryMax") or "").strip()
    if re.match(r"^[1-9][0-9]{0,5}[KMG]\Z", mem):
        lines.append("MemoryMax=%s" % mem)
    if opts.get("lan"):                 # may reach the home network (the unit blocks private ranges)
        lines.append("IPAddressDeny=")
    cpu = opts.get("cpuWeight")
    if isinstance(cpu, int) and 1 <= cpu <= 10000:
        lines.append("CPUWeight=%d" % cpu)
    return "\n".join(lines) + "\n"


def write_dropins(site):
    for slot in SLOTS:
        d = paths.dropin_dir(site["id"], slot)
        os.makedirs(d, mode=0o755, exist_ok=True)
        store.write_text(os.path.join(d, "50-quasar-sites.conf"), render_dropin(site, slot))


def remove_dropins(sid):
    for slot in SLOTS:
        shutil.rmtree(paths.dropin_dir(sid, slot), ignore_errors=True)


def daemon_reload():
    proc.systemctl("daemon-reload", check=False)


def start(unit):
    proc.systemctl("reset-failed", unit, check=False)
    return proc.systemctl("start", unit, check=False, timeout=180)


def stop(unit):
    return proc.systemctl("stop", unit, check=False, timeout=120)


def is_active(unit):
    return proc.systemctl("is-active", "--quiet", unit, check=False).returncode == 0


def is_failed(unit):
    return proc.systemctl("is-failed", "--quiet", unit, check=False).returncode == 0


PROPS = ("Id", "ActiveState", "SubState", "Result", "MemoryCurrent", "ActiveEnterTimestamp",
         "NRestarts", "LoadState")


def parse_show(text):
    """`systemctl show` output (blocks separated by blank lines) -> {unit id: {prop: value}}."""
    out, cur = {}, {}
    for line in text.splitlines() + [""]:
        if not line.strip():
            if cur.get("Id"):
                out[cur["Id"]] = cur
            cur = {}
            continue
        k, _, v = line.partition("=")
        cur[k] = v
    return out


def show(units, props=PROPS):
    if not units:
        return {}
    p = proc.run(["systemctl", "show", "--timestamp=unix", "-p", ",".join(props), "--"] + list(units),
                 check=False, timeout=30)
    return parse_show(p.stdout or "")


def journal_tail(units, lines=30):
    cmd = ["journalctl", "--no-pager", "-o", "cat", "-n", str(lines)]
    for u in units:
        cmd += ["-u", u]
    return (proc.run(cmd, check=False, timeout=20).stdout or "").strip()
