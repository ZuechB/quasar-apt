"""Applying changes to the front door: regenerate the Caddyfile, validate it as the caddy user,
swap it in atomically, update /etc/hosts and reload (or restart, when the listen addresses change).
The last good config always stays in place when Caddy rejects a new one."""
import os

from . import caddy, hosts, paths, proc, store, units
from .events import SitesError


def sites_with_state():
    return [(s, store.site_state(s["id"])) for s in store.list_sites()]


def validate_text(text):
    """Run `caddy validate` as the caddy user on text. Raises SitesError with Caddy's message."""
    import grp
    import pwd
    try:
        pw = pwd.getpwnam("caddy")
        gid = grp.getgrnam("caddy").gr_gid
    except KeyError:
        raise SitesError("The web server (Caddy) isn't installed on this PC.", "no-caddy")
    tmp = paths.CADDYFILE + ".new"
    store.write_text(tmp, text, mode=0o640, uid=0, gid=gid)
    p = proc.run(["setpriv", "--reuid=%d" % pw.pw_uid, "--regid=%d" % gid, "--init-groups", "--",
                  "caddy", "validate", "--adapter", "caddyfile", "--config", tmp],
                 check=False, timeout=60, env=proc.base_env({"HOME": pw.pw_dir or "/var/lib/caddy"}))
    if p.returncode != 0:
        os.unlink(tmp)
        raise SitesError("The web server didn't accept the new settings, so nothing changed.",
                         "caddy-invalid", details=(p.stderr or p.stdout or "")[-6000:])
    return tmp


def apply(force_restart=False):
    """Regenerate and apply. Returns the rendered text."""
    with store.lock("global"):
        g = store.global_state()
        sites = sites_with_state()
        tc = store.test_conf()
        text = caddy.render(g, sites, acme_ca=tc.get("acme_ca"), root_key=bool(g.get("caRootKey")))
        everywhere = caddy.binds_everywhere(sites, g)
        try:
            with open(paths.CADDYFILE, encoding="utf-8") as f:
                unchanged = f.read() == text
        except FileNotFoundError:
            unchanged = False
        if not unchanged:
            tmp = validate_text(text)
            os.replace(tmp, paths.CADDYFILE)
        hosts.update(caddy.host_names(sites, g))
        bind_changed = bool(g.get("bindEverywhere")) != everywhere
        if bind_changed:
            g["bindEverywhere"] = everywhere
            store.save_global_state(g)
        if g.get("active") and (not unchanged or force_restart or bind_changed):
            # A bind change must restart: a reload would try to open :443 while the old loopback
            # listener still holds 127.0.0.1:443.
            verb = "restart" if (force_restart or bind_changed) else "reload-or-restart"
            p = proc.systemctl(verb, units.PROXY, check=False, timeout=90)
            if p.returncode != 0:
                raise SitesError("The web server didn't restart.", "proxy-failed",
                                 details=units.journal_tail([units.PROXY], 40))
        return text
