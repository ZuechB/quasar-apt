"""/usr/libexec/quasar/quasar-sites: routine changes to your own sites.

Polkit action org.quasar.sites: administrators at the PC aren't asked for a password
(50-quasar-sites.rules); everything here only touches sites the caller owns. Big changes (turning
Sites on/off, sharing, removing) live in quasar-sites-admin, which asks every time.

  create                         spec on stdin (one JSON line)       -> result{site}
  update ID                      fields on stdin                     -> result{site}
  deploy ID [--ref SHA]          starts quasar-site-deploy@ID        -> result{run}
  rollback ID RELEASE                                                -> result{run}
  cancel ID
  start|stop|restart ID
  env-set ID NAME [--secret]     value on stdin (never in argv: pkexec logs argv)
  env-unset ID NAME
  set-option ID boot|crashRestart|stopFirst|strictHealth|lan on|off   (lan: may reach the home network)
  set-option ID memoryMax|cpuWeight|drain VALUE     (VALUE "-" clears it; applies on the next restart)
  (secret-reveal is quasar-sites-admin's: reading a secret back asks for the password every time)
  set-option ID boot|crashRestart|stopFirst on|off
  clean ID                       delete old releases
"""
import json
import os
import re
import sys
import time

from . import caddy, creds, events, paths, proc, proxy, release, store, units, validate
from .events import SitesError, result

PUBLIC_FIELDS = ("id", "name", "kind", "label", "framework", "tool", "source", "build", "run", "output",
                 "health", "port", "hostname", "lan", "public", "options", "env", "secrets", "owner", "created")


def _view(site):
    return {k: site.get(k) for k in PUBLIC_FIELDS}


def _stdin_json():
    line = sys.stdin.readline()
    if not line.strip():
        return {}
    try:
        data = json.loads(line)
    except ValueError:
        raise SitesError("Bad request.", "usage", events.USAGE)
    if not isinstance(data, dict):
        raise SitesError("Bad request.", "usage", events.USAGE)
    return data


def _stdin_value():
    value = sys.stdin.read()
    return value[:-1] if value.endswith("\n") else value


def _need_active():
    if not store.global_state().get("active"):
        raise SitesError("Sites is turned off. Turn it on first.", "off", events.UNAVAILABLE)


def _owned(sid, uid):
    site = store.load_site(validate.site_id(sid))
    store.check_owner(site, uid)
    return site


def _listening_ports():
    p = proc.run(["ss", "-Hltn"], check=False, timeout=10)
    ports = set()
    for line in (p.stdout or "").splitlines():
        cols = line.split()
        if len(cols) >= 4:
            m = re.search(r":(\d+)$", cols[3])
            if m:
                ports.add(int(m.group(1)))
    return ports


def allocate_port():
    used = set()
    for s in store.list_sites():
        if s.get("port"):
            used |= {int(s["port"]), int(s["port"]) + 1}
    busy = _listening_ports()
    for port in range(units.PORT_FIRST, units.PORT_LAST, 2):
        if port not in used and port + 1 not in used and port not in busy and port + 1 not in busy:
            return port
    raise SitesError("There are no free ports left for another site.", "no-ports")


def _source(spec):
    src = spec.get("source") or {}
    if src.get("type") == "folder":
        return {"type": "folder", "path": validate.project_path(src.get("path"))}
    if src.get("type") == "git":
        return {"type": "git", "url": validate.git_url(src.get("url")), "branch": validate.branch(src.get("branch"))}
    raise SitesError("Pick a project folder.", "invalid", events.USAGE)


def _output(value, kind):
    v = (value or ("out" if kind == "dotnet" else "src")).strip().strip("/")
    base, _, sub = v.partition("/")
    if base not in ("src", "out"):
        raise SitesError("That output folder isn't valid.", "invalid", events.USAGE)
    return base + ("/" + validate.output_dir(sub) if sub and sub != "." else "")


def _tool(value):
    if not value:
        return None
    if value.get("name") not in ("node", "dotnet"):
        raise SitesError("Unknown SDK.", "invalid", events.USAGE)
    return {"name": value["name"], "spec": validate.tool_spec(str(value.get("spec") or ""))}


def _ensure_account(sid):
    name = "site-" + sid
    if proc.run(["getent", "passwd", name], check=False).returncode == 0:
        return
    proc.run(["useradd", "--system", "--user-group", "--no-create-home", "--home-dir",
              "/var/lib/quasar-site/" + sid, "--shell", "/usr/sbin/nologin", "--comment",
              "Quasar site " + sid, name])


def _site_group(site):
    import grp
    return grp.getgrnam("caddy" if site["kind"] == "static" else "site-" + site["id"]).gr_gid


def cmd_create(args, uid):
    _need_active()
    spec = _stdin_json()
    sid = validate.site_id(spec.get("id", ""))
    kind = spec.get("kind")
    if kind not in validate.KINDS:
        raise SitesError("Unknown kind of site.", "invalid", events.USAGE)
    hostname = validate.local_host(spec.get("hostname") or sid + ".localhost")
    site = {
        "v": 1, "id": sid, "name": sid, "owner": uid if uid is not None else 0, "kind": kind,
        "label": (spec.get("label") or "")[:60], "framework": (spec.get("framework") or "")[:20],
        "tool": _tool(spec.get("tool")), "source": _source(spec),
        "build": validate.command(spec.get("build"), "build command"),
        "run": validate.command(spec.get("run"), "start command", required=kind != "static"),
        "output": _output(spec.get("output"), kind), "health": validate.health(spec.get("health")),
        "port": 0, "hostname": hostname,
        "lan": {"on": False, "name": sid + ".local"}, "public": {"on": False},
        "options": {"boot": True, "crashRestart": True, "stopFirst": False, "push": False, "watch": False},
        "env": [], "secrets": [], "created": int(time.time()),
    }
    if kind == "dotnet":
        site["env"].append(["ASPNETCORE_ENVIRONMENT", "Production"])
    elif kind == "node":
        site["env"].append(["NODE_ENV", "production"])
    with store.lock("global"):
        if os.path.exists(paths.site_def(sid)):
            raise SitesError("There's already a site called %s." % sid, "exists")
        if any(s.get("hostname") == hostname for s in store.list_sites()):
            raise SitesError("Another site already uses %s." % hostname, "exists")
        if kind != "static":
            site["port"] = allocate_port()
            _ensure_account(sid)
        os.makedirs(paths.site_srv(sid), mode=0o755, exist_ok=True)
        os.makedirs(paths.releases(sid), mode=0o750, exist_ok=True)
        os.chown(paths.releases(sid), 0, _site_group(site))
        os.makedirs(paths.site_var(sid), mode=0o755, exist_ok=True)
        store.save_site(site)
        store.save_site_state(sid, {"slots": {}})
    result(site=_view(site))


def cmd_update(args, uid):
    site = _owned(args[0], uid)
    spec = _stdin_json()
    changed_proxy = False
    if "build" in spec:
        site["build"] = validate.command(spec["build"], "build command")
    if "run" in spec:
        site["run"] = validate.command(spec["run"], "start command", required=site["kind"] != "static")
    if "health" in spec:
        site["health"] = validate.health(spec["health"])
    if "output" in spec:
        site["output"] = _output(spec["output"], site["kind"])
    if "tool" in spec:
        site["tool"] = _tool(spec["tool"])
    if "hostname" in spec:
        host = validate.local_host(spec["hostname"])
        if host != site["hostname"]:
            if any(s.get("hostname") == host for s in store.list_sites()):
                raise SitesError("Another site already uses %s." % host, "exists")
            site["hostname"] = host
            changed_proxy = True
    store.save_site(site)
    if changed_proxy:
        proxy.apply()
    result(site=_view(site))


def _start_deploy(site, request):
    sid = site["id"]
    if units.is_active(units.deploy_unit(sid)):
        raise SitesError("A deploy of %s is already running." % sid, "busy", events.BUSY)
    run = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime()) + "-" + os.urandom(3).hex()
    request.update({"at": int(time.time()), "run": run})
    os.makedirs(paths.site_run(sid), mode=0o755, exist_ok=True)
    store.write_json(paths.request_file(sid), request, mode=0o600)
    proc.systemctl("reset-failed", units.deploy_unit(sid), check=False)
    p = proc.systemctl("start", "--no-block", units.deploy_unit(sid), check=False)
    if p.returncode != 0:
        raise SitesError("The deploy couldn't start.", "start-failed", details=p.stderr)
    result(queued=True, run=run)


def cmd_deploy(args, uid):
    _need_active()
    site = _owned(args[0], uid)
    req = {"kind": "deploy"}
    if len(args) >= 3 and args[1] == "--ref":
        req["ref"] = validate.git_ref(args[2])
    _start_deploy(site, req)


def cmd_rollback(args, uid):
    _need_active()
    site = _owned(args[0], uid)
    rel = validate.release(args[1])
    if not os.path.isdir(paths.release(site["id"], rel)):
        raise SitesError("That release is no longer on this PC.", "not-found")
    _start_deploy(site, {"kind": "rollback", "release": rel})


def cmd_cancel(args, uid):
    site = _owned(args[0], uid)
    proc.systemctl("stop", units.deploy_unit(site["id"]), check=False, timeout=60)
    result(cancelled=True)


def cmd_start(args, uid):
    _need_active()
    site = _owned(args[0], uid)
    sid = site["id"]
    st = store.site_state(sid)
    if not st.get("release"):
        raise SitesError("Deploy %s once before starting it." % sid, "not-deployed")
    st.pop("stopped", None)
    store.save_site_state(sid, st)
    if caddy.is_app(site):
        units.write_dropins(site)
        units.daemon_reload()
        r = units.start(units.slot_unit(sid, st["active"]))
        if r.returncode != 0:
            raise SitesError("%s didn't start." % sid, "start-failed",
                             details=units.journal_tail([units.slot_unit(sid, st["active"])], 40))
    else:
        proxy.apply()
    result(state="live")


def cmd_stop(args, uid):
    site = _owned(args[0], uid)
    sid = site["id"]
    st = store.site_state(sid)
    st["stopped"] = True
    store.save_site_state(sid, st)
    if caddy.is_app(site):
        for slot in units.SLOTS:
            units.stop(units.slot_unit(sid, slot))
    else:
        proxy.apply()
    result(state="stopped")


def cmd_restart(args, uid):
    _need_active()
    site = _owned(args[0], uid)
    sid = site["id"]
    st = store.site_state(sid)
    if not caddy.is_app(site):
        result(state="live")
        return
    if st.get("active") not in units.SLOTS:
        raise SitesError("Deploy %s once before restarting it." % sid, "not-deployed")
    st.pop("stopped", None)
    store.save_site_state(sid, st)
    unit = units.slot_unit(sid, st["active"])
    proc.systemctl("reset-failed", unit, check=False)
    r = proc.systemctl("restart", unit, check=False, timeout=180)
    if r.returncode != 0:
        raise SitesError("%s didn't restart." % sid, "start-failed", details=units.journal_tail([unit], 40))
    result(state="live")


def cmd_env_set(args, uid):
    site = _owned(args[0], uid)
    name = validate.env_name(args[1])
    secret = "--secret" in args[2:]
    value = validate.env_value(_stdin_value())
    sid = site["id"]
    site["env"] = [e for e in site.get("env", []) if e[0] != name]
    if secret:
        creds.put(sid, name, value)
        if name not in site.setdefault("secrets", []):
            site["secrets"].append(name)
    else:
        if name in site.get("secrets", []):
            creds.remove(sid, name)
            site["secrets"].remove(name)
        site["env"].append([name, value])
    store.save_site(site)
    result(site=_view(site))


def cmd_env_unset(args, uid):
    site = _owned(args[0], uid)
    name = validate.env_name(args[1])
    site["env"] = [e for e in site.get("env", []) if e[0] != name]
    if name in site.get("secrets", []):
        site["secrets"].remove(name)
        creds.remove(site["id"], name)
    store.save_site(site)
    result(site=_view(site))


OPTIONS = {"boot", "crashRestart", "stopFirst", "strictHealth", "lan"}
# Valued options: "" clears one. memoryMax: systemd's MemoryMax (512M, 2G); cpuWeight: CPUWeight (1-10000,
# 100 is everyone else's); drain: seconds the old version keeps its connections after a deploy (10-600).
# (\Z, not $: $ also matches before a trailing newline.)
VALUED = {"memoryMax": re.compile(r"^([1-9][0-9]{0,5}[KMG])?\Z"),
          "cpuWeight": re.compile(r"^(10000|[1-9][0-9]{0,3})?\Z"),
          "drain": re.compile(r"^([1-9][0-9]|[1-5][0-9]{2}|600)?\Z")}
DROPIN_OPTIONS = {"crashRestart", "memoryMax", "cpuWeight", "lan"}


def cmd_set_option(args, uid):
    site = _owned(args[0], uid)
    key, value = args[1], args[2] if args[2] != "-" else ""
    if key in ("push", "watch"):
        raise SitesError("That option comes in a later update.", "soon", events.UNAVAILABLE)
    opts = site.setdefault("options", {})
    if key in OPTIONS and value in ("on", "off"):
        opts[key] = value == "on"
    elif key in VALUED and VALUED[key].match(value):
        if value:
            opts[key] = int(value) if key in ("cpuWeight", "drain") else value
        else:
            opts.pop(key, None)
    else:
        raise SitesError("Unknown option or value.", "usage", events.USAGE)
    store.save_site(site)
    if key in DROPIN_OPTIONS and caddy.is_app(site):
        units.write_dropins(site)
        units.daemon_reload()
    result(site=_view(site))


def cmd_clean(args, uid):
    site = _owned(args[0], uid)
    st = store.site_state(site["id"])
    release.prune(site["id"], protect=list(st.get("slots", {}).values()) + [st.get("release")], keep=1)
    result(cleaned=True)


VERBS = {
    "create": (cmd_create, 0), "update": (cmd_update, 1), "deploy": (cmd_deploy, 1),
    "rollback": (cmd_rollback, 2), "cancel": (cmd_cancel, 1), "start": (cmd_start, 1),
    "stop": (cmd_stop, 1), "restart": (cmd_restart, 1), "env-set": (cmd_env_set, 2),
    "env-unset": (cmd_env_unset, 2),
    "set-option": (cmd_set_option, 3), "clean": (cmd_clean, 1),
}


def main(argv):
    def go(argv):
        if not argv or argv[0] not in VERBS:
            events.usage("Usage: quasar-sites " + "|".join(sorted(VERBS)) + " …")
        for a in argv:
            validate.arg(a)
        fn, nargs = VERBS[argv[0]]
        if len(argv) - 1 < nargs:
            events.usage("%s needs %d argument(s)." % (argv[0], nargs))
        return fn(argv[1:], store.caller_uid())
    return events.run_main(go, argv)
