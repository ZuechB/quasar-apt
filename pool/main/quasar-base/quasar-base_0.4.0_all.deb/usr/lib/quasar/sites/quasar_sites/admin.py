"""/usr/libexec/quasar/quasar-sites-admin: the big changes. Polkit action org.quasar.sites.admin
asks for an administrator's password every time (auth_admin, no "keep").

  activate                 create Quasar's CA, trust it on this PC, start the web server
  deactivate [--purge]     stop everything (keeps sites unless --purge)
  remove ID                delete a site: service, address, certificate, releases and saved data
                           (the project folder is never touched)
  trust                    trust Quasar's CA on this PC again
  expose ID lan|public|tunnel|off   share a site (plan on stdin) — arrives with the home-network
                                    and public-hosting updates
  secret-reveal ID NAME    show one of the caller's own site's secrets (setting one is routine;
                           reading one back asks for the password every time)
  deployers ID [SPACE…]    the spaces whose Azure Pipelines deploy agent may hand this site a release
                           ("personal" = the caller's own; a company the caller owns); none = nobody
"""
import glob
import os
import re
import shutil

from . import ca, creds, datasnap, events, hosts, paths, proc, proxy, store, units, validate
from .events import SitesError, phase, result

SITE_UNITS = (units.PROXY, units.BOOT, units.CA_TIMER)


def _live_refused():
    return os.path.exists(paths.LIVE_MARK) and not os.path.exists(paths.ALLOW_LIVE)


def cmd_activate(args):
    if _live_refused():
        raise SitesError("Sites needs Quasar installed on this PC. The live USB forgets everything when it "
                         "restarts, including your sites and their certificates.", "live", events.UNAVAILABLE)
    if not proc.have("caddy"):
        raise SitesError("The web server (Caddy) isn't installed on this PC.", "no-caddy", events.UNAVAILABLE)
    for d, mode in ((paths.CONF, 0o755), (paths.DEFS, 0o755), (paths.VAR, 0o755), (paths.SRV, 0o755),
                    (paths.RUN, 0o755)):
        os.makedirs(d, mode=mode, exist_ok=True)
    phase("Create Quasar's certificate authority", step=1)
    ca.ensure()
    ca.claim("sites")
    phase("Trust it on this PC", step=2)
    ca.install_trust()
    phase("Start the web server", step=3)
    g = store.global_state()
    g["active"] = True
    g["caCode"] = ca.short_code(ca.fingerprint())
    store.save_global_state(g)
    try:
        proxy.apply(force_restart=True)
    except SitesError as e:
        # Older Caddy needs the root key next to the intermediate. Fall back once: the root is still
        # name-constrained to local names.
        if e.code != "caddy-invalid" or "key" not in e.details.lower() or g.get("caRootKey"):
            raise
        import grp
        os.chown(ca.files()["root_key"], 0, grp.getgrnam("caddy").gr_gid)
        os.chmod(ca.files()["root_key"], 0o640)
        g["caRootKey"] = True
        store.save_global_state(g)
        proxy.apply(force_restart=True)
    proc.systemctl("enable", *SITE_UNITS, check=False)
    p = proc.systemctl("start", units.PROXY, check=False, timeout=90)
    if p.returncode != 0:
        raise SitesError("The web server didn't start.", "proxy-failed",
                         details=units.journal_tail([units.PROXY], 40))
    proc.systemctl("start", units.CA_TIMER, check=False)
    phase("Ready", step=4)
    result(active=True, caCode=g["caCode"], fingerprint=ca.fingerprint())


def _stop_all():
    for site in store.list_sites():
        sid = site["id"]
        proc.systemctl("stop", units.deploy_unit(sid), check=False, timeout=60)
        for slot in units.SLOTS:
            units.stop(units.slot_unit(sid, slot))


def cmd_deactivate(args):
    purge = "--purge" in args
    _stop_all()
    # The CA may be shared (ca.claims): while another feature claims it, its renewal timer and files stay.
    shared = ca.claimed_by_others("sites")
    units_off = [u for u in SITE_UNITS if not (shared and u == units.CA_TIMER)]
    proc.systemctl("disable", "--now", *units_off, check=False, timeout=90)
    g = store.global_state()
    g["active"] = False
    store.save_global_state(g)
    if purge:
        for site in store.list_sites():
            _remove(site["id"], apply=False)
        ca.remove_trust()
        if shared:
            ca.release("sites")
        else:
            shutil.rmtree(paths.CA, ignore_errors=True)
        for f in (paths.STATE, paths.CADDYFILE):
            try:
                os.unlink(f)
            except FileNotFoundError:
                pass
    hosts.clear()
    result(active=False, purged=purge)


def _remove(sid, apply=True):
    proc.systemctl("stop", units.deploy_unit(sid), check=False, timeout=60)
    proc.systemctl("stop", units.build_unit(sid) + ".service", check=False)
    for slot in units.SLOTS:
        units.stop(units.slot_unit(sid, slot))
        proc.systemctl("reset-failed", units.slot_unit(sid, slot), check=False)
    units.remove_dropins(sid)
    units.daemon_reload()
    creds.remove_all(sid)
    datasnap.remove(sid)
    for path in (paths.site_srv(sid), paths.site_var(sid), paths.state_dir(sid), paths.site_run(sid),
                 os.path.join(paths.STATE_DIRS, "private", sid)):
        shutil.rmtree(path, ignore_errors=True)
    for f in glob.glob(paths.access_log(sid) + "*"):
        try:
            os.unlink(f)
        except OSError:
            pass
    try:
        os.unlink(paths.site_def(sid))
    except FileNotFoundError:
        pass
    if proc.run(["getent", "passwd", "site-" + sid], check=False).returncode == 0:
        proc.run(["userdel", "site-" + sid], check=False)
    if proc.run(["getent", "group", "site-" + sid], check=False).returncode == 0:
        proc.run(["groupdel", "site-" + sid], check=False)
    if apply:
        proxy.apply()


def cmd_remove(args):
    sid = validate.site_id(args[0])
    store.load_site(sid)
    with store.lock("site-" + sid, wait=False):
        _remove(sid)
    result(removed=sid)


def remove_owner(uid):
    """sitesd remove-owner UID: quasar-users removing an account takes its sites with it."""
    gone = 0
    for site in store.list_sites():
        if site.get("owner") != uid or not site.get("id"):
            continue
        sid = validate.site_id(site["id"])
        with store.lock("site-" + sid, wait=True):
            _remove(sid, apply=False)
        gone += 1
    if gone:
        proxy.apply()
    return 0


def cmd_trust(args):
    if not ca.exists():
        raise SitesError("Turn on Sites first.", "off", events.UNAVAILABLE)
    ca.install_trust()
    result(trusted=True)


def cmd_expose(args):
    raise SitesError("Sharing on the home network and the internet arrives in the next update of Sites.",
                     "soon", events.UNAVAILABLE)


def cmd_secret_reveal(args):
    site = store.load_site(validate.site_id(args[0]))
    store.check_owner(site, store.caller_uid())
    name = validate.env_name(args[1])
    if name not in site.get("secrets", []):
        raise SitesError("That secret doesn't exist.", "not-found")
    events.emit("secret", name=name, value=creds.get(site["id"], name))


def cmd_deployers(args):
    uid = store.caller_uid()
    site = store.load_site(validate.site_id(args[0]))
    store.check_owner(site, uid)
    accounts = []
    for space in args[1:]:
        if space == "personal":
            owner = uid if uid is not None else site.get("owner")
            key = "u%d" % int(owner)
        elif re.match(r"^[a-z][a-z0-9-]{0,21}$", space):
            conf = os.path.join("/etc/quasar/companies", space + ".conf")
            owner = None
            try:
                with open(conf, encoding="utf-8") as fh:
                    owner = next((l.split("=", 1)[1].strip() for l in fh if l.startswith("OWNER_UID=")), None)
            except OSError:
                pass
            if owner is None or (uid is not None and owner != str(uid)):
                raise SitesError("There's no company %s of yours on this PC." % space, "not-found")
            key = space
        else:
            raise SitesError("Unknown space %s." % space, "usage", events.USAGE)
        accounts.append("quasar-dp-" + key)
    site["deployers"] = sorted(set(accounts))
    store.save_site(site)
    result(deployers=site["deployers"])


VERBS = {"activate": (cmd_activate, 0), "deactivate": (cmd_deactivate, 0), "remove": (cmd_remove, 1),
         "trust": (cmd_trust, 0), "expose": (cmd_expose, 2), "secret-reveal": (cmd_secret_reveal, 2),
         "deployers": (cmd_deployers, 1)}


def main(argv):
    def go(argv):
        if not argv or argv[0] not in VERBS:
            events.usage("Usage: quasar-sites-admin " + "|".join(sorted(VERBS)) + " …")
        for a in argv:
            validate.arg(a)
        fn, nargs = VERBS[argv[0]]
        if len(argv) - 1 < nargs:
            events.usage("%s needs %d argument(s)." % (argv[0], nargs))
        return fn(argv[1:])
    return events.run_main(go, argv)


def reset_for_install(target_root=""):
    """Installer backstop (run inside the target chroot): remove every trace of Sites so the
    installed system starts with Sites off and makes its own CA. No systemctl in a chroot."""
    for d in (paths.CONF, paths.VAR, paths.SRV, paths.STATE_DIRS, paths.LOGS, paths.RUN):
        shutil.rmtree(d, ignore_errors=True)
    for f in glob.glob(os.path.join(paths.CREDSTORE, "site-*")):
        try:
            os.unlink(f)
        except OSError:
            pass
    for d in glob.glob(os.path.join(paths.DROPINS, "quasar-site-*@*.service.d")):
        shutil.rmtree(d, ignore_errors=True)
    for f in glob.glob(os.path.join(paths.DROPINS, "*.wants", "quasar-sites-*")):
        try:
            os.unlink(f)
        except OSError:
            pass
    try:
        os.unlink(paths.TRUST_ANCHOR)
    except FileNotFoundError:
        pass
    proc.run(["update-ca-certificates", "--fresh"], check=False, timeout=300)
    for policy in paths.FIREFOX_POLICIES:
        ca._firefox_policy(policy, add=False)
    hosts.clear()
    p = proc.run(["getent", "passwd"], check=False)
    for line in (p.stdout or "").splitlines():
        name = line.split(":", 1)[0]
        if name.startswith("site-"):
            proc.run(["userdel", name], check=False)
            proc.run(["groupdel", name], check=False)
    return 0
