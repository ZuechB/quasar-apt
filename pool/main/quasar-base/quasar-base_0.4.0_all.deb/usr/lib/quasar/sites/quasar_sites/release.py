"""Releases: /srv/sites/<id>/releases/<UTCSTAMP-hash>/, root-owned and read-only to the site.

The owner's build output arrives as a tar stream produced by the owner's own `tar`; root unpacks it
with tarfile's "data" filter, which refuses absolute paths, "..", links that leave the folder,
devices and setuid bits. Root therefore never follows a path the user controls, and a compromised
site can't rewrite its own releases. Files unchanged since the previous release are hard-linked.
"""
import hashlib
import os
import re
import shutil
import stat
import tarfile
import time

from . import paths, store
from .events import SitesError

META = ".quasar/release.json"
KEEP = 5


def new_id(hash7):
    h = (hash7 or "")[:7].lower()
    if not re.match(r"^[0-9a-f]{7}$", h):
        h = os.urandom(4).hex()[:7]
    return time.strftime("%Y%m%dT%H%M%SZ", time.gmtime()) + "-" + h


def extract(fileobj, dest):
    """Unpack a tar stream into dest (created). Raises SitesError on anything unsafe."""
    os.makedirs(dest, mode=0o750, exist_ok=True)
    try:
        with tarfile.open(fileobj=fileobj, mode="r|*") as tf:
            tf.extractall(dest, filter="data")
    except tarfile.FilterError as e:
        raise SitesError("The build output contains a file Sites won't copy: %s" % e, "unsafe-output")
    except (tarfile.TarError, EOFError) as e:
        raise SitesError("The build output couldn't be read.", "bad-output", details=str(e))


def finish_perms(dest, gid):
    """root:<gid>, directories 0750, files 0640 (0750 when executable), symlinks untouched."""
    for dirpath, dirnames, filenames in os.walk(dest):
        _fix(dirpath, gid, is_dir=True)
        for n in filenames:
            _fix(os.path.join(dirpath, n), gid, is_dir=False)
        for n in dirnames:
            full = os.path.join(dirpath, n)
            if os.path.islink(full):
                _fix(full, gid, is_dir=False)


def _fix(path, gid, is_dir):
    st = os.lstat(path)
    if hasattr(os, "chown"):
        os.chown(path, 0, gid, follow_symlinks=False)
    if stat.S_ISLNK(st.st_mode):
        return
    if is_dir:
        os.chmod(path, 0o750)
    else:
        os.chmod(path, 0o750 if st.st_mode & 0o100 else 0o640)


def _digest(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.digest()


def dedupe(dest, prev):
    """Hard-link files that are identical to the previous release (self-contained .NET and
    node_modules then only cost the difference). Returns bytes saved."""
    if not prev or not os.path.isdir(prev):
        return 0
    saved = 0
    for dirpath, _, filenames in os.walk(dest):
        rel_dir = os.path.relpath(dirpath, dest)
        for n in filenames:
            new = os.path.join(dirpath, n)
            old = os.path.normpath(os.path.join(prev, rel_dir, n))
            try:
                sn, so = os.lstat(new), os.lstat(old)
            except OSError:
                continue
            if not (stat.S_ISREG(sn.st_mode) and stat.S_ISREG(so.st_mode)) or sn.st_size != so.st_size \
                    or sn.st_size < 4096 or (sn.st_mode & 0o777) != (so.st_mode & 0o777):
                continue
            if sn.st_ino == so.st_ino or _digest(new) != _digest(old):
                continue
            tmp = new + ".qlink"
            try:
                os.link(old, tmp)
                os.replace(tmp, new)
                saved += sn.st_size
            except OSError:
                try:
                    os.unlink(tmp)
                except OSError:
                    pass
    return saved


def write_meta(dest, meta, gid):
    path = os.path.join(dest, META)
    os.makedirs(os.path.dirname(path), mode=0o750, exist_ok=True)
    store.write_json(path, meta, mode=0o640, uid=0 if hasattr(os, "chown") else None, gid=gid)


def read_meta(sid, rel):
    return store.read_json(os.path.join(paths.release(sid, rel), META), {}) or {}


def list_releases(sid):
    try:
        names = os.listdir(paths.releases(sid))
    except FileNotFoundError:
        return []
    return sorted((n for n in names if re.match(r"^\d{8}T\d{6}Z-[0-9a-f]{7}$", n)), reverse=True)


def prune(sid, protect, keep=KEEP):
    """Delete old releases, never one a slot runs or a deploy is building."""
    rels = list_releases(sid)
    keepers = set(rels[:keep]) | {r for r in protect if r}
    for r in rels:
        if r not in keepers:
            shutil.rmtree(paths.release(sid, r), ignore_errors=True)
    # leftovers of a deploy that died mid-unpack
    try:
        for n in os.listdir(paths.releases(sid)):
            if n.endswith(".partial") and n[:-8] not in protect:
                shutil.rmtree(os.path.join(paths.releases(sid), n), ignore_errors=True)
    except FileNotFoundError:
        pass


def point_current(sid, rel):
    """Swap the static site's `current` symlink atomically."""
    link = paths.current_link(sid)
    tmp = link + ".new"
    try:
        os.unlink(tmp)
    except FileNotFoundError:
        pass
    os.symlink(os.path.join("releases", rel), tmp)
    os.replace(tmp, link)
