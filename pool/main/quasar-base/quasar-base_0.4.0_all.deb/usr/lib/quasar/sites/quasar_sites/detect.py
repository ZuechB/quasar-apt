"""Working out how to build and run a project. Runs as the user, read-only, never executes anything.

A detection result:
  kind       static | node | dotnet | custom
  label      ".NET 10 · ASP.NET Core" style text for the UI ("ASP.NET Core", "Next.js", "Static site"…)
  framework  "net10.0", "22", "lts" …
  tool       {"name": "dotnet"|"node", "spec": "10"|"22"|"lts"} or None
  build      shell command(s) joined with " && " (run in the build sandbox; $OUT is the output folder)
  run        how to start it ($PORT is set; for .NET also ASPNETCORE_URLS)
  output     what becomes the release: "src", "src/<dir>", "out" or "out/<dir>"
  health     "/" unless the code maps a health check
  detect     one sentence for the UI ("Found Shop.csproj and Program.cs")
"""
import json
import os
import re
import time
from xml.etree import ElementTree as ET

from . import validate

SKIP = {".git", "node_modules", "bin", "obj", ".vs", ".vscode", ".idea", "dist", "build", ".next",
        ".nuxt", ".output", "out", "target", "__pycache__", ".venv", "venv", ".cache", "coverage",
        ".svelte-kit", ".angular", "packages", "TestResults"}
SCAN_ROOTS = ("Projects", "projects", "src", "code", "dev", "work", "repos", "git", "Sites",
              "Documents/Projects", "Documents/GitHub", "source/repos")


def _walk(root, depth):
    """(dirpath, filenames) to `depth` levels below root, skipping build output and VCS folders."""
    base = os.path.normpath(root).count(os.sep)
    for dirpath, dirnames, filenames in os.walk(root):
        level = os.path.normpath(dirpath).count(os.sep) - base
        dirnames[:] = [d for d in dirnames if d not in SKIP and not d.startswith(".")] if level < depth else []
        yield dirpath, filenames


def _read(path, limit=262144):
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            return f.read(limit)
    except OSError:
        return ""


# ---- .NET -----------------------------------------------------------------------------------------
def read_csproj(path):
    try:
        tree = ET.parse(path)
    except (ET.ParseError, OSError):
        return None
    root = tree.getroot()
    if root.tag.split("}")[-1] != "Project":
        return None
    sdk = root.get("Sdk") or ""
    if not sdk:
        el = root.find("Sdk") or root.find("{*}Sdk")
        if el is not None:
            sdk = el.get("Name") or ""
    tfm, assembly = "", ""
    for el in root.iter():
        tag = el.tag.split("}")[-1]
        if tag == "TargetFramework" and el.text and not tfm:
            tfm = el.text.strip()
        elif tag == "TargetFrameworks" and el.text and not tfm:
            tfm = el.text.strip().split(";")[0]
        elif tag == "AssemblyName" and el.text and not assembly:
            assembly = el.text.strip()
    stem = os.path.splitext(os.path.basename(path))[0]
    return {"path": path, "sdk": sdk.split("/")[0], "tfm": tfm, "assembly": assembly or stem}


def dotnet_major(tfm):
    m = re.match(r"^net(\d+)\.\d+", tfm or "")
    return int(m.group(1)) if m else None


def _cs_text(folder):
    parts = []
    for dirpath, files in _walk(folder, 2):
        for f in files:
            if f.endswith(".cs"):
                parts.append(_read(os.path.join(dirpath, f), 65536))
        if sum(len(p) for p in parts) > 1_000_000:
            break
    return "\n".join(parts)


def _dotnet_label(code):
    if "AddRazorComponents" in code and ("AddInteractiveServerComponents" in code
                                         or "AddInteractiveWebAssemblyComponents" in code):
        return "Blazor Web App"
    if "AddServerSideBlazor" in code:
        return "Blazor Server"
    if "MapControllers" in code and "AddRazorPages" not in code and "AddControllersWithViews" not in code:
        return "ASP.NET Core Web API"
    return "ASP.NET Core"


def detect_dotnet(root):
    projects = []
    for dirpath, files in _walk(root, 3):
        for f in files:
            if f.endswith(".csproj"):
                info = read_csproj(os.path.join(dirpath, f))
                if info:
                    projects.append(info)
    if not projects:
        return None
    web = [p for p in projects if p["sdk"].lower() == "microsoft.net.sdk.web"]
    wasm = [p for p in projects if p["sdk"].lower() == "microsoft.net.sdk.blazorwebassembly"]
    pick_from = web or wasm
    if not pick_from:
        return None
    name = os.path.basename(root.rstrip("/")).lower()
    pick_from.sort(key=lambda p: (os.path.basename(os.path.dirname(p["path"])).lower() != name,
                                  p["path"].count("/"), p["path"]))
    proj = pick_from[0]
    rel = os.path.relpath(proj["path"], root).replace(os.sep, "/")
    major = dotnet_major(proj["tfm"])
    spec = str(major) if major else ""
    folder = os.path.dirname(proj["path"])
    code = _cs_text(folder)
    m = re.search(r'MapHealthChecks\(\s*"(/[A-Za-z0-9._~/-]*)"', code)
    health = m.group(1) if m else "/"
    q = '"%s"' % rel
    if proj in web:
        return {
            "kind": "dotnet", "label": _dotnet_label(code), "framework": proj["tfm"],
            "tool": {"name": "dotnet", "spec": spec} if spec else None,
            "build": "dotnet restore %s -r linux-x64 && dotnet publish %s -c Release -r linux-x64 "
                     "--self-contained true --no-restore -o \"$OUT\"" % (q, q),
            "run": "./" + proj["assembly"], "output": "out", "health": health,
            "assembly": proj["assembly"], "project": rel,
            "detect": "Found %s and Program.cs" % os.path.basename(proj["path"]),
        }
    return {
        "kind": "static", "label": "Blazor WebAssembly", "framework": proj["tfm"],
        "tool": {"name": "dotnet", "spec": spec} if spec else None,
        "build": "dotnet publish %s -c Release -o \"$OUT\"" % q,
        "run": "", "output": "out/wwwroot", "health": "/", "project": rel,
        "detect": "Found %s (Blazor WebAssembly)" % os.path.basename(proj["path"]),
    }


# ---- Node -------------------------------------------------------------------------------------------
def node_spec(root, pkg):
    for f in (".nvmrc", ".node-version"):
        raw = _read(os.path.join(root, f), 200).strip()
        if raw:
            m = re.search(r"(\d+)", raw)
            if m:
                return m.group(1)
            if raw.lower().startswith("lts"):
                return "lts"
    engines = (pkg.get("engines") or {}).get("node") or ""
    m = re.search(r"(\d+)", str(engines))
    return m.group(1) if m else "lts"


def _angular_out(root):
    try:
        cfg = json.loads(_read(os.path.join(root, "angular.json")))
        for proj in (cfg.get("projects") or {}).values():
            opts = ((proj.get("architect") or {}).get("build") or {}).get("options") or {}
            out = opts.get("outputPath")
            if isinstance(out, dict):
                out = out.get("base")
            if out:
                out = out.strip("./")
                return out + "/browser" if os.path.exists(os.path.join(root, "src", "main.ts")) else out
    except (ValueError, AttributeError):
        pass
    return "dist"


def detect_node(root):
    path = os.path.join(root, "package.json")
    if not os.path.isfile(path):
        return None
    try:
        pkg = json.loads(_read(path))
    except ValueError:
        return {"kind": "custom", "label": "Custom", "framework": "", "tool": None, "build": "",
                "run": "", "output": "src", "health": "/",
                "detect": "package.json couldn't be read. Enter how to start it."}
    deps = {}
    deps.update(pkg.get("devDependencies") or {})
    deps.update(pkg.get("dependencies") or {})
    scripts = pkg.get("scripts") or {}
    spec = node_spec(root, pkg)
    tool = {"name": "node", "spec": spec}
    install = "npm ci" if os.path.exists(os.path.join(root, "package-lock.json")) else "npm install"
    with_build = install + (" && npm run build" if "build" in scripts else "")
    label_v = "Node %s" % spec if spec != "lts" else "Node LTS"

    def server(label, run, why):
        return {"kind": "node", "label": label, "framework": spec, "tool": tool, "build": with_build,
                "run": run, "output": "src", "health": "/", "detect": why}

    def static(label, out, why):
        return {"kind": "static", "label": label, "framework": spec, "tool": tool, "build": with_build,
                "run": "", "output": "src/" + out if out else "src", "health": "/", "detect": why}

    if "next" in deps:
        nconf = "".join(_read(os.path.join(root, f), 65536) for f in
                        ("next.config.js", "next.config.mjs", "next.config.ts"))
        if re.search(r"output\s*:\s*['\"]export['\"]", nconf):
            return static("Next.js (static export)", "out", "Found a Next.js project with output: export")
        return server("Next.js", "next start -H 127.0.0.1 -p $PORT", "Found a Next.js project")
    if "nuxt" in deps:
        return server("Nuxt", "node .output/server/index.mjs", "Found a Nuxt project")
    if "@sveltejs/kit" in deps:
        if "@sveltejs/adapter-node" in deps:
            return server("SvelteKit", "node build", "Found SvelteKit with adapter-node")
        return static("SvelteKit (static)", "build", "Found SvelteKit with a static adapter")
    if "astro" in deps:
        if "@astrojs/node" in deps:
            return server("Astro (server)", "node ./dist/server/entry.mjs", "Found Astro with the Node adapter")
        return static("Astro", "dist", "Found an Astro project")
    start = (scripts.get("start") or "").strip()
    static_tools = (("@angular/cli", "Angular", None), ("react-scripts", "Create React App", "build"),
                    ("gatsby", "Gatsby", "public"), ("@vue/cli-service", "Vue", "dist"),
                    ("vite", "Vite", "dist"), ("parcel", "Parcel", "dist"))
    for dep, label, out in static_tools:
        if dep in deps and "build" in scripts and not re.match(r"^(node|nodemon|tsx|ts-node)\b", start):
            if dep == "@angular/cli":
                out = _angular_out(root)
            return static(label, out, "Found package.json with a %s build" % label)
    if start:
        run = start
        if re.match(r"^(vite|react-scripts|ng serve|webpack serve)", start):
            run = ""
        return server(label_v, run, "Found package.json with a start script")
    for entry in ("server.js", "index.js", "app.js", "main.js", "server.mjs", "index.mjs"):
        if os.path.isfile(os.path.join(root, entry)):
            return server(label_v, "node " + entry, "Found package.json and %s" % entry)
    if "build" in scripts:
        return static("Static site", "dist", "Found package.json with a build script")
    return None


# ---- the rest ---------------------------------------------------------------------------------------
def detect(root):
    root = os.path.normpath(root)
    if not os.path.isdir(root):
        return {"error": "That folder doesn't exist."}
    if not os.access(root, os.R_OK | os.X_OK):
        return {"error": "You can't read that folder."}
    for fn in (detect_dotnet, detect_node):
        found = fn(root)
        if found:
            break
    else:
        found = None
        if os.path.isfile(os.path.join(root, "index.html")):
            found = {"kind": "static", "label": "Static site", "framework": "", "tool": None, "build": "",
                     "run": "", "output": "src", "health": "/", "detect": "Found index.html"}
        else:
            for sub in ("public", "site", "www", "_site", "dist"):
                if os.path.isfile(os.path.join(root, sub, "index.html")):
                    found = {"kind": "static", "label": "Static site", "framework": "", "tool": None,
                             "build": "", "run": "", "output": "src/" + sub, "health": "/",
                             "detect": "Found %s/index.html" % sub}
                    break
    if not found:
        found = {"kind": "custom", "label": "Custom", "framework": "", "tool": None, "build": "", "run": "",
                 "output": "src", "health": "/",
                 "detect": "No project type found. Enter how to start it; it must listen on $PORT."}
    found["path"] = root
    found["id"] = validate.slug(os.path.basename(root) if os.path.basename(root).lower() not in
                                ("src", "app", "web", "server") else
                                os.path.basename(os.path.dirname(root)) + "-" + os.path.basename(root))
    found["git"] = os.path.isdir(os.path.join(root, ".git")) or _in_git(root)
    return found


def _in_git(path):
    cur = path
    for _ in range(6):
        if os.path.isdir(os.path.join(cur, ".git")):
            return True
        parent = os.path.dirname(cur)
        if parent == cur:
            break
        cur = parent
    return False


def _looks_like_project(dirpath, files):
    if "package.json" in files or "index.html" in files:
        return True
    return any(f.endswith(".csproj") for f in files)


def scan(home, exclude=(), budget=1.5, limit=12):
    """Projects under the usual folders in home, newest first."""
    t0 = time.monotonic()
    seen, found = set(), []
    for rel in SCAN_ROOTS:
        base = os.path.join(home, rel)
        if not os.path.isdir(base):
            continue
        for dirpath, files in _walk(base, 3):
            if time.monotonic() - t0 > budget:
                break
            if dirpath == base:
                continue
            if any(dirpath.startswith(s + os.sep) for s in seen):
                continue
            if _looks_like_project(dirpath, files):
                seen.add(dirpath)
                if dirpath in exclude:
                    continue
                try:
                    mtime = os.stat(dirpath).st_mtime
                except OSError:
                    mtime = 0
                found.append((mtime, dirpath))
    found.sort(reverse=True)
    out = []
    for _, path in found[:limit]:
        d = detect(path)
        if "error" not in d:
            out.append(d)
    return out
