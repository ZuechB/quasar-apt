"""Quasar Sites: host websites from this PC.

Caddy is the front door: every site runs as its own sandboxed systemd service on a loopback port
(or is served straight from disk when it's static) and Caddy routes each address to it with
automatic HTTPS. Quasar's own name-constrained CA covers *.localhost / *.local; Let's Encrypt covers
public domains.

Entry points (all run with `python3 -I`):
  /usr/libexec/quasar/quasar-sites        routine changes to your own sites (pkexec, no password
                                          for administrators)
  /usr/libexec/quasar/quasar-sites-admin  big changes: turn Sites on/off, share, remove (pkexec,
                                          password every time)
  /usr/libexec/quasar/sites-query         read-only answers for the app (runs as the user)
  /usr/lib/quasar/sites/sitesd            jobs the systemd units run (deploys, boot, reconcile)
  /usr/lib/quasar/sites/site-run          ExecStart of a site's service

Standard library only. Every helper prints JSON lines ({"type": ...}) for apps/sites.
"""
