"""Quasar AI: the assistant's helper (/usr/libexec/quasar/quasar-ai).

Talks to the model (Ollama on this PC or ollama.com, Claude, ChatGPT), runs the tool loop for the
shell's assistant panel, keeps API keys in the login keyring, and manages Ollama models for Settings.
Python stdlib only, plus python3-jeepney for the keyring. Runs as the user; never as root.
"""
