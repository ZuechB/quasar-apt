"""The tools that run in the helper: files, commands, system info and the Store catalog.

Each returns a Result: text for the model, an optional short line for the panel, and the inverse
calls that undo it ("Undo all"). Files go through /usr/libexec/quasar/fileop where it already does
the job (unique names, the freedesktop Trash, opening with the default app).

Never touched: private key and sign-in folders (~/.ssh, ~/.gnupg, keyrings, browser profiles, …).
Changes only happen inside the home folder, removable drives and /tmp.
"""
import json
import os
import selectors
import shutil
import signal
import subprocess
import time

from . import config, store

MAX_OUTPUT = 8000
READ_LIMIT = 32 * 1024
COMMAND_TIMEOUT = 120

PRIVATE = (".ssh", ".gnupg", ".local/share/keyrings", ".local/share/quasar/ai", ".password-store", ".pki",
           ".mozilla", ".librewolf", ".config/google-chrome", ".config/chromium", ".config/BraveSoftware",
           ".config/microsoft-edge", ".var/app", ".aws", ".azure", ".kube", ".netrc", ".git-credentials",
           ".config/gh", ".docker/config.json", ".local/share/Trash")
SKIP_DIRS = {"node_modules", "__pycache__", ".git", ".cache", "venv", ".venv", "site-packages", ".npm",
             ".cargo", ".rustup", ".local", ".var", "snap", "obj", "bin"}
KINDS = {
    "document": {".pdf", ".doc", ".docx", ".odt", ".rtf", ".txt", ".md", ".xls", ".xlsx", ".ods", ".csv", ".ppt",
                 ".pptx", ".odp", ".epub"},
    "image": {".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg", ".heic", ".bmp", ".tif", ".tiff", ".avif", ".raw"},
    "video": {".mp4", ".mkv", ".webm", ".mov", ".avi", ".m4v"},
    "audio": {".mp3", ".flac", ".ogg", ".opus", ".wav", ".m4a", ".aac"},
    "archive": {".zip", ".7z", ".rar", ".tar", ".gz", ".tgz", ".xz", ".zst", ".bz2", ".iso"},
    "code": {".py", ".js", ".ts", ".tsx", ".jsx", ".cs", ".go", ".rs", ".java", ".c", ".h", ".cpp", ".hpp", ".sh",
             ".qml", ".json", ".toml", ".yaml", ".yml", ".html", ".css", ".csproj", ".sln", ".rb", ".php", ".kt"},
}


class ToolError(Exception):
    pass


class Result:
    def __init__(self, output, summary="", undo=None, changed=False, ok=True):
        self.ok = ok
        self.output = output if len(output) <= MAX_OUTPUT else output[:2000] + "\n…\n" + output[-(MAX_OUTPUT - 2100):]
        self.summary = summary
        self.undo = undo or []           # [{"tool": name, "args": {...}}]
        self.changed = changed


# ---------------------------------------------------------------------------------------------- paths
def home():
    return config.home()


def show(path):
    """~/… for paths in the home folder."""
    h = home()
    if path == h:
        return "~"
    return "~" + path[len(h):] if path.startswith(h + "/") else path


def resolve(p):
    p = str(p or "").strip()
    if not p:
        raise ToolError("No path was given.")
    if p.startswith("file://"):
        p = p[7:]
    p = os.path.expanduser(p)
    if not os.path.isabs(p):
        p = os.path.join(home(), p)
    return os.path.realpath(p)


def check_private(real):
    h = home()
    if real.startswith(h + "/"):
        rel = real[len(h) + 1:]
        for pfx in PRIVATE:
            if rel == pfx or rel.startswith(pfx + "/"):
                raise ToolError("Quasar AI doesn't open private key and sign-in folders (%s)." % show(real))


def writable_roots():
    user = os.environ.get("USER") or os.path.basename(home())
    return [home(), "/media/" + user, "/run/media/" + user, "/tmp"]


def check_change(real):
    check_private(real)
    if real in writable_roots():
        raise ToolError("Quasar AI doesn't change %s itself, only what's inside it." % show(real))
    if not any(real == r or real.startswith(r + "/") for r in writable_roots()):
        raise ToolError("Quasar AI only changes files in your home folder, removable drives and /tmp (%s isn't)."
                        % show(real))


def human(n):
    n = float(n or 0)
    for unit in ("bytes", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return ("%d %s" % (n, unit)) if unit == "bytes" else ("%.1f %s" % (n, unit))
        n /= 1024
    return ""


def when(ts):
    return time.strftime("%Y-%m-%d %H:%M", time.localtime(ts))


def fileop(*args):
    """(exit code, [json lines]) from /usr/libexec/quasar/fileop."""
    try:
        r = subprocess.run([config.FILEOP] + [str(a) for a in args], capture_output=True, timeout=600,
                           stdin=subprocess.DEVNULL)
    except (OSError, subprocess.SubprocessError) as e:
        raise ToolError("The file helper didn't run: %s" % e)
    out = []
    for line in r.stdout.decode(errors="replace").splitlines():
        try:
            out.append(json.loads(line))
        except ValueError:
            pass
    return r.returncode, out


def errors_of(lines):
    return ["%s: %s" % (show(e.get("path", "")) if e.get("path") else "", e["error"]) for e in lines if e.get("error")]


# ---------------------------------------------------------------------------------------------- files
def kind_of(name, is_dir):
    if is_dir:
        return "folder"
    ext = os.path.splitext(name)[1].lower()
    for k, exts in KINDS.items():
        if ext in exts:
            return k
    return "file"


def find_files(args, budget=3.0):
    query = str(args.get("query") or "").strip()
    kind = args.get("kind") or "any"
    root = resolve(args.get("folder") or "~")
    check_private(root)
    if not os.path.isdir(root):
        raise ToolError("%s isn't a folder." % show(root))
    import fnmatch
    low = query.lower()
    glob = any(c in low for c in "*?[")
    words = low.split()
    hidden = low.startswith(".")
    hits, seen, deadline = [], 0, time.monotonic() + budget
    stack = [root]
    truncated = False
    while stack:
        d = stack.pop()
        try:
            it = os.scandir(d)
        except OSError:
            continue
        with it:
            for e in it:
                seen += 1
                if seen % 2000 == 0 and time.monotonic() > deadline:
                    truncated, stack = True, []
                    break
                name = e.name
                if name.startswith(".") and not hidden:
                    continue
                try:
                    is_dir = e.is_dir(follow_symlinks=False)
                except OSError:
                    continue
                n = name.lower()
                match = fnmatch.fnmatch(n, low) if glob else all(w in n for w in words)
                if match and (kind == "any" or kind_of(name, is_dir) == kind):
                    try:
                        st = e.stat(follow_symlinks=False)
                    except OSError:
                        continue
                    exact = n == low or os.path.splitext(n)[0] == low
                    hits.append((0 if exact else 1, -st.st_mtime, e.path, is_dir, st))
                if is_dir and name not in SKIP_DIRS:
                    try:
                        check_private(e.path)
                    except ToolError:
                        continue
                    stack.append(e.path)
    hits.sort()
    lines = []
    for _x, _m, path, is_dir, st in hits[:40]:
        lines.append("%s%s · %s · %s" % (show(path), "/" if is_dir else "", "folder" if is_dir else human(st.st_size),
                                         when(st.st_mtime)))
    if not lines:
        out = "Nothing named like “%s” in %s." % (query, show(root))
    else:
        out = "\n".join(lines)
        if len(hits) > 40:
            out += "\n(%d more not shown)" % (len(hits) - 40)
    if truncated:
        out += "\n(The search stopped early: the folder is very large. Search a smaller folder for more.)"
    return Result(out, summary="%d found" % len(hits))


def list_folder(args):
    path = resolve(args.get("path") or "~")
    check_private(path)
    if not os.path.isdir(path):
        raise ToolError("%s isn't a folder." % show(path))
    rows = []
    with os.scandir(path) as it:
        for e in it:
            if e.name.startswith(".") and not args.get("hidden"):
                continue
            try:
                st = e.stat(follow_symlinks=False)
                is_dir = e.is_dir(follow_symlinks=False)
            except OSError:
                continue
            rows.append((not is_dir, e.name.lower(), e.name, is_dir, st))
    rows.sort()
    lines = ["%s%s · %s · %s" % (name, "/" if is_dir else "", "folder" if is_dir else human(st.st_size), when(st.st_mtime))
             for _a, _b, name, is_dir, st in rows[:200]]
    out = show(path) + " has %d item%s" % (len(rows), "" if len(rows) == 1 else "s") + (":\n" + "\n".join(lines) if lines else ".")
    if len(rows) > 200:
        out += "\n(%d more not shown)" % (len(rows) - 200)
    return Result(out, summary="%d items" % len(rows))


def file_info(args):
    path = resolve(args.get("path"))
    check_private(path)
    if not os.path.lexists(path):
        raise ToolError("%s doesn't exist." % show(path))
    st = os.lstat(path)
    if os.path.isdir(path):
        total, count, deadline, partial = 0, 0, time.monotonic() + 2.0, False
        for d, dirs, files in os.walk(path):
            for f in files:
                try:
                    total += os.lstat(os.path.join(d, f)).st_size
                except OSError:
                    pass
            count += len(files) + len(dirs)
            if time.monotonic() > deadline:
                partial = True
                break
        out = "%s/ · folder · %s%s in %d items · modified %s" % (show(path), "at least " if partial else "", human(total),
                                                                count, when(st.st_mtime))
    else:
        out = "%s · %s · %s · modified %s" % (show(path), kind_of(path, False), human(st.st_size), when(st.st_mtime))
    return Result(out)


def read_file(args):
    path = resolve(args.get("path"))
    check_private(path)
    if not os.path.isfile(path):
        raise ToolError("%s isn't a file." % show(path))
    with open(path, "rb") as f:
        data = f.read(READ_LIMIT + 1)
    if b"\0" in data[:8192]:
        raise ToolError("%s isn't a text file." % show(path))
    text = data[:READ_LIMIT].decode("utf-8", errors="replace")
    if len(data) > READ_LIMIT:
        text += "\n… (only the first 32 KB)"
    r = Result(text, summary=human(os.path.getsize(path)))
    r.output = text[:READ_LIMIT + 40]        # the model asked for the text: don't cut the middle out
    return r


def write_file(args):
    path = resolve(args.get("path"))
    check_change(path)
    content = str(args.get("content") or "")
    parent = os.path.dirname(path)
    if not os.path.isdir(parent):
        raise ToolError("The folder %s doesn't exist." % show(parent))
    undo = []
    if os.path.lexists(path):
        if not args.get("overwrite"):
            raise ToolError("%s already exists. Ask the user before replacing it (overwrite)." % show(path))
        if os.path.isdir(path):
            raise ToolError("%s is a folder." % show(path))
        code, lines = fileop("trash", path)
        trashed = [e["name"] for e in lines if e.get("trashed")]
        if code or not trashed:
            raise ToolError("Couldn't move the old %s to the Trash." % show(path))
        undo.append({"tool": "restore_trash", "args": {"names": trashed}})
    with open(path, "x", encoding="utf-8") as f:
        f.write(content)
    undo.insert(0, {"tool": "remove_path", "args": {"paths": [path]}})
    return Result("Wrote %s (%s)." % (show(path), human(len(content.encode()))), undo=undo, changed=True)


def make_folder(args):
    path = resolve(args.get("path"))
    check_change(path)
    if os.path.isdir(path):
        return Result("%s already exists." % show(path))
    top = path
    while not os.path.exists(os.path.dirname(top)):
        top = os.path.dirname(top)
    check_change(top)
    os.makedirs(path)
    return Result("Created %s." % show(path), undo=[{"tool": "remove_path", "args": {"paths": [top], "empty": True}}],
                  changed=True)


def _transfer(mode, args):
    paths = [resolve(p) for p in args.get("paths") or []]
    if not paths:
        raise ToolError("No files were given.")
    dest = resolve(args.get("to"))
    for p in paths:
        (check_change if mode == "move" else check_private)(p)
    check_private(dest)
    if dest not in writable_roots():
        check_change(dest)
    if not os.path.isdir(dest):
        raise ToolError("%s isn't a folder." % show(dest))
    code, lines = fileop(mode, dest, *paths)
    done = [e for e in lines if e.get("source") and not e.get("error")]
    failed = {e.get("path") for e in lines if e.get("error")}
    done = [e for e in done if e["source"] not in failed]
    if mode == "move":
        undo = [{"tool": "move_back", "args": {"pairs": [[e["path"], e["source"]] for e in done]}}] if done else []
    else:
        undo = [{"tool": "remove_path", "args": {"paths": [e["path"] for e in done]}}] if done else []
    verb = "Moved" if mode == "move" else "Copied"
    out = "%s %d item%s to %s." % (verb, len(done), "" if len(done) == 1 else "s", show(dest))
    renamed = [e for e in done if os.path.basename(e["path"]) != os.path.basename(e["source"])]
    if renamed:
        out += " Renamed because the name was taken: " + ", ".join(
            "%s → %s" % (os.path.basename(e["source"]), os.path.basename(e["path"])) for e in renamed)
    errs = errors_of(lines)
    if errs:
        out += "\nProblems: " + "; ".join(errs)
    return Result(out, undo=undo, changed=bool(done), ok=not errs or bool(done))


def copy_files(args):
    return _transfer("copy", args)


def move_files(args):
    return _transfer("move", args)


def rename_file(args):
    path = resolve(args.get("path"))
    check_change(path)
    name = str(args.get("name") or "").strip()
    code, lines = fileop("rename", path, name)
    if code == 2:
        raise ToolError("Something called “%s” is already there." % name)
    if code == 4:
        raise ToolError("“%s” can't be used as a name." % name)
    if code:
        raise ToolError("; ".join(errors_of(lines)) or "The rename failed.")
    new = os.path.join(os.path.dirname(path), name)
    return Result("Renamed %s to %s." % (show(path), name),
                  undo=[{"tool": "rename_file", "args": {"path": new, "name": os.path.basename(path)}}], changed=True)


def trash_files(args):
    paths = [resolve(p) for p in args.get("paths") or []]
    if not paths:
        raise ToolError("No files were given.")
    for p in paths:
        check_change(p)
    code, lines = fileop("trash", *paths)
    names = [e["name"] for e in lines if e.get("trashed")]
    out = "Moved %d item%s to the Trash." % (len(names), "" if len(names) == 1 else "s")
    errs = errors_of(lines)
    if errs:
        out += "\nProblems: " + "; ".join(errs)
    return Result(out, undo=[{"tool": "restore_trash", "args": {"names": names}}] if names else [],
                  changed=bool(names), ok=bool(names) or not errs)


# ---- undo-only calls -------------------------------------------------------------------------------
def restore_trash(args):
    code, lines = fileop("restore", *(args.get("names") or []))
    errs = errors_of(lines)
    if code and errs:
        raise ToolError("; ".join(errs))
    return Result("Restored from the Trash.")


def remove_path(args):
    """Undo of creating or copying: the new items go to the Trash (never deleted for good)."""
    paths = [p for p in args.get("paths") or [] if os.path.lexists(p)]
    if args.get("empty"):
        paths = [p for p in paths if not (os.path.isdir(p) and _has_files(p))]
    if not paths:
        return Result("Nothing to remove.")
    code, lines = fileop("trash", *paths)
    if code:
        raise ToolError("; ".join(errors_of(lines)) or "Couldn't remove them.")
    return Result("Moved to the Trash.")


def _has_files(d):
    for _r, _dirs, files in os.walk(d):
        if files:
            return True
    return False


def move_back(args):
    problems = []
    for cur, orig in args.get("pairs") or []:
        if not os.path.lexists(cur):
            problems.append("%s is gone" % show(cur))
            continue
        if os.path.lexists(orig):
            problems.append("%s is taken again" % show(orig))
            continue
        try:
            os.rename(cur, orig)
        except OSError:
            try:
                shutil.move(cur, orig)
            except (OSError, shutil.Error) as e:
                problems.append("%s: %s" % (show(cur), e))
    if problems:
        raise ToolError("Couldn't move everything back: " + "; ".join(problems))
    return Result("Moved back.")


# ------------------------------------------------------------------------------------------- opening
def open_path(args):
    path = resolve(args.get("path"))
    check_private(path)
    code, lines = fileop("open", path)
    if code == 3:
        raise ToolError("No app on this PC can open %s yet." % show(path))
    if code:
        raise ToolError("; ".join(errors_of(lines)) or "It didn't open.")
    app = next((e.get("name") for e in lines if e.get("name")), "")
    return Result("Opened %s%s." % (show(path), " with " + app if app else ""))


def open_url(args):
    url = str(args.get("url") or "").strip()
    if not url.lower().startswith(("http://", "https://")):
        raise ToolError("Only http and https addresses can be opened.")
    code, lines = fileop("open", url)
    if code:
        raise ToolError("; ".join(errors_of(lines)) or "No browser is installed.")
    return Result("Opened %s in the browser." % url)


# ------------------------------------------------------------------------------------------ commands
def command_env():
    env = dict(os.environ)
    for k in ("SUDO_ASKPASS", "SSH_ASKPASS"):
        env.pop(k, None)
    env.update({"TERM": "dumb", "NO_COLOR": "1", "PAGER": "cat", "GIT_PAGER": "cat", "SYSTEMD_PAGER": "cat",
                "MANPAGER": "cat", "DEBIAN_FRONTEND": "noninteractive", "GIT_TERMINAL_PROMPT": "0"})
    return env


def run_command(args, wrap=None, on_line=None, cancelled=lambda: False, timeout=COMMAND_TIMEOUT):
    command = str(args.get("command") or "").strip()
    if not command:
        raise ToolError("No command was given.")
    cwd = None
    if not wrap:
        cwd = resolve(args.get("folder") or "~")
        if not os.path.isdir(cwd):
            raise ToolError("%s isn't a folder." % show(cwd))
    argv = list(wrap or []) + ["/bin/bash", "-lc", command]
    try:
        p = subprocess.Popen(argv, cwd=cwd, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                             stderr=subprocess.STDOUT, env=command_env(), start_new_session=True)
    except OSError as e:
        raise ToolError("The command didn't start: %s" % e)
    sel = selectors.DefaultSelector()
    sel.register(p.stdout, selectors.EVENT_READ)
    buf, head, tail = b"", [], []
    size = {"head": 0, "tail": 0, "total": 0, "cut": 0}
    deadline, reason = time.monotonic() + timeout, ""
    tail_max = MAX_OUTPUT - 2400            # the head keeps ~2000, the rest is the newest output

    def take(line):
        n = len(line) + 1
        size["total"] += n
        if size["head"] < 2000:
            head.append(line)
            size["head"] += n
        else:
            tail.append(line)
            size["tail"] += n
            while size["tail"] > tail_max and len(tail) > 1:
                size["tail"] -= len(tail[0]) + 1
                size["cut"] += len(tail.pop(0)) + 1
        if on_line:
            on_line(line)

    while True:
        if cancelled():
            reason = "stopped"
        elif time.monotonic() > deadline:
            reason = "timeout"
        if reason:
            try:
                os.killpg(p.pid, signal.SIGTERM)
                time.sleep(0.5)
                os.killpg(p.pid, signal.SIGKILL)
            except OSError:
                pass
            break
        if not sel.select(timeout=0.2):
            if p.poll() is not None:
                break
            continue
        chunk = os.read(p.stdout.fileno(), 65536)
        if not chunk:
            break
        buf += chunk
        while b"\n" in buf:
            line, buf = buf.split(b"\n", 1)
            take(line.decode(errors="replace").rstrip("\r"))
    if buf:
        take(buf.decode(errors="replace"))
    sel.close()
    try:
        code = p.wait(timeout=5)
    except subprocess.TimeoutExpired:
        code = -9
    out = "\n".join(head + (["… (%d characters cut)" % size["cut"]] if size["cut"] else []) + tail)
    if reason == "timeout":
        return Result((out + "\n" if out else "") + "Stopped: it ran longer than %d seconds." % timeout,
                      summary="Timed out", changed=True, ok=False)
    if reason == "stopped":
        return Result((out + "\n" if out else "") + "The user stopped it.", summary="Stopped", changed=True, ok=False)
    return Result((out + "\n" if out else "") + "Exit code %d." % code, summary="Exit code %d" % code if code else "",
                  changed=True, ok=code == 0)


# ---------------------------------------------------------------------------------------- the system
def _read(path, default=""):
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            return f.read().strip()
    except OSError:
        return default


def _run(argv, timeout=5):
    try:
        r = subprocess.run(argv, capture_output=True, timeout=timeout, stdin=subprocess.DEVNULL)
        return r.stdout.decode(errors="replace").strip() if r.returncode == 0 else ""
    except (OSError, subprocess.SubprocessError):
        return ""


def system_info(args):
    topic = args.get("topic") or "all"
    parts = []
    if topic in ("all", "os"):
        rel = dict(line.split("=", 1) for line in _read("/etc/os-release").splitlines() if "=" in line)
        uptime = _read("/proc/uptime").split(" ")[0]
        parts.append("OS: Quasar (%s), kernel %s, hostname %s, up %s. Live USB: %s. Time: %s." % (
            rel.get("PRETTY_NAME", "Linux").strip('"'), os.uname().release, os.uname().nodename,
            "%dh %dm" % divmod(int(float(uptime or 0)) // 60, 60) if uptime else "?",
            "yes" if config.is_live() else "no", time.strftime("%A %Y-%m-%d %H:%M %Z")))
    if topic in ("all", "hardware"):
        hw = config.hardware()
        cpu = (hw.get("cpu") or {}).get("model") or _run(["sh", "-c", "grep -m1 'model name' /proc/cpuinfo | cut -d: -f2"])
        gpus = ["%s (%s)" % (g.get("name"), g.get("driverLabel") or g.get("driver") or "no driver") for g in hw.get("gpus") or []]
        acc = config.accel(hw)
        parts.append("Hardware: CPU %s; graphics %s; AI acceleration: %s. Virtual machine: %s." % (
            (cpu or "unknown").strip(), "; ".join(gpus) or "unknown",
            {"cuda": "NVIDIA CUDA", "vulkan": "Vulkan GPU", "cpu": "CPU only"}[acc[0]], "yes" if hw.get("virtual") else "no"))
    if topic in ("all", "memory"):
        m = config.meminfo()
        parts.append("Memory: %s total, %s available; swap %s free of %s." % (
            human(m.get("MemTotal", 0) * 1024), human(m.get("MemAvailable", 0) * 1024),
            human(m.get("SwapFree", 0) * 1024), human(m.get("SwapTotal", 0) * 1024)))
    if topic in ("all", "storage"):
        seen, rows = set(), []
        for label, p in (("System", "/"), ("Home", home())):
            try:
                st = os.statvfs(p)
            except OSError:
                continue
            if st.f_fsid in seen:
                continue
            seen.add(st.f_fsid)
            rows.append("%s: %s free of %s" % (label, human(st.f_bavail * st.f_frsize), human(st.f_blocks * st.f_frsize)))
        parts.append("Storage: " + "; ".join(rows) + ".")
    if topic in ("all", "battery"):
        bats = []
        base = "/sys/class/power_supply"
        for n in sorted(os.listdir(base)) if os.path.isdir(base) else []:
            if _read(os.path.join(base, n, "type")) == "Battery":
                bats.append("%s%% (%s)" % (_read(os.path.join(base, n, "capacity"), "?"),
                                           _read(os.path.join(base, n, "status"), "unknown").lower()))
        parts.append("Battery: " + (", ".join(bats) if bats else "none (desktop PC or VM)") + ".")
    if topic in ("all", "network"):
        dev = _run(["nmcli", "-t", "-f", "DEVICE,TYPE,STATE,CONNECTION", "device"])
        rows = []
        for line in dev.splitlines():
            f = line.split(":")
            if len(f) >= 4 and f[1] in ("wifi", "ethernet") and f[2]:
                rows.append("%s %s: %s%s" % (f[1], f[0], f[2], " to “%s”" % f[3] if f[3] else ""))
        parts.append("Network: " + ("; ".join(rows) if rows else "no details (NetworkManager didn't answer)") + ".")
    return Result("\n".join(parts))


# ------------------------------------------------------------------------------------------- Store
_installed_cache = {}


def _installed():
    if "flatpak" not in _installed_cache:
        _installed_cache["flatpak"] = set(_run(["flatpak", "list", "--app", "--columns=application"], 10).split())
    return _installed_cache["flatpak"]


def _dpkg_installed(pkg):
    out = _run(["dpkg-query", "-W", "-f=${Status}", pkg])
    return out.endswith("installed") and "not-installed" not in out


def _mise_installed(tool):
    if "mise" not in _installed_cache:
        try:
            _installed_cache["mise"] = json.loads(_run(["mise", "ls", "--installed", "--json"], 10) or "{}")
        except ValueError:
            _installed_cache["mise"] = {}
    return bool(_installed_cache["mise"].get(tool))


def search_store(args):
    query = " ".join(str(args.get("query") or "").lower().split())
    try:
        found, total = store.search(query, limit=8)
    except store.CatalogMissing:
        raise ToolError("The Store catalog isn't on this PC.")
    marks = store.has_picks()
    _installed_cache.clear()
    lines = []
    for a in found:
        src = a.get("source")
        if src == "flathub":
            inst = a.get("id") in _installed()
        elif src == "debian":
            inst = bool(a.get("pkgs")) and _dpkg_installed(a["pkgs"][0])
        elif src == "mise":
            inst = _mise_installed(a.get("tool") or a.get("id"))
        else:
            inst = False
        mark = "" if not marks else " · Quasar pick" if a.get("pick") else " · not hand-picked by Quasar"
        lines.append("%s · id %s · %s · %s%s%s" % (a.get("name"), a.get("id"), a.get("blurb") or "",
                                                   {"flathub": "Flathub app", "debian": "system package",
                                                    "mise": "developer tool"}.get(src, src),
                                                   mark, " · INSTALLED" if inst else ""))
    return Result("\n".join(lines) if lines else "The Store has nothing matching “%s”." % query,
                  summary="%d found" % total)


HANDLERS = {
    "find_files": find_files, "list_folder": list_folder, "file_info": file_info, "read_file": read_file,
    "write_file": write_file, "make_folder": make_folder, "copy_files": copy_files, "move_files": move_files,
    "rename_file": rename_file, "trash_files": trash_files, "open_path": open_path, "open_url": open_url,
    "system_info": system_info, "search_store": search_store, "run_command": run_command,
    "restore_trash": restore_trash, "remove_path": remove_path, "move_back": move_back,
}
