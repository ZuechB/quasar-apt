"""What the assistant can do: every tool's schema for the model, plus how the panel shows it.

  side  "helper": run here (files, commands, system info, Store catalog)
        "shell":  sent to the shell as a "call" (apps, windows, settings, Store installs)
  risk  "read": runs straight away · "act": a reversible change (held in the plan) ·
        "ask": always needs the user's yes (installs, commands, trash, closing windows)
  perm  the Settings › Quasar AI switch that allows it (None: always allowed):
        apps · settings · install · files · commands
  tag   the permission label on the step (the mockup's mono tag)
"""
from . import store


def S(props, required=()):
    return {"type": "object", "properties": props, "required": list(required)}


STR = {"type": "string"}
BOOL = {"type": "boolean"}
PATHS = {"type": "array", "items": {"type": "string"}, "description": "Paths; ~ is the home folder."}

SETTING_KEYS = ["wifi", "bluetooth", "airplane", "volume", "mute", "brightness", "nightLight", "focus",
                "profile", "accent", "wallpaper", "desktopArrange", "reduceMotion"]

SETTING_LABELS = {
    "wifi": "Wi-Fi", "bluetooth": "Bluetooth", "airplane": "Airplane mode", "volume": "Volume",
    "mute": "Mute", "brightness": "Brightness", "nightLight": "Night light", "focus": "Focus",
    "profile": "Performance profile", "accent": "Accent color", "wallpaper": "Wallpaper",
    "desktopArrange": "Desktop icon layout", "reduceMotion": "Reduce motion",
}

SETTINGS_PAGES = ["network", "vpn", "hotspot", "dns", "profiles", "bluetooth", "drivers", "display", "desktop", "sound", "appearance",
                  "notifications", "privacy", "ai", "apps", "performance", "storage", "users", "input",
                  "language", "updates", "about"]


def _short(text, n=60):
    text = " ".join(str(text or "").split())
    return text if len(text) <= n else text[:n - 1] + "…"


def _names(paths):
    paths = paths or []
    if not paths:
        return ""
    base = [str(p).rstrip("/").rsplit("/", 1)[-1] or str(p) for p in paths]
    return base[0] if len(base) == 1 else "%s and %d more" % (base[0], len(base) - 1)


def _setting_title(a):
    k, v = a.get("key"), a.get("value")
    label = SETTING_LABELS.get(k, str(k))
    if isinstance(v, bool):
        return "Turn %s %s" % ("on" if v else "off", label)
    if k in ("volume", "brightness"):
        return "Set %s to %s%%" % (label.lower(), v)
    return "Set %s to %s" % (label.lower(), v)


TOOLS = [
    # ---- apps and windows ---------------------------------------------------------------------------
    {"name": "search_apps", "side": "shell", "risk": "read", "perm": None, "tag": "Read only",
     "description": "Find installed apps by name or purpose. Returns app ids to use with open_app.",
     "parameters": S({"query": STR}, ["query"]),
     "title": lambda a: "Look for apps matching “%s”" % _short(a.get("query"), 40)},
    {"name": "open_app", "side": "shell", "risk": "act", "perm": "apps", "tag": "Open apps", "change": False,
     "description": "Open an installed app. Use the id from search_apps.",
     "parameters": S({"app": {"type": "string", "description": "App id, e.g. firefox-esr or quasar-terminal"},
                      "args": {"type": "array", "items": STR, "description": "Optional: files or URLs to open with it"}},
                     ["app"]),
     "title": lambda a: "Open %s" % _short(a.get("app"), 40)},
    {"name": "list_windows", "side": "shell", "risk": "read", "perm": "apps", "tag": "Read only",
     "description": "List open windows with their ids, apps and titles.",
     "parameters": S({}), "title": lambda a: "Check which windows are open"},
    {"name": "focus_window", "side": "shell", "risk": "act", "perm": "apps", "tag": "Arrange apps", "change": False,
     "description": "Bring a window to the front (id from list_windows).",
     "parameters": S({"window": STR}, ["window"]), "title": lambda a: "Bring a window to the front"},
    {"name": "minimize_window", "side": "shell", "risk": "act", "perm": "apps", "tag": "Arrange apps",
     "description": "Minimize a window (id from list_windows).",
     "parameters": S({"window": STR}, ["window"]), "title": lambda a: "Minimize a window"},
    {"name": "close_window", "side": "shell", "risk": "ask", "perm": "apps", "tag": "Arrange apps",
     "description": "Close a window (id from list_windows). Unsaved work may be lost, so the user is asked.",
     "parameters": S({"window": STR}, ["window"]), "title": lambda a: "Close a window"},
    {"name": "show_desktop", "side": "shell", "risk": "act", "perm": "apps", "tag": "Arrange apps",
     "description": "Minimize every window to show the desktop.",
     "parameters": S({}), "title": lambda a: "Minimize everything"},
    {"name": "open_terminal", "side": "shell", "risk": "act", "perm": "apps", "tag": "Open apps", "change": False,
     "description": "Open the Terminal, optionally in a folder. Use this for anything interactive.",
     "parameters": S({"folder": STR}), "title": lambda a: "Open the Terminal" + (" in " + _short(a.get("folder"), 40) if a.get("folder") else "")},
    {"name": "open_path", "side": "helper", "risk": "act", "perm": "apps", "tag": "Open apps", "change": False,
     "description": "Open a file or folder with its default app.",
     "parameters": S({"path": STR}, ["path"]), "title": lambda a: "Open %s" % _names([a.get("path")])},
    {"name": "open_url", "side": "helper", "risk": "act", "perm": "apps", "tag": "Open apps", "change": False,
     "description": "Open a web address (http or https) in the default browser.",
     "parameters": S({"url": STR}, ["url"]), "title": lambda a: "Open %s" % _short(a.get("url"), 48)},

    # ---- settings -----------------------------------------------------------------------------------
    {"name": "get_settings", "side": "shell", "risk": "read", "perm": None, "tag": "Read only",
     "description": "Current values of the settings set_setting can change.",
     "parameters": S({}), "title": lambda a: "Check the current settings"},
    {"name": "set_setting", "side": "shell", "risk": "act", "perm": "settings", "tag": "Settings",
     "description": ("Change a setting. Keys and values: wifi, bluetooth, airplane, mute, nightLight, focus "
                     "(Do Not Disturb), reduceMotion: true/false; volume, brightness: 0-100; profile: lite|balanced|max; "
                     "accent: ice|violet|amber|mint|rose; wallpaper: deep|aurora|graphite|photo (photo = the user's own "
                     "picture, only if get_settings shows one); desktopArrange: grid|free|auto."),
     "parameters": S({"key": {"type": "string", "enum": SETTING_KEYS},
                      "value": {"description": "true/false, a number or a name, depending on the key"}},
                     ["key", "value"]),
     "title": _setting_title},
    {"name": "find_setting", "side": "shell", "risk": "read", "perm": None, "tag": "Read only",
     "description": "Find which Settings page has something (e.g. 'screen resolution', 'printer').",
     "parameters": S({"query": STR}, ["query"]),
     "title": lambda a: "Look in Settings for “%s”" % _short(a.get("query"), 40)},
    {"name": "open_settings", "side": "shell", "risk": "act", "perm": None, "tag": "Open apps", "change": False,
     "description": "Open Settings at a page: " + ", ".join(SETTINGS_PAGES) + ".",
     "parameters": S({"page": {"type": "string", "enum": SETTINGS_PAGES}}),
     "title": lambda a: "Open Settings" + (" › " + str(a.get("page")).capitalize() if a.get("page") else "")},

    # ---- Store --------------------------------------------------------------------------------------
    {"name": "search_store", "side": "helper", "risk": "read", "perm": None, "tag": "Read only",
     "description": ("Search the Quasar Store (all of Flathub plus Quasar's hand-picked apps and developer tools). "
                     "Returns ids for install_app, whether each is installed, and whether Quasar picked it: "
                     "prefer a Quasar pick when several fit."),
     "parameters": S({"query": STR}, ["query"]),
     "title": lambda a: "Find “%s” in the Store" % _short(a.get("query"), 40)},
    {"name": "install_app", "side": "shell", "risk": "ask", "perm": "install", "tag": "Install",
     "description": "Install an app from the Store (id from search_store). The Store opens and shows the progress.",
     "parameters": S({"id": STR, "name": {"type": "string", "description": "The app's name, for the user"}}, ["id"]),
     "title": lambda a: "Install %s" % _short(a.get("name") or a.get("id"), 40)},
    {"name": "remove_app", "side": "shell", "risk": "ask", "perm": "install", "tag": "Install",
     "description": "Remove an app that was installed from the Store (id from search_store).",
     "parameters": S({"id": STR, "name": STR}, ["id"]),
     "title": lambda a: "Remove %s" % _short(a.get("name") or a.get("id"), 40)},

    # ---- files --------------------------------------------------------------------------------------
    {"name": "find_files", "side": "helper", "risk": "read", "perm": "files", "tag": "Read files",
     "description": ("Find files and folders by name in the home folder (or a folder inside it). Words must all "
                     "appear in the name; * and ? work as wildcards. Newest first."),
     "parameters": S({"query": STR, "folder": STR,
                      "kind": {"type": "string", "enum": ["any", "folder", "document", "image", "video", "audio", "archive", "code"]}},
                     ["query"]),
     "title": lambda a: "Search files for “%s”" % _short(a.get("query"), 40)},
    {"name": "list_folder", "side": "helper", "risk": "read", "perm": "files", "tag": "Read files",
     "description": "List what's in a folder (names, sizes, dates).",
     "parameters": S({"path": STR, "hidden": BOOL}, ["path"]),
     "title": lambda a: "Look in %s" % _names([a.get("path") or "~"])},
    {"name": "file_info", "side": "helper", "risk": "read", "perm": "files", "tag": "Read files",
     "description": "Size, type and dates of a file or folder (folders: total size and item count).",
     "parameters": S({"path": STR}, ["path"]), "title": lambda a: "Check %s" % _names([a.get("path")])},
    {"name": "read_file", "side": "helper", "risk": "read", "perm": "files", "tag": "Read files",
     "description": "Read a text file (first 32 KB).",
     "parameters": S({"path": STR}, ["path"]), "title": lambda a: "Read %s" % _names([a.get("path")])},
    {"name": "write_file", "side": "helper", "risk": "act", "perm": "files", "tag": "Write files",
     "description": "Create a text file. Set overwrite to replace an existing one (the old one goes to the Trash).",
     "parameters": S({"path": STR, "content": STR, "overwrite": BOOL}, ["path", "content"]),
     "title": lambda a: ("Replace %s" if a.get("overwrite") else "Create %s") % _names([a.get("path")])},
    {"name": "make_folder", "side": "helper", "risk": "act", "perm": "files", "tag": "Write files",
     "description": "Create a folder (and any missing parents).",
     "parameters": S({"path": STR}, ["path"]), "title": lambda a: "Create the folder %s" % _names([a.get("path")])},
    {"name": "copy_files", "side": "helper", "risk": "act", "perm": "files", "tag": "Write files",
     "description": "Copy files or folders into a folder. Clashing names get “(2)”.",
     "parameters": S({"paths": PATHS, "to": STR}, ["paths", "to"]),
     "title": lambda a: "Copy %s to %s" % (_names(a.get("paths")), _names([a.get("to")]))},
    {"name": "move_files", "side": "helper", "risk": "act", "perm": "files", "tag": "Move files",
     "description": "Move files or folders into a folder. Clashing names get “(2)”.",
     "parameters": S({"paths": PATHS, "to": STR}, ["paths", "to"]),
     "title": lambda a: "Move %s to %s" % (_names(a.get("paths")), _names([a.get("to")]))},
    {"name": "rename_file", "side": "helper", "risk": "act", "perm": "files", "tag": "Move files",
     "description": "Rename a file or folder (new name only, not a path).",
     "parameters": S({"path": STR, "name": STR}, ["path", "name"]),
     "title": lambda a: "Rename %s to %s" % (_names([a.get("path")]), _short(a.get("name"), 30))},
    {"name": "trash_files", "side": "helper", "risk": "ask", "perm": "files", "tag": "Trash",
     "description": "Move files or folders to the Trash. Nothing is deleted for good.",
     "parameters": S({"paths": PATHS}, ["paths"]),
     "title": lambda a: "Move %s to the Trash" % _names(a.get("paths"))},

    # ---- commands and the system --------------------------------------------------------------------
    {"name": "run_command", "side": "helper", "risk": "ask", "perm": "commands", "tag": "Run commands",
     "description": ("Run a bash command as the user (never root, no sudo, no terminal, 120 s limit). Output is "
                     "returned. For anything interactive, use open_terminal instead."),
     "parameters": S({"command": STR, "folder": {"type": "string", "description": "Working folder, default ~"}},
                     ["command"]),
     "title": lambda a: "Run a command"},
    {"name": "system_info", "side": "helper", "risk": "read", "perm": None, "tag": "Read only",
     "description": "About this PC: OS, hardware, memory, storage, battery, network and time.",
     "parameters": S({"topic": {"type": "string", "enum": ["all", "os", "hardware", "memory", "storage", "battery", "network"]}}),
     "title": lambda a: "Check this PC" + ("’s " + a["topic"] if a.get("topic") not in (None, "all") else "")},
]

BY_NAME = {t["name"]: t for t in TOOLS}
UNDO_ONLY = {"restore_trash", "remove_path", "set_window_minimized"}   # inverse calls, never offered to models


def enabled(perms):
    """Tools the model may see, given the Settings switches {apps: bool, …}."""
    perms = perms or {}
    return [t for t in TOOLS if t["perm"] is None or perms.get(t["perm"], True)]


def schemas(tools):
    return [{"name": t["name"], "description": t["description"], "parameters": t["parameters"]} for t in tools]


def risk(tool, args, cloud):
    """Some calls are riskier than their tool's default."""
    r = tool["risk"]
    if tool["name"] == "read_file" and cloud:
        return "ask"           # the contents leave this PC
    if tool["name"] == "write_file" and args.get("overwrite"):
        return "ask"
    return r


def title(tool, args):
    try:
        return tool["title"](args)
    except Exception:  # noqa: BLE001  (a model can send anything)
        return tool["name"].replace("_", " ").capitalize()


def detail(tool, args, company=""):
    """The grey line under the step title."""
    n = tool["name"]
    if n == "run_command":
        return _short(args.get("command"), 400)
    if n == "read_file" and company:
        return "Sends the file's text to %s" % company
    if n in ("copy_files", "move_files", "trash_files"):
        return _short(", ".join(str(p) for p in args.get("paths") or []), 120)
    if n in ("rename_file", "make_folder", "write_file", "open_path", "file_info", "list_folder", "read_file"):
        return _short(args.get("path"), 120)
    if n == "install_app":
        a = store.by_id(str(args.get("id") or ""))
        if a and a.get("source") == "flathub" and not a.get("pick") and store.has_picks():
            return "From Flathub · not hand-picked by Quasar · the Store shows the progress"
        return "The Store shows the progress"
    if n == "close_window":
        return "Unsaved work in it may be lost"
    return ""


def check_args(tool, args):
    """'' when the call has what the tool needs, else what's missing (sent back to the model)."""
    if not isinstance(args, dict) or "_invalid" in args:
        return "The arguments weren't valid JSON."
    for k in tool["parameters"].get("required", []):
        if k not in args or args[k] in (None, ""):
            return "Missing the “%s” argument." % k
    props = tool["parameters"].get("properties", {})
    for k, spec in props.items():
        if k in args and spec.get("type") == "array" and not isinstance(args[k], list):
            args[k] = [args[k]] if isinstance(args[k], str) else []
        if k in args and spec.get("enum") and args[k] not in spec["enum"]:
            return "“%s” must be one of: %s." % (k, ", ".join(spec["enum"]))
    return ""
