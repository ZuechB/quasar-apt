"""The Store catalog (/usr/share/quasar/store/catalog.json), read once and again only when it changes.

The Store lists all of Flathub (about 3,400 apps) plus Quasar's picks (marked `pick`). search() ranks
matches for the search_store tool; by_id() lets the install step say whether an app is a pick."""
import json
import os

from . import config

_cache = {"path": None, "stamp": None, "apps": [], "by_id": {}, "picks": False}


class CatalogMissing(Exception):
    pass


def apps():
    path = config.STORE_CATALOG
    try:
        st = os.stat(path)
    except OSError as ex:
        raise CatalogMissing(path) from ex
    stamp = (st.st_mtime_ns, st.st_size)
    if _cache["path"] != path or _cache["stamp"] != stamp:
        try:
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, ValueError) as ex:
            raise CatalogMissing(path) from ex
        lst = [a for a in (data.get("apps") or []) if isinstance(a, dict) and a.get("id")]
        _cache.update(path=path, stamp=stamp, apps=lst, by_id={a["id"]: a for a in lst},
                      picks=any(a.get("pick") for a in lst))
    return _cache["apps"]


def by_id(app_id):
    try:
        apps()
    except CatalogMissing:
        return None
    return _cache["by_id"].get(app_id)


def has_picks():
    """Older catalogs (before all of Flathub) mark nothing; then nothing is called "not hand-picked"."""
    try:
        apps()
    except CatalogMissing:
        return False
    return _cache["picks"]


def _keywords(a):
    kw = a.get("keywords") or ""
    return kw if isinstance(kw, str) else " ".join(str(k) for k in kw)


def search(query, limit=8):
    """(best matches, how many matched). Every word must appear in the name, id, blurb, developer,
    keywords or category. Order: exact name, name starting with the query, every word in the name, the
    rest; within each, Quasar's picks, then verified developers, then the most installed."""
    words = [w for w in str(query or "").lower().split() if w]
    if not words:
        return [], 0
    phrase = " ".join(words)
    scored = []
    for a in apps():
        name = str(a.get("name") or "").lower()
        hay = " ".join([name, a["id"].lower(), str(a.get("blurb") or "").lower(), str(a.get("dev") or "").lower(),
                        _keywords(a).lower(), str(a.get("cat") or "")])
        if not all(w in hay for w in words):
            continue
        tier = 0 if name == phrase else 1 if name.startswith(phrase) else 2 if all(w in name for w in words) else 3
        scored.append(((tier, not a.get("pick"), not a.get("verified"), -int(a.get("rank") or 0), name), a))
    scored.sort(key=lambda x: x[0])
    return [a for _k, a in scored[:limit]], len(scored)
