"""quasar-ai command line. Every mode prints JSON lines (see events.py) and exits 0 / 1 / 2 (usage).

  quasar-ai serve                       the assistant loop for the shell (session.py)
  quasar-ai models PROVIDER             {"type":"models","provider","models":[{id,name,…}],"default"}
  quasar-ai pull NAME                   download an Ollama model: progress / phase lines, then result
  quasar-ai delete NAME                 remove an Ollama model
  quasar-ai show NAME                   {"type":"model","capabilities":[…],"tools":bool}
  quasar-ai key set PROVIDER            the key on stdin; checked with one request, then saved
  quasar-ai key clear|status PROVIDER
  quasar-ai test PROVIDER [MODEL]       one tiny request: does it answer?
  quasar-ai engine                      the on-device engine: installed, version, running, acceleration
  quasar-ai hardware                    memory, GPU and acceleration, for model recommendations
  quasar-ai runtime-latest              the newest Ollama release on GitHub (only when the user asks)

Only `serve` (when asked), `models` and `test` for cloud providers, `key set`, `pull` and
`runtime-latest` use the network, and only because the user just asked for it.
"""
import json
import os
import re
import sys

from . import config, providers
from .events import AiError, FAILED, OK, USAGE, emit, error

MODEL_NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._/:-]{0,199}$")


def _keys():
    from .secrets import Keys
    return Keys()


def _provider(pid, model="", keys=None):
    info = config.provider(pid)
    key = ""
    if info["needsKey"]:
        key = (keys or _keys()).get(pid)
        if not key:
            raise AiError("Add your %s API key first." % info["name"], code="key", action="settings")
    return providers.make(pid, key, model)


def cmd_models(pid):
    prov = _provider(pid)
    ms = prov.models()
    emit("models", provider=pid, models=ms, default=providers.pick_default(pid, ms))


def _check_name(name):
    if not MODEL_NAME.match(name or ""):
        raise AiError("That isn't a model name.", code="model")


PHASES = {"pulling manifest": "Getting ready", "verifying sha256 digest": "Checking the download",
          "writing manifest": "Finishing", "removing any unused layers": "Finishing", "success": "Done"}


def cmd_pull(name):
    _check_name(name)
    prov = providers.make("ollama")
    s = prov.stream("POST", "/api/pull", {"model": name, "stream": True}, timeout=600)
    s.open()
    layers, last_pct, last_phase = {}, -1, ""
    try:
        for line in s.lines():
            if not line.strip():
                continue
            try:
                obj = json.loads(line)
            except ValueError:
                continue
            if obj.get("error"):
                msg = str(obj["error"])
                if "not found" in msg or "file does not exist" in msg:
                    raise AiError("Ollama's library has no model called %s." % name, code="model", details=msg)
                raise AiError("The download stopped: %s" % msg, code="failed", details=msg)
            status = str(obj.get("status") or "")
            phase = "Downloading" if status.startswith("pulling ") and status != "pulling manifest" else PHASES.get(status, "")
            if phase and phase != last_phase:
                emit("phase", text=phase)
                last_phase = phase
            if obj.get("digest") and obj.get("total"):
                layers[obj["digest"]] = (int(obj.get("completed") or 0), int(obj["total"]))
                done = sum(c for c, _t in layers.values())
                total = sum(t for _c, t in layers.values())
                pct = int(done * 100 / total) if total else 0
                if pct != last_pct:
                    emit("progress", percent=pct, done=done, total=total)
                    last_pct = pct
            if status == "success":
                emit("result", model=name)
                return
    finally:
        s.close()
    raise AiError("The download ended early. Try again.", code="network", action="retry")


def cmd_delete(name):
    _check_name(name)
    prov = providers.make("ollama")
    s = prov.stream("DELETE", "/api/delete", {"model": name}, timeout=60)
    s.open()
    s.close()
    emit("result", model=name, deleted=True)


def cmd_show(name):
    _check_name(name)
    info = providers.make("ollama").show(name)
    caps = info.get("capabilities") or []
    emit("model", model=name, capabilities=caps, tools="tools" in caps,
         details=info.get("details") or {})


def cmd_key(verb, pid):
    config.provider(pid)
    keys = _keys()
    if verb == "status":
        emit("key", **keys.status(pid))
    elif verb == "clear":
        keys.clear(pid)
        emit("key", **keys.status(pid))
    elif verb == "set":
        key = sys.stdin.readline().strip()
        prov = providers.make(pid, key, "")
        ms = prov.models()                          # one authenticated request: is the key right?
        store = keys.set(pid, key)
        emit("key", provider=pid, set=True, hint="…" + key[-4:], store=store)
        emit("models", provider=pid, models=ms, default=providers.pick_default(pid, ms))
    else:
        raise AiError("usage", code="usage")


def cmd_test(pid, model=""):
    prov = _provider(pid, model)
    got = []
    turn = prov.chat("Reply with the single word OK.", [{"role": "user", "content": "Say OK."}], [],
                     got.append, lambda s: None)
    emit("result", ok=True, reply=turn.text.strip()[:200], model=prov.model)


def cmd_engine():
    installed = config.engine_installed()
    version = ""
    try:
        with open(os.path.join(config.ENGINE_DIR, ".quasar-version"), encoding="utf-8") as f:
            version = f.read().strip()
    except OSError:
        pass
    libdir = os.path.join(config.ENGINE_DIR, "lib", "ollama")
    cuda = installed and any(n.startswith("cuda") for n in (os.listdir(libdir) if os.path.isdir(libdir) else []))
    mode, gpu, vram = config.accel()
    emit("engine", installed=installed, version=version,
         enabled=config.systemctl("is-enabled", "quasar-ollama.socket") == "enabled",
         running=config.systemctl("is-active", config.ENGINE_UNIT) == "active",
         accel=mode if (mode != "cuda" or cuda) else "cpu", gpu=gpu, vramMB=vram, cudaInstalled=cuda,
         live=config.is_live(), ramMB=config.mem_total_mb())


def cmd_hardware():
    mode, gpu, vram = config.accel()
    emit("hardware", ramMB=config.mem_total_mb(), accel=mode, gpu=gpu, vramMB=vram, live=config.is_live())


def cmd_runtime_latest():
    from .net import Stream
    data = Stream("GET", config.GITHUB_LATEST, {"Accept": "application/vnd.github+json"}, timeout=30,
                  who="GitHub").open().json() or {}
    tag = str(data.get("tag_name") or "").lstrip("v")
    if not re.match(r"^\d+\.\d+\.\d+$", tag):
        raise AiError("GitHub didn't say which Ollama version is newest.", code="failed")
    emit("latest", version=tag, published=data.get("published_at") or "")


def main(argv):
    if not argv:
        sys.stderr.write(__doc__)
        return USAGE
    cmd, rest = argv[0], argv[1:]
    try:
        if cmd == "serve":
            from .session import Session
            return Session().serve()
        if cmd == "models" and len(rest) == 1:
            cmd_models(rest[0])
        elif cmd == "pull" and len(rest) == 1:
            cmd_pull(rest[0])
        elif cmd == "delete" and len(rest) == 1:
            cmd_delete(rest[0])
        elif cmd == "show" and len(rest) == 1:
            cmd_show(rest[0])
        elif cmd == "key" and len(rest) == 2 and rest[0] in ("set", "clear", "status"):
            cmd_key(rest[0], rest[1])
        elif cmd == "test" and len(rest) in (1, 2):
            cmd_test(*rest)
        elif cmd == "engine" and not rest:
            cmd_engine()
        elif cmd == "hardware" and not rest:
            cmd_hardware()
        elif cmd == "runtime-latest" and not rest:
            cmd_runtime_latest()
        else:
            sys.stderr.write(__doc__)
            return USAGE
        return OK
    except AiError as e:
        error(e)
        return FAILED
    except KeyboardInterrupt:
        return FAILED
