"""HTTP for the providers: one request whose answer is read line by line, which another thread can
cancel at any moment (Stop in the panel), plus SSE parsing and readable errors.

http.client rather than urllib: the socket must be reachable to cancel a read that is blocked waiting
for the next token, and a model can take minutes to load before it answers at all.
"""
import http.client
import json
import socket
import ssl
import threading
import urllib.parse

from .events import AiError

USER_AGENT = "Quasar-AI/1"


class Cancelled(Exception):
    pass


class EngineLost(AiError):
    """The on-device engine took the connection and then dropped it: `ollama serve` died or was stopped
    mid-request. What happened to the engine (providers.lost_engine) says more than this."""


class Stream:
    def __init__(self, method, url, headers=None, body=None, timeout=300, who="the server", local=False):
        self.method = method
        self.url = url
        self.headers = dict(headers or {})
        self.body = body
        self.timeout = timeout
        self.who = who                # "Anthropic", "Ollama on this PC", … for messages
        self.local = local
        self.conn = None
        self.sock = None              # kept: http.client drops conn.sock once the response owns it
        self.resp = None
        self.cancelled = False
        self._lock = threading.Lock()

    # ---- request -----------------------------------------------------------------------------------
    def open(self):
        u = urllib.parse.urlsplit(self.url)
        path = (u.path or "/") + ("?" + u.query if u.query else "")
        with self._lock:
            if self.cancelled:
                raise Cancelled()
            if u.scheme == "https":
                self.conn = http.client.HTTPSConnection(u.hostname, u.port or 443, timeout=self.timeout,
                                                        context=ssl.create_default_context())
            else:
                self.conn = http.client.HTTPConnection(u.hostname, u.port or 80, timeout=self.timeout)
        data = None
        headers = {"User-Agent": USER_AGENT, "Accept": "*/*"}
        headers.update(self.headers)
        if self.body is not None:
            data = json.dumps(self.body).encode()
            headers["Content-Type"] = "application/json"
        try:
            self.conn.connect()
            with self._lock:
                self.sock = self.conn.sock
                if self.cancelled:
                    raise Cancelled()
            self.conn.request(self.method, path, body=data, headers=headers)
            self.resp = self.conn.getresponse()
        except Cancelled:
            raise
        except Exception as e:  # noqa: BLE001  (socket, TLS and protocol errors all mean "can't reach")
            self._raise_transport(e)
        if self.resp.status >= 400:
            raw = b""
            try:
                raw = self.resp.read(65536)
            except Exception:  # noqa: BLE001
                pass
            raise http_error(self.resp.status, raw, self.who, self.local, self.resp.getheader("retry-after"))
        return self

    def _raise_transport(self, e):
        if self.cancelled:
            raise Cancelled()
        if isinstance(e, ConnectionRefusedError) and self.local:
            raise AiError("The on-device AI engine isn't running. Install it or start it in Settings › Quasar AI.",
                          code="engine", action="settings")
        if isinstance(e, ssl.SSLError):
            raise AiError("Couldn't make a secure connection to %s." % self.who, code="network", action="retry",
                          details=str(e))
        if isinstance(e, (socket.timeout, TimeoutError)):
            raise AiError("%s took too long to answer." % self.who.capitalize(), code="network", action="retry")
        if self.local:
            raise EngineLost("The on-device AI engine stopped answering. Try again.", code="engine", action="retry",
                             details="%s: %s" % (type(e).__name__, e))
        raise AiError("Can't reach %s. Check the internet connection." % self.who, code="network", action="retry",
                      details=str(e))

    # ---- reading -----------------------------------------------------------------------------------
    def lines(self):
        """Decoded lines without their line ending, until the answer ends."""
        while True:
            if self.cancelled:
                raise Cancelled()
            try:
                raw = self.resp.readline(1 << 20)
            except Exception as e:  # noqa: BLE001
                if self.cancelled:
                    raise Cancelled()
                self._raise_transport(e)
            if not raw:
                if self.cancelled:
                    raise Cancelled()
                return
            yield raw.decode("utf-8", errors="replace").rstrip("\r\n")

    def json(self):
        try:
            data = self.resp.read()
        except Exception as e:  # noqa: BLE001
            self._raise_transport(e)
        finally:
            self.close()
        try:
            return json.loads(data or b"null")
        except ValueError:
            raise AiError("%s sent an answer Quasar couldn't read." % self.who.capitalize(), code="failed",
                          details=data[:500].decode(errors="replace"))

    def cancel(self):
        """Safe from any thread: wakes a blocked read, which then raises Cancelled."""
        with self._lock:
            self.cancelled = True
            sock = self.sock
        if sock is not None:
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass

    def close(self):
        if self.conn is not None:
            try:
                self.conn.close()
            except Exception:  # noqa: BLE001
                pass


def sse(lines):
    """(event, data) pairs from a text/event-stream."""
    event, data = None, []
    for line in lines:
        if line == "":
            if data:
                yield event, "\n".join(data)
            event, data = None, []
        elif line.startswith(":"):
            continue
        elif line.startswith("event:"):
            event = line[6:].strip()
        elif line.startswith("data:"):
            value = line[5:]
            data.append(value[1:] if value.startswith(" ") else value)
    if data:
        yield event, "\n".join(data)


def api_message(raw):
    """The provider's own error text from an error body (Anthropic, OpenAI and Ollama shapes)."""
    try:
        obj = json.loads(raw) if isinstance(raw, (bytes, str)) else raw
    except ValueError:
        return (raw.decode(errors="replace") if isinstance(raw, bytes) else str(raw)).strip()[:300]
    if isinstance(obj, dict):
        err = obj.get("error")
        if isinstance(err, dict):
            return str(err.get("message") or err.get("type") or "").strip()
        if isinstance(err, str):
            return err.strip()
        if obj.get("message"):
            return str(obj["message"]).strip()
    return ""


def http_error(status, raw, who, local=False, retry_after=None):
    msg = api_message(raw)
    low = msg.lower()
    if status in (401, 403):
        if local:
            return AiError("The on-device engine refused the request.", code="engine", details=msg)
        return AiError("%s didn't accept the API key. Check it in Settings › Quasar AI." % who, code="auth",
                       action="settings", details=msg)
    if status == 404:
        if "model" in low or local:
            return AiError("That model isn't available%s. Choose another in Settings › Quasar AI."
                           % (" on this PC" if local else " from " + who), code="model", action="settings",
                           details=msg)
        return AiError("%s doesn't offer that (%s)." % (who, msg or "not found"), code="failed", details=msg)
    if status == 429:
        if "credit" in low or "quota" in low or "billing" in low or "balance" in low:
            return AiError("Your %s account is out of credit or over its limit." % who, code="rate", details=msg)
        wait = " in %s seconds" % retry_after if retry_after and retry_after.isdigit() else " in a moment"
        return AiError("%s is limiting requests right now. Try again%s." % (who, wait), code="rate",
                       action="retry", details=msg)
    if status in (500, 502, 503, 504, 529) or "overloaded" in low:
        return AiError("%s is busy right now. Try again in a moment." % who, code="busy", action="retry",
                       details=msg)
    if status == 400 and ("credit" in low or "billing" in low):
        return AiError("Your %s account is out of credit." % who, code="rate", details=msg)
    return AiError("%s refused the request%s" % (who, ": " + msg if msg else "."), code="failed", details=msg)
