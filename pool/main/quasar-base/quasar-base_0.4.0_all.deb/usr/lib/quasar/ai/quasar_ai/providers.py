"""The model providers, behind one small interface.

Messages are kept in one internal shape and converted per provider:
  {"role": "user", "content": TEXT}
  {"role": "assistant", "content": TEXT, "calls": [{"id", "name", "args": {...}}]}
  {"role": "tool", "id": CALL_ID, "name": TOOL, "content": TEXT, "error": bool}
Tools: [{"name", "description", "parameters": JSON schema}].

  Ollama      /api/chat, NDJSON. Local (127.0.0.1:11434, no key) and ollama.com (Bearer key) alike.
  Anthropic   /v1/messages, SSE.
  OpenAI      /v1/chat/completions, SSE.
"""
import json
import re

from . import config
from .events import AiError
from .net import EngineLost, Stream, sse

ANTHROPIC_VERSION = "2023-06-01"
MAX_TOKENS = 4096


class Turn:
    def __init__(self):
        self.text = ""
        self.calls = []          # [{"id", "name", "args"}]
        self.stop = ""

    def message(self):
        return {"role": "assistant", "content": self.text, "calls": self.calls}


def _args(value):
    """Tool arguments arrive as an object or as JSON text, depending on the model."""
    if isinstance(value, dict):
        return value
    if isinstance(value, str) and value.strip():
        try:
            v = json.loads(value)
            return v if isinstance(v, dict) else {"value": v}
        except ValueError:
            return {"_invalid": value[:500]}
    return {}


class Provider:
    pid = ""

    def __init__(self, pid, key="", model=""):
        self.pid = pid
        self.info = config.provider(pid)
        self.key = key
        self.model = model or self.info.get("default", "")
        self.base = config.base_url(pid).rstrip("/")
        self.local = pid == "ollama"
        self.who = "Ollama on this PC" if self.local else self.info["company"]

    def stream(self, method, path, body=None, timeout=300):
        return Stream(method, self.base + path, self.headers(), body, timeout=timeout, who=self.who,
                      local=self.local)

    def headers(self):
        return {}

    def need_model(self):
        if not self.model:
            raise AiError("Choose a model for %s in Settings › Quasar AI." % self.info["label"], code="model",
                          action="settings")

    def chat(self, system, messages, tools, on_text, on_stream):
        raise NotImplementedError

    def models(self):
        raise NotImplementedError


# ------------------------------------------------------------------------------------------- Ollama
class Ollama(Provider):
    def headers(self):
        return {"Authorization": "Bearer " + self.key} if self.key else {}

    def convert(self, system, messages):
        out = [{"role": "system", "content": system}] if system else []
        for m in messages:
            if m["role"] == "assistant":
                o = {"role": "assistant", "content": m.get("content") or ""}
                if m.get("calls"):
                    o["tool_calls"] = [{"function": {"name": c["name"], "arguments": c["args"]}} for c in m["calls"]]
                out.append(o)
            elif m["role"] == "tool":
                out.append({"role": "tool", "content": m["content"], "tool_name": m["name"]})
            else:
                out.append({"role": "user", "content": m["content"]})
        return out

    def chat(self, system, messages, tools, on_text, on_stream):
        self.need_model()
        body = {"model": self.model, "messages": self.convert(system, messages), "stream": True}
        if tools:
            body["tools"] = [{"type": "function", "function": t} for t in tools]
        ctx = config.context_size(self.pid)
        if ctx:
            body["options"] = {"num_ctx": ctx}
        s = self.stream("POST", "/api/chat", body)
        on_stream(s)
        ooms = config.oom_kills() if self.local else None
        try:
            s.open()
        except EngineLost as e:
            raise lost_engine(self, e, ooms)
        except AiError as e:
            if e.code in ("failed", "busy") and self.local and oom_since(ooms):
                raise memory_error(self, e.details)   # the kernel killed the model runner while it loaded
            if e.code in ("failed", "model") and e.details:
                raise ollama_error(e.details, self)    # Ollama's own words say more ("does not support tools")
            if e.code == "busy" and self.local and e.details:
                raise ollama_error(e.details, self, fallback=e)   # a 500 while loading: out of memory, a crash
            raise
        turn, n = Turn(), 0
        try:
            for line in s.lines():
                if not line.strip():
                    continue
                try:
                    obj = json.loads(line)
                except ValueError:
                    continue
                if obj.get("error"):
                    if self.local and oom_since(ooms):
                        raise memory_error(self, obj["error"])
                    raise ollama_error(obj["error"], self)
                msg = obj.get("message") or {}
                if msg.get("content"):
                    turn.text += msg["content"]
                    on_text(msg["content"])
                for tc in msg.get("tool_calls") or []:
                    fn = tc.get("function") or {}
                    n += 1
                    turn.calls.append({"id": tc.get("id") or "c%d" % n, "name": fn.get("name") or "",
                                       "args": _args(fn.get("arguments"))})
                if obj.get("done"):
                    turn.stop = obj.get("done_reason") or "stop"
                    break
            else:
                # Ollama always ends with "done"; a stream that just stops was cut off.
                if self.local:
                    raise EngineLost("The on-device AI engine stopped answering. Try again.", code="engine",
                                     action="retry", details="the answer ended before Ollama said it was done")
                raise AiError("%s stopped answering mid-reply. Try again." % self.who, code="network", action="retry")
        except EngineLost as e:
            raise lost_engine(self, e, ooms)
        finally:
            s.close()
        return turn

    def models(self):
        data = self.stream("GET", "/api/tags", timeout=30).open().json() or {}
        out = []
        for m in data.get("models") or []:
            d = m.get("details") or {}
            out.append({"id": m.get("name") or m.get("model"), "name": m.get("name") or m.get("model"),
                        "size": m.get("size") or 0, "params": d.get("parameter_size") or "",
                        "quant": d.get("quantization_level") or "", "family": d.get("family") or ""})
        return out

    def show(self, name):
        return self.stream("POST", "/api/show", {"model": name}, timeout=30).open().json() or {}


def memory_error(prov, details):
    return AiError("This PC doesn't have enough free memory for %s. Close some apps or pick a smaller model."
                   % prov.model, code="model", action="settings", details=details)


def oom_since(before):
    """Did the kernel's OOM killer kill anything since `before` (config.oom_kills())?"""
    now = config.oom_kills()
    return before is not None and now is not None and now > before


def lost_engine(prov, e, ooms=None):
    """The engine dropped a request: say why, from the kernel's OOM count and the engine unit's state."""
    if not config.engine_installed():
        return AiError("The on-device AI engine isn't installed. Install it in Settings › Quasar AI.", code="engine",
                       action="settings", details=e.details)
    st = config.engine_failure()
    details = "%s; engine: %s" % (e.details, " ".join("%s=%s" % kv for kv in sorted(st.items())) or "state unknown")
    result = st.get("Result", "")
    if oom_since(ooms):
        return memory_error(prov, details + "; the kernel's OOM killer ran during the request")
    if result == "oom-kill":
        return memory_error(prov, details)
    if result == "timeout":
        return AiError("The on-device AI engine took too long to start. Try again.", code="engine", action="retry",
                       details=details)
    if result in ("signal", "core-dump", "exit-code", "watchdog"):
        return AiError("The on-device AI engine stopped unexpectedly. Try again.", code="engine", action="retry",
                       details=details)
    return EngineLost(e.message, code=e.code, action=e.action, details=details)


def ollama_error(text, prov, fallback=None):
    """Ollama's own error text as a message. `fallback` is kept when the text says nothing more."""
    low = str(text).lower()
    if "not found" in low and "model" in low:
        if prov.local:
            return AiError("The model %s isn't on this PC. Download it in Settings › Quasar AI." % prov.model,
                           code="model", action="settings", details=text)
        return AiError("Ollama Cloud doesn't have the model %s." % prov.model, code="model", action="settings",
                       details=text)
    if "does not support tools" in low:
        return AiError("%s can chat but can't act on this PC. Choose a model with tool support in Settings."
                       % prov.model, code="model", action="settings", details=text)
    if "unauthorized" in low or "api key" in low:
        return AiError("Ollama didn't accept the API key. Check it in Settings › Quasar AI.", code="auth",
                       action="settings", details=text)
    # "model requires more system memory (…) than is available (…)", "…: signal: killed" (the kernel's OOM
    # killer took the runner), CUDA/Vulkan allocation failures.
    if "memory" in low or "cuda" in low or "out of" in low or "signal: killed" in low:
        return memory_error(prov, text)
    # "llama runner process has terminated: …" (older), "llama-server process has terminated: …" (0.40)
    if "process has terminated" in low or "process no longer running" in low:
        return AiError("%s stopped while it was starting. Try again, or pick another model in Settings › Quasar AI."
                       % prov.model, code="model", action="settings", details=text)
    if fallback is not None:
        return fallback
    return AiError("The model stopped with an error.", code="failed", details=str(text))


# ---------------------------------------------------------------------------------------- Anthropic
class Anthropic(Provider):
    def headers(self):
        return {"x-api-key": self.key, "anthropic-version": ANTHROPIC_VERSION}

    @staticmethod
    def convert(messages):
        out = []

        def add(role, blocks):
            if out and out[-1]["role"] == role:
                out[-1]["content"].extend(blocks)
            else:
                out.append({"role": role, "content": list(blocks)})

        for m in messages:
            if m["role"] == "assistant":
                blocks = [{"type": "text", "text": m["content"]}] if (m.get("content") or "").strip() else []
                blocks += [{"type": "tool_use", "id": c["id"], "name": c["name"], "input": c["args"]}
                           for c in m.get("calls") or []]
                if blocks:
                    add("assistant", blocks)
            elif m["role"] == "tool":
                b = {"type": "tool_result", "tool_use_id": m["id"], "content": m["content"]}
                if m.get("error"):
                    b["is_error"] = True
                add("user", [b])
            else:
                add("user", [{"type": "text", "text": m["content"]}])
        return out

    def chat(self, system, messages, tools, on_text, on_stream):
        self.need_model()
        body = {"model": self.model, "max_tokens": MAX_TOKENS, "stream": True,
                "messages": self.convert(messages)}
        if system:
            # The system prompt and tools are sent on every turn: cache them.
            body["system"] = [{"type": "text", "text": system, "cache_control": {"type": "ephemeral"}}]
        if tools:
            body["tools"] = [{"name": t["name"], "description": t["description"], "input_schema": t["parameters"]}
                             for t in tools]
            body["tools"][-1]["cache_control"] = {"type": "ephemeral"}
        s = self.stream("POST", "/v1/messages", body)
        on_stream(s)
        s.open()
        turn, blocks = Turn(), {}
        try:
            for event, data in sse(s.lines()):
                try:
                    obj = json.loads(data)
                except ValueError:
                    continue
                kind = obj.get("type") or event
                if kind == "content_block_start":
                    cb = obj.get("content_block") or {}
                    blocks[obj.get("index", 0)] = {"type": cb.get("type"), "id": cb.get("id"),
                                                   "name": cb.get("name"), "json": ""}
                elif kind == "content_block_delta":
                    d = obj.get("delta") or {}
                    if d.get("type") == "text_delta" and d.get("text"):
                        turn.text += d["text"]
                        on_text(d["text"])
                    elif d.get("type") == "input_json_delta":
                        b = blocks.setdefault(obj.get("index", 0), {"type": "tool_use", "json": ""})
                        b["json"] += d.get("partial_json") or ""
                elif kind == "message_delta":
                    turn.stop = (obj.get("delta") or {}).get("stop_reason") or turn.stop
                elif kind == "error":
                    err = obj.get("error") or {}
                    status = 529 if err.get("type") == "overloaded_error" else 429 if err.get("type") == "rate_limit_error" else 500
                    from .net import http_error
                    raise http_error(status, json.dumps(obj).encode(), self.who)
                elif kind == "message_stop":
                    break
        finally:
            s.close()
        for i in sorted(blocks):
            b = blocks[i]
            if b.get("type") == "tool_use":
                turn.calls.append({"id": b.get("id") or "t%d" % i, "name": b.get("name") or "",
                                   "args": _args(b.get("json") or "{}")})
        return turn

    def models(self):
        data = self.stream("GET", "/v1/models?limit=100", timeout=30).open().json() or {}
        return [{"id": m["id"], "name": m.get("display_name") or m["id"]} for m in data.get("data") or [] if m.get("id")]


# ------------------------------------------------------------------------------------------- OpenAI
CHAT_MODEL = re.compile(r"^(gpt-|o\d|chatgpt-)")
NOT_CHAT = re.compile(r"(audio|realtime|transcribe|tts|image|embedding|search|moderation|instruct|davinci|babbage|dall-e|whisper|sora)")


class OpenAI(Provider):
    def headers(self):
        return {"Authorization": "Bearer " + self.key}

    @staticmethod
    def convert(system, messages):
        out = [{"role": "system", "content": system}] if system else []
        for m in messages:
            if m["role"] == "assistant":
                o = {"role": "assistant", "content": m.get("content") or None}
                if m.get("calls"):
                    o["tool_calls"] = [{"id": c["id"], "type": "function",
                                        "function": {"name": c["name"], "arguments": json.dumps(c["args"])}}
                                       for c in m["calls"]]
                out.append(o)
            elif m["role"] == "tool":
                out.append({"role": "tool", "tool_call_id": m["id"], "content": m["content"]})
            else:
                out.append({"role": "user", "content": m["content"]})
        return out

    def chat(self, system, messages, tools, on_text, on_stream):
        self.need_model()
        body = {"model": self.model, "stream": True, "messages": self.convert(system, messages)}
        if tools:
            body["tools"] = [{"type": "function", "function": t} for t in tools]
        s = self.stream("POST", "/v1/chat/completions", body)
        on_stream(s)
        s.open()
        turn, slots = Turn(), {}
        try:
            for _event, data in sse(s.lines()):
                if data.strip() == "[DONE]":
                    break
                try:
                    obj = json.loads(data)
                except ValueError:
                    continue
                if obj.get("error"):
                    from .net import http_error
                    raise http_error(500, json.dumps(obj).encode(), self.who)
                for ch in obj.get("choices") or []:
                    d = ch.get("delta") or {}
                    if d.get("content"):
                        turn.text += d["content"]
                        on_text(d["content"])
                    for tc in d.get("tool_calls") or []:
                        slot = slots.setdefault(tc.get("index", 0), {"id": "", "name": "", "args": ""})
                        if tc.get("id"):
                            slot["id"] = tc["id"]
                        fn = tc.get("function") or {}
                        if fn.get("name") and not slot["name"]:
                            slot["name"] = fn["name"]
                        if fn.get("arguments"):
                            slot["args"] += fn["arguments"]
                    if ch.get("finish_reason"):
                        turn.stop = ch["finish_reason"]
        finally:
            s.close()
        for i in sorted(slots):
            sl = slots[i]
            turn.calls.append({"id": sl["id"] or "call_%d" % i, "name": sl["name"], "args": _args(sl["args"])})
        return turn

    def models(self):
        data = self.stream("GET", "/v1/models", timeout=30).open().json() or {}
        ms = [m for m in data.get("data") or [] if m.get("id") and CHAT_MODEL.match(m["id"]) and not NOT_CHAT.search(m["id"])]
        ms.sort(key=lambda m: m.get("created") or 0, reverse=True)
        return [{"id": m["id"], "name": m["id"]} for m in ms]


def pick_default(pid, models):
    """A sensible model when the user hasn't chosen one: the newest flagship of the list."""
    ids = [m["id"] for m in models]
    if not ids:
        return ""
    if pid == "anthropic":
        for want in ("claude-sonnet-5-5", "claude-opus-5-5", "claude-haiku-5-5"):
            if want in ids:
                return want
        sonnet = [i for i in ids if "sonnet" in i]
        return sonnet[0] if sonnet else ids[0]
    if pid == "openai":
        def ver(i):
            m = re.match(r"^gpt-(\d+)(?:\.(\d+))?$", i)
            return (int(m.group(1)), int(m.group(2) or 0)) if m else None
        flagships = sorted((v, i) for i in ids if (v := ver(i)))
        return flagships[-1][1] if flagships else ids[0]
    if pid == "ollama-cloud":
        for want in ("gpt-oss:120b", "gpt-oss:20b"):
            if want in ids:
                return want
    return ids[0]


def make(pid, key="", model=""):
    if pid in ("ollama", "ollama-cloud"):
        return Ollama(pid, key, model)
    if pid == "anthropic":
        return Anthropic(pid, key, model)
    if pid == "openai":
        return OpenAI(pid, key, model)
    config.provider(pid)          # raises the "choose a provider" error
