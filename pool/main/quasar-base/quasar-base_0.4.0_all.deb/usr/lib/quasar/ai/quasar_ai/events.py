"""JSON lines on stdout (one object per line, flushed), shared by every quasar-ai mode, plus the error
type the UI shows.

Every line has a "type". The shell (shell/services/Assistant.qml) and Settings
(apps/settings/services/AiSetup.qml) parse them; anything on stderr is log text.
"""
import json
import sys
import threading

OK, FAILED, USAGE = 0, 1, 2

_lock = threading.Lock()


class AiError(Exception):
    """A failure the user reads: one plain sentence, a machine code and what the UI can offer.

    code:   auth | key | rate | busy (the provider is overloaded) | network | engine | model | refused | failed
            | inflight (serve only: an ask arrived while the last one still runs; the panel shows nothing)
    action: settings (open Settings › Quasar AI) | retry | "" (nothing to offer)
    details: the provider's or the system's own words, for the panel's Details and the log
    """

    def __init__(self, message, code="failed", action="", details=""):
        super().__init__(message)
        self.message = message
        self.code = code
        self.action = action
        self.details = details or ""

    def fields(self):
        f = {"message": self.message, "code": self.code}
        if self.action:
            f["action"] = self.action
        if self.details:
            f["details"] = self.details[-2000:]
        return f


def emit(kind, **fields):
    rec = {"type": kind}
    rec.update(fields)
    line = json.dumps(rec, ensure_ascii=False, separators=(",", ":")) + "\n"
    with _lock:
        sys.stdout.write(line)
        sys.stdout.flush()


def error(err):
    """To the UI, and to stderr (the shell's journal) with the details the UI keeps out of sight."""
    log("error [%s]: %s%s" % (err.code, err.message, " | " + err.details[-2000:] if err.details else ""))
    emit("error", **err.fields())


def log(msg):
    print("quasar-ai: " + msg, file=sys.stderr, flush=True)
