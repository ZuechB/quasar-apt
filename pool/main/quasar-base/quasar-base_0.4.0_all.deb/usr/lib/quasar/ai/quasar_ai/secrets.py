"""API keys for the cloud providers. They never pass through QML, settings.json or a command line.

Installed system: the login keyring through the Secret Service D-Bus API (gnome-keyring; PAM unlocks it
at login). Items carry {application: quasar-ai, provider: P}.
Live USB, or no keyring: ~/.local/share/quasar/ai/keys.json (folder 0700, file 0600); the live home is
in RAM, so it's gone after a restart anyway.
QUASAR_AI_SECRETS=file|keyring forces one store (tests).
"""
import json
import os

from . import config
from .events import AiError, log

APP = "quasar-ai"
SS_NAME = "org.freedesktop.secrets"
SS_PATH = "/org/freedesktop/secrets"
SS_IFACE = "org.freedesktop.Secret.Service"
LOGIN = "/org/freedesktop/secrets/collection/login"


# ------------------------------------------------------------------------------------------- file
class FileStore:
    kind = "file"

    def __init__(self, folder=None):
        self.folder = folder or config.data_dir()
        self.path = os.path.join(self.folder, "keys.json")

    def _load(self):
        try:
            with open(self.path, encoding="utf-8") as f:
                data = json.load(f)
            return data if isinstance(data, dict) else {}
        except (OSError, ValueError):
            return {}

    def get(self, pid):
        v = self._load().get(pid)
        return v if isinstance(v, str) else ""

    def set(self, pid, key):
        os.makedirs(self.folder, mode=0o700, exist_ok=True)
        os.chmod(self.folder, 0o700)
        data = self._load()
        data[pid] = key
        tmp = self.path + ".tmp"
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(tmp, self.path)

    def clear(self, pid):
        data = self._load()
        if pid in data:
            del data[pid]
            if data:
                self.set_all(data)
            else:
                try:
                    os.unlink(self.path)
                except FileNotFoundError:
                    pass

    def set_all(self, data):
        fd = os.open(self.path + ".tmp", os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(self.path + ".tmp", self.path)


# ---------------------------------------------------------------------------------- Secret Service
class KeyringStore:
    kind = "keyring"

    def __init__(self, bus=None):
        from jeepney import DBusAddress
        from jeepney.io.blocking import open_dbus_connection
        self._addr = DBusAddress
        self.conn = open_dbus_connection(bus=bus or os.environ.get("QUASAR_AI_SECRETS_BUS", "SESSION"))
        self.service = DBusAddress(SS_PATH, bus_name=SS_NAME, interface=SS_IFACE)
        self.session = self.call(self.service, "OpenSession", "sv", ("plain", ("s", "")))[1]

    def close(self):
        try:
            self.conn.close()
        except Exception:  # noqa: BLE001
            pass

    def call(self, addr, method, sig="", body=(), timeout=15):
        from jeepney import new_method_call
        from jeepney.wrappers import unwrap_msg
        return unwrap_msg(self.conn.send_and_get_reply(new_method_call(addr, method, sig, body), timeout=timeout))

    def obj(self, path, iface):
        return self._addr(path, bus_name=SS_NAME, interface=iface)

    def prompt(self, path):
        """Show the keyring's own prompt (unlock / confirm) and wait for the answer."""
        if path == "/":
            return None
        from jeepney import MatchRule, message_bus
        from jeepney.wrappers import unwrap_msg
        rule = MatchRule(type="signal", interface="org.freedesktop.Secret.Prompt", member="Completed", path=path)
        unwrap_msg(self.conn.send_and_get_reply(message_bus.AddMatch(rule)))
        with self.conn.filter(rule) as q:
            self.call(self.obj(path, "org.freedesktop.Secret.Prompt"), "Prompt", "s", ("",))
            msg = self.conn.recv_until_filtered(q, timeout=180)
        dismissed, result = msg.body
        if dismissed:
            raise AiError("The keyring stayed locked, so the key wasn't saved or read.", code="key")
        return result

    def unlock(self, paths):
        if not paths:
            return []
        unlocked, prompt = self.call(self.service, "Unlock", "ao", (list(paths),))
        if prompt != "/":
            res = self.prompt(prompt)
            unlocked = list(res[1]) if res else []
        return unlocked

    def collection(self):
        path = self.call(self.service, "ReadAlias", "s", ("default",))[0]
        return path if path and path != "/" else LOGIN

    def find(self, pid):
        unlocked, locked = self.call(self.service, "SearchItems", "a{ss}", ({"application": APP, "provider": pid},))
        return list(unlocked), list(locked)

    def get(self, pid):
        unlocked, locked = self.find(pid)
        items = unlocked or self.unlock(locked)
        if not items:
            return ""
        secrets = self.call(self.service, "GetSecrets", "aoo", (items[:1], self.session))[0]
        for _path, (_session, _params, value, _ctype) in secrets.items():
            return bytes(value).decode("utf-8", errors="replace")
        return ""

    def set(self, pid, key):
        coll = self.collection()
        self.unlock([coll])
        props = {
            "org.freedesktop.Secret.Item.Label": ("s", "Quasar AI: %s API key" % config.PROVIDERS[pid]["name"]),
            "org.freedesktop.Secret.Item.Attributes": ("a{ss}", {"application": APP, "provider": pid}),
        }
        secret = (self.session, b"", key.encode("utf-8"), "text/plain")
        _item, prompt = self.call(self.obj(coll, "org.freedesktop.Secret.Collection"), "CreateItem",
                                  "a{sv}(oayays)b", (props, secret, True))
        self.prompt(prompt)

    def clear(self, pid):
        unlocked, locked = self.find(pid)
        for path in unlocked + locked:
            prompt = self.call(self.obj(path, "org.freedesktop.Secret.Item"), "Delete")[0]
            self.prompt(prompt)


# ------------------------------------------------------------------------------------------ facade
def _keyring():
    try:
        return KeyringStore()
    except Exception as e:  # noqa: BLE001  (no jeepney, no session bus, no keyring service)
        log("keyring unavailable: %s" % e)
        return None


class Keys:
    """The key store for this account. Reads try the keyring, then the file (a key saved while the
    keyring was unavailable still works)."""

    def __init__(self):
        mode = os.environ.get("QUASAR_AI_SECRETS", "auto")
        self.file = FileStore()
        self.keyring = None
        if mode == "keyring" or (mode == "auto" and not config.is_live()):
            self.keyring = _keyring()
        if mode == "file":
            self.keyring = None
        self.cache = {}

    @property
    def primary(self):
        return self.keyring or self.file

    def get(self, pid):
        if pid in self.cache:
            return self.cache[pid]
        key = ""
        if self.keyring:
            try:
                key = self.keyring.get(pid)
            except AiError:
                raise
            except Exception as e:  # noqa: BLE001
                log("keyring read failed: %s" % e)
        key = key or self.file.get(pid)
        if key:
            self.cache[pid] = key
        return key

    def where(self, pid):
        if self.keyring:
            try:
                if self.keyring.find(pid) != ([], []):
                    return "keyring"
            except Exception:  # noqa: BLE001
                pass
        return "file" if self.file.get(pid) else ""

    def set(self, pid, key):
        key = key.strip()
        if not key or len(key) > 4096 or any(c.isspace() for c in key):
            raise AiError("That doesn't look like an API key.", code="key")
        self.cache.pop(pid, None)
        if self.keyring:
            try:
                self.keyring.set(pid, key)
                self.file.clear(pid)
                return "keyring"
            except AiError:
                raise
            except Exception as e:  # noqa: BLE001
                log("keyring write failed, using the file: %s" % e)
        self.file.set(pid, key)
        return "file"

    def clear(self, pid):
        self.cache.pop(pid, None)
        if self.keyring:
            try:
                self.keyring.clear(pid)
            except Exception as e:  # noqa: BLE001
                log("keyring delete failed: %s" % e)
        self.file.clear(pid)

    def status(self, pid):
        key = self.get(pid)
        return {"provider": pid, "set": bool(key), "hint": ("…" + key[-4:]) if len(key) >= 8 else "",
                "store": self.where(pid) if key else ""}

    def forget_cache(self, pid=None):
        if pid:
            self.cache.pop(pid, None)
        else:
            self.cache.clear()
