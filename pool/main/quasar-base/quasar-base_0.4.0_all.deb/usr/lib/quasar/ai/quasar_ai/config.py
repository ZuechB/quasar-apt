"""Providers, paths and what this PC has. Environment overrides exist for tests only."""
import json
import os
import subprocess
import time

# label: what Settings and the panel call it; company: who receives the requests (cloud only).
PROVIDERS = {
    "ollama": {
        "label": "This PC", "name": "Ollama", "cloud": False, "needsKey": False,
        "base": "http://127.0.0.1:11434",
    },
    "ollama-cloud": {
        "label": "Ollama Cloud", "name": "Ollama Cloud", "cloud": True, "needsKey": True, "company": "Ollama",
        "base": "https://ollama.com", "keyUrl": "https://ollama.com/settings/keys",
    },
    "anthropic": {
        "label": "Claude", "name": "Claude", "cloud": True, "needsKey": True, "company": "Anthropic",
        "base": "https://api.anthropic.com", "keyUrl": "https://console.anthropic.com/settings/keys",
        "default": "claude-sonnet-5-5",
    },
    "openai": {
        "label": "ChatGPT", "name": "ChatGPT", "cloud": True, "needsKey": True, "company": "OpenAI",
        "base": "https://api.openai.com", "keyUrl": "https://platform.openai.com/api-keys",
    },
}

ENGINE_DIR = os.environ.get("QUASAR_AI_ENGINE_DIR", "/opt/ollama")
HARDWARE_JSON = os.environ.get("QUASAR_HARDWARE_JSON", "/run/quasar/hardware.json")
STORE_CATALOG = os.environ.get("QUASAR_STORE_CATALOG", "/usr/share/quasar/store/catalog.json")
FILEOP = os.environ.get("QUASAR_FILEOP", "/usr/libexec/quasar/fileop")
SYSTEMCTL = os.environ.get("QUASAR_AI_SYSTEMCTL", "systemctl")
GITHUB_LATEST = "https://api.github.com/repos/ollama/ollama/releases/latest"


def provider(pid):
    from .events import AiError
    if pid not in PROVIDERS:
        raise AiError("Choose where Quasar AI runs in Settings.", code="key", action="settings")
    return PROVIDERS[pid]


ENGINE_UNIT = "quasar-ollama.service"
VMSTAT = os.environ.get("QUASAR_AI_VMSTAT", "/proc/vmstat")


def oom_kills():
    """How many processes the kernel's OOM killer has killed since boot (None when it can't say). Compared
    before and after a request: a model too big for the PC gets its runner killed, and what Ollama or
    systemd report afterwards varies (a 500, a panic, a dropped connection)."""
    try:
        with open(VMSTAT, encoding="ascii") as f:
            for line in f:
                if line.startswith("oom_kill "):
                    return int(line.split()[1])
    except (OSError, ValueError, IndexError):
        pass
    return None


def systemctl(*args):
    """systemctl's output ("" when it can't run). Queries only: this runs as the user."""
    try:
        r = subprocess.run([SYSTEMCTL] + list(args), capture_output=True, timeout=5)
        return r.stdout.decode(errors="replace").strip()
    except (OSError, subprocess.SubprocessError):
        return ""


def engine_installed():
    return os.path.isfile(os.path.join(ENGINE_DIR, "bin", "ollama"))


def engine_state():
    """The engine unit's ActiveState, SubState, Result and NRestarts ({} when systemd can't say)."""
    out = {}
    for line in systemctl("show", ENGINE_UNIT, "-p", "ActiveState", "-p", "SubState", "-p", "Result",
                          "-p", "NRestarts").splitlines():
        k, sep, v = line.partition("=")
        if sep:
            out[k] = v
    return out


def engine_failure(wait=2.0):
    """The engine's state right after its connection broke. systemd notices an OOM kill or a crash a moment
    after the socket closes, so a state that still looks fine is asked again for up to `wait` seconds."""
    end = time.monotonic() + wait
    while True:
        st = engine_state()
        if st.get("Result", "success") != "success" or st.get("ActiveState", "active") != "active" \
                or time.monotonic() >= end:
            return st
        time.sleep(0.25)


def base_url(pid):
    """QUASAR_AI_BASE_OLLAMA_CLOUD=http://127.0.0.1:PORT points a provider at a test server."""
    return os.environ.get("QUASAR_AI_BASE_" + pid.upper().replace("-", "_")) or PROVIDERS[pid]["base"]


def home():
    return os.path.realpath(os.path.expanduser("~"))


def data_dir():
    base = os.environ.get("XDG_DATA_HOME") or os.path.join(home(), ".local", "share")
    return os.path.join(base, "quasar", "ai")


def is_live():
    v = os.environ.get("QUASAR_AI_LIVE")
    if v is not None:
        return v == "1"
    return os.path.isdir("/run/live")


def meminfo():
    """{'MemTotal': kB, ...} or {} when /proc isn't there."""
    out = {}
    try:
        with open(os.environ.get("QUASAR_AI_MEMINFO", "/proc/meminfo"), encoding="ascii") as f:
            for line in f:
                k, _, v = line.partition(":")
                parts = v.split()
                if parts and parts[0].isdigit():
                    out[k.strip()] = int(parts[0])
    except OSError:
        pass
    return out


def mem_total_mb():
    return meminfo().get("MemTotal", 0) // 1024


def hardware():
    try:
        with open(HARDWARE_JSON, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def accel(hw=None):
    """('cuda'|'vulkan'|'cpu', gpu name, VRAM MB): what Ollama will run on. NVIDIA needs its own driver
    (CUDA); AMD and Intel use Vulkan through Mesa; a VM's virtual GPU counts as none."""
    hw = hw if hw is not None else hardware()
    best = ("cpu", "", 0)
    for g in hw.get("gpus") or []:
        vendor, driver = g.get("vendor"), g.get("driver") or ""
        vram = int(g.get("vramMB") or 0)
        if vendor == "nvidia" and driver == "nvidia":
            cand = ("cuda", g.get("name") or "NVIDIA", vram)
        elif vendor in ("amd", "intel") or (vendor == "nvidia" and driver == "nouveau"):
            cand = ("vulkan", g.get("name") or vendor, vram)
        else:
            continue
        rank = {"cpu": 0, "vulkan": 1, "cuda": 2}
        if (rank[cand[0]], cand[2]) > (rank[best[0]], best[2]):
            best = cand
    return best


def context_size(pid):
    """Tokens of context to ask Ollama for: its 4096 default can't hold the tool list."""
    if pid != "ollama":
        return 0
    return 8192 if mem_total_mb() and mem_total_mb() <= 8192 else 16384
