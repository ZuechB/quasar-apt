"""`quasar-ai serve`: the assistant's conversation and tool loop, for the shell's panel.

The shell (shell/services/Assistant.qml) starts this the first time the panel is used; it exits after
10 idle minutes or when stdin closes. One JSON object per line each way.

shell -> helper
  {"type": "ask", "text": T, "config": {provider, model, perms: {apps, settings, install, files, commands},
                                         plan: bool, wrap: [argv prefix for commands], company: NAME}}
  {"type": "run"} / {"type": "cancel"}          the held plan: run it / drop it
  {"type": "allow", "id": S} / {"type": "deny", "id": S}   one step that asks (plan off)
  {"type": "result", "id": S, "ok": b, "output": T, "summary": T, "undo": [calls], "changed": b}
                                                 the answer to a "call"
  {"type": "stop"}  {"type": "undo"}  {"type": "reset"}  {"type": "quit"}

helper -> shell
  ready · busy {on} · text {delta} (batched, ~20/s)
  step {id, tool, title, detail, tag, risk, state: staged|asking|running|done|failed|skipped|denied, summary}
  plan {ids}       the staged steps wait for Run / Cancel
  ask {id}         one step waits for Allow / Deny
  call {id, tool, args}   run a shell-side tool and answer with "result"
  line {id, text}  console output of a running step
  done {changed, undoable}   the request is finished
  undone {count, failed}     Undo all finished
  error {message, code, action}
"""
import json
import queue
import sys
import threading
import time

from . import config, localtools, providers, tools
from .events import AiError, emit, error, log
from .net import Cancelled

MAX_ROUNDS = 10
MAX_CALLS = 12
IDLE_SECONDS = 600
TEXT_INTERVAL = 0.05

PERM_LABELS = {"apps": "Open and arrange apps", "settings": "Change settings", "install": "Install apps",
               "files": "Find and manage files", "commands": "Run commands"}


class Stopped(Exception):
    pass


class Step:
    def __init__(self, sid, tool, call, risk, company):
        self.id = sid
        self.tool = tool
        self.call = call
        self.risk = risk
        self.title = tools.title(tool, call["args"])
        self.detail = tools.detail(tool, call["args"], company if tool["name"] == "read_file" else "")

    def emit(self, state, summary=""):
        emit("step", id=self.id, tool=self.tool["name"], title=self.title, detail=self.detail, tag=self.tool["tag"],
             risk=self.risk, state=state, summary=summary)


class Session:
    def __init__(self, keys=None, stdin=None):
        self.q = queue.Queue()
        self._keys = keys
        self.stdin = stdin or sys.stdin
        self.messages = []
        self.undo_log = []
        self.notes = []
        self.cfg = {}
        self.stream = None
        self.stopping = threading.Event()
        self.seq = 0
        self.changed = 0
        self._text = ""
        self._text_at = 0.0

    # ---- plumbing -----------------------------------------------------------------------------------
    @property
    def keys(self):
        if self._keys is None:
            from .secrets import Keys
            self._keys = Keys()
        return self._keys

    def reader(self):
        for line in self.stdin:
            try:
                msg = json.loads(line)
            except ValueError:
                continue
            if not isinstance(msg, dict):
                continue
            if msg.get("type") == "stop":
                self.stopping.set()
                s = self.stream
                if s is not None:
                    s.cancel()
            self.q.put(msg)
        self.stopping.set()
        s = self.stream
        if s is not None:
            s.cancel()
        self.q.put({"type": "quit"})

    def serve(self, idle=IDLE_SECONDS):
        threading.Thread(target=self.reader, daemon=True).start()
        emit("ready")
        while True:
            try:
                msg = self.q.get(timeout=idle)
            except queue.Empty:
                return 0
            t = msg.get("type")
            if t == "quit":
                return 0
            if t == "ask":
                self.ask(msg)
            elif t == "undo":
                self.undo_all()
            elif t == "reset":
                self.reset()

    def wait(self, kinds, sid=None):
        while True:
            if self.stopping.is_set():
                raise Stopped()
            try:
                msg = self.q.get(timeout=0.5)
            except queue.Empty:
                continue
            t = msg.get("type")
            if t in ("stop", "quit", "reset"):
                if t != "stop":
                    self.q.put(msg)          # handled by the main loop once this request has ended
                self.stopping.set()
                raise Stopped()
            if t in kinds and (sid is None or msg.get("id") == sid):
                return msg
            if t == "ask":
                emit("error", message="Quasar is still working on the last request.", code="inflight")

    def text(self, delta):
        self._text += delta
        now = time.monotonic()
        if now - self._text_at >= TEXT_INTERVAL:
            self.flush_text()

    def flush_text(self):
        if self._text:
            emit("text", delta=self._text)
            self._text = ""
        self._text_at = time.monotonic()

    def set_stream(self, s):
        self.stream = s
        if self.stopping.is_set():
            s.cancel()

    # ---- state --------------------------------------------------------------------------------------
    def reset(self):
        self.messages, self.undo_log, self.notes = [], [], []

    def provider(self):
        pid = self.cfg.get("provider") or ""
        info = config.provider(pid)
        key = ""
        if info["needsKey"]:
            self.keys.forget_cache(pid)
            key = self.keys.get(pid)
            if not key:
                raise AiError("Add your %s API key in Settings › Quasar AI." % info["name"], code="key",
                              action="settings")
        return providers.make(pid, key, self.cfg.get("model") or "")

    def system_prompt(self, prov, avail):
        perms = self.cfg.get("perms") or {}
        off = [label for p, label in PERM_LABELS.items() if perms.get(p, True) is False]
        names = {t["name"] for t in avail}
        lines = [
            "You are Quasar, the assistant built into Quasar OS, a privacy-first Linux desktop (Debian 13, Wayland). "
            "You help the user get things done on this PC with the tools you have.",
            "How to work:",
            "- Be brief and use plain words. Answer in the user's language.",
            "- Look things up first (search and list tools run at once). Never guess app ids, window ids or paths.",
            "- Then request ALL the changes the task needs together, in ONE reply with several tool calls. "
            "The user sees them as a plan and approves it once. Before the calls, write one short sentence "
            "saying what you'll do.",
            "- After the steps have run, say in one short sentence what changed. Don't repeat the step list.",
            "- Only do what was asked. If the request is unclear, ask a short question instead of acting.",
            "- Deleting means moving to the Trash. Never touch private key or sign-in folders.",
        ]
        if "run_command" in names:
            lines.append("- Commands run as the user without a terminal: no sudo, nothing interactive, 120 s limit. "
                         "For interactive things, open the Terminal instead.")
        if not avail or names <= {"search_apps", "get_settings", "find_setting", "open_settings", "search_store",
                                  "system_info"}:
            lines.append("- You can't change anything on this PC right now; explain how the user can do it.")
        if off:
            lines.append("- Turned off in Settings › Quasar AI: %s. If a task needs one, tell the user they can turn "
                         "it on there." % ", ".join(off))
        lines += [
            "About Quasar: apps come from the Store (Flathub apps, system packages, developer tools). Settings has "
            "pages for network, Bluetooth, display, sound, appearance, privacy, apps and more. Other built-in apps: "
            "Files, Terminal, Sites (host websites), Containers (Docker), Companies (separate work environments).",
            "Now: %s. Home folder: %s (~)." % (time.strftime("%A %d %B %Y, %H:%M"), config.home()),
        ]
        if self.cfg.get("company"):
            lines.append("The user is in the company environment “%s”: apps open there and commands run there."
                         % self.cfg["company"])
        if not prov.local:
            lines.append("You run in the cloud (%s): only read files when the task needs their contents."
                         % prov.who)
        return "\n".join(lines)

    def trim(self, budget):
        def size(m):
            return len(m.get("content") or "") + sum(len(json.dumps(c.get("args"))) + 40 for c in m.get("calls") or []) + 20
        while sum(size(m) for m in self.messages) > budget:
            nxt = next((i for i, m in enumerate(self.messages) if i > 0 and m["role"] == "user"), None)
            if nxt is None:
                break
            del self.messages[:nxt]

    # ---- one request --------------------------------------------------------------------------------
    def ask(self, msg):
        text = str(msg.get("text") or "").strip()
        if not text:
            return
        if isinstance(msg.get("config"), dict):
            self.cfg = msg["config"]
        self.stopping.clear()
        self.changed = 0
        emit("busy", on=True)
        try:
            prov = self.provider()
            avail = tools.enabled(self.cfg.get("perms"))
            schemas = tools.schemas(avail)
            if self.notes:
                text = "(%s)\n\n%s" % (" ".join(self.notes), text)
                self.notes = []
            self.messages.append({"role": "user", "content": text})
            system = self.system_prompt(prov, avail)
            ctx = config.context_size(prov.pid)
            budget = (ctx * 3 - len(system) - len(json.dumps(schemas))) if ctx else 400000
            for _round in range(MAX_ROUNDS):
                self.trim(max(budget, 4000))
                turn = self.model_turn(prov, system, schemas)
                self.messages.append(turn.message())
                if not turn.calls:
                    break
                if not self.handle_calls(turn.calls, avail, prov):
                    break
            else:
                self.flush_text()
                emit("text", delta="\n\nI stopped after %d rounds of steps. Tell me if I should carry on." % MAX_ROUNDS)
        except Stopped:
            self.flush_text()
        except AiError as e:
            self.flush_text()
            if e.code == "auth":
                self.keys.forget_cache()
            error(e)
        except Exception as e:  # noqa: BLE001
            log("request failed: %r" % e)
            import traceback
            traceback.print_exc(file=sys.stderr)
            error(AiError("Something went wrong in Quasar AI.", details=repr(e)))
        finally:
            self.flush_text()
            self.stream = None
            emit("done", changed=self.changed, undoable=bool(self.undo_log), stopped=self.stopping.is_set())
            emit("busy", on=False)

    def model_turn(self, prov, system, schemas):
        if self.stopping.is_set():
            raise Stopped()
        try:
            turn = prov.chat(system, self.messages, schemas, self.text, self.set_stream)
        except Cancelled:
            raise Stopped()
        finally:
            self.flush_text()
            self.stream = None
        if self.stopping.is_set():
            raise Stopped()
        return turn

    def handle_calls(self, calls, avail, prov):
        """Run what the model asked for. False when the request ends here (cancelled)."""
        allowed = {t["name"] for t in avail}
        results, staged = {}, []
        company = "" if prov.local else prov.who
        try:
            for i, c in enumerate(calls):
                if i >= MAX_CALLS:
                    results[c["id"]] = ("Too many steps at once: ask for the rest after these have run.", True)
                    continue
                t = tools.BY_NAME.get(c.get("name"))
                if not t:
                    results[c["id"]] = ("There's no tool called %s." % c.get("name"), True)
                    continue
                if t["name"] not in allowed:
                    results[c["id"]] = ("Not allowed: the user turned off “%s” in Settings › Quasar AI."
                                        % PERM_LABELS.get(t["perm"], t["perm"]), True)
                    continue
                problem = tools.check_args(t, c["args"])
                if problem:
                    results[c["id"]] = (problem, True)
                    continue
                self.seq += 1
                step = Step("s%d" % self.seq, t, c, tools.risk(t, c["args"], not prov.local), company)
                if step.risk == "read":
                    self.execute(step, results)
                else:
                    staged.append(step)
            if staged and not self.run_staged(staged, results):
                return False
            return True
        except Stopped:
            for s in staged:
                if s.call["id"] not in results:
                    s.emit("skipped")
            for c in calls:
                results.setdefault(c["id"], ("Stopped by the user before this ran.", True))
            raise
        finally:
            for c in calls:
                content, err = results.get(c["id"], ("Stopped by the user before this ran.", True))
                self.messages.append({"role": "tool", "id": c["id"], "name": c.get("name") or "", "content": content,
                                      "error": err})

    def run_staged(self, staged, results):
        if self.cfg.get("plan", True):
            for s in staged:
                s.emit("staged")
            emit("plan", ids=[s.id for s in staged])
            if self.wait({"run", "cancel"})["type"] == "cancel":
                for s in staged:
                    s.emit("skipped")
                    results[s.call["id"]] = ("The user cancelled the plan.", True)
                return False
            for n, s in enumerate(staged):
                if not self.execute(s, results):
                    for rest in staged[n + 1:]:
                        rest.emit("skipped")
                        results[rest.call["id"]] = ("Skipped because an earlier step failed.", True)
                    break
            return True
        for n, s in enumerate(staged):
            if s.risk == "ask":
                s.emit("asking")
                emit("ask", id=s.id)
                if self.wait({"allow", "deny"}, s.id)["type"] == "deny":
                    s.emit("denied")
                    results[s.call["id"]] = ("The user said no to this step.", True)
                    continue
            if not self.execute(s, results):
                for rest in staged[n + 1:]:
                    rest.emit("skipped")
                    results[rest.call["id"]] = ("Skipped because an earlier step failed.", True)
                break
        return True

    def execute(self, step, results):
        name, args = step.tool["name"], step.call["args"]
        if self.stopping.is_set():
            raise Stopped()
        step.emit("running")
        try:
            if step.tool["side"] == "shell":
                res = self.shell_call(step.id, name, args)
            elif name == "run_command":
                res = localtools.run_command(args, wrap=self.cfg.get("wrap") or None,
                                             on_line=lambda line: emit("line", id=step.id, text=line[:500]),
                                             cancelled=self.stopping.is_set)
            else:
                res = localtools.HANDLERS[name](args)
        except Stopped:
            step.emit("skipped")
            raise
        except localtools.ToolError as e:
            res = localtools.Result(str(e), ok=False)
        except Exception as e:  # noqa: BLE001
            log("%s failed: %r" % (name, e))
            res = localtools.Result("It failed: %s" % e, ok=False)
        step.emit("done" if res.ok else "failed", res.summary if res.ok else _first_line(res.output))
        if res.undo:
            self.undo_log.append({"id": step.id, "title": step.title, "calls": res.undo})
        if res.changed and step.tool.get("change", True):
            self.changed += 1
        results[step.call["id"]] = (res.output, not res.ok)
        if name == "run_command" and self.stopping.is_set():
            raise Stopped()
        return res.ok

    def shell_call(self, sid, name, args):
        emit("call", id=sid, tool=name, args=args)
        msg = self.wait({"result"}, sid)
        undo = msg.get("undo") or []
        return localtools.Result(str(msg.get("output") or ""), summary=str(msg.get("summary") or ""),
                                 undo=undo if isinstance(undo, list) else [], changed=bool(msg.get("changed")),
                                 ok=msg.get("ok", True) is not False)

    # ---- Undo all -----------------------------------------------------------------------------------
    def undo_all(self):
        if not self.undo_log:
            emit("undone", count=0, failed=[])
            return
        self.stopping.clear()
        emit("busy", on=True)
        failed, count, n = [], 0, 0
        try:
            for entry in reversed(self.undo_log):
                ok = True
                for call in entry["calls"]:
                    name = call.get("tool")
                    try:
                        if name in localtools.HANDLERS:
                            localtools.HANDLERS[name](call.get("args") or {})
                        else:
                            n += 1
                            res = self.shell_call("u%d" % n, name, call.get("args") or {})
                            if not res.ok:
                                raise localtools.ToolError(res.output or "it didn't work")
                    except localtools.ToolError as e:
                        ok = False
                        failed.append("%s: %s" % (entry["title"], e))
                    except Stopped:
                        raise
                    except Exception as e:  # noqa: BLE001
                        ok = False
                        failed.append("%s: %s" % (entry["title"], e))
                count += ok
        except Stopped:
            failed.append("Undo was stopped before it finished.")
        finally:
            self.undo_log = []
            note = "The user pressed Undo all, so the changes from the last request were reverted"
            self.notes.append(note + (" except: " + "; ".join(failed) + "." if failed else "."))
            emit("undone", count=count, failed=failed)
            emit("busy", on=False)


def _first_line(text):
    text = (text or "").strip()
    return text.splitlines()[0][:200] if text else ""
