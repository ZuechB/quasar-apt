"""Files a phone sends to this PC (over /ws/files, sealed): written into a hidden folder inside Downloads,
then moved in with fileop (which picks "name (2).ext" when the name is taken). A cancelled or broken
upload leaves nothing.
"""
import asyncio
import json
import os
import shutil
import tempfile
import unicodedata

from . import paths

MAX_BYTES = 8 << 30          # 8 GiB per file
ACK_EVERY = 512 << 10        # the phone keeps at most 2 MiB unacknowledged
KEEP_FREE = 256 << 20        # never fill the disk to the last byte


class UploadError(Exception):
    def __init__(self, message, code, status=400):
        super().__init__(message)
        self.code = code
        self.status = status


def safe_name(name):
    """A plain file name: no folders, no control characters, not hidden, not empty."""
    name = unicodedata.normalize("NFC", str(name or ""))
    name = name.replace("\\", "/").split("/")[-1]
    name = "".join(ch for ch in name if ch.isprintable()).strip().lstrip(".").strip()
    if len(name.encode("utf-8")) > 200:
        stem, dot, ext = name.rpartition(".")
        if dot and 0 < len(ext) <= 10:
            name = stem.encode("utf-8")[:180].decode("utf-8", "ignore") + "." + ext
        else:
            name = name.encode("utf-8")[:200].decode("utf-8", "ignore")
    return name or "Shared file"


class Upload:
    """One file on its way in: Upload(name, size), write() the bytes, then finish() (or abort())."""

    def __init__(self, name, size, dest=None):
        if isinstance(size, bool) or not isinstance(size, int) or size < 0:
            raise UploadError("The phone didn't say how big the file is.", "bad")
        if size > MAX_BYTES:
            raise UploadError("That file is too big to send (8 GB at most).", "too-big")
        self.dest = dest or paths.downloads_dir()
        os.makedirs(self.dest, exist_ok=True)
        st = os.statvfs(self.dest)
        if st.f_bavail * st.f_frsize < size + KEEP_FREE:
            raise UploadError("There isn't enough free space on this PC.", "no-space")
        self.name = safe_name(name)
        self.size = size
        self.done = 0
        self.tmpdir = tempfile.mkdtemp(prefix=".deck-upload-", dir=self.dest)
        self.part = os.path.join(self.tmpdir, self.name)
        self.fh = open(self.part, "wb")

    def write(self, data):
        if self.done + len(data) > self.size:
            self.abort()
            raise UploadError("The phone sent more than it said it would.", "bad")
        self.fh.write(data)
        self.done += len(data)

    async def finish(self):
        try:
            self.fh.close()
            if self.done != self.size:
                raise UploadError("The phone stopped sending.", "cancelled")
            final = await _move_in(self.part, self.dest)
            return final or self.name
        finally:
            self.abort()

    def abort(self):
        try:
            self.fh.close()
        except OSError:
            pass
        shutil.rmtree(self.tmpdir, ignore_errors=True)


async def _move_in(part, dest):
    proc = await asyncio.create_subprocess_exec(paths.FILEOP, "move", dest, part,
                                                stdout=asyncio.subprocess.PIPE,
                                                stderr=asyncio.subprocess.DEVNULL)
    out, _ = await proc.communicate()
    name = None
    for line in out.decode("utf-8", "replace").splitlines():
        try:
            msg = json.loads(line)
        except ValueError:
            continue
        if isinstance(msg, dict) and msg.get("error"):
            raise UploadError(msg["error"], "move", 500)
        if isinstance(msg, dict) and msg.get("name") and msg.get("path"):
            name = msg["name"]
    if proc.returncode not in (0, None):
        raise UploadError("The file couldn't be saved.", "move", 500)
    return name
