"""One phone viewing the screen (or using it as a trackpad): a quasar-deck-screen process, its stdout
relayed to the phone untouched, the phone's input checked and passed to its stdin.

The engine paces itself on the phone's acks, so a slow Wi-Fi link never piles frames up here.
"""
import asyncio
import json
import math
import os
import struct

from . import paths, ws

KEY_RE_CHARS = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_")
MODS = {"ctrl", "alt", "shift", "super"}
BUTTONS = {"left", "right", "middle"}
MAX_TEXT = 512
MAX_SESSIONS = 3


def _num(v, lo, hi):
    if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v):
        return None
    return max(lo, min(hi, float(v)))


def clean_input(cmd):
    """The phone's input command, validated and rebuilt (never passed through as-is)."""
    if not isinstance(cmd, dict):
        return None
    t = cmd.get("t")
    if t == "move":
        x, y = _num(cmd.get("x"), 0, 1), _num(cmd.get("y"), 0, 1)
        return None if x is None or y is None else {"t": "move", "x": round(x, 5), "y": round(y, 5)}
    if t == "rel":
        dx, dy = _num(cmd.get("dx"), -4000, 4000), _num(cmd.get("dy"), -4000, 4000)
        return None if dx is None or dy is None else {"t": "rel", "dx": round(dx, 2), "dy": round(dy, 2)}
    if t == "btn":
        b = cmd.get("b")
        return {"t": "btn", "b": b, "down": bool(cmd.get("down"))} if b in BUTTONS else None
    if t == "scroll":
        dx, dy = _num(cmd.get("dx", 0), -50, 50), _num(cmd.get("dy", 0), -50, 50)
        return None if dx is None or dy is None else {"t": "scroll", "dx": round(dx, 3), "dy": round(dy, 3)}
    if t in ("key", "tap"):
        k = cmd.get("k")
        if not isinstance(k, str) or not (0 < len(k) <= 32) or any(c not in KEY_RE_CHARS for c in k):
            return None
        if t == "key":
            return {"t": "key", "k": k, "down": bool(cmd.get("down"))}
        mods = cmd.get("mods") or []
        if not isinstance(mods, list) or any(m not in MODS for m in mods):
            return None
        return {"t": "tap", "k": k, "mods": sorted(set(mods))}
    if t == "text":
        s = cmd.get("s")
        if not isinstance(s, str) or not s or len(s) > MAX_TEXT:
            return None
        s = "".join(ch for ch in s if ch in "\n\t" or (ch.isprintable() and ord(ch) < 0x110000))
        return {"t": "text", "s": s} if s else None
    if t == "release":
        return {"t": "release"}
    return None


class ScreenSession:
    def __init__(self, deck, sock, device, mode, width, output):
        self.deck = deck
        self.ws = sock
        self.device = device
        self.mode = "trackpad" if mode == "trackpad" else "screen"
        self.width = int(_num(width, 160, 3840) or 1280)
        self.output = output if isinstance(output, str) and len(output) < 64 else ""
        self.proc = None
        self.reader = None
        self.closed = False

    @property
    def viewing(self):
        return self.mode == "screen" and not self.closed

    async def start(self):
        if not os.access(paths.ENGINE, os.X_OK):
            await self.ws.send_text(json.dumps({"t": "stopped", "reason": "missing",
                                                "message": "Screen sharing isn't installed on this PC."}))
            return False
        args = [paths.ENGINE, "--width", str(self.width)]
        if self.mode == "trackpad":
            args.append("--input-only")
        if self.output:
            args += ["--output", self.output]
        self.proc = await asyncio.create_subprocess_exec(*args, stdin=asyncio.subprocess.PIPE,
                                                         stdout=asyncio.subprocess.PIPE,
                                                         stderr=None, limit=1 << 22)
        self.reader = asyncio.ensure_future(self._relay())
        return True

    async def _relay(self):
        out = self.proc.stdout
        reason = "ended"
        try:
            while True:
                head = await out.readexactly(4)
                (n,) = struct.unpack("!I", head)
                if n == 0 or n > 64 << 20:
                    reason = "bad-frame"
                    break
                payload = await out.readexactly(n)
                kind = payload[:1]
                if kind in (b"H", b"F"):
                    await self.ws.send_binary(payload)
                elif kind == b"E":
                    try:
                        msg = json.loads(payload[1:].decode("utf-8"))
                    except (ValueError, UnicodeDecodeError):
                        continue
                    if isinstance(msg, dict):
                        await self.ws.send_text(json.dumps(dict(msg, t="engine")))
        except asyncio.IncompleteReadError:
            reason = "ended"
        except ws.Closed:
            reason = "phone-gone"
        except asyncio.CancelledError:
            reason = "stopped"
            raise
        finally:
            code = None
            if self.proc and self.proc.returncode is None:
                try:
                    code = await asyncio.wait_for(self.proc.wait(), 2)
                except asyncio.TimeoutError:
                    pass
            elif self.proc:
                code = self.proc.returncode
            if not self.closed and reason != "phone-gone":
                why = {3: "unsupported", 4: "no-display"}.get(code, reason)
                try:
                    await self.ws.send_text(json.dumps({"t": "stopped", "reason": why}))
                except ws.Closed:
                    pass
            self.deck.screen_changed()

    def _write(self, obj):
        if self.proc and self.proc.stdin and not self.proc.stdin.is_closing():
            try:
                self.proc.stdin.write((json.dumps(obj) + "\n").encode("utf-8"))
            except (ConnectionError, OSError, RuntimeError):
                pass

    def control(self, msg):
        """A message from the phone (already authenticated)."""
        t = msg.get("t")
        if t == "ack" and isinstance(msg.get("seq"), int):
            self._write({"t": "ack", "seq": msg["seq"]})
        elif t == "view":
            w = _num(msg.get("width"), 160, 3840)
            if w:
                self._write({"t": "view", "w": int(w)})
        elif t == "output" and isinstance(msg.get("name"), str) and len(msg["name"]) < 64:
            self._write({"t": "output", "name": msg["name"]})
        elif t == "refresh":
            self._write({"t": "refresh"})
        elif t == "quality":
            q = _num(msg.get("q"), 10, 95)
            if q:
                self._write({"t": "quality", "q": int(q)})
        elif t == "in":
            cmd = clean_input(msg.get("cmd"))
            if cmd is None:
                return
            if self.deck.locked and cmd["t"] != "release":
                return                      # the lock screen is never typed into from a phone
            self._write(cmd)

    def release(self):
        self._write({"t": "release"})

    async def stop(self):
        if self.closed:
            return
        self.closed = True
        if self.proc and self.proc.returncode is None:
            self.release()
            try:
                self.proc.stdin.close()
            except (ConnectionError, OSError, RuntimeError, AttributeError):
                pass
            try:
                await asyncio.wait_for(self.proc.wait(), 2)
            except asyncio.TimeoutError:
                try:
                    self.proc.terminate()
                    await asyncio.wait_for(self.proc.wait(), 2)
                except (ProcessLookupError, asyncio.TimeoutError):
                    try:
                        self.proc.kill()
                    except ProcessLookupError:
                        pass
        if self.reader:
            self.reader.cancel()
        self.deck.screen_changed()
