"""Command Deck's own encryption. The connection is plain HTTP (a phone can't trust a certificate this PC
made itself without a setup step), so everything a paired phone and deckd say to each other is sealed
with NaCl: libsodium through python3-nacl here, tweetnacl-js on the phone.

Keys
  * The PC has one X25519 key pair (devices.json "pcKey"); a phone makes one X25519 pair per PC
    (IndexedDB, keyed by pcId).
  * K = crypto_box_beforenm(phonePub, pcSecret): the same 32 bytes on both sides, never sent.

Pairing (POST /api/pair). The QR token (or the 6-digit code) is the shared secret S; it never crosses the
network. The phone sends mac = H32(S, "pair\\n<pcId>\\n<pub>\\n<name>\\n<model>"); deckd answers with its
public key and H32(S, "paired\\n<pcId>\\n<pub>\\n<deviceId>\\n<pcPub>"), so each side knows the other saw the
code on this PC's screen.

Sessions (every WebSocket). deckd's hello carries a nonce; the phone picks cnonce;
  sk = H32(K, "session\\n<nonce>\\n<cnonce>\\n<origin>"), proof = H32(sk, "phone").
After sign-in every message, both ways, is a binary frame secretbox(plain, nonce(dir, n), sk): dir 1 = PC
to phone, 2 = phone to PC, n counts from 0 in each direction (big-endian in bytes 16..23). Nothing can be
replayed, dropped or reordered unnoticed. A plaintext starting with "{" is JSON; anything else is binary
(the screen engine's 'H'/'F' messages, a file's 'D' chunks).

H32(key, msg) = HMAC-SHA-512(key, msg)[:32]; strings are UTF-8, base64 is URL-safe without padding.

What this doesn't cover: the page's own code arrives over plain HTTP, so someone who takes over the home
network (rather than only listening to it) could serve a changed page.
"""
import base64
import hashlib
import hmac
import os

FROM_PC, FROM_PHONE = 1, 2
KEY_BYTES = 32


def b64u(data):
    return base64.urlsafe_b64encode(bytes(data)).rstrip(b"=").decode("ascii")


def unb64u(s, size=None):
    """Strict URL-safe base64 (no padding needed); b"" when it isn't, or isn't `size` bytes."""
    s = str(s or "")
    if not s or len(s) > 4096 or any(ch not in _B64U for ch in s):
        return b""
    try:
        out = base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))
    except (ValueError, TypeError):
        return b""
    if size is not None and len(out) != size:
        return b""
    return out


_B64U = frozenset("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_")


def h32(key, msg):
    if isinstance(key, str):
        key = key.encode("utf-8")
    if isinstance(msg, str):
        msg = msg.encode("utf-8")
    return hmac.new(key, msg, hashlib.sha512).digest()[:32]


def same(a, b):
    return hmac.compare_digest(str(a or "").encode("ascii", "replace"), str(b or "").encode("ascii", "replace"))


# ---- keys ------------------------------------------------------------------------------------------
def new_secret():
    return os.urandom(KEY_BYTES)


def public_of(secret_key):
    from nacl import public
    return bytes(public.PrivateKey(bytes(secret_key)).public_key)


def shared(my_secret, their_pub):
    """crypto_box_beforenm. None for a key that can't be used (e.g. a low-order point)."""
    from nacl import exceptions, public
    try:
        return public.Box(public.PrivateKey(bytes(my_secret)), public.PublicKey(bytes(their_pub))).shared_key()
    except (exceptions.CryptoError, TypeError, ValueError):
        return None


# ---- pairing and sign-in ---------------------------------------------------------------------------
def pair_mac(secret_text, pc_id, pub, name, model):
    return b64u(h32(secret_text, "pair\n%s\n%s\n%s\n%s" % (pc_id, pub, name, model)))


def paired_mac(secret_text, pc_id, pub, device_id, pc_pub):
    return b64u(h32(secret_text, "paired\n%s\n%s\n%s\n%s" % (pc_id, pub, device_id, pc_pub)))


def session_key(k, nonce, cnonce, origin):
    return h32(k, "session\n%s\n%s\n%s" % (nonce, cnonce, origin))


def proof(sk):
    return b64u(h32(sk, "phone"))


# ---- sealed messages -------------------------------------------------------------------------------
def nonce(direction, n):
    return bytes([direction]) + bytes(15) + int(n).to_bytes(8, "big")


class Broken(Exception):
    """A sealed message that didn't open: wrong key, tampered, replayed or out of order."""


class Channel:
    """One WebSocket's keys and counters. `me` is the side this end speaks for."""

    def __init__(self, key, me=FROM_PC):
        from nacl import secret
        self.box = secret.SecretBox(bytes(key))
        self.out_dir = me
        self.in_dir = FROM_PHONE if me == FROM_PC else FROM_PC
        self.sent = 0
        self.got = 0

    def seal(self, plain):
        ct = self.box.encrypt(bytes(plain), nonce(self.out_dir, self.sent)).ciphertext
        self.sent += 1
        return ct

    def open(self, ct):
        from nacl import exceptions
        try:
            plain = self.box.decrypt(bytes(ct), nonce(self.in_dir, self.got))
        except (exceptions.CryptoError, ValueError, TypeError):
            raise Broken()
        self.got += 1
        return plain
