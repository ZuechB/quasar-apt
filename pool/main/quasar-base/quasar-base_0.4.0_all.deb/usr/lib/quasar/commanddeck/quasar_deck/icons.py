"""App icons for the phone: a desktop entry's Icon= name -> an SVG or PNG file.

Quickshell hands the shell image:// URLs, which a phone can't load, so deckd looks the name up in the
icon themes itself (hicolor and Adwaita, Flatpak's exported icons, pixmaps). Results are cached.
"""
import os

EXTS = (".svg", ".png")
SIZES = ("scalable", "512x512", "256x256", "192x192", "128x128", "96x96", "64x64", "48x48", "32x32")
THEMES = ("hicolor", "Adwaita")


def _bases():
    home = os.path.expanduser("~")
    data_home = os.environ.get("XDG_DATA_HOME") or os.path.join(home, ".local", "share")
    dirs = [os.path.join(data_home, "icons"), os.path.join(home, ".icons"),
            os.path.join(data_home, "flatpak", "exports", "share", "icons"),
            "/var/lib/flatpak/exports/share/icons"]
    for d in (os.environ.get("XDG_DATA_DIRS") or "/usr/local/share:/usr/share").split(":"):
        if d:
            dirs.append(os.path.join(d, "icons"))
    seen, out = set(), []
    for d in dirs:
        if d not in seen and os.path.isdir(d):
            seen.add(d)
            out.append(d)
    return out


class Icons:
    def __init__(self):
        self.cache = {}

    def find(self, name):
        name = str(name or "").strip()
        if not name or len(name) > 255 or "\0" in name:
            return None
        if name in self.cache:
            return self.cache[name]
        path = self._find(name)
        if len(self.cache) > 2000:
            self.cache.clear()
        self.cache[name] = path
        return path

    def _find(self, name):
        if name.startswith("/"):
            return name if name.lower().endswith(EXTS) and os.path.isfile(name) else None
        if "/" in name or name.startswith("."):
            return None
        stem = name[:-4] if name.lower().endswith(EXTS) else name
        for base in _bases():
            for theme in THEMES:
                for size in SIZES:
                    for ext in EXTS:
                        p = os.path.join(base, theme, size, "apps", stem + ext)
                        if os.path.isfile(p):
                            return p
        for ext in EXTS:
            p = os.path.join("/usr/share/pixmaps", stem + ext)
            if os.path.isfile(p):
                return p
        return None


def content_type(path):
    return "image/svg+xml" if path.lower().endswith(".svg") else "image/png"
