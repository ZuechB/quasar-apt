"""A small RFC 6455 WebSocket server side on asyncio streams (stdlib only).

Client frames must be masked; server frames never are. Fragmented messages are joined; ping gets a
pong; close is answered and ends the socket. Messages above `max_size` close it with 1009.

After sign-in deckd sets `channel` (seal.Channel): from then on send_text/send_binary go out sealed as
binary frames and recv opens them (sealing happens under the send lock, so counters match the wire
order). An unsealed or broken message then ends the socket (1008).
"""
import asyncio
import base64
import hashlib
import struct

GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
OP_CONT, OP_TEXT, OP_BINARY, OP_CLOSE, OP_PING, OP_PONG = 0x0, 0x1, 0x2, 0x8, 0x9, 0xA


class Closed(Exception):
    def __init__(self, code=1000, reason=""):
        super().__init__("closed %d %s" % (code, reason))
        self.code = code
        self.reason = reason


def accept_key(key):
    return base64.b64encode(hashlib.sha1((key + GUID).encode("ascii")).digest()).decode("ascii")


def valid_key(key):
    try:
        return len(base64.b64decode(key, validate=True)) == 16
    except (ValueError, TypeError):
        return False


def frame(opcode, payload, fin=True):
    """One unmasked (server) frame."""
    n = len(payload)
    head = bytes([(0x80 if fin else 0) | opcode])
    if n < 126:
        head += bytes([n])
    elif n < 65536:
        head += bytes([126]) + struct.pack("!H", n)
    else:
        head += bytes([127]) + struct.pack("!Q", n)
    return head + payload


def unmask(data, mask):
    if not data:
        return data
    # XOR with the 4-byte mask, a word at a time via int arithmetic (fast enough for control traffic).
    reps = (len(data) + 3) // 4
    m = int.from_bytes((mask * reps)[:len(data)], "big")
    return (int.from_bytes(data, "big") ^ m).to_bytes(len(data), "big")


class WebSocket:
    def __init__(self, reader, writer, max_size=1 << 20):
        self.reader = reader
        self.writer = writer
        self.max_size = max_size
        self.closed = False
        self.channel = None
        self._lock = asyncio.Lock()

    async def _read_frame(self):
        b1, b2 = await self.reader.readexactly(2)
        fin, rsv, opcode = b1 & 0x80, b1 & 0x70, b1 & 0x0F
        masked, n = b2 & 0x80, b2 & 0x7F
        if rsv:
            raise Closed(1002, "reserved bits")
        if not masked:
            raise Closed(1002, "client frames must be masked")
        if n == 126:
            (n,) = struct.unpack("!H", await self.reader.readexactly(2))
        elif n == 127:
            (n,) = struct.unpack("!Q", await self.reader.readexactly(8))
        if opcode >= 0x8 and (n > 125 or not fin):
            raise Closed(1002, "bad control frame")
        if n > self.max_size:
            raise Closed(1009, "message too big")
        mask = await self.reader.readexactly(4)
        data = unmask(await self.reader.readexactly(n), mask) if n else b""
        return bool(fin), opcode, data

    async def recv(self):
        """The next message: (OP_TEXT, str) or (OP_BINARY, bytes). Raises Closed."""
        if self.closed:
            raise Closed(1006, "closed")
        parts, kind = [], None
        size = 0
        try:
            while True:
                fin, op, data = await self._read_frame()
                if op == OP_PING:
                    await self._send(OP_PONG, data)
                    continue
                if op == OP_PONG:
                    continue
                if op == OP_CLOSE:
                    code = struct.unpack("!H", data[:2])[0] if len(data) >= 2 else 1005
                    await self.close(1000 if code == 1005 else code)
                    raise Closed(code, data[2:].decode("utf-8", "replace"))
                if op in (OP_TEXT, OP_BINARY):
                    if kind is not None:
                        raise Closed(1002, "new message inside a fragmented one")
                    kind = op
                elif op == OP_CONT:
                    if kind is None:
                        raise Closed(1002, "continuation without a start")
                else:
                    raise Closed(1002, "unknown opcode")
                size += len(data)
                if size > self.max_size:
                    raise Closed(1009, "message too big")
                parts.append(data)
                if fin:
                    break
        except (asyncio.IncompleteReadError, ConnectionError, OSError):
            self.closed = True
            raise Closed(1006, "connection lost")
        except Closed as e:
            if not self.closed:
                await self.close(e.code if e.code in (1002, 1007, 1009) else 1000)
            raise
        payload = b"".join(parts)
        if self.channel is not None:
            from .seal import Broken
            try:
                if kind != OP_BINARY:
                    raise Broken()
                plain = self.channel.open(payload)
            except Broken:
                await self.close(1008)
                raise Closed(1008, "not sealed")
            if plain[:1] == b"{":
                try:
                    return OP_TEXT, plain.decode("utf-8")
                except UnicodeDecodeError:
                    await self.close(1007)
                    raise Closed(1007, "not UTF-8")
            return OP_BINARY, plain
        if kind == OP_TEXT:
            try:
                return OP_TEXT, payload.decode("utf-8")
            except UnicodeDecodeError:
                await self.close(1007)
                raise Closed(1007, "not UTF-8")
        return OP_BINARY, payload

    async def _send(self, opcode, payload):
        if self.closed:
            raise Closed(1006, "closed")
        async with self._lock:
            if self.channel is not None and opcode in (OP_TEXT, OP_BINARY):
                payload, opcode = self.channel.seal(payload), OP_BINARY
            try:
                self.writer.write(frame(opcode, payload))
                await self.writer.drain()
            except (ConnectionError, OSError, RuntimeError):
                self.closed = True
                raise Closed(1006, "connection lost")

    async def send_text(self, text):
        await self._send(OP_TEXT, text.encode("utf-8"))

    async def send_binary(self, data):
        await self._send(OP_BINARY, bytes(data))

    def buffered(self):
        """Bytes waiting in the transport (for backpressure decisions)."""
        t = self.writer.transport
        return t.get_write_buffer_size() if t and not t.is_closing() else 0

    async def close(self, code=1000, reason=""):
        if self.closed:
            return
        try:
            async with self._lock:
                self.writer.write(frame(OP_CLOSE, struct.pack("!H", code) + reason.encode("utf-8")[:120]))
                await asyncio.wait_for(self.writer.drain(), 2)
        except (ConnectionError, OSError, RuntimeError, asyncio.TimeoutError):
            pass
        self.closed = True
        try:
            self.writer.close()
        except (ConnectionError, OSError, RuntimeError):
            pass
