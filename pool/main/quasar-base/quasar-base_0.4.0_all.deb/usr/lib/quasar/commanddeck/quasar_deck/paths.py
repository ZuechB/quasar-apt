"""Where Command Deck keeps things.

Test overrides (QUASAR_DECK_*) are honoured only when not running as root, so nobody can redirect a
root helper with an environment variable.
"""
import os


def _is_root():
    geteuid = getattr(os, "geteuid", None)
    return geteuid is not None and geteuid() == 0


IS_ROOT = _is_root()


def env(name, default):
    if IS_ROOT:
        return default
    return os.environ.get(name) or default


# ---- system (root-owned) ------------------------------------------------------------------------
SYS_DIR = env("QUASAR_DECK_SYS", "/etc/quasar/commanddeck")
USERS = os.path.join(SYS_DIR, "users.json")          # accounts an administrator turned it on for
NET_STATE = env("QUASAR_DECK_NET_STATE", "/run/quasar/firewall-net.json")
FIREWALL = env("QUASAR_DECK_FIREWALL", "/usr/libexec/quasar/quasar-firewall")
IP = env("QUASAR_DECK_IP", "ip")

# ---- programs ------------------------------------------------------------------------------------
LIB = env("QUASAR_DECK_LIB", "/usr/lib/quasar/commanddeck")
WEB = env("QUASAR_DECK_WEB", "/usr/share/quasar/commanddeck/web")
ENGINE = env("QUASAR_DECK_ENGINE", os.path.join(LIB, "quasar-deck-screen"))
FILEOP = env("QUASAR_DECK_FILEOP", "/usr/libexec/quasar/fileop")


# ---- the account's own files ---------------------------------------------------------------------
def runtime_dir():
    base = os.environ.get("XDG_RUNTIME_DIR") or "/run/user/%d" % os.getuid()
    return os.path.join(base, "quasar")


def control_socket():
    return env("QUASAR_DECK_SOCK", os.path.join(runtime_dir(), "commanddeck.sock"))


def data_dir():
    base = os.environ.get("XDG_DATA_HOME") or os.path.join(os.path.expanduser("~"), ".local", "share")
    return env("QUASAR_DECK_DATA", os.path.join(base, "quasar", "commanddeck"))


def downloads_dir():
    """The XDG download folder (user-dirs.dirs), else ~/Downloads."""
    home = os.path.expanduser("~")
    cfg = os.path.join(os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config"), "user-dirs.dirs")
    try:
        with open(cfg, encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if line.startswith("XDG_DOWNLOAD_DIR="):
                    v = line.split("=", 1)[1].strip().strip('"').replace("$HOME", home)
                    if v.startswith("/"):
                        return v
    except OSError:
        pass
    return os.path.join(home, "Downloads")


def port_for(uid):
    """Each account its own port: its own browser origin on the phone, so two accounts' phone keys
    never mix, and two signed-in accounts never fight over one port."""
    fixed = os.environ.get("QUASAR_DECK_PORT") if not IS_ROOT else None
    if fixed and fixed.isdigit():
        return int(fixed)
    if 1000 <= uid < 3000:
        return 47300 + (uid - 1000)
    return 47300

