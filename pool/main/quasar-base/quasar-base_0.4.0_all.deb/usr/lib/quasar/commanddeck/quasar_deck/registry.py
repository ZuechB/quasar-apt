"""The registry of server-side module halves (quasar_deck/modules/<id>.py); see modules/__init__.py."""
import importlib
import pkgutil
import re

ID_RE = re.compile(r"^[a-z][a-z0-9-]{0,31}$")
OP_RE = re.compile(r"^[a-zA-Z][a-zA-Z0-9]{0,31}$")


class Registry:
    def __init__(self):
        self.mods = {}
        try:
            from . import modules as pkg
        except ImportError:
            return
        for info in pkgutil.iter_modules(pkg.__path__):
            mid = info.name.replace("_", "-")
            if not ID_RE.match(mid):
                continue
            try:
                self.mods[mid] = importlib.import_module("%s.%s" % (pkg.__name__, info.name))
            except Exception as e:                      # one broken module never stops the deck
                import sys
                print("deckd: module %s: %r" % (mid, e), file=sys.stderr)

    def public(self):
        return [{"id": mid, "name": getattr(m, "NAME", mid)} for mid, m in sorted(self.mods.items())]

    async def call(self, deck, mid, op, args, device):
        m = self.mods.get(mid) if isinstance(mid, str) else None
        fn = getattr(m, "op_" + op, None) if m and isinstance(op, str) and OP_RE.match(op) else None
        if fn is None:
            return {"ok": False, "error": "That isn't something Command Deck can do.", "code": "unknown-op"}
        if not isinstance(args, dict):
            return {"ok": False, "error": "That request wasn't complete.", "code": "bad-args"}
        try:
            res = await fn(deck, args, device)
        except Exception as e:
            return {"ok": False, "error": "It didn't work (%s)." % e, "code": "failed"}
        return res if isinstance(res, dict) else {"ok": True, "data": res}
