"""Command Deck: use a phone on the home network as a remote for this PC.

deckd (user service) serves the phone app over plain HTTP, seals everything after sign-in itself
(seal.py), and relays to the shell (apps, windows, media, power) and to quasar-deck-screen (screen +
input). quasar-commanddeck-admin is the root helper (turning it on for an account: firewall entry).
"""
VERSION = 2
