"""Pairing and the phones Command Deck knows.

Pairing: while Settings shows "Connect a phone", there is one pairing secret, shown two ways: a token
in the QR code's URL fragment (#p=…, which a browser never sends) and a 6-digit code under it (an iPhone
home-screen app has its own storage, so it pairs itself by typing the code). Neither crosses the network:
the phone proves it knows one with a MAC (seal.pair_mac). Both rotate every 60 s and after each use; ten
misses rotate it early, and each address gets 10 tries a minute.

A phone is its X25519 public key (devices.json holds public keys only, plus this PC's own key pair); every
WebSocket starts with a proof made from the key both sides share (seal.py). No cookies: they would be
sent to any port on this address (a Site shared on the home network, say).
"""
import os
import secrets
import time

from . import seal, store

ROTATE_S = 60
MAX_MISSES = 10
PER_IP_PER_MIN = 10
MAX_DEVICES = 20
NAME_MAX = 40
b64u = seal.b64u


def clean_name(name):
    s = " ".join(str(name or "").split())
    s = "".join(ch for ch in s if ch.isprintable())
    return s[:NAME_MAX] or "Phone"


class Devices:
    """devices.json (0600): {version: 2, pcId, pcKey (this PC's X25519 secret), devices: [{id, name, pub,
    created, lastSeen, model}]}"""

    def __init__(self, path):
        self.path = path
        data = store.read_json(path, {})
        if not isinstance(data, dict):
            data = {}
        self.pc_id = data.get("pcId") if isinstance(data.get("pcId"), str) and data.get("pcId") else b64u(os.urandom(12))
        self.pc_secret = seal.unb64u(data.get("pcKey"), 32) or seal.new_secret()
        self.pc_pub = b64u(seal.public_of(self.pc_secret))
        # Phones paired before Command Deck sealed its own traffic carry WebCrypto keys: they pair again.
        self.items = [d for d in data.get("devices") or []
                      if isinstance(d, dict) and d.get("id") and seal.unb64u(d.get("pub"), 32)]
        if data.get("version") != 2 or not data.get("pcKey") or len(self.items) != len(data.get("devices") or []):
            self.save()

    def save(self):
        store.write_json(self.path, {"version": 2, "pcId": self.pc_id, "pcKey": b64u(self.pc_secret),
                                     "devices": self.items})

    def get(self, did):
        return next((d for d in self.items if d["id"] == did), None)

    def add(self, name, pub, model=""):
        name = clean_name(name)
        # A phone that pairs again under the same name (its address changed, its storage was cleared)
        # replaces its old entry instead of piling up.
        self.items = [d for d in self.items if d.get("name") != name]
        if len(self.items) >= MAX_DEVICES:
            self.items.sort(key=lambda d: d.get("lastSeen") or 0)
            self.items = self.items[1:]
        d = {"id": b64u(os.urandom(9)), "name": name, "pub": pub, "created": int(time.time()),
             "lastSeen": int(time.time()), "model": clean_name(model)[:40] if model else ""}
        self.items.append(d)
        self.save()
        return d

    def rename(self, did, name):
        d = self.get(did)
        if d:
            d["name"] = clean_name(name)
            self.save()
        return d

    def remove(self, did):
        before = len(self.items)
        self.items = [d for d in self.items if d["id"] != did]
        if len(self.items) != before:
            self.save()
            return True
        return False

    def remove_all(self, new_keys=True):
        """Every phone goes, and (by default) this PC gets a new id and key: nothing a phone kept still fits."""
        self.items = []
        if new_keys:
            self.pc_id = b64u(os.urandom(12))
            self.pc_secret = seal.new_secret()
            self.pc_pub = b64u(seal.public_of(self.pc_secret))
        self.save()

    def seen(self, did):
        d = self.get(did)
        if d:
            now = int(time.time())
            if now - (d.get("lastSeen") or 0) > 60:
                d["lastSeen"] = now
                self.save()

    def public(self):
        return [{"id": d["id"], "name": d["name"], "created": d.get("created"), "lastSeen": d.get("lastSeen"),
                 "model": d.get("model") or ""} for d in self.items]


class Pairing:
    """The pairing secret, alive only while someone is looking at it in Settings."""

    def __init__(self, clock=time.monotonic):
        self.clock = clock
        self.token = ""
        self.code = ""
        self.born = 0.0
        self.misses = 0
        self.watchers = 0
        self.tries = {}          # ip -> [times]

    @property
    def active(self):
        return self.watchers > 0

    def _new(self):
        self.token = b64u(os.urandom(16))
        self.code = "%06d" % secrets.randbelow(1000000)
        self.born = self.clock()
        self.misses = 0

    def current(self):
        """(token, code, seconds left), rotating when due. Only while shown."""
        if not self.active:
            return None
        if not self.token or self.clock() - self.born >= ROTATE_S:
            self._new()
        return self.token, self.code, max(0, int(ROTATE_S - (self.clock() - self.born)))

    def show(self):
        """Another viewer (a second Settings window) sees the same secret: rotating it here would make
        the code already on screen stop working."""
        self.watchers += 1
        if self.watchers == 1 or not self.token:
            self._new()

    def hide(self):
        self.watchers = max(0, self.watchers - 1)
        if not self.watchers:
            self.token = self.code = ""

    def allowed(self, ip):
        now = self.clock()
        times = [t for t in self.tries.get(ip, []) if now - t < 60]
        if len(times) >= PER_IP_PER_MIN:
            self.tries[ip] = times
            return False
        times.append(now)
        self.tries[ip] = times
        if len(self.tries) > 256:
            self.tries = {k: v for k, v in self.tries.items() if v and now - v[-1] < 60}
        return True

    def verify(self, via, mac, expected):
        """The phone's pairing MAC against the current secret: `expected(secret_text)` is the MAC it should
        have sent. Returns the secret (which then rotates) when it matches, else None."""
        cur = self.current()
        if not cur:
            return None
        secret_text = cur[0] if via == "qr" else cur[1] if via == "code" else ""
        if secret_text and isinstance(mac, str) and seal.same(mac, expected(secret_text)):
            self._new()
            return secret_text
        self.misses += 1
        if self.misses >= MAX_MISSES:
            self._new()
        return None
