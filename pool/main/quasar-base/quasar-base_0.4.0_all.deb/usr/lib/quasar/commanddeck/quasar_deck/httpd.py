"""Just enough HTTP/1.1 for the phone app, on asyncio streams (stdlib only).

Requests are read with hard limits (request line, header count and size); bodies are read by the
handler (uploads stream). Chunked request bodies aren't supported (411): browsers send Content-Length
for files and JSON.
"""
import asyncio
import email.utils
import json
import urllib.parse

MAX_LINE = 8192
MAX_HEADERS = 64
REASONS = {200: "OK", 204: "No Content", 206: "Partial Content", 301: "Moved Permanently", 303: "See Other",
           304: "Not Modified", 400: "Bad Request", 401: "Unauthorized", 403: "Forbidden", 404: "Not Found",
           405: "Method Not Allowed", 408: "Request Timeout", 409: "Conflict", 411: "Length Required",
           413: "Payload Too Large", 421: "Misdirected Request", 423: "Locked", 429: "Too Many Requests",
           500: "Internal Server Error", 503: "Service Unavailable", 507: "Insufficient Storage"}


class BadRequest(Exception):
    def __init__(self, status=400, message="Bad request"):
        super().__init__(message)
        self.status = status


class Request:
    def __init__(self, method, target, version, headers, reader, peer, local):
        self.method = method
        self.version = version
        self.headers = headers
        self.reader = reader
        self.peer = peer
        self.local = local
        u = urllib.parse.urlsplit(target)
        self.path = urllib.parse.unquote(u.path or "/")
        self.raw_path = u.path or "/"
        self.query = {k: v[0] for k, v in urllib.parse.parse_qs(u.query, keep_blank_values=True).items()}

    def header(self, name, default=""):
        return self.headers.get(name.lower(), default)

    @property
    def length(self):
        v = self.header("content-length")
        if not v:
            return None
        if not v.isdigit():
            raise BadRequest(400, "Bad length")
        return int(v)

    @property
    def keep_alive(self):
        conn = self.header("connection").lower()
        if self.version == "HTTP/1.0":
            return "keep-alive" in conn
        return "close" not in conn

    async def body(self, limit):
        if self.header("transfer-encoding"):
            raise BadRequest(411, "Length required")
        n = self.length or 0
        if n > limit:
            raise BadRequest(413, "Too big")
        return await self.reader.readexactly(n) if n else b""

    async def json(self, limit=16384):
        try:
            data = json.loads((await self.body(limit)).decode("utf-8") or "null")
        except (ValueError, UnicodeDecodeError):
            raise BadRequest(400, "Not JSON")
        if not isinstance(data, dict):
            raise BadRequest(400, "Not an object")
        return data


async def read_request(reader, peer, local, timeout=30):
    """The next request on a connection, or None when the client went away."""
    try:
        line = await asyncio.wait_for(reader.readline(), timeout)
    except (asyncio.TimeoutError, ConnectionError, OSError, ValueError, asyncio.LimitOverrunError):
        return None
    if not line:
        return None
    if len(line) > MAX_LINE or not line.endswith(b"\n"):
        raise BadRequest(400, "Request line too long")
    try:
        method, target, version = line.decode("latin-1").strip().split(" ", 2)
    except ValueError:
        raise BadRequest(400, "Bad request line")
    if version not in ("HTTP/1.1", "HTTP/1.0") or not target.startswith("/"):
        raise BadRequest(400, "Bad request line")
    headers = {}
    for _ in range(MAX_HEADERS + 1):
        try:
            h = await asyncio.wait_for(reader.readline(), timeout)
        except (asyncio.TimeoutError, ConnectionError, OSError, ValueError, asyncio.LimitOverrunError):
            return None
        if len(h) > MAX_LINE:
            raise BadRequest(400, "Header too long")
        if h in (b"\r\n", b"\n", b""):
            break
        k, sep, v = h.decode("latin-1").partition(":")
        if not sep:
            raise BadRequest(400, "Bad header")
        k = k.strip().lower()
        if k in headers and k not in ("cookie",):
            headers[k] += ", " + v.strip()
        else:
            headers[k] = v.strip()
    else:
        raise BadRequest(400, "Too many headers")
    return Request(method.upper(), target, version, headers, reader, peer, local)


def head(status, headers=(), length=None, keep_alive=True):
    lines = ["HTTP/1.1 %d %s" % (status, REASONS.get(status, "OK")),
             "Date: " + email.utils.formatdate(usegmt=True), "Server: Quasar"]
    for k, v in headers:
        lines.append("%s: %s" % (k, v))
    if length is not None:
        lines.append("Content-Length: %d" % length)
    lines.append("Connection: " + ("keep-alive" if keep_alive else "close"))
    return ("\r\n".join(lines) + "\r\n\r\n").encode("latin-1")


async def send(writer, status, body=b"", headers=(), keep_alive=True, head_only=False):
    if isinstance(body, str):
        body = body.encode("utf-8")
    writer.write(head(status, headers, len(body), keep_alive))
    if body and not head_only:
        writer.write(body)
    await writer.drain()


async def send_json(writer, status, obj, headers=(), keep_alive=True):
    await send(writer, status, json.dumps(obj).encode("utf-8"),
               [("Content-Type", "application/json"), ("Cache-Control", "no-store")] + list(headers), keep_alive)
