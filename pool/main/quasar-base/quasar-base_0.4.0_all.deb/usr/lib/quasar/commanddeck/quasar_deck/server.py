"""deckd: Command Deck's server (one per signed-in account, a systemd user service).

  phones  --HTTP + sealed WebSockets :port-->  Deck  <--commanddeck.sock-->  shell (apps, windows, media, power)
                                                 |                       <-->  Settings (pairing, phones, status)
                                                 +-- quasar-deck-screen (one per screen/trackpad viewer)

Plain HTTP, because a phone can't trust a certificate this PC made without a setup step; everything
after sign-in is sealed with keys from the QR code (seal.py). The protocol is
linux/session/commanddeck/PROTOCOL.md. Nothing runs while nobody is connected: no polling, the shell
pushes state only for topics a phone watches, the engine only runs while a phone shows the screen.
"""
import asyncio
import base64
import ctypes
import hashlib
import json
import os
import signal
import socket
import struct
import subprocess
import sys

from . import admin, auth, files, httpd, icons, netinfo, paths, registry, screen, seal, ws

CALL_TIMEOUT = 10
OPS = {
    "launch": {"id": str},
    "focus": {"wid": str},
    "minimize": {"wid": str},
    "close": {"wid": str},
    "media": {"action": ("playPause", "next", "previous", "stop", "play", "pause")},
    "volume": {"value": (int, float)},
    "mute": {"on": bool},
    "power": {"action": ("lock", "sleep", "logout", "reboot", "poweroff")},
}
LOCKED_OK = {"media", "volume", "mute", "power"}
LOCAL_OPS = {"icon": 512 << 10, "art": 4 << 20}     # answered by deckd itself, with a size cap
TOPICS = ("apps", "windows", "media", "system")
TYPES = {".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8",
         ".mjs": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8",
         ".json": "application/json", ".webmanifest": "application/manifest+json",
         ".svg": "image/svg+xml", ".png": "image/png", ".jpg": "image/jpeg", ".webp": "image/webp",
         ".ico": "image/x-icon", ".woff2": "font/woff2", ".woff": "font/woff", ".ttf": "font/ttf",
         ".txt": "text/plain; charset=utf-8"}


def log(msg):
    print("deckd: " + msg, file=sys.stderr, flush=True)


def pc_name():
    try:
        with open("/etc/machine-info", encoding="utf-8") as fh:
            for line in fh:
                if line.startswith("PRETTY_HOSTNAME="):
                    v = line.split("=", 1)[1].strip().strip('"')
                    if v:
                        return v
    except OSError:
        pass
    return socket.gethostname().split(".")[0] or "This PC"


def _check_args(op, args):
    spec = OPS.get(op)
    if spec is None or not isinstance(args, dict):
        return None
    out = {}
    for k, kind in spec.items():
        v = args.get(k)
        if isinstance(kind, tuple) and all(isinstance(x, str) for x in kind):
            if v not in kind:
                return None
        elif kind is bool:
            if not isinstance(v, bool):
                return None
        elif kind is str:
            if not isinstance(v, str) or not v or len(v) > 256:
                return None
        else:
            if isinstance(v, bool) or not isinstance(v, kind):
                return None
            v = max(0, min(100, v))
        out[k] = v
    return out


# --------------------------------------------------------------------------------------------- peers
class Client:
    """One connection on commanddeck.sock: the shell or Settings."""

    def __init__(self, deck, reader, writer):
        self.deck = deck
        self.reader = reader
        self.writer = writer
        self.role = None
        self.showing_pairing = False

    async def send(self, obj):
        try:
            self.writer.write((json.dumps(obj) + "\n").encode("utf-8"))
            await self.writer.drain()
        except (ConnectionError, OSError, RuntimeError):
            pass


class Phone:
    """One phone's control WebSocket."""

    def __init__(self, deck, sock, device, peer):
        self.deck = deck
        self.ws = sock
        self.device = device
        self.peer = peer
        self.topics = set()

    async def send(self, obj):
        try:
            await self.ws.send_text(json.dumps(obj))
        except ws.Closed:
            pass


# ----------------------------------------------------------------------------------------------- deck
class Deck:
    def __init__(self):
        self.uid = os.getuid()
        self.port = paths.port_for(self.uid)
        self.name = pc_name()
        self.devices = auth.Devices(os.path.join(paths.data_dir(), "devices.json"))
        self.pairing = auth.Pairing()
        self.icons = icons.Icons()
        self.modules = registry.Registry()
        self.net_state = {}
        self.links = []
        self.own = set()
        self.server = None
        self.vm = detect_vm()
        self.problem = None              # (code, message) when it can't serve
        self.clients = set()
        self.shell = None
        self.phones = set()
        self.screens = set()
        self.file_socks = set()          # (device id, socket) of /ws/files uploads in progress
        self.state = {}
        self.watching = ()
        self.calls = {}
        self.cid = 0
        self.art = {}
        self.greeted = set()
        self.stopping = False
        self.pair_task = None
        self.prefs = self.load_prefs()

    # ---- simple facts ----------------------------------------------------------------------------
    @staticmethod
    def load_prefs():
        """What the user lets phones do (Settings › Command Deck), straight from settings.json at start;
        the shell sends changes ({op: "prefs"}). Anything unreadable means the defaults (both allowed)."""
        base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(os.path.expanduser("~"), ".config")
        try:
            with open(os.path.join(base, "quasar", "settings.json"), encoding="utf-8") as fh:
                cd = json.load(fh).get("commandDeck") or {}
        except (OSError, ValueError, AttributeError):
            cd = {}
        if not isinstance(cd, dict):
            cd = {}
        return {"screen": cd.get("screen") is not False, "files": cd.get("files") is not False}

    @property
    def locked(self):
        return bool((self.state.get("system") or {}).get("locked"))

    @property
    def enabled(self):
        return self.uid in admin.enabled_uids()

    def host_for(self, ip):
        return "%s:%d" % (netinfo.url_host(ip), self.port)

    def url(self):
        best = netinfo.best_ip(self.links)
        return ("http://" + self.host_for(best)) if best else ""

    # ---- start / stop ----------------------------------------------------------------------------
    async def run(self):
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGTERM, signal.SIGINT):
            loop.add_signal_handler(sig, lambda: asyncio.ensure_future(self.stop()))
        await self.start_control()
        self.watch_net()
        await self.refresh(initial=True)
        while not self.stopping:
            await asyncio.sleep(300)             # a slow sanity pass; changes arrive through inotify
            await self.refresh()

    async def stop(self):
        if self.stopping:
            return
        self.stopping = True
        for p in list(self.phones):
            await p.send({"t": "bye", "reason": "off"})
            await p.ws.close(1001)
        for s in list(self.screens):
            await s.stop()
        if self.server:
            self.server.close()
        try:
            os.unlink(paths.control_socket())
        except OSError:
            pass
        os._exit(0)

    async def refresh(self, initial=False):
        """Re-read who we are allowed to be and where; listen while turned on. Off a home network the
        port stays open but every connection is refused (reach_ok), and Settings says why."""
        self.net_state = netinfo.read_net_state()
        self.links = netinfo.home_links(self.net_state)
        self.own = netinfo.all_addresses()
        if not self.enabled:
            self.problem = ("not-enabled", "Turn Command Deck on in Settings (an administrator confirms it once).")
        elif not self.links:
            self.problem = ("not-home", "This PC isn't on a home network right now.")
        else:
            self.problem = None
        if self.problem and self.problem[0] == "not-enabled":
            await self.stop_server()
        elif not self.server:
            await self.start_server()
        # Phones that were reachable on a network we left are cut off.
        for p in list(self.phones):
            if not self.reach(p.peer[1], p.peer[0]):
                await p.send({"t": "bye", "reason": "network"})
                await p.ws.close(1008)
        await self.broadcast_status()

    def reach(self, local, peer):
        return netinfo.reach_ok(local, peer, self.links, self.own)

    async def start_server(self):
        try:
            self.server = await asyncio.start_server(self.handle_http, host=None, port=self.port,
                                                     reuse_address=True, limit=1 << 16)
        except OSError as e:
            self.problem = ("port", "Port %d is in use by another program." % self.port)
            log("listen :%d: %s" % (self.port, e))
            return
        log("listening on :%d" % self.port)

    async def stop_server(self):
        if self.server:
            self.server.close()
            self.server = None
        for p in list(self.phones):
            await p.send({"t": "bye", "reason": "off"})
            await p.ws.close(1001)
        for s in list(self.screens):
            await s.stop()
        await self.close_uploads()

    async def close_uploads(self, did=None):
        """End uploads in progress (all, or one phone's): the partial file is removed."""
        for d, sock in list(self.file_socks):
            if did is None or d == did:
                await sock.close(4401 if did else 1001)

    # ---- network changes (inotify on /run/quasar) --------------------------------------------------
    def watch_net(self):
        IN_MODIFY, IN_CLOSE_WRITE, IN_CREATE, IN_MOVED_TO = 0x2, 0x8, 0x100, 0x80
        try:
            libc = ctypes.CDLL(None, use_errno=True)
            fd = libc.inotify_init1(os.O_NONBLOCK | os.O_CLOEXEC)
            d = os.path.dirname(paths.NET_STATE)
            if fd < 0 or not os.path.isdir(d):
                return
            if fd < 0 or libc.inotify_add_watch(fd, d.encode(), IN_MODIFY | IN_CLOSE_WRITE | IN_CREATE | IN_MOVED_TO) < 0:
                return
        except (OSError, AttributeError):
            return
        base = os.path.basename(paths.NET_STATE).encode()
        pending = {"h": None}

        def readable():
            try:
                buf = os.read(fd, 8192)
            except BlockingIOError:
                return
            i, hit = 0, False
            while i + 16 <= len(buf):
                _wd, _mask, _c, ln = struct.unpack_from("=iIII", buf, i)
                if buf[i + 16:i + 16 + ln].rstrip(b"\0") == base:
                    hit = True
                i += 16 + ln
            if hit:
                if pending["h"]:
                    pending["h"].cancel()
                pending["h"] = asyncio.get_running_loop().call_later(
                    0.4, lambda: asyncio.ensure_future(self.refresh()))
        asyncio.get_running_loop().add_reader(fd, readable)

    # ---- control socket --------------------------------------------------------------------------
    async def start_control(self):
        path = paths.control_socket()
        os.makedirs(os.path.dirname(path), mode=0o700, exist_ok=True)
        try:
            os.unlink(path)
        except FileNotFoundError:
            pass
        old = os.umask(0o177)
        try:
            await asyncio.start_unix_server(self.handle_control, path=path, limit=1 << 22)
        finally:
            os.umask(old)

    async def handle_control(self, reader, writer):
        sock = writer.get_extra_info("socket")
        try:
            creds = sock.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, struct.calcsize("3i"))
            _pid, uid, _gid = struct.unpack("3i", creds)
        except OSError:
            uid = -1
        if uid != self.uid:
            writer.close()
            return
        c = Client(self, reader, writer)
        self.clients.add(c)
        try:
            while True:
                line = await reader.readline()
                if not line:
                    break
                try:
                    msg = json.loads(line)
                except ValueError:
                    continue
                if isinstance(msg, dict):
                    await self.control_message(c, msg)
        except (ConnectionError, OSError, asyncio.LimitOverrunError, ValueError):
            pass
        finally:
            self.clients.discard(c)
            if c.showing_pairing:
                self.pairing.hide()
            if self.shell is c:
                self.shell = None
                for fut in list(self.calls.values()):
                    if not fut.done():
                        fut.set_result({"ok": False, "error": "The desktop restarted.", "code": "shell"})
            try:
                writer.close()
            except (ConnectionError, OSError, RuntimeError):
                pass

    async def reply(self, c, msg, **fields):
        if msg.get("id") is not None:
            await c.send(dict(fields, id=msg["id"]))

    async def control_message(self, c, msg):
        op = msg.get("op")
        if op == "hello":
            c.role = "shell" if msg.get("role") == "shell" else "settings"
            if c.role == "shell":
                self.shell = c
                await self.reply(c, msg, ok=True)
                await c.send({"event": "watch", "topics": list(self.watching)})
                await c.send({"event": "phones", "phones": self.phone_list()})
            else:
                await self.reply(c, msg, ok=True, **self.status())
            return
        if op == "state" and c is self.shell:
            topic = msg.get("topic")
            if topic in TOPICS and isinstance(msg.get("data"), dict):
                await self.set_state(topic, msg["data"])
            return
        if op == "prefs" and c is self.shell:
            self.prefs = {"screen": msg.get("screen") is not False, "files": msg.get("files") is not False}
            if not self.prefs["screen"]:
                for s in list(self.screens):
                    try:
                        await s.ws.send_text(json.dumps({"t": "stopped", "reason": "off"}))
                    except ws.Closed:
                        pass
                    await s.stop()
            for p in list(self.phones):
                await p.send({"t": "caps", "caps": self.caps()})
            return
        if op == "reply" and c is self.shell:
            fut = self.calls.pop(msg.get("cid"), None)
            if fut and not fut.done():
                fut.set_result({k: msg.get(k) for k in ("ok", "data", "error", "code") if k in msg})
            return
        if op == "status":
            await self.refresh_enabled()
            await self.reply(c, msg, ok=True, **self.status())
            return
        if op == "pairing":
            if msg.get("show") and not c.showing_pairing:
                c.showing_pairing = True
                self.pairing.show()
                if not self.pair_task or self.pair_task.done():
                    self.pair_task = asyncio.ensure_future(self.pairing_tick())
            elif not msg.get("show") and c.showing_pairing:
                c.showing_pairing = False
                self.pairing.hide()
            await self.reply(c, msg, ok=True, **self.pairing_info())
            return
        if op == "rename":
            d = self.devices.rename(str(msg.get("device") or ""), msg.get("name"))
            await self.reply(c, msg, ok=bool(d))
            await self.broadcast_status()
            return
        if op == "remove":
            did = str(msg.get("device") or "")
            ok = self.devices.remove(did)
            for p in [p for p in self.phones if p.device["id"] == did]:
                await p.send({"t": "bye", "reason": "removed"})
                await p.ws.close(4401)
            for s in [s for s in self.screens if s.device["id"] == did]:
                await s.stop()
            await self.close_uploads(did)
            await self.reply(c, msg, ok=ok)
            await self.broadcast_status()
            return
        if op == "removeAll":
            self.devices.remove_all()
            for p in list(self.phones):
                await p.send({"t": "bye", "reason": "removed"})
                await p.ws.close(4401)
            for s in list(self.screens):
                await s.stop()
            await self.close_uploads()
            await self.reply(c, msg, ok=True)
            await self.broadcast_status()
            return
        if op == "stopScreen":
            for s in list(self.screens):
                if s.viewing:
                    try:
                        await s.ws.send_text(json.dumps({"t": "stopped", "reason": "stopped-by-pc"}))
                    except ws.Closed:
                        pass
                    await s.stop()
            await self.reply(c, msg, ok=True)
            return
        if op == "disconnect":
            for s in list(self.screens):
                await s.stop()
            for p in list(self.phones):
                await p.send({"t": "bye", "reason": "disconnected"})
                await p.ws.close(1000)
            await self.reply(c, msg, ok=True)
            return
        await self.reply(c, msg, ok=False, error="Unknown request")

    async def refresh_enabled(self):
        was = self.problem
        if (was and was[0] == "not-enabled" and self.enabled) or (not was and not self.enabled):
            await self.refresh()

    # ---- what Settings sees ----------------------------------------------------------------------
    def phone_list(self):
        viewing = {s.device["id"] for s in self.screens if s.viewing}
        seen, out = set(), []
        for p in self.phones:
            if p.device["id"] not in seen:
                seen.add(p.device["id"])
                out.append({"id": p.device["id"], "name": p.device["name"], "screen": p.device["id"] in viewing})
        for s in self.screens:
            if s.device["id"] not in seen:
                seen.add(s.device["id"])
                out.append({"id": s.device["id"], "name": s.device["name"], "screen": s.viewing})
        return out

    def status(self):
        conns = netinfo.connections(self.net_state)
        home = self.links[0] if self.links else None
        current = home.as_dict() if home else (conns[0] if conns else None)
        phones = self.phone_list()
        return {
            "enabled": self.enabled, "listening": bool(self.server), "port": self.port, "url": self.url(),
            "problem": {"code": self.problem[0], "message": self.problem[1]} if self.problem else None,
            "network": {"home": bool(self.links), "name": (current or {}).get("name", ""),
                        "uuid": (current or {}).get("uuid", ""), "connections": conns},
            "addresses": [str(ip) for ip in netinfo.home_ips(self.links)],
            "pcId": self.devices.pc_id, "pcName": self.name, "vm": self.vm,
            "devices": self.devices.public(),
            "connected": [p["id"] for p in phones], "screen": [p["id"] for p in phones if p["screen"]],
            "engine": os.access(paths.ENGINE, os.X_OK),
        }

    async def broadcast_status(self):
        st = None
        for c in list(self.clients):
            if c.role == "settings":
                st = st or self.status()
                await c.send(dict(st, event="status"))
        if self.shell:
            await self.shell.send({"event": "phones", "phones": self.phone_list()})

    def pairing_info(self):
        cur = self.pairing.current()
        url = self.url()
        if not cur or not url:
            return {"url": "", "code": "", "left": 0}
        return {"url": url + "/#p=" + cur[0], "code": cur[1], "left": cur[2]}

    async def pairing_tick(self):
        """While Settings shows the code, tell it when the secret rotates."""
        last = None
        while self.pairing.active:
            info = self.pairing_info()
            if info.get("code") != last:
                last = info.get("code")
                for c in list(self.clients):
                    if c.showing_pairing:
                        await c.send(dict(info, event="pairing"))
            await asyncio.sleep(1)

    # ---- shell bridge ----------------------------------------------------------------------------
    async def set_state(self, topic, data):
        if topic == "media":
            data = self.rewrite_media(data)
        elif topic in ("apps", "windows"):
            # An icon name this PC has no file for is dropped here, so the phone draws its letter tile
            # instead of asking for a picture that isn't there.
            for item in data.get(topic) or []:
                if isinstance(item, dict) and item.get("icon") and not self.icons.find(item["icon"]):
                    item["icon"] = ""
        self.state[topic] = data
        for p in list(self.phones):
            if topic in p.topics:
                await p.send({"t": "ev", "topic": topic, "data": data})
        if topic == "system" and data.get("locked"):
            for s in list(self.screens):
                s.release()

    def rewrite_media(self, data):
        player = data.get("player") if isinstance(data, dict) else None
        if not isinstance(player, dict):
            return {"player": None}
        art = str(player.get("art") or "")
        self.art = {}
        if art.startswith("file://"):
            import urllib.parse
            path = urllib.parse.unquote(art[7:])
            key = hashlib.sha256(path.encode()).hexdigest()[:16]
            if os.path.isfile(path):
                self.art[key] = path
                art = "art:" + key
            else:
                art = ""
        elif not art.startswith(("https://", "http://")):
            art = ""
        return {"player": dict(player, art=art)}

    async def update_watch(self):
        topics = sorted({t for p in self.phones for t in p.topics})
        if tuple(topics) != self.watching:
            self.watching = tuple(topics)
            if self.shell:
                await self.shell.send({"event": "watch", "topics": topics})

    async def call_shell(self, op, args, device):
        if not self.shell:
            return {"ok": False, "error": "The desktop isn't answering. Try again in a moment.", "code": "shell"}
        self.cid += 1
        cid = self.cid
        fut = asyncio.get_running_loop().create_future()
        self.calls[cid] = fut
        await self.shell.send({"event": "call", "cid": cid, "op": op, "args": args,
                               "device": {"id": device["id"], "name": device["name"]}})
        try:
            return await asyncio.wait_for(fut, CALL_TIMEOUT)
        except asyncio.TimeoutError:
            return {"ok": False, "error": "The desktop didn't answer.", "code": "timeout"}
        finally:
            self.calls.pop(cid, None)

    async def toast(self, title, sub="", kind="info", **extra):
        if self.shell:
            await self.shell.send(dict({"event": "toast", "title": title, "sub": sub, "kind": kind}, **extra))

    def screen_changed(self):
        self.screens = {s for s in self.screens if not s.closed}
        asyncio.ensure_future(self.broadcast_status())

    # ---- HTTP ------------------------------------------------------------------------------------
    async def handle_http(self, reader, writer):
        peer = writer.get_extra_info("peername") or ("", 0)
        local = writer.get_extra_info("sockname") or ("", 0)
        if not self.reach(local[0], peer[0]):
            writer.close()
            return
        try:
            while True:
                try:
                    req = await httpd.read_request(reader, peer, local)
                except httpd.BadRequest as e:
                    await httpd.send(writer, e.status, str(e), keep_alive=False)
                    break
                if req is None:
                    break
                upgraded = await self.route(req, writer)
                if upgraded or not req.keep_alive:
                    break
        except (ConnectionError, OSError, asyncio.IncompleteReadError, httpd.BadRequest):
            pass
        except Exception as e:                      # never let one request take the server down
            log("request failed: %r" % e)
        finally:
            try:
                writer.close()
            except (ConnectionError, OSError, RuntimeError):
                pass

    def security_headers(self, host):
        csp = ("default-src 'self'; img-src 'self' data: blob: http: https:; connect-src 'self' ws://%s; "
               "style-src 'self'; script-src 'self'; font-src 'self'; manifest-src 'self'; "
               "base-uri 'none'; frame-ancestors 'none'; form-action 'self'" % host)
        return [("Content-Security-Policy", csp), ("X-Content-Type-Options", "nosniff"),
                ("Referrer-Policy", "no-referrer"), ("X-Frame-Options", "DENY"),
                ("Cross-Origin-Resource-Policy", "same-origin"),        # (COOP needs HTTPS: browsers ignore it)
                ("Permissions-Policy", "camera=(), microphone=(), geolocation=()")]

    async def route(self, req, writer):
        host = req.header("host")
        try:
            expected = self.host_for(netinfo._plain(req.local[0])) if req.local[0] else None
        except ValueError:
            expected = None
        if not expected or host != expected:                 # DNS rebinding: only our own address
            await httpd.send(writer, 421, "Wrong address", keep_alive=False)
            return True
        sec = self.security_headers(host)
        path, method = req.path, req.method
        if path in ("/ws", "/ws/screen", "/ws/files"):
            await self.websocket(req, writer, host, path)
            return True
        if path == "/api/info" and method == "GET":
            await httpd.send_json(writer, 200, {"pcId": self.devices.pc_id, "name": self.name, "port": self.port,
                                                "v": 2, "pairing": self.pairing.active}, sec, req.keep_alive)
            return False
        if path == "/api/pair" and method == "POST":
            await self.pair(req, writer, sec)
            return False
        if method in ("GET", "HEAD"):
            await self.static(req, writer, sec)
            return False
        await httpd.send(writer, 405, "Not allowed", sec, req.keep_alive)
        return False

    async def static(self, req, writer, sec):
        rel = req.path.lstrip("/") or "index.html"
        if rel.endswith("/"):
            rel += "index.html"
        parts = rel.split("/")
        if any(p in ("", ".", "..") or p.startswith(".") for p in parts):
            await httpd.send(writer, 404, "Not found", sec, req.keep_alive)
            return
        root = os.path.realpath(paths.WEB)
        full = os.path.realpath(os.path.join(root, *parts))
        if not full.startswith(root + os.sep) or not os.path.isfile(full):
            if "." not in parts[-1]:                       # an app route (/apps, /running …)
                full = os.path.join(root, "index.html")
            if not os.path.isfile(full):
                await httpd.send(writer, 404, "Not found", sec, req.keep_alive)
                return
        st = os.stat(full)
        etag = '"%x-%x"' % (int(st.st_mtime), st.st_size)
        ext = os.path.splitext(full)[1].lower()
        cache = "public, max-age=604800" if ext in (".woff2", ".woff", ".ttf", ".png") else "no-cache"
        headers = sec + [("Content-Type", TYPES.get(ext, "application/octet-stream")), ("ETag", etag),
                         ("Cache-Control", cache)]
        if req.header("if-none-match") == etag:
            await httpd.send(writer, 304, b"", headers, req.keep_alive)
            return
        with open(full, "rb") as fh:
            body = fh.read()
        await httpd.send(writer, 200, body, headers, req.keep_alive, head_only=req.method == "HEAD")

    async def pair(self, req, writer, sec):
        ip = req.peer[0]

        async def answer(status, **body):
            await httpd.send_json(writer, status, body, sec, req.keep_alive)

        if not self.pairing.active:
            await answer(403, ok=False, code="expired", error="Open Settings › Command Deck on the PC to connect a phone.")
            return
        if not self.pairing.allowed(ip):
            await answer(429, ok=False, code="slow-down", error="Too many tries. Wait a minute.")
            return
        try:
            body = await req.json()
        except httpd.BadRequest as e:
            await answer(e.status, ok=False, code="bad", error=str(e))
            return
        if not isinstance(body, dict):
            await answer(400, ok=False, code="bad", error="That request wasn't readable.")
            return
        via, pub, mac = body.get("via"), body.get("pub"), body.get("mac")
        name, model = body.get("name"), body.get("model") or ""
        if not all(isinstance(x, str) for x in (pub, mac, name, model)) or len(name) > 200 or len(model) > 200 \
                or via not in ("qr", "code"):
            await answer(400, ok=False, code="bad", error="That request wasn't complete.")
            return
        raw = seal.unb64u(pub, 32)
        if not raw or seal.shared(self.devices.pc_secret, raw) is None:
            await answer(400, ok=False, code="bad-key", error="This browser couldn't make a key.")
            return
        pc_id = self.devices.pc_id
        secret_text = self.pairing.verify(via, mac, lambda s: seal.pair_mac(s, pc_id, pub, name, model))
        if not secret_text:
            await answer(403, ok=False, code="wrong" if via == "code" else "expired",
                         error="That code didn't match." if via == "code"
                         else "That code has expired. Scan the one on the PC now.")
            return
        d = self.devices.add(name, seal.b64u(raw), model)
        await answer(200, ok=True, device={"id": d["id"], "name": d["name"]}, pcId=pc_id,
                     pcPub=self.devices.pc_pub,
                     mac=seal.paired_mac(secret_text, pc_id, pub, d["id"], self.devices.pc_pub))
        for c in list(self.clients):
            if c.role == "settings":
                await c.send({"event": "paired", "device": {"id": d["id"], "name": d["name"]}})
        await self.broadcast_status()

    async def drop_device(self, did):
        for p in [p for p in self.phones if p.device["id"] == did]:
            await p.send({"t": "bye", "reason": "removed"})
            await p.ws.close(4401)
        for s in [s for s in self.screens if s.device["id"] == did]:
            await s.stop()
        await self.close_uploads(did)

    def known_icons(self):
        names = set()
        for topic, key in (("apps", "apps"), ("windows", "windows")):
            for item in (self.state.get(topic) or {}).get(key) or []:
                if isinstance(item, dict) and isinstance(item.get("icon"), str) and item["icon"]:
                    names.add(item["icon"])
        return names

    def local_op(self, op, args):
        """icon {name} / art {key}: a picture as {type, b64}. Icons only for names the shell reported for
        an app or a window (desktop entries may name any file: Icon=/path/x.png), art only for the
        current track's own local cover."""
        path, ctype = None, ""
        if op == "icon":
            name = args.get("name") if isinstance(args, dict) else None
            if isinstance(name, str) and name in self.known_icons():
                path = self.icons.find(name)
                ctype = icons.content_type(path) if path else ""
        else:
            key = args.get("key") if isinstance(args, dict) else None
            path = self.art.get(key) if isinstance(key, str) else None
            ctype = TYPES.get(os.path.splitext(path or "")[1].lower(), "image/jpeg")
        if not path:
            return {"ok": False, "error": "Not found.", "code": "not-found"}
        try:
            if os.path.getsize(path) > LOCAL_OPS[op]:
                raise OSError("too big")
            with open(path, "rb") as fh:
                data = fh.read()
        except OSError:
            return {"ok": False, "error": "Not found.", "code": "not-found"}
        return {"ok": True, "data": {"type": ctype, "b64": base64.b64encode(data).decode("ascii")}}

    async def files_socket(self, sock, device):
        """/ws/files: one file after another into Downloads (PROTOCOL.md §1)."""
        up = None
        acked = 0
        entry = (device["id"], sock)
        self.file_socks.add(entry)
        try:
            await sock.send_text(json.dumps({"t": "ready", "caps": self.caps()}))
            while True:
                op, data = await asyncio.wait_for(sock.recv(), 120)
                if op == ws.OP_BINARY:
                    if not up or data[:1] != b"D":
                        await sock.close(1008)
                        return
                    up.write(data[1:])
                    if up.done - acked >= files.ACK_EVERY or up.done == up.size:
                        acked = up.done
                        await sock.send_text(json.dumps({"t": "ack", "got": up.done}))
                    if up.done == up.size:
                        cur, up = up, None
                        try:
                            name = await cur.finish()
                        except files.UploadError as e:
                            await sock.send_text(json.dumps({"t": "failed", "code": e.code, "error": str(e)}))
                            continue
                        await sock.send_text(json.dumps({"t": "done", "name": name}))
                        await self.toast("%s sent %s" % (device["name"], name), "Saved in Downloads", "file",
                                         path=os.path.join(paths.downloads_dir(), name))
                    continue
                try:
                    msg = json.loads(data)
                except ValueError:
                    continue
                if not isinstance(msg, dict):
                    continue
                if msg.get("t") == "cancel":
                    if up:
                        up.abort()
                        up = None
                    continue
                if msg.get("t") != "file" or up:
                    continue
                why = None
                if not self.prefs["files"]:
                    why = ("off", "Sending files is turned off on this PC.")
                elif self.locked:
                    why = ("locked", "The PC is locked. Unlock it to send files.")
                if not why:
                    try:
                        up = files.Upload(msg.get("name"), msg.get("size"))
                        acked = 0
                    except files.UploadError as e:
                        why = (e.code, str(e))
                if why:
                    await sock.send_text(json.dumps({"t": "refused", "code": why[0], "error": why[1]}))
                    continue
                await sock.send_text(json.dumps({"t": "go"}))
                if up.size == 0:
                    cur, up = up, None
                    try:
                        name = await cur.finish()
                        await sock.send_text(json.dumps({"t": "done", "name": name}))
                    except files.UploadError as e:
                        await sock.send_text(json.dumps({"t": "failed", "code": e.code, "error": str(e)}))
        except files.UploadError as e:
            try:
                await sock.send_text(json.dumps({"t": "failed", "code": e.code, "error": str(e)}))
            except ws.Closed:
                pass
        except (ws.Closed, asyncio.TimeoutError):
            pass
        finally:
            self.file_socks.discard(entry)
            if up:
                up.abort()
            await sock.close()

    # ---- WebSockets ------------------------------------------------------------------------------
    async def websocket(self, req, writer, host, path):
        key = req.header("sec-websocket-key")
        if (req.method != "GET" or "websocket" not in req.header("upgrade").lower()
                or "upgrade" not in req.header("connection").lower()
                or req.header("sec-websocket-version") != "13" or not ws.valid_key(key)):
            await httpd.send(writer, 400, "WebSocket expected", keep_alive=False)
            return
        origin = "http://" + host
        if req.header("origin") != origin:
            await httpd.send(writer, 403, "Wrong origin", keep_alive=False)
            return
        writer.write(("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                      "Sec-WebSocket-Accept: %s\r\n\r\n" % ws.accept_key(key)).encode("latin-1"))
        await writer.drain()
        # A file chunk is 64 KiB + its 'D' and the seal's 16 bytes; everything else is small.
        sock = ws.WebSocket(req.reader, writer, max_size=(1 << 17) if path == "/ws/files" else (1 << 16))
        device = await self.authenticate(sock, origin)
        if not device:
            return
        self.devices.seen(device["id"])
        if path == "/ws/screen":
            await self.screen_socket(sock, device)
        elif path == "/ws/files":
            await self.files_socket(sock, device)
        else:
            await self.control_socket(sock, device, (req.peer[0], req.local[0]))

    async def authenticate(self, sock, origin):
        """hello → auth {device, cnonce, proof} → from here on sealed (seal.py). Returns the device."""
        nonce = seal.b64u(os.urandom(24))
        try:
            await sock.send_text(json.dumps({"t": "hello", "v": 2, "pcId": self.devices.pc_id, "nonce": nonce,
                                             "name": self.name}))
            op, data = await asyncio.wait_for(sock.recv(), 15)
            msg = json.loads(data) if op == ws.OP_TEXT else None
        except (ws.Closed, asyncio.TimeoutError, ValueError):
            await sock.close(1008)
            return None
        if not isinstance(msg, dict) or msg.get("t") != "auth":
            await sock.close(1008)
            return None
        d = self.devices.get(str(msg.get("device") or ""))
        cnonce = msg.get("cnonce")
        reason, sk = None, None
        if not d:
            reason = "unknown"
        else:
            k = seal.shared(self.devices.pc_secret, seal.unb64u(d["pub"], 32))
            if k is None or not isinstance(cnonce, str) or len(seal.unb64u(cnonce)) != 24:
                reason = "bad-proof"
            else:
                sk = seal.session_key(k, nonce, cnonce, origin)
                if not seal.same(msg.get("proof"), seal.proof(sk)):
                    reason = "bad-proof"
        if reason:
            try:
                await sock.send_text(json.dumps({"t": "denied", "reason": reason}))
            except ws.Closed:
                pass
            await sock.close(4401)
            return None
        sock.channel = seal.Channel(sk, seal.FROM_PC)
        return d

    def caps(self):
        engine = os.access(paths.ENGINE, os.X_OK)
        on = self.prefs["screen"]
        return {"screen": engine and on, "trackpad": engine and on, "files": self.prefs["files"], "power": True}

    async def control_socket(self, sock, device, peer):
        p = Phone(self, sock, device, peer)
        self.phones.add(p)
        await p.send({"t": "ready", "device": {"id": device["id"], "name": device["name"]},
                      "pc": {"name": self.name}, "caps": self.caps(), "modules": self.modules.public()})
        if device["id"] not in self.greeted:
            self.greeted.add(device["id"])
            await self.toast("%s connected" % device["name"], "Command Deck", "connected")
        await self.broadcast_status()
        try:
            while True:
                op, data = await asyncio.wait_for(sock.recv(), 75)
                if op != ws.OP_TEXT:
                    continue
                try:
                    msg = json.loads(data)
                except ValueError:
                    continue
                if isinstance(msg, dict):
                    await self.phone_message(p, msg)
        except (ws.Closed, asyncio.TimeoutError):
            pass
        finally:
            self.phones.discard(p)
            await sock.close()
            await self.update_watch()
            await self.broadcast_status()

    async def phone_message(self, p, msg):
        t = msg.get("t")
        if t == "ping":
            await p.send({"t": "pong"})
        elif t in ("sub", "unsub"):
            topics = [x for x in msg.get("topics") or [] if x in TOPICS]
            if t == "sub":
                new = [x for x in topics if x not in p.topics]
                p.topics.update(topics)
                await self.update_watch()
                for x in new:
                    if x in self.state:
                        await p.send({"t": "ev", "topic": x, "data": self.state[x]})
            else:
                p.topics.difference_update(topics)
                await self.update_watch()
        elif t == "call":
            rid = msg.get("id")
            res = await self.run_call(p, msg)
            await p.send(dict(res, t="res", id=rid))

    async def run_call(self, p, msg):
        mod = msg.get("mod")
        op = msg.get("op")
        if op == "forget" and not mod:
            # "Forget this PC" on the phone: the PC forgets the phone too.
            did = p.device["id"]
            self.devices.remove(did)
            asyncio.get_running_loop().call_later(0.3, lambda: asyncio.ensure_future(self.drop_device(did)))
            await self.broadcast_status()
            return {"ok": True}
        if mod:
            return await self.modules.call(self, mod, op, msg.get("args") or {}, p.device)
        if op in LOCAL_OPS:
            return self.local_op(op, msg.get("args") or {})
        args = _check_args(op, msg.get("args") or {})
        if op not in OPS:
            return {"ok": False, "error": "That isn't something Command Deck can do.", "code": "unknown-op"}
        if args is None:
            return {"ok": False, "error": "That request wasn't complete.", "code": "bad-args"}
        if self.locked and op not in LOCKED_OK:
            return {"ok": False, "error": "The PC is locked. Unlock it at the PC first.", "code": "locked"}
        if op == "launch":
            known = {a.get("id") for a in (self.state.get("apps") or {}).get("apps") or [] if isinstance(a, dict)}
            if known and args["id"] not in known:
                return {"ok": False, "error": "That app isn't on this PC.", "code": "bad-args"}
        res = await self.call_shell(op, args, p.device)
        return {k: res.get(k) for k in ("ok", "data", "error", "code") if k in res}

    async def screen_socket(self, sock, device):
        s = None
        try:
            await sock.send_text(json.dumps({"t": "ready", "device": {"id": device["id"], "name": device["name"]},
                                             "pc": {"name": self.name}, "caps": self.caps(),
                                             "locked": self.locked}))
            op, data = await asyncio.wait_for(sock.recv(), 30)
            msg = json.loads(data) if op == ws.OP_TEXT else None
            if not isinstance(msg, dict) or msg.get("t") != "start":
                await sock.close(1008)
                return
            if not self.prefs["screen"]:
                await sock.send_text(json.dumps({"t": "stopped", "reason": "off"}))
                await sock.close(1000)
                return
            if len([x for x in self.screens if not x.closed]) >= screen.MAX_SESSIONS:
                await sock.send_text(json.dumps({"t": "stopped", "reason": "busy"}))
                await sock.close(1013)
                return
            s = screen.ScreenSession(self, sock, device, msg.get("mode"), msg.get("width"), msg.get("output"))
            self.screens.add(s)
            if not await s.start():
                return
            await self.broadcast_status()
            if s.viewing:
                await self.toast("%s is viewing your screen" % device["name"], "Command Deck", "screen")
            while True:
                op, data = await sock.recv()
                if op != ws.OP_TEXT:
                    continue
                try:
                    m = json.loads(data)
                except ValueError:
                    continue
                if isinstance(m, dict):
                    s.control(m)
        except (ws.Closed, asyncio.TimeoutError, ValueError):
            pass
        finally:
            if s:
                await s.stop()
            await sock.close()
            await self.broadcast_status()

def detect_vm():
    """"microsoft", "kvm", "oracle"… when this PC is a virtual machine (Settings then explains that phones
    reach it only through a bridged network adapter), else ""."""
    try:
        r = subprocess.run(["systemd-detect-virt", "--vm"], capture_output=True, text=True, timeout=5)
    except (OSError, subprocess.SubprocessError):
        return ""
    v = r.stdout.strip()
    return "" if r.returncode or v in ("", "none") else v


def main(argv):
    if argv and argv[0] not in ("serve",):
        print("Usage: deckd [serve]", file=sys.stderr)
        return 2
    deck = Deck()

    try:
        asyncio.run(deck.run())
    except KeyboardInterrupt:
        pass
    return 0
