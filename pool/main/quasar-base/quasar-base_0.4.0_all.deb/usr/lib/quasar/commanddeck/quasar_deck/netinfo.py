"""Which networks are home networks right now, and who may reach Command Deck.

The firewall's dispatcher writes /run/quasar/firewall-net.json ({connections: [{uuid, name, type,
device, home, state}]}, state "home" only when the network's router is the one the user marked). deckd
applies the same rule itself, firewall on or off: a phone is served only when its connection arrived on
a home network's interface, from inside that link's own prefixes, and not from one of this PC's own
addresses (which rules out loopback, Docker bridges, company namespaces, the hotspot and café Wi-Fi).
"""
import ipaddress
import json
import subprocess

from . import paths


def read_net_state(path=None):
    try:
        with open(path or paths.NET_STATE, encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def device_addresses(device):
    """[ipaddress.IPv4Interface | IPv6Interface] on one interface, from `ip -j addr`."""
    try:
        r = subprocess.run([paths.IP, "-j", "addr", "show", "dev", device], capture_output=True, text=True,
                           timeout=5)
        links = json.loads(r.stdout or "[]")
    except (OSError, ValueError, subprocess.SubprocessError):
        return []
    out = []
    for link in links if isinstance(links, list) else []:
        for a in link.get("addr_info") or []:
            try:
                out.append(ipaddress.ip_interface("%s/%s" % (a["local"], a["prefixlen"])))
            except (KeyError, ValueError):
                continue
    return out


def all_addresses():
    """Every address on this PC (any interface), for "not from ourselves"."""
    try:
        r = subprocess.run([paths.IP, "-j", "addr"], capture_output=True, text=True, timeout=5)
        links = json.loads(r.stdout or "[]")
    except (OSError, ValueError, subprocess.SubprocessError):
        return set()
    out = set()
    for link in links if isinstance(links, list) else []:
        for a in link.get("addr_info") or []:
            try:
                out.add(ipaddress.ip_address(a["local"].split("%")[0]))
            except (KeyError, ValueError):
                continue
    return out


class Link:
    """One home network link: its interface, its addresses and the prefixes phones may come from."""

    def __init__(self, conn, addrs):
        self.device = conn.get("device") or ""
        self.uuid = conn.get("uuid") or ""
        self.name = conn.get("name") or ""
        self.kind = conn.get("type") or ""
        self.addrs = addrs
        # The home router's VPN ranges (Settings › Firewall › Router VPN): its clients arrive through this
        # link from their own range and count as home devices, as they do for the firewall.
        self.vpn = []
        for s in conn.get("vpn") or []:
            try:
                self.vpn.append(ipaddress.ip_network(str(s), strict=False))
            except ValueError:
                continue

    def own(self):
        return {a.ip for a in self.addrs}

    def networks(self):
        nets = []
        for a in self.addrs:
            net = a.network
            if net.version == 4:
                if not net.is_loopback and net.prefixlen >= 8:
                    nets.append(net)
            elif not net.is_loopback:
                nets.append(net.supernet(new_prefix=64) if net.prefixlen > 64 else net)
        if any(a.version == 6 for a in self.addrs):
            nets.append(ipaddress.ip_network("fe80::/10"))
        return nets + self.vpn

    def as_dict(self):
        return {"device": self.device, "uuid": self.uuid, "name": self.name, "type": self.kind,
                "addresses": [str(a.ip) for a in self.addrs]}


def home_links(state=None, addresses=device_addresses):
    """The connections that are home networks right now (state "home": the router matches)."""
    state = read_net_state() if state is None else state
    links = []
    for c in state.get("connections") or []:
        if not isinstance(c, dict) or c.get("state") != "home" or not c.get("home"):
            continue
        dev = str(c.get("device") or "")
        if not dev or dev == "lo":
            continue
        links.append(Link(c, addresses(dev)))
    return links


def connections(state=None):
    """Every active connection the firewall knows (home or not), for Settings' network row."""
    state = read_net_state() if state is None else state
    return [c for c in state.get("connections") or [] if isinstance(c, dict)]


def _plain(ip):
    """An address without its IPv6 zone, with IPv4-mapped IPv6 unwrapped."""
    if isinstance(ip, str):
        ip = ipaddress.ip_address(ip.split("%")[0])
    if ip.version == 6 and ip.ipv4_mapped:
        return ip.ipv4_mapped
    return ip


def reach_ok(local, peer, links, own=None):
    """May the phone at `peer` talk to us? `local` is the address its connection arrived on."""
    try:
        local, peer = _plain(local), _plain(peer)
    except ValueError:
        return False
    if peer.is_loopback or peer.is_unspecified or peer.is_multicast:
        return False
    if own is not None and peer in own:
        return False
    for link in links:
        if local not in link.own() or peer in link.own():
            continue
        if any(peer in net for net in link.networks() if net.version == peer.version):
            return True
    return False


def home_ips(links):
    """Addresses a phone can open this PC at: private IPv4 and ULA IPv6 on home links (phones can't use
    zone-scoped link-local addresses in a URL)."""
    out = []
    for link in links:
        for a in link.addrs:
            ip = a.ip
            if ip.version == 4 and ip.is_private and not ip.is_loopback and not ip.is_link_local:
                out.append(ip)
            elif ip.version == 6 and ip in ipaddress.ip_network("fd00::/8"):
                out.append(ip)
    seen, uniq = set(), []
    for ip in out:
        if ip not in seen:
            seen.add(ip)
            uniq.append(ip)
    return uniq


def best_ip(links):
    """The address to put in the QR code: the first home link's private IPv4 (wired before Wi-Fi), else
    its ULA address."""
    ordered = sorted(links, key=lambda l: 0 if l.kind == "ethernet" else 1)
    for link in ordered:
        for a in link.addrs:
            if a.ip.version == 4 and a.ip.is_private and not a.ip.is_link_local:
                return a.ip
    for link in ordered:
        for a in link.addrs:
            if a.ip.version == 6 and a.ip in ipaddress.ip_network("fd00::/8"):
                return a.ip
    return None


def url_host(ip):
    return "[%s]" % ip if ip.version == 6 else str(ip)
