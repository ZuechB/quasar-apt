"""quasar-commanddeck-admin: turn Command Deck on or off for an account (root, through pkexec).

  quasar-commanddeck-admin enable    stdin (optional): {"home": NM_UUID} also marks this network as home
  quasar-commanddeck-admin disable   [--uid N]  (quasar-users passes --uid when it removes an account)
  quasar-commanddeck-admin status    anyone: {"enabled": [uids]}

"enable" is ONE administrator password for everything that needs root:
  * the account is listed in /etc/quasar/commanddeck/users.json (deckd serves only listed accounts);
  * the firewall lets deckd (app:quasar-commanddeck, its own cgroup) in from home networks only, as an
    entry Quasar manages (by "commanddeck"). quasar-firewall trusts "by" only from root without pkexec,
    so it runs with PKEXEC_UID removed from its environment.
Output: JSON lines ({"type": "result", ...} or {"type": "error", "code", "message"}).
"""
import json
import os
import pwd
import subprocess
import sys

from . import paths

FIREWALL_ENTRY = {"app": "quasar-commanddeck", "name": "Command Deck", "by": "commanddeck"}


class Fail(Exception):
    def __init__(self, message, code="failed"):
        super().__init__(message)
        self.code = code


def emit(**fields):
    print(json.dumps(fields), flush=True)


def read_users():
    try:
        with open(paths.USERS, encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def enabled_uids():
    users = read_users().get("uids") or []
    return {int(u) for u in users if isinstance(u, int) or (isinstance(u, str) and u.isdigit())}


def write_users(uids):
    os.makedirs(paths.SYS_DIR, mode=0o755, exist_ok=True)
    tmp = paths.USERS + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump({"version": 1, "uids": sorted(uids)}, fh)
        fh.write("\n")
    os.chmod(tmp, 0o644)
    os.replace(tmp, paths.USERS)


def caller_uid(args):
    if "--uid" in args:
        i = args.index("--uid")
        v = args[i + 1] if i + 1 < len(args) else ""
        if not v.isdigit() or os.environ.get("PKEXEC_UID") is not None:
            raise Fail("Only Quasar's own tools may name another account.", "usage")
        return int(v)
    v = os.environ.get("PKEXEC_UID")
    if v is not None and v.isdigit():
        return int(v)
    if not paths.IS_ROOT:
        return os.getuid()
    raise Fail("Run this through pkexec.", "usage")


def check_account(uid):
    try:
        name = pwd.getpwuid(uid).pw_name
    except KeyError:
        raise Fail("That account doesn't exist.", "account")
    if uid < 1000 or name.startswith("quasar-co-") or name.startswith("site-"):
        raise Fail("Command Deck isn't available to this account.", "account")


def firewall(verb, spec=None):
    """quasar-firewall as Quasar itself (no PKEXEC_UID), so it accepts a managed entry."""
    env = {k: v for k, v in os.environ.items() if k != "PKEXEC_UID"}
    args = [paths.FIREWALL, verb]
    if verb == "unallow":
        args.append("app:" + FIREWALL_ENTRY["app"])
    try:
        r = subprocess.run(args, input=(json.dumps(spec) + "\n") if spec is not None else None,
                           capture_output=True, text=True, timeout=60, env=env)
    except (OSError, subprocess.SubprocessError) as e:
        raise Fail("The firewall couldn't be changed (%s)." % e, "firewall")
    if r.returncode != 0:
        msg = (r.stdout or r.stderr or "").strip().splitlines()
        raise Fail(msg[-1] if msg else "The firewall couldn't be changed.", "firewall")
    return r


def read_spec():
    if sys.stdin is None or sys.stdin.isatty():
        return {}
    line = sys.stdin.readline(4096)
    if not line.strip():
        return {}
    try:
        spec = json.loads(line)
    except ValueError:
        raise Fail("The request wasn't readable.", "usage")
    return spec if isinstance(spec, dict) else {}


def enable(args):
    uid = caller_uid(args)
    check_account(uid)
    spec = read_spec()
    write_users(enabled_uids() | {uid})
    entry = dict(FIREWALL_ENTRY)
    home = spec.get("home")
    if isinstance(home, str) and home:
        entry["home"] = home
    firewall("allow", entry)
    emit(type="result", enabled=True, uid=uid)
    return 0


def disable(args):
    uid = caller_uid(args)
    left = enabled_uids() - {uid}
    write_users(left)
    if not left:
        try:
            firewall("unallow")
        except Fail:
            pass
    emit(type="result", enabled=False, uid=uid)
    return 0


def status():
    emit(type="result", enabled=sorted(enabled_uids()))
    return 0


def main(argv):
    try:
        if not argv:
            raise Fail("Usage: quasar-commanddeck-admin enable|disable|status", "usage")
        if argv[0] == "enable":
            return enable(argv[1:])
        if argv[0] == "disable":
            return disable(argv[1:])
        if argv[0] == "status":
            return status()
        raise Fail("Usage: quasar-commanddeck-admin enable|disable|status", "usage")
    except Fail as e:
        emit(type="error", code=e.code, message=str(e))
        return 1
    except Exception as e:                         # a crash still answers in JSON
        emit(type="error", code="failed", message="Something went wrong: %s" % e)
        return 1
