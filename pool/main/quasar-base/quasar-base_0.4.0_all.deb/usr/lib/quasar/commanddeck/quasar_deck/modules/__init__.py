"""Server-side halves of Command Deck modules (see linux/session/commanddeck/MODULES.md).

A module that needs the PC beyond what the shell offers (an API, a local service, a file) adds
`quasar_deck/modules/<id>.py` with:

    NAME = "Spotify"                     # shown to the phone in `ready.modules`
    TOPICS = ()                          # reserved: topics it pushes (not yet wired)
    async def op_<name>(deck, args, device) -> dict   # {"ok": bool, "data"?, "error"?, "code"?}

The phone calls them with {t:"call", id, mod:"<id>", op:"<name>", args}. Ops run inside deckd as the
signed-in account, so a module is trusted code shipped with Quasar: there is no third-party loading.
Validate `args` yourself; never pass them to a shell. Built-in modules (apps, running, screen, …) need
no Python here: their ops go to the shell (server.OPS).
"""
