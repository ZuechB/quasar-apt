"""Encrypted DNS (DNS over TLS through systemd-resolved), the parts without root.

On: /etc/systemd/resolved.conf.d/60-quasar-encrypted.conf names the provider's servers with their TLS
name (`DNS=9.9.9.9#dns.quad9.net …`), `DNSOverTLS=yes` and `Domains=~.`, so every lookup that isn't for
a network's own domain goes there, encrypted. Links inherit DNSOverTLS=yes, so a network's own servers
are only ever asked over TLS (verified in QEMU: no plaintext port 53 left the PC).
Off: the same file with explicit resets. `systemctl reload systemd-resolved` doesn't drop a `Domains=~.`
that a removed file had set (seen on 257), so "off" is written, not deleted.
"""
import concurrent.futures
import errno
import ipaddress
import re
import socket
import ssl

PROVIDERS = {
    "quad9": {"name": "Quad9", "tls": "dns.quad9.net",
              "addresses": ["9.9.9.9", "149.112.112.112", "2620:fe::fe", "2620:fe::9"]},
    "cloudflare": {"name": "Cloudflare", "tls": "cloudflare-dns.com",
                   "addresses": ["1.1.1.1", "1.0.0.1", "2606:4700:4700::1111", "2606:4700:4700::1001"]},
    "mullvad": {"name": "Mullvad", "tls": "dns.mullvad.net", "addresses": ["194.242.2.2", "2a07:e340::2"]},
    "nextdns": {"name": "NextDNS", "tls": "{id}.dns.nextdns.io", "addresses": ["45.90.28.0", "45.90.30.0"]},
}
ORDER = ["quad9", "cloudflare", "mullvad", "nextdns", "custom"]
NEXTDNS_RE = re.compile(r"^[a-z0-9]{6}$")
HOST_RE = re.compile(r"^(?=.{4,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$")
MAX_ADDRESSES = 4
TLS_PORT = 853


class Bad(Exception):
    def __init__(self, reason, text=""):
        super().__init__(text or reason)
        self.reason = reason


def unicast(addr):
    try:
        ip = ipaddress.ip_address(addr)
    except ValueError:
        return None
    if ip.is_loopback or ip.is_multicast or ip.is_unspecified or ip.is_link_local or ip.is_reserved:
        return None
    return str(ip)


def choose(spec, resolve=None):
    """A request from Settings -> the config to keep: {"provider", "nextdnsId"?, "host"?, "addresses"}.
    `resolve(host)` gives addresses for a custom server named without any (quasar-net uses getaddrinfo
    while the current DNS still works). Raises Bad(reason)."""
    p = str(spec.get("provider") or "quad9")
    if p in ("quad9", "cloudflare", "mullvad"):
        return {"provider": p, "addresses": list(PROVIDERS[p]["addresses"]), "tls": PROVIDERS[p]["tls"]}
    if p == "nextdns":
        nid = str(spec.get("nextdnsId") or "").strip().lower()
        if not NEXTDNS_RE.match(nid):
            raise Bad("bad-id")
        return {"provider": p, "nextdnsId": nid, "addresses": list(PROVIDERS[p]["addresses"]),
                "tls": PROVIDERS[p]["tls"].format(id=nid)}
    if p == "custom":
        host = str(spec.get("host") or "").strip().lower().rstrip(".")
        if not HOST_RE.match(host):
            raise Bad("bad-host")
        given = spec.get("addresses") or []
        if isinstance(given, str):
            given = re.split(r"[\s,]+", given)
        addrs = [a for a in (unicast(str(x).strip()) for x in given if str(x).strip()) if a]
        if given and len(addrs) != len([x for x in given if str(x).strip()]):
            raise Bad("no-addresses", "An address isn't a usable IP address.")
        if not addrs and resolve:
            addrs = [a for a in (unicast(x) for x in resolve(host)) if a]
        addrs = list(dict.fromkeys(addrs))[:MAX_ADDRESSES]
        if not addrs:
            raise Bad("no-addresses")
        return {"provider": p, "host": host, "addresses": addrs, "tls": host}
    raise Bad("other", "unknown provider")


def dropin_on(cfg):
    servers = " ".join("%s#%s" % (a, cfg["tls"]) for a in cfg["addresses"])
    return ("# Written by quasar-net (Settings › Network & Internet › Encrypted DNS). Don't edit: it is rewritten.\n"
            "[Resolve]\nDNS=%s\nDNSOverTLS=yes\nDomains=~.\n" % servers)


def dropin_off():
    return ("# Written by quasar-net: Encrypted DNS is off (the network's own DNS). Don't edit: it is rewritten.\n"
            "[Resolve]\nDNS=\nDomains=\nDNSOverTLS=no\n")


def public(cfg):
    """What `dns status` shows (and the state file carries): no addresses for NextDNS (the ID is enough)."""
    out = {"provider": cfg.get("provider", "quad9"), "name": PROVIDERS.get(cfg.get("provider"), {}).get("name", "")}
    if cfg.get("provider") == "nextdns":
        out["nextdnsId"] = cfg.get("nextdnsId", "")
    if cfg.get("provider") == "custom":
        out["name"] = cfg.get("host", "")
        out["host"] = cfg.get("host", "")
        out["addresses"] = cfg.get("addresses", [])
    return out


# ------------------------------------------------------------------------------------------------ reach
def _probe_one(addr, name, timeout, ctx, port):
    """-> (reason, detail)"""
    fam = socket.AF_INET6 if ":" in addr else socket.AF_INET
    try:
        with socket.socket(fam, socket.SOCK_STREAM) as s:
            s.settimeout(timeout)
            s.connect((addr, port))
            with ctx.wrap_socket(s, server_hostname=name):
                return "ok", ""
    except ssl.SSLCertVerificationError as e:
        # 9 = not yet valid, 10 = expired: on a PC without network time that's the clock, not the server.
        return ("clock" if getattr(e, "verify_code", 0) in (9, 10) else "tls"), "%s: %s" % (addr, e)
    except ssl.SSLError as e:
        return "tls", "%s: %s" % (addr, e)
    except socket.timeout:
        return "blocked", "%s: no answer on port %d" % (addr, port)
    except OSError as e:
        if e.errno in (errno.ENETUNREACH, errno.EHOSTUNREACH, errno.EADDRNOTAVAIL, errno.EAFNOSUPPORT):
            return "offline", "%s: %s" % (addr, e.strerror or e)
        return "blocked", "%s: %s" % (addr, e.strerror or e)


LAST_DETAIL = ""          # why the last probe() failed, server by server (for the "Details" disclosure)


def context(cafile=None):
    """Check certificates the way systemd-resolved does (OpenSSL's defaults). Python 3.13 adds
    VERIFY_X509_STRICT, which refuses e.g. a certificate without an Authority Key Identifier that
    resolved accepts: the check before switching would then turn down a server that works."""
    ctx = ssl.create_default_context(cafile=cafile) if cafile else ssl.create_default_context()
    ctx.verify_flags &= ~getattr(ssl, "VERIFY_X509_STRICT", 0)
    return ctx


def probe(cfg, timeout=4.0, cafile=None, port=TLS_PORT):
    """Can this PC open a TLS connection (port 853, the provider's certificate) to any of the servers?
    -> "ok" | "offline" | "clock" | "tls" | "blocked". All servers are tried at once."""
    global LAST_DETAIL
    ctx = context(cafile)
    addrs = cfg["addresses"]
    with concurrent.futures.ThreadPoolExecutor(max_workers=len(addrs) or 1) as ex:
        out = list(ex.map(lambda a: _probe_one(a, cfg["tls"], timeout, ctx, port), addrs))
    results = [r for r, _ in out]
    LAST_DETAIL = "; ".join(d for _, d in out if d)
    if "ok" in results:
        return "ok"
    if all(r == "offline" for r in results):
        return "offline"
    for r in ("clock", "tls"):
        if r in results:
            return r
    return "blocked"


def encrypted(query_output):
    """`resolvectl query --cache=no NAME` printed an answer that came over an encrypted connection."""
    return "encrypted transport: yes" in query_output
