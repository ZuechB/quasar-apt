"""/run/quasar/net-state.json: what the shell's taskbar, Quick settings and toasts (and Settings) show
about VPNs, the hotspot and Encrypted DNS. Root writes it (quasar-net: the dispatcher and `dns`);
everyone reads it. Written in place under a lock: the FileViews watching it keep watching the same file.

  {"version": 1, "updated": unix,
   "vpns": [{"uuid", "name", "kind": "wireguard"|"openvpn", "device"}],     connected ones only
   "hotspot": {"on", "ssid", "device", "mode": "direct"|"concurrent", "stopped": ""|"uplink-lost"|"wifi-off"},
   "dns": {"on", "provider", "name", "reach": "ok"|"blocked"|"tls"|"clock"|"offline"|"checking"|""}}
"""
import fcntl
import json
import os
import time


def default():
    return {"version": 1, "updated": 0, "vpns": [],
            "hotspot": {"on": False, "ssid": "", "device": "", "mode": "", "stopped": ""},
            "dns": {"on": False, "provider": "", "name": "", "reach": ""}}


def read(path):
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return default()
    out = default()
    if isinstance(data, dict):
        if isinstance(data.get("vpns"), list):
            out["vpns"] = [v for v in data["vpns"] if isinstance(v, dict)]
        for k in ("hotspot", "dns"):
            if isinstance(data.get(k), dict):
                out[k].update(data[k])
        out["updated"] = data.get("updated", 0)
    return out


def write_in_place(path, state):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    data = (json.dumps(state, indent=1, sort_keys=True) + "\n").encode()
    fd = os.open(path, os.O_WRONLY | os.O_CREAT, 0o644)
    try:
        os.ftruncate(fd, 0)
        os.write(fd, data)
    finally:
        os.close(fd)


def update(path, lock, fn):
    """Read, change with fn(state) (it edits the dict), write back in place; returns the new state.
    The file is only rewritten when something changed, so watchers don't wake for nothing."""
    os.makedirs(os.path.dirname(lock), exist_ok=True)
    with open(lock, "a") as lf:
        fcntl.flock(lf, fcntl.LOCK_EX)
        st = read(path)
        before = json.dumps({k: v for k, v in st.items() if k != "updated"}, sort_keys=True)
        fn(st)
        if json.dumps({k: v for k, v in st.items() if k != "updated"}, sort_keys=True) != before:
            st["updated"] = int(time.time())
            write_in_place(path, st)
        return st
