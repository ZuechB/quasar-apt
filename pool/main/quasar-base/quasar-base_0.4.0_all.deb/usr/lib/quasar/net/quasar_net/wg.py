"""WireGuard: read a wg-quick file (what VPN providers and home servers hand out) and turn it into a
NetworkManager profile. Pure: no D-Bus here. Settings come out as {group: {key: (signature, value)}},
the shape jeepney sends as a{sa{sv}}.

Why not `nmcli connection import type wireguard`: it names the profile and the interface after the file
(an invalid interface name fails), and the new profile connects at once. Here the name is the user's,
the interface is ours (wgq + 5 hex digits), and the profile is added without connecting
(AddConnection2 with BLOCK_AUTOCONNECT)."""
import base64
import ipaddress
import re
import socket
import struct

from .const import WG_PREFIX

MAX_BYTES = 64 * 1024
KEY_RE = re.compile(r"^[A-Za-z0-9+/]{42}[AEIMQUYcgkosw480]=$")      # 32 bytes, base64
HOST_RE = re.compile(r"^[A-Za-z0-9]([A-Za-z0-9.-]{0,251}[A-Za-z0-9])?$")
DOMAIN_RE = re.compile(r"^(~?[A-Za-z0-9_]([A-Za-z0-9_-]{0,62})(\.[A-Za-z0-9_]([A-Za-z0-9_-]{0,62}))*\.?|~\.)$")
SCRIPT_KEYS = {"preup", "postup", "predown", "postdown"}
IGNORED_KEYS = {"saveconfig"}


class Bad(Exception):
    """The file isn't a usable WireGuard configuration (reason bad-config; the text says what)."""


def looks_like(text):
    """A wg-quick file has an [Interface] section with a PrivateKey."""
    return bool(re.search(r"^\s*\[\s*interface\s*\]", text, re.I | re.M)) and \
        bool(re.search(r"^\s*privatekey\s*=", text, re.I | re.M))


def _key(value, what):
    v = value.strip()
    if not KEY_RE.match(v):
        raise Bad("%s isn't a WireGuard key." % what)
    base64.b64decode(v, validate=True)
    return v


def _list(value):
    return [x.strip() for x in value.split(",") if x.strip()]


def _network(item, what):
    try:
        if "/" not in item:
            ip = ipaddress.ip_address(item)
            return ipaddress.ip_interface("%s/%d" % (ip, 32 if ip.version == 4 else 128))
        return ipaddress.ip_interface(item)
    except ValueError:
        raise Bad("%s has an address that isn't valid: %s" % (what, item))


def _endpoint(value):
    v = value.strip()
    m = re.match(r"^\[([0-9A-Fa-f:.]+)\]:(\d{1,5})$", v) or re.match(r"^([^:\s\[\]]+):(\d{1,5})$", v)
    if not m:
        raise Bad("The server address (Endpoint) isn't host:port.")
    host, port = m.group(1), int(m.group(2))
    if not 1 <= port <= 65535:
        raise Bad("The server's port isn't valid.")
    try:
        ip = ipaddress.ip_address(host)
        host = str(ip)
        shown = "[%s]:%d" % (host, port) if ip.version == 6 else "%s:%d" % (host, port)
    except ValueError:
        if not HOST_RE.match(host):
            raise Bad("The server's name isn't valid: %s" % host)
        shown = "%s:%d" % (host, port)
    return shown, host


def _int(value, lo, hi, what):
    v = value.strip().lower()
    try:
        n = int(v, 16) if v.startswith("0x") else int(v)
    except ValueError:
        raise Bad("%s isn't a number." % what)
    if not lo <= n <= hi:
        raise Bad("%s is out of range." % what)
    return n


def parse(text):
    """wg-quick text -> {"interface": {...}, "peers": [...], "notes": [...]}. Raises Bad."""
    if len(text.encode("utf-8", "replace")) > MAX_BYTES:
        raise Bad("The file is too big for a WireGuard configuration.")
    iface = {"addresses": [], "dns": [], "search": []}
    peers, notes, section, peer = [], [], None, None
    for n, raw in enumerate(text.splitlines(), 1):
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        m = re.match(r"^\[\s*([A-Za-z]+)\s*\]$", line)
        if m:
            section = m.group(1).lower()
            if section == "peer":
                peer = {"allowedIps": []}
                peers.append(peer)
            elif section != "interface":
                raise Bad("Line %d: unknown section [%s]." % (n, m.group(1)))
            continue
        if "=" not in line or section is None:
            raise Bad("Line %d isn't part of a WireGuard configuration." % n)
        k, v = line.split("=", 1)
        k = k.strip().lower()
        v = v.strip()
        if section == "interface":
            if k == "privatekey":
                iface["privateKey"] = _key(v, "The private key")
            elif k == "address":
                iface["addresses"] += [_network(x, "Address") for x in _list(v)]
            elif k == "dns":
                for x in _list(v):
                    try:
                        iface["dns"].append(ipaddress.ip_address(x))
                    except ValueError:
                        if not DOMAIN_RE.match(x):
                            raise Bad("DNS has an entry that's neither an address nor a domain: %s" % x)
                        iface["search"].append(x.rstrip(".") or ".")
            elif k == "mtu":
                iface["mtu"] = _int(v, 576, 9200, "MTU")
            elif k == "listenport":
                iface["listenPort"] = _int(v, 0, 65535, "ListenPort")
            elif k == "fwmark":
                if v.lower() != "off":
                    iface["fwmark"] = _int(v, 0, 0xFFFFFFFF, "FwMark")
            elif k == "table":
                if v.lower() == "off":
                    iface["tableOff"] = True
                elif v.lower() != "auto":
                    notes.append("table-ignored")
            elif k in SCRIPT_KEYS:
                if "scripts-ignored" not in notes:
                    notes.append("scripts-ignored")
            elif k in IGNORED_KEYS:
                pass
            else:
                raise Bad("Line %d: unknown setting %s." % (n, k))
        else:
            if k == "publickey":
                peer["publicKey"] = _key(v, "A server's public key")
            elif k == "presharedkey":
                peer["presharedKey"] = _key(v, "A preshared key")
            elif k == "allowedips":
                peer["allowedIps"] += [_network(x, "AllowedIPs").network for x in _list(v)]
            elif k == "endpoint":
                peer["endpoint"], peer["host"] = _endpoint(v)
            elif k == "persistentkeepalive":
                if v.lower() != "off":
                    peer["keepalive"] = _int(v, 0, 65535, "PersistentKeepalive")
            else:
                raise Bad("Line %d: unknown setting %s." % (n, k))
    if "privateKey" not in iface:
        raise Bad("The file has no private key.")
    if not peers:
        raise Bad("The file has no server ([Peer]).")
    for p in peers:
        if "publicKey" not in p:
            raise Bad("A server ([Peer]) has no public key.")
    if not iface["addresses"]:
        raise Bad("The file gives this PC no address (Address).")
    return {"interface": iface, "peers": peers, "notes": notes}


def covers_all(nets, version):
    """True when the networks route every address of that IP version (0.0.0.0/0, or 0/1 + 128/1…)."""
    mine = [n for n in nets if n.version == version]
    if not mine:
        return False
    whole = ipaddress.ip_network("0.0.0.0/0" if version == 4 else "::/0")
    return list(ipaddress.collapse_addresses(mine)) == [whole]


def full_tunnel(conf):
    nets = [n for p in conf["peers"] for n in p["allowedIps"]]
    return covers_all(nets, 4) or covers_all(nets, 6)


def server(conf):
    """What Settings shows as the VPN's server: the first peer's endpoint host."""
    for p in conf["peers"]:
        if p.get("host"):
            return p["host"]
    return ""


def interface_name(uuid):
    return WG_PREFIX + uuid.replace("-", "")[:5]


def _ip4_u32(ip):
    # NetworkManager's legacy ipv4.dns: in_addr_t values, i.e. network byte order in memory.
    return struct.unpack("=I", socket.inet_aton(str(ip)))[0]


def settings(conf, name, uuid):
    """The NetworkManager profile (a{sa{sv}}): not connecting by itself, its DNS used inside the tunnel
    even while Encrypted DNS is on (dns-over-tls=no), and on a full tunnel every lookup goes through it
    (~. with a negative priority; NetworkManager doesn't see WireGuard's policy-routed default route)."""
    i = conf["interface"]
    full = full_tunnel(conf)
    peers = []
    for p in conf["peers"]:
        d = {"public-key": ("s", p["publicKey"]),
             "allowed-ips": ("as", [str(n) for n in p["allowedIps"]])}
        if p.get("endpoint"):
            d["endpoint"] = ("s", p["endpoint"])
        if p.get("presharedKey"):
            d["preshared-key"] = ("s", p["presharedKey"])
            d["preshared-key-flags"] = ("u", 0)
        if p.get("keepalive"):
            d["persistent-keepalive"] = ("u", p["keepalive"])
        peers.append(d)
    wg = {"private-key": ("s", i["privateKey"]), "private-key-flags": ("u", 0), "peers": ("aa{sv}", peers)}
    if i.get("listenPort"):
        wg["listen-port"] = ("u", i["listenPort"])
    if i.get("fwmark"):
        wg["fwmark"] = ("u", i["fwmark"])
    if i.get("mtu"):
        wg["mtu"] = ("u", i["mtu"])
    if i.get("tableOff"):
        wg["peer-routes"] = ("b", False)
    v4 = [a for a in i["addresses"] if a.version == 4]
    v6 = [a for a in i["addresses"] if a.version == 6]
    dns4 = [d for d in i["dns"] if d.version == 4]
    dns6 = [d for d in i["dns"] if d.version == 6]
    search = list(i["search"])
    if full and "~." not in search:
        search.append("~.")

    def ipcfg(addrs, dns, version):
        if not addrs:
            return {"method": ("s", "disabled")}
        c = {"method": ("s", "manual"),
             "address-data": ("aa{sv}", [{"address": ("s", str(a.ip)), "prefix": ("u", a.network.prefixlen)}
                                         for a in addrs])}
        if dns:
            c["dns"] = ("au", [_ip4_u32(d) for d in dns]) if version == 4 else ("aay", [d.packed for d in dns])
        if search:
            c["dns-search"] = ("as", search)
        if full:
            c["dns-priority"] = ("i", -50)
        return c

    return {
        "connection": {"id": ("s", name), "uuid": ("s", uuid), "type": ("s", "wireguard"),
                       "interface-name": ("s", interface_name(uuid)), "autoconnect": ("b", False),
                       "dns-over-tls": ("i", 0)},
        "wireguard": wg,
        "ipv4": ipcfg(v4, dns4, 4),
        "ipv6": ipcfg(v6, dns6, 6),
    }
