"""Names shared by the helpers, NetworkManager's config (linux/system/networkmanager/conf.d/quasar.conf),
the dispatchers (55-quasar-net, 60-quasar-firewall, 90-quasar-companies) and the UI (Wifi.qml,
SystemControls.qml). Change one, change them all."""

# The one "Quasar hotspot" profile. Fixed, so NetworkManager's config can say that only this profile
# may run on the extra access-point interface ([device-quasar-ap] allowed-connections=uuid:…).
HOTSPOT_UUID = "9a3c1f2e-4b7d-4e15-8a6f-2c0d5b7e9f31"
HOTSPOT_ID = "Quasar hotspot"

# The extra interface a Wi-Fi adapter gets when it hosts the hotspot while staying connected to Wi-Fi.
AP_IFACE = "qap0"

# WireGuard interfaces made by nm-ctl: "wgq" + 5 hex digits (Linux allows 15 characters).
WG_PREFIX = "wgq"

# Encrypted DNS: the resolved drop-in quasar-net writes, and what it remembers (no secrets in either).
RESOLVED_DROPIN = "/etc/systemd/resolved.conf.d/60-quasar-encrypted.conf"
DNS_CONFIG = "/etc/quasar/dns.json"

# Live state for the shell and Settings: written in place (FileView keeps watching the same file),
# created at boot by tmpfiles (quasar-net.conf) so it can be watched from the start.
STATE_FILE = "/run/quasar/net-state.json"
STATE_LOCK = "/run/quasar/net-state.lock"
