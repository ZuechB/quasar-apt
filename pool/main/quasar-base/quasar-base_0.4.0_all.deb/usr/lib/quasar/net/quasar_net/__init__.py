"""Quasar's VPN, Mobile hotspot and Encrypted DNS (Settings › Network & Internet).

Installed to /usr/lib/quasar/net. Two entry points share it:
  /usr/libexec/quasar/nm-ctl       as the user: VPN and hotspot profiles over NetworkManager's D-Bus
  /usr/libexec/quasar/quasar-net   root through pkexec (org.quasar.net): Encrypted DNS (systemd-resolved)
                                   and the hotspot's extra Wi-Fi interface; plus `dispatch` for
                                   NetworkManager's dispatcher (55-quasar-net)
The pure parts (wg, ovpn, wifi, dns, reasons) import nothing outside the standard library, so the
tests run them without jeepney or NetworkManager.
"""
