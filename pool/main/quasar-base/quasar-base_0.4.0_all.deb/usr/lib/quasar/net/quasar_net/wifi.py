"""Mobile hotspot, the pure parts: what an adapter can do (from `iw phy <phy> info`), which adapter
and channel to use, the profile, and the default name and password.

Two ways to host (the plan's `mode`):
  direct      an access-point-capable adapter that isn't carrying the internet becomes the hotspot
              (sharing a cable, a phone over USB, or a second Wi-Fi adapter).
  concurrent  the adapter that IS the internet (a Wi-Fi connection) also hosts, on an extra interface
              (qap0, made by `quasar-net ap-add`), when its interface combinations allow a station and
              an access point at once. With one channel to share (#channels <= 1) the hotspot has to
              sit on the station's channel; DFS/radar, no-IR and 6 GHz channels can't host.
"""
import re
import secrets

from .const import AP_IFACE, HOTSPOT_ID, HOTSPOT_UUID

# NM_WIFI_DEVICE_CAP_AP (NetworkManager's WirelessCapabilities)
NM_CAP_AP = 0x40
NM_CAP_FREQ_5GHZ = 0x400
ALPHABET = "abcdefghijkmnpqrstuvwxyz23456789"       # no l/1, o/0: read off a screen, typed on a phone


# ------------------------------------------------------------------------------------------------ iw
def parse_phy(text):
    """`iw phy <phy> info` -> {"modes": set, "combinations": [{"limits": [(max, set)], "total", "channels"}],
    "channels": [{"mhz", "ch", "flags": set}]}. Unknown lines are ignored."""
    modes, combos, chans = set(), [], []
    lines = text.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        s = line.strip()
        if s == "Supported interface modes:":
            ind = len(line) - len(line.lstrip())
            i += 1
            while i < len(lines) and lines[i].strip().startswith("*") and \
                    len(lines[i]) - len(lines[i].lstrip()) > ind:
                modes.add(lines[i].strip()[1:].strip())
                i += 1
            continue
        if s.lower().startswith("valid interface combinations"):
            ind = len(line) - len(line.lstrip())
            i += 1
            cur = None
            while i < len(lines) and len(lines[i]) - len(lines[i].lstrip()) > ind and lines[i].strip():
                t = lines[i].strip()
                if t.startswith("*"):
                    if cur:
                        combos.append(_combo(cur))
                    cur = t[1:].strip()
                elif cur is not None:
                    cur += " " + t
                i += 1
            if cur:
                combos.append(_combo(cur))
            continue
        m = re.match(r"^\*\s+(\d+)(?:\.\d+)?\s+MHz\s+\[(\d+)\](.*)$", s)
        if m:
            flags = set()
            for grp in re.findall(r"\(([^)]*)\)", m.group(3)):
                for f in grp.split(","):
                    f = f.strip().lower()
                    if f and not f.endswith("dbm"):
                        flags.add(f)
            chans.append({"mhz": int(m.group(1)), "ch": int(m.group(2)), "flags": flags})
        i += 1
    return {"modes": modes, "combinations": combos, "channels": chans}


def _combo(text):
    limits = [(int(n), {t.strip() for t in types.split(",") if t.strip()})
              for types, n in re.findall(r"#\{\s*([^}]*)\}\s*<=\s*(\d+)", text)]
    total = re.search(r"total\s*<=\s*(\d+)", text)
    chans = re.search(r"#channels\s*<=\s*(\d+)", text)
    return {"limits": limits, "total": int(total.group(1)) if total else 1,
            "channels": int(chans.group(1)) if chans else 1}


def concurrency(phy):
    """How many channels a station + access point pair may use at once on this adapter (0 = it can't
    host while it's connected to Wi-Fi)."""
    best = 0
    for c in phy["combinations"]:
        if c["total"] < 2:
            continue
        sta = [n for n, t in c["limits"] if "managed" in t]
        ap = [n for n, t in c["limits"] if "AP" in t]
        if not sta or not ap:
            continue
        shared = [n for n, t in c["limits"] if "managed" in t and "AP" in t]
        separate = any("managed" in t for n, t in c["limits"] if "AP" not in t) and \
            any("AP" in t for n, t in c["limits"] if "managed" not in t)
        if separate or (shared and max(shared) >= 2):
            best = max(best, c["channels"])
    return best


def freq_band(mhz):
    if 2400 <= mhz < 2500:
        return "bg"
    if 4900 <= mhz < 5900:
        return "a"
    return ""           # 6 GHz and anything odd: never hosts here


def channel_ok(phy, mhz):
    """Can an access point start on this frequency? (Not disabled, no "no IR", no radar/DFS, not 6 GHz.)"""
    if not freq_band(mhz):
        return False
    for c in phy["channels"]:
        if c["mhz"] == mhz:
            bad = {"disabled", "no ir", "no-ir", "radar detection", "passive scanning", "passive scan"}
            return not (c["flags"] & bad)
    return False


def channel_of(mhz):
    if mhz == 2484:
        return 14
    if 2412 <= mhz <= 2472:
        return (mhz - 2407) // 5
    if 5000 <= mhz < 5900:
        return (mhz - 5000) // 5
    return 0


def can_5ghz(phy):
    return any(freq_band(c["mhz"]) == "a" and channel_ok(phy, c["mhz"]) for c in phy["channels"])


# ------------------------------------------------------------------------------------------------ plan
def plan(state):
    """Pick how to host. `state` (gathered by nm-ctl):
        {"radio": bool (Wi-Fi on), "hardBlocked": bool, "dnsmasq": bool,
         "wifi": [{"iface", "ap": bool, "station": bool, "freq": MHz of the station's network (0),
                   "phy": parse_phy() result or None, "fiveGhz": bool}],
         "uplink": {"iface", "kind": "wifi"|"ethernet"|"usb"|"mobile"|"other", "name"} or None}
    -> {"possible": True, "device", "mode", "uplink", "bands", "channel", "band", "bandFixed"}
       or {"possible": False, "reason"}."""
    wifi = [w for w in state.get("wifi") or [] if w.get("iface") != AP_IFACE]
    if not wifi:
        return {"possible": False, "reason": "no-wifi"}
    if state.get("hardBlocked"):
        return {"possible": False, "reason": "blocked"}
    if not state.get("radio", True):
        return {"possible": False, "reason": "wifi-off"}
    hosts = [w for w in wifi if w.get("ap")]
    if not hosts:
        return {"possible": False, "reason": "no-ap"}
    if not state.get("dnsmasq", True):
        return {"possible": False, "reason": "no-dnsmasq"}
    up = state.get("uplink")
    if not up:
        return {"possible": False, "reason": "offline"}
    # Direct: an adapter that isn't the internet (an idle one first; a Wi-Fi it's on is dropped).
    direct = [w for w in hosts if w["iface"] != up.get("iface")]
    direct.sort(key=lambda w: 1 if w.get("station") else 0)
    if direct:
        w = direct[0]
        bands = ["bg"] + (["a"] if w.get("fiveGhz") or (w.get("phy") and can_5ghz(w["phy"])) else [])
        # dropsWifi: that adapter is on a Wi-Fi network now (not the internet): hosting leaves it.
        return {"possible": True, "device": w["iface"], "mode": "direct", "uplink": up, "bands": bands,
                "channel": 0, "band": "bg", "bandFixed": False, "dropsWifi": bool(w.get("station"))}
    # Concurrent: the adapter carrying the internet hosts too, if it can.
    w = next((x for x in hosts if x["iface"] == up.get("iface")), None)
    if not w or up.get("kind") != "wifi" or not w.get("phy"):
        return {"possible": False, "reason": "same-adapter"}
    n = concurrency(w["phy"])
    if n < 1:
        return {"possible": False, "reason": "same-adapter"}
    freq = w.get("freq") or 0
    if freq and channel_ok(w["phy"], freq):
        ch, band = channel_of(freq), freq_band(freq)
    elif n >= 2 and channel_ok(w["phy"], 2437):
        ch, band = 6, "bg"
    else:
        return {"possible": False, "reason": "channel"}
    return {"possible": True, "device": w["iface"], "mode": "concurrent", "uplink": up, "bands": [band],
            "channel": ch, "band": band, "bandFixed": True}


# ------------------------------------------------------------------------------------------------ profile
def new_password():
    return "-".join("".join(secrets.choice(ALPHABET) for _ in range(4)) for _ in range(3))


def new_ssid():
    return "Quasar-%04d" % secrets.randbelow(10000)


def valid_ssid(s):
    return isinstance(s, str) and 1 <= len(s.encode("utf-8")) <= 32 and all(c.isprintable() for c in s)


def valid_password(p):
    return isinstance(p, str) and 8 <= len(p) <= 63 and all(32 <= ord(c) < 127 for c in p)


def settings(ssid, password, band="bg", channel=0, iface=""):
    """The "Quasar hotspot" profile (a{sa{sv}}): WPA2-PSK (AES), the PC shares its connection (NAT +
    DHCP/DNS by NetworkManager's dnsmasq), never starts by itself, the password stays root-only."""
    wl = {"ssid": ("ay", ssid.encode("utf-8")), "mode": ("s", "ap"), "band": ("s", band if band in ("a", "bg") else "bg")}
    if channel:
        wl["channel"] = ("u", int(channel))
    conn = {"id": ("s", HOTSPOT_ID), "uuid": ("s", HOTSPOT_UUID), "type": ("s", "802-11-wireless"),
            "autoconnect": ("b", False)}
    if iface:
        conn["interface-name"] = ("s", iface)
    return {
        "connection": conn,
        "802-11-wireless": wl,
        "802-11-wireless-security": {"key-mgmt": ("s", "wpa-psk"), "psk": ("s", password), "psk-flags": ("u", 0),
                                     "proto": ("as", ["rsn"]), "pairwise": ("as", ["ccmp"]), "group": ("as", ["ccmp"])},
        "ipv4": {"method": ("s", "shared")},
        "ipv6": {"method": ("s", "ignore")},
    }


def derived_mac(mac):
    """A locally administered address for qap0, from the adapter's own (two interfaces on one radio can't
    share a MAC)."""
    b = [int(x, 16) for x in mac.split(":")]
    b[0] = (b[0] | 0x02) & 0xFE
    b[5] ^= 0x01
    return ":".join("%02x" % x for x in b)
