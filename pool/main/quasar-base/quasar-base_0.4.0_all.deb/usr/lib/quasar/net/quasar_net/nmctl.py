"""nm-ctl: VPN and Mobile hotspot profiles for Settings and the shell. Runs as the user; NetworkManager's
polkit rules decide (Debian's: active local sudo/netdev members may change system profiles).

  nm-ctl list                         VPNs and the hotspot, one JSON line
  nm-ctl vpn-import                   stdin {"path", "name"?}: a WireGuard (.conf) or OpenVPN (.ovpn) file
  nm-ctl vpn-secrets                  stdin {"uuid", "user"?, "password"?, "keyPassword"?}
  nm-ctl vpn-up|vpn-down|vpn-remove UUID
  nm-ctl vpn-set                      stdin {"uuid", "name"?, "autostart"?}
  nm-ctl hotspot-plan                 how the hotspot would run now (or why it can't)
  nm-ctl hotspot-start                stdin {"band"?} (may run `pkexec quasar-net ap-add`)
  nm-ctl hotspot-stop
  nm-ctl hotspot-show                 {"ssid", "password", "band"}; makes the profile on first use
  nm-ctl hotspot-set                  stdin {"ssid"?, "password"?, "newPassword"?: true, "band"?}
  nm-ctl hotspot-devices              who's connected now

Secrets only ever come on stdin. Output: JSON lines, {"event": …} while working, then one
{"result": …}. Exit 0 = done, 1 = {"result": "failed", "reason": <reasons.py code>, "detail"}, 64 = usage.
"""
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import uuid as uuidlib

from . import ovpn, wg, wifi
from .const import AP_IFACE, HOTSPOT_UUID

try:
    from . import nm
    JEEPNEY = True
except ImportError:            # python3-jeepney missing: every verb fails the same way
    JEEPNEY = False

NMCLI = os.environ.get("QUASAR_NM_CTL_NMCLI", "nmcli")
IW = os.environ.get("QUASAR_NM_CTL_IW", "/usr/sbin/iw")
NET_HELPER = os.environ.get("QUASAR_NET", "")          # tests: a fake quasar-net instead of pkexec
OPENVPN_PLUGIN = os.environ.get("QUASAR_NM_CTL_OPENVPN", "/usr/lib/NetworkManager/VPN/nm-openvpn-service.name")
DNSMASQ = os.environ.get("QUASAR_NM_CTL_DNSMASQ", "/usr/sbin/dnsmasq")
SYS_NET = os.environ.get("QUASAR_NM_CTL_SYSFS", "/sys/class/net")
CLIENTS = os.environ.get("QUASAR_NM_CTL_CLIENTS", "/run/quasar/hotspot-clients.json")
CERT_DIR = os.path.join(os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share"),
                        "networkmanagement", "certificates", "nm-openvpn")
OPENVPN_SERVICE = "org.freedesktop.NetworkManager.openvpn"
USB_DRIVERS = {"rndis_host", "cdc_ether", "cdc_ncm", "ipheth", "cdc_mbim", "huawei_cdc_ncm", "qmi_wwan"}
MAX_FILE = 256 * 1024


class Failed(Exception):
    def __init__(self, reason, detail=""):
        super().__init__(detail or reason)
        self.reason = reason
        self.detail = detail


class Usage(Exception):
    pass


def say(obj):
    print(json.dumps(obj), flush=True)


def read_spec():
    line = sys.stdin.readline(65536)
    if not line.strip():
        return {}
    try:
        spec = json.loads(line)
    except ValueError:
        raise Usage()
    if not isinstance(spec, dict):
        raise Usage()
    return spec


def clean_name(s, fallback="VPN"):
    s = "".join(ch for ch in str(s or "") if ch.isprintable()).strip()
    return s[:40] or fallback


def v(settings, group, key, default=None):
    """A value out of a{sa{sv}} settings (variants are (signature, value) pairs)."""
    x = settings.get(group, {}).get(key)
    return x[1] if isinstance(x, tuple) else default


# ------------------------------------------------------------------------------------------------ VPN
def vpn_kind(s):
    t = v(s, "connection", "type", "")
    if t == "wireguard":
        return "wireguard"
    if t == "vpn" and v(s, "vpn", "service-type", "") == OPENVPN_SERVICE:
        return "openvpn"
    return None


def vpn_server(s, kind):
    if kind == "wireguard":
        for p in v(s, "wireguard", "peers", []) or []:
            ep = p.get("endpoint", ("s", ""))[1]
            if ep:
                return ep.rsplit(":", 1)[0].strip("[]")
        return ""
    remote = (v(s, "vpn", "data", {}) or {}).get("remote", "")
    first = remote.split(",")[0].strip()
    return re.split(r"[:\s]", first)[0] if first else ""


def vpn_needs(s, kind):
    if kind != "openvpn":
        return []
    data = v(s, "vpn", "data", {}) or {}
    needs = []
    if data.get("connection-type", "tls") in ("password", "password-tls"):
        if not data.get("username"):
            needs.append("user")
        if data.get("password-flags", "1") != "0":
            needs.append("password")
    if data.get("cert-pass-flags") not in (None, "0", "4"):
        needs.append("keyPassword")
    return needs


def vpn_entry(s, act):
    kind = vpn_kind(s)
    uuid = v(s, "connection", "uuid", "")
    a = act.get(uuid)
    state = "off"
    if a:
        state = "on" if a["state"] == nm.AC_ACTIVATED else "connecting" if a["state"] == nm.AC_ACTIVATING else "off"
    return {"uuid": uuid, "name": v(s, "connection", "id", ""), "kind": kind, "server": vpn_server(s, kind),
            "state": state, "fullTunnel": "~." in (v(s, "ipv4", "dns-search", []) or []),
            "autostart": bool(v(s, "connection", "autoconnect", True)) if kind == "wireguard" else False,
            "needs": vpn_needs(s, kind)}


def verb_list(router):
    act = nm.active(router)
    vpns, hotspot = [], {"saved": False, "state": "off", "ssid": "", "band": "bg", "device": "", "mode": ""}
    for _path, s in nm.connections(router):
        if vpn_kind(s):
            vpns.append(vpn_entry(s, act))
        elif v(s, "connection", "uuid", "") == HOTSPOT_UUID:
            hotspot.update(saved=True, ssid=bytes(v(s, "802-11-wireless", "ssid", b"")).decode("utf-8", "replace"),
                           band=v(s, "802-11-wireless", "band", "bg") or "bg")
    a = act.get(HOTSPOT_UUID)
    if a and a["state"] in (nm.AC_ACTIVATING, nm.AC_ACTIVATED):
        dev = nm.iface_of(router, a["devices"][0]) if a["devices"] else ""
        hotspot.update(state="on" if a["state"] == nm.AC_ACTIVATED else "starting", device=dev,
                       mode="concurrent" if dev == AP_IFACE else "direct")
    vpns.sort(key=lambda x: x["name"].lower())
    say({"result": "ok", "vpns": vpns, "hotspot": hotspot})


def unique_name(router, name):
    taken = {v(s, "connection", "id", "") for _p, s in nm.connections(router) if vpn_kind(s)}
    if name not in taken:
        return name
    n = 2
    while "%s %d" % (name, n) in taken:
        n += 1
    return "%s %d" % (name, n)


def verb_vpn_import(router, spec):
    path = str(spec.get("path") or "")
    if not path or not os.path.isfile(path):
        raise Failed("unreadable", os.path.basename(path))
    try:
        if os.path.getsize(path) > MAX_FILE:
            raise Failed("too-big")
        with open(path, "rb") as f:
            text = f.read().decode("utf-8")
    except (OSError, UnicodeDecodeError) as e:
        raise Failed("unreadable", str(e))
    stem = os.path.splitext(os.path.basename(path))[0]
    name = unique_name(router, clean_name(spec.get("name") or stem.replace("_", " ")))
    if wg.looks_like(text):
        try:
            conf = wg.parse(text)
        except wg.Bad as e:
            raise Failed("bad-config", str(e))
        uuid = str(uuidlib.uuid4())
        try:
            nm.add(router, wg.settings(conf, name, uuid))
        except nm.Error as e:
            raise Failed("nm-refused", str(e))
        say({"result": "ok", "uuid": uuid, "name": name, "kind": "wireguard", "needs": [], "notes": conf["notes"],
             "fullTunnel": wg.full_tunnel(conf)})
        return
    if ovpn.looks_like(text):
        import_openvpn(router, text, os.path.dirname(os.path.abspath(path)), name)
        return
    raise Failed("not-vpn")


def import_openvpn(router, text, base, name):
    if not os.path.exists(OPENVPN_PLUGIN):
        raise Failed("no-openvpn")
    try:
        prof = ovpn.sanitize(text, base)
    except ovpn.Bad as e:
        raise Failed(e.reason, str(e))
    # nmcli names the profile and its certificate files after the file: a unique name keeps two
    # "client.ovpn" imports from overwriting each other's certificates (we rename the profile after).
    runtime = os.environ.get("XDG_RUNTIME_DIR") or tempfile.gettempdir()
    tmp = tempfile.mkdtemp(prefix="quasar-vpn-", dir=runtime)
    try:
        os.chmod(tmp, 0o700)
        f = os.path.join(tmp, "%s-%s.ovpn" % (ovpn.safe_name(name), uuidlib.uuid4().hex[:6]))
        with open(os.open(f, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600), "w", encoding="utf-8") as out:
            out.write(prof["text"])
        r = subprocess.run([NMCLI, "connection", "import", "type", "openvpn", "file", f],
                           capture_output=True, text=True, timeout=60)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    m = re.search(r"\(([0-9a-fA-F-]{36})\)", r.stdout)
    if r.returncode or not m:
        raise Failed("nm-refused", (r.stderr or r.stdout).strip()[:300])
    uuid = m.group(1).lower()
    path = nm.by_uuid(router, uuid)
    s = nm.get_settings(router, path, ("vpn",))
    s["connection"]["id"] = ("s", name)
    s["connection"]["autoconnect"] = ("b", False)
    s["connection"]["dns-over-tls"] = ("i", 0)
    data = dict(v(s, "vpn", "data", {}) or {})
    secrets_ = dict(v(s, "vpn", "secrets", {}) or {})
    data["password-flags"] = "0" if prof["password"] else "1"
    if prof["user"]:
        data["username"] = prof["user"]
    if prof["password"]:
        secrets_["password"] = prof["password"]
    data.pop("challenge-response-flags", None)
    s["vpn"]["data"] = ("a{ss}", data)
    s["vpn"]["secrets"] = ("a{ss}", secrets_)
    if prof["fullTunnel"]:
        for fam in ("ipv4", "ipv6"):
            s.setdefault(fam, {})
            s[fam]["dns-search"] = ("as", ["~."])
            s[fam]["dns-priority"] = ("i", -50)
    try:
        nm.update(router, path, s)
    except nm.Error as e:
        try:
            nm.delete(router, path)
        finally:
            raise Failed("nm-refused", str(e))
    needs = [n for n in prof["needs"] if not (n == "user" and prof["user"]) and not (n == "password" and prof["password"])]
    say({"result": "ok", "uuid": uuid, "name": name, "kind": "openvpn", "needs": needs, "notes": prof["notes"],
         "fullTunnel": prof["fullTunnel"]})


def find(router, uuid):
    if not re.match(r"^[0-9a-fA-F-]{36}$", uuid or ""):
        raise Usage()
    path = nm.by_uuid(router, uuid)
    if not path:
        raise Failed("not-found")
    return path


def verb_vpn_secrets(router, spec):
    path = find(router, str(spec.get("uuid", "")))
    s = nm.get_settings(router, path, ("vpn",))
    if vpn_kind(s) != "openvpn":
        say({"result": "ok"})
        return
    data = dict(v(s, "vpn", "data", {}) or {})
    sec = dict(v(s, "vpn", "secrets", {}) or {})
    if spec.get("user") is not None:
        data["username"] = clean_name(spec["user"], "")[:128]
    if spec.get("password") is not None:
        sec["password"] = str(spec["password"])
        data["password-flags"] = "0"
    if spec.get("keyPassword") is not None:
        sec["cert-pass"] = str(spec["keyPassword"])
        data["cert-pass-flags"] = "0"
    s["vpn"]["data"] = ("a{ss}", data)
    s["vpn"]["secrets"] = ("a{ss}", sec)
    nm.update(router, path, s)
    say({"result": "ok"})


# NMActiveConnectionStateReason / NMVpnConnectionStateReason (same numbers for 0-11)
VPN_REASONS = {9: "needs-secrets", 10: "password", 6: "unreachable", 7: "unreachable", 4: "service", 8: "service",
               3: "no-network", 11: "not-found"}


def verb_vpn_up(router, uuid):
    path = find(router, uuid)
    s = nm.get_settings(router, path)
    kind = vpn_kind(s)
    if not kind:
        raise Failed("not-found")
    if "password" in vpn_needs(s, kind) or "user" in vpn_needs(s, kind):
        raise Failed("needs-secrets")
    act = nm.active(router)
    for other, a in act.items():                    # one VPN at a time
        if other != uuid and (a["vpn"] or a["type"] == "wireguard"):
            nm.deactivate(router, a["path"])
    say({"event": "activating"})
    try:
        how, info = nm.activate(router, path, "/", timeout=90)
    except nm.Error as e:
        raise Failed("no-network" if "NoDevice" in e.name or "not available" in str(e) else "other", str(e))
    if how == "up":
        say({"result": "connected", "device": nm.iface_of(router, info) if info != "/" else ""})
        return
    if how == "timeout":
        raise Failed("timeout")
    reason = VPN_REASONS.get(info["vpn"]) or VPN_REASONS.get(info["ac"]) or "other"
    # A refused OpenVPN password comes back as no-secrets, not login-failed: the plugin asks again and
    # there's no secret agent to answer (seen in QEMU). With a password saved, that means it was refused.
    data = v(s, "vpn", "data", {}) or {}
    if reason == "needs-secrets" and kind == "openvpn" and data.get("password-flags") == "0":
        reason = "password"
    if reason == "password" and kind == "openvpn":         # don't keep a refused password
        s = nm.get_settings(router, path, ("vpn",))
        data = dict(v(s, "vpn", "data", {}) or {})
        sec = dict(v(s, "vpn", "secrets", {}) or {})
        sec.pop("password", None)
        data["password-flags"] = "1"
        s["vpn"]["data"] = ("a{ss}", data)
        s["vpn"]["secrets"] = ("a{ss}", sec)
        try:
            nm.update(router, path, s)
        except nm.Error:
            pass
    raise Failed(reason, "vpn reason %d, connection reason %d" % (info["vpn"], info["ac"]))


def verb_vpn_down(router, uuid):
    find(router, uuid)
    a = nm.active(router).get(uuid)
    if a:
        nm.deactivate(router, a["path"])
    say({"result": "disconnected"})


def verb_vpn_remove(router, uuid):
    path = find(router, uuid)
    s = nm.get_settings(router, path)
    a = nm.active(router).get(uuid)
    if a:
        nm.deactivate(router, a["path"])
    nm.delete(router, path)
    # The OpenVPN plugin's copies of this profile's certificates and keys (only from its own folder).
    data = v(s, "vpn", "data", {}) or {}
    root = os.path.realpath(CERT_DIR)
    for k in ("ca", "cert", "key", "ta", "tls-crypt", "tls-crypt-v2", "pkcs12", "extra-certs"):
        p = data.get(k)
        if p and os.path.dirname(os.path.realpath(p)) == root:
            try:
                os.remove(p)
            except OSError:
                pass
    say({"result": "ok"})


def verb_vpn_set(router, spec):
    path = find(router, str(spec.get("uuid", "")))
    s = nm.get_settings(router, path, ("vpn", "wireguard"))
    kind = vpn_kind(s)
    if spec.get("name") is not None:
        s["connection"]["id"] = ("s", clean_name(spec["name"]))
    if spec.get("autostart") is not None and kind == "wireguard":
        s["connection"]["autoconnect"] = ("b", bool(spec["autostart"]))
    nm.update(router, path, s)
    say({"result": "ok"})


# ------------------------------------------------------------------------------------------------ hotspot
def _read(path):
    try:
        with open(path, encoding="utf-8") as f:
            return f.read().strip()
    except OSError:
        return ""


def phy_info(iface):
    phy = _read(os.path.join(SYS_NET, iface, "phy80211", "name"))
    if not phy:
        return None
    try:
        r = subprocess.run([IW, "phy", phy, "info"], capture_output=True, text=True, timeout=10)
    except (OSError, subprocess.SubprocessError):
        return None
    return wifi.parse_phy(r.stdout) if r.returncode == 0 else None


def gather(router):
    """What wifi.plan() needs, from NetworkManager and the adapters."""
    m = nm.props(router, nm.NM_PATH, nm.NM)
    act = nm.active(router)
    hotspot_devs = set(act.get(HOTSPOT_UUID, {}).get("devices", []))
    devs, ifaces = [], {}
    for d in nm.call(router, nm.NM_PATH, nm.NM, "GetDevices")[0]:
        try:
            p = nm.props(router, d, nm.NM + ".Device")
        except nm.Error:
            continue
        ifaces[d] = p
        if p.get("DeviceType") != nm.DT_WIFI or not p.get("Managed"):
            continue
        w = nm.props(router, d, nm.NM + ".Device.Wireless")
        caps = w.get("WirelessCapabilities", 0)
        freq = 0
        apath = w.get("ActiveAccessPoint", "/")
        station = w.get("Mode") == 2 and p.get("State") == nm.DEVICE_ACTIVATED and d not in hotspot_devs
        if station and apath and apath != "/":
            try:
                freq = nm.prop(router, apath, nm.NM + ".AccessPoint", "Frequency")
            except nm.Error:
                freq = 0
        devs.append({"iface": p.get("Interface", ""), "ap": bool(caps & wifi.NM_CAP_AP), "station": station,
                     "freq": freq, "fiveGhz": bool(caps & wifi.NM_CAP_FREQ_5GHZ), "phy": phy_info(p.get("Interface", ""))})
    uplink = None
    prim = m.get("PrimaryConnection", "/")
    cands = []
    for uuid, a in act.items():
        if uuid == HOTSPOT_UUID or a["vpn"] or a["type"] in ("wireguard", "tun", "loopback", "bridge", "vpn") \
                or a["state"] != nm.AC_ACTIVATED or not a["devices"]:
            continue
        cands.append(a)
    cands.sort(key=lambda a: (a["path"] != prim, not a["default"]))
    if cands:
        a = cands[0]
        p = ifaces.get(a["devices"][0], {})
        kind = {"802-11-wireless": "wifi", "802-3-ethernet": "ethernet", "gsm": "mobile", "cdma": "mobile"}.get(a["type"], "other")
        if kind == "ethernet" and p.get("Driver") in USB_DRIVERS:
            kind = "usb"
        uplink = {"iface": p.get("Interface", ""), "kind": kind, "name": a["id"]}
    return {"radio": bool(m.get("WirelessEnabled", True)), "hardBlocked": not m.get("WirelessHardwareEnabled", True),
            "dnsmasq": os.path.exists(DNSMASQ), "wifi": devs, "uplink": uplink}


def verb_hotspot_plan(router):
    p = wifi.plan(gather(router))
    p = dict(p, result="ok")
    say(p)


def hotspot_profile(router, create=True):
    """(path, ssid, password, band) of the one hotspot profile; made with a new name and password the
    first time it's needed."""
    path = nm.by_uuid(router, HOTSPOT_UUID)
    if not path:
        if not create:
            return None, "", "", "bg"
        ssid, pw = wifi.new_ssid(), wifi.new_password()
        path = nm.add(router, wifi.settings(ssid, pw))
        return path, ssid, pw, "bg"
    s = nm.get_settings(router, path, ("802-11-wireless-security",))
    ssid = bytes(v(s, "802-11-wireless", "ssid", b"")).decode("utf-8", "replace")
    return path, ssid, v(s, "802-11-wireless-security", "psk", "") or "", v(s, "802-11-wireless", "band", "bg") or "bg"


def net_helper(args):
    cmd = ([NET_HELPER] if NET_HELPER else ["pkexec", "/usr/libexec/quasar/quasar-net"]) + list(args)
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
    except (OSError, subprocess.SubprocessError) as e:
        raise Failed("other", str(e))
    if r.returncode == 126:
        raise Failed("cancelled")
    if r.returncode == 127:
        raise Failed("not-allowed")
    last = {}
    for line in r.stdout.splitlines():
        try:
            last = json.loads(line)
        except ValueError:
            continue
    if r.returncode:
        raise Failed("ap-refused" if last.get("reason") in ("no-ap", "not-station", "not-wifi") else "other",
                     last.get("detail") or r.stderr.strip()[:300])
    return last


DEVICE_HOTSPOT_REASONS = {9: "ap-refused", 10: "ap-refused", 11: "ap-refused", 18: "other", 19: "other"}


def start_hotspot(router, band=None):
    st = gather(router)
    p = wifi.plan(st)
    if not p["possible"]:
        raise Failed(p["reason"])
    say({"event": "plan", "mode": p["mode"], "device": p["device"]})
    path, ssid, pw, saved_band = hotspot_profile(router)
    band = p["band"] if p["bandFixed"] else (band if band in p["bands"] else (saved_band if saved_band in p["bands"] else "bg"))
    iface = p["device"]
    if p["mode"] == "concurrent":
        say({"event": "adding-interface"})
        iface = net_helper(["ap-add", p["device"]]).get("iface") or AP_IFACE
        if not nm.wait_device(router, iface):
            net_helper(["ap-del"])
            raise Failed("ap-refused", "NetworkManager didn't take the new interface")
    dev = nm.call(router, nm.NM_PATH, nm.NM, "GetDeviceByIpIface", "s", (iface,))[0]
    nm.update(router, path, wifi.settings(ssid, pw, band, p["channel"], iface))
    say({"event": "activating"})
    how, info = nm.activate(router, path, dev, timeout=60)
    if how == "up":
        say({"result": "on", "ssid": ssid, "device": iface, "mode": p["mode"], "uplink": p["uplink"]})
        return
    if p["mode"] == "concurrent":
        try:
            net_helper(["ap-del"])
        except Failed:
            pass
    if how == "timeout":
        raise Failed("timeout")
    raise Failed(DEVICE_HOTSPOT_REASONS.get(info["device"], "other"),
                 "device reason %d, connection reason %d" % (info["device"], info["ac"]))


def verb_hotspot_start(router, spec):
    a = nm.active(router).get(HOTSPOT_UUID)
    if a and a["state"] == nm.AC_ACTIVATED:
        say({"result": "on", "device": nm.iface_of(router, a["devices"][0]) if a["devices"] else ""})
        return
    start_hotspot(router, spec.get("band"))


def verb_hotspot_stop(router):
    a = nm.active(router).get(HOTSPOT_UUID)
    if a:
        nm.deactivate(router, a["path"])
    say({"result": "off"})


def verb_hotspot_show(router):
    _path, ssid, pw, band = hotspot_profile(router)
    say({"result": "ok", "ssid": ssid, "password": pw, "band": band})


def verb_hotspot_set(router, spec):
    path, ssid, pw, band = hotspot_profile(router)
    if spec.get("ssid") is not None:
        if not wifi.valid_ssid(spec["ssid"].strip()):
            raise Failed("bad-name")
        ssid = spec["ssid"].strip()
    if spec.get("newPassword"):
        pw = wifi.new_password()
    elif spec.get("password") is not None:
        if not wifi.valid_password(spec["password"]):
            raise Failed("bad-password")
        pw = spec["password"]
    if spec.get("band") in ("a", "bg"):
        band = spec["band"]
    s = nm.get_settings(router, path, ("802-11-wireless-security",))
    channel = v(s, "802-11-wireless", "channel", 0) or 0
    iface = v(s, "connection", "interface-name", "") or ""
    nm.update(router, path, wifi.settings(ssid, pw, band, channel, iface))
    a = nm.active(router).get(HOTSPOT_UUID)
    if a and a["state"] == nm.AC_ACTIVATED:
        nm.deactivate(router, a["path"])
        wait_stopped(router)
        start_hotspot(router, band)                 # says its own result
        return
    say({"result": "ok", "restarted": False})


def wait_stopped(router, seconds=8):
    """After stopping: until NetworkManager is done with it and the dispatcher has removed qap0 (a
    restart that recreated qap0 first would have it deleted under the new hotspot)."""
    import time
    end = time.monotonic() + seconds
    while time.monotonic() < end:
        if HOTSPOT_UUID not in nm.active(router) and not os.path.exists(os.path.join(SYS_NET, AP_IFACE)):
            return
        time.sleep(0.25)


def verb_hotspot_devices(router):
    a = nm.active(router).get(HOTSPOT_UUID)
    if not a or not a["devices"]:
        say({"result": "ok", "devices": []})
        return
    iface = nm.iface_of(router, a["devices"][0])
    macs = []
    try:
        r = subprocess.run([IW, "dev", iface, "station", "dump"], capture_output=True, text=True, timeout=10)
        macs = [m.lower() for m in re.findall(r"^Station ([0-9a-fA-F:]{17})", r.stdout, re.M)]
    except (OSError, subprocess.SubprocessError):
        pass
    try:
        with open(CLIENTS, encoding="utf-8") as f:
            leases = json.load(f).get("clients", {})
    except (OSError, ValueError, AttributeError):
        leases = {}
    if not macs:
        macs = list(leases)
    devices = [{"mac": m, "name": (leases.get(m) or {}).get("name", ""), "ip": (leases.get(m) or {}).get("ip", "")}
               for m in macs]
    say({"result": "ok", "devices": devices})


# ------------------------------------------------------------------------------------------------ main
def main(argv):
    try:
        if not argv:
            raise Usage()
        verb, args = argv[0], argv[1:]
        if not JEEPNEY:
            raise Failed("other", "python3-jeepney is missing")
        with nm.open_bus() as router:
            if verb == "list" and not args:
                verb_list(router)
            elif verb == "vpn-import" and not args:
                verb_vpn_import(router, read_spec())
            elif verb == "vpn-secrets" and not args:
                verb_vpn_secrets(router, read_spec())
            elif verb == "vpn-up" and len(args) == 1:
                verb_vpn_up(router, args[0])
            elif verb == "vpn-down" and len(args) == 1:
                verb_vpn_down(router, args[0])
            elif verb == "vpn-remove" and len(args) == 1:
                verb_vpn_remove(router, args[0])
            elif verb == "vpn-set" and not args:
                verb_vpn_set(router, read_spec())
            elif verb == "hotspot-plan" and not args:
                verb_hotspot_plan(router)
            elif verb == "hotspot-start" and not args:
                verb_hotspot_start(router, read_spec())
            elif verb == "hotspot-stop" and not args:
                verb_hotspot_stop(router)
            elif verb == "hotspot-show" and not args:
                verb_hotspot_show(router)
            elif verb == "hotspot-set" and not args:
                verb_hotspot_set(router, read_spec())
            elif verb == "hotspot-devices" and not args:
                verb_hotspot_devices(router)
            else:
                raise Usage()
        return 0
    except Usage:
        sys.stderr.write(__doc__)
        return 64
    except Failed as e:
        say({"result": "failed", "reason": e.reason, "detail": e.detail})
        return 1
    except Exception as e:          # NetworkManager refused (permission, gone…): one clean line for the UI
        name = getattr(e, "name", "") or ""
        reason = "not-allowed" if "PermissionDenied" in name or "NotAuthorized" in name else "other"
        say({"result": "failed", "reason": reason, "detail": str(e)[:300]})
        return 1
