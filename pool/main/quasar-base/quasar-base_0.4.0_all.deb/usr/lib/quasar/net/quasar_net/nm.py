"""NetworkManager over the system D-Bus (jeepney), for nm-ctl. Same approach as libexec/nm-join: whole
profiles, secrets included, go over D-Bus (never argv), and an activation is followed through
StateChanged signals until it's up or NetworkManager says why not.

jeepney note: signals carry NetworkManager's unique name (":1.x"), so local filters match on
interface + member only; the sender is named in the bus's AddMatch (see CLAUDE.md, Files › Drives).
"""
import os
import queue
import time

from jeepney import DBusAddress, HeaderFields, MatchRule, MessageType, new_method_call
from jeepney.bus_messages import message_bus
from jeepney.io.threading import open_dbus_router

NM = "org.freedesktop.NetworkManager"
NM_PATH = "/org/freedesktop/NetworkManager"
SETTINGS_PATH = NM_PATH + "/Settings"
PROPS = "org.freedesktop.DBus.Properties"
BUS = os.environ.get("QUASAR_NM_CTL_BUS", "SYSTEM")

ADD_TO_DISK, ADD_BLOCK_AUTOCONNECT = 0x1, 0x20
UPDATE_TO_DISK = 0x1
# NMActiveConnectionState / NMVpnConnectionState
AC_ACTIVATING, AC_ACTIVATED, AC_DEACTIVATING, AC_DEACTIVATED = 1, 2, 3, 4
VPN_ACTIVATED, VPN_FAILED, VPN_DISCONNECTED = 5, 6, 7
DEVICE_ACTIVATED, DEVICE_FAILED = 100, 120
# NMDeviceType
DT_ETHERNET, DT_WIFI, DT_WIREGUARD, DT_TUN = 1, 2, 29, 16


class Error(Exception):
    def __init__(self, text, name=""):
        super().__init__(text)
        self.name = name            # the D-Bus error name, e.g. org.freedesktop.NetworkManager.PermissionDenied


def open_bus():
    return open_dbus_router(bus=BUS)


def call(router, path, iface, member, sig="", body=(), timeout=30, dest=NM):
    msg = new_method_call(DBusAddress(path, bus_name=dest, interface=iface), member, sig, body)
    reply = router.send_and_get_reply(msg, timeout=timeout)
    if reply.header.message_type == MessageType.error:
        name = reply.header.fields.get(HeaderFields.error_name, "")
        raise Error("%s: %s" % (name, reply.body[0] if reply.body else ""), name)
    return reply.body


def prop(router, path, iface, name):
    return call(router, path, PROPS, "Get", "ss", (iface, name))[0][1]


def props(router, path, iface):
    return {k: v[1] for k, v in call(router, path, PROPS, "GetAll", "s", (iface,))[0].items()}


def listen(router, events, iface, member):
    """Queue this signal from NetworkManager (call before the method whose outcome it reports)."""
    router.filter(MatchRule(type="signal", interface=iface, member=member), queue=events).__enter__()
    router.send_and_get_reply(message_bus.AddMatch(
        MatchRule(type="signal", sender=NM, interface=iface, member=member)), timeout=10)


def connections(router):
    """[(path, settings)] for every saved profile (no secrets)."""
    out = []
    for path in call(router, SETTINGS_PATH, NM + ".Settings", "ListConnections")[0]:
        try:
            out.append((path, call(router, path, NM + ".Settings.Connection", "GetSettings")[0]))
        except Error:
            continue
    return out


def by_uuid(router, uuid):
    try:
        return call(router, SETTINGS_PATH, NM + ".Settings", "GetConnectionByUuid", "s", (uuid,))[0]
    except Error:
        return None


def get_settings(router, path, secret_groups=()):
    """Settings with the secrets of these groups merged in (what Update2 needs so it keeps them)."""
    s = call(router, path, NM + ".Settings.Connection", "GetSettings")[0]
    for g in secret_groups:
        if g not in s:
            continue
        try:
            sec = call(router, path, NM + ".Settings.Connection", "GetSecrets", "s", (g,))[0]
        except Error:
            continue
        for grp, vals in sec.items():
            s.setdefault(grp, {}).update(vals)
    return s


def update(router, path, settings):
    call(router, path, NM + ".Settings.Connection", "Update2", "a{sa{sv}}ua{sv}", (settings, UPDATE_TO_DISK, {}))


def add(router, settings):
    path, _result = call(router, SETTINGS_PATH, NM + ".Settings", "AddConnection2", "a{sa{sv}}ua{sv}",
                         (settings, ADD_TO_DISK | ADD_BLOCK_AUTOCONNECT, {}))
    return path


def delete(router, path):
    call(router, path, NM + ".Settings.Connection", "Delete")


def active(router):
    """{uuid: {"path", "state", "type", "id", "devices", "vpn", "default"}} for active connections."""
    out = {}
    for a in prop(router, NM_PATH, NM, "ActiveConnections"):
        try:
            p = props(router, a, NM + ".Connection.Active")
        except Error:
            continue
        out[p.get("Uuid", "")] = {"path": a, "state": p.get("State", 0), "type": p.get("Type", ""),
                                  "id": p.get("Id", ""), "devices": list(p.get("Devices", [])),
                                  "vpn": p.get("Vpn", False), "default": p.get("Default", False) or p.get("Default6", False)}
    return out


def deactivate(router, active_path):
    try:
        call(router, NM_PATH, NM, "DeactivateConnection", "o", (active_path,))
    except Error:
        pass


def iface_of(router, device_path):
    try:
        return prop(router, device_path, NM + ".Device", "Interface")
    except Error:
        return ""


def activate(router, conn_path, device="/", timeout=90):
    """Start a profile and follow it. -> ("up", device_path) or ("failed", {"ac": reason, "vpn": reason,
    "device": reason}) or ("timeout", {...}). An activation still going at the timeout is stopped."""
    events = queue.Queue()
    listen(router, events, NM + ".Connection.Active", "StateChanged")
    listen(router, events, NM + ".VPN.Connection", "VpnStateChanged")
    listen(router, events, NM + ".Device", "StateChanged")
    ac = call(router, NM_PATH, NM, "ActivateConnection", "ooo", (conn_path, device, "/"), timeout=60)[0]
    why = {"ac": 0, "vpn": 0, "device": 0}
    try:
        p = props(router, ac, NM + ".Connection.Active")
        devices = list(p.get("Devices", []))
        if p.get("State") == AC_ACTIVATED and not p.get("Vpn"):
            return "up", devices[0] if devices else "/"
        if p.get("Vpn"):
            vs = prop(router, ac, NM + ".VPN.Connection", "VpnState")
            if vs == VPN_ACTIVATED:
                return "up", devices[0] if devices else "/"
    except Error:
        devices = []
    start = time.monotonic()
    while time.monotonic() - start < timeout:
        try:
            msg = events.get(timeout=1)
        except queue.Empty:
            continue
        path = msg.header.fields.get(HeaderFields.path)
        iface = msg.header.fields.get(HeaderFields.interface)
        if iface == NM + ".Connection.Active" and path == ac:
            state, reason = msg.body
            if state == AC_ACTIVATED:
                return "up", _first_device(router, ac)
            if state == AC_DEACTIVATED:
                why["ac"] = reason
                return "failed", why
        elif iface == NM + ".VPN.Connection" and path == ac:
            state, reason = msg.body
            if state == VPN_ACTIVATED:
                return "up", _first_device(router, ac)
            if state in (VPN_FAILED, VPN_DISCONNECTED):
                why["vpn"] = reason
                return "failed", why
        elif iface == NM + ".Device" and (path in devices or path == device):
            new, _old, reason = msg.body
            if new == DEVICE_FAILED:
                why["device"] = reason
    deactivate(router, ac)
    return "timeout", why


def _first_device(router, ac):
    try:
        d = list(prop(router, ac, NM + ".Connection.Active", "Devices"))
        return d[0] if d else "/"
    except Error:
        return "/"


def wait_device(router, iface, seconds=8):
    """The device path once NetworkManager knows (and manages) a new interface, or None."""
    end = time.monotonic() + seconds
    while time.monotonic() < end:
        try:
            d = call(router, NM_PATH, NM, "GetDeviceByIpIface", "s", (iface,))[0]
            p = props(router, d, NM + ".Device")
            if p.get("Managed") and p.get("State", 0) >= 30:
                return d
        except Error:
            pass
        time.sleep(0.3)
    return None
