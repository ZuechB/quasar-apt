"""Every reason code the helpers can report. Settings turns each into plain words
(apps/settings/components/{vpn,hotspot,dns}.js `reasonText`); tools/test-settings-net-js.py checks that
every code below has its words, so add new codes here first."""

# nm-ctl vpn-import
IMPORT = ("unreadable", "too-big", "not-vpn", "bad-config", "missing-file", "otp", "no-openvpn", "nm-refused")
# nm-ctl vpn-up (and vpn-secrets)
VPN_UP = ("needs-secrets", "password", "unreachable", "no-network", "service", "timeout", "not-found", "other")
# nm-ctl hotspot-plan / hotspot-start / hotspot-set
HOTSPOT = ("no-wifi", "no-ap", "wifi-off", "blocked", "offline", "same-adapter", "channel", "no-dnsmasq",
           "cancelled", "not-allowed", "ap-refused", "timeout", "bad-name", "bad-password", "other")
# quasar-net dns set / check
DNS = ("offline", "blocked", "tls", "clock", "lookup", "bad-id", "bad-host", "no-addresses", "no-resolved", "other")
# quasar-net ap-add
AP = ("not-wifi", "not-station", "no-ap", "other")

ALL = sorted(set(IMPORT + VPN_UP + HOTSPOT + DNS + AP))
