"""OpenVPN: make a provider's .ovpn safe and self-contained before NetworkManager's OpenVPN plugin
imports it (`nmcli connection import type openvpn file …`). Pure: no D-Bus here.

- Files the profile points at (ca, cert, key, tls-auth, tls-crypt…) are read now and put inline, so the
  VPN keeps working after the download is deleted (nmcli would store their absolute paths). The plugin
  writes inline blocks to ~/.cert/nm-openvpn/ at import.
- Scripts, plugins and management directives are dropped (the plugin ignores most; none should run).
- An `auth-user-pass FILE` holds the user name and password: they're taken out of the profile and handed
  back, so nm-ctl saves them as the profile's secrets.
- `static-challenge` (a one-time code at every connect) is refused: there's no secret agent to ask.
"""
import base64
import os
import re

MAX_BYTES = 256 * 1024
FILE_DIRECTIVES = {"ca": "ca", "cert": "cert", "key": "key", "tls-auth": "tls-auth", "tls-crypt": "tls-crypt",
                   "tls-crypt-v2": "tls-crypt-v2", "secret": "secret", "extra-certs": "extra-certs",
                   "dh": "dh", "crl-verify": "crl-verify"}
DROPPED = {"script-security", "up", "down", "route-up", "route-pre-down", "ipchange", "client-connect",
           "client-disconnect", "learn-address", "auth-user-pass-verify", "tls-verify", "plugin", "management",
           "management-hold", "management-query-passwords", "management-client", "management-signal",
           "management-forget-disconnect", "management-up-down", "management-external-key",
           "management-external-cert", "daemon", "log", "log-append", "status", "writepid", "cd", "chroot",
           "user", "group", "askpass", "config", "setenv", "setenv-safe", "pull-filter-script", "auth-nocache"}
SCRIPTY = {"up", "down", "route-up", "route-pre-down", "ipchange", "client-connect", "client-disconnect",
           "learn-address", "auth-user-pass-verify", "tls-verify", "plugin", "script-security"}
INLINE_TAGS = {"ca", "cert", "key", "tls-auth", "tls-crypt", "tls-crypt-v2", "secret", "extra-certs", "dh",
               "pkcs12", "crl-verify", "http-proxy-user-pass", "connection"}


class Bad(Exception):
    """Unusable profile. `reason` is a reasons.IMPORT code (bad-config, missing-file, otp, too-big)."""
    def __init__(self, reason, text):
        super().__init__(text)
        self.reason = reason


def looks_like(text):
    """An OpenVPN client profile: a `client` or `remote` directive, or a `<connection>` block."""
    return bool(re.search(r"^\s*(client|remote\s+\S+|<connection>)", text, re.M))


def _words(line):
    """Split an OpenVPN directive line: whitespace-separated, with "double" or 'single' quotes."""
    out, cur, q, i = [], "", None, 0
    while i < len(line):
        c = line[i]
        if q:
            if c == "\\" and q == '"' and i + 1 < len(line):
                cur += line[i + 1]
                i += 1
            elif c == q:
                q = None
            else:
                cur += c
        elif c in "\"'":
            q = c
        elif c.isspace():
            if cur:
                out.append(cur)
                cur = ""
        else:
            cur += c
        i += 1
    if q:
        raise Bad("bad-config", "A quote isn't closed: %s" % line.strip())
    if cur:
        out.append(cur)
    return out


def _read(path, base, binary=False):
    p = path if os.path.isabs(path) else os.path.join(base, path)
    try:
        if os.path.getsize(p) > MAX_BYTES:
            raise Bad("too-big", "%s is too big." % os.path.basename(path))
        with open(p, "rb") as f:
            data = f.read()
    except OSError:
        raise Bad("missing-file", os.path.basename(path))
    if binary:
        return data
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        raise Bad("bad-config", "%s isn't a text file." % os.path.basename(path))


def _encrypted_key(pem):
    return "ENCRYPTED" in pem and ("PRIVATE KEY" in pem or "Proc-Type" in pem)


def sanitize(text, base_dir):
    """-> {"text": safe .ovpn, "needs": [...], "notes": [...], "fullTunnel": bool, "server": host,
           "user": str|None, "password": str|None, "pkcs12": bytes|None}. Raises Bad."""
    if len(text.encode("utf-8", "replace")) > MAX_BYTES:
        raise Bad("too-big", "The file is too big for a VPN profile.")
    out, notes = [], []
    needs, user, password, pkcs12, server = [], None, None, None, ""
    full = False
    lines = text.splitlines()
    i = 0
    while i < len(lines):
        raw = lines[i]
        stripped = raw.strip()
        i += 1
        if not stripped or stripped[0] in "#;":
            continue
        m = re.match(r"^<([a-z0-9-]+)>$", stripped)
        if m:                                       # an inline block: copied as is (up to its end tag)
            tag = m.group(1)
            if tag not in INLINE_TAGS:
                raise Bad("bad-config", "Unknown block <%s>." % tag)
            block = []
            while i < len(lines) and lines[i].strip() != "</%s>" % tag:
                block.append(lines[i])
                i += 1
            if i >= len(lines):
                raise Bad("bad-config", "<%s> isn't closed." % tag)
            i += 1
            body = "\n".join(block)
            if tag == "key" and _encrypted_key(body) and "keyPassword" not in needs:
                needs.append("keyPassword")
            if tag == "connection":
                for w in (_words(x) for x in block if x.strip() and x.strip()[0] not in "#;"):
                    if w and w[0] == "remote" and len(w) > 1 and not server:
                        server = w[1]
            out += ["<%s>" % tag] + block + ["</%s>" % tag]
            continue
        w = _words(stripped)
        d = w[0].lower()
        if d in DROPPED:
            if d in SCRIPTY and "scripts-ignored" not in notes:
                notes.append("scripts-ignored")
            continue
        if d == "static-challenge":
            raise Bad("otp", "This VPN asks for a one-time code at every connect.")
        if d == "remote" and len(w) > 1 and not server:
            server = w[1]
        if d == "redirect-gateway":
            full = True
        if d == "auth-user-pass":
            if len(w) > 1:                          # credentials in a file: take them, drop the path
                creds = _read(w[1], base_dir).splitlines()
                if creds and creds[0].strip():
                    user = creds[0].strip()
                if len(creds) > 1 and creds[1]:
                    password = creds[1].rstrip("\r")
            if user is None and "user" not in needs:
                needs.append("user")
            if password is None and "password" not in needs:
                needs.append("password")
            out.append("auth-user-pass")
            continue
        if d == "pkcs12" and len(w) > 1:
            pkcs12 = _read(w[1], base_dir, binary=True)
            out.append("<pkcs12>")
            out += [base64.b64encode(pkcs12)[k:k + 64].decode() for k in range(0, len(base64.b64encode(pkcs12)), 64)]
            out.append("</pkcs12>")
            continue
        if d in FILE_DIRECTIVES and len(w) > 1 and w[1] != "[inline]":
            body = _read(w[1], base_dir).rstrip("\n")
            if d == "key" and _encrypted_key(body) and "keyPassword" not in needs:
                needs.append("keyPassword")
            tag = FILE_DIRECTIVES[d]
            out += ["<%s>" % tag] + body.splitlines() + ["</%s>" % tag]
            if d == "tls-auth" and len(w) > 2:      # the key direction moves to its own directive
                out.append("key-direction %s" % w[2])
            continue
        out.append(stripped)
    if not server:
        raise Bad("bad-config", "The profile names no server (remote).")
    return {"text": "\n".join(out) + "\n", "needs": needs, "notes": notes, "fullTunnel": full,
            "server": server, "user": user, "password": password, "pkcs12": pkcs12}


def safe_name(name):
    """A file name for the copy nmcli imports (it names the profile after the file; we rename after)."""
    s = re.sub(r"[^A-Za-z0-9._-]+", "-", name).strip("-.")[:40]
    return s or "vpn"
