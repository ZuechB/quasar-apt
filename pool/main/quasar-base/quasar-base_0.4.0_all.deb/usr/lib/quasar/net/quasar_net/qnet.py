"""quasar-net: the root half of Settings › Network & Internet's VPN / Mobile hotspot / Encrypted DNS.

  quasar-net dns status                any user: {"available", "enabled", "provider", …, "reach"}
  quasar-net dns check                 any user: can the chosen servers be reached over TLS now?
  quasar-net dns set                   stdin {"provider": "quad9"|"cloudflare"|"mullvad"|"nextdns"|"custom",
                                       "nextdnsId"?, "host"?, "addresses"?}: check, switch, check again
  quasar-net dns off                   back to the network's own DNS
  quasar-net ap-add IFACE              a second interface (qap0) on IFACE's adapter, for a hotspot that
                                       shares the Wi-Fi the adapter is connected to
  quasar-net ap-del
  quasar-net dispatch IFACE ACTION     root only, never through pkexec: NetworkManager's dispatcher
                                       (55-quasar-net) on every network change

Everything but status/check runs as root through pkexec (polkit org.quasar.net; no password for active
sudo members, 51-quasar-net.rules). Prints JSON lines: {"event": …} while working, then one
{"result": …}. Exit 0 = done, 2 = {"result": "failed", "reason", "detail"}, 64 = usage.
"""
import fcntl
import json
import os
import re
import socket
import subprocess
import sys
import time

from . import dns, state, wifi
from .const import AP_IFACE, DNS_CONFIG, HOTSPOT_UUID, RESOLVED_DROPIN, STATE_FILE, STATE_LOCK

TEST = os.geteuid() != 0          # overrides only for unprivileged test runs, never under pkexec
ROOT = os.environ.get("QUASAR_NET_ROOT", "/") if TEST else "/"
RESOLVECTL = os.environ.get("QUASAR_NET_RESOLVECTL", "resolvectl") if TEST else "resolvectl"
SYSTEMCTL = os.environ.get("QUASAR_NET_SYSTEMCTL", "systemctl") if TEST else "systemctl"
IW = os.environ.get("QUASAR_NET_IW", "/usr/sbin/iw") if TEST else "/usr/sbin/iw"
IP = os.environ.get("QUASAR_NET_IP", "ip") if TEST else "ip"
NMCLI = os.environ.get("QUASAR_NET_NMCLI", "nmcli") if TEST else "nmcli"
CAFILE = os.environ.get("QUASAR_NET_CAFILE") if TEST else None
TLS_PORT = int(os.environ.get("QUASAR_NET_PORT", "853")) if TEST else 853
PROBE_TIMEOUT = float(os.environ.get("QUASAR_NET_PROBE_TIMEOUT", "4")) if TEST else 4.0
ENV = {"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LC_ALL": "C.UTF-8"}
IFACE_RE = re.compile(r"^[A-Za-z0-9_.-]{1,15}$")
TUNNEL_TYPES = {"wireguard", "vpn", "tun"}


def P(path):
    return os.path.join(ROOT, path.lstrip("/"))


class Failed(Exception):
    def __init__(self, reason, detail=""):
        super().__init__(detail or reason)
        self.reason = reason
        self.detail = detail


class Usage(Exception):
    pass


def say(obj):
    print(json.dumps(obj), flush=True)


def run(cmd, input=None, timeout=30):
    env = dict(os.environ, **ENV) if TEST else ENV
    try:
        return subprocess.run(cmd, input=input, capture_output=True, text=True, timeout=timeout, env=env)
    except (OSError, subprocess.SubprocessError) as e:
        return subprocess.CompletedProcess(cmd, 127, "", str(e))


def write_file(path, text, mode=0o644):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(text)
    os.chmod(tmp, mode)
    os.replace(tmp, path)


# ------------------------------------------------------------------------------------------------ DNS
def load_cfg():
    try:
        with open(P(DNS_CONFIG), encoding="utf-8") as f:
            c = json.load(f)
        return c if isinstance(c, dict) else {}
    except (OSError, ValueError):
        return {}


def save_cfg(c):
    write_file(P(DNS_CONFIG), json.dumps(c, indent=1) + "\n")


def resolved_available():
    return TEST or os.path.exists("/usr/lib/systemd/systemd-resolved")


def set_state_dns(on, cfg, reach):
    pub = dns.public(cfg) if on else {}
    def change(st):
        st["dns"] = {"on": bool(on), "provider": pub.get("provider", ""), "name": pub.get("name", ""), "reach": reach}
    state.update(P(STATE_FILE), P(STATE_LOCK), change)


def apply_dropin(text):
    write_file(P(RESOLVED_DROPIN), text)
    r = run([SYSTEMCTL, "reload", "systemd-resolved"])
    if r.returncode:
        r = run([SYSTEMCTL, "restart", "systemd-resolved"])
    run([RESOLVECTL, "reset-server-features"])
    run([RESOLVECTL, "flush-caches"])
    return r.returncode == 0


def verify(cfg, tries=4):
    """A lookup through resolved came back over an encrypted connection."""
    for i in range(tries):
        r = run([RESOLVECTL, "query", "--cache=no", "-t", "A", cfg["tls"]], timeout=15)
        if r.returncode == 0 and dns.encrypted(r.stdout):
            return True
        time.sleep(1 + i)
    return False


def resolve_host(host):
    try:
        return [a[4][0] for a in socket.getaddrinfo(host, None, type=socket.SOCK_STREAM)]
    except OSError:
        return []


def verb_dns_status():
    c = load_cfg()
    st = state.read(P(STATE_FILE))
    out = {"result": "ok", "available": resolved_available(), "enabled": bool(c.get("enabled")),
           "reach": st["dns"].get("reach", "") if c.get("enabled") else ""}
    out.update(dns.public(c) if c.get("provider") else {"provider": "quad9", "name": "Quad9"})
    say(out)


def verb_dns_check():
    c = load_cfg()
    if not c.get("enabled"):
        say({"result": "ok", "reach": ""})
        return
    say({"result": "ok", "reach": dns.probe(c, PROBE_TIMEOUT, CAFILE, TLS_PORT)})


def read_spec():
    line = sys.stdin.readline(8192)
    try:
        spec = json.loads(line) if line.strip() else {}
    except ValueError:
        raise Usage()
    if not isinstance(spec, dict):
        raise Usage()
    return spec


def verb_dns_set():
    if not resolved_available():
        raise Failed("no-resolved")
    spec = read_spec()
    try:
        cfg = dns.choose(spec, resolve=resolve_host)
    except dns.Bad as e:
        raise Failed(e.reason, str(e))
    say({"event": "checking"})
    reach = dns.probe(cfg, PROBE_TIMEOUT, CAFILE, TLS_PORT)
    if reach != "ok":
        raise Failed(reach, dns.LAST_DETAIL)     # nothing was changed
    old = load_cfg()
    try:
        with open(P(RESOLVED_DROPIN), encoding="utf-8") as f:
            old_text = f.read()
    except OSError:
        old_text = dns.dropin_off()
    if not apply_dropin(dns.dropin_on(cfg)) or not verify(cfg):
        apply_dropin(old_text)
        raise Failed("lookup")
    new = dict(cfg, enabled=True)
    save_cfg(new)
    set_state_dns(True, new, "ok")
    say({"result": "on", "provider": cfg["provider"], "name": dns.public(cfg)["name"]})


def verb_dns_off():
    c = load_cfg()
    apply_dropin(dns.dropin_off())
    if c:
        c["enabled"] = False
        save_cfg(c)
    set_state_dns(False, c, "")
    say({"result": "off"})


# ------------------------------------------------------------------------------------------------ AP interface
def sys_net(*parts):
    return P(os.path.join("/sys/class/net", *parts))


def phy_of(iface):
    try:
        with open(sys_net(iface, "phy80211", "name"), encoding="utf-8") as f:
            return f.read().strip()
    except OSError:
        return ""


def verb_ap_add(args):
    if len(args) != 1 or not IFACE_RE.match(args[0]) or args[0] == AP_IFACE:
        raise Usage()
    iface = args[0]
    phy = phy_of(iface)
    if not phy:
        raise Failed("not-wifi", iface)
    info = run([IW, "dev", iface, "info"])
    if "type managed" not in info.stdout:
        raise Failed("not-station", iface)
    pinfo = run([IW, "phy", phy, "info"])
    p = wifi.parse_phy(pinfo.stdout)
    if "AP" not in p["modes"] or wifi.concurrency(p) < 1:
        raise Failed("no-ap", iface)
    if os.path.exists(sys_net(AP_IFACE)):
        if phy_of(AP_IFACE) == phy:
            say({"result": "ok", "iface": AP_IFACE, "existing": True})
            return
        run([IW, "dev", AP_IFACE, "del"])
    try:
        with open(sys_net(iface, "address"), encoding="utf-8") as f:
            mac = wifi.derived_mac(f.read().strip())
    except (OSError, ValueError):
        mac = "02:00:00:5a:9e:01"
    r = run([IW, "phy", phy, "interface", "add", AP_IFACE, "type", "__ap"])
    if r.returncode:
        raise Failed("other", (r.stderr or r.stdout).strip()[:300])
    run([IP, "link", "set", AP_IFACE, "address", mac])
    say({"result": "ok", "iface": AP_IFACE, "mac": mac})


def verb_ap_del():
    if os.path.exists(sys_net(AP_IFACE)):
        run([IW, "dev", AP_IFACE, "del"])
    say({"result": "ok"})


# ------------------------------------------------------------------------------------------------ dispatcher
def active_connections():
    r = run([NMCLI, "-t", "-f", "UUID,TYPE,DEVICE,NAME", "connection", "show", "--active"])
    out = []
    for line in r.stdout.splitlines():
        f = re.split(r"(?<!\\):", line)
        if len(f) >= 4:
            out.append({"uuid": f[0].lower(), "type": f[1], "device": f[2], "name": ":".join(f[3:]).replace("\\:", ":")})
    return out


def hotspot_ssid():
    r = run([NMCLI, "-g", "802-11-wireless.ssid", "connection", "show", HOTSPOT_UUID])
    return r.stdout.strip() if r.returncode == 0 else ""


def verb_dispatch(args):
    if "PKEXEC_UID" in os.environ:
        raise Failed("other", "dispatch is for NetworkManager's dispatcher only.")
    if len(args) != 2:
        raise Usage()
    iface, action = args
    act = active_connections()
    vpns = [{"uuid": a["uuid"], "name": a["name"], "kind": "wireguard" if a["type"] == "wireguard" else "openvpn",
             "device": a["device"]} for a in act if a["type"] in ("wireguard", "vpn")]
    hs = next((a for a in act if a["uuid"] == HOTSPOT_UUID), None)
    stopped = ""
    # A hotspot sharing its adapter's Wi-Fi: when that Wi-Fi drops (out of range, roaming), stop it, or
    # the adapter can't follow its network to another channel.
    if hs and hs["device"] == AP_IFACE and action == "down" and iface != AP_IFACE and phy_of(iface) \
            and phy_of(iface) == phy_of(AP_IFACE):
        run([NMCLI, "connection", "down", HOTSPOT_UUID])
        hs, stopped = None, "uplink-lost"
    # qap0 only lives while the hotspot runs on it (Wi-Fi off, airplane mode, Stop, the above). Only on
    # its own "down": while nm-ctl starts a hotspot, qap0 exists before it's up.
    if not hs and action == "down" and (iface == AP_IFACE or stopped) and os.path.exists(sys_net(AP_IFACE)):
        run([IW, "dev", AP_IFACE, "del"])
    ssid = hotspot_ssid() if hs else ""

    def change(st):
        st["vpns"] = vpns
        prev = st["hotspot"]
        if hs:
            st["hotspot"] = {"on": True, "ssid": ssid, "device": hs["device"],
                             "mode": "concurrent" if hs["device"] == AP_IFACE else "direct", "stopped": ""}
        else:
            st["hotspot"] = {"on": False, "ssid": "", "device": "", "mode": "",
                             "stopped": stopped or (prev.get("stopped", "") if not prev.get("on") else "")}
    state.update(P(STATE_FILE), P(STATE_LOCK), change)
    # Encrypted DNS: a new network may block it (or want a sign-in page first). Check, so the shell can say so.
    c = load_cfg()
    if c.get("enabled") and action in ("up", "connectivity-change", "dhcp4-change") and \
            not any(a["device"] == iface and a["type"] in TUNNEL_TYPES for a in act) and iface != AP_IFACE:
        set_state_dns(True, c, "checking")
        set_state_dns(True, c, dns.probe(c, PROBE_TIMEOUT, CAFILE, TLS_PORT))
    say({"result": "ok"})


# ------------------------------------------------------------------------------------------------ main
def locked(fn, *a):
    lock = P("/run/quasar/quasar-net.lock")
    os.makedirs(os.path.dirname(lock), exist_ok=True)
    with open(lock, "a") as lf:
        fcntl.flock(lf, fcntl.LOCK_EX)
        return fn(*a)


def main(argv):
    try:
        if argv == ["dns", "status"]:
            verb_dns_status()
            return 0
        if argv == ["dns", "check"]:
            verb_dns_check()
            return 0
        if not TEST and os.geteuid() != 0:
            raise Failed("not-allowed", "This needs administrator rights (pkexec).")
        if argv == ["dns", "set"]:
            locked(verb_dns_set)
        elif argv == ["dns", "off"]:
            locked(verb_dns_off)
        elif argv[:1] == ["ap-add"]:
            locked(verb_ap_add, argv[1:])
        elif argv == ["ap-del"]:
            locked(verb_ap_del)
        elif argv[:1] == ["dispatch"]:
            locked(verb_dispatch, argv[1:])
        else:
            raise Usage()
        return 0
    except Usage:
        sys.stderr.write(__doc__)
        return 64
    except Failed as e:
        say({"result": "failed", "reason": e.reason, "detail": e.detail})
        return 2
    except OSError as e:
        say({"result": "failed", "reason": "other", "detail": str(e.strerror or e)})
        return 2
