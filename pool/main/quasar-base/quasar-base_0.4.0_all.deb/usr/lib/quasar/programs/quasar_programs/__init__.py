"""Programs from files: what a double-clicked .sh, .py, .exe (.NET), .AppImage or .deb is, whether it can
run here, and how. Entry point: /usr/libexec/quasar/program (cli.py has the subcommands)."""
