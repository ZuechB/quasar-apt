"""Windows executables, read defensively (every offset comes from an untrusted file): the PE header
(machine, GUI or console subsystem, the .NET CLI header) and .NET's single-file bundle manifest.

Bundle layout (dotnet/runtime src/installer/managed/Microsoft.NET.HostModel/Bundle): the host carries an
8-byte header offset right before a 32-byte signature (offset 0 = not a bundle). The header: u32 major,
u32 minor, i32 file count, string bundle id, then (major >= 2) i64 deps.json offset/size, i64
runtimeconfig.json offset/size, u64 flags; then per file: i64 offset, i64 size, i64 compressed size
(major >= 6; 0 = stored), u8 type, string path. Strings are 7-bit-length-prefixed UTF-8; compressed
entries are raw deflate."""
import struct
import zlib

BUNDLE_SIG = bytes.fromhex("8b1202b96a612038727b930214d7a03213f5b9e6efae3318ee3b2dce24b36aae")
SIG_SEARCH = 16 << 20          # the signature lives in the host, at the start of the file
NETFX_SEARCH = 32 << 20
MACHINES = {0x14c: "x86", 0x8664: "x64", 0xaa64: "arm64", 0x1c4: "arm"}
GUI, CONSOLE = 2, 3
CLI_ILONLY, CLI_32BITREQUIRED, CLI_32BITPREFERRED = 0x1, 0x2, 0x20000
TYPES = {0: "other", 1: "assembly", 2: "native", 3: "deps", 4: "runtimeconfig", 5: "symbols"}
MAX_ENTRIES = 20000
MAX_PATH = 1024


class BadFile(Exception):
    pass


def _u16(b, o):
    if o < 0 or o + 2 > len(b):
        raise BadFile("truncated")
    return struct.unpack_from("<H", b, o)[0]


def _u32(b, o):
    if o < 0 or o + 4 > len(b):
        raise BadFile("truncated")
    return struct.unpack_from("<I", b, o)[0]


def header(data):
    """PE facts from the first bytes of a file (or an in-memory assembly): {machine, subsystem, clr}.
    clr is None for native code, else {flags, ilonly, x86only}. None when it isn't a PE at all."""
    if len(data) < 64 or data[:2] != b"MZ":
        return None
    try:
        pe = _u32(data, 0x3C)
        if pe > len(data) - 24 or data[pe:pe + 4] != b"PE\0\0":
            return None
        machine = _u16(data, pe + 4)
        nsect = _u16(data, pe + 6)
        optsize = _u16(data, pe + 20)
        opt = pe + 24
        magic = _u16(data, opt)
        if magic not in (0x10b, 0x20b):
            return None
        subsystem = _u16(data, opt + 68)
        ndirs_at, dirs = (opt + 92, opt + 96) if magic == 0x10b else (opt + 108, opt + 112)
        ndirs = _u32(data, ndirs_at)
        clr = None
        if ndirs > 14:
            rva, size = _u32(data, dirs + 14 * 8), _u32(data, dirs + 14 * 8 + 4)
            if rva and size >= 24:
                off = _rva_to_offset(data, opt + optsize, nsect, rva)
                if off is not None and off + 20 <= len(data):
                    flags = _u32(data, off + 16)
                    clr = {"flags": flags, "ilonly": bool(flags & CLI_ILONLY),
                           "x86only": bool(flags & CLI_32BITREQUIRED) and not flags & CLI_32BITPREFERRED}
                else:
                    clr = {"flags": 0, "ilonly": False, "x86only": False, "unreadable": True}
        return {"machine": MACHINES.get(machine, hex(machine)), "subsystem": subsystem, "clr": clr}
    except BadFile:
        return None


def _rva_to_offset(data, sect, nsect, rva):
    for i in range(min(nsect, 96)):
        s = sect + i * 40
        if s + 40 > len(data):
            return None
        vsize, vaddr, rawsize, rawptr = struct.unpack_from("<IIII", data, s + 8)
        if vaddr <= rva < vaddr + max(vsize, rawsize):
            return rawptr + (rva - vaddr)
    return None


def find_bundle(f, file_size):
    """The bundle header offset, or 0 when the file isn't a single-file bundle."""
    f.seek(0)
    keep, pos = b"", 0
    while pos < min(file_size, SIG_SEARCH):
        chunk = f.read(1 << 20)
        if not chunk:
            break
        buf = keep + chunk
        i = buf.find(BUNDLE_SIG)
        if i >= 8:
            off = struct.unpack_from("<q", buf, i - 8)[0]
            return off if 0 < off < file_size else 0
        keep = buf[-(len(BUNDLE_SIG) + 8):]
        pos += len(chunk)
    return 0


class _Reader:
    def __init__(self, f, offset, file_size):
        self.f, self.file_size = f, file_size
        f.seek(offset)

    def take(self, n):
        b = self.f.read(n)
        if len(b) != n:
            raise BadFile("truncated bundle header")
        return b

    def u32(self):
        return struct.unpack("<I", self.take(4))[0]

    def i32(self):
        return struct.unpack("<i", self.take(4))[0]

    def i64(self):
        return struct.unpack("<q", self.take(8))[0]

    def string(self):
        n, shift = 0, 0
        for _ in range(5):
            b = self.take(1)[0]
            n |= (b & 0x7F) << shift
            if not b & 0x80:
                break
            shift += 7
        else:
            raise BadFile("bad string length")
        if n > MAX_PATH:
            raise BadFile("string too long")
        return self.take(n).decode("utf-8")


def manifest(f, offset, file_size):
    """The bundle's header and file list, every offset checked against the file's size."""
    r = _Reader(f, offset, file_size)
    major, minor, count = r.u32(), r.u32(), r.i32()
    if major not in (2, 6) or not 0 < count <= MAX_ENTRIES:
        raise BadFile("unsupported bundle (version %d, %d files)" % (major, count))
    bundle_id = r.string()
    r.i64(), r.i64(), r.i64(), r.i64(), r.take(8)       # deps / runtimeconfig locations, flags
    entries, seen = [], set()
    for _ in range(count):
        off, size = r.i64(), r.i64()
        csize = r.i64() if major >= 6 else 0
        kind = r.take(1)[0]
        path = r.string()
        stored = csize or size
        if off < 0 or size < 0 or csize < 0 or off + stored > file_size:
            raise BadFile("an entry points outside the file")
        if path in seen:
            raise BadFile("repeated entry " + path)
        seen.add(path)
        entries.append({"offset": off, "size": size, "csize": csize, "type": TYPES.get(kind, "other"),
                        "path": path})
    return {"major": major, "minor": minor, "id": bundle_id, "entries": entries}


def safe_path(path):
    """The entry's path as relative parts, or None when it could escape the folder it's unpacked into."""
    if not path or len(path) > MAX_PATH or "\\" in path or "\0" in path or path.startswith("/"):
        return None
    parts = path.split("/")
    if any(p in ("", ".", "..") for p in parts):
        return None
    return parts


def read_entry(f, entry, cap=None):
    """An entry's bytes (inflated when compressed), never more than its declared size."""
    out = bytearray()
    for chunk in iter_entry(f, entry):
        out += chunk
        if cap is not None and len(out) > cap:
            raise BadFile("entry too large")
    return bytes(out)


def iter_entry(f, entry):
    f.seek(entry["offset"])
    size = entry["size"]
    if not entry["csize"]:
        left = size
        while left:
            b = f.read(min(left, 1 << 20))
            if not b:
                raise BadFile("truncated entry")
            left -= len(b)
            yield b
        return
    d = zlib.decompressobj(-15)
    left, made = entry["csize"], 0
    while left:
        b = f.read(min(left, 1 << 20))
        if not b:
            raise BadFile("truncated entry")
        left -= len(b)
        # Inflate in steps, never past the declared size: a crafted entry can't balloon in memory.
        data = d.decompress(b, size - made + 1)
        while True:
            made += len(data)
            if made > size:
                raise BadFile("entry larger than it says")
            if data:
                yield data
            if not d.unconsumed_tail:
                break
            data = d.decompress(d.unconsumed_tail, size - made + 1)
    tail = d.flush()
    made += len(tail)
    if made != size:
        raise BadFile("entry size mismatch")
    if tail:
        yield tail


def has_netfx_marker(f, file_size):
    """.NET Framework assemblies carry TargetFrameworkAttribute(".NETFramework,Version=v4.x")."""
    f.seek(0)
    keep, pos, needle = b"", 0, b".NETFramework,Version="
    while pos < min(file_size, NETFX_SEARCH):
        chunk = f.read(1 << 20)
        if not chunk:
            break
        if needle in keep + chunk:
            return True
        keep = chunk[-len(needle):]
        pos += len(chunk)
    return False
