"""Starting a program the user said yes to. Everything here is an argv list; nothing goes through a shell.

- Windowed programs start in their own systemd scope (app-quasar-file.<name>.<hash>-<ms>: the firewall
  counts and allows per app by that name) under a small watcher, `program exec --watch 15`. It leaves
  after 15 s (the program keeps running in its scope); if the program fails before that, it tells the
  shell, which offers to run it in Terminal so the error shows. Started detached: a shell restart
  doesn't touch it.
- Scripts and console programs run in a Terminal tab under `program exec --pause`, which says how it
  ended and waits for Enter. The word after quasar-terminal's -e is always this helper's absolute
  path: the Terminal turns a single -e word with spaces into `sh -c`.
- A file inside a company's home runs inside that company (its account, its network), never as you:
  the company account can change its own files."""
import base64
import json
import os
import shutil
import signal
import subprocess
import sys
import time

SELF = os.environ.get("QUASAR_PROGRAM_SELF", "/usr/libexec/quasar/program")
SHELL_PATH = "/usr/share/quasar/shell"


def scope(unit_id):
    rt = os.environ.get("XDG_RUNTIME_DIR", "/run/user/%d" % os.getuid())
    if os.environ.get("QUASAR_NO_SCOPES") == "1" or not os.path.exists(os.path.join(rt, "systemd", "private")):
        return []
    return ["systemd-run", "--user", "--scope", "--quiet", "--collect", "--slice=app.slice",
            "--unit=app-quasar-%s-%d" % (unit_id, int(time.time() * 1000)), "--"]


def spawn(argv, cwd, env=None):
    subprocess.Popen(argv, cwd=cwd if cwd and os.path.isdir(cwd) else os.path.expanduser("~"), env=env,
                     stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                     start_new_session=True, close_fds=True)


def run_gui(argv, cwd, unit_id, name, path, key, extra_env=None):
    env = dict(os.environ, **(extra_env or {}))
    watcher = [SELF, "exec", "--watch", "15", "--name", name, "--path", path, "--key", key, "--"]
    spawn(scope(unit_id) + watcher + argv, cwd, env)


def in_company_account():
    try:
        import pwd
        return pwd.getpwuid(os.getuid()).pw_name.startswith("quasar-co-")
    except (KeyError, ImportError):
        return False


def run_terminal(argv, cwd):
    inner = [SELF, "exec", "--pause", "--"] + argv
    if in_company_account():
        # Inside a company: its own terminal (foot; Quasar's Terminal runs in the owner's session).
        spawn(["foot", "--working-directory=" + cwd, "--"] + inner, cwd)
        return
    spawn(scope("quasar-terminal") + ["quasar-terminal", "--cwd", cwd, "-e"] + inner, cwd)


def run_in_company(cid, path, expect, how, cwd):
    """Hands the whole run to the company's account: its own runtimes, interpreters (mise), caches and
    network, none of which can be in your home (the company can't read it). The helper there checks the
    file against the same key and starts it (`program run … --here`)."""
    # Starting a company needs no password for its owner (quasar-company-ctl); it may already run.
    subprocess.run(["quasar-company", "start", cid], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=60)
    p = subprocess.run(["quasar-company", "run", cid, "--cwd", cwd, "--", SELF, "run", path, "--expect", expect,
                        "--how", how, "--here"], capture_output=True, text=True, timeout=60)
    if p.returncode != 0:
        raise OSError(p.stderr.strip() or "Couldn't start it in the company")


# ---------------------------------------------------------------------------------------- in-process modes
def watch(argv, seconds, name, path, key):
    """Runs a windowed program; reports a failure in its first seconds, then leaves it running."""
    try:
        p = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError as e:
        report(name, path, key, 127, str(e))
        return 0
    try:
        code = p.wait(timeout=seconds)
    except subprocess.TimeoutExpired:
        return 0
    if code != 0:
        report(name, path, key, code, "")
    return 0


def report(name, path, key, code, error):
    msg = base64.b64encode(json.dumps({"name": name, "path": path, "key": key, "code": code, "error": error}).encode()).decode()
    if shutil.which("qs"):
        try:
            if subprocess.run(["qs", "--path", SHELL_PATH, "ipc", "call", "programs", "exited", msg],
                              stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=10).returncode == 0:
                return
        except (OSError, subprocess.SubprocessError):
            pass
    try:
        subprocess.run(["notify-send", "--app-name=Quasar", "--icon=dialog-warning",
                        "“%s” stopped right away" % name,
                        "Choose Run in Terminal on its menu to see why."], timeout=10)
    except (OSError, subprocess.SubprocessError):
        pass


def pause(argv):
    """Runs a script or console program in the Terminal, then says how it ended and waits for Enter, so
    its output stays readable. Exits 0 afterwards (the tab closes)."""
    # Ctrl+C goes to the program, not to this wrapper. A handler (not SIG_IGN) is reset to the default
    # in the program when it starts, so the program still stops on Ctrl+C.
    for s in (signal.SIGINT, signal.SIGQUIT):
        signal.signal(s, lambda *_: None)
    try:
        code = subprocess.call(argv)
    except OSError as e:
        code, err = None, str(e)
    else:
        err = ""
    for s in (signal.SIGINT, signal.SIGQUIT):
        signal.signal(s, signal.SIG_DFL)
    if code is None:
        line = "Couldn't start it: %s" % err
    elif code == 0:
        line = "The program finished."
    elif code < 0:
        line = "The program was stopped (signal %d)." % -code
    else:
        line = "The program stopped with exit code %d." % code
    try:
        sys.stdout.write("\n\033[2m%s Press Enter to close.\033[0m" % line)
        sys.stdout.flush()
        sys.stdin.readline()
    except (KeyboardInterrupt, OSError):
        pass
    return 0
