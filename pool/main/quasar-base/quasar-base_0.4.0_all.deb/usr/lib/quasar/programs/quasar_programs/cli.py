"""program — runs what the user double-clicks (.sh, .py, .exe for .NET, .AppImage) and describes .deb
files for the Store. Runs as the user; prints one JSON line.

  program inspect PATH [--external]       what it is, whether it can run, what the prompt offers
  program run PATH --expect KEY [--how run|apps|terminal]
                                          runs it (KEY from inspect: a file that changed since is
                                          refused); apps = add an AppImage to Apps first; terminal =
                                          in a Terminal tab even if it has a window
  program integrate PATH | unintegrate DESKTOP_ID     Add to Apps / Remove from Apps (AppImages)
  program deb-info PATH [--no-plan] [--icon]          a .deb's fields, apt's dry run, its icon
  program deb-installed                   packages installed from files, with their launcher entries
  program open-external PATH              from another app (xdg-open, the portal): hands it to the
                                          shell, which always asks first; never runs it itself
  program exec --watch N --name N --path P --key K -- ARGV…   (the launcher's watcher)
  program exec --pause -- ARGV…           (a Terminal tab: waits for Enter when it ends)

Exit codes: 0 ok, 1 failed, 2 can't run here, 3 the file changed, 64 usage."""
import base64
import json
import os
import subprocess
import sys
import time
from urllib.parse import unquote, urlsplit

from . import allow, appimage, deb, dotnet, files, launch, script

HEAD = 64 << 10
TYPE = {"shell": "Shell script", "python": "Python script"}


def emit(**fields):
    print(json.dumps(fields), flush=True)


def store_has(entry_id):
    """Whether the Store's root-owned recipes (system.tsv) have this entry."""
    table = os.environ.get("QUASAR_STORE_TABLE", "/usr/share/quasar/store/system.tsv")
    try:
        with open(table) as f:
            return any(line.split("\t", 1)[0] == entry_id for line in f)
    except OSError:
        return False


def _path_arg(arg):
    if arg.startswith("file://"):
        arg = unquote(urlsplit(arg).path)
    return os.path.abspath(os.path.expanduser(arg))


def inspect(path, external=False):
    real, st = files.identity(path)
    kind = files.kind_by_suffix(real)
    with open(real, "rb") as f:
        head = f.read(HEAD)
    name = files.display_name(os.path.basename(real))
    out = {"path": real, "name": name, "kind": kind or "unknown", "key": files.key_of(real, st), "size": st.st_size,
           "origin": files.origin(real), "owner": files.owner(real, st), "company": files.company_of(real),
           "terminal": False, "canRun": False, "reason": "", "detail": {}, "actions": [], "type": "", "unit": ""}
    if kind == "script":
        lang = files.SCRIPT[files.suffix(real)]
        s = script.inspect(real, head, lang)
        out.update(type=TYPE[lang], terminal=True, detail={"crlf": s["crlf"], "missing": s["missing"], "lang": lang,
                                                           "interp": s["interp"][:1]})
        if s["missing"]:
            out.update(reason="missing-interpreter", actions=["store", "edit"])
        else:
            out.update(canRun=True, actions=["run", "edit"])
    elif kind == "appimage":
        a = appimage.inspect(real, head)
        out.update(type="AppImage app", detail={k: a[k] for k in ("arch", "appimageType", "executable", "runsHere", "entry") if k in a},
                   unit=a.get("entry") or "file.%s.%s" % (files.slug(name.rsplit(".", 1)[0]), out["key"][:6]))
        if not a["canRun"]:
            out.update(reason=a["reason"])
        elif a["entry"]:
            out.update(canRun=True, actions=["run"])
        elif a["executable"] or a["runsHere"]:
            out.update(canRun=True, actions=["apps", "run"])
        else:
            out.update(canRun=True, reason="copy-first", actions=["apps"])
    elif kind == "windows":
        d = dotnet.inspect(real, st, head)
        gui = d.get("gui", True)
        what = files.suffix(real)
        out.update(type={"msi": "Windows installer", "bat": "Windows batch file", "cmd": "Windows batch file"}.get(what)
                   or (".NET app" if d.get("major") and gui else ".NET console app" if d.get("major") else "Windows program"),
                   reason=d.get("reason", ""), canRun=bool(d.get("canRun")), terminal=d.get("major") is not None and not gui,
                   detail={k: d[k] for k in ("mode", "major", "aspnet", "tfm", "selfContained", "machine", "gui", "assembly")
                           if k in d})
        if d.get("runtime"):
            out["detail"]["rollForward"] = d["runtime"]["rollForward"]
            out["detail"]["runtime"] = d["runtime"]["version"]
        if d.get("detail"):
            out["detail"].update(d["detail"])
        out["unit"] = "file.%s.%s" % (files.slug(d.get("assembly") or name.rsplit(".", 1)[0]), out["key"][:6])
        if out["canRun"]:
            out["actions"] = ["run"]
        elif out["reason"] == "runtime-missing":
            # Offered only when this Quasar's Store has that runtime (dotnet-N / aspnetcore-N entries).
            sid = ("aspnetcore-%d" if out["detail"].get("aspnet") else "dotnet-%d") % out["detail"]["major"]
            out["detail"]["storeId"] = sid
            out["actions"] = ["runtime"] if store_has(sid) else []
        elif out["reason"] in ("windows-program", "windows-only-dotnet", "netfx", "cpp-cli", "x86-only"):
            out["actions"] = ["bottles"]
    elif kind == "deb":
        out.update(type="Debian package", actions=["install"])
    else:
        out.update(reason="not-a-program")
    out["allowed"] = (not external and out["canRun"] and out["owner"] == "you" and out["reason"] == ""
                      and allow.is_allowed(out["key"]))
    return out, real, st


def cmd_inspect(args):
    path = _path_arg(args[0])
    try:
        out, _, _ = inspect(path, external="--external" in args[1:])
    except FileNotFoundError:
        emit(error="It isn't there any more", reason="gone")
        return 1
    except OSError as e:
        emit(error=e.strerror or str(e), reason="unreadable")
        return 1
    emit(**out)
    return 0


def _opt(args, name, default=None):
    if name in args:
        i = args.index(name)
        if i + 1 < len(args):
            return args[i + 1]
    return default


def cmd_run(args):
    path = _path_arg(args[0])
    expect = _opt(args, "--expect", "")
    how = _opt(args, "--how", "run")
    here = "--here" in args            # already in the account that should run it (a company's)
    if how not in ("run", "apps", "terminal") or not expect:
        emit(error="usage")
        return 64
    try:
        info, real, st = inspect(path)
    except OSError:
        emit(ok=False, error="It isn't there any more", reason="gone")
        return 1
    if info["key"] != expect:
        emit(ok=False, error="The file changed after it was checked", reason="changed")
        return 3
    if info["company"] and not here:
        # A company's own file runs inside that company, never as you.
        try:
            launch.run_in_company(info["company"], real, expect, how, os.path.dirname(real))
        except (OSError, subprocess.SubprocessError) as e:
            emit(ok=False, error=str(e), reason="start")
            return 1
        emit(ok=True, where=info["company"], terminal=info["terminal"] or how == "terminal", path=real, unit=info["unit"])
        return 0
    if not info["canRun"]:
        emit(ok=False, error="It can't run here", reason=info["reason"])
        return 2
    unit = info["unit"]
    if info["kind"] == "appimage" and how == "apps":
        try:
            res = appimage.integrate(real)
        except (OSError, ValueError) as e:
            emit(ok=False, error=str(e), reason="integrate")
            return 1
        real, st = files.identity(res["path"])
        unit = res["entry"]
    elif info["reason"] == "copy-first":
        emit(ok=False, error="It can't run from this drive", reason="copy-first")
        return 2
    allow.allow(files.key_of(real, st), real, info["name"])
    name = info["name"]
    terminal = info["terminal"] or how == "terminal"
    env = {}
    try:
        if info["kind"] == "script":
            s = script.inspect(real, open(real, "rb").read(HEAD), info["detail"]["lang"])
            argv, cwd = s["interp"] + [real], os.path.dirname(real)
        elif info["kind"] == "appimage":
            argv, env = appimage.command(real)
            cwd = os.path.expanduser("~")
        else:
            d = dotnet.inspect(real, st, open(real, "rb").read(HEAD))
            if not d.get("canRun"):
                emit(ok=False, error="It can't run here", reason=d.get("reason", ""))
                return 2
            argv, cwd = dotnet.command(d, real, st)
        if terminal:
            launch.run_terminal(argv, cwd)
        else:
            launch.run_gui(argv, cwd, unit, name, real, files.key_of(real, st), env)
    except OSError as e:
        emit(ok=False, error=e.strerror or str(e), reason="start")
        return 1
    except Exception as e:                    # a broken bundle and the like: say so, don't trace
        emit(ok=False, error=str(e), reason="start")
        return 1
    emit(ok=True, where=info["company"] or "personal", terminal=terminal, path=real, unit=unit)
    return 0


def cmd_integrate(args):
    try:
        real, _ = files.identity(_path_arg(args[0]))
        emit(ok=True, **appimage.integrate(real))
        return 0
    except (OSError, ValueError) as e:
        emit(ok=False, error=str(e))
        return 1


def cmd_unintegrate(args):
    try:
        emit(ok=True, **appimage.unintegrate(args[0]))
        return 0
    except (OSError, ValueError) as e:
        emit(ok=False, error=str(e))
        return 1


def cmd_deb_info(args):
    path = _path_arg(args[0])
    try:
        if "--icon" in args[1:]:
            real, st = files.identity(path)
            out_dir = os.path.join(os.environ.get("XDG_CACHE_HOME") or os.path.expanduser("~/.cache"), "quasar", "debfiles",
                                   files.key_of(real, st)[:16])
            emit(**deb.icon(real, out_dir))
        else:
            emit(**deb.inspect(path, want_plan="--no-plan" not in args[1:]))
        return 0
    except (OSError, ValueError, subprocess.SubprocessError) as e:
        emit(error=str(e) or "This package can't be read")
        return 1


def cmd_deb_installed(args):
    emit(packages=deb.installed_from_files())
    return 0


def cmd_open_external(args):
    path = _path_arg(args[0])
    for _ in range(7):                        # the shell restarts within a second or two
        try:
            if subprocess.run(["qs", "--path", launch.SHELL_PATH, "ipc", "call", "programs", "external", path],
                              stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=10).returncode == 0:
                return 0
        except (OSError, subprocess.SubprocessError):
            pass
        time.sleep(0.5)
    try:
        subprocess.run(["notify-send", "--app-name=Quasar", "--icon=dialog-warning", "Couldn't open it",
                        os.path.basename(path) + ": the desktop isn't running."], timeout=10)
    except (OSError, subprocess.SubprocessError):
        pass
    return 1


def cmd_exec(args):
    if "--" not in args:
        return 64
    i = args.index("--")
    opts, argv = args[:i], args[i + 1:]
    if not argv:
        return 64
    if "--pause" in opts:
        return launch.pause(argv)
    seconds = float(_opt(opts, "--watch", "15"))
    return launch.watch(argv, seconds, _opt(opts, "--name", os.path.basename(argv[0])), _opt(opts, "--path", ""),
                        _opt(opts, "--key", ""))


COMMANDS = {"inspect": cmd_inspect, "run": cmd_run, "integrate": cmd_integrate, "unintegrate": cmd_unintegrate,
            "deb-info": cmd_deb_info, "deb-installed": cmd_deb_installed, "open-external": cmd_open_external,
            "exec": cmd_exec}


def main(argv):
    if not argv or argv[0] not in COMMANDS or (argv[0] not in ("exec", "deb-installed") and len(argv) < 2):
        sys.stderr.write(__doc__)
        return 64
    return COMMANDS[argv[0]](argv[1:])
