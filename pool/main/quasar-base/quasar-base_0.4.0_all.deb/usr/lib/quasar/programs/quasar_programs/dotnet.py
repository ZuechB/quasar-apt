""".NET apps from Windows (.exe): what kind of build it is, which runtime here can run it, and the folder
it runs from.

- A framework-dependent app (App.exe + App.dll + App.runtimeconfig.json) runs in place with
  `dotnet App.dll`: the .exe is only Windows' launcher.
- A single-file bundle, or a self-contained app (it carries Windows' own copy of .NET), gets a run
  folder in ~/.cache/quasar/dotnet-apps: the app's own assemblies, unpacked or linked, with a
  runtimeconfig that asks for this PC's shared .NET instead. Windows machine code (native .dll files,
  the bundled Windows runtime) is left out: it can't run here anyway.
- Windows Forms / WPF apps, .NET Framework apps, C++/CLI and 32-bit-only code can't run here.

Runtimes: the system's (the .NET runtime Store entries, /usr/bin/dotnet) first, then ~/.dotnet (the
Store's developer .NET). Always by absolute path: mise shims come first on PATH."""
import hashlib
import json
import os
import shutil
import subprocess
import tempfile
import time

from . import files, pe

NETCORE, ASPNET, DESKTOP = "Microsoft.NETCore.App", "Microsoft.AspNetCore.App", "Microsoft.WindowsDesktop.App"
LOWEST_SHIPPED = 10          # older apps (.NET 6–9) roll forward onto it
HEAD = 64 << 10
KEEP_DAYS = 30
MAX_RC = 1 << 20


def system_muxers():
    env = os.environ.get("QUASAR_DOTNET")
    if env:
        return [env]
    out = []
    for p in ("/usr/bin/dotnet", "/usr/share/dotnet/dotnet", "/usr/lib/dotnet/dotnet"):
        if os.path.exists(p):
            r = os.path.realpath(p)
            if r not in out:
                out.append(r)
    return out[:1]


def user_muxer():
    p = os.environ.get("QUASAR_DOTNET_USER") or os.path.join(os.path.expanduser("~"), ".dotnet", "dotnet")
    return p if os.path.isfile(p) and os.access(p, os.X_OK) else ""


_cache = {}


def runtimes(muxer):
    """{framework name: {major: [versions…]}, "_dirs": {name: dir}} from `dotnet --list-runtimes`."""
    if muxer in _cache:
        return _cache[muxer]
    found = {}
    try:
        out = subprocess.run([muxer, "--list-runtimes"], capture_output=True, text=True, timeout=15,
                             env=dict(os.environ, DOTNET_CLI_TELEMETRY_OPTOUT="1", DOTNET_NOLOGO="1")).stdout
    except (OSError, subprocess.SubprocessError):
        out = ""
    for line in out.splitlines():
        parts = line.split(" ", 2)
        if len(parts) < 3:
            continue
        name, ver, where = parts[0], parts[1], parts[2].strip().strip("[]")
        try:
            major = int(ver.split(".")[0])
        except ValueError:
            continue
        found.setdefault(name, {}).setdefault(major, []).append(ver)
        found.setdefault("_dirs", {})[(name, ver)] = os.path.join(where, ver)
    _cache[muxer] = found
    return found


def _newest(vers):
    def key(v):
        return [int(x) if x.isdigit() else 0 for x in v.split("-")[0].split(".")]
    return sorted(vers, key=key)[-1]


def choose(major, asp):
    """{muxer, version, rollForward} for an app that wants .NET `major` (and ASP.NET Core), or None."""
    muxers = system_muxers() + ([user_muxer()] if user_muxer() else [])
    for m in muxers:
        rt = runtimes(m)
        if major in rt.get(NETCORE, {}) and (not asp or major in rt.get(ASPNET, {})):
            return {"muxer": m, "version": _newest(rt[NETCORE][major]), "rollForward": False}
    if major < LOWEST_SHIPPED:
        for m in muxers:
            rt = runtimes(m)
            newer = sorted(x for x in rt.get(NETCORE, {}) if x > major and (not asp or x in rt.get(ASPNET, {})))
            if newer:
                return {"muxer": m, "version": _newest(rt[NETCORE][newer[0]]), "rollForward": True}
    return None


def framework_files(muxer, version, asp):
    """Lower-case file names of the shared framework that will run the app: a self-contained app's
    own (Windows) copies of these are left out of its run folder."""
    rt = runtimes(muxer)
    names = set()
    for fw in (NETCORE, ASPNET) if asp else (NETCORE,):
        d = rt.get("_dirs", {}).get((fw, version))
        if not d and fw == ASPNET:
            majors = rt.get(ASPNET, {}).get(int(version.split(".")[0]), [])
            d = rt.get("_dirs", {}).get((fw, _newest(majors))) if majors else None
        try:
            names |= {n.lower() for n in os.listdir(d)} if d else set()
        except OSError:
            pass
    return names


def _head(path):
    try:
        with open(path, "rb") as f:
            return f.read(HEAD)
    except OSError:
        return b""


def _entry_head(f, entry):
    out = bytearray()
    for chunk in pe.iter_entry(f, entry):
        out += chunk
        if len(out) >= HEAD:
            break
    return bytes(out)


def inspect(real, st, head):
    """What the prompt needs to know about a Windows .exe/.msi/.bat/.cmd."""
    sfx = files.suffix(real)
    if sfx in ("msi", "bat", "cmd"):
        return {"canRun": False, "reason": "windows-program", "detail": {"what": sfx}}
    hdr = pe.header(head)
    if hdr is None:
        return {"canRun": False, "reason": "not-a-program"}
    info = {"machine": hdr["machine"], "gui": hdr["subsystem"] == pe.GUI}
    folder = os.path.dirname(real)
    stem = os.path.basename(real)[:-4] if real.lower().endswith(".exe") else os.path.basename(real)
    with open(real, "rb") as f:
        off = pe.find_bundle(f, st.st_size)
        if off:
            try:
                man = pe.manifest(f, off, st.st_size)
                rc_entry = next((e for e in man["entries"] if e["type"] == "runtimeconfig"), None)
                if not rc_entry or not rc_entry["path"].endswith(".runtimeconfig.json") or pe.safe_path(rc_entry["path"]) is None:
                    return dict(info, canRun=False, reason="broken", detail={"why": "no runtimeconfig"})
                rc = json.loads(pe.read_entry(f, rc_entry, cap=MAX_RC))
                name = os.path.basename(rc_entry["path"])[:-len(".runtimeconfig.json")]
                main = next((e for e in man["entries"] if e["path"] == name + ".dll"), None)
                main_hdr = pe.header(_entry_head(f, main)) if main else None
            except (pe.BadFile, ValueError, UnicodeDecodeError) as e:
                return dict(info, canRun=False, reason="broken", detail={"why": str(e)})
            info.update(mode="bundle", bundleId=man["id"], assembly=name)
        else:
            rc_path, dll = (os.path.join(folder, stem + ".runtimeconfig.json"), os.path.join(folder, stem + ".dll"))
            if not (os.path.isfile(rc_path) and os.path.isfile(dll)):
                try:
                    cands = [n for n in os.listdir(folder) if n.lower().endswith(".runtimeconfig.json")]
                except OSError:
                    cands = []
                if len(cands) == 1:
                    s2 = cands[0][:-len(".runtimeconfig.json")]
                    rc_path, dll = os.path.join(folder, cands[0]), os.path.join(folder, s2 + ".dll")
            if os.path.isfile(rc_path) and os.path.isfile(dll):
                try:
                    with open(rc_path, "rb") as r:
                        rc = json.loads(r.read(MAX_RC))
                except (OSError, ValueError):
                    return dict(info, canRun=False, reason="broken", detail={"why": "unreadable runtimeconfig"})
                main_hdr = pe.header(_head(dll))
                info.update(mode="folder", assembly=os.path.basename(dll)[:-4], dll=dll)
            elif hdr["clr"] is not None:
                # .NET code in the .exe itself, with no runtimeconfig: .NET Framework (or Mono), or C++/CLI.
                if not hdr["clr"]["ilonly"]:
                    return dict(info, canRun=False, reason="cpp-cli")
                return dict(info, canRun=False, reason="netfx", detail={"marker": pe.has_netfx_marker(f, st.st_size)})
            else:
                return dict(info, canRun=False, reason="windows-program", detail={"what": "exe"})
    return _with_runtime(info, rc, main_hdr)


def _with_runtime(info, rc, main_hdr):
    ro = rc.get("runtimeOptions") if isinstance(rc, dict) else None
    if not isinstance(ro, dict):
        return dict(info, canRun=False, reason="broken", detail={"why": "no runtimeOptions"})
    included = ro.get("includedFrameworks")
    fws = included or ro.get("frameworks") or ([ro["framework"]] if isinstance(ro.get("framework"), dict) else [])
    names = {fw.get("name"): str(fw.get("version") or "") for fw in fws if isinstance(fw, dict)}
    tfm = str(ro.get("tfm") or "")
    info.update(tfm=tfm, selfContained=bool(included), configProperties=ro.get("configProperties") or {})
    if DESKTOP in names:
        return dict(info, canRun=False, reason="windows-only-dotnet")
    ver = names.get(NETCORE) or names.get(ASPNET)
    try:
        major = int(ver.split(".")[0])
    except (AttributeError, ValueError):
        return dict(info, canRun=False, reason="broken", detail={"why": "no .NET version"})
    asp = ASPNET in names
    info.update(major=major, aspnet=asp)
    clr = (main_hdr or {}).get("clr")
    if clr and not clr.get("unreadable"):
        if not clr["ilonly"]:
            return dict(info, canRun=False, reason="cpp-cli")
        if clr["x86only"]:
            return dict(info, canRun=False, reason="x86-only")
    rt = choose(major, asp)
    if rt is None:
        return dict(info, canRun=False, reason="runtime-missing", detail={"major": major, "aspnet": asp})
    info.update(runtime=rt)
    return dict(info, canRun=True, reason="")


# ---------------------------------------------------------------------------------------- running
def cache_root():
    base = os.environ.get("XDG_CACHE_HOME") or os.path.join(os.path.expanduser("~"), ".cache")
    return os.path.join(base, "quasar", "dotnet-apps")


def command(info, real, st):
    """(argv, cwd) to start the app; builds its run folder first when it needs one."""
    rt = info["runtime"]
    base = [rt["muxer"]] + (["--roll-forward", "Major"] if rt["rollForward"] else [])
    folder = os.path.dirname(real)
    if info["mode"] == "folder" and not info["selfContained"]:
        return base + [info["dll"]], folder
    run = run_folder(info, real, st)
    return base + [os.path.join(run, info["assembly"] + ".dll")], folder


def run_folder(info, real, st):
    root = cache_root()
    os.makedirs(root, mode=0o700, exist_ok=True)
    prune(root)
    raw = "\0".join((real, str(st.st_size), str(st.st_mtime_ns), info.get("bundleId", ""), info["runtime"]["version"]))
    key = hashlib.sha256(raw.encode("utf-8", "surrogateescape")).hexdigest()[:24]
    final = os.path.join(root, key)
    if os.path.isfile(os.path.join(final, ".complete")):
        _touch(os.path.join(final, ".used"))
        return final
    fw = framework_files(info["runtime"]["muxer"], info["runtime"]["version"], info["aspnet"]) if info["selfContained"] else set()
    tmp = tempfile.mkdtemp(prefix=".building-", dir=root)
    try:
        fd = os.open(tmp, os.O_RDONLY | os.O_DIRECTORY)
        try:
            if info["mode"] == "bundle":
                _fill_bundle(fd, info, real, st, fw)
            else:
                _fill_folder(fd, info, real, fw)
            _link_siblings(fd, real, info)
            _write(fd, ["%s.runtimeconfig.json" % info["assembly"]], [_runtimeconfig(info)], replace=True)
        finally:
            os.close(fd)
        open(os.path.join(tmp, ".complete"), "w").close()
        try:
            os.rename(tmp, final)
        except OSError:
            shutil.rmtree(tmp, ignore_errors=True)       # another start built it meanwhile
    except BaseException:
        shutil.rmtree(tmp, ignore_errors=True)
        raise
    _touch(os.path.join(final, ".used"))
    return final


def _runtimeconfig(info):
    """Framework-dependent on this PC's shared .NET; the app's own settings (configProperties) kept."""
    major = info["major"]
    fws = [{"name": NETCORE, "version": "%d.0.0" % major}]
    if info["aspnet"]:
        fws.append({"name": ASPNET, "version": "%d.0.0" % major})
    ro = {"tfm": info.get("tfm") or "net%d.0" % major, "frameworks": fws}
    if info.get("configProperties"):
        ro["configProperties"] = info["configProperties"]
    return (json.dumps({"runtimeOptions": ro}, indent=2) + "\n").encode()


def _fill_bundle(fd, info, real, st, fw):
    with open(real, "rb") as f:
        man = pe.manifest(f, pe.find_bundle(f, st.st_size), st.st_size)
        want = []
        for e in man["entries"]:
            parts = pe.safe_path(e["path"])
            if parts is None:
                raise pe.BadFile("unsafe path in bundle: %r" % e["path"])
            t, low = e["type"], parts[-1].lower()
            if t in ("symbols", "native", "runtimeconfig"):
                continue                     # Windows machine code; the runtimeconfig is rewritten
            if t == "deps" and info["selfContained"]:
                continue                     # it lists Windows' runtime pack: without it the folder is probed
            if t == "assembly" and info["selfContained"] and len(parts) == 1 and low in fw:
                continue                     # Windows' copy of the framework: this PC's shared one is used
            want.append((parts, e))
        need = sum(e["size"] for _, e in want)
        if need * 1.1 + (16 << 20) > files.free_bytes(cache_root()):
            raise OSError(28, "Not enough free space to unpack this app")
        for parts, e in want:
            _write(fd, parts, pe.iter_entry(f, e))


def _fill_folder(fd, info, real, fw):
    """A self-contained app: links to its own files, without Windows' runtime and machine code."""
    top = os.path.dirname(real)
    asm = info["assembly"].lower()
    count = 0
    for dirpath, dirnames, names in os.walk(top):
        rel = os.path.relpath(dirpath, top)
        parts0 = [] if rel == "." else rel.split(os.sep)
        if len(parts0) > 8:
            dirnames[:] = []
            continue
        dirnames[:] = [d for d in dirnames if not os.path.islink(os.path.join(dirpath, d))]
        for n in names:
            count += 1
            if count > 50000:
                raise OSError("Too many files in this app's folder")
            low = n.lower()
            src = os.path.join(dirpath, n)
            if not parts0 and low in (asm + ".runtimeconfig.json", asm + ".deps.json"):
                continue
            if low.endswith(".pdb"):
                continue
            if low.endswith((".dll", ".exe")):
                h = pe.header(_head(src))
                if h is not None and h["clr"] is None:
                    continue                 # native Windows code
                if not parts0 and low in fw:
                    continue
            if os.path.realpath(src) == real:
                continue
            if not parts0 and low == asm + ".dll":
                # The main assembly is copied, not linked: the .NET host follows links to find the app's
                # folder, and would read the Windows runtimeconfig next to the original.
                _write(fd, [n], _chunks(src))
                continue
            _symlink(fd, parts0 + [n], src)


def _link_siblings(fd, real, info):
    """Files next to the .exe that a bundle doesn't carry (appsettings.json, assets): the app finds them
    in its base folder, which is now the run folder."""
    if info["mode"] != "bundle":
        return
    top = os.path.dirname(real)
    try:
        names = os.listdir(top)
    except OSError:
        return
    for n in names[:2000]:
        low = n.lower()
        if low.endswith((".exe", ".dll", ".pdb")) or os.path.join(top, n) == real:
            continue
        try:
            os.lstat(n, dir_fd=fd)
            continue                         # the bundle has its own copy
        except FileNotFoundError:
            pass
        except OSError:
            continue
        _symlink(fd, [n], os.path.join(top, n))


def _open_parent(fd, parts):
    d = os.dup(fd)
    try:
        for p in parts[:-1]:
            try:
                os.mkdir(p, 0o700, dir_fd=d)
            except FileExistsError:
                pass
            nd = os.open(p, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=d)
            os.close(d)
            d = nd
    except BaseException:
        os.close(d)
        raise
    return d


def _write(fd, parts, chunks, replace=False):
    d = _open_parent(fd, parts)
    try:
        if replace:
            try:
                os.unlink(parts[-1], dir_fd=d)
            except FileNotFoundError:
                pass
        w = os.open(parts[-1], os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=d)
        with os.fdopen(w, "wb") as out:
            for c in chunks:
                out.write(c)
    finally:
        os.close(d)


def _symlink(fd, parts, target):
    d = _open_parent(fd, parts)
    try:
        os.symlink(target, parts[-1], dir_fd=d)
    except FileExistsError:
        pass
    finally:
        os.close(d)


def _chunks(path):
    with open(path, "rb") as f:
        while True:
            b = f.read(1 << 20)
            if not b:
                return
            yield b


def _touch(p):
    try:
        with open(p, "a"):
            pass
        os.utime(p)
    except OSError:
        pass


def prune(root):
    """Run folders not used for 30 days go (checked at most once a day)."""
    stamp = os.path.join(root, ".pruned")
    now = time.time()
    try:
        if now - os.path.getmtime(stamp) < 86400:
            return
    except OSError:
        pass
    for n in os.listdir(root):
        p = os.path.join(root, n)
        if not os.path.isdir(p) or os.path.islink(p):
            continue
        try:
            used = os.path.getmtime(os.path.join(p, ".used")) if os.path.exists(os.path.join(p, ".used")) else os.path.getmtime(p)
        except OSError:
            continue
        limit = 86400 if n.startswith(".building-") else KEEP_DAYS * 86400
        if now - used > limit:
            shutil.rmtree(p, ignore_errors=True)
    _touch(stamp)
