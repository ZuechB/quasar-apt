"""Shell and Python scripts: which interpreter runs one. The script's own #! line wins when that
interpreter exists here; otherwise bash for .sh and python3 for .py. The file's mode is never changed:
the interpreter is given the script, so no execute bit is needed."""
import os
import re
import shutil

DEFAULT = {"shell": "bash", "python": "python3"}
PYTHON = re.compile(r"^python(\d(\.\d+)?)?$")


def _which(name, path_env):
    if "/" in name:
        return name if os.path.isfile(name) and os.access(name, os.X_OK) else ""
    return shutil.which(name, path=path_env) or ""


def shebang(head):
    """(interpreter, [args]) from a #! line, or None. Linux hands everything after the interpreter to it
    as one argument; `env -S` splits it (that's how scripts pass flags through env)."""
    if not head.startswith(b"#!"):
        return None
    line = head[2:].split(b"\n", 1)[0].rstrip(b"\r").decode("utf-8", "replace").strip()
    if not line:
        return None
    interp, _, rest = line.partition(" ")
    rest = rest.strip()
    if os.path.basename(interp) == "env":
        words = rest.split()
        while words and words[0].startswith("-") and words[0] != "-S":
            words.pop(0)              # env -i, -u NAME: not something a double-click can honour
        if words and words[0] == "-S":
            words.pop(0)
        if not words:
            return None
        return words[0], words[1:]
    return interp, ([rest] if rest else [])


def inspect(real, head, lang, path_env=None):
    """{interp: [argv prefix], crlf, missing} for a script; argv = interp + [real]."""
    path_env = path_env if path_env is not None else os.environ.get("PATH", "/usr/local/bin:/usr/bin:/bin")
    crlf = b"\r\n" in head[:4096]
    sb = shebang(head)
    name, args = (sb if sb else (DEFAULT[lang], []))
    base = os.path.basename(name)
    if PYTHON.match(base) and (base in ("python", "python2") or not _which(name, path_env)):
        name = "python3"          # Debian has no python2, and plain "python" only when asked for
    found = _which(name, path_env)
    if not found and "/" in name:
        found = _which(os.path.basename(name), path_env)   # #!/usr/local/bin/bash on a Debian system
    if not found:
        return {"interp": [], "crlf": crlf, "missing": os.path.basename(name), "shebang": bool(sb)}
    found = os.path.abspath(found)
    return {"interp": [found] + args, "crlf": crlf, "missing": "", "shebang": bool(sb)}
