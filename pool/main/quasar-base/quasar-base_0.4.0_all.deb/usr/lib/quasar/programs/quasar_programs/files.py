"""File facts the prompt and the launcher need: identity, ownership, where it came from, its name."""
import hashlib
import os
import re
import stat
import unicodedata
from urllib.parse import urlsplit

COMPANY_HOME = os.environ.get("QUASAR_COMPANY_HOME", "/home/companies")
COMPANY_ID = re.compile(r"^[a-z][a-z0-9-]{0,21}$")

# Kinds by suffix. One table for every entry point (desktop, Files, fileop, other apps): MIME types
# can't tell these apart (file(1) calls a .sh without a shebang text/plain, an AppImage
# application/x-pie-executable like every other program).
SCRIPT = {"sh": "shell", "py": "python"}
WINDOWS = {"exe", "msi", "bat", "cmd"}


def suffix(path):
    base = os.path.basename(path)
    i = base.rfind(".")
    return base[i + 1:].lower() if i > 0 else ""


def kind_by_suffix(path):
    s = suffix(path)
    if s in SCRIPT:
        return "script"
    if s == "appimage":
        return "appimage"
    if s in WINDOWS:
        return "windows"
    if s == "deb":
        return "deb"
    return ""


def identity(path):
    """(realpath, stat) of the file itself; raises OSError when it isn't a regular file."""
    real = os.path.realpath(path)
    st = os.stat(real)
    if not stat.S_ISREG(st.st_mode):
        raise IsADirectoryError(real)
    return real, st


def key_of(real, st):
    # Which file this is, as inspected: a replaced, edited or moved file gets a new key.
    raw = "\0".join((real, str(st.st_dev), str(st.st_ino), str(st.st_size), str(st.st_mtime_ns)))
    return hashlib.sha256(raw.encode("utf-8", "surrogateescape")).hexdigest()[:32]


def owner(real, st):
    """"you" when this account owns the file (or root does) and no other account can change it where it
    is; "other" otherwise. Another account's file, or one in a folder others can write to, could be
    swapped between the prompt and the run, so it never counts as allowed."""
    uid = os.getuid()
    if st.st_uid not in (uid, 0) or st.st_mode & stat.S_IWOTH:
        return "other"
    if st.st_uid == 0 and st.st_mode & stat.S_IWGRP:
        return "other"
    try:
        d = os.stat(os.path.dirname(real))
    except OSError:
        return "other"
    # A folder another account owns (a company's home, someone's shared folder) or one anyone can write
    # to without the sticky bit lets them rename the file away and put another in its place.
    if d.st_uid not in (uid, 0) or (d.st_mode & stat.S_IWOTH and not d.st_mode & stat.S_ISVTX):
        return "other"
    return "you"


def origin(real):
    """The site a browser saved it from (user.xdg.origin.url, set by Chromium and Firefox)."""
    try:
        url = os.getxattr(real, "user.xdg.origin.url").decode("utf-8", "replace")
    except (OSError, AttributeError):
        return ""
    host = urlsplit(url).hostname or ""
    return host[4:] if host.startswith("www.") else host


def display_name(name):
    """The name as the prompt shows it: direction overrides and other invisible characters removed, so
    "Photo‮gpj.sh" can't pose as "Photohs.jpg"."""
    out = []
    for ch in name:
        cat = unicodedata.category(ch)
        if cat in ("Cc", "Cf", "Co", "Cs", "Zl", "Zp"):
            continue
        out.append(ch)
    return "".join(out).strip() or "?"


def slug(text, limit=40):
    s = re.sub(r"[^A-Za-z0-9_.-]+", "_", text).strip("._-")
    return (s or "program")[:limit]


def company_of(real):
    """The company whose home holds the file ("" for anything else)."""
    root = COMPANY_HOME.rstrip("/") + "/"
    if not real.startswith(root):
        return ""
    cid = real[len(root):].split("/", 1)[0]
    return cid if COMPANY_ID.match(cid) else ""


def live():
    return os.path.isdir(os.environ.get("QUASAR_LIVE_DIR", "/run/live"))


def free_bytes(path):
    """Room to write under path. On the live USB everything lands in memory, so the smaller of the
    filesystem's free space and available memory plus half the free swap (the Store's rule)."""
    try:
        v = os.statvfs(path)
        free = v.f_bavail * v.f_frsize
    except OSError:
        return 0
    if live():
        mem = {}
        try:
            with open("/proc/meminfo") as f:
                for line in f:
                    k, _, rest = line.partition(":")
                    mem[k] = int(rest.split()[0]) * 1024
        except (OSError, ValueError, IndexError):
            return free
        free = min(free, mem.get("MemAvailable", free) + mem.get("SwapFree", 0) // 2)
    return free


def mount_of(real):
    """(fstype, options) of the mount holding the file, from /proc/self/mountinfo."""
    best, fstype, opts = "", "", ""
    try:
        with open("/proc/self/mountinfo") as f:
            for line in f:
                parts = line.split(" - ")
                if len(parts) != 2:
                    continue
                left, right = parts[0].split(), parts[1].split()
                if len(left) < 6 or len(right) < 1:
                    continue
                mp = left[4].replace("\\040", " ")
                if (real == mp or real.startswith(mp.rstrip("/") + "/")) and len(mp) >= len(best):
                    best, fstype, opts = mp, right[0], left[5] + "," + (right[2] if len(right) > 2 else "")
    except OSError:
        pass
    return fstype, opts


def can_execute_here(real):
    """Whether a program on this drive can be made executable where it is: noexec mounts and drives
    without Unix permissions (FAT, exFAT, NTFS: udisks mounts FAT with showexec) can't."""
    try:
        if os.statvfs(real).f_flag & os.ST_NOEXEC:
            return False
    except OSError:
        return False
    fstype, _ = mount_of(real)
    return fstype not in ("vfat", "msdos", "exfat", "ntfs", "ntfs3", "fuseblk", "iso9660", "udf")
