"""Files the user has said yes to: double-clicking one of them again runs it without asking. Keyed by
the file's identity (path, device, inode, size, modification time), so an edited, replaced or moved
file asks again. Only this helper writes the list."""
import fcntl
import json
import os
import time

LIMIT = 200


def path():
    base = os.environ.get("XDG_STATE_HOME") or os.path.join(os.path.expanduser("~"), ".local", "state")
    return os.path.join(base, "quasar", "programs.json")


def _load(p):
    try:
        with open(p) as f:
            data = json.load(f)
        items = data.get("allowed", [])
        return [i for i in items if isinstance(i, dict) and isinstance(i.get("key"), str)]
    except (OSError, ValueError, AttributeError):
        return []


def is_allowed(key):
    return any(i["key"] == key for i in _load(path()))


def allow(key, real, name):
    p = path()
    os.makedirs(os.path.dirname(p), mode=0o700, exist_ok=True)
    with open(p + ".lock", "a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        items = [i for i in _load(p) if i["key"] != key and i.get("path") != real]
        items.append({"key": key, "path": real, "name": name, "at": int(time.time())})
        items = items[-LIMIT:]
        tmp = p + ".tmp"
        with open(tmp, "w") as f:
            json.dump({"allowed": items}, f, indent=1)
            f.write("\n")
        os.replace(tmp, p)
