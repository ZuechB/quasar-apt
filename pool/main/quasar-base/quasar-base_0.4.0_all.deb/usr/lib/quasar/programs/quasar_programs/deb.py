"""A .deb file as the Store shows it before installing: its fields, what installing it would do (apt's
dry run, as this user: what it adds, what it would remove, what's missing and needs the internet), and
its own icon and desktop entry, read from the package without unpacking anything to disk.

Installing happens in the root helper quasar-debfile, which refuses what this only reports."""
import hashlib
import json
import os
import re
import subprocess
import tarfile

from . import files

NAME_RE = re.compile(r"^[a-z0-9][a-z0-9+.-]*$")
RECORDS = os.environ.get("QUASAR_DEBFILE_RECORDS", "/var/lib/quasar/debfiles.json")
ICON_EXT = (".png", ".svg")
ICON_MAX = 2 << 20
ENV = dict(os.environ, LC_ALL="C.UTF-8", DEBIAN_FRONTEND="noninteractive")


def fields(path):
    p = subprocess.run(["dpkg-deb", "-f", path], capture_output=True, timeout=60, env=ENV)
    if p.returncode != 0:
        raise ValueError(p.stderr.decode("utf-8", "replace").strip() or "This isn't a package dpkg can read")
    out, key = {}, None
    for line in p.stdout.decode("utf-8", "replace").splitlines():
        if line.startswith((" ", "\t")) and key:
            out[key] += "\n" + line[1:]
        elif ":" in line:
            key, _, v = line.partition(":")
            key = key.strip()
            out[key] = v.strip()
    return out


def description(text):
    """(summary, long text) from a Description field: continuation lines, " ." = an empty line."""
    lines = (text or "").split("\n")
    summary = lines[0].strip()
    body = []
    for ln in lines[1:]:
        s = ln.strip()
        body.append("" if s == "." else s)
    return summary, "\n".join(body).strip()


def installed_version(name):
    p = subprocess.run(["dpkg-query", "-W", "-f=${db:Status-Abbrev}\t${Version}", name], capture_output=True,
                       text=True, timeout=30, env=ENV)
    st, _, ver = p.stdout.partition("\t")
    return ver.strip() if p.returncode == 0 and st.startswith("ii") else ""


def compare(a, op, b):
    return subprocess.run(["dpkg", "--compare-versions", a, op, b], timeout=30).returncode == 0


def records():
    try:
        with open(RECORDS) as f:
            data = json.load(f)
        return data.get("packages", {}) if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def plan(path):
    """apt's dry run of installing the file: {installs, removes, missing, ok, needsInternet}."""
    p = subprocess.run(["apt-get", "-s", "-q", "-o", "Debug::NoLocking=1", "install", "--no-install-recommends", path],
                       capture_output=True, text=True, timeout=180, env=ENV)
    installs, removes, missing = [], [], []
    for line in p.stdout.splitlines():
        m = re.match(r"^(Inst|Remv) (\S+)", line)
        if m:
            (installs if m.group(1) == "Inst" else removes).append(m.group(2))
    for line in (p.stdout + "\n" + p.stderr).splitlines():
        m = re.search(r"Depends: (\S+).* but it is not (installable|going to be installed)", line)
        if m and m.group(1) not in missing:
            missing.append(m.group(1))
        m = re.search(r"Unable to locate package (\S+)", line)
        if m and m.group(1) not in missing:
            missing.append(m.group(1))
    lists = any(n.endswith("_Packages") for n in _listdir("/var/lib/apt/lists"))
    # The first Inst is the package itself; anything more is downloaded. Missing packages need fresh
    # package lists (the image ships none), which also means the internet.
    return {"ok": p.returncode == 0, "installs": installs, "removes": removes, "missing": missing,
            "listsPresent": lists, "needsInternet": bool(missing) or len(installs) > 1}


def _listdir(d):
    try:
        return os.listdir(d)
    except OSError:
        return []


def inspect(path, want_plan=True):
    real, st = files.identity(path)
    f = fields(real)
    name = f.get("Package", "")
    if not NAME_RE.match(name):
        raise ValueError("This package has no usable name")
    summary, body = description(f.get("Description", ""))
    try:
        isize = int(f.get("Installed-Size", "0")) * 1024
    except ValueError:
        isize = 0
    have = installed_version(name)
    rec = records().get(name)
    ver = f.get("Version", "")
    out = {"kind": "deb", "path": real, "file": os.path.basename(real), "name": name, "version": ver,
           "arch": f.get("Architecture", ""), "maintainer": f.get("Maintainer", ""), "summary": summary,
           "description": body, "homepage": f.get("Homepage", ""), "section": f.get("Section", ""),
           "size": st.st_size, "installedSize": isize, "sha256": sha256(real), "origin": files.origin(real),
           "installed": have, "fromFile": bool(rec), "essential": f.get("Essential", "").lower() == "yes",
           "priority": f.get("Priority", "")}
    if have and ver:
        out["older"] = compare(ver, "lt", have)
        out["same"] = compare(ver, "eq", have)
    if want_plan:
        out["plan"] = plan(real)
    return out


def icon(path, out_dir):
    """The package's desktop entry and icon, read from its data archive in memory (dpkg-deb unpacks
    any compression, tarfile reads the stream). Returns {desktopId, appName, icon} (empty if none)."""
    real, _ = files.identity(path)
    desks, icons = {}, {}
    proc = subprocess.Popen(["dpkg-deb", "--fsys-tarfile", real], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, env=ENV)
    total = 0
    try:
        with tarfile.open(fileobj=proc.stdout, mode="r|") as t:
            for m in t:
                if not m.isfile():
                    continue
                n = m.name.lstrip("./")
                if n.startswith("usr/share/applications/") and n.endswith(".desktop") and m.size <= 64 << 10:
                    desks[os.path.basename(n)] = t.extractfile(m).read().decode("utf-8", "replace")
                elif (n.startswith("usr/share/icons/hicolor/") or n.startswith("usr/share/pixmaps/")) \
                        and n.endswith(ICON_EXT) and m.size <= ICON_MAX and total < 24 << 20:
                    data = t.extractfile(m).read()
                    total += len(data)
                    icons.setdefault(os.path.basename(n).rsplit(".", 1)[0], []).append((n, data))
    except (tarfile.TarError, OSError):
        pass
    finally:
        proc.stdout.close()
        proc.wait(timeout=60)
    if not desks:
        return {"desktopId": "", "appName": "", "icon": ""}
    # The entry that is shown in a launcher (not NoDisplay), else the first.
    chosen = None
    for fname, text in sorted(desks.items()):
        e = _entry(text)
        if e.get("Type", "Application") == "Application" and e.get("NoDisplay", "").lower() != "true":
            chosen = (fname, e)
            break
    if chosen is None:
        fname = sorted(desks)[0]
        chosen = (fname, _entry(desks[fname]))
    fname, e = chosen
    res = {"desktopId": fname[:-8], "appName": e.get("Name", "")[:200], "icon": ""}
    want = os.path.basename(e.get("Icon", ""))
    want = want.rsplit(".", 1)[0] if want.endswith(ICON_EXT) else want
    if want in icons:
        def rank(item):
            n, data = item
            if n.endswith(".svg"):
                return 0
            m = re.search(r"/(\d+)x\d+/", n)
            size = int(m.group(1)) if m else 48
            return 1 + abs(256 - size)
        n, data = sorted(icons[want], key=rank)[0]
        os.makedirs(out_dir, mode=0o700, exist_ok=True)
        dest = os.path.join(out_dir, "icon" + (".svg" if n.endswith(".svg") else ".png"))
        with open(dest + ".tmp", "wb") as f:
            f.write(data)
        os.replace(dest + ".tmp", dest)
        res["icon"] = dest
    return res


def installed_from_files():
    """Packages installed from files (quasar-debfile's records) that are still installed, each with the
    desktop entry it put in /usr/share/applications (name, icon name) for the Store's Installed page."""
    out = []
    for name, rec in sorted(records().items()):
        if not NAME_RE.match(name):
            continue
        ver = installed_version(name)
        if not ver:
            continue
        item = {"name": name, "version": ver, "summary": str(rec.get("summary", ""))[:200], "desktopId": "",
                "appName": "", "iconName": "", "sources": sorted(rec.get("sources") or {})}
        p = subprocess.run(["dpkg-query", "-L", name], capture_output=True, text=True, timeout=60, env=ENV)
        desks = sorted(ln for ln in p.stdout.splitlines() if ln.startswith("/usr/share/applications/") and ln.endswith(".desktop"))
        for d in desks:
            try:
                with open(d, encoding="utf-8", errors="replace") as f:
                    e = _entry(f.read(65536))
            except OSError:
                continue
            if e.get("NoDisplay", "").lower() == "true" and len(desks) > 1:
                continue
            item.update(desktopId=os.path.basename(d)[:-8], appName=e.get("Name", "")[:200], iconName=e.get("Icon", "")[:200])
            break
        out.append(item)
    return out


def _entry(text):
    out, section = {}, ""
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("["):
            section = line
            continue
        if section == "[Desktop Entry]" and "=" in line and not line.startswith("#"):
            k, _, v = line.partition("=")
            out.setdefault(k.strip(), v.strip())
    return out
