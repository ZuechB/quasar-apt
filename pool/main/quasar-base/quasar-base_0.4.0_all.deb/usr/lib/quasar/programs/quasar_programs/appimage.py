"""AppImages: check one, make it runnable, and add it to (or remove it from) the launcher.

"Add to Apps" moves the file into ~/Applications (a copy when it's on another drive: fileop drop's
rules), reads its desktop entry and icon with the AppImage's own --appimage-extract (that runs the
AppImage's code, so only after the user said yes) and writes
~/.local/share/applications/quasar-appimage-<slug>.desktop. Quickshell's DesktopEntries already watches
that folder (quasar-session creates it before the shell starts)."""
import configparser
import hashlib
import os
import re
import shutil
import stat
import subprocess
import tempfile

from . import allow, files

MACHINES = {62: "x86_64", 183: "aarch64", 3: "i386", 40: "arm"}
PREFIX = "quasar-appimage-"
FIELD_CODES = ("%U", "%u", "%F", "%f")
ICON_MAX = 4 << 20
FILEOP = os.environ.get("QUASAR_FILEOP", "/usr/libexec/quasar/fileop")


def data_home():
    return os.environ.get("XDG_DATA_HOME") or os.path.join(os.path.expanduser("~"), ".local", "share")


def apps_dir():
    return os.path.join(data_home(), "applications")


def icons_dir():
    return os.path.join(data_home(), "quasar", "appimages")


def target_dir():
    return os.environ.get("QUASAR_APPIMAGE_DIR") or os.path.join(os.path.expanduser("~"), "Applications")


def inspect(real, head):
    if head[:4] != b"\x7fELF":
        return {"canRun": False, "reason": "not-a-program"}
    kind = {b"AI\x01": 1, b"AI\x02": 2}.get(head[8:11], 0)
    machine = int.from_bytes(head[18:20], "little") if len(head) >= 20 else 0
    arch = MACHINES.get(machine, str(machine))
    here = os.uname().machine
    info = {"appimageType": kind, "arch": arch, "executable": os.access(real, os.X_OK),
            "runsHere": files.can_execute_here(real), "entry": entry_for(real)}
    if arch != here:
        return dict(info, canRun=False, reason="wrong-arch")
    return dict(info, canRun=True, reason="")


def fuse_ok():
    if os.environ.get("QUASAR_APPIMAGE_FUSE") in ("0", "1"):
        return os.environ["QUASAR_APPIMAGE_FUSE"] == "1"
    have_lib = any(os.path.exists(p) for p in ("/usr/lib/x86_64-linux-gnu/libfuse.so.2", "/usr/lib/aarch64-linux-gnu/libfuse.so.2",
                                                 "/lib/x86_64-linux-gnu/libfuse.so.2"))
    return os.access("/dev/fuse", os.R_OK | os.W_OK) and bool(shutil.which("fusermount3") or shutil.which("fusermount")) and have_lib


def command(real):
    """(argv, extra env) to run it, making it executable first. Without working FUSE the AppImage
    unpacks itself to /tmp each time instead (slower, but it runs)."""
    st = os.stat(real)
    if not st.st_mode & stat.S_IXUSR:
        os.chmod(real, stat.S_IMODE(st.st_mode) | stat.S_IXUSR)
    env = {} if fuse_ok() else {"APPIMAGE_EXTRACT_AND_RUN": "1"}
    return [real], env


# ---------------------------------------------------------------------------------------- launcher
def entry_for(real):
    """The launcher entry that runs this AppImage, if it was added to Apps."""
    try:
        names = os.listdir(apps_dir())
    except OSError:
        return ""
    for n in names:
        if n.startswith(PREFIX) and n.endswith(".desktop"):
            e = read_entry(os.path.join(apps_dir(), n))
            if e.get("X-Quasar-AppImage") == real:
                return n[:-8]
    return ""


def read_entry(path):
    cp = configparser.RawConfigParser(interpolation=None, strict=False)
    cp.optionxform = str
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            cp.read_file(f)
        return {k: unescape(v) for k, v in cp.items("Desktop Entry")}
    except (OSError, configparser.Error):
        return {}


def unescape(v):
    out, i = [], 0
    while i < len(v):
        c = v[i]
        if c == "\\" and i + 1 < len(v):
            out.append({"s": " ", "n": "\n", "t": "\t", "r": "\r", "\\": "\\"}.get(v[i + 1], v[i + 1]))
            i += 2
            continue
        out.append(c)
        i += 1
    return "".join(out)


def escape_value(v):
    """A desktop entry string value (key-file escapes)."""
    return v.replace("\\", "\\\\").replace("\n", "\\n").replace("\t", "\\t").replace("\r", "\\r")


def exec_quote(arg):
    """One argument of Exec=, quoted per the Desktop Entry spec: inside double quotes, " ` $ \\ get a
    backslash; % is doubled (field codes). The key-file escape then doubles the backslashes again."""
    q = arg.replace("\\", "\\\\").replace('"', '\\"').replace("`", "\\`").replace("$", "\\$")
    return '"' + q.replace("%", "%%") + '"'


def _single_line(s, limit=200):
    return re.sub(r"[\x00-\x1f\x7f]+", " ", s or "").strip()[:limit]


# Characters that need escapes inside an Exec= argument. Launchers disagree on those escapes
# (the spec's double unescaping vs. a plain shlex split), so an added AppImage never has them in its
# name: it's renamed as it moves into ~/Applications.
UNSAFE = re.compile(r'["`$\\%\x00-\x1f\x7f]')


def safe_name(name):
    return UNSAFE.sub("_", name)


def _unique(folder, name):
    stem, dot, ext = name.rpartition(".")
    if not dot:
        stem, ext = name, ""
    cand, n = name, 2
    while os.path.lexists(os.path.join(folder, cand)):
        cand = "%s (%d)%s" % (stem, n, "." + ext if ext else "")
        n += 1
    return cand


def integrate(real):
    """Moves/copies the AppImage into ~/Applications and adds it to the launcher. Returns
    {path, entry, name}."""
    dest_dir = os.path.realpath(target_dir()) if os.path.isdir(target_dir()) else target_dir()
    os.makedirs(dest_dir, exist_ok=True)
    dest_dir = os.path.realpath(dest_dir)
    path = real
    if os.path.dirname(real) != dest_dir:
        path = _drop(dest_dir, real)
    base = os.path.basename(path)
    if safe_name(base) != base:
        new = os.path.join(dest_dir, _unique(dest_dir, safe_name(base)))
        os.rename(path, new)
        path = new
    if UNSAFE.search(path):
        raise ValueError("This folder's name can't go in the launcher")
    command(path)                                    # executable at its new place
    meta = _extract_meta(path)
    name = _single_line(meta.get("Name")) or files.display_name(os.path.basename(path).rsplit(".", 1)[0])
    h = hashlib.sha256(path.encode("utf-8", "surrogateescape")).hexdigest()[:6]
    sl = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")[:40] or "app"
    desk_id = "%s%s-%s" % (PREFIX, sl, h)
    icon = _save_icon(meta.get("_icon"), desk_id)
    code = next((c for c in FIELD_CODES if c in (meta.get("Exec") or "")), "%U")
    lines = ["[Desktop Entry]", "Type=Application",
             "Name=" + escape_value(name),
             "Exec=" + escape_value(exec_quote(path)) + " " + code,
             "TryExec=" + escape_value(path),
             "X-Quasar-AppImage=" + escape_value(path)]
    for k in ("GenericName", "Comment", "Categories", "StartupWMClass", "Keywords"):
        if meta.get(k):
            lines.append("%s=%s" % (k, escape_value(_single_line(meta[k], 400))))
    if (meta.get("Terminal") or "").strip().lower() == "true":
        lines.append("Terminal=true")
    if icon:
        lines.append("Icon=" + escape_value(icon))
    os.makedirs(apps_dir(), exist_ok=True)
    out = os.path.join(apps_dir(), desk_id + ".desktop")
    tmp = out + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    os.replace(tmp, out)
    real2, st2 = files.identity(path)
    allow.allow(files.key_of(real2, st2), real2, os.path.basename(real2))
    return {"path": path, "entry": desk_id, "name": name}


def _drop(dest_dir, real):
    """fileop drop: a move on the same drive, a copy from another; never overwrites."""
    p = subprocess.run([FILEOP, "drop", dest_dir, real], capture_output=True, text=True, timeout=3600)
    import json
    for line in p.stdout.splitlines():
        try:
            o = json.loads(line)
        except ValueError:
            continue
        if o.get("source") == real and o.get("path"):
            return o["path"]
        if o.get("error"):
            raise OSError(o["error"])
    if p.returncode != 0:
        raise OSError(p.stderr.strip() or "Couldn't move it to Applications")
    raise OSError("Couldn't move it to Applications")


def _extract_meta(path):
    """The AppImage's own desktop entry and icon, unpacked by its runtime into a scratch folder."""
    meta = {}
    with tempfile.TemporaryDirectory(prefix="quasar-appimage-") as tmp:
        env = dict(os.environ)
        env.pop("APPIMAGE_EXTRACT_AND_RUN", None)

        def extract(pattern):
            try:
                subprocess.run([path, "--appimage-extract", pattern], cwd=tmp, env=env, timeout=120,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except (OSError, subprocess.SubprocessError):
                pass

        root = os.path.realpath(os.path.join(tmp, "squashfs-root"))

        def resolve(rel):
            """The file `rel` names inside the unpacked AppImage. Top-level entries are usually links
            (appimagetool.desktop -> usr/share/applications/…, .DirIcon -> the icon): followed only
            while they stay inside, their targets unpacked when they aren't yet."""
            p = os.path.join(root, rel)
            for _ in range(4):
                t = os.path.realpath(p)
                if t != root and not t.startswith(root + os.sep):
                    return None
                if os.path.isfile(t):
                    return t
                if not os.path.lexists(p):
                    return None
                extract(os.path.relpath(t, root))
            return None

        extract("*.desktop")
        desk = None
        if os.path.isdir(root):
            for n in sorted(os.listdir(root)):
                if n.endswith(".desktop"):
                    desk = resolve(n)
                    if desk:
                        break
        if desk:
            meta = read_entry(desk)
        icon_name = os.path.basename(meta.get("Icon") or "")
        cands = []
        if icon_name and re.match(r"^[\w.+-]+$", icon_name):
            for pat in (icon_name + ".png", icon_name + ".svg", icon_name,
                        "usr/share/icons/hicolor/256x256/apps/%s.png" % icon_name,
                        "usr/share/icons/hicolor/512x512/apps/%s.png" % icon_name,
                        "usr/share/icons/hicolor/scalable/apps/%s.svg" % icon_name):
                cands.append(pat)
        cands.append(".DirIcon")
        for pat in cands:
            extract(pat)
            p = resolve(pat)
            if p and 0 < os.path.getsize(p) <= ICON_MAX:
                with open(p, "rb") as f:
                    data = f.read()
                if data[:8] == b"\x89PNG\r\n\x1a\n" or b"<svg" in data[:4096]:
                    meta["_icon"] = data
                    break
    return meta


def _save_icon(data, desk_id):
    if not data:
        return ""
    ext = "png" if data[:8] == b"\x89PNG\r\n\x1a\n" else "svg"
    os.makedirs(icons_dir(), exist_ok=True)
    p = os.path.join(icons_dir(), "%s.%s" % (desk_id, ext))
    with open(p + ".tmp", "wb") as f:
        f.write(data)
    os.replace(p + ".tmp", p)
    return p


def unintegrate(desk_id):
    """Takes an AppImage out of the launcher: its entry and icon go, the file goes to the Trash."""
    if not re.match(r"^%s[a-z0-9-]+$" % re.escape(PREFIX), desk_id or ""):
        raise ValueError("Not an AppImage added to Apps")
    entry = os.path.join(apps_dir(), desk_id + ".desktop")
    e = read_entry(entry)
    if not e:
        raise FileNotFoundError("It isn't in Apps any more")
    path = e.get("X-Quasar-AppImage", "")
    trashed = False
    if path and os.path.isfile(path):
        p = subprocess.run([FILEOP, "trash", path], capture_output=True, text=True, timeout=600)
        trashed = p.returncode == 0
    icon = e.get("Icon", "")
    if icon and os.path.dirname(icon) == icons_dir() and os.path.basename(icon).startswith(desk_id):
        try:
            os.unlink(icon)
        except OSError:
            pass
    os.unlink(entry)
    return {"entry": desk_id, "path": path, "trashed": trashed}
