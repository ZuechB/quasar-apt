"""Input checks. Everything that reaches a root helper, a definition, a drop-in or a unit passes through
here first; anything unexpected is refused, never "cleaned up"."""
import os
import re

from .events import ServicesError, USAGE

# svc-<id> must fit useradd's 32 characters.
ID_RE = re.compile(r"^[a-z][a-z0-9-]{0,24}[a-z0-9]$")
_LABEL = r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?"
DOMAIN_RE = re.compile(r"^(?:%s\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$" % _LABEL)
ENV_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]{0,127}$")
MEM_RE = re.compile(r"^[1-9][0-9]{0,5}[KMG]\Z")
KINDS = ("unity", "dotnet", "program")
REACHES = ("this-pc", "home", "internet")
PROTOS = ("udp", "tcp")
MAX_PORTS = 16
MAX_ARGS = 64
# The service's environment can't move its home or pretend to be systemd.
RESERVED_ENV = {"HOME", "USER", "LOGNAME", "SHELL", "PATH", "STATE_DIRECTORY", "CREDENTIALS_DIRECTORY",
                "INVOCATION_ID", "JOURNAL_STREAM", "NOTIFY_SOCKET", "LISTEN_FDS", "LISTEN_PID",
                "LISTEN_FDNAMES", "SYSTEMD_EXEC_PID", "QUASAR_SERVICE"}
# Folders a server can't run from: kernel views, volatile runtime folders and Services' own.
NOT_FOLDERS = ("/proc", "/sys", "/dev", "/run", "/var/lib/quasar-svc", "/etc/quasar")


def _bad(text, code="invalid"):
    raise ServicesError(text, code, USAGE)


def _plain_text(value, limit):
    return isinstance(value, str) and len(value) <= limit and not any(ord(c) < 32 or ord(c) == 127 for c in value)


def arg(value, what="argument"):
    """A command-line argument: non-empty, no whitespace or NUL (pkexec joins argv with spaces)."""
    if not isinstance(value, str) or not value or len(value) > 512 or "\x00" in value \
            or any(c.isspace() for c in value):
        _bad("That %s isn't valid." % what)
    return value


def service_id(value):
    if not isinstance(value, str) or not ID_RE.match(value):
        _bad("Service names use 2–26 lowercase letters, digits and dashes, starting with a letter.")
    return value


def name(value):
    v = (value or "").strip() if isinstance(value, str) else ""
    if not v or not _plain_text(v, 60):
        _bad("Give it a name of up to 60 characters.")
    return v


def kind(value):
    if value not in KINDS:
        _bad("Unknown kind of program.")
    return value


def folder(value):
    if not isinstance(value, str) or not value.startswith("/") or len(value) > 4096 \
            or any(c in value for c in "\x00\r\n"):
        _bad("Pick the folder the server is in.")
    v = value.rstrip("/") or "/"
    if v == "/" or os.path.normpath(v) != v or "/../" in v + "/" or "/./" in v + "/":
        _bad("Pick the folder the server is in.")
    if v.startswith(("/run/media/", "/media/")):
        _bad("A server can't run from a removable drive (it would stop when the drive goes). Copy the folder "
             "into your home folder first.")
    for bad in NOT_FOLDERS:
        if v == bad or v.startswith(bad + "/"):
            _bad("A server can't run from %s." % bad)
    return v


def exec_path(value):
    """The program, relative to the folder ("Animal Go Server.x86_64", "bin/server")."""
    if not isinstance(value, str) or not value or len(value) > 512 or value.startswith("/") \
            or any(c in value for c in "\x00\r\n\\"):
        _bad("Pick the program to start, inside the folder.")
    if any(part in ("", ".", "..") for part in value.split("/")):
        _bad("Pick the program to start, inside the folder.")
    return value


def args(value):
    if value is None:
        return []
    if not isinstance(value, list) or len(value) > MAX_ARGS:
        _bad("Use at most %d arguments." % MAX_ARGS)
    total = 0
    for a in value:
        if not isinstance(a, str) or len(a) > 1000 or "\x00" in a or "\n" in a or "\r" in a:
            _bad("An argument can't be stored.")
        total += len(a)
    if total > 16000:
        _bad("The arguments are too long.")
    return list(value)


def env(value):
    if value is None:
        return []
    if not isinstance(value, list) or len(value) > 64:
        _bad("Use at most 64 environment variables.")
    out, seen = [], set()
    for pair in value:
        if not isinstance(pair, (list, tuple)) or len(pair) != 2:
            _bad("An environment variable can't be stored.")
        k, v = pair
        if not isinstance(k, str) or not ENV_RE.match(k):
            _bad("Use letters, numbers and underscores; names can't start with a number.")
        if k in RESERVED_ENV:
            _bad("%s belongs to Quasar." % k)
        if not isinstance(v, str) or "\x00" in v or len(v) > 32768:
            _bad("That value can't be stored.")
        if k in seen:
            _bad("%s is set twice." % k)
        seen.add(k)
        out.append([k, v])
    return out


def port_number(value):
    if isinstance(value, bool) or not isinstance(value, int) or not 1024 <= value <= 65535:
        _bad("Ports go from 1024 to 65535.")
    return value


def ports(value):
    if value is None:
        return []
    if not isinstance(value, list) or len(value) > MAX_PORTS:
        _bad("Use at most %d ports." % MAX_PORTS)
    out, seen = [], set()
    for item in value:
        if not isinstance(item, dict):
            _bad("A port can't be stored.")
        proto = item.get("proto")
        if proto not in PROTOS:
            _bad("Ports are UDP or TCP.")
        port = port_number(item.get("port"))
        if (proto, port) in seen:
            _bad("%s %d is listed twice." % (proto.upper(), port))
        seen.add((proto, port))
        label = (item.get("label") or "").strip() if isinstance(item.get("label") or "", str) else None
        if label is None or not _plain_text(label, 40):
            _bad("A port's label can be up to 40 characters.")
        reach = item.get("reach") or "home"
        if reach not in REACHES:
            _bad("Choose who can reach each port.")
        out.append({"proto": proto, "port": port, "label": label, "reach": reach})
    return out


def domain(value, what="name"):
    v = (value or "").strip().lower().rstrip(".") if isinstance(value, str) else ""
    for prefix in ("https://", "http://"):
        if v.startswith(prefix):
            v = v[len(prefix):]
    if len(v) > 253 or not DOMAIN_RE.match(v):
        _bad("Enter a %s like play.example.com (without http://)." % what)
    return v


def public(value):
    if not value:
        return None
    if not isinstance(value, dict):
        _bad("That public name can't be stored.")
    name_ = domain(value.get("name"), "public name")
    via = (value.get("via") or "").strip()
    return {"name": name_, "via": domain(via, "dynamic DNS name") if via else ""}


def options(value, old=None):
    old = dict(old or {})
    value = value or {}
    if not isinstance(value, dict):
        _bad("Those options can't be stored.")
    out = {"boot": bool(old.get("boot", True)), "crashRestart": bool(old.get("crashRestart", True)),
           "memoryMax": old.get("memoryMax"), "cpuWeight": old.get("cpuWeight")}
    for key in ("boot", "crashRestart"):
        if key in value:
            if not isinstance(value[key], bool):
                _bad("Unknown option value.")
            out[key] = value[key]
    if "memoryMax" in value:
        mem = value["memoryMax"]
        if mem in (None, ""):
            out["memoryMax"] = None
        elif isinstance(mem, str) and MEM_RE.match(mem):
            out["memoryMax"] = mem
        else:
            _bad("A memory limit looks like 512M or 4G.")
    if "cpuWeight" in value:
        cpu = value["cpuWeight"]
        if cpu in (None, ""):
            out["cpuWeight"] = None
        elif isinstance(cpu, int) and not isinstance(cpu, bool) and 1 <= cpu <= 10000:
            out["cpuWeight"] = cpu
        else:
            _bad("CPU weight goes from 1 to 10000 (100 is everyone else's).")
    return out


def players(value):
    if not value:
        return None
    if not isinstance(value, dict) or not isinstance(value.get("regex"), str):
        _bad("That players pattern can't be stored.")
    rx = value["regex"]
    if not rx or len(rx) > 200:
        _bad("That players pattern can't be stored.")
    try:
        compiled = re.compile(rx)
    except re.error:
        _bad("That players pattern isn't a valid regular expression.")
    if compiled.groups < 1:
        _bad("The players pattern needs a group for the number of players.")
    return {"regex": rx}


def slug(text):
    """A service id suggestion from a name ("Animal Go Server" -> "animal-go-server")."""
    s = re.sub(r"[^a-z0-9]+", "-", (text or "").lower()).strip("-")
    s = re.sub(r"-{2,}", "-", s)
    if not s or not s[0].isalpha():
        s = "server-" + s if s else "server"
    s = s[:26].rstrip("-")
    if len(s) < 2:
        s = (s + "-server")[:26]
    return s
