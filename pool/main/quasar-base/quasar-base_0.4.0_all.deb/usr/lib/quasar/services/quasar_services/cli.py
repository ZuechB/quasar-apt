"""/usr/bin/quasar-service: your servers from a terminal, over SSH too.

  quasar-service list
  quasar-service status ID
  quasar-service start|stop|restart ID
  quasar-service enable|disable ID        start with the PC, or not
  quasar-service logs ID [-f]
  quasar-service inspect FOLDER

Updating a server: quasar-service stop ID, copy the new build into its folder, quasar-service start ID.
A program that a zip made on Windows left without its execute permission gets it back when it starts.
Reads go through services-query (as you); changes through pkexec quasar-services (no password for an
administrator at the PC; elsewhere, an administrator's password).
"""
import json
import os
import subprocess
import sys
import time

QUERY = os.environ.get("QUASAR_SERVICES_QUERY") or "/usr/libexec/quasar/services-query"
ROUTINE = ([os.environ["QUASAR_SERVICES_HELPER"]] if os.environ.get("QUASAR_SERVICES_HELPER")
           else ["pkexec", "/usr/libexec/quasar/quasar-services"])
STATUS = {"running": "running", "starting": "starting", "stopped": "stopped", "failed": "FAILED", "idle": "idle"}


def run_json(cmd, stream=False, on_event=None, stdin=None):
    p = subprocess.Popen(cmd, stdin=stdin, stdout=subprocess.PIPE, text=True, bufsize=1)
    events = []
    for line in p.stdout:
        if not line.startswith("{"):
            continue
        try:
            ev = json.loads(line)
        except ValueError:
            continue
        events.append(ev)
        if on_event:
            on_event(ev)
    return p.wait(), events


def last(events, kind):
    found = [e for e in events if e.get("type") == kind]
    return found[-1] if found else None


def fail(events, rc):
    err = last(events, "error")
    if err:
        print(err.get("message") or "That didn't work.", file=sys.stderr)
        details = (err.get("details") or "").strip()
        if details:
            print("\n" + "\n".join(details.splitlines()[-15:]), file=sys.stderr)
    elif rc == 126:
        print("The password prompt was closed, so nothing changed.", file=sys.stderr)
    elif rc == 127:
        print("Your account isn't allowed to do that. Ask an administrator.", file=sys.stderr)
    else:
        print("That didn't work (code %d)." % rc, file=sys.stderr)
    return 1


def state():
    rc, events = run_json([QUERY, "state"])
    res = last(events, "result")
    if rc != 0 or not res:
        sys.exit(fail(events, rc))
    return res


def server(res, sid):
    for item in res.get("items") or []:
        if item.get("key") == "svc:" + sid:
            return item
    print("There's no server called %s (quasar-service list shows yours)." % sid, file=sys.stderr)
    sys.exit(1)


def _ports(item):
    out = []
    for p in (item.get("server") or {}).get("ports") or []:
        reach = {"internet": "internet", "home": "home network", "this-pc": "this PC"}.get(p.get("reach"), "?")
        out.append("%s %s (%s%s)" % (p["proto"].upper(), p["port"], reach, ", listening" if p.get("listening") else ""))
    return out


def cmd_list(args):
    res = state()
    rows = [i for i in res.get("items") or [] if i.get("source") == "server"]
    if not rows:
        print("No servers yet. Add one in Services (Add a service).")
        return 0
    for i in rows:
        print("%-24s %-9s %s%s" % (i["id"], STATUS.get(i["status"], i["status"]), ", ".join(_ports(i)) or "no ports",
                                   "" if i.get("enabled") else "  (doesn't start with the PC)"))
    return 0


def cmd_status(args):
    res = state()
    i = server(res, args[0])
    s = i.get("server") or {}
    since = i.get("since")
    print("%s (%s)" % (i["name"], i["id"]))
    print("  Status:   %s%s" % (STATUS.get(i["status"], i["status"]),
                                (", up %s" % _dur(time.time() - since)) if since else ""))
    print("  Folder:   %s" % s.get("path"))
    print("  Command:  %s" % i.get("cmd"))
    print("  Account:  %s, saves in %s" % (s.get("account"), s.get("data")))
    print("  Starts with the PC: %s" % ("yes" if i.get("enabled") else "no"))
    for line in _ports(i):
        print("  Port:     " + line)
    lan = res.get("lan") or {}
    ports = [p for p in s.get("ports") or [] if p.get("reach") in ("home", "internet")]
    if lan.get("ip") and ports:
        print("  On your network: %s:%s" % (lan["ip"], ports[0]["port"]))
    if (s.get("public") or {}).get("name") and any(p.get("reach") == "internet" for p in ports):
        print("  From the internet: %s:%s" % (s["public"]["name"],
                                              next(p["port"] for p in ports if p.get("reach") == "internet")))
    ls = s.get("lastStart") or {}
    if ls and not ls.get("ok"):
        print("  Last start: %s" % ls.get("message"))
    if not res.get("firewall", {}).get("on"):
        print("  Note: the firewall is off, so every port on this PC is open to your home network.")
    return 0


def _dur(seconds):
    m = int(seconds // 60)
    if m < 60:
        return "%dm" % m
    h = m // 60
    return "%dh %dm" % (h, m % 60) if h < 24 else "%dd %dh" % (h // 24, h % 24)


def _routine(verb, sid):
    rc, events = run_json(ROUTINE + [verb, sid],
                          on_event=lambda ev: ev.get("type") == "phase" and print(ev.get("text")))
    if rc != 0 or last(events, "error"):
        return fail(events, rc)
    return 0


def cmd_start(args):
    rc = _routine("start", args[0])
    if rc == 0:
        print("%s is running." % args[0])
    return rc


def cmd_stop(args):
    rc = _routine("stop", args[0])
    if rc == 0:
        print("%s is stopped. Replace its files now if you're updating it, then: quasar-service start %s"
              % (args[0], args[0]))
    return rc


def cmd_restart(args):
    rc = _routine("restart", args[0])
    if rc == 0:
        print("%s restarted." % args[0])
    return rc


def cmd_enable(args):
    rc = _routine("enable", args[0])
    if rc == 0:
        print("%s starts with the PC, and it's running." % args[0])
    return rc


def cmd_disable(args):
    rc = _routine("disable", args[0])
    if rc == 0:
        print("%s is stopped and won't start with the PC." % args[0])
    return rc


def cmd_logs(args):
    cmd = [QUERY, "logs", args[0]] + (["-f"] if "-f" in args[1:] else [])

    def show(ev):
        if ev.get("type") == "log":
            print("%s  %s" % (time.strftime("%H:%M:%S", time.localtime(ev.get("t") or 0)), ev.get("m")), flush=True)
        elif ev.get("type") == "players":
            cap = ev.get("max")
            print("          (%s%s playing)" % (ev.get("now"), " of %s" % cap if cap else ""), flush=True)
    try:
        # Not our stdin: a following stream ends when its stdin pipe closes (the app's way to stop it), and a
        # script's stdin often is a closed pipe. Ctrl-C still stops it (SIGINT reaches both).
        rc, events = run_json(cmd, on_event=show, stdin=subprocess.DEVNULL)
    except KeyboardInterrupt:
        return 0
    return 0 if rc == 0 else fail(events, rc)


def cmd_inspect(args):
    path = os.path.abspath(os.path.expanduser(args[0]))
    rc, events = run_json([QUERY, "inspect", path])
    res = last(events, "result")
    if rc != 0 or not res:
        return fail(events, rc)
    print("%s: %s" % (res.get("name"), res.get("label") or "nothing to run"))
    if res.get("facts"):
        print("  " + " · ".join(res["facts"]))
    if res.get("exec"):
        print("  Program:   %s" % res["exec"])
    if res.get("args"):
        print("  Arguments: %s" % " ".join(res["args"]))
    if res.get("flags"):
        print("  Options it reads: %s" % " ".join(f.get("flag", "") for f in res["flags"]))
    for p in res.get("ports") or []:
        print("  Port:      %s %s (%s)" % (p["proto"].upper(), p["port"], p.get("label") or ""))
    for pr in res.get("problems") or []:
        print("  Problem:   " + pr.get("message", ""))
    for n in res.get("notes") or []:
        print("  Note:      " + n)
    return 0


VERBS = {"list": (cmd_list, 0), "status": (cmd_status, 1), "start": (cmd_start, 1), "stop": (cmd_stop, 1),
         "restart": (cmd_restart, 1), "enable": (cmd_enable, 1), "disable": (cmd_disable, 1),
         "logs": (cmd_logs, 1), "inspect": (cmd_inspect, 1)}


def main(argv):
    if not argv or argv[0] in ("-h", "--help", "help") or argv[0] not in VERBS:
        print(__doc__.split("\n\n", 1)[1].split("Reads go")[0].rstrip())
        return 0 if argv and argv[0] in ("-h", "--help", "help") else 2
    fn, nargs = VERBS[argv[0]]
    if len(argv) - 1 < nargs:
        print("quasar-service %s needs %s." % (argv[0], "a folder" if argv[0] == "inspect" else "a server's id"),
              file=sys.stderr)
        return 2
    try:
        return fn(argv[1:])
    except BrokenPipeError:
        return 0
