"""services-query watch: systemd's D-Bus signals drive it; nothing is polled.

It subscribes to both managers (the system one for servers, sites and Quasar's own services; the user
one for Command Deck) and recomputes shortly after anything relevant changes: a unit's state
(PropertiesChanged), a finished job, enable/disable (UnitFilesChanged) or a daemon-reload (which the
admin helper does after adding, changing or removing a server). Not UnitNew/UnitRemoved: its own probes
cause those (see _listen). A burst of signals is folded into one update. Only when the system bus can't
be used does it look every 5 s.

It ends when stdin closes (when stdin is a pipe) or when it's stopped.
"""
import json
import os
import queue
import re
import stat
import sys
import threading
import time

from .events import emit

PREFIXES = ("quasar-svc@", "quasar-site-")
DEBOUNCE = 0.4
POLL = 5.0


def unescape(part):
    """A systemd object path's last part ("quasar_2dsvc_40x_2eservice") back to the unit name."""
    return re.sub(r"_([0-9a-fA-F]{2})", lambda m: chr(int(m.group(1), 16)), part)


def relevant(name, extra):
    return name.startswith(PREFIXES) or name in extra


def _listen(bus, extra, q, stop):
    try:
        from jeepney import DBusAddress, HeaderFields, MatchRule, MessageType, new_method_call
        from jeepney.bus_messages import message_bus
        from jeepney.io.blocking import open_dbus_connection
    except ImportError:
        q.put("down:" + bus)
        return
    try:
        conn = open_dbus_connection(bus=bus)
        mgr = DBusAddress("/org/freedesktop/systemd1", bus_name="org.freedesktop.systemd1",
                          interface="org.freedesktop.systemd1.Manager")
        conn.send_and_get_reply(new_method_call(mgr, "Subscribe"), timeout=10)
        rules = (MatchRule(type="signal", interface="org.freedesktop.DBus.Properties", member="PropertiesChanged",
                           path_namespace="/org/freedesktop/systemd1/unit"),
                 MatchRule(type="signal", interface="org.freedesktop.systemd1.Manager", path="/org/freedesktop/systemd1"))
        for rule in rules:
            conn.send_and_get_reply(new_method_call(message_bus, "AddMatch", "s", (rule.serialise(),)), timeout=10)
    except Exception:                                  # noqa: BLE001 (no bus, no systemd)
        q.put("down:" + bus)
        return
    while not stop.is_set():
        try:
            msg = conn.receive(timeout=1.0)
        except TimeoutError:
            continue
        except Exception:                              # noqa: BLE001 (the bus went away)
            q.put("down:" + bus)
            return
        if msg.header.message_type != MessageType.signal:
            continue
        fields = msg.header.fields
        member = fields.get(HeaderFields.member)
        body = msg.body or ()
        if member == "PropertiesChanged":
            if relevant(unescape(str(fields.get(HeaderFields.path) or "").rsplit("/", 1)[-1]), extra):
                q.put("change")
        # UnitNew/UnitRemoved are left alone on purpose: collect()'s own `systemctl show` loads a unit that
        # isn't loaded (a stopped, disabled server; Docker or the AI engine when not installed), and systemd
        # garbage-collects it again right after, which signals both. Reacting to them made watch recompute
        # forever. Real changes still arrive: state (PropertiesChanged), start/stop (JobRemoved), add, remove,
        # install (Reloading after daemon-reload), enable/disable (UnitFilesChanged).
        elif member == "JobRemoved":
            if len(body) >= 3 and relevant(str(body[2]), extra):
                q.put("change")
        elif member in ("Reloading", "UnitFilesChanged"):
            q.put("change")


def run(collect, summarize, summary=False, extra=()):
    q = queue.Queue()
    stop = threading.Event()

    def stdin_eof():
        try:
            while sys.stdin.readline():
                pass
        except (OSError, ValueError):
            pass
        stop.set()
        q.put("quit")
    try:
        if stat.S_ISFIFO(os.fstat(0).st_mode):
            threading.Thread(target=stdin_eof, daemon=True).start()
    except OSError:
        pass
    for bus in ("SYSTEM", "SESSION"):
        threading.Thread(target=_listen, args=(bus, set(extra), q, stop), daemon=True).start()

    last = [None]

    def push():
        state = collect()
        out = summarize(state) if summary else state
        key = json.dumps(out, sort_keys=True, default=str)
        if key != last[0]:
            last[0] = key
            emit("summary" if summary else "state", **out)

    push()
    polling = False
    while not stop.is_set():
        try:
            ev = q.get(timeout=POLL if polling else 3600)
        except queue.Empty:
            if polling:
                push()
            continue
        if ev == "quit":
            break
        if ev == "down:SYSTEM":
            polling = True
            continue
        if ev.startswith("down:"):
            continue                                   # the user bus only adds Command Deck
        deadline = time.monotonic() + DEBOUNCE
        while not stop.is_set():
            left = deadline - time.monotonic()
            if left <= 0:
                break
            try:
                if q.get(timeout=left) == "quit":
                    stop.set()
            except queue.Empty:
                break
        if not stop.is_set():
            push()
