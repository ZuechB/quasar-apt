"""systemd: the unit name, each server's drop-in and batched status.

A server runs as quasar-svc@<id>.service (the template is linux/system/services/systemd). Its drop-in
holds what differs per server: Restart=, SocketBindAllow= for exactly its ports (SocketBindDeny=any:
nothing else can be bound, at the OS level) and the optional limits. "Start with the PC" = the
instance is enabled (multi-user.target.wants).
"""
import os
import re
import shutil

from . import paths, proc, store

TEMPLATE = "quasar-svc@.service"
DROPIN = "50-quasar-services.conf"
MEM_RE = re.compile(r"^[1-9][0-9]{0,5}[KMG]\Z")


def unit(sid):
    return "quasar-svc@%s.service" % sid


def folder_unit(sid):
    """svc-prepare's oneshot (root): pins and mounts the owner's folder before the server starts."""
    return "quasar-svc-folder@%s.service" % sid


def both(sid):
    return [folder_unit(sid), unit(sid)]


def render_dropin(defn):
    opts = defn.get("options") or {}
    lines = ["# Written by Quasar Services for %s. Rewritten on every change." % defn["id"],
             "[Service]",
             "Restart=%s" % ("on-failure" if opts.get("crashRestart", True) else "no")]
    for p in defn.get("ports") or []:
        lines.append("SocketBindAllow=%s:%d" % (p["proto"], int(p["port"])))
    lines.append("SocketBindDeny=any")
    mem = str(opts.get("memoryMax") or "").strip()
    if MEM_RE.match(mem):
        lines.append("MemoryMax=%s" % mem)
    cpu = opts.get("cpuWeight")
    if isinstance(cpu, int) and not isinstance(cpu, bool) and 1 <= cpu <= 10000:
        lines.append("CPUWeight=%d" % cpu)
    return "\n".join(lines) + "\n"


def write_dropin(defn):
    """Write the drop-in; True when it changed (then a daemon-reload is due)."""
    d = paths.dropin_dir(defn["id"])
    path = os.path.join(d, DROPIN)
    text = render_dropin(defn)
    try:
        with open(path, encoding="utf-8") as f:
            if f.read() == text:
                return False
    except OSError:
        pass
    os.makedirs(d, mode=0o755, exist_ok=True)
    store.write_text(path, text)
    return True


def remove_dropin(sid):
    shutil.rmtree(paths.dropin_dir(sid), ignore_errors=True)


def daemon_reload():
    proc.systemctl("daemon-reload", check=False)


PROPS = ("Id", "ActiveState", "SubState", "Result", "MemoryCurrent", "ActiveEnterTimestamp", "NRestarts",
         "LoadState", "UnitFileState", "MainPID", "ControlGroup", "TasksCurrent", "ExecMainCode", "ExecMainStatus")
EXIT_CODES = {1: "exited", 2: "killed", 3: "dumped"}       # siginfo's CLD_* (systemd's ExecMainCode)


def exit_of(code, status):
    """How the main program last ended, when that isn't a clean exit: {"code", "status"} or None.
    code: exited (status = its exit code) | killed | dumped (status = the signal's number)."""
    word = EXIT_CODES.get(_int(code) if not isinstance(code, int) else code)
    status = _int(status) if not isinstance(status, int) else status
    if not word or status is None or (word == "exited" and status == 0):
        return None
    return {"code": word, "status": status}


def parse_show(text):
    """`systemctl show` output (blocks separated by blank lines) -> {unit id: {prop: value}}."""
    out, cur = {}, {}
    for line in text.splitlines() + [""]:
        if not line.strip():
            if cur.get("Id"):
                out[cur["Id"]] = cur
            cur = {}
            continue
        k, _, v = line.partition("=")
        cur[k] = v
    return out


def show(names, props=PROPS, user=False):
    if not names:
        return {}
    p = proc.run(["systemctl"] + (["--user"] if user else []) +
                 ["show", "--timestamp=unix", "-p", ",".join(props), "--"] + list(names),
                 check=False, timeout=30, env=proc.base_env(proc._user_bus_env()) if user else None)
    return parse_show(p.stdout or "")


def _int(raw):
    try:
        return int(raw)
    except (TypeError, ValueError):
        return None


def _ts(raw):
    raw = (raw or "").strip()
    if raw.startswith("@"):
        try:
            return int(float(raw[1:]))
        except ValueError:
            return None
    return None


def status_of(info):
    """{status, since, memory, restarts, result, enabled} in the template's words from systemctl show."""
    a, sub, res = info.get("ActiveState"), info.get("SubState"), info.get("Result") or ""
    if a in ("active", "reloading"):
        status = "running"
    elif a == "activating" or sub == "auto-restart":
        status = "starting"
    elif a == "failed":
        status = "failed"
    else:
        status = "stopped"
    mem = _int(info.get("MemoryCurrent"))
    return {"status": status, "since": _ts(info.get("ActiveEnterTimestamp")) if status == "running" else None,
            "memory": mem if status == "running" and mem is not None and mem < 1 << 50 else None,
            "restarts": _int(info.get("NRestarts")) or 0, "result": res,
            "exit": exit_of(info.get("ExecMainCode"), info.get("ExecMainStatus")) if status != "running" else None,
            "enabled": info.get("UnitFileState") in ("enabled", "enabled-runtime", "static", "indirect", "alias")}


def systemctl(verb, sid, timeout=180):
    """start/restart/stop a server. Its folder unit follows (Requires + PartOf)."""
    if verb in ("start", "restart"):
        proc.systemctl("reset-failed", *both(sid), check=False)
    return proc.systemctl(verb, unit(sid), check=False, timeout=timeout)


def journal_tail(sid, lines=40):
    """The last lines of the server and of svc-prepare (its refusals are logged by the folder unit)."""
    cmd = ["journalctl", "--no-pager", "-o", "cat", "-n", str(lines)]
    for name in both(sid):
        cmd += ["-u", name]
    p = proc.run(cmd, check=False, timeout=20)
    return (p.stdout or "").strip()


def cgroup_dir(info):
    cg = (info.get("ControlGroup") or "").strip()
    return "/sys/fs/cgroup" + cg if cg.startswith("/") else ""
