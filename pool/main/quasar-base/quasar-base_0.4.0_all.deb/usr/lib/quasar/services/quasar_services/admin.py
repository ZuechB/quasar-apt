"""/usr/libexec/quasar/quasar-services-admin: the big changes, which ask for the password every time
(polkit org.quasar.services.admin): adding a server, changing its folder, its ports or who can reach
them, and removing it.

  add          stdin SPEC (PROTOCOL.md)                        -> phase lines, result{service, startError}
  update ID    stdin {path?, exec?, kind?, label?, facts?, ports?, public?, args?}
                                                               -> result{service, startError}
  remove ID                                                    -> result{removed}

`args` rides along with `update` when the ports change too, so a closed password prompt can't leave the
arguments naming a port the server isn't allowed to open.

Adding makes the account svc-<id>, writes the definition and the unit's drop-in, opens the ports in the
firewall (one managed entry) and, unless asked not to, turns the server on (start with the PC + start).
A start that fails leaves the server added, so the owner sees why in Services.
"""
import os
import shutil
import time

from . import events, firewall, paths, prepare, proc, reasons, routine, store, units, validate
from . import ports as portmod
from .events import ServicesError, phase, result


def _plain(value, limit):
    return isinstance(value, str) and len(value) <= limit and not any(ord(c) < 32 for c in value)


def _label(value):
    v = (value or "").strip() if isinstance(value, str) else ""
    return v if _plain(v, 40) else ""


def _facts(value):
    if not isinstance(value, list):
        return []
    return [f.strip() for f in value[:6] if isinstance(f, str) and f.strip() and _plain(f.strip(), 30)]


def _taken(sid):
    return os.path.exists(paths.definition(sid)) or proc.account("svc-" + sid) is not None


def _new_id(spec, name):
    if spec.get("id"):
        sid = validate.service_id(spec["id"])
        if _taken(sid):
            raise ServicesError("There's already a server called %s, or an account svc-%s." % (sid, sid), "taken")
        return sid
    base = validate.slug(name)
    for n in range(1, 100):
        sid = base if n == 1 else (base[:23].rstrip("-") + "-%d" % n)
        if validate.ID_RE.match(sid) and not _taken(sid):
            return sid
    raise ServicesError("Pick another name: that one is taken.", "taken")


def _check_ports(defn, running=False):
    defs = store.readable_definitions()
    busy = portmod.listening()
    if running:
        busy -= {(p["proto"], int(p["port"])) for p in defn.get("ports") or []}
    for p in defn.get("ports") or []:
        by = portmod.conflict(p["proto"], int(p["port"]), defn["id"], defs, busy)
        if by:
            raise ServicesError(reasons.message("port-busy", what=by, proto=p["proto"].upper(), port=p["port"]),
                                "port-busy")


def _ensure_account(sid):
    name = "svc-" + sid
    if proc.account(name):
        return False
    proc.run(["useradd", "--system", "--user-group", "--no-create-home", "--home-dir", paths.sys_state_dir(sid),
              "--shell", "/usr/sbin/nologin", "--comment", "Quasar service " + sid, name])
    return True


def _drop(sid, account):
    """Everything a server has outside its owner's folder."""
    proc.systemctl("disable", "--now", units.unit(sid), check=False, timeout=120)
    firewall.remove(sid)
    units.remove_dropin(sid)
    units.daemon_reload()
    prepare.unmount(sid)
    store.remove(sid)
    for d in (paths.state_dir(sid), paths.run_dir(sid), os.path.join(paths.MNT, sid)):
        shutil.rmtree(d, ignore_errors=True)       # fd-based on Linux: never follows the server's symlinks
    if account:
        proc.run(["userdel", "svc-" + sid], check=False)
    proc.systemctl("reset-failed", *units.both(sid), check=False)


def _owner(spec, uid):
    owner = uid if uid is not None else spec.get("owner")
    if isinstance(owner, bool) or not isinstance(owner, int) or owner < 1000:
        raise ServicesError("Unknown owner.", "usage", events.USAGE)
    return owner


def cmd_add(args, uid):
    spec = routine.stdin_json()
    routine.not_live()
    defn = {"v": 1, "id": "", "name": validate.name(spec.get("name")), "owner": _owner(spec, uid),
            "kind": validate.kind(spec.get("kind")), "path": validate.folder(spec.get("path")),
            "exec": validate.exec_path(spec.get("exec")), "args": validate.args(spec.get("args")),
            "env": validate.env(spec.get("env")), "ports": validate.ports(spec.get("ports")),
            "public": validate.public(spec.get("public")), "options": validate.options(spec.get("options")),
            "players": validate.players(spec.get("players")), "label": _label(spec.get("label")),
            "facts": _facts(spec.get("facts")), "created": int(time.time())}
    with store.lock("global"):
        defn["id"] = _new_id(spec, defn["name"])
        prepare.check_only(defn)            # the folder first: nothing else matters if it can't run
        _check_ports(defn)
        phase("Creating its account")
        made = False
        try:
            made = _ensure_account(defn["id"])
            store.save(defn)
            units.write_dropin(defn)
            units.daemon_reload()
            phase("Opening its ports")
            firewall.apply(defn)
        except BaseException:
            _drop(defn["id"], made)
            raise
    start_error = None
    if spec.get("start", True) and defn["options"].get("boot", True):
        phase("Starting it")
        proc.systemctl("enable", units.unit(defn["id"]), check=False)
        try:
            routine.start_unit(defn)
        except ServicesError as e:
            start_error = {"code": e.code, "message": e.message, "details": e.details}
    elif spec.get("start", True):
        phase("Starting it")
        try:
            routine.start_unit(defn)
        except ServicesError as e:
            start_error = {"code": e.code, "message": e.message, "details": e.details}
    result(service=routine.item(defn), startError=start_error)


def cmd_update(args, uid):
    defn = routine.owned(args[0], uid)
    data = routine.stdin_json()
    sid = defn["id"]
    name = units.unit(sid)
    with store.lock("global"):
        moved = False
        if "path" in data:
            new = validate.folder(data["path"])
            moved |= new != defn.get("path")
            defn["path"] = new
        if "exec" in data:
            new = validate.exec_path(data["exec"])
            moved |= new != defn.get("exec")
            defn["exec"] = new
        if "kind" in data:
            new = validate.kind(data["kind"])
            moved |= new != defn.get("kind")
            defn["kind"] = new
        if "label" in data:
            defn["label"] = _label(data["label"])
        if "facts" in data:
            defn["facts"] = _facts(data["facts"])
        if "ports" in data:
            defn["ports"] = validate.ports(data["ports"])
        if "args" in data:
            defn["args"] = validate.args(data["args"])
        if "public" in data:
            defn["public"] = validate.public(data["public"])
        running = units.status_of(units.show([name]).get(name) or {})["status"] == "running"
        _check_ports(defn, running=running)
        if moved:
            prepare.check_only(defn)
        store.save(defn)
        if units.write_dropin(defn):
            units.daemon_reload()
        firewall.apply(defn)
    start_error = None
    if running:
        phase("Restarting it")
        try:
            routine.start_unit(defn, "restart")
        except ServicesError as e:
            start_error = {"code": e.code, "message": e.message, "details": e.details}
    result(service=routine.item(defn), startError=start_error)


def cmd_remove(args, uid):
    defn = routine.owned(args[0], uid)
    with store.lock("global"):
        _drop(defn["id"], account=True)
    result(removed=True)


VERBS = {"add": (cmd_add, 0), "update": (cmd_update, 1), "remove": (cmd_remove, 1)}


def main(argv):
    def go(argv):
        if not argv or argv[0] not in VERBS:
            events.usage("Usage: quasar-services-admin " + "|".join(sorted(VERBS)) + " …")
        for a in argv:
            validate.arg(a)
        fn, nargs = VERBS[argv[0]]
        if len(argv) - 1 < nargs:
            events.usage("%s needs %d argument(s)." % (argv[0], nargs))
        return fn(argv[1:], store.caller_uid())
    return events.run_main(go, argv)
