"""The firewall side of a server: one managed entry per server (PROTOCOL.md, "The firewall").

Ports a server lists as "home" or "internet" are opened to home networks; "internet" ones also to
everyone else (chain wan, with a counter of packets from outside the home network). Root calls
quasar-firewall without PKEXEC_UID, so the entry is marked as managed by Services and the owner isn't
asked for a second password; Settings › Firewall shows it but sends changes here.
"""
import json
import os

from . import paths, proc
from .events import ServicesError


def entry_id(sid):
    return "svc:" + sid


def entry(defn):
    """The managed entry for a server, or None when nothing of it is reachable from other devices."""
    home = {"tcp": set(), "udp": set()}
    wan = {"tcp": set(), "udp": set()}
    for p in defn.get("ports") or []:
        if p.get("reach") in ("home", "internet"):
            home[p["proto"]].add(int(p["port"]))
        if p.get("reach") == "internet":
            wan[p["proto"]].add(int(p["port"]))

    def fmt(ports):
        return ", ".join(str(x) for x in sorted(ports))
    if not home["tcp"] and not home["udp"]:
        return None
    out = {"id": entry_id(defn["id"]), "name": defn.get("name") or defn["id"], "by": "services",
           "tcp": fmt(home["tcp"]), "udp": fmt(home["udp"])}
    if wan["tcp"] or wan["udp"]:
        out["internet"] = {"tcp": fmt(wan["tcp"]), "udp": fmt(wan["udp"])}
    return out


def _helper(args, line=None):
    if not os.access(paths.FIREWALL, os.X_OK):
        return None
    # A fresh environment: never PKEXEC_UID, so the firewall knows Quasar itself is asking.
    return proc.run([paths.FIREWALL] + list(args), input=line, check=False, timeout=60, env=proc.base_env())


def apply(defn):
    """Make the firewall match the server's ports. False when this PC has no firewall helper."""
    e = entry(defn)
    if e is None:
        remove(defn["id"])
        return True
    p = _helper(["allow"], json.dumps(e) + "\n")
    if p is None:
        return False
    if p.returncode != 0:
        raise ServicesError("The firewall didn't take the change, so the ports stay closed.", "firewall",
                            details=((p.stdout or "") + (p.stderr or ""))[-4000:])
    return True


def remove(sid):
    """Close the server's ports. A missing entry is fine."""
    _helper(["unallow", entry_id(sid)])
