"""svc-prepare: what runs as root before and after a server (quasar-svc-folder@<id>.service, a oneshot the
server's unit requires: systemd applies a unit's BindPaths= to its "+" commands too, so the server's own
ExecStartPre=+ couldn't make the folder the unit binds).

"Respect the path" without root ever following a path the owner controls:
- the folder is opened one component at a time from / with O_PATH|O_NOFOLLOW, so a symlink anywhere
  in the path is refused, and every check below looks at the pinned folder, never at a path string;
- the folder must belong to the owner, not be writable by group or others, and sit on ext4, btrfs, xfs
  or f2fs (not FAT/NTFS/network/overlay: no exec bits, no idmapped mounts, or it can vanish);
- the program must be a regular file inside it (no symlinks on the way either), owned by the owner,
  built for this CPU (or a #! script) and not a Windows build. One that lost its execute permission (zips
  made on Windows do that) gets it back here, through the pinned fd: what `chmod +x` would do, which its
  owner may do anyway. That covers adding (check_only), every start and boot;
- the pinned fd (/proc/self/fd/N) is bind-mounted read-only, nosuid, nodev at
  /run/quasar/svc-mnt/<id>/app (parent 0700 root, so services can't see each other's folders); the
  unit binds that at /srv/app. The mount is idmapped (util-linux X-mount.idmap): the owner's files
  appear owned by svc-<id>, so their modes don't matter. Where that isn't supported it falls back to a
  plain bind, which needs files the server's account can read ("not-readable" otherwise).
- the save folder (/var/lib/quasar-svc/<id>, the server's HOME) gets an ACL for the owner, so Files can
  open it; top level only, never recursive (the server's account controls what's inside).
The outcome goes to /run/quasar/svc/<id>/last-start.json, which the helpers turn into the app's message.
"""
import ctypes
import ctypes.util
import os
import re
import stat
import struct
import sys

from . import detect, paths, proc, reasons, store, validate
from .events import ServicesError

FS_OK = {0xEF53: "ext4", 0x9123683E: "btrfs", 0x58465342: "xfs", 0xF2F52010: "f2fs"}
EX_CONFIG = 78
O_PATH = getattr(os, "O_PATH", 0o10000000)
_libc = None


class Refused(Exception):
    def __init__(self, code, **fields):
        super().__init__(code)
        self.code = code
        self.fields = fields


def fs_type(fd):
    """statfs f_type of an open fd (O_PATH fds work too)."""
    global _libc
    if _libc is None:
        _libc = ctypes.CDLL(ctypes.util.find_library("c") or "libc.so.6", use_errno=True)
    buf = ctypes.create_string_buffer(256)
    if _libc.fstatfs(fd, buf) != 0:
        raise OSError(ctypes.get_errno(), "fstatfs")
    return struct.unpack_from("@l", buf, 0)[0] & 0xFFFFFFFF


def _open_component(name, dirfd):
    try:
        fd = os.open(name, O_PATH | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=dirfd)
    except OSError:
        raise Refused("missing-folder")
    st = os.fstat(fd)
    if stat.S_ISLNK(st.st_mode):           # O_PATH|O_NOFOLLOW opens the link itself
        os.close(fd)
        raise Refused("symlink")
    return fd, st


def open_folder(path):
    """The folder as an O_PATH fd, reached without following any symlink."""
    fd = os.open("/", O_PATH | os.O_DIRECTORY | os.O_CLOEXEC)
    try:
        for part in [p for p in path.split("/") if p]:
            if part in (".", ".."):
                raise Refused("missing-folder")
            nfd, st = _open_component(part, fd)
            os.close(fd)
            fd = nfd
            if not stat.S_ISDIR(st.st_mode):
                raise Refused("not-a-folder")
        return fd
    except BaseException:
        os.close(fd)
        raise


def open_program(folder_fd, rel):
    """The program inside the pinned folder, the same way: (O_PATH fd, stat)."""
    parts = rel.split("/")
    fd = os.dup(folder_fd)
    try:
        st = None
        for i, part in enumerate(parts):
            if part in ("", ".", ".."):
                raise Refused("missing-exec")
            nfd, st = _open_component(part, fd)
            os.close(fd)
            fd = nfd
            last = i == len(parts) - 1
            if (not last and not stat.S_ISDIR(st.st_mode)) or (last and not stat.S_ISREG(st.st_mode)):
                raise Refused("missing-exec")
        return fd, st
    except Refused as r:
        os.close(fd)
        if r.code in ("missing-folder", "not-a-folder"):
            raise Refused("missing-exec")
        raise
    except BaseException:
        os.close(fd)
        raise


def read_header(fd, n=64):
    """Read a pinned file through its fd's magic link: the same inode, no path lookup."""
    rfd = os.open("/proc/self/fd/%d" % fd, os.O_RDONLY | os.O_CLOEXEC | os.O_NONBLOCK)
    try:
        return os.read(rfd, n)
    finally:
        os.close(rfd)


def make_executable(pfd, pst, folder_st):
    """Give the owner's program back its execute permission the way `chmod +x` would: execute wherever
    reading is allowed (0644 -> 0755, 0600 -> 0700), set-id bits dropped (root could keep one its owner
    couldn't set). Through the pinned fd: fchmod refuses O_PATH fds, and the magic link reaches the same
    inode without a name lookup. Returns the new stat; Refused("not-executable") when it can't."""
    if pst.st_dev != folder_st.st_dev:           # another filesystem mounted inside the folder: not ours to change
        raise Refused("not-executable")
    mode = (pst.st_mode & 0o777) | ((pst.st_mode & 0o444) >> 2)
    if not mode & 0o100:
        raise Refused("not-executable")
    try:
        os.chmod("/proc/self/fd/%d" % pfd, mode)
        st = os.fstat(pfd)
    except OSError:                               # a read-only drive or snapshot, an immutable file
        raise Refused("not-executable")
    if not st.st_mode & 0o100:
        raise Refused("not-executable")
    return st


def check(defn, fs_types=FS_OK):
    """Pin the folder and check it and the program (and mark the program executable when it lost that).
    Returns (folder fd, program stat as it is now); raises Refused."""
    owner = int(defn["owner"])
    fd = open_folder(defn["path"])
    try:
        st = os.fstat(fd)
        if st.st_uid != owner:
            raise Refused("owner")
        if st.st_mode & 0o022:
            raise Refused("writable")
        if fs_types is not None:
            try:
                ft = fs_type(fd)
            except OSError:
                ft = None
            if ft is not None and ft not in fs_types:
                raise Refused("fs")
        pfd, pst = open_program(fd, defn["exec"])
        try:
            if pst.st_uid != owner:
                raise Refused("owner")
            if defn.get("kind") in ("unity", "program"):
                # What it is first: a Windows build gets its own words, and is never marked executable.
                kind = detect.binary_kind(read_header(pfd))
                if kind == "pe":
                    raise Refused("windows-build" if defn.get("kind") == "unity" else "windows-program")
                machine = detect.this_machine()
                if kind.startswith("elf:") and kind[4:] != machine:
                    raise Refused("arch", arch=kind[4:], machine=machine)
                if not pst.st_mode & 0o100:
                    if kind not in ("elf:" + machine, "script"):
                        raise Refused("not-a-program")
                    pst = make_executable(pfd, pst, st)
                    print("svc-prepare: marked %s as a program (it had lost its execute permission)" % defn["exec"],
                          file=sys.stderr)
        finally:
            os.close(pfd)
        return fd, pst
    except BaseException:
        os.close(fd)
        raise


def check_only(defn, fs_types=FS_OK):
    """For add/update: the same checks as a start, as a ServicesError with the plain-words message."""
    try:
        fd, _ = check(defn, fs_types)
        os.close(fd)
    except Refused as r:
        fields = {"path": defn.get("path", ""), "exec": defn.get("exec", ""), "name": defn.get("name", "")}
        fields.update(r.fields)
        raise ServicesError(reasons.message(r.code, **fields), r.code)


def _unescape(s):
    return re.sub(r"\\([0-7]{3})", lambda m: chr(int(m.group(1), 8)), s)


def mounted(target):
    try:
        with open(paths.MOUNTINFO, encoding="utf-8", errors="replace") as f:
            for line in f:
                parts = line.split()
                if len(parts) > 4 and _unescape(parts[4]) == target:
                    return True
    except OSError:
        pass
    return False


def unmount(sid):
    target = paths.mount_dir(sid)
    for _ in range(4):
        if not mounted(target):
            return
        proc.run(["umount", "-l", target], check=False, timeout=30)


def _ids(defn):
    import pwd
    acct = proc.account("svc-" + defn["id"])
    if not acct:
        raise ServicesError("The server's account is missing. Remove the server and add it again.", "no-account")
    pw = pwd.getpwuid(int(defn["owner"]))
    return acct[0], acct[1], pw.pw_uid, pw.pw_gid


def mount(defn, fd):
    """Mount the pinned folder for the unit. Returns "idmapped" or "bind"."""
    sid = defn["id"]
    os.makedirs(paths.MNT, mode=0o700, exist_ok=True)
    os.chmod(paths.MNT, 0o700)
    os.makedirs(os.path.join(paths.MNT, sid), mode=0o700, exist_ok=True)
    target = paths.mount_dir(sid)
    os.makedirs(target, mode=0o755, exist_ok=True)
    unmount(sid)
    svc_uid, svc_gid, own_uid, own_gid = _ids(defn)
    src = "/proc/self/fd/%d" % fd
    # The owner's files (on disk) must appear as the server's account's (in the mount). Verified on
    # util-linux 2.41.5 / kernel 7.3: "u:A:B:1" shows files owned by A on disk as B in the mount (the kernel
    # looks the disk id up on the namespace side of the map util-linux writes), the reverse of how
    # mount(8)'s "id-mount:id-host" reads. The other order showed them as nobody (65534).
    idmap = "X-mount.idmap=u:%d:%d:1 g:%d:%d:1" % (own_uid, svc_uid, own_gid, svc_gid)
    r = proc.run(["mount", "--bind", "-o", "ro,nosuid,nodev," + idmap, src, target], check=False, timeout=30,
                 pass_fds=(fd,))
    if r.returncode == 0 and mounted(target):
        try:
            seen = os.stat(target).st_uid
        except OSError:
            seen = None
        if seen == svc_uid:
            return "idmapped"
        print("svc-prepare: the idmapped mount shows uid %s, not %d: using a plain bind" % (seen, svc_uid),
              file=sys.stderr)
        unmount(sid)
    else:
        print("svc-prepare: no idmapped mount (%s), using a plain bind" % (r.stderr or "").strip(), file=sys.stderr)
    r = proc.run(["mount", "--bind", src, target], check=False, timeout=30, pass_fds=(fd,))
    if r.returncode != 0:
        raise ServicesError("Couldn't make the folder available to the server.", "mount", details=r.stderr or "")
    r = proc.run(["mount", "-o", "remount,bind,ro,nosuid,nodev", target], check=False, timeout=30)
    if r.returncode != 0:
        unmount(sid)
        raise ServicesError("Couldn't make the folder read-only for the server.", "mount", details=r.stderr or "")
    return "bind"


def readable_plain(st_folder, st_prog, kind):
    """With a plain bind the server's account is "others": it needs r-x on the folder, r(-x) on the program."""
    if (st_folder.st_mode & 0o005) != 0o005:
        return False
    need = 0o005 if kind in ("unity", "program") else 0o004
    return (st_prog.st_mode & need) == need


def share_state_dir(defn):
    """The save folder (StateDirectory=), made here on the first start because this runs before the
    server's unit (systemd would make it then), plus the owner's ACL so Files can open it."""
    d = paths.state_dir(defn["id"])
    if os.path.islink(d):
        return
    svc_uid, svc_gid, own_uid, _ = _ids(defn)
    if not os.path.isdir(d):
        os.makedirs(paths.STATE_DIRS, mode=0o755, exist_ok=True)
        os.mkdir(d, 0o750)
        os.chown(d, svc_uid, svc_gid)
    if proc.have("setfacl"):
        proc.run(["setfacl", "-m", "u:%d:rwx,d:u:%d:rwx,d:u:%d:rwx" % (own_uid, own_uid, svc_uid), d],
                 check=False, timeout=20)


def main(argv):
    release = "--release" in argv
    args = [a for a in argv if a != "--release"]
    if len(args) != 1 or not validate.ID_RE.match(args[0]):
        print("usage: svc-prepare [--release] ID", file=sys.stderr)
        return 2
    sid = args[0]
    if release:
        unmount(sid)
        return 0
    defn = store.read_json(paths.definition(sid)) or {}
    fields = {"path": defn.get("path", ""), "exec": defn.get("exec", ""), "name": defn.get("name", sid)}
    try:
        if not defn.get("path"):
            raise Refused("missing-folder")
        if paths.live():
            raise Refused("live")
        fd, pst = check(defn)
        try:
            how = mount(defn, fd)
            if how == "bind" and not readable_plain(os.fstat(fd), pst, defn.get("kind")):
                unmount(sid)
                raise Refused("not-readable")
        finally:
            os.close(fd)
        share_state_dir(defn)
        store.write_last_start(sid, True, "ok", "Ready (%s folder)." % how)
        print("svc-prepare: %s runs from %s (%s mount)" % (sid, defn["path"], how), file=sys.stderr)
        return 0
    except Refused as r:
        fields.update(r.fields)
        msg = reasons.message(r.code, **fields)
        store.write_last_start(sid, False, r.code, msg)
        print("svc-prepare: " + msg, file=sys.stderr)
        return EX_CONFIG
    except ServicesError as e:
        store.write_last_start(sid, False, e.code, e.message)
        print("svc-prepare: %s %s" % (e.message, e.details), file=sys.stderr)
        return 1
