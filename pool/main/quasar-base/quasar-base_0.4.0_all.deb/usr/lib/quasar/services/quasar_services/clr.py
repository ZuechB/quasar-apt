"""The flag-like literals a .NET assembly's code uses, read straight from the file: what a Unity game's own
scripts compare their command line against (`-port`, `-maxplayers`, `-name`…). Nothing is loaded or run.

Literals a method loads (`ldstr`) live in the assembly's #US heap (ECMA-335 II.24): DOS header → e_lfanew →
"PE\\0\\0" → COFF → optional header → data directory 14 (the CLI header) → COR20 → metadata root "BSJB" →
stream headers → "#US", a run of blobs: a compressed length, UTF-16LE text, one trailing byte.

Stdlib only. Every offset is bounded by the file, and the walk is capped. A damaged or hostile file gives
what was read before the damage (usually nothing): flag_strings() never raises.
"""
import os
import stat
import struct

MAX_FILE = 64 << 20          # a game's Assembly-CSharp.dll is a few MB
MAX_HEAP = 4 << 20           # Animal Go's #US heap is 69 KB
MAX_ENTRIES = 200000
MAX_SECTIONS = 96
MAX_STREAMS = 16
CLI_DIRECTORY = 14
MIN_CHARS, MAX_CHARS = 3, 33   # "-ip" … a dash and 32 more: longer literals aren't flags


class _Bad(Exception):
    pass


def _open(path):
    """(fd, size) of a regular file, or (None, 0). O_NONBLOCK: a FIFO named like an assembly can't hang the
    open; O_NOFOLLOW: a link isn't followed. The type is checked on the open fd."""
    flags = os.O_RDONLY | getattr(os, "O_NONBLOCK", 0) | getattr(os, "O_NOFOLLOW", 0) \
        | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_BINARY", 0)
    try:
        fd = os.open(path, flags)
    except OSError:
        return None, 0
    try:
        st = os.fstat(fd)
    except OSError:
        os.close(fd)
        return None, 0
    if not stat.S_ISREG(st.st_mode) or not 128 <= st.st_size <= MAX_FILE:
        os.close(fd)
        return None, 0
    return fd, st.st_size


def _read(fd, offset, size):
    if offset < 0 or size < 0:
        raise _Bad("negative")
    chunks, got = [], 0
    while got < size:
        if hasattr(os, "pread"):
            data = os.pread(fd, size - got, offset + got)
        else:
            os.lseek(fd, offset + got, os.SEEK_SET)
            data = os.read(fd, size - got)
        if not data:
            raise _Bad("short read")
        chunks.append(data)
        got += len(data)
    return b"".join(chunks)


def _sections(fd, size):
    """(CLI header RVA, [(virtual address, raw size, raw pointer)])."""
    dos = _read(fd, 0, 64)
    if dos[:2] != b"MZ":
        raise _Bad("no MZ")
    (lfanew,) = struct.unpack_from("<I", dos, 0x3C)
    if not 0x40 <= lfanew <= 0x10000 or lfanew + 24 > size:
        raise _Bad("e_lfanew")
    head = _read(fd, lfanew, 24)
    if head[:4] != b"PE\0\0":
        raise _Bad("no PE")
    (nsect,) = struct.unpack_from("<H", head, 6)
    (optsize,) = struct.unpack_from("<H", head, 20)
    if not 1 <= nsect <= MAX_SECTIONS:
        raise _Bad("sections")
    opt = _read(fd, lfanew + 24, optsize)
    (magic,) = struct.unpack_from("<H", opt, 0)
    if magic == 0x10B:                 # PE32
        count_at, dirs_at = 92, 96
    elif magic == 0x20B:               # PE32+
        count_at, dirs_at = 108, 112
    else:
        raise _Bad("optional header")
    if optsize < dirs_at + (CLI_DIRECTORY + 1) * 8:
        raise _Bad("directories")
    (ndirs,) = struct.unpack_from("<I", opt, count_at)
    if ndirs <= CLI_DIRECTORY:
        raise _Bad("no CLI directory")
    cli_rva, cli_size = struct.unpack_from("<II", opt, dirs_at + CLI_DIRECTORY * 8)
    if not cli_rva or cli_size < 16:
        raise _Bad("not .NET")
    table = _read(fd, lfanew + 24 + optsize, nsect * 40)
    sections = []
    for i in range(nsect):
        _vsize, va, rawsize, rawptr = struct.unpack_from("<IIII", table, i * 40 + 8)
        sections.append((va, rawsize, rawptr))
    return cli_rva, sections


def _offset(sections, rva, length, size):
    """The file offset of [rva, rva+length), which must lie in one section's bytes on disk."""
    for va, rawsize, rawptr in sections:
        if va <= rva and rva + length <= va + rawsize:
            off = rawptr + (rva - va)
            if off + length <= size:
                return off
    raise _Bad("rva %#x" % rva)


def _us_heap(fd, size):
    cli_rva, sections = _sections(fd, size)
    cor = _read(fd, _offset(sections, cli_rva, 16, size), 16)
    md_rva, md_size = struct.unpack_from("<II", cor, 8)
    if md_size < 32:
        raise _Bad("metadata")
    md_off = _offset(sections, md_rva, md_size, size)
    root = _read(fd, md_off, min(md_size, 4096))       # the root and its stream headers come first
    if root[:4] != b"BSJB":
        raise _Bad("no BSJB")
    (vlen,) = struct.unpack_from("<I", root, 12)
    if vlen > 255:
        raise _Bad("version")
    pos = 16 + ((vlen + 3) & ~3)
    (nstreams,) = struct.unpack_from("<H", root, pos + 2)
    pos += 4
    if nstreams > MAX_STREAMS:
        raise _Bad("streams")
    for _ in range(nstreams):
        off, ssize = struct.unpack_from("<II", root, pos)
        pos += 8
        end = root.find(b"\0", pos, pos + 32)
        if end < 0:
            raise _Bad("stream name")
        name = root[pos:end]
        pos = (end + 1 + 3) & ~3                       # names are padded to 4 bytes
        if name == b"#US":
            if off + ssize > md_size:
                raise _Bad("#US outside the metadata")
            return _read(fd, md_off + off, min(ssize, MAX_HEAP))
    return b""


def _flag_entries(heap):
    """Entries of the #US heap that start with "-" and are 3–33 plain (8-bit) characters."""
    pos, n, size = 0, 0, len(heap)
    while pos < size and n < MAX_ENTRIES:
        b0 = heap[pos]
        if b0 & 0x80 == 0:
            length, pos = b0, pos + 1
        elif b0 & 0xC0 == 0x80:
            if pos + 2 > size:
                return
            length, pos = ((b0 & 0x3F) << 8) | heap[pos + 1], pos + 2
        elif b0 & 0xE0 == 0xC0:
            if pos + 4 > size:
                return
            length = ((b0 & 0x1F) << 24) | (heap[pos + 1] << 16) | (heap[pos + 2] << 8) | heap[pos + 3]
            pos += 4
        else:
            return
        if length == 0:                                # the empty first entry, and padding
            continue
        n += 1
        if pos + length > size:
            return
        chars = (length - 1) // 2
        if MIN_CHARS <= chars <= MAX_CHARS and heap[pos] == 0x2D and heap[pos + 1] == 0:
            text = heap[pos:pos + 2 * chars]
            if not any(text[1::2]):
                yield text[0::2].decode("latin-1")
        pos += length


def flag_strings(path):
    """The literals in the assembly at `path` that look like command-line flags, in heap order (roughly the
    order of the source). [] for anything that isn't a readable .NET assembly."""
    fd, size = _open(path)
    if fd is None:
        return []
    found = []
    try:
        for text in _flag_entries(_us_heap(fd, size)):
            found.append(text)
    except (_Bad, OSError, struct.error, ValueError, IndexError, OverflowError):
        pass
    finally:
        os.close(fd)
    return found
