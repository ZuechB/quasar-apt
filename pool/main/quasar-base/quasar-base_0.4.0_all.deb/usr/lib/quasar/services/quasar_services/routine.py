"""/usr/libexec/quasar/quasar-services: routine changes to your own servers.

Polkit action org.quasar.services: administrators at the PC aren't asked for a password
(53-quasar-services.rules); elsewhere (over SSH, other accounts) an administrator's password, kept for
a few minutes. Everything here only touches servers the caller owns. Adding a server, removing it and
anything that changes what other devices can reach are quasar-services-admin's: it asks every time.

  start|stop|restart ID
  enable ID          start with the PC, and start now
  disable ID         stop, and don't start with the PC
  set ID             stdin {name?, exec?, args?, env?, options?, players?}  -> result{service}
"""
import json
import os
import sys
import time

from . import events, paths, proc, reasons, store, units, validate
from . import ports as portmod
from .events import ServicesError, result


def stdin_json():
    line = sys.stdin.readline()
    if not line.strip():
        return {}
    try:
        data = json.loads(line)
    except ValueError:
        raise ServicesError("Bad request.", "usage", events.USAGE)
    if not isinstance(data, dict):
        raise ServicesError("Bad request.", "usage", events.USAGE)
    return data


def owned(sid, uid):
    defn = store.load(validate.service_id(sid))
    store.check_owner(defn, uid)
    return defn


def not_live():
    if paths.live():
        raise ServicesError(reasons.message("live"), "live", events.UNAVAILABLE)


def item(defn):
    from . import query
    name = units.unit(defn["id"])
    return query.server_item(defn, units.show([name]), portmod.listening(), store.last_start(defn["id"]))


def start_unit(defn, verb="start"):
    """Start (or restart) a server and make sure it stays up for its first seconds."""
    sid = defn["id"]
    name = units.unit(sid)
    try:
        os.unlink(paths.last_start(sid))
    except OSError:
        pass
    if units.write_dropin(defn):
        units.daemon_reload()
    r = units.systemctl(verb, sid)
    if r.returncode != 0:
        last = store.last_start(sid)
        if last and not last.get("ok") and last.get("code"):
            raise ServicesError(last.get("message") or reasons.message(last["code"]), last["code"],
                                details=units.journal_tail(sid, 20))
        raise ServicesError(reasons.message("start-failed", name=defn.get("name") or sid), "start-failed",
                            details=units.journal_tail(sid, 40))
    # Type=exec: systemctl returns once the program runs. One that stops at once (a busy port, a missing
    # library) shows within a few seconds.
    # Any auto-restart counts: NRestarts only goes up when the restart actually runs (after RestartSec), so
    # a server that dies at once can sit in auto-restart with the counter still 0 (seen on systemd 257).
    deadline = time.time() + 4
    while time.time() < deadline:
        time.sleep(0.5)
        info = units.show([name]).get(name) or {}
        st = units.status_of(info)
        if st["status"] in ("failed", "stopped") or (info.get("SubState") or "").startswith("auto-restart"):
            raise ServicesError(reasons.message("start-failed", name=defn.get("name") or sid), "start-failed",
                                details=units.journal_tail(sid, 40))
    return "running"


def forget_last_start(sid):
    try:
        os.unlink(paths.last_start(sid))
    except OSError:
        pass


def cmd_start(args, uid):
    not_live()
    defn = owned(args[0], uid)
    with store.lock("svc-" + defn["id"], wait=False):
        start_unit(defn, "start")
    result(status="running")


def cmd_restart(args, uid):
    not_live()
    defn = owned(args[0], uid)
    with store.lock("svc-" + defn["id"], wait=False):
        start_unit(defn, "restart")
    result(status="running")


def cmd_stop(args, uid):
    defn = owned(args[0], uid)
    with store.lock("svc-" + defn["id"], wait=False):
        r = units.systemctl("stop", defn["id"], timeout=120)
        if r.returncode != 0:
            raise ServicesError("%s didn't stop." % defn.get("name"), "stop-failed", details=r.stderr or "")
        forget_last_start(defn["id"])       # stopped on purpose: no longer "needs attention"
    result(status="stopped")


def cmd_enable(args, uid):
    not_live()
    defn = owned(args[0], uid)
    name = units.unit(defn["id"])
    with store.lock("svc-" + defn["id"], wait=False):
        proc.systemctl("enable", name, check=False)
        defn.setdefault("options", {})["boot"] = True
        store.save(defn)
        if units.status_of(units.show([name]).get(name) or {})["status"] != "running":
            start_unit(defn, "start")
    result(status="running", enabled=True)


def cmd_disable(args, uid):
    defn = owned(args[0], uid)
    name = units.unit(defn["id"])
    with store.lock("svc-" + defn["id"], wait=False):
        proc.systemctl("disable", "--now", name, check=False, timeout=120)
        forget_last_start(defn["id"])
        defn.setdefault("options", {})["boot"] = False
        store.save(defn)
    result(status="stopped", enabled=False)


def cmd_set(args, uid):
    defn = owned(args[0], uid)
    data = stdin_json()
    with store.lock("svc-" + defn["id"], wait=False):
        if "name" in data:
            defn["name"] = validate.name(data["name"])
        if "exec" in data:
            defn["exec"] = validate.exec_path(data["exec"])
        if "args" in data:
            defn["args"] = validate.args(data["args"])
        if "env" in data:
            defn["env"] = validate.env(data["env"])
        if "options" in data:
            opts = dict(data["options"] or {})
            opts.pop("boot", None)              # start-with-the-PC is enable/disable
            defn["options"] = validate.options(opts, defn.get("options"))
        if "players" in data:
            defn["players"] = validate.players(data["players"])
        store.save(defn)
        if units.write_dropin(defn):
            units.daemon_reload()
    result(service=item(defn))


VERBS = {"start": (cmd_start, 1), "stop": (cmd_stop, 1), "restart": (cmd_restart, 1), "enable": (cmd_enable, 1),
         "disable": (cmd_disable, 1), "set": (cmd_set, 1)}


def main(argv):
    def go(argv):
        if not argv or argv[0] not in VERBS:
            events.usage("Usage: quasar-services " + "|".join(sorted(VERBS)) + " ID")
        for a in argv:
            validate.arg(a)
        fn, nargs = VERBS[argv[0]]
        if len(argv) - 1 < nargs:
            events.usage("%s needs %d argument(s)." % (argv[0], nargs))
        return fn(argv[1:], store.caller_uid())
    return events.run_main(go, argv)
