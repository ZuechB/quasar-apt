"""services-query units [-f]: every service on this PC (the Services app's "Every service on this PC").

Both service managers, the system's and this account's, through D-Bus (jeepney); no programs started.
The list comes once (ListUnitsByPatterns + ListUnitFilesByPatterns), then a unit is read again only when
systemd says it changed (PropertiesChanged). It lists again, at most once a second, after a daemon-reload,
an enable/disable, or a finished job for a unit it didn't know (a service started for the first time).
UnitNew/UnitRemoved don't count: reading a unit that isn't loaded loads it and garbage-collects it again,
which signals both (watch.py had that loop).

  {"type":"units","rows":[ROW…],"full":true}        first (and the only line without -f)
  {"type":"units","rows":[ROW…],"gone":[KEY…]}      what changed since the last line
ROW: {"key":"service:ssh.service" | "userservice:pipewire.service", "unit":"ssh.service", "user":false,
      "name":"OpenBSD Secure Shell server", "status":"running|starting|stopping|stopped|failed",
      "sub":"running", "enabled":true|false|null,
      "result":"exit-code", "exit":{"code":"exited","status":1}, "restarts":3}   (failed ones only)
Left out: units that aren't found or are masked, templates, unit files nobody enables (static, alias,
generated…) unless loaded, and the helper units the app never shows on their own: svc-prepare's
quasar-svc-folder@, Sites' deploy and build runs.
"""
import queue
import re
import threading
import time

from . import lifecycle, units
from .events import ServicesError, emit

PATTERNS = ["*.service"]
HIDDEN = re.compile(r"quasar-svc-folder@|quasar-site-deploy@|quasar-site-build@")
FILE_STATES_SHOWN = {"enabled", "enabled-runtime", "linked", "linked-runtime", "disabled"}
ENABLED = {"enabled", "enabled-runtime", "linked", "linked-runtime", "indirect"}
RELIST_AFTER = 1.0           # seconds: a re-list waits this long for more of the same burst
REFRESH_AFTER = 0.2          # seconds: changed units are read again in one go
SYSTEMD = "org.freedesktop.systemd1"
UNIT_IFACE = "org.freedesktop.systemd1.Unit"
SERVICE_IFACE = "org.freedesktop.systemd1.Service"
MANAGER_PATH = "/org/freedesktop/systemd1"
UNIT_PATHS = "/org/freedesktop/systemd1/unit"


# ---- rows (pure) ----------------------------------------------------------------------------------
def status_of(active, sub):
    if active in ("active", "reloading", "refreshing"):
        return "running"
    if active == "activating" or sub == "auto-restart":
        return "starting"
    if active == "deactivating":
        return "stopping"
    if active == "failed":
        return "failed"
    return "stopped"


def key_of(name, user):
    return ("userservice:" if user else "service:") + name


def shown(name):
    return name.endswith(".service") and "@." not in name and not HIDDEN.match(name)


def row_of(name, desc, active, sub, user, file_state=None, failed=None):
    st = status_of(active, sub)
    row = {"key": key_of(name, user), "unit": name, "user": bool(user),
           "name": desc if desc and desc != name else name[:-len(".service")],
           "status": st, "sub": sub or "", "enabled": True if file_state in ENABLED else
           False if file_state == "disabled" else None}
    if st == "failed" and failed:
        row.update(failed)
    return row


def failed_details(props):
    """{"result", "exit", "restarts"} from a Service's GetAll ({name: value})."""
    out = {"result": str(props.get("Result") or "")}
    ex = units.exit_of(props.get("ExecMainCode"), props.get("ExecMainStatus"))
    if ex:
        out["exit"] = ex
    restarts = props.get("NRestarts")
    if isinstance(restarts, int) and restarts > 0:
        out["restarts"] = restarts
    return out


def build_rows(loaded, files, user, failed=None):
    """loaded: [(name, description, load_state, active_state, sub_state)]; files: {name: file state};
    failed: {name: failed_details} -> {key: row}."""
    failed = failed or {}
    rows = {}
    for name, desc, load, active, sub in loaded:
        if not shown(name) or load in ("not-found", "masked"):
            continue
        rows[key_of(name, user)] = row_of(name, desc, active, sub, user, files.get(name), failed.get(name))
    for name, state in files.items():
        key = key_of(name, user)
        if key in rows or not shown(name) or state not in FILE_STATES_SHOWN:
            continue
        rows[key] = row_of(name, "", "inactive", "dead", user, state)
    return rows


def diff(old, new):
    """(rows that are new or changed, keys that are gone)."""
    return [r for k, r in new.items() if old.get(k) != r], [k for k in old if k not in new]


def ordered(rows):
    rank = {"failed": 0, "starting": 1, "stopping": 1, "running": 2, "stopped": 3}
    return sorted(rows, key=lambda r: (rank.get(r["status"], 3), r["name"].lower(), r["key"]))


def unescape(part):
    """The last part of a unit's object path ("ssh_2eservice") back to its name."""
    return re.sub(r"_([0-9a-fA-F]{2})", lambda m: chr(int(m.group(1), 16)), part)


# ---- one service manager over D-Bus -----------------------------------------------------------------
class Manager:
    """The system's (user=False) or this account's (user=True) service manager: two connections, one for
    calls and one for signals, so no signal is lost while a call waits for its reply."""

    def __init__(self, user):
        from jeepney import DBusAddress
        from jeepney.io.blocking import open_dbus_connection
        self.user = user
        bus = "SESSION" if user else "SYSTEM"
        self.calls = open_dbus_connection(bus=bus)
        self.signals = None
        self._open_signals = lambda: open_dbus_connection(bus=bus)
        self.mgr = DBusAddress(MANAGER_PATH, bus_name=SYSTEMD, interface="org.freedesktop.systemd1.Manager")
        self.paths = {}                              # unit name -> object path (loaded units)
        self.files = {}                              # unit file name -> its state (the last list)

    def call(self, addr, method, sig="", body=(), timeout=10):
        from jeepney import new_method_call
        from jeepney.wrappers import unwrap_msg
        return unwrap_msg(self.calls.send_and_get_reply(new_method_call(addr, method, sig, body), timeout=timeout))

    def get_all(self, path, iface):
        from jeepney import DBusAddress
        props = self.call(DBusAddress(path, bus_name=SYSTEMD, interface="org.freedesktop.DBus.Properties"),
                          "GetAll", "s", (iface,))[0]
        return {k: v[1] for k, v in props.items()}

    def failed_of(self, name):
        path = self.paths.get(name)
        if not path:
            return None
        try:
            return failed_details(self.get_all(path, SERVICE_IFACE))
        except Exception:                          # noqa: BLE001 (gone meanwhile)
            return None

    def snapshot(self):
        """Every service this manager has or could start -> {key: row}."""
        loaded = []
        self.paths = {}
        for name, desc, load, active, sub, _follow, path, *_rest in self.call(
                self.mgr, "ListUnitsByPatterns", "asas", ([], PATTERNS), timeout=20)[0]:
            loaded.append((name, desc, load, active, sub))
            self.paths[name] = path
        files = {}
        try:
            for path, state in self.call(self.mgr, "ListUnitFilesByPatterns", "asas", ([], PATTERNS), timeout=20)[0]:
                files[path.rsplit("/", 1)[-1]] = state
        except Exception:                          # noqa: BLE001 (an older systemd: loaded units only)
            pass
        failed = {n: self.failed_of(n) for n, _d, load, active, _s in loaded if active == "failed" and shown(n)}
        self.files = files
        return build_rows(loaded, files, self.user, failed)

    def read(self, name):
        """One unit again -> its row, or None when it isn't loaded and no unit file shows it."""
        from jeepney import DBusAddress
        try:
            path = self.paths.get(name) or self.call(self.mgr, "GetUnit", "s", (name,))[0]
            p = self.get_all(path, UNIT_IFACE)
        except Exception:                          # noqa: BLE001 (not loaded)
            self.paths.pop(name, None)
            state = self.files.get(name)
            return row_of(name, "", "inactive", "dead", self.user, state) if state in FILE_STATES_SHOWN else None
        self.paths[name] = path
        if p.get("LoadState") in ("not-found", "masked"):
            return None
        active = p.get("ActiveState")
        failed = None
        if active == "failed":
            try:
                failed = failed_details(self.get_all(path, SERVICE_IFACE))
            except Exception:                      # noqa: BLE001
                failed = None
        return row_of(name, p.get("Description"), active, p.get("SubState"), self.user,
                      p.get("UnitFileState") or self.files.get(name), failed)

    def listen(self, q, stop):
        """Signals -> q: ("unit", user, name) for a changed unit, ("job", user, name), ("relist", user)."""
        from jeepney import HeaderFields, MatchRule, MessageType, new_method_call
        from jeepney.bus_messages import message_bus
        try:
            conn = self._open_signals()
            conn.send_and_get_reply(new_method_call(self.mgr, "Subscribe"), timeout=10)
            for rule in (MatchRule(type="signal", interface="org.freedesktop.DBus.Properties",
                                   member="PropertiesChanged", path_namespace=UNIT_PATHS),
                         MatchRule(type="signal", interface="org.freedesktop.systemd1.Manager", path=MANAGER_PATH)):
                conn.send_and_get_reply(message_bus.AddMatch(rule), timeout=10)
        except Exception:                          # noqa: BLE001
            q.put(("down", self.user, ""))
            return
        while not stop.is_set():
            try:
                msg = conn.receive(timeout=1.0)
            except TimeoutError:
                continue
            except Exception:                      # noqa: BLE001 (the bus went away)
                q.put(("down", self.user, ""))
                return
            if msg.header.message_type != MessageType.signal:
                continue
            member = msg.header.fields.get(HeaderFields.member)
            body = msg.body or ()
            if member == "PropertiesChanged":
                name = unescape(str(msg.header.fields.get(HeaderFields.path) or "").rsplit("/", 1)[-1])
                if body and body[0] == UNIT_IFACE and shown(name):
                    q.put(("unit", self.user, name))
            elif member == "JobRemoved":
                if len(body) >= 3 and shown(str(body[2])):
                    q.put(("job", self.user, str(body[2])))
            elif member == "UnitFilesChanged" or (member == "Reloading" and body and not body[0]):
                q.put(("relist", self.user, ""))


# ---- the stream -----------------------------------------------------------------------------------
def cmd_units(args):
    follow = "-f" in args
    stopper = lifecycle.Stopper().install()
    managers = []
    try:
        managers.append(Manager(False))
    except Exception as e:                         # noqa: BLE001 (no jeepney, no system bus)
        raise ServicesError("Services couldn't list this PC's services.", "no-dbus", details=str(e))
    try:
        managers.append(Manager(True))
    except Exception:                              # noqa: BLE001 (no session bus: system services only)
        pass
    rows = {}
    for m in managers:
        rows.update(m.snapshot())
    emit("units", rows=ordered(rows.values()), full=True)
    if not follow:
        return 0
    by_user = {m.user: m for m in managers}
    q = queue.Queue()
    for m in managers:
        threading.Thread(target=m.listen, args=(q, stopper.event), daemon=True).start()
    stopper.watch_stdin()
    dirty, relist = {}, {}                         # (user, name) -> first seen; user -> due
    while not stopper.event.is_set():
        try:
            ev = q.get(timeout=0.25)
        except queue.Empty:
            ev = None
        while ev is not None:                      # the whole burst, then whatever is due
            kind, user, name = ev
            now = time.monotonic()
            if kind == "unit":
                dirty.setdefault((user, name), now)
            elif kind == "job":
                if key_of(name, user) in rows:
                    dirty.setdefault((user, name), now)
                else:
                    relist.setdefault(user, now + RELIST_AFTER)
            elif kind == "relist":
                relist.setdefault(user, now + RELIST_AFTER)
            elif kind == "down" and not user:
                raise ServicesError("Services lost its connection to systemd.", "no-dbus")
            try:
                ev = q.get_nowait()
            except queue.Empty:
                ev = None
        now = time.monotonic()
        new = dict(rows)
        for user, due in list(relist.items()):
            if now >= due and user in by_user:
                del relist[user]
                fresh = by_user[user].snapshot()
                for k in [k for k, r in new.items() if r["user"] == user]:
                    del new[k]
                new.update(fresh)
                for d in [d for d in dirty if d[0] == user]:
                    del dirty[d]
        for (user, name), first in list(dirty.items()):
            if now - first >= REFRESH_AFTER and user in by_user:
                del dirty[(user, name)]
                row = by_user[user].read(name)
                if row:
                    new[row["key"]] = row
                else:
                    new.pop(key_of(name, user), None)
        changed, gone = diff(rows, new)
        if changed or gone:
            rows = new
            emit("units", rows=ordered(changed), gone=gone)
    return 0
