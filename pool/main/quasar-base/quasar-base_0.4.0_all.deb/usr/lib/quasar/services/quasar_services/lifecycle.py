"""How a long-running services-query stream (journal -f, units -f) ends, and takes its programs with it.

Quickshell stops a Process with SIGTERM when it's told to stop running, and SIGKILLs it when the object
goes away (a closed console window). So a stream ends:
  - on SIGTERM or SIGINT (the Stopper's event is set; the stream's loop notices within one tick);
  - when its stdin pipe closes (the app runs these with stdinEnabled; only when stdin is a pipe);
  - when its parent dies (PR_SET_PDEATHSIG on itself);
and every program it starts dies with it (PR_SET_PDEATHSIG through child_setup), so a SIGKILLed stream
never leaves a `journalctl -f` behind.
"""
import ctypes
import os
import signal
import stat
import threading

PR_SET_PDEATHSIG = 1


def _pdeathsig(sig):
    try:
        libc = ctypes.CDLL(None, use_errno=True)
        libc.prctl(PR_SET_PDEATHSIG, int(sig), 0, 0, 0)
    except (OSError, AttributeError, TypeError):
        pass


def child_setup():
    """preexec_fn for a program a stream starts: it gets SIGTERM when the stream dies."""
    _pdeathsig(signal.SIGTERM)


class Stopper:
    """stop.event is set when the stream should end. install() first (before starting programs: no
    threads exist yet when they fork), then watch_stdin() once they run."""

    def __init__(self):
        self.event = threading.Event()

    def install(self):
        _pdeathsig(signal.SIGTERM)
        for sig in (signal.SIGTERM, signal.SIGINT):
            try:
                signal.signal(sig, self._on_signal)
            except (ValueError, OSError):        # not the main thread (tests)
                pass
        return self

    def _on_signal(self, signum, frame):
        self.event.set()

    def watch_stdin(self):
        try:
            if not stat.S_ISFIFO(os.fstat(0).st_mode):
                return self
        except OSError:
            return self
        threading.Thread(target=self._stdin, daemon=True).start()
        return self

    def _stdin(self):
        try:
            while os.read(0, 4096):
                pass
        except OSError:
            pass
        self.event.set()

    def wait(self, seconds):
        """Sleep up to `seconds`; True when it's time to stop."""
        return self.event.wait(seconds)
