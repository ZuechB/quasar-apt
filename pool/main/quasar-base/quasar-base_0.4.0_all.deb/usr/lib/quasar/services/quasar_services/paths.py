"""Where Quasar Services keeps things.

Tests point QUASAR_SERVICES_ROOT at a temporary folder. The override is ignored when running as root,
so nobody can redirect a root helper to another tree. Helper paths (the firewall, Sites' query) can be
swapped for tests the same way, also never as root.
"""
import os


def _is_root():
    geteuid = getattr(os, "geteuid", None)
    return geteuid is not None and geteuid() == 0


IS_ROOT = _is_root()
ROOT = "" if IS_ROOT else os.environ.get("QUASAR_SERVICES_ROOT", "").rstrip("/")


def p(path):
    """A system path, moved under the test root when one is set."""
    return ROOT + path if ROOT else path


def tool(env, default):
    """A helper program: the real one, or a test fake from the environment (never as root)."""
    return default if IS_ROOT else (os.environ.get(env) or default)


# ---- real system paths (written into units and drop-ins) ----------------------------------------
SYS_CONF = "/etc/quasar/services"
SYS_LIB = "/usr/lib/quasar/services"
SYS_STATE = "/var/lib/quasar-svc"
SYS_MNT = "/run/quasar/svc-mnt"
APP_IN_SANDBOX = "/srv/app"

# ---- configuration (root-owned) -----------------------------------------------------------------
DEFS = p(SYS_CONF)                          # <id>.json: what the owner set up (0640 root:<owner's group>)
DROPINS = p("/etc/systemd/system")          # quasar-svc@<id>.service.d/50-quasar-services.conf

# ---- state ---------------------------------------------------------------------------------------
STATE_DIRS = p(SYS_STATE)                   # StateDirectory=quasar-svc/<id>: the server's HOME, its saves
RUN = p("/run/quasar/svc")                  # <id>/last-start.json, locks
MNT = p(SYS_MNT)                            # <id>/app: the owner's folder, pinned (0700 root parent)
MOUNTINFO = "/proc/self/mountinfo"

# ---- other parts of Quasar --------------------------------------------------------------------------
FIREWALL = tool("QUASAR_SERVICES_FIREWALL", "/usr/libexec/quasar/quasar-firewall")
SITES_QUERY = tool("QUASAR_SITES_QUERY", "/usr/libexec/quasar/sites-query")
FIREWALL_NET = p("/run/quasar/firewall-net.json")
NETGUARD_SOCK = p("/run/quasar/netguard.sock")
LIVE_MARK = p("/run/live")                      # present on the live USB
ALLOW_LIVE = p("/run/quasar/services-allow-live")   # root-only test flag (QEMU boot tests)


def definition(sid):
    return os.path.join(DEFS, sid + ".json")


def dropin_dir(sid):
    return os.path.join(DROPINS, "quasar-svc@%s.service.d" % sid)


def state_dir(sid):
    return os.path.join(STATE_DIRS, sid)


def sys_state_dir(sid):
    return SYS_STATE + "/" + sid


def run_dir(sid):
    return os.path.join(RUN, sid)


def last_start(sid):
    return os.path.join(RUN, sid, "last-start.json")


def mount_dir(sid):
    return os.path.join(MNT, sid, "app")


def lock_file(name):
    return os.path.join(RUN, "locks", name + ".lock")


def live():
    """On the live USB (and not allowed there for a test)."""
    return os.path.exists(LIVE_MARK) and not os.path.exists(ALLOW_LIVE)
