"""Why a server can't run, in plain words. One table, shared by inspect (before adding), svc-prepare
(every start, as root) and the helpers' error lines, so the app and the command line say the same."""

MESSAGES = {
    "missing-folder": "The server's folder isn't there anymore ({path}).",
    "not-a-folder": "{path} isn't a folder.",
    "symlink": "The folder's path goes through a link (symlink). Pick the real folder instead.",
    "owner": "This folder doesn't belong to you. A server runs only from a folder its owner owns.",
    "writable": "Other accounts can change files in this folder. Take away their write access first "
                "(chmod go-w).",
    "fs": "This folder is on a drive Linux servers can't run from (FAT, exFAT, NTFS or a network drive). "
          "Copy it into your home folder.",
    "missing-exec": "{exec} isn't in the folder anymore. Copy the whole build back, or pick the program again.",
    "not-executable": "{exec} isn't allowed to run, and Quasar couldn't change that (its drive is read-only, "
                      "or the file is locked).",
    "not-a-program": "{exec} isn't a program Linux can run. Pick the server's Linux program (for a Unity "
                     "build, the .x86_64 file).",
    "arch": "{exec} is built for {arch}, but this PC is {machine}.",
    "windows-build": "This is the Windows build. In Unity, build the server for Linux (Unity Hub needs "
                     "“Linux Build Support (Mono)”).",
    "windows-dotnet": "This .NET app was published for Windows. Publish it for Linux "
                      "(dotnet publish -r linux-x64) or without a runtime identifier.",
    "windows-only": "This is a Windows desktop app (WPF or Windows Forms), which can't run on Linux.",
    "windows-program": "This is a Windows program (.exe). A server here needs its Linux build.",
    "no-runtime": "It needs the .NET {major} runtime. Get “.NET {major}” in the Store, then start it again.",
    "not-readable": "The server's account can't read this folder. Use “Make readable” in Services "
                    "(chmod -R a+rX), then start it again.",
    "live": "Servers can't run from the live USB. Install Quasar first.",
    "none": "There's no program in this folder that Quasar can start. Pick the program yourself.",
    "start-failed": "{name} stopped right after it started. Its last lines are below.",
    "port-busy": "{what} already uses {proto} {port}.",
}


def message(code, **fields):
    text = MESSAGES.get(code, "That didn't work.")
    try:
        return text.format(**fields)
    except (KeyError, IndexError):
        return text
