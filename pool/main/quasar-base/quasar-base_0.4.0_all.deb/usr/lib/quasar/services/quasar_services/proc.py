"""Running programs: systemctl, journalctl, ss and the firewall helper."""
import os
import subprocess

from .events import ServicesError

SAFE_PATH = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"


def base_env(extra=None):
    env = {"PATH": SAFE_PATH, "LC_ALL": "C.UTF-8", "LANG": "C.UTF-8"}
    if extra:
        env.update(extra)
    return env


def run(cmd, input=None, timeout=120, check=True, env=None, cwd=None, pass_fds=()):
    try:
        p = subprocess.run(cmd, input=input, capture_output=True, text=True, timeout=timeout,
                           env=env or base_env(), cwd=cwd, pass_fds=pass_fds)
    except FileNotFoundError:
        if check:
            raise ServicesError("%s isn't installed." % os.path.basename(cmd[0]), "missing-tool")
        return subprocess.CompletedProcess(cmd, 127, "", "not installed")
    except subprocess.TimeoutExpired:
        raise ServicesError("%s took too long." % os.path.basename(cmd[0]), "timeout")
    if check and p.returncode != 0:
        raise ServicesError("%s didn't work." % os.path.basename(cmd[0]), "command-failed",
                            details=((p.stderr or "") + (p.stdout or ""))[-6000:])
    return p


def systemctl(*args, check=True, timeout=120, user=False):
    return run(["systemctl"] + (["--user"] if user else []) + list(args), check=check, timeout=timeout,
               env=base_env(_user_bus_env()) if user else None)


def _user_bus_env():
    """systemctl --user needs the session bus address (a cleaned environment drops it)."""
    out = {}
    for key in ("XDG_RUNTIME_DIR", "DBUS_SESSION_BUS_ADDRESS", "HOME", "USER"):
        if os.environ.get(key):
            out[key] = os.environ[key]
    return out


def have(tool):
    for d in SAFE_PATH.split(":"):
        if os.access(os.path.join(d, tool), os.X_OK):
            return True
    return False


def account(name):
    """(uid, gid) of an account by name, or None."""
    import pwd
    try:
        pw = pwd.getpwnam(name)
    except KeyError:
        return None
    return pw.pw_uid, pw.pw_gid


def owner_name(uid):
    import pwd
    try:
        return pwd.getpwuid(uid).pw_name
    except KeyError:
        return str(uid)
