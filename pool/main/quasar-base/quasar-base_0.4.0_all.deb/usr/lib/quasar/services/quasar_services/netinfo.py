"""This PC's address on its home network, for "players on your Wi-Fi join 192.168.1.20:7770".

The firewall writes which connections are home networks to /run/quasar/firewall-net.json; the address
itself comes from `ip -j addr`. Without a home network it falls back to the default route's link.
"""
import ipaddress
import json

from . import paths, proc, store


def _ipv4(dev):
    p = proc.run(["ip", "-j", "-4", "addr", "show", "dev", dev], check=False, timeout=10)
    try:
        data = json.loads(p.stdout or "[]")
    except ValueError:
        return ""
    for link in data or []:
        for a in link.get("addr_info") or []:
            try:
                ip = ipaddress.ip_address(a.get("local", ""))
            except ValueError:
                continue
            if ip.version == 4 and not ip.is_loopback and not ip.is_link_local:
                return str(ip)
    return ""


def _mac(dev):
    try:
        with open("/sys/class/net/%s/address" % dev, encoding="ascii") as f:
            return f.read().strip()
    except OSError:
        return ""


def _default_dev():
    p = proc.run(["ip", "-j", "route", "show", "default"], check=False, timeout=10)
    try:
        routes = json.loads(p.stdout or "[]")
    except ValueError:
        return ""
    for r in routes or []:
        if r.get("dev"):
            return r["dev"]
    return ""


def lan(state=None):
    """{ip, iface, mac, network, home} or None."""
    state = store.read_json(paths.FIREWALL_NET, {}) if state is None else state
    conns = [c for c in (state or {}).get("connections") or [] if isinstance(c, dict) and c.get("device")]
    home = [c for c in conns if c.get("state") == "home" and c.get("home")]
    for c in home + [c for c in conns if c not in home]:
        dev = str(c["device"])
        if dev == "lo" or not dev.replace("-", "").replace("_", "").replace(".", "").isalnum():
            continue
        ip = _ipv4(dev)
        if ip:
            return {"ip": ip, "iface": dev, "mac": _mac(dev), "network": str(c.get("name") or ""),
                    "home": c in home}
    dev = _default_dev()
    if dev and dev.replace("-", "").replace("_", "").replace(".", "").isalnum():
        ip = _ipv4(dev)
        if ip:
            return {"ip": ip, "iface": dev, "mac": _mac(dev), "network": "", "home": False}
    return None
