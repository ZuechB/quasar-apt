"""Reading and writing Services' files: atomic JSON writes, locks and server definitions.

  /etc/quasar/services/<id>.json        the definition (0640 root:<owner's group>: the owner and root read
                                        it; the server's own unit gets a copy through LoadCredential=)
  /run/quasar/svc/<id>/last-start.json  why the last start was refused (svc-prepare), or that it was fine
"""
import contextlib
import json
import os
import tempfile

from . import paths
from .events import ServicesError, BUSY, NOT_OWNER


def read_json(path, default=None):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def _atomic(path, write, mode, uid, gid):
    folder = os.path.dirname(path)
    os.makedirs(folder, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=".tmp-", dir=folder)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            write(f)
            f.flush()
            os.fsync(f.fileno())
        os.chmod(tmp, mode)
        if (uid is not None or gid is not None) and hasattr(os, "chown"):
            os.chown(tmp, -1 if uid is None else uid, -1 if gid is None else gid)
        os.replace(tmp, path)
    except BaseException:
        with contextlib.suppress(OSError):
            os.unlink(tmp)
        raise


def write_json(path, data, mode=0o644, uid=None, gid=None):
    def w(f):
        json.dump(data, f, indent=1, ensure_ascii=False)
        f.write("\n")
    _atomic(path, w, mode, uid, gid)


def write_text(path, text, mode=0o644, uid=None, gid=None):
    _atomic(path, lambda f: f.write(text), mode, uid, gid)


@contextlib.contextmanager
def lock(name, wait=True):
    """An exclusive flock. "global" guards ids, accounts and ports; "svc-<id>" guards one server."""
    try:
        import fcntl
    except ImportError:          # Windows (unit tests): no locking needed
        yield
        return
    path = paths.lock_file(name)
    os.makedirs(os.path.dirname(path), mode=0o755, exist_ok=True)
    fd = os.open(path, os.O_CREAT | os.O_RDWR, 0o600)
    try:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | (0 if wait else fcntl.LOCK_NB))
        except BlockingIOError:
            raise ServicesError("Another change to this server is still running. Try again in a moment.",
                                "busy", BUSY)
        yield
    finally:
        os.close(fd)


def list_ids():
    try:
        names = os.listdir(paths.DEFS)
    except OSError:
        return []
    return sorted(n[:-5] for n in names if n.endswith(".json") and not n.startswith("."))


def load(sid):
    data = read_json(paths.definition(sid))
    if not data:
        raise ServicesError("There's no server called %s." % sid, "not-found")
    return data


def readable_definitions():
    """Every definition this process may read: all of them as root, the caller's own otherwise."""
    out = []
    for sid in list_ids():
        data = read_json(paths.definition(sid))
        if isinstance(data, dict) and data.get("id") == sid:
            out.append(data)
    return out


def owner_gid(defn):
    """The owner's own group (Debian gives every account one): files only the owner and root may read.
    None when not running as root (tests) or the account is gone (then root's group: root only)."""
    if not paths.IS_ROOT:
        return None
    try:
        import pwd
        return pwd.getpwuid(int(defn.get("owner"))).pw_gid
    except (KeyError, TypeError, ValueError):
        return 0


def save(defn):
    write_json(paths.definition(defn["id"]), defn, mode=0o640, gid=owner_gid(defn))


def remove(sid):
    with contextlib.suppress(FileNotFoundError):
        os.unlink(paths.definition(sid))


def write_last_start(sid, ok, code="", message="", at=None):
    import time
    os.makedirs(paths.run_dir(sid), mode=0o755, exist_ok=True)
    write_json(paths.last_start(sid), {"ok": bool(ok), "code": code, "message": message,
                                       "at": int(at if at is not None else time.time())})


def last_start(sid):
    data = read_json(paths.last_start(sid))
    return data if isinstance(data, dict) else None


def caller_uid():
    """The account that ran pkexec, or None when called directly as root (units, tests, installer)."""
    raw = os.environ.get("PKEXEC_UID")
    if raw is None:
        return None
    try:
        return int(raw)
    except ValueError:
        raise ServicesError("Unknown caller.", "usage")


def check_owner(defn, uid):
    if uid is not None and defn.get("owner") != uid:
        raise ServicesError("This server belongs to another account on this PC.", "not-owner", NOT_OWNER)
