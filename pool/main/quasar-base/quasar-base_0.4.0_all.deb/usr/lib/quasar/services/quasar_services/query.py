"""/usr/libexec/quasar/services-query: read-only answers for the Services app, the shell's tray and
Settings. Runs as the user, no pkexec. PROTOCOL.md has every shape.

  state                       servers, sites and Quasar's own services, in one call
  watch [--summary]           the same (or the tray's counts) at start and after every change
  inspect PATH                how a folder would run
  logs ID [-f]                a server's log (journald), plus its player count when it has a pattern
  journal KEY…|--all [-n N] [-f]   any service's log in batches: the consoles (journal.py)
  units [-f]                  every service on this PC, then what changes (allunits.py)
  stats ID [-f]               CPU, memory, ports listening, packets from outside (every 2 s with -f)
  dns-check NAME [--public]   is the public name there, DNS only, pointing at this network
  public-ip                   this network's public address (asks Cloudflare: only when asked)
  check-port PROTO PORT [ID]  is a port free for a server
"""
import json
import os
import re
import socket
import time

from . import allunits, detect, dns, events, journal, lifecycle, netinfo, paths, proc, reasons, run, store, system
from . import units, validate
from . import ports as portmod
from .events import ServicesError, emit, result

ICONS = {"unity": ("gamepad", "#FF8FB1"), "dotnet": ("code", "#B9A4FF"), "program": ("server", "#8CF5B0")}
ACTIONS = ["start", "stop", "restart", "toggle", "update", "settings", "remove"]


def _quote(arg):
    if arg and not re.search(r"[\s\"'\\$`]", arg):
        return arg
    return '"' + arg.replace("\\", "\\\\").replace('"', '\\"') + '"'


def display_cmd(defn):
    """The command as svc-run runs it (run.player_args adds Unity's headless flags and -logFile -)."""
    args = run.player_args(defn.get("kind"), defn.get("args"))
    if defn.get("kind") == "dotnet":
        parts = ["dotnet", defn.get("exec", "")] + args
    else:
        parts = [defn.get("exec", "")] + args
    return " ".join(_quote(p) for p in parts)


def server_item(defn, info, busy, last=None):
    sid = defn["id"]
    name = units.unit(sid)
    i = info.get(name) or {}
    st = units.status_of(i)
    # A start svc-prepare refused leaves the server unit merely inactive ("dependency"): it needs attention.
    if st["status"] == "stopped" and last and not last.get("ok"):
        st["status"] = "failed"
    opts = defn.get("options") or {}
    enabled = i.get("UnitFileState") in ("enabled", "enabled-runtime") if i.get("LoadState") == "loaded" \
        else bool(opts.get("boot", True))
    icon, hue = ICONS.get(defn.get("kind"), ICONS["program"])
    label, facts = defn.get("label") or "", defn.get("facts") or []
    ports = [dict(p, listening=(p.get("proto"), int(p.get("port", 0))) in busy) for p in defn.get("ports") or []]
    return {
        "key": "svc:" + sid, "id": sid, "source": "server", "name": defn.get("name") or sid,
        "desc": " · ".join(x for x in [label] + facts[:1] if x), "kind": "service", "icon": icon, "hue": hue,
        "system": False, "unit": name, "enabled": enabled, "status": st["status"], "since": st["since"],
        "memory": st["memory"], "restarts": st["restarts"], "result": st["result"],
        "restart": bool(opts.get("crashRestart", True)), "cmd": display_cmd(defn), "link": None,
        "actions": list(ACTIONS),
        "server": {"path": defn.get("path"), "exec": defn.get("exec"), "args": defn.get("args") or [],
                   "env": defn.get("env") or [], "engine": defn.get("kind"), "label": label, "facts": facts,
                   "ports": ports, "public": defn.get("public"), "data": paths.sys_state_dir(sid),
                   "account": "svc-" + sid,
                   "options": {"boot": enabled, "crashRestart": bool(opts.get("crashRestart", True)),
                               "memoryMax": opts.get("memoryMax"), "cpuWeight": opts.get("cpuWeight")},
                   "players": defn.get("players"), "lastStart": last},
    }


def collect_state():
    defs = store.readable_definitions()
    info = units.show([units.unit(d["id"]) for d in defs] + system.system_units(False))
    uinfo = units.show(system.system_units(True), user=True)
    busy = portmod.listening()
    items = [server_item(d, info, busy, store.last_start(d["id"])) for d in defs]
    items += system.site_rows()
    items += system.system_rows(info, uinfo)
    fw = info.get("quasar-firewall.service") or {}
    return {"live": paths.live(), "firewall": {"on": fw.get("ActiveState") == "active"},
            "netguard": os.path.exists(paths.NETGUARD_SOCK), "lan": netinfo.lan(), "items": items}


def summarize(state):
    items = state.get("items") or []
    failed = [i for i in items if i.get("status") == "failed"]
    return {"running": sum(1 for i in items if i.get("status") == "running"), "failed": len(failed),
            "failedNames": [i.get("name") for i in failed], "failedKeys": [i.get("key") for i in failed],
            "added": sum(1 for i in items if i.get("source") == "server")}


def cmd_state(args):
    result(**collect_state())


def cmd_watch(args):
    from . import watch
    extra = set(system.system_units(False)) | set(system.system_units(True))
    watch.run(collect_state, summarize, summary="--summary" in args, extra=extra)


def _fstype(path):
    p = proc.run(["findmnt", "-no", "FSTYPE", "-T", path], check=False, timeout=10)
    return (p.stdout or "").strip().splitlines()[0] if (p.stdout or "").strip() else ""


def cmd_inspect(args):
    path = validate.folder(args[0])
    out = detect.inspect(path)
    have = {p["code"] for p in out["problems"]}
    if "missing-folder" not in have and "not-a-folder" not in have:
        found = detect.folder_problems(path, os.getuid(), _fstype(path))
        out["problems"] = [{"code": c, "message": reasons.message(c, path=path)} for c in found if c not in have] \
            + out["problems"]
    result(**out)


def _owned(sid):
    """A definition the caller can read: their own (definitions are 0640 root:<owner's group>)."""
    return store.load(validate.service_id(sid))


def journal_item(raw, ctx=None):
    """One `journalctl -o json` line -> logs' per-line shape {"type":"log","t","m","lvl"}, or None.
    Levels as the consoles' (journal.classify: Unity prints everything at one priority, so its own words
    tell errors apart)."""
    try:
        rec = json.loads(raw)
    except ValueError:
        return None
    line = journal.classify(rec, ctx or journal.Context(os.getuid()))
    if not line:
        return None
    return {"type": "log", "t": line["t"], "m": line["m"], "lvl": line["lvl"]}


def players_of(text, rx):
    m = rx.search(text)
    if not m:
        return None
    try:
        now = int(m.group(1))
        cap = int(m.group(2)) if rx.groups >= 2 and m.group(2) else None
    except (TypeError, ValueError):
        return None
    return {"now": now, "max": cap}


def cmd_logs(args):
    defn = _owned(args[0])
    follow = "-f" in args[1:]
    rx = None
    if defn.get("players") and defn["players"].get("regex"):
        try:
            rx = re.compile(defn["players"]["regex"])
        except re.error:
            rx = None
    # One journalctl for the backlog and what follows (nothing lost in between), the server and svc-prepare's
    # refusals; one line per entry, as before (the app's console uses `journal`, in batches).
    stopper = lifecycle.Stopper().install()
    ctx = journal.Context(os.getuid())
    argv = journal.build_argv(units.both(defn["id"]), [], 200, follow)
    seen = {"live": False, "latest": None}

    def out(batch):
        latest = None
        for line in batch:
            emit("log", t=line["t"], m=line["m"], lvl=line["lvl"])
            if rx:
                latest = players_of(line["m"], rx) or latest
        if latest and seen["live"]:
            emit("players", **latest)            # a new count
        elif latest:
            seen["latest"] = latest              # the backlog's newest count, sent once it's out

    def live():
        seen["live"] = True
        if seen["latest"]:
            emit("players", **seen["latest"])
    return journal.stream(argv, lambda rec: journal.classify(rec, ctx), follow, stopper, out, live)


def wan_counters(sid):
    """Packets from outside the home network to this server's internet ports (netguard), or None."""
    try:
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.settimeout(2)
        s.connect(paths.NETGUARD_SOCK)
        s.sendall(b'{"op":"wan"}\n')
        data = b""
        while b"\n" not in data and len(data) < (1 << 20):
            chunk = s.recv(65536)
            if not chunk:
                break
            data += chunk
        s.close()
        resp = json.loads(data.split(b"\n", 1)[0].decode("utf-8"))
    except (OSError, ValueError):
        return None
    if not isinstance(resp, dict) or not resp.get("ok"):
        return None
    for e in resp.get("entries") or []:
        if isinstance(e, dict) and e.get("id") == "svc:" + sid:
            return {"packets": int(e.get("packets") or 0), "bytes": int(e.get("bytes") or 0)}
    return {"packets": 0, "bytes": 0}


def _read_int(path, key=None):
    try:
        with open(path, encoding="ascii") as f:
            text = f.read()
    except OSError:
        return None
    if key is None:
        try:
            return int(text.strip())
        except ValueError:
            return None
    for line in text.splitlines():
        k, _, v = line.partition(" ")
        if k == key:
            try:
                return int(v)
            except ValueError:
                return None
    return None


def cmd_stats(args):
    defn = _owned(args[0])
    follow = "-f" in args[1:]
    name = units.unit(defn["id"])
    internet = any(p.get("reach") == "internet" for p in defn.get("ports") or [])
    prev = None
    while True:
        info = units.show([name]).get(name) or {}
        cg = units.cgroup_dir(info)
        usage = _read_int(cg + "/cpu.stat", "usage_usec") if cg else None
        now = time.monotonic()
        cpu = None
        if usage is not None and prev and prev[0] is not None and now > prev[1]:
            cpu = round(max(0.0, (usage - prev[0]) / ((now - prev[1]) * 1e6) * 100.0), 1)
        prev = (usage, now)
        busy = portmod.listening()
        result(status=units.status_of(info)["status"], cpu=cpu,
               memory=_read_int(cg + "/memory.current") if cg else None,
               tasks=_read_int(cg + "/pids.current") if cg else None,
               ports=[{"proto": p["proto"], "port": p["port"], "listening": (p["proto"], int(p["port"])) in busy}
                      for p in defn.get("ports") or []],
               wan=wan_counters(defn["id"]) if internet else None)
        if not follow:
            return 0
        time.sleep(2)


def cmd_dns_check(args):
    result(**dns.check(validate.domain(args[0]), want_public="--public" in args[1:]))


def cmd_public_ip(args):
    try:
        result(ip=dns.public_ip())
    except (OSError, ValueError) as e:
        raise ServicesError("Couldn't ask for this network's public address.", "offline", details=str(e))


def cmd_check_port(args):
    proto = args[0]
    if proto not in validate.PROTOS:
        events.usage("check-port udp|tcp PORT [ID]")
    try:
        port = validate.port_number(int(args[1]))
    except ValueError:
        raise ServicesError("Ports go from 1024 to 65535.", "invalid", events.USAGE)
    own = validate.service_id(args[2]) if len(args) > 2 else ""
    defs = store.readable_definitions()
    busy = portmod.listening()
    mine = next((d for d in defs if d["id"] == own), None)
    if mine and units.status_of(units.show([units.unit(own)]).get(units.unit(own)) or {})["status"] == "running":
        busy -= {(p["proto"], int(p["port"])) for p in mine.get("ports") or []}
    by = portmod.conflict(proto, port, own, defs, busy)
    result(free=not by, by=by)


VERBS = {"state": (cmd_state, 0), "watch": (cmd_watch, 0), "inspect": (cmd_inspect, 1), "logs": (cmd_logs, 1),
         "journal": (journal.cmd_journal, 1), "units": (allunits.cmd_units, 0),
         "stats": (cmd_stats, 1), "dns-check": (cmd_dns_check, 1), "public-ip": (cmd_public_ip, 0),
         "check-port": (cmd_check_port, 2)}


def main(argv):
    def go(argv):
        if not argv or argv[0] not in VERBS:
            events.usage("Usage: services-query " + "|".join(sorted(VERBS)) + " …")
        fn, nargs = VERBS[argv[0]]
        if len(argv) - 1 < nargs:
            events.usage("%s needs %d argument(s)." % (argv[0], nargs))
        return fn(argv[1:])
    return events.run_main(go, argv)
