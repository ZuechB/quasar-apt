"""How a folder would run as a server: Unity players built for Linux, .NET apps and plain programs.

inspect(path) never runs anything from the folder. It reads names, ELF/PE headers, Unity's app.info and
.NET's runtimeconfig.json, and suggests the program, its arguments and the ports its networking library
uses by default. Suggested ports always reach the home network only: the internet is the owner's choice.
For a Unity Mono build it also lists the flags the game's own scripts read (the literals in
Assembly-CSharp*.dll, clr.py), and pre-fills its port and name flags from the suggested port and name.
An optional quasar-service.json in the folder pre-fills everything (PROTOCOL.md).
"""
import json
import os
import platform
import re
import stat
import struct

from . import clr, reasons, validate
from .events import ServicesError

MANIFEST = "quasar-service.json"
MAX_ENTRIES = 4000            # a folder with more top-level entries than this isn't a server build
MAX_HEADERS = 200             # files whose header is read when looking for a program

ELF_MACHINES = {0x3E: "x86-64", 0xB7: "arm64", 0x28: "arm", 0x03: "x86"}
MACHINE_NAMES = {"x86_64": "x86-64", "amd64": "x86-64", "aarch64": "arm64", "arm64": "arm64",
                 "armv7l": "arm", "armv6l": "arm", "i686": "x86", "i386": "x86"}
UNITY_EXTS = (".x86_64", ".arm64", ".x86")

# Networking libraries a Unity build's Managed folder can carry: (dll name prefix, label, default ports,
# note). The first match wins, so the specific ones come first. Ports are the library's own defaults.
NETWORKING = (
    ("fishnet.runtime", "FishNet", [("udp", 7770)], ""),
    ("unity.netcode.runtime", "Netcode for GameObjects", [("udp", 7777)], ""),
    ("mirror", "Mirror", [("udp", 7777)], ""),
    ("darkrift", "DarkRift", [("tcp", 4296), ("udp", 4296)], ""),
    ("fusion.runtime", "Photon Fusion", [], "photon"),
    ("photon", "Photon", [], "photon"),
    ("riptide", "Riptide", [], "port"),
    ("litenetlib", "LiteNetLib", [], "port"),
)

# The game's own flags: only the assemblies Unity compiles the project's scripts into. Engine and
# third-party dlls carry literals that aren't the game's options (-Infinity, -label, -runTests…).
USER_ASSEMBLIES = ("Assembly-CSharp.dll", "Assembly-CSharp-firstpass.dll")
FLAG_RE = re.compile(r"^--?[A-Za-z][A-Za-z0-9_-]{1,31}\Z")
FLAG_SKIP = {"batchmode", "nographics", "logfile", "infinity", "inf", "nan"}   # Unity's own, and numbers
MAX_FLAGS = 40
# What a flag is for, by its exact name (lowercase, no leading dashes, no "-" or "_"), never by a part of
# it: -playername isn't a name or players flag. Listed first, in this order; the rest keep the heap's order.
FLAG_ROLES = (("port", "port"), ("serverport", "port"), ("gameport", "port"),
              ("name", "name"), ("servername", "name"), ("sessionname", "name"),
              ("maxplayers", "value"), ("password", "value"), ("map", "value"), ("queryport", "value"))
_ROLE = dict(FLAG_ROLES)
_RANK = {key: i for i, (key, _) in enumerate(FLAG_ROLES)}
# A game's scripts serve its players too: flags a server never uses go last (Animal Go's -join, -skiptitle).
CLIENT_FLAGS = {"join", "connect", "playername", "username", "nickname", "skiptitle", "skipintro", "nosplash",
                "windowed", "fullscreen"}


def this_machine():
    m = platform.machine().lower()
    return MACHINE_NAMES.get(m, m)


def header(path, n=64):
    try:
        with open(path, "rb") as f:
            return f.read(n)
    except OSError:
        return b""


def binary_kind(data):
    """"elf:<machine>", "pe" (Windows), "script" (#!), or ""."""
    if data[:4] == b"\x7fELF" and len(data) >= 20:
        fmt = "<H" if data[5:6] == b"\x01" else ">H"
        (machine,) = struct.unpack(fmt, data[18:20])
        return "elf:" + ELF_MACHINES.get(machine, "machine %d" % machine)
    if data[:2] == b"MZ":
        return "pe"
    if data[:2] == b"#!":
        return "script"
    return ""


def _listdir(path):
    try:
        names = os.listdir(path)
    except OSError:
        return None
    return names if len(names) <= MAX_ENTRIES else names[:MAX_ENTRIES]


def _isfile(path):
    try:
        return stat.S_ISREG(os.stat(path).st_mode)
    except OSError:
        return False


def _isdir(path):
    return os.path.isdir(path)


def _executable(path):
    try:
        return bool(os.stat(path).st_mode & 0o100)
    except OSError:
        return False


def _app_info(data_dir):
    """Unity writes "<company>\\n<product>" into <Name>_Data/app.info."""
    try:
        with open(os.path.join(data_dir, "app.info"), encoding="utf-8", errors="replace") as f:
            lines = [l.strip() for l in f.read(4096).splitlines()]
    except OSError:
        return "", ""
    return (lines[0] if lines else ""), (lines[1] if len(lines) > 1 else "")


def _networking(managed):
    names = [n.lower() for n in (_listdir(managed) or []) if n.lower().endswith(".dll")]
    for prefix, label, ports, note in NETWORKING:
        if any(n.startswith(prefix) for n in names):
            return label, ports, note
    return "", [], ""


def flag_key(flag):
    """"-Max-Players" -> "maxplayers": how flags are compared."""
    return re.sub(r"[-_]", "", str(flag).lstrip("-").lower())


def game_flags(managed):
    """[{flag, role}] the game's scripts read, from <Name>_Data/Managed (role: port | name | value | "")."""
    found, seen = [], set()
    for name in USER_ASSEMBLIES:
        for text in clr.flag_strings(os.path.join(managed, name)):
            if not FLAG_RE.match(text) or flag_key(text) in FLAG_SKIP or text.lower() in seen:
                continue
            seen.add(text.lower())
            found.append(text)
    def rank(i):
        key = flag_key(found[i])
        return (_RANK.get(key, len(_RANK) + (1 if key in CLIENT_FLAGS else 0)), i)
    order = sorted(range(len(found)), key=rank)
    return [{"flag": found[i], "role": _ROLE.get(flag_key(found[i]), "")} for i in order[:MAX_FLAGS]]


def _prefill(out):
    """The game's own port and name flags, filled in from the suggested port and name, after what's there."""
    flags = out.get("flags") or []
    port = next((f["flag"] for f in flags if f["role"] == "port"), "")
    name = next((f["flag"] for f in flags if f["role"] == "name"), "")
    args = list(out["args"])
    if port and out["ports"]:
        args += [port, str(out["ports"][0]["port"])]
    if name and out["name"]:
        args += [name, out["name"]]
    out["args"] = args


def _port_items(ports, label="Game"):
    out = []
    for i, (proto, port) in enumerate(ports):
        out.append({"proto": proto, "port": port, "label": label if i == 0 else label + " (" + proto.upper() + ")",
                    "reach": "home"})
    return out


def _unity(path, names):
    linux = windows = None
    for d in sorted(names):
        if not d.endswith("_Data") or not _isdir(os.path.join(path, d)):
            continue
        base = d[:-5]
        for ext in UNITY_EXTS:
            if base + ext in names and _isfile(os.path.join(path, base + ext)):
                linux = linux or (base, base + ext)
        if base + ".exe" in names:
            windows = windows or (base, base + ".exe")
    if linux and "UnityPlayer.so" in names:
        return "linux", linux
    if windows and "UnityPlayer.dll" in names:
        return "windows", windows
    return None, None


def _dotnet_runtimes():
    """{framework name: [major, ...]} from the system's dotnet (the only one a server's sandbox sees)."""
    for exe in ("/usr/bin/dotnet", "/usr/lib/dotnet/dotnet", "/usr/share/dotnet/dotnet"):
        if os.access(exe, os.X_OK):
            break
    else:
        return {}
    import subprocess
    try:
        out = subprocess.run([exe, "--list-runtimes"], capture_output=True, text=True, timeout=15).stdout
    except (OSError, subprocess.SubprocessError):
        return {}
    found = {}
    for line in out.splitlines():
        m = re.match(r"^(\S+)\s+(\d+)\.", line.strip())
        if m:
            found.setdefault(m.group(1), []).append(int(m.group(2)))
    return found


def _major(version):
    m = re.match(r"^(\d+)\.", str(version or ""))
    return int(m.group(1)) if m else None


def inspect(path, runtimes=None):
    """What would run from this folder. Never raises for a bad folder: problems come back as data."""
    out = {"path": path, "kind": "none", "name": os.path.basename(path.rstrip("/")) or path, "id": "",
           "exec": "", "args": [], "label": "", "facts": [], "ports": [], "players": None, "manifest": False,
           "executable": True, "problems": [], "notes": [], "choices": [], "flags": []}

    def problem(code, **fields):
        out["problems"].append({"code": code, "message": reasons.message(code, path=path, **fields)})

    if not os.path.exists(path):
        problem("missing-folder")
        out["id"] = validate.slug(out["name"])
        return out
    if not _isdir(path):
        problem("not-a-folder")
        out["id"] = validate.slug(out["name"])
        return out
    names = set(_listdir(path) or [])
    machine = this_machine()

    kind, found = _unity(path, names)
    if kind == "linux":
        base, exe = found
        company, product = _app_info(os.path.join(path, base + "_Data"))
        bkind = binary_kind(header(os.path.join(path, exe)))
        arch = bkind[4:] if bkind.startswith("elf:") else ""
        net, ports, note = _networking(os.path.join(path, base + "_Data", "Managed"))
        il2cpp = "GameAssembly.so" in names
        # No -batchmode -nographics here: svc-run always adds them (run.player_args), so the arguments are
        # the game's own options only.
        out.update(kind="unity", name=product or base, exec=exe, label="Unity server", args=[],
                   ports=_port_items(ports))
        out["facts"] = [f for f in (net, "IL2CPP" if il2cpp else "Mono", arch) if f]
        out["flags"] = [] if il2cpp else game_flags(os.path.join(path, base + "_Data", "Managed"))
        if arch and arch != machine:
            problem("arch", exec=exe, arch=arch, machine=machine)
        if note == "photon":
            out["notes"].append("It uses Photon's cloud: players connect through Photon, not to this PC, "
                                "so there's no port to open.")
        elif note == "port" or (not net and not il2cpp):
            out["notes"].append("Enter the port your game listens on.")
        elif il2cpp and not net:
            out["notes"].append("IL2CPP builds don't show their networking library: enter the port your game uses.")
        out["notes"].append("Unity's log shows under Logs.")
        if company:
            out["facts"].append(company)
    elif kind == "windows":
        base, exe = found
        company, product = _app_info(os.path.join(path, base + "_Data"))
        out.update(kind="unity-windows", name=product or base, exec=exe, label="Unity server (Windows build)")
        problem("windows-build")
    else:
        _dotnet_or_program(path, names, out, problem, machine, runtimes)

    if out["exec"] and out["kind"] in ("unity", "program"):
        out["executable"] = _executable(os.path.join(path, out["exec"]))
    applied = _apply_manifest(path, names, out)
    if out["kind"] == "unity" and "args" not in applied:      # the owner's quasar-service.json wins
        _prefill(out)
    out["id"] = validate.slug(out["name"])
    return out


def _dotnet_or_program(path, names, out, problem, machine, runtimes):
    configs = sorted(n for n in names if n.endswith(".runtimeconfig.json"))
    for cfg in configs:
        stem = cfg[:-len(".runtimeconfig.json")]
        if stem + ".dll" not in names:
            continue
        try:
            with open(os.path.join(path, cfg), encoding="utf-8") as f:
                rc = json.loads(f.read(262144))
        except (OSError, ValueError):
            continue
        opts = (rc or {}).get("runtimeOptions") or {}
        frameworks = opts.get("frameworks") or ([opts["framework"]] if opts.get("framework") else [])
        included = opts.get("includedFrameworks") or []
        fnames = [str(f.get("name") or "") for f in (frameworks or included) if isinstance(f, dict)]
        if any(n == "Microsoft.WindowsDesktop.App" for n in fnames):
            out.update(kind="dotnet-windows", name=stem, exec=stem + ".dll", label=".NET app (Windows desktop)")
            problem("windows-only")
            return
        asp = "Microsoft.AspNetCore.App" in fnames
        if included:
            apphost = os.path.join(path, stem)
            bkind = binary_kind(header(apphost)) if stem in names else ""
            if bkind.startswith("elf:"):
                arch = bkind[4:]
                out.update(kind="program", name=stem, exec=stem, label=".NET app (self-contained)",
                           facts=[f for f in ("ASP.NET Core" if asp else ".NET", arch) if f])
                if arch != machine:
                    problem("arch", exec=stem, arch=arch, machine=machine)
            else:
                out.update(kind="dotnet-windows", name=stem, exec=stem + ".exe", label=".NET app (Windows)")
                problem("windows-dotnet")
            return
        need = None
        for f in frameworks:
            if isinstance(f, dict) and f.get("name") == "Microsoft.NETCore.App":
                need = _major(f.get("version"))
        need = need or max([_major(f.get("version")) or 0 for f in frameworks if isinstance(f, dict)] or [0]) or None
        have = runtimes if runtimes is not None else _dotnet_runtimes()
        cores = have.get("Microsoft.NETCore.App") or []
        out.update(kind="dotnet", name=stem, exec=stem + ".dll", label=".NET app",
                   facts=[f for f in ("ASP.NET Core" if asp else "", ".NET %d" % need if need else ".NET") if f])
        if need and not any(m >= need for m in cores):
            problem("no-runtime", major=need)
        elif need and need not in cores and cores:
            out["notes"].append("Runs on .NET %d (built for .NET %d)." % (max(cores), need))
        if asp and need and not any(m >= need for m in have.get("Microsoft.AspNetCore.App") or []):
            out["notes"].append("It also needs ASP.NET Core %d (“ASP.NET Core %d” in the Store)." % (need, need))
        return

    # A plain program: ELF executables at the top (not libraries), then #! scripts.
    elfs, pes, scripts, looked = [], [], [], 0
    for n in sorted(names):
        full = os.path.join(path, n)
        if looked >= MAX_HEADERS or not _isfile(full) or n.endswith(".so") or ".so." in n:
            continue
        looked += 1
        bkind = binary_kind(header(full))
        if bkind.startswith("elf:"):
            elfs.append((n, bkind[4:]))
        elif bkind == "pe" and n.lower().endswith(".exe"):
            pes.append(n)
        elif bkind == "script":
            scripts.append(n)
    folder_name = os.path.basename(path.rstrip("/")).lower()

    def rank(item):
        n = item[0].lower()
        return (0 if "server" in n else 1, 0 if folder_name and folder_name in n else 1, n)

    if elfs:
        elfs.sort(key=rank)
        exe, arch = elfs[0]
        out.update(kind="program", name=os.path.basename(path.rstrip("/")) or exe, exec=exe, label="Program",
                   facts=[arch], choices=[e[0] for e in elfs] + scripts)
        if arch != machine:
            problem("arch", exec=exe, arch=arch, machine=machine)
    elif scripts:
        scripts.sort(key=lambda n: (0 if "server" in n.lower() or "start" in n.lower() else 1, n))
        out.update(kind="program", exec=scripts[0], label="Script", choices=scripts)
    elif pes:
        out.update(kind="windows", exec=pes[0], label="Windows program")
        problem("windows-program")
    else:
        problem("none")


def _apply_manifest(path, names, out):
    """quasar-service.json over what was found. Returns the keys it set."""
    applied = set()
    if MANIFEST not in names:
        return applied
    full = os.path.join(path, MANIFEST)
    try:
        if os.path.getsize(full) > 65536:
            raise ValueError("it's too big")
        with open(full, encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            raise ValueError("it isn't an object")
        if data.get("name"):
            out["name"] = validate.name(data["name"])
            applied.add("name")
        if data.get("exec"):
            out["exec"] = validate.exec_path(data["exec"])
            out["executable"] = _executable(os.path.join(path, out["exec"])) if out["kind"] != "dotnet" else True
            applied.add("exec")
        if "args" in data:
            out["args"] = validate.args(data["args"])
            applied.add("args")
        if "ports" in data:
            out["ports"] = validate.ports(data["ports"])
            applied.add("ports")
        if data.get("players"):
            out["players"] = validate.players(data["players"])
            applied.add("players")
        out["manifest"] = True
    except (OSError, ValueError, ServicesError) as e:
        out["notes"].append("%s has a problem (%s), so Quasar ignored it." % (MANIFEST, getattr(e, "message", None) or e))
    return applied


def folder_problems(path, uid, fstype=None):
    """The owner-side view of what svc-prepare will refuse (codes from reasons.py)."""
    found = []
    probe = "/"
    for part in [p for p in path.split("/") if p]:
        probe = os.path.join(probe, part)
        try:
            st = os.lstat(probe)
        except OSError:
            return ["missing-folder"]
        if stat.S_ISLNK(st.st_mode):
            return ["symlink"]
    try:
        st = os.stat(path)
    except OSError:
        return ["missing-folder"]
    if uid is not None and st.st_uid != uid:
        found.append("owner")
    if st.st_mode & 0o022:
        found.append("writable")
    if fstype and fstype not in ("ext4", "btrfs", "xfs", "f2fs"):
        found.append("fs")
    return found
