"""svc-run: ExecStart of quasar-svc@.service. Runs as svc-<id> inside the sandbox, where the owner's
folder is /srv/app (read-only) and HOME is the save folder (/var/lib/quasar-svc/<id>).

- Unity players always get `-batchmode -nographics` (the sandbox has no screen, and a player started
  without them waits for one: Animal Go's server only hosts in batch mode), and `-logFile -` unless their
  arguments name a log file, so their log reaches journald (Services' Logs) instead of Player.log.
- Framework-dependent .NET apps run through the system's dotnet, rolling forward to the newest major
  (Quasar ships .NET 10) unless their environment says otherwise.
- Everything else is exec'd as it is: no shell, so arguments arrive exactly as stored.
"""
import json
import os
import re
import sys

APP = "/srv/app"
DOTNETS = ("/usr/bin/dotnet", "/usr/lib/dotnet/dotnet", "/usr/share/dotnet/dotnet")
ID_RE = re.compile(r"^[a-z][a-z0-9-]{0,24}[a-z0-9]$")
ENV_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]{0,127}$")
RESERVED = {"HOME", "USER", "LOGNAME", "SHELL", "PATH", "STATE_DIRECTORY", "CREDENTIALS_DIRECTORY",
            "INVOCATION_ID", "JOURNAL_STREAM", "NOTIFY_SOCKET", "LISTEN_FDS", "LISTEN_PID", "LISTEN_FDNAMES",
            "SYSTEMD_EXEC_PID", "QUASAR_SERVICE"}
PASS = ("INVOCATION_ID", "JOURNAL_STREAM", "CREDENTIALS_DIRECTORY", "STATE_DIRECTORY")
UNITY_HEADLESS = ("-batchmode", "-nographics")


def player_args(kind, args):
    """The arguments a server really gets (query.display_cmd shows the same). Unity: -batchmode and
    -nographics in front when missing, so an option left without its value at the end can't take them;
    -logFile - at the end unless a log file is named."""
    args = [str(a) for a in args or []]
    if kind != "unity":
        return args
    have = {a.lower() for a in args}
    out = [f for f in UNITY_HEADLESS if f not in have] + args
    if "-logfile" not in have:
        out += ["-logFile", "-"]
    return out


def die(msg):
    print("svc-run: " + msg, file=sys.stderr, flush=True)
    sys.exit(78)          # EX_CONFIG: systemd shows it as a failed start


def build(defn, environ, app=APP, exists=os.path.exists):
    """(program to exec, argv, environment) for a definition."""
    sid = defn["id"]
    kind = defn.get("kind")
    env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": environ.get("STATE_DIRECTORY") or "/var/lib/quasar-svc/" + sid,
           "LANG": "C.UTF-8", "QUASAR_SERVICE": sid, "DOTNET_CLI_TELEMETRY_OPTOUT": "1", "DOTNET_NOLOGO": "1"}
    for key in PASS:
        if environ.get(key):
            env[key] = environ[key]
    if kind == "dotnet":
        env["DOTNET_ROLL_FORWARD"] = "Major"
    for pair in defn.get("env") or []:
        if isinstance(pair, (list, tuple)) and len(pair) == 2:
            key, value = pair
            if isinstance(key, str) and ENV_RE.match(key) and key not in RESERVED:
                env[key] = str(value)
    args = player_args(kind, defn.get("args"))
    program = os.path.join(app, defn["exec"])
    if kind == "dotnet":
        exe = next((d for d in DOTNETS if exists(d)), None)
        if not exe:
            die("this .NET app needs the .NET runtime, and it isn't installed")
        return exe, ["dotnet", program] + args, env
    return program, [program] + args, env


def main(argv):
    if len(argv) != 1 or not ID_RE.match(argv[0]):
        die("usage: svc-run <service-id>")
    creds = os.environ.get("CREDENTIALS_DIRECTORY") or ""
    try:
        with open(os.path.join(creds, "service.json"), encoding="utf-8") as f:
            defn = json.load(f)
    except (OSError, ValueError) as e:
        die("can't read the service's definition: %s" % e)
    if not isinstance(defn, dict) or defn.get("id") != argv[0] or not defn.get("exec"):
        die("the service's definition doesn't match")
    exe, args, env = build(defn, os.environ)
    try:
        os.chdir(APP)
    except OSError as e:
        die("its folder isn't there: %s" % e)
    try:
        os.execve(exe, args, env)
    except OSError as e:
        die("couldn't start %s: %s" % (defn["exec"], e.strerror or e))
