"""Which ports a server may list: not another server's, not one Quasar keeps for itself, not one in use."""
import re

from . import proc

SITES_FIRST, SITES_LAST = 41000, 41999       # Sites' app slots (quasar_sites/units.py)
DECK_BASE = 47300                            # Command Deck: 47300 + uid - 1000 (each account its own)
FIXED = {("tcp", 11434): "Quasar AI", ("tcp", 8081): "Sites", ("udp", 5353): "Quasar (network names)",
         ("udp", 1900): "Quasar (router discovery)"}


def deck_ports():
    import pwd
    out = set()
    try:
        for pw in pwd.getpwall():
            if 1000 <= pw.pw_uid <= 2999:
                out.add(DECK_BASE + pw.pw_uid - 1000)
    except OSError:
        pass
    return out


def reserved(proto, port):
    if proto == "tcp" and SITES_FIRST <= port <= SITES_LAST:
        return "Sites"
    if (proto, port) in FIXED:
        return FIXED[(proto, port)]
    if proto == "tcp" and port in deck_ports():
        return "Command Deck"
    return ""


def parse_ss(text):
    ports = set()
    for line in (text or "").splitlines():
        cols = line.split()
        if len(cols) >= 4:
            m = re.search(r":(\d+)$", cols[3])
            if m:
                ports.add(int(m.group(1)))
    return ports


def listening():
    """{(proto, port)} open on this PC right now (bound UDP sockets, listening TCP ones)."""
    out = set()
    for proto, flag in (("udp", "-Hlun"), ("tcp", "-Hltn")):
        p = proc.run(["ss", flag], check=False, timeout=10)
        out |= {(proto, port) for port in parse_ss(p.stdout)}
    return out


def conflict(proto, port, own_id, defs, busy):
    """Who already has proto/port, in words ("" = free). `busy` = listening(), minus the server's own
    ports when it's the one running."""
    for d in defs:
        if d.get("id") == own_id:
            continue
        for p in d.get("ports") or []:
            if p.get("proto") == proto and int(p.get("port", 0)) == port:
                return d.get("name") or d.get("id")
    r = reserved(proto, port)
    if r:
        return r
    if (proto, port) in busy:
        return "A program on this PC"
    return ""
