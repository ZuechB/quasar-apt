"""Rows for Quasar's own background services (marked "System" in the app) and for Sites' sites.

Phase 1 shows their status and logs and links to the page that manages each; they can't be removed
here, and only sites can be started and stopped (through Sites' own helper).
"""
import json
import os

from . import paths, proc, units

# key, unit, bus, name, description, icon, hue, link, unit whose being enabled means "installed and on"
SYSTEM = (
    {"key": "sys:sites-proxy", "unit": "quasar-sites-proxy.service", "user": False, "name": "Sites proxy",
     "desc": "Reverse proxy and HTTPS for Sites: it routes each address to its site.", "icon": "shield",
     "hue": "#8CF5B0", "link": {"app": "sites", "arg": "server"}},
    {"key": "sys:ollama", "unit": "quasar-ollama.service", "user": False, "name": "AI engine",
     "desc": "Local model server behind Quasar AI. It starts when Quasar AI needs it.", "icon": "orbit",
     "hue": "#7AE7FF", "link": {"app": "settings", "arg": "ai"}, "also": "quasar-ollama.socket"},
    {"key": "sys:docker", "unit": "docker.service", "user": False, "name": "Docker engine",
     "desc": "Runs the containers you manage in Containers. It starts when they need it.", "icon": "server",
     "hue": "#7AB8FF", "link": {"app": "containers", "arg": ""}, "also": "docker.socket"},
    {"key": "sys:firewall", "unit": "quasar-firewall.service", "user": False, "name": "Firewall",
     "desc": "Blocks connections nobody asked for. Its rules load before the network starts.", "icon": "shield",
     "hue": "#FFB86B", "link": {"app": "settings", "arg": "firewall"}},
    {"key": "sys:netguard", "unit": "quasar-netguard.service", "user": False, "name": "Network monitor",
     "desc": "Counts each app's traffic and asks before a new app takes connections.", "icon": "activity",
     "hue": "#B9A4FF", "link": {"app": "settings", "arg": "firewall"}},
    {"key": "sys:commanddeck", "unit": "quasar-commanddeck.service", "user": True, "name": "Command Deck",
     "desc": "Lets your phone control this PC on your home network.", "icon": "monitor", "hue": "#7AE7FF",
     "link": {"app": "settings", "arg": "commanddeck"}},
    {"key": "sys:vnc", "unit": "quasar-vnc.service", "user": True, "name": "Remote desktop",
     "desc": "Lets your other computers see and use this screen, at home or through your router's VPN.",
     "icon": "monitor", "hue": "#7AE7FF", "link": {"app": "settings", "arg": "remotedesktop"}},
)


def system_units(user=False):
    names = []
    for s in SYSTEM:
        if s["user"] == user:
            names.append(s["unit"])
            if s.get("also"):
                names.append(s["also"])
    return names


def system_rows(info, user_info):
    rows = []
    for s in SYSTEM:
        src = user_info if s["user"] else info
        i = src.get(s["unit"]) or {}
        if i.get("LoadState") != "loaded":
            continue
        st = units.status_of(i)
        also = src.get(s.get("also") or "") or {}
        enabled = st["enabled"] or also.get("UnitFileState") in ("enabled", "enabled-runtime")
        # Installed but never turned on (Command Deck off, no Docker): not a background service yet.
        if st["status"] == "stopped" and not enabled:
            continue
        rows.append({"key": s["key"], "id": s["key"][4:], "source": "system", "name": s["name"], "desc": s["desc"],
                     "kind": "service", "icon": s["icon"], "hue": s["hue"], "system": True, "unit": s["unit"],
                     "user": s["user"], "enabled": enabled, "status": st["status"], "since": st["since"],
                     "memory": st["memory"], "restarts": st["restarts"], "result": st["result"], "exit": st["exit"],
                     "restart": True, "cmd": "",
                     "onDemand": bool(s.get("also")),     # socket-activated: starts when something needs it
                     "link": s["link"], "actions": [], "server": None})
    return rows


SITE_STATUS = {"live": "running", "starting": "starting", "crashed": "failed", "stopped": "stopped", "new": "stopped"}


def site_rows():
    """Sites' sites as rows, from `sites-query state` (Sites' own read API, run as this user)."""
    if not os.access(paths.SITES_QUERY, os.X_OK):
        return []
    env = proc.base_env({k: os.environ[k] for k in ("HOME", "USER", "XDG_RUNTIME_DIR") if os.environ.get(k)})
    p = proc.run([paths.SITES_QUERY, "state"], check=False, timeout=30, env=env)
    res = None
    for line in (p.stdout or "").splitlines():
        try:
            o = json.loads(line)
        except ValueError:
            continue
        if isinstance(o, dict) and o.get("type") == "result":
            res = o
    if not res or not res.get("active"):
        return []
    rows = []
    for s in res.get("sites") or []:
        if not isinstance(s, dict) or not s.get("id"):
            continue
        app = s.get("kind") != "static"
        opts = s.get("options") or {}
        host = s.get("hostname") or ""
        desc = "Website %s" % host + (", on 127.0.0.1:%s." % s.get("port") if app and s.get("port") else
                                      ", served by the proxy.")
        slot = s.get("slot") if s.get("slot") in ("a", "b") else "a"
        rows.append({"key": "site:" + s["id"], "id": s["id"], "source": "site", "name": s.get("name") or s["id"],
                     "desc": desc, "kind": "service", "icon": "web", "hue": "#7AE7FF", "system": False,
                     "unit": "quasar-site-%s@%s.service" % (slot, s["id"]) if app else "", "user": False,
                     "enabled": bool(opts.get("boot", True)), "status": SITE_STATUS.get(s.get("state"), "stopped"),
                     "since": s.get("since"), "memory": s.get("memory"), "restarts": 0, "result": "",
                     "restart": bool(opts.get("crashRestart", True)), "cmd": s.get("run") or "",
                     "link": {"app": "sites", "arg": "site/" + s["id"]},
                     "actions": ["start", "stop", "restart"] if app else [], "server": None})
    return rows
