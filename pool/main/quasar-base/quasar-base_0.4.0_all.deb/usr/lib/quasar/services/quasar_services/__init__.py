"""Quasar Services: run programs other people connect to (game servers first) from this PC.

Each server runs as its own account (svc-<id>) in a sandboxed systemd unit, quasar-svc@<id>.service,
straight from the folder its owner picked. svc-prepare (root, ExecStartPre=+) pins that folder without
following any symlink and mounts it read-only at /srv/app inside the sandbox, idmapped so the owner's
files appear owned by the service's account. The server can bind only the ports its definition lists
(SocketBindAllow), and the firewall opens them to the home network or the internet through one managed
entry per server.

Entry points (all run with `python3 -I`):
  /usr/libexec/quasar/services-query        read-only answers for the app, the shell and Settings
                                            (runs as the user)
  /usr/libexec/quasar/quasar-services       routine changes to your own servers: start, stop, restart,
                                            start with the PC, arguments (pkexec, no password for
                                            administrators at the PC)
  /usr/libexec/quasar/quasar-services-admin add, remove, folder/ports/reach changes (pkexec, password
                                            every time)
  /usr/lib/quasar/services/svc-prepare      ExecStartPre=+ / ExecStopPost=+ of quasar-svc@.service
  /usr/lib/quasar/services/svc-run          ExecStart of quasar-svc@.service (inside the sandbox)
  /usr/bin/quasar-service                   the command line (over SSH too)

The wire protocol is linux/system/services/PROTOCOL.md. Standard library only, plus jeepney for
`services-query watch` (systemd's D-Bus signals).
"""
