"""services-query journal: what a service writes, from journald, live (the Services app's consoles).

  journal KEY… [-n N] [-f]     one or more services
  journal --all [-n N] [-f]    every service: system services, yours and your companies'

KEY                              reads
svc:<id>                         a server: quasar-svc@<id>.service and svc-prepare's quasar-svc-folder@<id>
site:<id>                        a site's two slots, quasar-site-a@<id> and quasar-site-b@<id>
sys:<name>                       one of Quasar's own services (system.SYSTEM; user units by --user-unit)
service:<unit>[,<unit>…]         system services
userservice:<unit>[,<unit>…]     your own user services (--user-unit matches your uid by itself)

One journalctl does both halves, the last N entries and then (-f) new ones, so nothing is lost or
repeated in between. Every ≤100 ms while there is something new:
  {"type":"lines","lines":[{"t":1763900000.25,"m":"…","lvl":"info|warn|err","unit":"x.service",
                            "src":"systemd"?, "user":true?, "acct":"Acme"?, "pid":1234?}, …]}
  {"type":"live"}                       once, when the backlog is out
  {"type":"notice","code":"no-access","message":"…"}
                                        this account can't read system services' logs (not in adm)
Levels: journald's priority; lines a program printed (stdout, where everything has one priority) also
by their words; systemd's own lines about the unit (src "systemd") by their exit code. --all keeps only
services' lines, and of other accounts only your companies' (acct = the company's name): an
administrator can read everyone's, but this view doesn't show other people's.

It ends on SIGTERM, when its stdin pipe closes, or (without -f) after the backlog; journalctl dies with
it (lifecycle.py).
"""
import json
import os
import queue
import re
import subprocess
import threading
import time

from . import lifecycle, paths, proc, system, units, validate
from .events import USAGE, ServicesError, emit

JOURNALCTL = paths.tool("QUASAR_JOURNALCTL", "journalctl")
COMPANIES = paths.p("/etc/quasar/companies.json")
MACHINE_ID = paths.p("/etc/machine-id")
JOURNAL_DIRS = (paths.p("/var/log/journal"), paths.p("/run/log/journal"))

UNIT_RE = re.compile(r"(?!-)[A-Za-z0-9:_.\\@-]{1,240}\.service\Z")
FIELDS = ("MESSAGE", "PRIORITY", "_PID", "_UID", "_COMM", "_TRANSPORT", "_SYSTEMD_UNIT", "_SYSTEMD_USER_UNIT",
          "UNIT", "USER_UNIT", "COREDUMP_UNIT", "COREDUMP_USER_UNIT", "COREDUMP_UID", "EXIT_CODE", "EXIT_STATUS")
DEFAULT_LINES, DEFAULT_ALL_LINES, MAX_LINES = 1000, 2000, 20000
FLUSH = 0.1                    # seconds between batches
MAX_BATCH = 2000               # lines in one batch (the rest goes in the next)
MAX_TEXT = 8000                # characters kept of one line
LIVE_QUIET, LIVE_LATEST = 0.15, 2.0

ANSI = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]|\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)|\x1b[@-Z\\-_]")
# Programs printing to stdout give every line one priority (Unity, .NET, Python, Node): their own words
# tell errors apart.
ERR_TEXT = re.compile(r"\w*Exception\b|\b\w*Error\b|\b(?:ERROR|FATAL|Fatal|CRITICAL|Traceback|panic)\b"
                      r"|\berror CS\d+|Segmentation fault|Crash!!!|^\s*(?:fail|crit|error):", re.M)
WARN_TEXT = re.compile(r"\b\w*Warning\b|\b(?:WARNING|WARN)\b|^\s*warn(?:ing)?:", re.M)
CLEAN_SIGNALS = {1, 2, 13, 15}     # HUP INT PIPE TERM: how a stop ends a program, not a crash
STATUS_TEXT = re.compile(r"\bstatus=(\d+)/")


# ---- keys -> units --------------------------------------------------------------------------------
def unit_name(raw):
    if not isinstance(raw, str) or not UNIT_RE.match(raw):
        raise ServicesError("%r isn't the name of a service." % str(raw)[:80], "invalid", USAGE)
    return raw


def resolve(keys):
    """[KEY…] -> ([system units], [your user units]), in order, each once."""
    sys_units, user_units = [], []

    def add(into, name):
        if name not in into:
            into.append(name)
    for key in keys:
        kind, _, rest = str(key).partition(":")
        if kind == "svc":
            for name in units.both(validate.service_id(rest)):
                add(sys_units, name)
        elif kind == "site":
            sid = validate.service_id(rest)          # Sites' ids follow the same rule
            add(sys_units, "quasar-site-a@%s.service" % sid)
            add(sys_units, "quasar-site-b@%s.service" % sid)
        elif kind == "sys":
            entry = next((s for s in system.SYSTEM if s["key"] == key), None)
            if not entry:
                raise ServicesError("%s isn't one of Quasar's services." % key[:80], "invalid", USAGE)
            add(user_units if entry["user"] else sys_units, entry["unit"])
        elif kind in ("service", "userservice"):
            for name in rest.split(","):
                add(user_units if kind == "userservice" else sys_units, unit_name(name))
        else:
            raise ServicesError("%s isn't a service." % str(key)[:80], "invalid", USAGE)
    if not sys_units and not user_units:
        raise ServicesError("Name a service.", "usage", USAGE)
    return sys_units, user_units


def build_argv(sys_units, user_units, lines, follow, every=False):
    argv = [JOURNALCTL, "--no-pager", "-q", "-o", "json", "--all", "--output-fields=" + ",".join(FIELDS),
            "-n", str(int(lines))]
    if follow:
        argv.append("-f")
    if not every:
        for name in sys_units:
            argv += ["-u", name]
        for name in user_units:
            argv.append("--user-unit=" + name)
    return argv


# ---- who can read what ----------------------------------------------------------------------------
def can_read_system_journal():
    """False when the system journal exists but this account can't read it (not in adm or
    systemd-journal: Debian gives adm read access through an ACL, so the files decide, not group names)."""
    try:
        with open(MACHINE_ID, encoding="ascii") as f:
            mid = f.read().strip()
    except OSError:
        return True
    if not re.fullmatch(r"[0-9a-f]{32}", mid):
        return True
    there = [os.path.join(d, mid, "system.journal") for d in JOURNAL_DIRS]
    there = [p for p in there if os.path.exists(p)]
    return not there or any(os.access(p, os.R_OK) for p in there)


def companies_of(uid):
    """{company account uid: company name} for the companies this account owns (the registry)."""
    try:
        with open(COMPANIES, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return {}
    out = {}
    for c in (data.get("companies") if isinstance(data, dict) else None) or []:
        try:
            if isinstance(c, dict) and int(c.get("owner", -1)) == uid:
                out[int(c["uid"])] = str(c.get("name") or c.get("id") or "")[:60]
        except (TypeError, ValueError, KeyError):
            continue
    return out


# ---- one record -> one line -----------------------------------------------------------------------
def _int(raw):
    try:
        return int(raw)
    except (TypeError, ValueError):
        return None


def text_of(raw):
    """MESSAGE as text: journald gives bytes it can't print as a list of numbers; colours are dropped."""
    if isinstance(raw, list):
        try:
            raw = bytes(int(b) & 0xFF for b in raw).decode("utf-8", "replace")
        except (TypeError, ValueError):
            return None
    if raw is None:
        return None
    text = ANSI.sub("", str(raw)).replace("\r", "")
    return text[:MAX_TEXT]


class Context:
    """Who is reading (their uid) and the companies they own ({uid: name})."""

    def __init__(self, uid, companies=None):
        self.uid = uid
        self.companies = companies or {}


def classify(rec, ctx, every=False):
    """One `journalctl -o json` record -> a line for the app, or None: no text; with `every`, not a
    service's, or another account's that isn't one of your companies."""
    if not isinstance(rec, dict):
        return None
    msg = text_of(rec.get("MESSAGE"))
    if not msg:
        return None
    ts = _int(rec.get("__REALTIME_TIMESTAMP"))
    prio = _int(rec.get("PRIORITY"))
    prio = 6 if prio is None else prio
    pid, uid = _int(rec.get("_PID")), _int(rec.get("_UID"))
    owner, user, src = uid, False, "app"
    if pid == 1 and rec.get("UNIT"):
        unit, src = rec["UNIT"], "systemd"                       # the system manager about the unit
    elif rec.get("USER_UNIT") and rec.get("_COMM") == "systemd":
        unit, user, src = rec["USER_UNIT"], True, "systemd"      # a user manager about one of its units
    elif rec.get("COREDUMP_UNIT"):
        unit, src = rec["COREDUMP_UNIT"], "systemd"              # systemd-coredump: it crashed
    elif rec.get("COREDUMP_USER_UNIT"):
        unit, user, src = rec["COREDUMP_USER_UNIT"], True, "systemd"
        owner = _int(rec.get("COREDUMP_UID"))
    elif rec.get("_SYSTEMD_USER_UNIT") and rec.get("_SYSTEMD_USER_UNIT") != "init.scope":
        unit, user = rec["_SYSTEMD_USER_UNIT"], True
    else:
        unit = rec.get("_SYSTEMD_UNIT") or ""
    unit = str(unit)
    if every and not unit.endswith(".service"):
        return None                                              # scopes, the kernel, audit
    acct = ""
    m = re.fullmatch(r"user@(\d+)\.service", unit)
    if user or m:                                                # someone's own services, or their manager
        if m:
            owner = int(m.group(1))
        if owner != ctx.uid:
            if owner in ctx.companies:
                acct = ctx.companies[owner] or "Company"
            elif every:
                return None                                      # another person's: not shown here
    lvl = "err" if prio <= 3 else "warn" if prio == 4 else "info"
    if src == "systemd":
        code, status = rec.get("EXIT_CODE"), _int(rec.get("EXIT_STATUS"))
        if code == "exited" and status not in (None, 0):
            lvl = "err"
        elif code == "dumped" or (code == "killed" and status is not None and status not in CLEAN_SIGNALS):
            lvl = "err"
        elif not code:
            st = STATUS_TEXT.search(msg)
            if (st and st.group(1) != "0") or "code=dumped" in msg:
                lvl = "err"
    elif lvl == "info" and rec.get("_TRANSPORT", "stdout") == "stdout":
        if ERR_TEXT.search(msg):
            lvl = "err"
        elif WARN_TEXT.search(msg):
            lvl = "warn"
    line = {"t": round(ts / 1e6, 3) if ts is not None else round(time.time(), 3), "m": msg, "lvl": lvl,
            "unit": unit}
    if src != "app":
        line["src"] = src
    if user:
        line["user"] = True
    if acct:
        line["acct"] = acct
    if pid is not None:
        line["pid"] = pid
    return line


# ---- the stream -----------------------------------------------------------------------------------
class Follower:
    """One journalctl; a thread parses its JSON lines into a queue."""

    def __init__(self, argv, convert):
        self.q = queue.Queue()
        self.done = threading.Event()
        self.last = time.monotonic()
        self._err = b""
        try:
            self.p = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                      env=proc.base_env(), preexec_fn=lifecycle.child_setup)
        except FileNotFoundError:
            raise ServicesError("journalctl isn't installed.", "missing-tool")
        self._convert = convert
        self._threads = [threading.Thread(target=self._read, daemon=True),
                         threading.Thread(target=self._read_err, daemon=True)]
        for t in self._threads:
            t.start()

    def _read(self):
        try:
            for raw in self.p.stdout:
                try:
                    rec = json.loads(raw)
                except ValueError:
                    continue
                line = self._convert(rec)
                if line is not None:
                    self.q.put(line)
                    self.last = time.monotonic()
        except (OSError, ValueError):
            pass
        self.done.set()

    def _read_err(self):
        try:
            for chunk in iter(lambda: self.p.stderr.read(4096), b""):
                self._err = (self._err + chunk)[-4096:]
        except (OSError, ValueError):
            pass

    def drain(self, limit=MAX_BATCH):
        out = []
        while len(out) < limit:
            try:
                out.append(self.q.get_nowait())
            except queue.Empty:
                break
        return out

    def stop(self):
        if self.p.poll() is None:
            self.p.terminate()
            try:
                self.p.wait(timeout=1)
            except subprocess.TimeoutExpired:
                self.p.kill()
                self.p.wait()
        for t in self._threads:                  # its pipes are at their end now
            t.join(timeout=1)
        for pipe in (self.p.stdout, self.p.stderr):
            try:
                pipe.close()
            except OSError:
                pass

    def error_text(self):
        return self._err.decode("utf-8", "replace").strip()


def stream(argv, convert, follow, stopper, out, on_live=None):
    """Run journalctl, hand batches to out(lines) at most every FLUSH seconds, call on_live() once the
    backlog is out. Returns at stop, or (without -f) once everything was read."""
    f = Follower(argv, convert)
    if follow:
        # Only a follower waits on stdin: a one-shot read ends by itself, and scripts often run it with stdin
        # already closed (QEMU's guest scripts did: `logs ID` printed nothing).
        stopper.watch_stdin()
    start = time.monotonic()
    live = False
    try:
        while True:
            batch = f.drain()
            if batch:
                out(batch)
            finished = f.done.is_set() and f.q.empty()
            if not live and f.q.empty():
                now = time.monotonic()
                if finished or now - max(start, f.last) >= LIVE_QUIET or now - start >= LIVE_LATEST:
                    live = True
                    if on_live:
                        on_live()
            if finished:
                rc = f.p.wait()
                if rc not in (0, None) and not stopper.event.is_set():
                    raise ServicesError("journalctl stopped.", "journal-failed", details=f.error_text())
                return 0
            if len(batch) >= MAX_BATCH:
                continue                             # more waiting: send it now
            if stopper.wait(FLUSH):
                return 0
    finally:
        f.stop()


def parse_args(args):
    every, follow, lines, keys = False, False, None, []
    it = iter(args)
    for a in it:
        if a == "--all":
            every = True
        elif a == "-f":
            follow = True
        elif a == "-n":
            lines = _int(next(it, None))
            if lines is None or not 0 <= lines <= MAX_LINES:           # 0: only what comes next (with -f)
                raise ServicesError("-n takes 0 to %d lines." % MAX_LINES, "usage", USAGE)
        elif a.startswith("-"):
            raise ServicesError("journal doesn't know %s." % a[:40], "usage", USAGE)
        else:
            keys.append(a)
    if every == bool(keys):
        raise ServicesError("Usage: services-query journal KEY… | --all [-n N] [-f]", "usage", USAGE)
    return every, follow, (DEFAULT_ALL_LINES if every else DEFAULT_LINES) if lines is None else lines, keys


NO_ACCESS_ONE = "Only an administrator can read this service's log. Sign in as one to see it."
NO_ACCESS_ALL = "Only an administrator can read system services' logs, so this shows only your own services."


def cmd_journal(args):
    every, follow, lines, keys = parse_args(args)
    sys_units, user_units = ([], []) if every else resolve(keys)
    stopper = lifecycle.Stopper().install()
    if (every or sys_units) and not can_read_system_journal():
        emit("notice", code="no-access", message=NO_ACCESS_ALL if every else NO_ACCESS_ONE)
        if not every and not user_units:
            emit("live")
            return 0
        sys_units = []
    uid = os.getuid()
    ctx = Context(uid, companies_of(uid))
    argv = build_argv(sys_units, user_units, lines, follow, every)
    return stream(argv, lambda rec: classify(rec, ctx, every), follow, stopper,
                  lambda batch: emit("lines", lines=batch), lambda: emit("live"))
