"""DNS checks for "point your name here": is the public name set, DNS only, and pointing at this network?

A small wire-format client asks systemd-resolved's stub (127.0.0.53) for A and AAAA records, which
answers with the whole CNAME chain, so the check can show "animalgo.zuech.io CNAME ha.zuech.io". The
public address comes from Cloudflare's trace page (https://1.1.1.1/cdn-cgi/trace), and only when the
owner presses Check: it's a network call they started.
"""
import ipaddress
import os
import socket
import struct
import urllib.request

STUB = ("127.0.0.53", 53)
A, CNAME, AAAA = 1, 5, 28
NXDOMAIN = 3
TRACE = "https://1.1.1.1/cdn-cgi/trace"

# Cloudflare's proxy ranges (cloudflare.com/ips): a name that resolves here is orange-clouded, and
# Cloudflare's proxy carries web traffic only, never a game's UDP.
CLOUDFLARE = [ipaddress.ip_network(n) for n in (
    "173.245.48.0/20", "103.21.244.0/22", "103.22.200.0/22", "103.31.4.0/22", "141.101.64.0/18",
    "108.162.192.0/18", "190.93.240.0/20", "188.114.96.0/20", "197.234.240.0/22", "198.41.128.0/17",
    "162.158.0.0/15", "104.16.0.0/13", "104.24.0.0/14", "172.64.0.0/13", "131.0.72.0/22",
    "2400:cb00::/32", "2606:4700::/32", "2803:f800::/32", "2405:b500::/32", "2405:8100::/32",
    "2a06:98c0::/29", "2c0f:f248::/32")]


def in_cloudflare(ip):
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        return False
    return any(addr in net for net in CLOUDFLARE if net.version == addr.version)


def build_query(name, qtype, qid):
    out = struct.pack(">HHHHHH", qid, 0x0100, 1, 0, 0, 0)
    for label in name.rstrip(".").split("."):
        raw = label.encode("idna") if label else b""
        if not raw or len(raw) > 63:
            raise ValueError("bad name")
        out += bytes([len(raw)]) + raw
    return out + b"\x00" + struct.pack(">HH", qtype, 1)


def _name(data, off, depth=0):
    labels = []
    while True:
        if off >= len(data) or depth > 20:
            raise ValueError("bad packet")
        n = data[off]
        if n & 0xC0 == 0xC0:
            ptr = struct.unpack(">H", data[off:off + 2])[0] & 0x3FFF
            rest, _ = _name(data, ptr, depth + 1)
            labels.append(rest)
            return ".".join(l for l in labels if l), off + 2
        if n == 0:
            return ".".join(labels), off + 1
        labels.append(data[off + 1:off + 1 + n].decode("ascii", "replace"))
        off += 1 + n


def parse(data, qid):
    """(rcode, [(name, type, value)]) from a reply."""
    if len(data) < 12:
        raise ValueError("short reply")
    rid, flags, qd, an, _, _ = struct.unpack(">HHHHHH", data[:12])
    if rid != qid:
        raise ValueError("wrong reply")
    off = 12
    for _ in range(qd):
        _, off = _name(data, off)
        off += 4
    answers = []
    for _ in range(an):
        name, off = _name(data, off)
        rtype, _cls, _ttl, rdlen = struct.unpack(">HHIH", data[off:off + 10])
        off += 10
        rdata = data[off:off + rdlen]
        if rtype == A and rdlen == 4:
            answers.append((name.lower(), A, socket.inet_ntop(socket.AF_INET, rdata)))
        elif rtype == AAAA and rdlen == 16:
            answers.append((name.lower(), AAAA, socket.inet_ntop(socket.AF_INET6, rdata)))
        elif rtype == CNAME:
            target, _ = _name(data, off)
            answers.append((name.lower(), CNAME, target.lower()))
        off += rdlen
    return flags & 0x000F, answers


def query(name, qtype, server=STUB, timeout=3.0):
    qid = struct.unpack(">H", os.urandom(2))[0]
    packet = build_query(name, qtype, qid)
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        s.settimeout(timeout)
        for _ in range(2):
            s.sendto(packet, server)
            try:
                data, _ = s.recvfrom(4096)
            except socket.timeout:
                continue
            return parse(data, qid)
    raise TimeoutError("no answer")


def resolve(name, server=STUB):
    chain, addresses, nx = [], [], False
    for qtype in (A, AAAA):
        rcode, answers = query(name, qtype, server)
        nx = nx or rcode == NXDOMAIN
        for owner, rtype, value in answers:
            if rtype == CNAME:
                line = "%s CNAME %s" % (owner, value)
                if line not in chain:
                    chain.append(line)
            elif value not in addresses:
                addresses.append(value)
    return {"chain": chain, "addresses": addresses, "nxdomain": nx and not addresses}


def public_ip(timeout=6):
    req = urllib.request.Request(TRACE, headers={"User-Agent": "quasar-services"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        text = r.read(4096).decode("ascii", "replace")
    for line in text.splitlines():
        if line.startswith("ip="):
            ipaddress.ip_address(line[3:].strip())
            return line[3:].strip()
    raise ValueError("no address in the reply")


def verdict(name, found, public=None):
    """The check's outcome in plain words."""
    out = {"name": name, "chain": found.get("chain") or [], "addresses": found.get("addresses") or [],
           "proxied": False, "publicIp": public}
    addrs = out["addresses"]
    if not addrs:
        out.update(verdict="missing", message="There's no record for %s yet. Add it in Cloudflare; a new record "
                                              "can take a few minutes to show up." % name)
    elif any(in_cloudflare(a) for a in addrs):
        out.update(verdict="proxied", proxied=True,
                   message="%s goes through Cloudflare's proxy (the orange cloud), which doesn't carry game "
                           "traffic. Set the record to DNS only." % name)
    elif public and public not in addrs:
        out.update(verdict="elsewhere",
                   message="%s points at %s, but this network's public address is %s. Check the record and your "
                           "dynamic DNS name." % (name, ", ".join(addrs), public))
    elif public:
        out.update(verdict="ok", message="%s points at this network (%s)." % (name, public))
    else:
        out.update(verdict="ok", message="%s points at %s." % (name, ", ".join(addrs)))
    return out


def check(name, want_public=False):
    try:
        found = resolve(name)
    except (OSError, ValueError, TimeoutError) as e:
        try:
            infos = socket.getaddrinfo(name, None, proto=socket.IPPROTO_UDP)
            found = {"chain": [], "addresses": sorted({i[4][0] for i in infos})}
        except OSError:
            return {"name": name, "chain": [], "addresses": [], "proxied": False, "publicIp": None,
                    "verdict": "error", "message": "Couldn't look %s up (%s)." % (name, e)}
    public = None
    if want_public:
        try:
            public = public_ip()
        except (OSError, ValueError) as e:
            out = verdict(name, found)
            out["message"] += " (Couldn't ask for this network's public address: %s.)" % e
            return out
    return verdict(name, found, public)
