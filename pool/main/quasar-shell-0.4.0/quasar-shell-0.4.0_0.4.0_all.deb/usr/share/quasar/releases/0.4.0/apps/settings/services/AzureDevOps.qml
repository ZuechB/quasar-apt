import QtQuick
import Quickshell
import Quickshell.Io
import Quasar
import Quasar.Services
import "../components/azure.js" as Az

// Settings > Companies & Profiles > Azure DevOps: build and deploy agents for one space (Personal or a
// company), through `pkexec quasar-azp-admin` (the administrator password every time). Specs and the
// personal access token go on stdin. The token isn't stored: once registered, an agent signs in with
// its own key. State comes from /var/lib/quasar-azp/agents.json (no secrets in it) and the units.
//   QUASAR_AZP_ADMIN=/path: a stand-in for the helper; QUASAR_AZP_AGENTS=/path: the summary file.
Scope {
    id: root
    property bool active: false
    property string space: "personal"
    property string spaceName: "Personal"
    property var agents: ({})
    property var states: ({})
    property string busy: ""
    property var form: null                   // { role } while the add dialog is open
    property string formError: ""
    property var ask: null                    // { key, role, title, message, button }
    property var sites: []                    // your Sites (sites-query state), for "May deploy …"
    signal notify(var banner)

    readonly property int uid: parseInt((Quickshell.env("XDG_RUNTIME_DIR") || "").split("/").pop()) || 0
    readonly property string exe: Quickshell.env("QUASAR_AZP_ADMIN") || ""
    readonly property string agentsFile: Quickshell.env("QUASAR_AZP_AGENTS") || "/var/lib/quasar-azp/agents.json"
    function admin(args) { return (exe ? [exe] : ["pkexec", "/usr/libexec/quasar/quasar-azp-admin"]).concat(args) }

    readonly property string sitesQuery: Quickshell.env("QUASAR_SITES_QUERY") || "/usr/libexec/quasar/sites-query"
    readonly property string sitesAdminExe: Quickshell.env("QUASAR_SITES_ADMIN") || ""
    readonly property var ctx: ({ space: space, spaceName: spaceName, uid: uid, states: states, busy: busy, sites: sites,
                                  icons: Icons, theme: Theme })
    readonly property var groups: Az.groups(agents, ctx)
    readonly property var hero: Az.hero(agents, ctx)
    function countFor(space) { return Az.count(agents, space, uid) }

    FileView {
        path: root.agentsFile
        watchChanges: true
        printErrors: false
        onFileChanged: reload()
        onLoaded: { try { root.agents = JSON.parse(text()) || {} } catch (e) { root.agents = {} } root.refreshStates() }
        onLoadFailed: root.agents = {}
    }
    onActiveChanged: if (active) { refreshStates(); sitesProc.running = true }
    Process {
        id: sitesProc
        command: [root.sitesQuery, "state"]
        stdout: StdioCollector {
            onStreamFinished: {
                const line = text.split("\n").map(l => { try { return JSON.parse(l) } catch (e) { return null } })
                                 .find(o => o && o.sites)
                root.sites = line ? line.sites : []
            }
        }
    }
    Timer { interval: 4000; running: root.active; repeat: true; onTriggered: root.refreshStates() }
    function refreshStates() {
        const units = Object.keys(agents).map(a => "quasar-azp@" + a + ".service")
        if (!units.length || stateProc.running) return
        stateProc.command = ["systemctl", "show", "-p", "Id", "-p", "ActiveState", "--"].concat(units)
        stateProc.running = true
    }
    Process {
        id: stateProc
        stdout: StdioCollector {
            onStreamFinished: {
                const out = {}
                let id = ""
                for (const l of text.split("\n")) {
                    if (l.startsWith("Id=")) id = l.slice(3).replace(/^quasar-azp@/, "").replace(/\.service$/, "")
                    else if (l.startsWith("ActiveState=") && id) out[id] = l.slice(12)
                }
                root.states = out
            }
        }
    }

    function toggle(key) { activate(key) }
    function activate(key) {
        if (busy !== "" || Platform.live) return
        const role = key.split(":").pop()
        const a = Az.agentFor(agents, ctx, role)
        if (key.startsWith("azp:add:")) { formError = ""; form = { role: role } }
        else if (key.startsWith("azp:rm:") && a)
            ask = { key: key, role: role, title: "Remove " + a.name + "?", button: "Remove",
                    message: "It stops and its account and files leave this PC. To also remove it from Azure DevOps, paste an access token below (optional)." }
        else if (key.startsWith("azp:site:")) {
            const s = sites.find(x => "azp:site:" + x.id === key)
            if (!s) return
            const mine = Az.accountFor(space, uid, "deploy")
            const spaces = Az.spacesOf(s.deployers, uid).filter(x => x !== space)
            if (!(s.deployers || []).includes(mine)) spaces.push(space)
            busy = key
            _done = null
            job.run((sitesAdminExe ? [sitesAdminExe] : ["pkexec", "/usr/libexec/quasar/quasar-sites-admin"])
                    .concat(["deployers", s.id], spaces))
        }
        else if ((key.startsWith("azp:lan:") || key.startsWith("azp:keep:")) && a) {
            const lan = key.startsWith("azp:lan:") ? !a.lan : !!a.lan
            const keep = key.startsWith("azp:keep:") ? !a.keep : !!a.keep
            run(key, ["set", space, role], JSON.stringify({ lan: lan, keep: keep }) + "\n")
        }
    }
    // The add dialog: { url, pool | environment+project, token, name } (shell.qml).
    function submit(spec) {
        const role = form ? form.role : "build"
        formError = ""
        run("azp:add:" + role, ["add", space, role], JSON.stringify(spec) + "\n", () => {
            root.form = null
            root.notify({ tone: "success", title: (role === "build" ? "Build" : "Deploy") + " agent added",
                          message: "It's online in Azure DevOps. Point a pipeline at it (" + (role === "build" ? "pool: " + spec.pool
                                   : "environment: " + spec.environment) + ")." })
        })
    }
    function confirm(token) {
        const a = ask
        ask = null
        if (!a) return
        run(a.key, ["remove", space, a.role], token ? JSON.stringify({ token: token }) + "\n" : "\n")
    }

    property var _done: null
    function run(key, args, input, done) {
        busy = key
        _done = done || null
        job.run(admin(args), undefined, input)
    }
    Cmd {
        id: job
        onFinished: (code) => {
            const key = root.busy, done = root._done
            root._done = null
            root.busy = ""
            if (code === 0) {
                if (done) done()
            } else if (code !== 126) {
                const err = job.details().split("\n").filter(l => l.startsWith("ERROR ")).map(l => l.slice(6)).pop()
                if (key.startsWith("azp:add:") && root.form) root.formError = err || "The agent couldn't be added."
                else root.notify({ tone: "error", title: err || "That didn't work", message: err ? "" : "Nothing was changed.",
                                   details: job.details() })
            }
            root.refreshStates()
            if (key.startsWith("azp:site:")) sitesProc.running = true
        }
    }
}
