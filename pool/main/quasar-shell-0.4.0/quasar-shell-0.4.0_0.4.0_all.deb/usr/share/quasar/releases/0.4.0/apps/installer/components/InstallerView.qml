import QtQuick
import Quasar

// "Install Quasar" wizard (apps/installer), sized for a 760x560 dialog window: step dots, one page
// at a time, footer buttons. Pure view — the wizard pages (welcome → region → account → disk)
// navigate here; the host sets page = installing / done / failed / installed and runs the
// backend. The host reads the form through config() when installRequested fires.
// Repair (from the welcome page): the installed Quasar systems on this computer's disks and their
// snapshots (repairDisks, from `quasar-snapshot repair-list`); picking one asks, then repairRequested.
// The host sets page = repairing / repaired / repairFailed.
Item {
    id: root

    // ---- data in --------------------------------------------------------------------------------
    // welcome | region | account | disk | installing | done | failed | installed
    // | repair | repairing | repaired | repairFailed
    property string page: "welcome"
    property var languages: [
        { key: "en_US.UTF-8", label: "English (US)" }, { key: "en_GB.UTF-8", label: "English (UK)" },
        { key: "es_ES.UTF-8", label: "Spanish" }, { key: "fr_FR.UTF-8", label: "French" },
        { key: "de_DE.UTF-8", label: "German" }, { key: "pt_BR.UTF-8", label: "Portuguese (Brazil)" },
        { key: "zh_CN.UTF-8", label: "Chinese (Simplified)" }, { key: "ja_JP.UTF-8", label: "Japanese" },
        { key: "ko_KR.UTF-8", label: "Korean" }, { key: "it_IT.UTF-8", label: "Italian" },
        { key: "nl_NL.UTF-8", label: "Dutch" }, { key: "ru_RU.UTF-8", label: "Russian" }
    ]
    property var zones: []                  // [{ key, label }] from timedatectl list-timezones
    property string systemTimezone: ""
    property var disks: []                  // [{ path, name, size, model, removable }]
    property bool disksLoading: false
    property string disksError: ""
    property real progress: 0               // 0..1
    property string stepName: ""
    property string stepMessage: ""
    property string errorMessage: ""
    property string errorDetails: ""
    property var repairDisks: []            // [{ device, size, model, version, snapshots: [...], old: [...] }]
    property bool repairLoading: false
    property string repairPhase: ""

    // ---- the form (read by the host through config()) --------------------------------------------
    property string languageCode: "en_US.UTF-8"
    property string timezone: ""            // empty = keep the system's
    readonly property string zone: timezone || systemTimezone || "UTC"
    property string username: ""
    property string password: ""
    property string confirm: ""
    property string machineName: "quasar"
    property bool autoLogin: true
    property string diskPath: ""

    // ---- signals out ------------------------------------------------------------------------------
    signal cancelled()
    signal installRequested()
    signal restartRequested()
    signal quitRequested()
    signal refreshDisks()
    signal repairOpened()                   // the Repair page opened: look for installed systems
    signal repairRequested(string device, var target)

    function config() {
        const lang = languages.find(l => l.key === languageCode)
        return {
            disk: diskPath, language: lang ? lang.label : "English (US)", languageCode: languageCode,
            timezone: zone, username: username, password: password, autoLogin: autoLogin,
            machineName: machineName
        }
    }

    // ---- navigation ---------------------------------------------------------------------------------
    readonly property var steps: ["welcome", "region", "account", "disk"]
    readonly property int stepIndex: steps.indexOf(page)
    readonly property bool inWizard: stepIndex >= 0
    readonly property var selectedDisk: disks.find(d => d.path === diskPath) || null
    property bool checkAccount: false       // show account errors once Continue was pressed

    // Same rules as the backend (src/AvaloniaShell.App/InstallBackend.cs).
    readonly property var accountProblem: {
        if (username.length < 3) return { field: "user", text: "Usernames need at least 3 characters." }
        if (username.length > 32 || !/^[a-z_][a-z0-9_-]*$/.test(username))
            return { field: "user", text: "Use lowercase letters, numbers, - and _ in the username, starting with a letter." }
        if (password.length < 4) return { field: "pass", text: "Passwords need at least 4 characters." }
        if (confirm !== password) return { field: "confirm", text: "The passwords don't match." }
        if (!/^[a-zA-Z][a-zA-Z0-9-]{0,62}$/.test(machineName))
            return { field: "host", text: "Computer names start with a letter and use only letters, numbers and hyphens." }
        return null
    }
    function fieldError(f) { return checkAccount && accountProblem !== null && accountProblem.field === f }

    function next() {
        if (page === "account") {
            checkAccount = true
            if (accountProblem) return
        }
        if (page === "disk") {
            if (selectedDisk) eraseDialog.open = true
            return
        }
        if (stepIndex >= 0 && stepIndex < steps.length - 1) page = steps[stepIndex + 1]
    }
    function back() { if (stepIndex > 0) page = steps[stepIndex - 1] }

    // One disk: pick it. Several: the person chooses (this erases a disk, so no guessing).
    onDisksChanged: {
        if (!disks.some(d => d.path === diskPath)) diskPath = disks.length === 1 ? disks[0].path : ""
    }

    function sizeLabel(s) { return (s || "").replace(/^([\d.,]+)([KMGTP])$/, "$1 $2B") }

    // Repair: every snapshot (and system kept from an earlier restore) on every disk, newest first.
    readonly property real repairNow: Date.now() / 1000
    readonly property var repairRows: {
        const out = []
        for (const d of repairDisks) {
            const disk = (d.model || "Disk") + "  ·  " + d.device + (d.version ? "  ·  Quasar " + d.version : "")
            for (const sn of (d.snapshots || []).slice().reverse())
                out.push({ device: d.device, target: sn.id, disk: disk, label: SnapKit.words(sn), sub: SnapKit.detail(sn, repairNow),
                           when: SnapKit.when(sn.created, repairNow), glyph: sn.reason === "manual" ? Icons.pin : Icons.layers })
            for (const o of (d.old || []).slice().reverse())
                out.push({ device: d.device, target: o.name, disk: disk, label: "The system as it was before a restore",
                           sub: SnapKit.when(o.created, repairNow), when: SnapKit.when(o.created, repairNow), glyph: Icons.restore })
        }
        return out
    }
    property var repairPick: null
    function diskName(d) { return d ? (d.model || "Disk " + d.name) : "" }

    // ---- shared bits --------------------------------------------------------------------------------
    component PageTitle: Column {
        property string title: ""
        property string sub: ""
        property bool centered: false
        width: parent ? parent.width : 520
        spacing: 6
        Text {
            width: parent.width
            text: parent.title
            horizontalAlignment: parent.centered ? Text.AlignHCenter : Text.AlignLeft
            wrapMode: Text.Wrap
            font.family: Theme.fontDisplay; font.pixelSize: 24; font.weight: Font.Medium; font.letterSpacing: -0.4
            color: Theme.text
        }
        Text {
            width: parent.width
            visible: parent.sub !== ""
            text: parent.sub
            horizontalAlignment: parent.centered ? Text.AlignHCenter : Text.AlignLeft
            wrapMode: Text.Wrap
            lineHeight: 1.2
            font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
            color: Theme.textMuted
        }
    }
    component FieldLabel: Text {
        font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5); font.weight: Font.Medium
        color: Theme.textMuted
    }
    // Round badge for the result pages (done / failed / installed).
    component ResultBadge: Rectangle {
        property color tone: Theme.accent
        property string glyph: Icons.check
        width: 76; height: 76; radius: 38
        anchors.horizontalCenter: parent ? parent.horizontalCenter : undefined
        color: Theme.alpha(tone, 0.12)
        border.width: 1
        border.color: Theme.alpha(tone, 0.35)
        QIcon { anchors.centerIn: parent; path: parent.glyph; size: 34; strokeWidth: 2.2; color: parent.tone }
    }

    // ---- step dots ------------------------------------------------------------------------------------
    Row {
        id: dots
        y: 24
        anchors.horizontalCenter: parent.horizontalCenter
        spacing: 6
        visible: root.inWizard
        Accessible.role: Accessible.StaticText
        Accessible.name: "Step " + (root.stepIndex + 1) + " of " + root.steps.length
        Repeater {
            model: root.steps.length
            Rectangle {
                required property int index
                height: 6; radius: 3
                width: index === root.stepIndex ? 22 : 6
                color: index <= root.stepIndex ? Theme.accent : Theme.white(0.16)
                opacity: index < root.stepIndex ? 0.55 : 1
                Behavior on width { NumberAnimation { duration: Motion.dur(Motion.pill); easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.spring } }
            }
        }
    }

    // ---- pages ----------------------------------------------------------------------------------------
    Item {
        id: pageArea
        anchors { top: parent.top; topMargin: root.inWizard ? 54 : 24; bottom: footer.top; left: parent.left; right: parent.right }
        Loader {
            id: pageLoader
            readonly property real colWidth: Math.min(520, pageArea.width - 48)
            anchors.fill: parent
            sourceComponent: root.page === "welcome" ? welcomePage
                           : root.page === "region" ? regionPage
                           : root.page === "account" ? accountPage
                           : root.page === "disk" ? diskPage
                           : root.page === "installing" ? installingPage
                           : root.page === "done" ? donePage
                           : root.page === "failed" ? failedPage
                           : root.page === "repair" ? repairPage
                           : root.page === "repairing" ? repairingPage
                           : root.page === "repaired" ? repairedPage
                           : root.page === "repairFailed" ? repairFailedPage
                           : installedPage
        }
    }

    Component {
        id: welcomePage
        Item {
            Column {
                anchors.centerIn: parent
                anchors.verticalCenterOffset: -6
                width: pageLoader.colWidth
                spacing: 0
                Appear {
                    order: 0
                    width: parent.width
                    Rectangle {
                        width: 88; height: 88; radius: 44
                        anchors.horizontalCenter: parent.horizontalCenter
                        color: Theme.accentTint
                        border.width: 1
                        border.color: Theme.alpha(Theme.accent, 0.3)
                        OrbitMark {
                            anchors.centerIn: parent
                            size: 50
                            strokeWidth: 2
                            spinning: Theme.ambientMotion
                        }
                    }
                }
                Item { width: 1; height: 22 }
                Appear {
                    order: 1
                    width: parent.width
                    PageTitle {
                        centered: true
                        title: "Install Quasar on this computer"
                        sub: "Quasar copies itself to this computer's disk, so it starts without the USB drive. It takes about ten minutes, and you can keep using Quasar while it works."
                    }
                }
                Item { width: 1; height: 22 }
                Appear {
                    order: 2
                    width: parent.width
                    Row {
                        anchors.horizontalCenter: parent.horizontalCenter
                        spacing: 8
                        Chip { text: "Create your account"; glyph: Icons.user }
                        Chip { text: "Pick a disk"; glyph: Icons.drive }
                        Chip { text: "Nothing leaves this PC"; glyph: Icons.shield; tone: Theme.mint; fill: Theme.alpha(Theme.mint, 0.1) }
                    }
                }
            }
        }
    }

    Component {
        id: regionPage
        Item {
            Column {
                x: (parent.width - width) / 2
                width: pageLoader.colWidth
                spacing: 20
                Appear {
                    order: 0
                    width: parent.width
                    PageTitle {
                        title: "Language and time zone"
                        sub: "Apps use this language when they have it, and the clock follows the time zone."
                    }
                }
                Appear {
                    order: 1
                    width: parent.width
                    SettingsGroup {
                        SettingsRow {
                            label: "Language"
                            glyph: Icons.globe
                            trailing: "chevron"
                            value: { const l = root.languages.find(x => x.key === root.languageCode); return l ? l.label : root.languageCode }
                            onActivated: langSheet.open = true
                        }
                        SettingsRow {
                            label: "Time zone"
                            glyph: Icons.clock
                            trailing: "chevron"
                            value: root.zone.replace(/_/g, " ")
                            onActivated: tzSheet.open = true
                        }
                    }
                }
            }
        }
    }

    Component {
        id: accountPage
        Item {
            Column {
                x: (parent.width - width) / 2
                width: pageLoader.colWidth
                spacing: 16
                Appear {
                    order: 0
                    width: parent.width
                    PageTitle {
                        title: "Create your account"
                        sub: "You sign in with it, and it's how you approve changes to the system."
                    }
                }
                Appear {
                    order: 1
                    width: parent.width
                    Column {
                        width: parent.width
                        spacing: 12
                        Column {
                            width: parent.width
                            spacing: 6
                            FieldLabel { text: "Username" }
                            TextField {
                                id: userField
                                width: parent.width
                                glyph: Icons.user
                                placeholder: "e.g. alex"
                                text: root.username
                                error: root.fieldError("user")
                                inputItem.activeFocusOnTab: true
                                onEdited: (t) => root.username = t.toLowerCase().replace(/\s/g, "")
                                onAccepted: passField.focusInput()
                                Component.onCompleted: focusInput()
                            }
                        }
                        Row {
                            width: parent.width
                            spacing: 12
                            Column {
                                width: (parent.width - 12) / 2
                                spacing: 6
                                FieldLabel { text: "Password" }
                                TextField {
                                    id: passField
                                    width: parent.width
                                    glyph: Icons.lock
                                    password: true
                                    text: root.password
                                    error: root.fieldError("pass")
                                    inputItem.activeFocusOnTab: true
                                    onEdited: (t) => root.password = t
                                    onAccepted: confirmField.focusInput()
                                }
                            }
                            Column {
                                width: (parent.width - 12) / 2
                                spacing: 6
                                FieldLabel { text: "Confirm password" }
                                TextField {
                                    id: confirmField
                                    width: parent.width
                                    password: true
                                    text: root.confirm
                                    error: root.fieldError("confirm")
                                    inputItem.activeFocusOnTab: true
                                    onEdited: (t) => root.confirm = t
                                    onAccepted: hostField.focusInput()
                                }
                            }
                        }
                        Column {
                            width: parent.width
                            spacing: 6
                            FieldLabel { text: "Computer name" }
                            TextField {
                                id: hostField
                                width: parent.width
                                glyph: Icons.monitor
                                placeholder: "quasar"
                                text: root.machineName
                                error: root.fieldError("host")
                                inputItem.activeFocusOnTab: true
                                onEdited: (t) => root.machineName = t.replace(/\s/g, "-")
                                onAccepted: root.next()
                            }
                        }
                    }
                }
                Appear {
                    order: 2
                    width: parent.width
                    Item {
                        width: parent.width
                        height: Math.max(autoSwitch.height, autoText.implicitHeight)
                        QSwitch {
                            id: autoSwitch
                            anchors.verticalCenter: parent.verticalCenter
                            checked: root.autoLogin
                            accessibleName: "Sign in automatically"
                            onToggled: root.autoLogin = !root.autoLogin
                        }
                        Column {
                            id: autoText
                            anchors { left: autoSwitch.right; leftMargin: 14; right: parent.right; verticalCenter: parent.verticalCenter }
                            spacing: 2
                            Text {
                                text: "Sign in automatically"
                                font.family: Theme.fontUi; font.pixelSize: 14; font.weight: Font.Medium
                                color: Theme.text
                            }
                            Text {
                                width: parent.width
                                text: "Skip the password at startup. You'll still need it to install apps and change system settings."
                                wrapMode: Text.Wrap
                                font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
                                color: Theme.textDim
                            }
                        }
                    }
                }
                Text {
                    width: parent.width
                    visible: root.checkAccount && root.accountProblem !== null
                    text: root.accountProblem ? root.accountProblem.text : ""
                    wrapMode: Text.Wrap
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
                    color: Theme.danger
                    Accessible.role: Accessible.AlertMessage
                    Accessible.name: text
                }
            }
        }
    }

    Component {
        id: diskPage
        Item {
            Column {
                x: (parent.width - width) / 2
                width: pageLoader.colWidth
                spacing: 18
                Appear {
                    order: 0
                    width: parent.width
                    PageTitle {
                        title: "Choose where to install"
                        sub: "Quasar takes the whole disk."
                    }
                }

                // Looking…
                Row {
                    visible: root.disksLoading && root.disks.length === 0
                    spacing: 10
                    Spinner { anchors.verticalCenter: parent.verticalCenter; size: 16 }
                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        text: "Looking for disks…"
                        font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
                        color: Theme.textMuted
                    }
                }

                // Nothing to install to
                Rectangle {
                    visible: !root.disksLoading && root.disks.length === 0
                    width: parent.width
                    height: emptyCol.implicitHeight + 36
                    radius: 16
                    color: Theme.white(0.035)
                    border.width: 1
                    border.color: Theme.white(0.06)
                    Column {
                        id: emptyCol
                        x: 18; y: 18
                        width: parent.width - 36
                        spacing: 6
                        Text {
                            text: root.disksError !== "" ? "Quasar couldn't look for disks" : "No disk to install to"
                            font.family: Theme.fontUi; font.pixelSize: 14; font.weight: Font.DemiBold
                            color: Theme.text
                        }
                        Text {
                            width: parent.width
                            text: root.disksError !== "" ? root.disksError
                                  : "Connect a drive (or add a virtual disk to this VM), then look again. The USB drive Quasar is running from isn't listed."
                            wrapMode: Text.Wrap
                            font.family: Theme.fontUi; font.pointSize: Theme.pt(13)
                            color: Theme.textDim
                        }
                        Item { width: 1; height: 6 }
                        Button { text: "Look again"; glyph: Icons.refresh; variant: "soft"; size: 34; onClicked: root.refreshDisks() }
                    }
                }

                // The disks
                ListView {
                    id: diskList
                    visible: root.disks.length > 0
                    width: parent.width
                    height: Math.min(contentHeight, 212)
                    spacing: 8
                    clip: true
                    boundsBehavior: Flickable.StopAtBounds
                    model: root.disks
                    delegate: Appear {
                        id: diskWrap
                        required property var modelData
                        required property int index
                        readonly property bool picked: root.diskPath === modelData.path
                        order: index + 1
                        width: diskList.width
                        Pressable {
                            width: parent.width
                            height: 64
                            kind: "plain"
                            radius: 14
                            color: diskWrap.picked ? Theme.accentTint : Theme.white(0.035)
                            hoverColor: diskWrap.picked ? Theme.accentTint : Theme.white(0.06)
                            borderColor: diskWrap.picked ? Theme.accentLine : Theme.white(0.07)
                            accessibleName: root.diskName(diskWrap.modelData) + ", " + root.sizeLabel(diskWrap.modelData.size) + (diskWrap.picked ? ", selected" : "")
                            onClicked: root.diskPath = diskWrap.modelData.path
                            Rectangle {
                                id: radio
                                x: 16
                                anchors.verticalCenter: parent.verticalCenter
                                width: 18; height: 18; radius: 9
                                color: "transparent"
                                border.width: 2
                                border.color: diskWrap.picked ? Theme.accent : Theme.white(0.3)
                                Rectangle {
                                    anchors.centerIn: parent
                                    width: 8; height: 8; radius: 4
                                    color: Theme.accent
                                    visible: diskWrap.picked
                                }
                            }
                            Rectangle {
                                id: driveTile
                                anchors { left: radio.right; leftMargin: 14; verticalCenter: parent.verticalCenter }
                                width: 38; height: 38; radius: 11
                                color: Theme.white(0.05)
                                QIcon { anchors.centerIn: parent; path: Icons.drive; size: 18; strokeWidth: 1.9; color: diskWrap.picked ? Theme.accent : Theme.text3 }
                            }
                            Column {
                                anchors { left: driveTile.right; leftMargin: 14; right: sizeText.left; rightMargin: 12; verticalCenter: parent.verticalCenter }
                                spacing: 2
                                Text {
                                    width: parent.width
                                    text: root.diskName(diskWrap.modelData)
                                    elide: Text.ElideRight
                                    font.family: Theme.fontUi; font.pixelSize: 14; font.weight: Font.Medium
                                    color: Theme.text
                                }
                                Text {
                                    width: parent.width
                                    text: diskWrap.modelData.path + (diskWrap.modelData.removable ? " · Removable" : "")
                                    elide: Text.ElideRight
                                    font.family: Theme.fontMono; font.pointSize: Theme.pt(11.5)
                                    color: Theme.textDim
                                }
                            }
                            Text {
                                id: sizeText
                                anchors { right: parent.right; rightMargin: 18; verticalCenter: parent.verticalCenter }
                                text: root.sizeLabel(diskWrap.modelData.size)
                                font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5); font.weight: Font.DemiBold
                                color: Theme.text2
                            }
                        }
                    }
                }

                Banner {
                    visible: root.selectedDisk !== null
                    width: parent.width
                    tone: "warning"
                    title: "Everything on " + root.diskName(root.selectedDisk) + " will be erased"
                    message: "Back up anything you want to keep before you continue."
                }
            }
        }
    }

    Component {
        id: installingPage
        Item {
            Column {
                anchors.centerIn: parent
                anchors.verticalCenterOffset: 6
                width: pageLoader.colWidth
                spacing: 0
                Item {
                    width: 112; height: 112
                    anchors.horizontalCenter: parent.horizontalCenter
                    ProgressRing {
                        anchors.centerIn: parent
                        size: 112
                        thickness: 6
                        value: root.progress
                    }
                    Text {
                        anchors.centerIn: parent
                        text: Math.round(root.progress * 100) + "%"
                        font.family: Theme.fontDisplay; font.pixelSize: 26; font.weight: Font.Medium
                        color: Theme.text
                    }
                }
                Item { width: 1; height: 26 }
                Text {
                    width: parent.width
                    text: root.stepName !== "" ? root.stepName : "Installing"
                    horizontalAlignment: Text.AlignHCenter
                    font.family: Theme.fontDisplay; font.pixelSize: 22; font.weight: Font.Medium
                    color: Theme.text
                }
                Item { width: 1; height: 8 }
                Text {
                    width: parent.width
                    height: 2 * Math.ceil(fontInfo.pixelSize * 1.35)
                    text: root.stepMessage
                    horizontalAlignment: Text.AlignHCenter
                    wrapMode: Text.Wrap
                    maximumLineCount: 2
                    elide: Text.ElideRight
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
                    color: Theme.text3
                }
                Item { width: 1; height: 18 }
                Text {
                    width: parent.width
                    text: "Keep the computer on and plugged in. You can use Quasar in the meantime."
                    horizontalAlignment: Text.AlignHCenter
                    wrapMode: Text.Wrap
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
                    color: Theme.textDim
                }
            }
        }
    }

    Component {
        id: donePage
        Item {
            Column {
                anchors.centerIn: parent
                width: pageLoader.colWidth
                spacing: 22
                Appear { order: 0; width: parent.width; ResultBadge { tone: Theme.mint; glyph: Icons.check } }
                Appear {
                    order: 1
                    width: parent.width
                    PageTitle {
                        centered: true
                        title: "Quasar is installed"
                        sub: "Restart to start using it. When the screen goes dark, remove the USB drive so the computer starts from its own disk."
                    }
                }
            }
        }
    }

    Component {
        id: failedPage
        Item {
            Column {
                anchors.centerIn: parent
                width: pageLoader.colWidth
                spacing: 20
                Appear { order: 0; width: parent.width; ResultBadge { tone: Theme.danger; glyph: Icons.alert } }
                Appear {
                    order: 1
                    width: parent.width
                    PageTitle {
                        centered: true
                        title: "The installation didn't finish"
                        sub: "The disk you picked may be partly written. Try again, or pick another disk."
                    }
                }
                Appear {
                    order: 2
                    width: parent.width
                    Banner {
                        width: parent.width
                        tone: "error"
                        title: "What went wrong"
                        message: root.errorMessage !== "" ? root.errorMessage : "The installer stopped unexpectedly."
                        details: root.errorDetails
                    }
                }
            }
        }
    }

    Component {
        id: repairPage
        Item {
            Column {
                x: (parent.width - width) / 2
                width: pageLoader.colWidth
                spacing: 16
                Appear {
                    order: 0
                    width: parent.width
                    PageTitle {
                        title: "Repair an installed PC"
                        sub: "If Quasar on this computer doesn't start any more, restore its system as it was in a snapshot. Its files, accounts and sites stay as they are."
                    }
                }
                Row {
                    visible: root.repairLoading
                    spacing: 10
                    Spinner { size: 18; anchors.verticalCenter: parent.verticalCenter }
                    Text {
                        text: "Looking for Quasar on this computer's disks…"
                        font.family: Theme.fontUi; font.pointSize: Theme.pt(13)
                        color: Theme.textDim
                        anchors.verticalCenter: parent.verticalCenter
                    }
                }
                Rectangle {
                    visible: !root.repairLoading && root.repairRows.length === 0
                    width: parent.width
                    height: noneCol.implicitHeight + 36
                    radius: 16
                    color: Theme.white(0.035)
                    border.width: 1
                    border.color: Theme.white(0.06)
                    Column {
                        id: noneCol
                        x: 18; y: 18
                        width: parent.width - 36
                        spacing: 6
                        Text {
                            text: "No snapshots found"
                            font.family: Theme.fontUi; font.pixelSize: 14; font.weight: Font.DemiBold
                            color: Theme.text
                        }
                        Text {
                            width: parent.width
                            text: "None of this computer's disks has Quasar with snapshots on it. Quasar installed before snapshots existed (on ext4) can't be repaired this way."
                            wrapMode: Text.Wrap
                            font.family: Theme.fontUi; font.pointSize: Theme.pt(13)
                            color: Theme.textDim
                        }
                        Item { width: 1; height: 6 }
                        Button { text: "Look again"; glyph: Icons.refresh; variant: "soft"; size: 34; onClicked: root.repairOpened() }
                    }
                }
                ListView {
                    id: repairList
                    visible: root.repairRows.length > 0
                    width: parent.width
                    height: Math.min(contentHeight, 268)
                    spacing: 8
                    clip: true
                    boundsBehavior: Flickable.StopAtBounds
                    model: root.repairRows
                    delegate: Appear {
                        id: snapWrap
                        required property var modelData
                        required property int index
                        order: Math.min(index + 1, 6)
                        width: repairList.width
                        Pressable {
                            width: parent.width
                            height: 60
                            kind: "plain"
                            radius: 14
                            color: Theme.white(0.035)
                            hoverColor: Theme.white(0.06)
                            borderColor: Theme.white(0.07)
                            accessibleName: snapWrap.modelData.label + ", " + snapWrap.modelData.sub
                            onClicked: { root.repairPick = snapWrap.modelData; repairDialog.open = true }
                            Rectangle {
                                id: snapTile
                                x: 14
                                anchors.verticalCenter: parent.verticalCenter
                                width: 36; height: 36; radius: 10
                                color: Theme.white(0.05)
                                QIcon { anchors.centerIn: parent; path: snapWrap.modelData.glyph; size: 17; strokeWidth: 1.9; color: Theme.text3 }
                            }
                            Column {
                                anchors { left: snapTile.right; leftMargin: 14; right: chev.left; rightMargin: 12; verticalCenter: parent.verticalCenter }
                                spacing: 2
                                Text {
                                    width: parent.width
                                    text: snapWrap.modelData.label
                                    elide: Text.ElideRight
                                    textFormat: Text.PlainText
                                    font.family: Theme.fontUi; font.pixelSize: 14; font.weight: Font.Medium
                                    color: Theme.text
                                }
                                Text {
                                    width: parent.width
                                    text: snapWrap.modelData.sub + (root.repairDisks.length > 1 ? "  ·  " + snapWrap.modelData.device : "")
                                    elide: Text.ElideRight
                                    font.family: Theme.fontUi; font.pointSize: Theme.pt(12)
                                    color: Theme.textDim
                                }
                            }
                            QIcon {
                                id: chev
                                anchors { right: parent.right; rightMargin: 16; verticalCenter: parent.verticalCenter }
                                path: Icons.fwd; size: 15; strokeWidth: 2; color: Theme.textMuted
                            }
                        }
                    }
                }
            }
        }
    }

    Component {
        id: repairingPage
        Item {
            Column {
                anchors.centerIn: parent
                width: pageLoader.colWidth
                spacing: 18
                Spinner { size: 44; anchors.horizontalCenter: parent.horizontalCenter }
                PageTitle {
                    centered: true
                    title: "Restoring the system…"
                    sub: root.repairPhase !== "" ? root.repairPhase : "This takes a minute. Keep the computer on."
                }
            }
        }
    }

    Component {
        id: repairedPage
        Item {
            Column {
                anchors.centerIn: parent
                width: pageLoader.colWidth
                spacing: 22
                Appear { order: 0; width: parent.width; ResultBadge { tone: Theme.mint; glyph: Icons.check } }
                Appear {
                    order: 1
                    width: parent.width
                    PageTitle {
                        centered: true
                        title: "The system is restored"
                        sub: "Restart, and remove the USB drive when the screen goes dark. The system from before the restore is kept for three starts, so this can be undone in Settings › Storage › Snapshots."
                    }
                }
            }
        }
    }

    Component {
        id: repairFailedPage
        Item {
            Column {
                anchors.centerIn: parent
                width: pageLoader.colWidth
                spacing: 20
                Appear { order: 0; width: parent.width; ResultBadge { tone: Theme.danger; glyph: Icons.alert } }
                Appear {
                    order: 1
                    width: parent.width
                    PageTitle {
                        centered: true
                        title: "The restore didn't work"
                        sub: "The installed system was left as it was. Try another snapshot, or reinstall Quasar."
                    }
                }
                Appear {
                    order: 2
                    width: parent.width
                    Banner {
                        width: parent.width
                        tone: "error"
                        title: "What went wrong"
                        message: root.errorMessage !== "" ? root.errorMessage : "The restore stopped unexpectedly."
                        details: root.errorDetails
                    }
                }
            }
        }
    }

    Component {
        id: installedPage
        Item {
            Column {
                anchors.centerIn: parent
                width: pageLoader.colWidth
                spacing: 22
                Appear { order: 0; width: parent.width; ResultBadge { tone: Theme.accent; glyph: Icons.check } }
                Appear {
                    order: 1
                    width: parent.width
                    PageTitle {
                        centered: true
                        title: "Quasar is already installed"
                        sub: "This computer runs Quasar from its own disk, so there's nothing to install. To put Quasar on another computer, start that computer from the Quasar USB drive."
                    }
                }
            }
        }
    }

    // ---- footer -----------------------------------------------------------------------------------------
    Item {
        id: footer
        anchors { left: parent.left; right: parent.right; bottom: parent.bottom }
        height: root.page === "installing" || root.page === "repairing" ? 24 : 72

        Rectangle {
            visible: root.page !== "installing" && root.page !== "repairing"
            width: parent.width; height: 1
            color: Theme.white(0.06)
        }
        Button {
            visible: root.stepIndex > 0 || root.page === "repair" || root.page === "repairFailed"
            x: 20
            anchors.verticalCenter: parent.verticalCenter
            text: "Back"
            glyph: Icons.back
            variant: "ghost"
            size: 38
            onClicked: root.page === "repair" ? root.page = "welcome" : root.page === "repairFailed" ? root.page = "repair" : root.back()
        }
        Button {
            visible: root.page === "welcome"
            x: 20
            anchors.verticalCenter: parent.verticalCenter
            text: "Repair an installed PC"
            glyph: Icons.restore
            variant: "ghost"
            size: 38
            onClicked: { root.page = "repair"; root.repairOpened() }
        }
        Row {
            visible: root.page !== "installing" && root.page !== "repairing"
            anchors { right: parent.right; rightMargin: 24; verticalCenter: parent.verticalCenter }
            spacing: 8
            // wizard
            Button {
                visible: root.inWizard
                text: "Cancel"; variant: "outline"; size: 38
                onClicked: root.cancelled()
            }
            Button {
                visible: root.inWizard
                text: root.page === "welcome" ? "Get started" : root.page === "disk" ? "Install" : "Continue"
                variant: "primary"; size: 38
                enabled: root.page !== "disk" || root.selectedDisk !== null
                onClicked: root.next()
            }
            // results
            Button {
                visible: root.page === "done"
                text: "Later"; variant: "outline"; size: 38
                onClicked: root.quitRequested()
            }
            Button {
                visible: root.page === "done"
                text: "Restart now"; glyph: Icons.power; variant: "primary"; size: 38
                onClicked: root.restartRequested()
            }
            Button {
                visible: root.page === "failed"
                text: "Close"; variant: "outline"; size: 38
                onClicked: root.quitRequested()
            }
            Button {
                visible: root.page === "failed"
                text: "Try again"; variant: "primary"; size: 38
                onClicked: { root.page = "disk"; root.refreshDisks() }
            }
            Button {
                visible: root.page === "installed"
                text: "Close"; variant: "primary"; size: 38
                onClicked: root.quitRequested()
            }
            Button {
                visible: root.page === "repair" || root.page === "repairFailed"
                text: "Close"; variant: "outline"; size: 38
                onClicked: root.quitRequested()
            }
            Button {
                visible: root.page === "repaired"
                text: "Later"; variant: "outline"; size: 38
                onClicked: root.quitRequested()
            }
            Button {
                visible: root.page === "repaired"
                text: "Restart now"; glyph: Icons.power; variant: "primary"; size: 38
                onClicked: root.restartRequested()
            }
        }
    }

    // ---- sheets ------------------------------------------------------------------------------------------
    ChoiceSheet {
        id: langSheet
        title: "Language"
        options: root.languages
        current: root.languageCode
        onChosen: (k) => { root.languageCode = k; open = false }
        onDismissed: open = false
    }
    ChoiceSheet {
        id: tzSheet
        title: "Time zone"
        options: root.zones.length ? root.zones : [{ key: root.zone, label: root.zone.replace(/_/g, " ") }]
        current: root.zone
        searchable: true
        onChosen: (k) => { root.timezone = k; open = false }
        onDismissed: open = false
    }
    Dialog {
        id: repairDialog
        title: root.repairPick ? (typeof root.repairPick.target === "string" ? "Go back to the system from before the restore?"
                                  : "Restore the system from " + root.repairPick.when.replace(/^[A-Z]/, c => c.toLowerCase()) + "?") : ""
        message: "The installed Quasar starts as it was then. Updates and programs installed since then are undone. "
                 + "Its files, accounts and passwords, Wi-Fi, sites, Docker and Flatpak apps stay as they are now, and today's system is kept, so this can be undone."
        onDismissed: open = false
        buttons: [
            Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: repairDialog.open = false },
            Button {
                text: "Restore"; variant: "primary"; size: 38
                onClicked: {
                    repairDialog.open = false
                    root.page = "repairing"
                    root.repairRequested(root.repairPick.device, root.repairPick.target)
                }
            }
        ]
    }
    Dialog {
        id: eraseDialog
        title: "Erase " + root.diskName(root.selectedDisk) + " and install Quasar?"
        message: "Everything on this disk (" + root.sizeLabel(root.selectedDisk ? root.selectedDisk.size : "") + ", "
                 + (root.selectedDisk ? root.selectedDisk.path : "") + ") is deleted, including other operating systems. This can't be undone."
        onDismissed: open = false
        buttons: [
            Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: eraseDialog.open = false },
            Button {
                text: "Erase and install"; variant: "primary"; tone: Theme.danger; size: 38
                onClicked: { eraseDialog.open = false; root.page = "installing"; root.installRequested() }
            }
        ]
    }
}
