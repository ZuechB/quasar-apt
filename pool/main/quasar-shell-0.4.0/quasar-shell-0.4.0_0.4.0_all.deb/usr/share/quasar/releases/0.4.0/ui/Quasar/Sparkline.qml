import QtQuick
import QtQuick.Shapes

// A small line chart (template Sites › Requests per minute: 84×28). `values` are drawn left to right,
// scaled to the largest value (at least `floor`), 3px from the top and bottom. The Shape sits in a
// fixed-size Item: a Shape sizes itself to its path, which would flatten the line.
Item {
    id: root
    property var values: []
    property real floor: 10
    property color color: Theme.accent
    property real lineWidth: 1.8

    implicitWidth: 84
    implicitHeight: 28

    readonly property var _points: {
        const n = values ? values.length : 0, out = []
        if (n < 2 || width <= 0 || height <= 0) return out
        let max = floor
        for (let i = 0; i < n; i++) max = Math.max(max, Number(values[i]) || 0)
        for (let i = 0; i < n; i++)
            out.push(Qt.point(i / (n - 1) * width, height - 3 - (Number(values[i]) || 0) / max * (height - 6)))
        return out
    }

    Shape {
        anchors.fill: parent
        visible: root._points.length > 1
        preferredRendererType: Shape.CurveRenderer
        layer.enabled: Theme.softwareRender     // clips when scrolled away (see Theme.softwareRender)
        ShapePath {
            strokeColor: root.color
            strokeWidth: root.lineWidth
            fillColor: "transparent"
            capStyle: ShapePath.RoundCap
            joinStyle: ShapePath.RoundJoin
            PathPolyline { path: root._points }
        }
    }
}
