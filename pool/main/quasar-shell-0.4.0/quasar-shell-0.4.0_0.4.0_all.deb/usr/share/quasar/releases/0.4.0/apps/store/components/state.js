.pragma library

// What the Store shows for a catalog entry, worked out from the live maps instead of being copied into
// thousands of entries. Catalog entries are never modified (apart from search keys, see search.js):
// a job's progress tick re-evaluates only the cards on screen.
//   inst = { flatpaks: { id: {version, installation, …} }, debs: { pkg: version },
//            tools: { tool: { versions, active } } }
//   jobs = { id: { state: "queued"|"busy", progress, phase, action, cancellable, cancelling } }

function isInstalled(a, inst) {
    if (!a || !inst) return false
    if (a.source === "flathub") return !!(inst.flatpaks && inst.flatpaks[a.id])
    if (a.source === "mise") {
        const t = inst.tools ? inst.tools[a.tool] : null
        return !!(t && t.versions && t.versions.length)
    }
    const p = a.pkgs || []
    // A page for a .deb file: installed means this file's version is installed (another version of
    // the same package is an update, or an older file that can't be installed).
    if (a.source === "debfile" && a.file) return p.length > 0 && !!inst.debs && inst.debs[p[0]] === a.version
    return p.length > 0 && !!inst.debs && p.every(x => !!inst.debs[x])
}

// Command-line tools have no window to open: their Open button opens a terminal.
function isCli(a) {
    return !!a && (a.source === "mise" || ((a.source === "debian" || a.source === "debfile") && !a.desktopId) || !!a.cli)
}

function stateOf(a, jobs, inst) {
    if (!a) return "get"
    const s = jobs ? jobs[a.id] : null
    return s ? s.state : (isInstalled(a, inst) ? "open" : "get")
}

function refOf(a) { return a.ref || ("app/" + a.id + "/x86_64/stable") }
function desktopIdOf(a) { return a.desktopId || a.id }

function iconUrl(a, dir) {
    if (!a || !a.icon) return ""
    return a.icon.indexOf(":") > 0 ? a.icon : "file://" + dir + "/" + a.icon
}

// Monogram for apps without an icon (anything not hand-picked; picks have their own glyph).
function letterOf(a) {
    if (!a || a.icon || a.pick) return ""
    const m = /[A-Za-z0-9]/.exec(a.name || "")
    return m ? m[0].toUpperCase() : "?"
}

// The small line under a card's blurb.
function sourceLine(a) {
    if (!a) return ""
    if (a.online) return "Flathub · newer than this Store"
    if (a.local) return "Installed"
    if (a.source === "debfile") return "From a file"
    if (a.pick) return "Quasar pick"
    if (a.source === "mise") return "Developer tool"
    if (a.source === "debian") return a.sourceLabel || "Debian"
    return a.verified ? "Flathub · verified developer" : "Flathub"
}

var UNRESTRICTED = { net: "Unrestricted", files: "Unrestricted", cam: "Unrestricted", mic: "Unrestricted", loc: "Unrestricted" }

// One full object for the detail page or the Discover hero (one at a time, so copying is fine):
// the entry, its live state, and the details loaded for it (description, licence, privacy label…).
function merged(a, jobs, inst, live, details, runtimes, dir) {
    if (!a) return null
    const s = jobs ? jobs[a.id] : null
    const d = details || {}
    const out = Object.assign({}, a, {
        state: s ? s.state : (isInstalled(a, inst) ? "open" : "get"),
        progress: s ? s.progress : 0,
        action: s ? s.action : "",
        phase: s ? s.phase : "",
        cancellable: s ? !!s.cancellable : false,
        cancelling: s ? !!s.cancelling : false,
        cli: isCli(a),
        blocked: !!a.needsDisk && !!live,
        runtimeSize: a.runtimeSize || (runtimes && a.runtime ? runtimes[a.runtime] || 0 : 0),
        // Packages opened from a file carry their own description and website (no details shard).
        desc: d.desc || a.desc || "", license: d.license || "", home: d.home || a.home || "", version: d.version || a.version || "",
        weak: d.weak || [], types: d.types || [],
        detailsLoaded: !!details,
        iconUrl: iconUrl(a, dir || ""),
        perms: a.source === "flathub" ? (details ? d.perms || null : null) : UNRESTRICTED
    })
    if (a.source === "mise") {
        const t = inst && inst.tools ? inst.tools[a.tool] : null
        out.versions = t ? t.versions : []
        out.activeVersion = t ? t.active : ""
    }
    return out
}
