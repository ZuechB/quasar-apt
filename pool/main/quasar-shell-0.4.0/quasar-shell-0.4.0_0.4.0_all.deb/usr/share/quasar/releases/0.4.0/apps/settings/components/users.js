// Settings > Users & Accounts: the page's rows. Pure, so the Settings app (services/UserAdmin.qml)
// and the design preview share it, and tools/test-accounts-js.py checks it.
//   ctx: { me: username, people: Accounts.people(...) [{ name, uid, fullName, display, admin }],
//          autologin: username or "", live, busy: row key, signedIn: [username], icons, theme }
// Keys: "u:<name>:<what>" for a person, plus "u:add", "autologin", "autologinUser", "vault".
.pragma library

function parseKey(key) {
    var m = /^u:([a-z_][a-z0-9_-]{0,31}):([a-z]+)$/.exec(key || "")
    return m ? { name: m[1], what: m[2] } : null
}

function sub(p) {
    return (p.admin ? "Administrator" : "Standard account") + "  ·  " + p.name
}

function find(people, name) {
    for (var i = 0; i < people.length; i++) if (people[i].name === name) return people[i]
    return null
}

function groups(ctx) {
    var icons = ctx.icons, t = ctx.theme, live = !!ctx.live, out = []
    var people = ctx.people || []
    var me = find(people, ctx.me) || { name: ctx.me, fullName: "", display: ctx.myName || ctx.me, admin: !!ctx.meAdmin }
    var signedIn = ctx.signedIn || []

    out.push({ label: "Your account", rows: [
        { key: "u:" + me.name + ":info", label: me.display, glyph: icons.user, trailing: "value", value: "You",
          sub: live ? "Live session" : sub(me) },
        { key: "u:" + me.name + ":name", label: "Your name", glyph: icons.pencil, trailing: live ? "value" : "chevron",
          value: me.fullName || (live ? "" : "Not set"), sub: live ? "" : "Shown when you sign in and lock the screen" },
        { key: "u:" + me.name + ":password", label: "Change your password", glyph: icons.key,
          trailing: live ? "value" : "chevron", value: "",
          sub: live ? "The live session has no password" : "Also protects your passwords and passkeys in Vault" }] })

    people.forEach(function (p) {
        if (p.name === me.name) return
        var on = signedIn.indexOf(p.name) >= 0
        var k = "u:" + p.name + ":"
        out.push({ label: p.display, rows: [
            { key: k + "type", label: "Account type", glyph: icons.shield, trailing: "chevron",
              value: p.admin ? "Administrator" : "Standard",
              sub: p.name + (on ? "  ·  signed in" : "") + (p.admin ? "  ·  can install apps and change the system" : "") },
            { key: k + "password", label: "Password", glyph: icons.key, trailing: "button", value: "Reset…",
              busy: ctx.busy === k + "password", sub: "Choose a new password if " + p.display + " forgot theirs" },
            { key: k + "remove", label: "Remove " + p.display, glyph: icons.trash, trailing: "button", value: "Remove…",
              busy: ctx.busy === k + "remove",
              sub: on ? p.display + " is signed in: they need to sign out first" : "Their account and files leave this PC" }] })
    })

    out.push({ label: "Manage", rows: [
        live ? { key: "u:add", label: "Add a user", glyph: icons.plus, trailing: "value", value: "",
                 sub: "Accounts are made when Quasar is installed" }
             : { key: "u:add", label: "Add a user", glyph: icons.plus, trailing: "chevron", busy: ctx.busy === "u:add",
                 sub: "Their own files, apps, settings and passwords" }] })

    var auto = find(people, ctx.autologin)
    var signRows = []
    if (live) {
        signRows.push({ key: "autologin", label: "Sign in automatically", glyph: icons.user, trailing: "value",
                        value: "On", sub: "The live session always starts signed in" })
    } else {
        signRows.push({ key: "autologin", label: "Sign in automatically", glyph: icons.user, trailing: "toggle",
                        checked: ctx.autologin !== "", busy: ctx.busy === "autologin",
                        sub: ctx.autologin !== ""
                             ? "Opens " + (auto ? auto.display : ctx.autologin) + "'s desktop at startup without a password. "
                               + "Vault stays locked until you unlock the screen or use it."
                             : "Everyone signs in with their password when the PC starts" })
        if (ctx.autologin !== "" && people.length > 1)
            signRows.push({ key: "autologinUser", label: "Sign in as", glyph: icons.users, trailing: "chevron",
                            value: auto ? auto.display : ctx.autologin })
        if (ctx.autologin !== "")
            signRows.push({ key: "autologinLock", label: "Lock the screen right away", glyph: icons.lock, trailing: "toggle",
                            checked: !!ctx.autologinLocked, busy: ctx.busy === "autologinLock",
                            sub: ctx.autologinLocked
                                 ? "The desktop starts, but this screen shows only the lock screen. Good for a server: its apps, "
                                   + "services and Remote desktop come back after a restart."
                                 : "Anyone at this PC can use the desktop after it starts" })
    }
    out.push({ label: "Sign-in", rows: signRows })

    out.push({ label: "Passwords", rows: [
        { key: "vault", label: "Passkeys and passwords", glyph: icons.lock, trailing: "chevron",
          sub: "Stored in Vault" }] })
    return out
}
