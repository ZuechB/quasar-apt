//@ pragma AppId quasar-containers
// Quasar Containers — Docker containers, images and volumes. Native Qt Quick app run by Quickshell
// (launched by /usr/bin/quasar-containers; the Store's Docker entry adds it to the launcher).
//   quasar-containers [containers|images|volumes]
// Talks to Docker through its command-line client (services/Docker.qml); root-only changes (start with
// the PC, start/stop the engine, access for an account) go through pkexec quasar-sys.
import QtQuick
import Quickshell
import Quickshell.Io
import Quasar
import Quasar.Services
import "components"
import "components/Format.js" as Format
import "services"

ShellRoot {
    id: app

    Binding { target: Theme; property: "accent"; value: Settings.accent }
    Binding { target: Theme; property: "reduceMotion"; value: Settings.reduceMotion }
    Binding { target: Theme; property: "softwareRender"; value: Platform.softwareScene }
    Binding { target: Theme; property: "profile"; value: Platform.softwareRender ? 0 : (Settings.profile >= 0 ? Settings.profile : 1) }

    property string page: "containers"
    property var banner: null
    function go(arg) {
        const a = (arg || "").trim()
        if (["containers", "images", "volumes"].indexOf(a) >= 0) { page = a; docker.closeLogs() }
    }
    Component.onCompleted: go(Quickshell.env("QUASAR_APP_ARGS"))

    Docker {
        id: docker
        active: win.visible
        onFailed: (err) => app.banner = err
        onNotice: (info) => app.banner = info
    }

    // ---- root-only changes ------------------------------------------------------------------------
    Privileged {
        id: sys
        helper: "quasar-sys"
        property string verb: ""
        onFinished: (code) => {
            const v = verb
            verb = ""
            if (code !== 0 && code !== 126)                              // 126: the password sheet was closed
                app.banner = { tone: "error", title: "That didn't work",
                               message: code === 127 ? "Your account isn't allowed to change this. Ask an administrator." : "Docker's service reported an error. The details below show what it said.",
                               details: details() }
            if (v === "docker-stop") {
                if (code === 0) docker.markStopped()
                else docker.probe()                                      // still running: show it again
            } else if (code !== 0 || v === "docker-autostart") {
                docker.checkAutostart()
            } else {
                docker.probe()                                           // docker-start, docker-access
            }
        }
    }
    function system(args) {
        if (sys.running) return
        banner = null
        sys.verb = args[0]
        sys.runHelper(args)
    }

    function engineAction(a) {
        if (docker.company && a !== "get" && a !== "retry") { companyEngineAction(a); return }
        if (a === "get") Quickshell.execDetached(["/usr/bin/quasar-store", "app:docker"])
        else if (a === "access") system(["docker-access"])
        else if (a === "autostart") system(["docker-autostart", docker.autostart ? "off" : "on"])
        else if (a === "retry") docker.probe()
        else if (a === "start") {
            // Stopped from here: its socket is still on, so any docker command starts it (no password).
            if (docker.stoppedByUser) docker.probe()
            else system(["docker-start"])
        } else if (a === "stop") {
            const n = docker.containers.filter(c => c.state === "running").length
            ask("Stop Docker?",
                (n ? n + (n === 1 ? " running container stops" : " running containers stop") + " too. " : "")
                + "Docker frees its memory and starts again the next time something uses it.",
                "Stop Docker", () => { if (sys.running) return; docker.beginStop(); app.system(["docker-stop"]) })
        }
    }
    // While a company is shown, its own rootless engine (company environments): no password needed,
    // it runs in the company's account and starts with the company.
    function companyEngineAction(a) {
        banner = null
        if (a === "companySetup") docker.companySetup()
        else if (a === "start") docker.companyEngine("start")
        else if (a === "autostart") docker.companyEngine(docker.autostart ? "disable" : "enable")
        else if (a === "stop") {
            const n = docker.containers.filter(c => c.state === "running").length
            ask("Stop Docker for " + docker.companyName + "?",
                (n ? n + (n === 1 ? " running container stops" : " running containers stop") + " too. " : "")
                + "It starts again when you start it here, or with " + docker.companyName + " if that's turned on.",
                "Stop Docker", () => { docker.beginStop(); docker.companyEngine("stop") })
        }
    }
    function containerAction(c, a) {
        banner = null
        if (a === "start") docker.start(c)
        else if (a === "stop") docker.stop(c)
        else if (a === "restart") docker.restart(c)
        else if (a === "logs") docker.openLogs(c)
        else if (a === "terminal") docker.terminal(c)
        else if (a === "remove")
            ask("Remove " + c.name + "?", (c.state === "running" ? "It's running: it stops and is removed. " : "") + "Its volumes and image stay.",
                "Remove", () => docker.remove(c))
    }
    function projectAction(p, a) {
        banner = null
        if (a === "remove")
            ask("Remove the " + p + " project?", "Its containers and networks are removed (docker compose down). Volumes and images stay, so its data comes back with it.",
                "Remove", () => docker.project(p, "remove"))
        else docker.project(p, a)
    }
    function imageAction(i, a) {
        banner = null
        if (a === "run") askRun(i)
        else if (a === "remove")
            ask("Remove " + (i.dangling ? "this unnamed image" : i.ref) + "?", "You can download it again any time.", "Remove", () => docker.removeImage(i))
    }
    function volumeAction(v, a) {
        banner = null
        if (a === "remove")
            ask("Delete the volume " + (v.anonymous ? v.name.slice(0, 12) + "…" : v.name) + "?", "The data in it is deleted for good.", "Delete", () => docker.removeVolume(v))
    }

    // ---- confirmations --------------------------------------------------------------------------
    property var pending: null                    // { title, message, button, run }
    function ask(title, message, button, run) { pending = { title: title, message: message, button: button, run: run } }

    // ---- clean up -------------------------------------------------------------------------------
    property bool cleanupOpen: false
    property var cleanSel: ({ containers: true, images: true, cache: true, volumes: false })

    // ---- run an image ---------------------------------------------------------------------------
    property var runFor: null
    function askRun(image) {
        runFor = image
        runName.text = ""; runHost.text = ""; runCont.text = ""; runRm.checked = false
        docker.exposedPort(image.ref, (p) => {
            if (!p || app.runFor !== image || runCont.text !== "") return
            runCont.text = String(p)
            runHost.text = String(p < 1024 ? 8000 + p : p)   // 80 -> 8080, 443 -> 8443, 5432 -> 5432
        })
    }
    readonly property bool runValid: {
        const port = (t) => /^\d{1,5}$/.test(t) && +t >= 1 && +t <= 65535
        const name = runName.text.trim()
        const h = runHost.text.trim(), c = runCont.text.trim()
        return (name === "" || /^[A-Za-z0-9][A-Za-z0-9_.-]*$/.test(name)) && ((h === "" && c === "") || (port(h) && port(c)))
    }

    // ---- window -----------------------------------------------------------------------------------
    AppWindow {
        id: win
        appName: "containers"
        title: "Containers"
        glyph: Icons.layers
        glyphColor: "#7AB8FF"

        ContainersView {
            anchors.fill: parent
            page: app.page
            engine: docker.engine
            version: docker.version
            engineError: docker.engineError
            autostart: docker.autostart
            sysBusy: sys.running
            company: docker.companyName
            containers: docker.containers
            images: docker.imageRows
            volumes: docker.volumeRows
            df: docker.df
            busy: docker.busy
            pulling: docker.pulling
            pullStatus: docker.pullStatus
            logs: docker.logs
            logText: docker.logText
            banner: app.banner
            onNavigate: (p) => { app.page = p; app.banner = null; docker.closeLogs() }
            onContainerAction: (c, a) => app.containerAction(c, a)
            onProjectAction: (p, a) => app.projectAction(p, a)
            onOpenPort: (p) => docker.openPort(p)
            onCloseLogs: docker.closeLogs()
            onPullImage: (ref) => { app.banner = null; docker.pull(ref) }
            onImageAction: (i, a) => app.imageAction(i, a)
            onVolumeAction: (v, a) => app.volumeAction(v, a)
            onRemoveUnusedVolumes: app.ask("Delete the unused volumes?", "Volumes no container uses are deleted, with the data in them.", "Delete",
                                           () => docker.cleanUp({ volumes: true }))
            onCleanUp: { app.cleanSel = { containers: true, images: true, cache: true, volumes: false }; app.cleanupOpen = true }
            onEngineAction: (a) => app.engineAction(a)
            onBannerAction: {
                const b = app.banner
                app.banner = null
                if (b && b.action) app.engineAction(b.action)
            }
        }

        Dialog {
            open: app.pending !== null
            title: app.pending ? app.pending.title : ""
            message: app.pending ? app.pending.message : ""
            onDismissed: app.pending = null
            buttons: [
                Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: app.pending = null },
                Button {
                    text: app.pending ? app.pending.button : ""
                    variant: "primary"; tone: Theme.danger; size: 38
                    onClicked: { const p = app.pending; app.pending = null; if (p && p.run) p.run() }
                }
            ]
        }

        Dialog {
            id: cleanup
            open: app.cleanupOpen
            title: "Clean up Docker"
            message: "Free disk space. Running containers, and the images and volumes they use, are never touched."
            cardWidth: 500
            onDismissed: app.cleanupOpen = false
            Column {
                width: parent.width
                spacing: 4
                Repeater {
                    model: [
                        ["containers", "Stopped containers", "containers"],
                        ["images", "Images no container uses", "images"],
                        ["cache", "Build cache", "cache"],
                        ["volumes", "Volumes no container uses (deletes their data)", "volumes"]
                    ]
                    Item {
                        required property var modelData
                        readonly property var stat: docker.df ? docker.df[modelData[2]] : null
                        width: parent.width
                        height: 44
                        QSwitch {
                            id: sw
                            anchors.verticalCenter: parent.verticalCenter
                            checked: !!app.cleanSel[modelData[0]]
                            accessibleName: modelData[1]
                            onToggled: { const s = Object.assign({}, app.cleanSel); s[modelData[0]] = !s[modelData[0]]; app.cleanSel = s }
                        }
                        Text {
                            anchors { left: sw.right; leftMargin: 12; right: reclaimText.left; rightMargin: 12; verticalCenter: parent.verticalCenter }
                            elide: Text.ElideRight
                            text: modelData[1]
                            font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
                            color: modelData[0] === "volumes" && sw.checked ? Theme.danger : Theme.text3
                        }
                        Text {
                            id: reclaimText
                            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                            text: parent.stat ? Format.bytes(parent.stat.reclaim) : ""
                            font.family: Theme.fontUi; font.pixelSize: 12; font.features: { "tnum": 1 }
                            color: Theme.textDim
                        }
                    }
                }
            }
            buttons: [
                Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: app.cleanupOpen = false },
                Button {
                    text: "Clean up"
                    enabled: Object.keys(app.cleanSel).some(k => app.cleanSel[k])
                    variant: "primary"; size: 38
                    onClicked: { app.cleanupOpen = false; app.banner = null; docker.cleanUp(app.cleanSel) }
                }
            ]
        }

        Dialog {
            open: app.runFor !== null
            title: app.runFor ? "Run " + app.runFor.ref : ""
            message: "Starts a new container from this image in the background."
            cardWidth: 480
            onDismissed: app.runFor = null
            Column {
                width: parent.width
                spacing: 10
                TextField { id: runName; width: parent.width; placeholder: "Name (optional)"; glyph: Icons.pen }
                Row {
                    width: parent.width
                    spacing: 8
                    TextField { id: runHost; width: (parent.width - 8) / 2; placeholder: "Port on this PC, e.g. 8080" }
                    TextField { id: runCont; width: (parent.width - 8) / 2; placeholder: "Port in the container, e.g. 80" }
                }
                Row {
                    spacing: 12
                    QSwitch { id: runRm; anchors.verticalCenter: parent.verticalCenter; accessibleName: "Remove the container when it stops"; onToggled: checked = !checked }
                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        text: "Remove the container when it stops"
                        font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
                        color: Theme.text3
                    }
                }
            }
            buttons: [
                Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: app.runFor = null },
                Button {
                    text: "Run"; glyph: Icons.play
                    enabled: app.runValid
                    variant: "primary"; size: 38
                    onClicked: {
                        const r = { ref: app.runFor.ref, name: runName.text.trim(), hostPort: runHost.text.trim(),
                                    containerPort: runCont.text.trim(), autoRemove: runRm.checked }
                        app.runFor = null
                        app.banner = null
                        app.page = "containers"
                        docker.runImage(r)
                    }
                }
            ]
        }
    }

    IpcHandler {
        target: "app"
        function open(arg: string): void { app.go(arg); win.visible = true }
    }
}
