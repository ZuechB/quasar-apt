import QtQuick
import QtQuick.Shapes

// Hero card (template Settings: Wi-Fi / About / AI / Profiles): radius 20, white .035 fill with a
// radial accent glow from the top-left corner, white .07 hairline, padding 18, 54px icon tile
// (radius 17), 17px/600 title, 13px #A4ABBD sub, trailing control slot.
Item {
    id: root
    property string glyph: ""
    property color iconBg: Theme.white(0.07)
    property color iconFg: Theme.text3
    property string title: ""
    property string sub: ""
    property color glow: Theme.accentTint
    property color fill: Theme.white(0.035)
    property color line: Theme.white(0.07)
    property real iconSize: 54
    default property alias trailing: trail.data

    implicitHeight: Math.max(iconSize, texts.implicitHeight) + 36
    width: parent ? parent.width : 600

    Shape {
        anchors.fill: parent
        layer.enabled: Theme.softwareRender      // clips when scrolled away (see Theme.softwareRender)
        ShapePath {
            strokeColor: root.line
            strokeWidth: 1
            fillGradient: RadialGradient {
                centerX: 0; centerY: 0; centerRadius: 340
                focalX: 0; focalY: 0
                GradientStop { position: 0.0; color: root.glow }
                GradientStop { position: 0.7; color: root.fill }
                GradientStop { position: 1.0; color: root.fill }
            }
            PathRectangle { x: 0.5; y: 0.5; width: root.width - 1; height: root.height - 1; radius: 20 }
        }
    }

    Rectangle {
        id: icon
        visible: root.glyph !== ""
        x: 18
        anchors.verticalCenter: parent.verticalCenter
        width: root.iconSize; height: root.iconSize; radius: Math.round(root.iconSize * 17 / 54)
        color: root.iconBg
        Behavior on color { ColorAnimation { duration: Motion.dur(300) } }
        QIcon { anchors.centerIn: parent; path: root.glyph; size: Math.round(root.iconSize * 26 / 54); strokeWidth: 1.9; color: root.iconFg }
    }
    Column {
        id: texts
        anchors { left: icon.visible ? icon.right : parent.left; leftMargin: icon.visible ? 16 : 18; right: trail.left; rightMargin: 16; verticalCenter: parent.verticalCenter }
        spacing: 3
        Text {
            width: parent.width
            text: root.title
            elide: Text.ElideRight
            font.family: Theme.fontUi; font.pixelSize: 17; font.weight: Font.DemiBold
            color: Theme.text
        }
        Text {
            visible: root.sub !== ""
            width: parent.width
            text: root.sub
            wrapMode: Text.Wrap
            font.family: Theme.fontUi; font.pixelSize: 13
            color: Theme.textMuted
        }
    }
    Item {
        id: trail
        anchors { right: parent.right; rightMargin: 18; verticalCenter: parent.verticalCenter }
        width: childrenRect.width
        height: childrenRect.height
    }
}
