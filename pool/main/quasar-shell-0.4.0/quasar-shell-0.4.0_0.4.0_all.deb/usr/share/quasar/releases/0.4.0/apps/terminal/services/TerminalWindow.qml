import QtQuick
import Quickshell
import Quasar
import Quasar.Services
import "../components"

// One Terminal window: the tab strip in the 44px title bar (template Terminal window: accent glyph,
// accent tint fading out at 55%), the tabs' terminals below, and the window-wide shortcuts.
// Programs in the terminal never see these keys:
//   Ctrl+Shift+T new tab · Ctrl+Shift+W close tab · Ctrl+Shift+N new window
//   Ctrl+Tab / Ctrl+PgDn next tab · Ctrl+Shift+Tab / Ctrl+PgUp previous · Alt+1…8 tab, Alt+9 last
//   Ctrl+= / Ctrl+- / Ctrl+0 text size · Ctrl+, settings · Ctrl+Shift+F find
// (Ctrl+Shift+C/V, Shift+Insert, Shift+PgUp/PgDn and Ctrl+Shift+↑/↓ are the Terminal item's own.)
AppWindow {
    id: win
    required property int windowId
    property var request: ({})              // the first tab: { cwd, program, args }
    property var cfg: ({})
    property Component engine: null
    signal closeWindow(int id)
    signal newWindow(var request)
    signal settingChanged(string key, var value)

    function addTab(r) { view.newTab(r) }

    appName: "terminal"
    title: view.currentTitle
    glyph: Icons.terminal
    glyphColor: Theme.accent
    titleTint: Theme.alpha(Theme.accent, 0.12)
    titleBarHeight: 44
    defaultSize: Qt.size(980, 600)
    background: "#06070B"
    quitOnClose: false
    closeBlocked: true                       // every close goes through the view (it may ask first)
    onCloseRequested: view.requestCloseWindow()

    titleItem: TerminalTabBar {
        model: view.tabs
        current: view.current
        active: win.focused
        onSelected: (i) => view.selectTab(i)
        onCloseClicked: (i) => view.closeTab(i, false)
        onNewTabClicked: view.newTab()
        onMoved: (from, to) => view.moveTab(from, to)
    }

    TerminalView {
        id: view
        anchors.fill: parent
        engine: win.engine
        cfg: win.cfg
        home: Quickshell.env("HOME") || ""
        windowActive: win.focused
        onLastTabClosed: win.closeWindow(win.windowId)
        onWindowCloseConfirmed: win.closeWindow(win.windowId)
        onOpenUrl: (url) => Quickshell.execDetached(["/usr/libexec/quasar/fileop", "open", url])   // the browser in its own scope
        onSettingChanged: (key, value) => win.settingChanged(key, value)
    }

    Component.onCompleted: view.newTab(win.request)

    Shortcut { sequences: ["Ctrl+Shift+T"]; onActivated: view.newTab() }
    Shortcut { sequences: ["Ctrl+Shift+W"]; onActivated: view.closeTab(view.current, false) }
    Shortcut { sequences: ["Ctrl+Shift+N"]; onActivated: win.newWindow({ cwd: view.currentCwd, window: true }) }
    Shortcut { sequences: ["Ctrl+Tab", "Ctrl+PgDown"]; onActivated: view.nextTab(1) }
    Shortcut { sequences: ["Ctrl+Shift+Tab", "Ctrl+Shift+Backtab", "Ctrl+Backtab", "Ctrl+PgUp"]; onActivated: view.nextTab(-1) }
    Shortcut { sequences: ["Ctrl+=", "Ctrl++", "Ctrl+Shift+="]; onActivated: view.zoom(1) }
    Shortcut { sequences: ["Ctrl+-"]; onActivated: view.zoom(-1) }
    Shortcut { sequences: ["Ctrl+0"]; onActivated: view.zoom(0) }
    Shortcut { sequences: ["Ctrl+,"]; onActivated: view.openSettings() }
    Shortcut { sequences: ["Ctrl+Shift+F"]; onActivated: view.find() }
    Instantiator {
        model: 9
        delegate: Shortcut {
            required property int index
            sequence: "Alt+" + (index + 1)
            onActivated: view.selectTab(index === 8 ? view.tabs.count - 1 : index)
        }
    }
}
