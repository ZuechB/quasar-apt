import QtQuick
import Quickshell
import Quickshell.Io
import Quasar.Services
import "DockerErrors.js" as DockerErrors

// Docker through its command-line client (JSON output) for the Containers app.
// Nothing runs while the window is hidden. While it's visible, one `docker events` process follows
// changes and only the lists that changed are read again (no polling). Opening the app starts the
// engine if it's idle (docker.socket starts it on first use), unless the user stopped it here.
// QUASAR_DOCKER swaps the docker binary (tools/fake-docker.sh for UI tests).
Scope {
    id: root
    readonly property string cli: Quickshell.env("QUASAR_DOCKER") || "docker"
    readonly property bool fake: !!Quickshell.env("QUASAR_DOCKER")
    // Company environments: while a company is shown, Docker is that company's own rootless engine.
    // Every docker command then runs inside its account (quasar-company exec), where the CLI's
    // "rootless" context points at that engine; its published ports are on the company's localhost.
    readonly property string company: fake ? "" : (Companies.inCompany ? Companies.active : "")
    readonly property string companyName: company ? Companies.current.name : ""
    function dk(args) { return company ? ["quasar-company", "exec", company, "--", "docker"].concat(args) : [cli].concat(args) }
    onCompanyChanged: {
        events.running = false
        closeLogs()
        containers = []; images = []; volumes = []; df = null
        stoppedByUser = false
        if (active) probe()
    }
    property bool active: false                 // the window is visible
    property string engine: "starting"          // missing | noAccess | stopped | starting | stopping | running | error
    property string version: ""
    property string engineError: ""
    property bool autostart: false
    property bool stoppedByUser: false
    property var containers: []                 // see _container()
    property var images: []                     // see _image()
    property var volumes: []                    // see _volume()
    property var df: null                       // { images|containers|volumes|cache: { count, size, reclaim }, used, reclaim } (bytes)
    property var busy: ({})                     // item key -> what is running on it
    property bool pulling: false
    property string pullStatus: ""
    property var logs: null                     // { id, name } while the logs pane is open
    property string logText: ""
    signal failed(var error)                    // { tone, title, message, details, actionText, action }
    signal notice(var info)                     // { tone, title, message }

    // Images and volumes a container uses (for "In use" and safe clean-up).
    readonly property var imageRows: images.map(i => Object.assign({}, i, { inUse: containers.some(c => c.image === i.ref || c.image === i.id
                                                                           || (i.tag === "latest" && c.image === i.repo)) }))
    readonly property var volumeRows: volumes.map(v => Object.assign({}, v, { inUse: containers.some(c => c.mounts.indexOf(v.name) >= 0) }))

    onActiveChanged: {
        if (active) { if (!stoppedByUser) probe() }
        else { events.running = false; closeLogs() }
    }

    // ---- engine --------------------------------------------------------------------------------
    function probe() {
        stoppedByUser = false
        if (engine !== "running") engine = "starting"
        probeProc.running = true
    }
    // Before `quasar-sys docker-stop`: no docker commands from here until it's done, since each one
    // would start the engine again through its socket. probe() undoes it if the stop doesn't happen.
    function beginStop() {
        stoppedByUser = true
        events.running = false
        closeLogs()
        engine = "stopping"
    }
    // After `quasar-sys docker-stop`: idle until the user starts it again (any docker command would).
    function markStopped() {
        stoppedByUser = true
        events.running = false
        closeLogs()
        engine = "stopped"
        containers = []; images = []; volumes = []; df = null
    }
    function checkAutostart() { if (!fake) autostartProc.running = true }

    Process {
        id: probeProc
        // Is the docker command there, and does the engine start with the PC? (no systemd with a fake)
        command: root.company
            // The company's engine: Docker installed, its rootless parts there, set up in this company?
            ? ["quasar-company", "exec", root.company, "--", "sh", "-c",
               "command -v docker >/dev/null 2>&1 || { echo MISSING; exit 0; }; "
               + "command -v dockerd-rootless-setuptool.sh >/dev/null 2>&1 || { echo NOROOTLESS; exit 0; }; "
               + "[ -f ~/.config/systemd/user/docker.service ] || { echo OFF; exit 0; }; "
               + "systemctl --user is-enabled docker.service 2>/dev/null; true"]
            : ["sh", "-c", "command -v \"$1\" >/dev/null 2>&1 || { echo MISSING; exit 0; }; [ -n \"$2\" ] || systemctl is-enabled docker.service 2>/dev/null; true",
               "sh", root.cli, root.fake ? "fake" : ""]
        stdout: StdioCollector {
            onStreamFinished: {
                const t = text.trim().split("\n").pop()
                if (t === "MISSING") { root.engine = "missing"; return }
                if (t === "NOROOTLESS") { root.engine = "companyNoRootless"; return }
                if (t === "OFF") { root.engine = "companyOff"; return }
                root.autostart = t === "enabled"
                versionCmd.run(root.dk(["version", "--format", "{{json .}}"]))
            }
        }
    }
    Process {
        id: autostartProc
        command: root.company ? ["quasar-company", "exec", root.company, "--", "systemctl", "--user", "is-enabled", "docker.service"]
                              : ["systemctl", "is-enabled", "docker.service"]
        stdout: StdioCollector { onStreamFinished: root.autostart = text.trim().split("\n").pop() === "enabled" }
    }
    Cmd {
        id: versionCmd
        onFinished: (code) => {
            const json = tail.find(l => l.startsWith("{"))
            let server = null
            try { const o = json ? JSON.parse(json) : null; server = o && o.Server ? o.Server : null } catch (e) { server = null }
            if (code === 0 && server) {
                root.version = server.Version || ""
                root.engineError = ""
                root.engine = "running"
                root.refresh(["containers", "images", "volumes", "df"])
                if (root.active) events.running = true
                return
            }
            const L = details().toLowerCase()
            if (/permission denied/.test(L)) root.engine = root.company ? "companyOff" : "noAccess"
            else if (/cannot connect to the docker daemon|is the docker daemon running|no such file or directory/.test(L)) root.engine = "stopped"
            else { root.engine = "error"; root.engineError = details() }
        }
    }

    // ---- lists ---------------------------------------------------------------------------------
    function refresh(kinds) {
        if (engine !== "running") return
        for (const k of kinds) {
            if (k === "containers") psProc.go()
            else if (k === "images") imagesProc.go()
            else if (k === "volumes") volumesProc.go()
            else if (k === "df") dfProc.go()
        }
    }

    // A docker command printing one JSON object per line; asked again while running = once more after.
    component JsonLines: Process {
        id: jl
        property bool again: false
        signal rows(var list)
        function go() { if (running) again = true; else running = true }
        onRunningChanged: if (!running && again) { again = false; running = true }
        stdout: StdioCollector {
            onStreamFinished: {
                const out = []
                for (const l of text.split("\n")) {
                    if (!l.startsWith("{")) continue
                    try { out.push(JSON.parse(l)) } catch (e) { }
                }
                jl.rows(out)
            }
        }
    }
    JsonLines {
        id: psProc
        command: root.dk(["ps", "-a", "--no-trunc", "--format", "{{json .}}"])
        onRows: (l) => root.containers = l.map(root._container).sort((a, b) => a.name.localeCompare(b.name))
    }
    JsonLines {
        id: imagesProc
        command: root.dk(["image", "ls", "--format", "{{json .}}"])
        onRows: (l) => root.images = l.map(root._image).sort((a, b) => a.dangling - b.dangling || a.ref.localeCompare(b.ref))
    }
    JsonLines {
        id: volumesProc
        command: root.dk(["volume", "ls", "--format", "{{json .}}"])
        onRows: (l) => root.volumes = l.map(root._volume).sort((a, b) => a.anonymous - b.anonymous || a.name.localeCompare(b.name))
    }
    JsonLines {
        id: dfProc
        command: root.dk(["system", "df", "--format", "{{json .}}"])
        onRows: (l) => root.df = root._df(l)
    }

    function _labels(s) {
        const out = {}
        for (const kv of String(s || "").split(",")) {
            const i = kv.indexOf("=")
            if (i > 0) out[kv.slice(0, i)] = kv.slice(i + 1)
        }
        return out
    }
    // "0.0.0.0:8080->80/tcp, [::]:8080->80/tcp, 5432/tcp" -> published ports (one per host port).
    function _ports(s) {
        const out = [], seen = {}
        const re = /(?:\d{1,3}(?:\.\d{1,3}){3}|\[?[0-9a-fA-F:]*\]?):(\d+)->(\d+)\/(tcp|udp|sctp)/g
        let m
        while ((m = re.exec(String(s || ""))) !== null) {
            const k = m[1] + "/" + m[3]
            if (seen[k]) continue
            seen[k] = true
            out.push({ host: +m[1], container: +m[2], proto: m[3] })
        }
        return out
    }
    function _container(o) {
        const labels = root._labels(o.Labels)
        return {
            id: o.ID || "", name: String(o.Names || "").split(",")[0], image: o.Image || "",
            state: String(o.State || "").toLowerCase(), status: o.Status || "",
            project: labels["com.docker.compose.project"] || "", service: labels["com.docker.compose.service"] || "",
            ports: root._ports(o.Ports), mounts: String(o.Mounts || "").split(",").filter(x => x)
        }
    }
    function _image(o) {
        const dangling = !o.Repository || o.Repository === "<none>"
        const tag = o.Tag && o.Tag !== "<none>" ? o.Tag : ""
        const id = String(o.ID || "").replace(/^sha256:/, "")
        return { id: id, repo: dangling ? "" : o.Repository, tag: tag, dangling: dangling,
                 ref: dangling ? id.slice(0, 12) : o.Repository + (tag ? ":" + tag : ""),
                 size: root._bytes(o.Size), created: o.CreatedSince || "" }
    }
    function _volume(o) {
        const labels = root._labels(o.Labels)
        return { name: o.Name || "", driver: o.Driver || "", project: labels["com.docker.compose.project"] || "",
                 anonymous: /^[0-9a-f]{64}$/.test(o.Name || "") ? 1 : 0 }
    }
    function _df(rows) {
        const key = { "Images": "images", "Containers": "containers", "Local Volumes": "volumes", "Build Cache": "cache" }
        const out = { used: 0, reclaim: 0 }
        for (const r of rows) {
            const k = key[r.Type]
            if (!k) continue
            out[k] = { count: +(r.TotalCount || 0), size: root._bytes(r.Size), reclaim: root._bytes(r.Reclaimable) }
            out.used += out[k].size
            out.reclaim += out[k].reclaim
        }
        return out
    }
    // Docker's sizes: "1.234GB", "12.5MB", "0B", "4.1kB" (decimal units).
    function _bytes(s) {
        const m = /^([\d.]+)\s*([kKMGTP]?B)/.exec(String(s || "").trim())
        if (!m) return 0
        return parseFloat(m[1]) * ({ B: 1, kB: 1e3, KB: 1e3, MB: 1e6, GB: 1e9, TB: 1e12, PB: 1e15 }[m[2]] || 1)
    }

    // ---- live updates --------------------------------------------------------------------------
    property var _dirty: ({})
    Process {
        id: events
        command: root.dk(["events", "--format", "{{json .}}", "--filter", "type=container", "--filter", "type=image", "--filter", "type=volume"])
        stdout: SplitParser {
            onRead: (line) => {
                let o
                try { o = JSON.parse(line) } catch (e) { return }
                if (/^exec_/.test(String(o.Action || ""))) return       // `docker exec` noise
                const kind = o.Type === "container" ? "containers" : o.Type === "image" ? "images" : o.Type === "volume" ? "volumes" : ""
                if (!kind) return
                const d = Object.assign({}, root._dirty); d[kind] = true; root._dirty = d
                dirtyTimer.start()
            }
        }
        // The engine went away (stopped elsewhere, or crashed): show it, don't restart it from here.
        onExited: if (root.active && root.engine === "running" && !root.stoppedByUser) {
            root.engine = "stopped"
            root.containers = []; root.images = []; root.volumes = []; root.df = null
        }
    }
    Timer {
        id: dirtyTimer
        interval: 300
        onTriggered: { const k = Object.keys(root._dirty); root._dirty = ({}); root.refresh(k.concat(["df"])) }
    }

    // ---- actions (one at a time; pulls run on their own) --------------------------------------------
    property var _queue: []
    function _setBusy(key, what) {
        const m = Object.assign({}, busy)
        if (what) m[key] = what; else delete m[key]
        busy = m
    }
    function act(key, what, args, kinds) {
        _queue = _queue.concat([{ key: key, what: what, args: args, kinds: kinds || ["containers"] }])
        _setBusy(key, what)
        _next()
    }
    function _next() {
        if (actCmd.job || !_queue.length) return
        const j = _queue[0]
        _queue = _queue.slice(1)
        actCmd.job = j
        actCmd.run(dk(j.args))
    }
    Cmd {
        id: actCmd
        property var job: null
        onFinished: (code) => {
            const j = job
            job = null
            root._setBusy(j.key, "")
            if (code !== 0) root.failed(DockerErrors.describe(details(), code, j.what))
            root.refresh(j.kinds.concat(["df"]))
            root._next()
        }
    }

    function start(c) { act(c.id, "Starting " + c.name, ["start", c.id]) }
    function stop(c) { act(c.id, "Stopping " + c.name, ["stop", c.id]) }
    function restart(c) { act(c.id, "Restarting " + c.name, ["restart", c.id]) }
    function remove(c) { act(c.id, "Removing " + c.name, ["rm", "-f", c.id]) }
    // Compose projects by name (works without the compose file: Compose finds them by label).
    function project(name, action) {
        const verb = { start: "start", stop: "stop", restart: "restart", remove: "down" }[action]
        if (!verb) return
        const what = { start: "Starting ", stop: "Stopping ", restart: "Restarting ", remove: "Removing " }[action] + name
        act("project:" + name, what, ["compose", "-p", name, verb], ["containers", "volumes"])
    }
    function removeImage(i) { act("image:" + i.id, "Removing " + i.ref, ["image", "rm", i.dangling ? i.id : i.ref], ["images"]) }
    function removeVolume(v) { act("volume:" + v.name, "Removing volume " + v.name, ["volume", "rm", v.name], ["volumes"]) }
    // run: { ref, name, hostPort, containerPort, autoRemove }
    function runImage(r) {
        const args = ["run", "-d"]
        if (r.autoRemove) args.push("--rm")
        if (r.name) args.push("--name", r.name)
        if (r.hostPort && r.containerPort) args.push("-p", r.hostPort + ":" + r.containerPort)
        args.push(r.ref)
        act("image:" + r.ref, "Starting " + r.ref, args, ["containers"])
    }
    // opts: { containers, images, cache, volumes } — what to clean up.
    function cleanUp(opts) {
        if (opts.containers) act("prune:containers", "Removing stopped containers", ["container", "prune", "-f"], ["containers"])
        if (opts.images) act("prune:images", "Removing unused images", ["image", "prune", "-a", "-f"], ["images"])
        if (opts.cache) act("prune:cache", "Clearing the build cache", ["builder", "prune", "-f"], [])
        if (opts.volumes) act("prune:volumes", "Removing unused volumes", ["volume", "prune", "-a", "-f"], ["volumes"])
    }

    function pull(ref) {
        if (pulling || !ref) return
        pulling = true
        pullStatus = "Starting the download…"
        pullCmd.ref = ref
        pullCmd.run(dk(["pull", ref]))
    }
    Cmd {
        id: pullCmd
        property string ref: ""
        onLine: (l) => { const t = l.trim(); if (t) root.pullStatus = t.replace(/^[0-9a-f]{12}: /, "") }
        onFinished: (code) => {
            root.pulling = false
            root.pullStatus = ""
            if (code !== 0) root.failed(DockerErrors.describe(details(), code, "Downloading " + ref))
            else root.notice({ tone: "success", title: ref + " is ready", message: "Run it from the list below." })
            root.refresh(["images", "df"])
        }
    }

    // ---- logs (one container at a time, last 2000 lines; the text updates at most ~8 times a second) --
    property var _logLines: []
    function openLogs(c) {
        closeLogs()
        logs = { id: c.id, name: c.name }
        logsProc.command = dk(["logs", "-f", "--tail", "500", c.id])
        logsProc.running = true
    }
    function closeLogs() {
        logsProc.running = false
        logs = null
        _logLines = []
        logText = ""
    }
    function _log(l) {
        _logLines.push(l)
        if (_logLines.length > 2000) _logLines.splice(0, _logLines.length - 2000)
        logFlush.start()
    }
    Process {
        id: logsProc
        stdout: SplitParser { onRead: (l) => root._log(l) }
        stderr: SplitParser { onRead: (l) => root._log(l) }
    }
    Timer { id: logFlush; interval: 120; onTriggered: root.logText = root._logLines.join("\n") }

    // The first TCP port an image says it listens on (EXPOSE), to suggest a port mapping in Run.
    function exposedPort(ref, cb) {
        inspectProc.cb = cb
        inspectProc.command = dk(["image", "inspect", "--format", "{{json .Config.ExposedPorts}}", ref])
        inspectProc.running = true
    }
    Process {
        id: inspectProc
        property var cb: null
        stdout: StdioCollector {
            onStreamFinished: {
                let port = 0
                try {
                    const o = JSON.parse(text.trim() || "null")
                    const k = o ? Object.keys(o).find(p => /\/tcp$/.test(p)) : null
                    if (k) port = parseInt(k)
                } catch (e) { port = 0 }
                const cb = inspectProc.cb
                inspectProc.cb = null
                if (cb) cb(port)
            }
        }
    }

    // ---- outside the app -------------------------------------------------------------------------
    // A shell inside the container, in a terminal window (bash if the image has it).
    function terminal(c) {
        const inner = "command -v bash >/dev/null 2>&1 && exec bash || exec sh"
        if (company) {                         // a terminal of the company, with its docker
            Quickshell.execDetached(["quasar-company", "run", company, "--", "sh", "-c",
                "footclient -N -T \"$1\" docker exec -it \"$2\" sh -c \"$3\" 2>/dev/null || foot -T \"$1\" docker exec -it \"$2\" sh -c \"$3\"",
                "sh", c.name + " (container)", c.id, inner])
            return
        }
        Quickshell.execDetached(["sh", "-c", "footclient -N -T \"$1\" \"$2\" exec -it \"$3\" sh -c \"$4\" 2>/dev/null || foot -T \"$1\" \"$2\" exec -it \"$3\" sh -c \"$4\"",
                                 "sh", c.name + " (container)", cli, c.id, inner])
    }
    // A company's published ports are on its own localhost: open them with its browser.
    function openPort(port) {
        const url = "http://localhost:" + port
        Quickshell.execDetached(company ? ["quasar-company", "run", company, "--", "xdg-open", url] : ["/usr/libexec/quasar/fileop", "open", url])
    }

    // ---- a company's own engine (company environments) -------------------------------------------
    // Turn on: Docker's rootless setup inside the company's account (its systemd user service, the
    // "rootless" CLI context, DOCKER_HOST for other tools). No password: it's the company's own account.
    // On the live USB a company's home is on the live overlay, where Docker's overlay storage can't
    // stack ("invalid argument"): use plain vfs storage there (slower, but works anywhere).
    readonly property string setupScript: "set -e\n"
        + "if [ \"$(stat -f -c %T \"$HOME\")\" = overlayfs ] && [ ! -f ~/.config/docker/daemon.json ]; then\n"
        + "  mkdir -p ~/.config/docker\n"
        + "  printf '{ \"features\": { \"containerd-snapshotter\": false }, \"storage-driver\": \"vfs\" }\\n' > ~/.config/docker/daemon.json\n"
        + "fi\n"
        + "dockerd-rootless-setuptool.sh install --force >&2\n"
        + "docker context use rootless >/dev/null 2>&1 || true\n"
        + "mkdir -p ~/.config/environment.d\n"
        + "printf 'DOCKER_HOST=unix://%s/docker.sock\\n' \"$XDG_RUNTIME_DIR\" > ~/.config/environment.d/50-quasar-docker.conf\n"
        + "systemctl --user enable docker.service >&2\n"
    function companySetup() {
        if (!company || setupCmd.running) return
        engine = "settingUp"
        setupCmd.run(["quasar-company", "exec", company, "--", "sh", "-c", setupScript])
    }
    Cmd {
        id: setupCmd
        onFinished: (code) => {
            if (code === 0) { root.probe(); return }
            root.engine = "error"
            root.engineError = details()
        }
    }
    // start | stop | enable | disable the company's engine (its systemd user service).
    function companyEngine(verb) {
        if (!company || companyCmd.running) return
        if (verb === "start") engine = "starting"
        companyCmd.verb = verb
        companyCmd.run(["quasar-company", "exec", company, "--", "systemctl", "--user", verb, "docker.service"])
    }
    Cmd {
        id: companyCmd
        property string verb: ""
        onFinished: (code) => {
            if (verb === "stop" && code === 0) root.markStopped()
            else if (verb === "enable" || verb === "disable") root.checkAutostart()
            else root.probe()
        }
    }
}
