.pragma library

// "1.2 GB", "340 MB", "12 kB", "0 B" (decimal units, like Docker).
function bytes(n) {
    n = +n || 0
    if (n >= 1e9) return (n / 1e9).toFixed(1) + " GB"
    if (n >= 1e6) return Math.round(n / 1e6) + " MB"
    if (n >= 1e3) return Math.round(n / 1e3) + " kB"
    return Math.round(n) + " B"
}

// Status dot colour of a container state.
function stateTone(state, theme) {
    return state === "running" ? theme.mint
         : state === "paused" || state === "restarting" || state === "removing" ? theme.amber
         : state === "dead" ? theme.danger : theme.textFaint
}
