import QtQuick
import Quickshell
import Quasar
import Quasar.Services
import "attribution.js" as Attr

// Command Deck, the shell's half: phones on the home network use this PC as a remote (deckd serves them;
// linux/session/commanddeck/PROTOCOL.md §2). The shell starts and stops deckd with the setting, tells it
// what the phones asked to see (only while one watches: an idle Command Deck costs nothing here) and runs
// what they ask for through the same functions the taskbar and launcher use.
Scope {
    id: root
    required property var apps          // services/Apps.qml
    required property var sys           // services/SystemControls.qml
    required property var media         // services/MediaKeys.qml
    required property var lock          // services/ScreenLock.qml
    property var desk: null             // services/CompanyDesk.qml
    property var restartGuard: null     // services/RestartGuard.qml: no restart in the middle of an install

    readonly property bool enabled: !!Settings.commandDeck && Settings.commandDeck.enabled === true
    property var phones: []             // [{ id, name, screen }] connected right now
    readonly property bool connected: phones.length > 0
    readonly property bool live: phones.some(p => p.screen)        // a phone sees the screen
    signal toast(var t)

    property var client: null
    property int backoff: 0
    property var watched: []
    readonly property Component _clientComponent: Component { DeckClient { } }

    // ---- deckd's life ----------------------------------------------------------------------------
    onEnabledChanged: apply()
    Component.onCompleted: apply()
    function apply() {
        Quickshell.execDetached(["systemctl", "--user", enabled ? "start" : "stop", "quasar-commanddeck.service"])
        backoff = 0
        if (enabled) connectTimer.restart()
        else { connectTimer.stop(); watched = []; phones = []; if (client) { client.destroy(); client = null } }
    }
    Timer {
        id: connectTimer
        interval: 500 + Math.min(root.backoff, 8) * 1500
        onTriggered: root.connectNow()
    }
    function connectNow() {
        if (!enabled || (client && !client.dead)) return
        if (client) client.destroy()
        const c = _clientComponent.createObject(root)
        client = c
        c.event.connect(onEvent)
        c.lost.connect(() => {
            if (client !== c) return
            watched = []; phones = []
            if (enabled) { backoff++; connectTimer.restart() }
        })
        c.request({ op: "hello", role: "shell" }, (r) => {
            if (client !== c) return
            if (r.ok) { backoff = 0; sendPrefs(); return }
            backoff++
            if (enabled) connectTimer.restart()
        })
    }
    function send(obj) { if (client && !client.dead) client.send(obj) }

    // What phones may do (Settings › Command Deck); deckd also reads it from settings.json when it starts.
    readonly property bool allowScreen: !Settings.commandDeck || Settings.commandDeck.screen !== false
    readonly property bool allowFiles: !Settings.commandDeck || Settings.commandDeck.files !== false
    onAllowScreenChanged: sendPrefs()
    onAllowFilesChanged: sendPrefs()
    function sendPrefs() { send({ op: "prefs", screen: allowScreen, files: allowFiles }) }

    function onEvent(e) {
        if (e.event === "watch") {
            watched = e.topics || []
            if (watched.indexOf("system") >= 0) sys.refresh()       // volume is only re-read on demand
            for (const t of watched) pending[t] = true
            pushTimer.restart()
        } else if (e.event === "call") run(e)
        else if (e.event === "phones") phones = e.phones || []
        else if (e.event === "toast") showToast(e)
    }

    // ---- what phones see -------------------------------------------------------------------------
    function watching(t) { return watched.indexOf(t) >= 0 }
    function deskInfo() {
        const id = Companies.active || ""
        const c = id ? Companies.byId(id) : null
        return { company: c && !c.personal ? id : "", name: c && !c.personal ? (c.name || id) : "Personal" }
    }
    function look(e) {
        const d = apps.decorate(e)
        return { icon: d.glyph ? "" : (e.icon || ""), glyph: d.glyph || "", hue: String(d.hue || ""), letter: d.letter || "" }
    }
    readonly property string appsJson: {
        if (!watching("apps")) return ""
        const pins = Settings.pins || []
        const list = apps.listed.map(e => Object.assign({ id: e.id, name: apps.decorate(e).name,
                                                          pinned: pins.indexOf(e.id) >= 0 }, look(e)))
        list.sort((a, b) => a.name.localeCompare(b.name))
        return JSON.stringify({ apps: list, desk: deskInfo() })
    }
    readonly property string windowsJson: {
        if (!watching("windows")) return ""
        const owners = desk ? desk.ownership : null
        const wins = apps.shown.filter(t => t && !t.parent).map(t => {
            const e = apps.entryFor(t.appId)
            const owner = owners ? (Attr.ownerOf(owners, t) || "") : ""
            const c = owner ? Companies.byId(owner) : null
            return Object.assign({ wid: apps.wid(t), app: e ? e.id : (t.appId || ""),
                                   name: e ? apps.decorate(e).name : (t.appId || "App"), title: t.title || "",
                                   focused: !!t.activated, minimized: !!t.minimized,
                                   company: c && !c.personal ? (c.name || owner) : "" },
                                 e ? look(e) : { icon: "", glyph: "", hue: apps.hueFor(t.appId || "?"),
                                                 letter: apps.initial(t.appId || "?") })
        })
        return JSON.stringify({ windows: wins })
    }
    readonly property string mediaJson: {
        if (!watching("media")) return ""
        const p = media.current
        if (!p) return JSON.stringify({ player: null })
        return JSON.stringify({ player: {
            name: p.identity || "", title: p.trackTitle || "", artist: p.trackArtist || "", album: p.trackAlbum || "",
            art: p.trackArtUrl || "", playing: !!p.isPlaying, canPlay: !!(p.canTogglePlaying || p.canPlay),
            canNext: !!p.canGoNext, canPrev: !!p.canGoPrevious, length: p.lengthSupported ? Math.round(p.length || 0) : 0 } })
    }
    readonly property string systemJson: {
        if (!watching("system")) return ""
        return JSON.stringify({ volume: Math.round(sys.volume), muted: !!sys.muted, locked: !!lock.locked,
                                desk: deskInfo() })
    }
    onAppsJsonChanged: schedule("apps")
    onWindowsJsonChanged: schedule("windows")
    onMediaJsonChanged: schedule("media")
    onSystemJsonChanged: schedule("system")

    property var pending: ({})
    function schedule(t) { if (watching(t)) { pending[t] = true; pushTimer.restart() } }
    Timer {
        id: pushTimer
        interval: 150
        onTriggered: {
            const due = root.pending
            root.pending = {}
            const json = { apps: root.appsJson, windows: root.windowsJson, media: root.mediaJson, system: root.systemJson }
            for (const t in due) if (json[t]) root.send({ op: "state", topic: t, data: JSON.parse(json[t]) })
        }
    }
    // The lock state matters at once (deckd refuses input while locked), never after a debounce.
    Connections {
        target: root.lock
        function onLockedChanged() { if (root.watching("system")) root.send({ op: "state", topic: "system", data: JSON.parse(root.systemJson) }) }
    }

    // ---- what phones ask for ---------------------------------------------------------------------
    readonly property var lockedOk: ["media", "volume", "mute", "power"]
    function run(e) {
        const a = e.args || {}
        let r = { ok: true }
        const fail = (code, error) => { r = { ok: false, code: code, error: error } }
        if (lock.locked && lockedOk.indexOf(e.op) < 0) fail("locked", "The PC is locked. Unlock it at the PC first.")
        else if (e.op === "launch") {
            if (!apps.listed.some(x => x.id === a.id)) fail("bad-args", "That app isn't on this PC.")
            else apps.launchId(a.id)
        } else if (e.op === "focus" || e.op === "minimize" || e.op === "close") {
            const t = apps.win(a.wid)
            if (!t) fail("gone", "That window is already closed.")
            else if (e.op === "focus") apps.focusWindow(t)
            else if (e.op === "minimize") t.minimized = true
            else t.close()
        } else if (e.op === "media") {
            const p = media.current
            if (!p) fail("no-player", "Nothing is playing.")
            else if (a.action === "play") { if (p.canPlay) p.play() }
            else if (typeof media[a.action] === "function") media[a.action]()
        } else if (e.op === "volume") sys.setVolume(Math.max(0, Math.min(100, Number(a.value) || 0)))
        else if (e.op === "mute") sys.setMuted(!!a.on)
        else if (e.op === "power") {
            const who = (e.device && e.device.name) || "A phone"
            const words = { sleep: "sleep", logout: "sign out", reboot: "restart", poweroff: "shut down" }
            if ((a.action === "reboot" || a.action === "poweroff") && restartGuard) {
                // Not while a driver or updates install (services/RestartGuard.qml): the reply waits for the check.
                restartGuard.request(a.action, (ok, reasons) => {
                    if (ok) toast({ title: who + " asked this PC to " + words[a.action], sub: "Command Deck", glyph: Icons.phone, hue: Theme.accent })
                    send(ok ? { op: "reply", cid: e.cid, ok: true }
                            : { op: "reply", cid: e.cid, ok: false, code: "busy",
                                error: reasons.join(", ") + ". Try again when it's done, or do it at the PC." })
                })
                return
            }
            if (a.action === "lock") sys.lock()
            else if (a.action === "sleep") sys.suspend()
            else if (a.action === "logout") sys.logout()
            else if (a.action === "reboot") sys.reboot()
            else if (a.action === "poweroff") sys.poweroff()
            else fail("bad-args", "That isn't something Command Deck can do.")
            if (r.ok && a.action !== "lock") toast({ title: who + " asked this PC to " + ({ sleep: "sleep", logout: "sign out", reboot: "restart", poweroff: "shut down" })[a.action], sub: "Command Deck", glyph: Icons.phone, hue: Theme.accent })
        } else fail("unknown-op", "That isn't something Command Deck can do.")
        send(Object.assign({ op: "reply", cid: e.cid }, r))
    }

    function showToast(e) {
        const t = { title: e.title || "Command Deck", sub: e.sub || "", glyph: e.kind === "file" ? Icons.download : Icons.phone,
                    hue: Theme.accent, settings: e.kind === "file" ? "" : "commanddeck" }
        if (e.kind === "file" && e.path) t.open = e.path
        toast(t)
    }

    // From the taskbar's phone icon.
    function stopScreen() { send({ op: "stopScreen" }) }
    function disconnect() { send({ op: "disconnect" }) }
}
