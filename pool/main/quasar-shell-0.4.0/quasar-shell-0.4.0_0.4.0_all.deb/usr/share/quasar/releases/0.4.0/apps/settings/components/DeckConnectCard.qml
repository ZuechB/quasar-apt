import QtQuick
import Quasar

// Settings › Command Deck: "Connect a phone" — the QR code a phone's camera opens, the same secret as six
// digits (an iPhone home-screen app types them), how long until it changes, and the address. Pure:
// SettingsView feeds it.
Item {
    id: root
    property string url: ""             // http://…/#p=… (empty: not ready)
    property string code: ""            // 6 digits
    property int secondsLeft: 60        // until the code changes
    property string address: ""         // http://192.168.1.5:47300
    property string pcName: "this PC"

    implicitHeight: card.height
    width: parent ? parent.width : 600

    Rectangle {
        id: card
        width: parent.width
        height: Math.max(qr.height, info.implicitHeight) + 40
        radius: 18
        color: Theme.white(0.035)
        border.width: 1
        border.color: Theme.white(0.07)

        QrCode {
            id: qr
            x: 20; y: 20
            width: 196; height: 196
            text: root.url
            radius: 14
            opacity: root.url ? 1 : 0
            Behavior on opacity { NumberAnimation { duration: Motion.dur(180) } }
        }
        Rectangle {          // while the first code is on its way
            anchors.fill: qr
            radius: 14
            visible: !root.url
            color: Theme.white(0.05)
            Spinner { anchors.centerIn: parent; size: 22 }
        }

        Column {
            id: info
            anchors { left: qr.right; leftMargin: 24; right: parent.right; rightMargin: 20; top: qr.top }
            spacing: 6

            Text {
                text: "Connect a phone"
                font.family: Theme.fontUi; font.pixelSize: 17; font.weight: Font.DemiBold
                color: Theme.text
            }
            Text {
                width: parent.width
                text: "Point your phone's camera at the code and tap the link. It opens Command Deck in the phone's browser. The phone has to be on the same network as this PC."
                wrapMode: Text.WordWrap
                font.family: Theme.fontUi; font.pixelSize: 13; lineHeight: 1.25
                color: Theme.text2
            }
            Item { width: 1; height: 8 }
            Text {
                text: "Or type this code on the phone"
                font.family: Theme.fontUi; font.pixelSize: 12
                color: Theme.textMuted
            }
            Row {
                spacing: 12
                Text {
                    id: digits
                    text: root.code.length === 6 ? root.code.slice(0, 3) + " " + root.code.slice(3) : "––– –––"
                    font.family: Theme.fontMono; font.pixelSize: 26; font.weight: Font.DemiBold
                    font.letterSpacing: 2
                    color: root.code ? Theme.text : Theme.textMuted
                }
                ProgressRing {
                    anchors.verticalCenter: digits.verticalCenter
                    visible: root.code !== ""
                    size: 18
                    value: root.secondsLeft / 60
                    color: root.secondsLeft <= 10 ? Theme.amber : Theme.accent
                    Behavior on value { NumberAnimation { duration: Motion.dur(900); easing.type: Easing.Linear } }
                }
            }
            Text {
                width: parent.width
                visible: root.address !== ""
                text: root.address
                elide: Text.ElideRight
                font.family: Theme.fontMono; font.pointSize: Theme.pt(11.5)
                color: Theme.textMuted
            }
        }
    }
}
