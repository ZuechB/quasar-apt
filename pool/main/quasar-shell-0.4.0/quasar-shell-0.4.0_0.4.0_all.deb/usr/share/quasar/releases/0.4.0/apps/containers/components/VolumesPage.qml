import QtQuick
import Quasar

// Volumes page: the data containers keep (databases, uploads …), which project it belongs to and
// whether a container uses it; Remove, and Remove unused.
Column {
    id: root
    property var volumes: []               // with inUse
    property var busy: ({})
    signal volumeAction(var volume, string action)
    signal removeUnused()

    spacing: 0
    width: parent ? parent.width : 700
    readonly property int unused: volumes.filter(v => !v.inUse).length

    Item {
        width: parent.width
        height: 34
        Text {
            anchors.verticalCenter: parent.verticalCenter
            text: "Volumes"
            font.family: Theme.fontDisplay; font.pixelSize: 18; font.weight: Font.Medium
            color: Theme.text
        }
        Button {
            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
            visible: root.unused > 0
            enabled: !root.busy["prune:volumes"]
            busy: !!root.busy["prune:volumes"]
            text: "Remove unused (" + root.unused + ")…"
            glyph: Icons.trash
            variant: "outline"; size: 34
            onClicked: root.removeUnused()
        }
    }
    Text {
        width: parent.width
        topPadding: 6; bottomPadding: 16
        wrapMode: Text.Wrap
        text: "Volumes keep a container's data when the container is removed. Removing a volume deletes that data."
        font.family: Theme.fontUi; font.pixelSize: 12
        color: Theme.textFaint
    }

    Rectangle {
        visible: root.volumes.length > 0
        width: parent.width
        height: list.implicitHeight
        radius: 16
        color: Theme.white(0.035)
        border.width: 1; border.color: Theme.white(0.06)
        Column {
            id: list
            width: parent.width
            Repeater {
                model: root.volumes
                Item {
                    id: volRow
                    required property int index
                    required property var modelData
                    readonly property bool working: !!root.busy["volume:" + modelData.name]
                    width: list.width
                    height: 58
                    Rectangle { visible: volRow.index > 0; width: parent.width; height: 1; color: Theme.white(0.05) }
                    QIcon {
                        id: ic
                        x: 16
                        anchors.verticalCenter: parent.verticalCenter
                        path: Icons.drive; size: 18; strokeWidth: 1.9
                        color: Theme.text3
                    }
                    Column {
                        anchors { left: ic.right; leftMargin: 14; right: acts.left; rightMargin: 12; verticalCenter: parent.verticalCenter }
                        spacing: 3
                        Row {
                            width: parent.width
                            spacing: 8
                            Text {
                                anchors.verticalCenter: parent.verticalCenter
                                width: Math.min(implicitWidth, parent.width - (useChip.visible ? useChip.width + 8 : 0))
                                elide: Text.ElideMiddle
                                text: volRow.modelData.anonymous ? volRow.modelData.name.slice(0, 12) + "… (unnamed)" : volRow.modelData.name
                                font.family: Theme.fontUi; font.pixelSize: 14; font.weight: Font.DemiBold
                                color: Theme.text
                            }
                            Chip {
                                id: useChip
                                anchors.verticalCenter: parent.verticalCenter
                                visible: volRow.modelData.inUse
                                text: "In use"
                                tone: Theme.mint; fill: Theme.alpha(Theme.mint, 0.1)
                            }
                        }
                        Text {
                            width: parent.width
                            elide: Text.ElideRight
                            text: (volRow.modelData.project ? "Project " + volRow.modelData.project + "  ·  " : "") + volRow.modelData.driver
                            font.family: Theme.fontUi; font.pixelSize: 12
                            color: Theme.textDim
                        }
                    }
                    Row {
                        id: acts
                        anchors { right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter }
                        Spinner { visible: volRow.working; anchors.verticalCenter: parent.verticalCenter; size: 14 }
                        Button {
                            visible: !volRow.working
                            anchors.verticalCenter: parent.verticalCenter
                            glyph: Icons.trash
                            variant: "ghost"; size: 30
                            fg: Theme.textDim
                            accessibleName: "Remove volume " + volRow.modelData.name
                            onClicked: root.volumeAction(volRow.modelData, "remove")
                        }
                    }
                }
            }
        }
    }
    Text {
        visible: root.volumes.length === 0
        wrapMode: Text.Wrap
        width: Math.min(560, parent.width)
        text: "No volumes yet."
        font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
        color: Theme.textDim
    }
}
