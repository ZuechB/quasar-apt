.pragma library

// People on this PC (`import Quasar` → Accounts): parsing /etc/passwd, /etc/group and greetd's
// config.toml, plus the rules for new accounts. Shared by Settings › Users & Accounts, the sign-in
// screen, the lock screen and the password sheet. Pure JavaScript (no Qt objects), so
// tools/test-accounts-js.py runs it in a bare QJSEngine. The root helper quasar-users applies the
// same rules again: this file only decides what the UI offers.

var HUES = ["#7AB8FF", "#7AE7FF", "#8CF5B0", "#FFD66B", "#FFB86B", "#FF9BD2", "#B9A4FF"]
var UID_MIN = 1000
var UID_MAX = 59999
// Names a person can't take: system accounts that may not exist yet, and Quasar's own prefixes
// (company accounts are quasar-co-<id>, Sites accounts site-<id>).
var RESERVED = ["root", "daemon", "bin", "sys", "sync", "games", "man", "lp", "mail", "news", "uucp",
                "proxy", "www-data", "backup", "list", "irc", "nobody", "admin", "administrator",
                "live", "guest", "user", "users", "sudo", "wheel", "staff", "quasar"]

function parsePasswd(text) {
    var out = []
    String(text || "").split("\n").forEach(function (line) {
        if (!line || line.charAt(0) === "#") return
        var f = line.split(":")
        if (f.length < 7) return
        out.push({ name: f[0], uid: parseInt(f[2], 10), gid: parseInt(f[3], 10),
                   fullName: (f[4] || "").split(",")[0].trim(), home: f[5], shell: f[6].trim() })
    })
    return out
}

// { name: { gid, members: [..] } }
function parseGroups(text) {
    var out = {}
    String(text || "").split("\n").forEach(function (line) {
        if (!line || line.charAt(0) === "#") return
        var f = line.split(":")
        if (f.length < 4) return
        out[f[0]] = { gid: parseInt(f[2], 10), members: f[3].trim() ? f[3].trim().split(",") : [] }
    })
    return out
}

function inGroup(groups, group, account) {
    var g = groups[group]
    if (!g) return false
    return g.members.indexOf(account.name) >= 0 || g.gid === account.gid
}

// A person: a regular account someone signs in to. Company accounts, Sites accounts, system
// accounts and accounts without a login shell are not people.
function isPerson(account, groups, opts) {
    var o = opts || {}
    if (!(account.uid >= UID_MIN && account.uid <= UID_MAX)) return false
    if (/(nologin|false)$/.test(account.shell) || account.shell === "") return false
    if (/^quasar/.test(account.name) || /^site-/.test(account.name) || account.name === "nobody") return false
    if (account.name === "live" && !o.live) return false
    if (groups && inGroup(groups, "quasar-companies", account)) return false
    return true
}

// [{ name, uid, fullName, display, admin, home }], sorted by display name.
function people(passwdText, groupText, opts) {
    var groups = parseGroups(groupText)
    return parsePasswd(passwdText).filter(function (a) { return isPerson(a, groups, opts) })
        .map(function (a) {
            return { name: a.name, uid: a.uid, fullName: a.fullName, display: displayName(a),
                     admin: inGroup(groups, "sudo", a), home: a.home }
        })
        .sort(function (a, b) { return a.display.toLowerCase() < b.display.toLowerCase() ? -1 : a.display.toLowerCase() > b.display.toLowerCase() ? 1 : 0 })
}

function displayName(a) {
    var n = String((a && a.fullName) || "").trim()
    return n !== "" ? n : String((a && a.name) || "")
}

// "Brandon Zuech" → "BZ", "bz" → "B", "anne-marie o'neil" → "AO"
function initials(name) {
    var words = String(name || "").trim().split(/[\s._-]+/).filter(function (w) { return /[A-Za-z0-9]/.test(w) })
    if (!words.length) return "?"
    var first = words[0].match(/[A-Za-z0-9]/)[0]
    if (words.length === 1) return first.toUpperCase()
    var last = words[words.length - 1].match(/[A-Za-z0-9]/)[0]
    return (first + last).toUpperCase()
}

function hue(name) {
    var s = String(name || ""), h = 0
    for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0
    return HUES[Math.abs(h) % HUES.length]
}

// Same rules as the installer (InstallBackend.cs) and quasar-users. "" when fine.
function usernameProblem(name, takenNames) {
    var n = String(name || "")
    if (n === "") return "Choose a username"
    if (n.length < 3) return "At least 3 characters"
    if (n.length > 32) return "At most 32 characters"
    if (!/^[a-z_][a-z0-9_-]*$/.test(n)) return "Lowercase letters, digits, - and _ only, starting with a letter"
    if (RESERVED.indexOf(n) >= 0 || /^quasar/.test(n) || /^site-/.test(n) || /^systemd-/.test(n) || n.charAt(0) === "_")
        return "That name is reserved"
    if ((takenNames || []).indexOf(n) >= 0) return "That name is taken"
    return ""
}

// A username from a full name: "Anne-Marie O'Neil" → "annemarie", falling back to the next free
// "annemarie2". "" when nothing usable is left.
function suggestUsername(fullName, takenNames) {
    var first = String(fullName || "").trim().split(/\s+/)[0] || ""
    var base = first.normalize ? first.normalize("NFD") : first
    base = base.toLowerCase().replace(/[^a-z0-9]/g, "")
    if (!/^[a-z]/.test(base)) base = ""
    if (base.length > 30) base = base.slice(0, 30)
    if (base.length < 3) return ""
    var taken = takenNames || []
    if (!usernameProblem(base, taken)) return base
    for (var i = 2; i < 100; i++) {
        var cand = base + i
        if (!usernameProblem(cand, taken)) return cand
    }
    return ""
}

function passwordProblem(password, confirm) {
    var p = String(password || "")
    if (p === "") return "Choose a password"
    if (p.length < 4) return "At least 4 characters"
    if (confirm !== undefined && confirm !== null && String(confirm) !== p) return "The passwords don't match"
    return ""
}

// The person greetd signs in automatically ([initial_session] user = "..."), or "".
function autologinUser(configText) {
    var section = "", user = ""
    String(configText || "").split("\n").forEach(function (raw) {
        var line = raw.replace(/#.*$/, "").trim()
        if (!line) return
        var s = line.match(/^\[([^\]]+)\]$/)
        if (s) { section = s[1].trim(); return }
        if (section !== "initial_session") return
        var kv = line.match(/^user\s*=\s*"([^"]*)"$/)
        if (kv) user = kv[1]
    })
    return user
}

// Does automatic sign-in start with the screen locked? ([initial_session] command = quasar-session-locked:
// its own program, so a system without it shows the sign-in screen instead of an unlocked desktop.)
function autologinLocked(configText) {
    var section = "", command = "", user = ""
    String(configText || "").split("\n").forEach(function (raw) {
        var line = raw.replace(/#.*$/, "").trim()
        if (!line) return
        var s = line.match(/^\[([^\]]+)\]$/)
        if (s) { section = s[1].trim(); return }
        if (section !== "initial_session") return
        var kv = line.match(/^(user|command)\s*=\s*"([^"]*)"$/)
        if (kv && kv[1] === "user") user = kv[2]
        else if (kv) command = kv[2]
    })
    return user !== "" && command === "/usr/bin/quasar-session-locked"
}

// "Administrator  ·  bz"
function accountSub(p) {
    return (p.admin ? "Administrator" : "Standard account") + "  ·  " + p.name
}
