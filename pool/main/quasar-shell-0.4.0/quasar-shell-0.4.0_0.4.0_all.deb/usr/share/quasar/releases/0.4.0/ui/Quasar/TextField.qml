import QtQuick

// Single-line input (template Wi-Fi password row): 38px, radius 10, dark fill, accent hairline,
// optional 14px leading glyph, 13.5px text. `password` masks the text; `error` turns the line red.
Rectangle {
    id: root
    property alias text: input.text
    property string placeholder: ""
    property string glyph: ""
    property bool password: false
    property bool error: false
    property bool mono: false                 // code-style input (template Sites build/run fields)
    property alias inputItem: input
    signal edited(string text)
    signal accepted()
    signal escapePressed()
    function focusInput() { input.forceActiveFocus() }

    implicitHeight: 38
    implicitWidth: 220
    radius: 10
    color: Qt.rgba(0, 0, 0, 0.3)
    border.width: 1
    border.color: root.error ? Theme.alpha(Theme.danger, 0.7)
                : input.activeFocus ? Theme.accentLine : Theme.white(0.1)
    Behavior on border.color { ColorAnimation { duration: Motion.dur(Motion.hover) } }

    MouseArea {
        anchors.fill: parent
        cursorShape: Qt.IBeamCursor
        onPressed: input.forceActiveFocus()
    }
    QIcon {
        id: icon
        x: 12
        visible: root.glyph !== ""
        anchors.verticalCenter: parent.verticalCenter
        path: root.glyph; size: 14; strokeWidth: 2
        color: Theme.textDim
    }
    TextInput {
        id: input
        anchors { left: icon.visible ? icon.right : parent.left; leftMargin: icon.visible ? 8 : 12; right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter }
        font.family: root.mono ? Theme.fontMono : Theme.fontUi; font.pointSize: Theme.pt(root.mono ? 12.5 : 13.5)
        color: Theme.text
        echoMode: root.password ? TextInput.Password : TextInput.Normal
        passwordCharacter: "•"
        selectionColor: Theme.alpha(Theme.accent, 0.35)
        selectedTextColor: Theme.text
        selectByMouse: true
        activeFocusOnTab: true                // Tab moves between fields (not straight to the buttons)
        clip: true
        Accessible.role: Accessible.EditableText
        Accessible.name: root.placeholder
        Accessible.passwordEdit: root.password
        onTextEdited: root.edited(text)
        onAccepted: root.accepted()
        Keys.onEscapePressed: root.escapePressed()
        Text {
            anchors.fill: parent
            verticalAlignment: Text.AlignVCenter
            visible: input.text === "" && input.preeditText === ""
            text: root.placeholder
            elide: Text.ElideRight
            font.family: root.mono ? Theme.fontMono : Theme.fontUi; font.pointSize: Theme.pt(root.mono ? 12.5 : 13.5)
            color: Theme.textFaint
        }
    }
}
