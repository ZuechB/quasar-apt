.pragma library
// Pure logic behind the Services window (template data-win="svc"): rows, groups, filters, the summary,
// status words (the template's svStat), times (fmtDur / schedText / nextRun), argument quoting, port
// checks and the Add form's spec. No Qt types: colours come back as tokens ("accent", "fail", "dim",
// "sched") that the views map to Theme colours. Checked by tools/test-services-js.py.

// ---- times ---------------------------------------------------------------------------------------
function fmtDur(ms) {
    var m = Math.max(0, Math.round(ms / 60000))
    if (m < 1) return "under a minute"
    if (m < 60) return m + "m"
    var h = Math.floor(m / 60)
    if (h < 24) return h + "h " + (m % 60) + "m"
    var d = Math.floor(h / 24)
    return d + "d " + (h % 24) + "h"
}

function t12(dt) {
    var h = dt.getHours(), mm = dt.getMinutes()
    return ((h % 12) || 12) + ":" + (mm < 10 ? "0" : "") + mm + " " + (h >= 12 ? "PM" : "AM")
}

function schedText(sc) {
    if (!sc) return ""
    if (sc.every === "hour") { var a = sc.at || 0; return "Every hour at :" + (a < 10 ? "0" : "") + a }
    var hm = String(sc.at || "06:00").split(":").map(Number), dt = new Date()
    dt.setHours(hm[0], hm[1] || 0, 0, 0)
    var t = t12(dt)
    return sc.every === "day" ? "Every day at " + t : sc.every === "weekdays" ? "Weekdays at " + t : "Every Sunday at " + t
}

// The next run of a scheduled entry after `now` (ms), as a Date, or null.
function nextRun(item, now) {
    var sc = item && item.sched
    if (!sc) return null
    var d = new Date(now), n = new Date(now)
    if (sc.every === "hour") {
        n.setMinutes(sc.at || 0, 0, 0)
        if (n <= d) n.setHours(n.getHours() + 1)
        return n
    }
    var hm = String(sc.at || "06:00").split(":").map(Number)
    n.setHours(hm[0], hm[1] || 0, 0, 0)
    if (n <= d) n.setDate(n.getDate() + 1)
    if (sc.every === "weekdays") while (n.getDay() === 0 || n.getDay() === 6) n.setDate(n.getDate() + 1)
    if (sc.every === "week") while (n.getDay() !== (sc.day || 0)) n.setDate(n.getDate() + 1)
    return n
}

function clock(ms) {
    var d = new Date(ms)
    var p = function (n) { return (n < 10 ? "0" : "") + n }
    return p(d.getHours()) + ":" + p(d.getMinutes()) + ":" + p(d.getSeconds())
}

// ---- status (template svStat) --------------------------------------------------------------------
// icon: an Icons property name; color: accent | fail | dim | sched; spin: the icon turns.
function statusOf(item, now) {
    var since = item.since ? item.since * 1000 : now
    if (item.status === "starting") return { label: "Starting", color: "accent", icon: "refresh", spin: true, meta: "One moment" }
    if (item.status === "running")
        return { label: item.kind === "schedule" ? "Running now" : "Running", color: "accent", icon: "play2", spin: false,
                 meta: item.kind === "schedule" ? "Started " + fmtDur(now - since) + " ago" : "Up " + fmtDur(now - since) }
    if (item.status === "failed") {
        var ls = item.server && item.server.lastStart
        var at = ls && ls.at ? ls.at * 1000 : (item.lastRun && item.lastRun.at ? item.lastRun.at : 0)
        return { label: "Failed", color: "fail", icon: "alert", spin: false, meta: at ? fmtDur(now - at) + " ago" : "" }
    }
    if (!item.enabled) return { label: "Off", color: "dim", icon: "power", spin: false, meta: "Turned off" }
    if (item.status === "stopped")
        return { label: "Stopped", color: "dim", icon: "stop", spin: false,
                 meta: item.onDemand ? "Starts when it's needed" : item.kind === "startup" ? "Starts at next sign-in" : "Start it any time" }
    var nr = nextRun(item, now)
    return { label: "Scheduled", color: "sched", icon: "clock", spin: false, meta: nr ? "Next in " + fmtDur(nr - now) : "" }
}

function trigger(item) {
    if (item.onDemand) return "Starts when it's needed"
    if (item.kind === "startup") return "Starts at sign-in"
    if (item.kind === "service") return "Always running" + (item.restart ? ", restarts if it crashes" : "")
    return schedText(item.sched)
}

function kindLabel(item) {
    return item.kind === "startup" ? "At sign-in" : item.kind === "service" ? "Always running" : "Scheduled"
}

function live(item) { return item.status === "running" && item.kind !== "schedule" }
function can(item, action) { return (item.actions || []).indexOf(action) >= 0 }

// ---- the list ------------------------------------------------------------------------------------
var GROUPS = [["startup", "AT SIGN-IN"], ["schedule", "SCHEDULED"], ["service", "ALWAYS RUNNING"]]
var FILTERS = [["all", "All", "grid"], ["startup", "At sign-in", "power"], ["schedule", "Scheduled", "clock"],
               ["service", "Always running", "cycle"], ["failed", "Needs attention", "alert"]]

function inFilter(item, f) {
    return f === "all" || (f === "failed" ? item.status === "failed" : item.kind === f)
}

function matches(item, query) {
    var q = String(query || "").trim().toLowerCase()
    return !q || (String(item.name || "") + " " + String(item.desc || "")).toLowerCase().indexOf(q) >= 0
}

function shown(items, filter, query) {
    return (items || []).filter(function (x) { return inFilter(x, filter || "all") && matches(x, query) })
}

// [{ key, label, rows: [item…] }], empty groups left out (template order).
function groups(items, filter, query) {
    var s = shown(items, filter, query)
    return GROUPS.map(function (g) {
        return { key: g[0], label: g[1], rows: s.filter(function (x) { return x.kind === g[0] }) }
    }).filter(function (g) { return g.rows.length > 0 })
}

// The rows in display order (groups flattened), for keyboard navigation and the stagger index.
function ordered(items, filter, query) {
    var out = []
    groups(items, filter, query).forEach(function (g) { out = out.concat(g.rows) })
    return out
}

function filters(items, current) {
    return FILTERS.map(function (f) {
        var n = (items || []).filter(function (x) { return inFilter(x, f[0]) }).length
        return { key: f[0], label: f[1], icon: f[2], on: (current || "all") === f[0], count: n, warn: f[0] === "failed" && n > 0 }
    })
}

function summary(items, now) {
    var all = items || []
    var running = all.filter(function (x) { return x.status === "running" }).length
    var failed = all.filter(function (x) { return x.status === "failed" }).length
    var next = all.filter(function (x) { return x.kind === "schedule" && x.enabled && x.status !== "running" })
                  .map(function (x) { return { x: x, t: nextRun(x, now) } })
                  .filter(function (o) { return !!o.t })
                  .sort(function (a, b) { return a.t - b.t })[0]
    return running + " running" + (next ? "  ·  next: " + next.x.name + " in " + fmtDur(next.t - now) : "")
         + (failed ? "  ·  " + failed + " failed" : "")
}

// The template's selection: the chosen row, else the first failed one, else the first that isn't
// Quasar's own, else the first. Not limited to the rows the filter shows.
function selected(items, key) {
    var all = items || []
    for (var i = 0; i < all.length; i++) if (all[i].key === key) return all[i]
    for (i = 0; i < all.length; i++) if (all[i].status === "failed") return all[i]
    for (i = 0; i < all.length; i++) if (!all[i].system) return all[i]
    return all.length ? all[0] : null
}

// ---- the detail ----------------------------------------------------------------------------------
function runsAs(item) {
    if (item.system) return "System, shared by every company"
    if (item.server) return "Its own account, " + item.server.account
    if (item.source === "site") return "Its own account, site-" + item.id
    return "Personal profile"
}

function ifItStops(item) {
    if (item.kind === "service") return item.restart ? "Restart it, up to 5 times a minute" : "Leave it stopped"
    if (item.kind === "startup") return "Wait for the next sign-in"
    return "Catch up at the next boot if a run was missed"
}

// [{ label, value, mono }] for the facts card.
function facts(item, now) {
    var out = [{ label: "When", value: trigger(item), mono: false }]
    if (item.cmd) out.push({ label: "Command", value: item.cmd, mono: true })
    var s = item.server
    if (s) out.push({ label: "Folder", value: s.path, mono: true })
    out.push({ label: "Runs as", value: runsAs(item), mono: false })
    if (s && s.data) out.push({ label: "Saved data", value: s.data, mono: true })
    out.push({ label: "If it stops", value: ifItStops(item), mono: false })
    if (item.unit) out.push({ label: "Unit", value: item.unit, mono: true })
    var ls = s && s.lastStart
    if (ls && ls.at) out.push({ label: "Last start", value: (ls.ok ? "Succeeded " : "Failed ") + fmtDur(now - ls.at * 1000) + " ago." + (ls.ok ? "" : " " + reasonText(ls.code, ls.message, s)), mono: false })
    return out
}

// svc-prepare's reason codes (PROTOCOL.md) in plain words. The helper's own message wins when it has one.
function reasonText(code, message, server) {
    if (message) return message
    var path = server ? server.path : "the folder", exec = server ? server.exec : "the program"
    switch (code) {
    case "missing-folder": return "Its folder isn’t there anymore: " + path + "."
    case "symlink": return "The folder’s path goes through a shortcut (a symbolic link). Pick the real folder."
    case "owner": return "The folder has to belong to you."
    case "writable": return "Other accounts on this PC can change that folder. Take away their write access, then start it again."
    case "fs": return "That folder is on a drive that can’t run programs safely, like a USB stick. Move it into your home folder."
    case "missing-exec": return "The program isn’t in the folder anymore: " + exec + "."
    case "not-executable": return "The program isn’t allowed to run, and Quasar couldn’t change that (its drive is read-only, or the file is locked)."
    case "not-a-program": return "That file isn’t a program Linux can run. Pick the server’s Linux program (for a Unity build, the .x86_64 file)."
    case "arch": return "This build is for a different kind of processor."
    case "windows-build": return "This is the Windows build. Build the server for Linux and put that in the folder."
    case "not-readable": return "Its account can’t read the files in the folder."
    case "live": return "Servers can’t run from the live USB. Install Quasar first."
    case "start-failed": return "The program stopped right away. Its last lines are under Details."
    case "port-busy": return "Another program already uses one of its ports."
    }
    return "It didn’t start."
}

function bytesText(b) {
    if (b === null || b === undefined || b < 0) return ""
    if (b >= 1e9) return (b / 1e9).toFixed(1) + " GB"
    if (b >= 1e6) return Math.round(b / 1e6) + " MB"
    if (b >= 1e3) return Math.round(b / 1e3) + " KB"
    return b + " bytes"
}

// 1234567 -> "1,234,567".
function grouped(n) {
    var s = String(Math.max(0, Math.round(Number(n) || 0)))
    return s.replace(/\B(?=(\d{3})+(?!\d))/g, ",")
}

// "just now" / "4m ago" since a moment in ms (0: "").
function ago(at, now) {
    if (!at) return ""
    return now - at < 60000 ? "just now" : fmtDur(now - at) + " ago"
}

// The template's memory bar: GB with one decimal, the bar full at 4 GB.
function memGb(b) { return b ? Math.round(b / 1e8) / 10 : 0 }
function memPct(b) { return Math.min(100, Math.round(memGb(b) / 4 * 100)) }
function cpuPct(cpu) { return Math.min(100, Math.max(0, (cpu || 0) * 2)) }

// ---- arguments -----------------------------------------------------------------------------------
// Split a command line like a POSIX shell would, without expanding anything: "a b" and 'a b' are one
// argument, a backslash escapes the next character outside single quotes. An unclosed quote takes the
// rest of the line.
function splitArgs(text) {
    var s = String(text || ""), out = [], cur = "", has = false, q = ""
    for (var i = 0; i < s.length; i++) {
        var c = s.charAt(i)
        if (q === "'") { if (c === "'") q = ""; else cur += c; continue }
        if (q === '"') {
            if (c === '"') q = ""
            else if (c === "\\" && i + 1 < s.length && '"\\$`'.indexOf(s.charAt(i + 1)) >= 0) cur += s.charAt(++i)
            else cur += c
            continue
        }
        if (c === "'" || c === '"') { q = c; has = true; continue }
        if (c === "\\" && i + 1 < s.length) { cur += s.charAt(++i); has = true; continue }
        if (c === " " || c === "\t" || c === "\n") { if (has || cur !== "") { out.push(cur); cur = ""; has = false }; continue }
        cur += c; has = true
    }
    if (has || cur !== "") out.push(cur)
    return out
}

function quoteArg(a) {
    var s = String(a)
    if (s === "") return "''"
    if (/^[A-Za-z0-9_@%+=:,.\/-]+$/.test(s)) return s
    if (s.indexOf('"') < 0 && s.indexOf("\\") < 0 && s.indexOf("$") < 0 && s.indexOf("`") < 0) return '"' + s + '"'
    return "'" + s.replace(/'/g, "'\\''") + "'"
}

function joinArgs(args) { return (args || []).map(quoteArg).join(" ") }

// What the detail shows as the command (the helper sends the effective one in item.cmd).
function commandText(exec, args) { return [quoteArg("./" + (exec || "")).replace(/^'\.\//, "'./")].concat((args || []).map(quoteArg)).join(" ") }

// ---- ports ---------------------------------------------------------------------------------------
var REACHES = [["this-pc", "This PC"], ["home", "Home network"], ["internet", "Internet"]]

function reachLabel(r) {
    for (var i = 0; i < REACHES.length; i++) if (REACHES[i][0] === r) return REACHES[i][1]
    return "This PC"
}

function portText(p) { return String(p.proto || "udp").toUpperCase() + " " + p.port }

function hasInternet(ports) { return (ports || []).some(function (p) { return p.reach === "internet" }) }

function internetPorts(ports) { return (ports || []).filter(function (p) { return p.reach === "internet" }) }

// Ports Quasar keeps for itself (PROTOCOL.md): Sites 41000-41999, Command Deck 47300 and up (one per
// account), Ollama 11434, SSH 22.
function reservedBy(port) {
    var n = Number(port)
    if (n >= 41000 && n <= 41999) return "Sites"
    if (n >= 47300 && n <= 47399) return "Command Deck"
    if (n === 11434) return "Quasar AI"
    if (n === 22) return "Remote sign-in"
    return ""
}

// The first problem with port row i, in words, or "". `ports` is the whole list (duplicates).
function portProblem(ports, i) {
    var p = ports[i] || {}
    var s = String(p.port === undefined || p.port === null ? "" : p.port).trim()
    if (s === "") return "Enter the port number."
    if (!/^\d+$/.test(s)) return "A port is a number."
    var n = Number(s)
    if (n < 1024 || n > 65535) return "Use a port from 1024 to 65535."
    if (p.proto !== "udp" && p.proto !== "tcp") return "Pick UDP or TCP."
    var by = reservedBy(n)
    if (by) return "Port " + n + " belongs to " + by + "."
    for (var j = 0; j < ports.length; j++)
        if (j !== i && ports[j] && Number(ports[j].port) === n && ports[j].proto === p.proto) return portText(p) + " is listed twice."
    return ""
}

function portsProblem(ports) {
    for (var i = 0; i < (ports || []).length; i++) { var e = portProblem(ports, i); if (e) return e }
    return ""
}

// Where players connect: { lan: "192.168.1.20:7770", internet: "animalgo.zuech.io:7770" } for the
// first port players use (the first internet one, else the first home one). Empty when unknown.
function addresses(server, lan) {
    var out = { lan: "", internet: "", port: null }
    if (!server) return out
    var ports = server.ports || []
    var pick = internetPorts(ports)[0] || ports.filter(function (p) { return p.reach === "home" })[0] || null
    if (!pick) return out
    out.port = pick
    if (lan && lan.ip && (pick.reach === "home" || pick.reach === "internet")) out.lan = lan.ip + ":" + pick.port
    if (pick.reach === "internet" && server["public"] && server["public"].name) out.internet = server["public"].name + ":" + pick.port
    return out
}

// ---- the Add form --------------------------------------------------------------------------------
function slugId(name) {
    var s = String(name || "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").replace(/-{2,}/g, "-")
    if (!s || !/^[a-z]/.test(s)) s = s ? "svc-" + s : "server"
    s = s.slice(0, 26).replace(/-+$/, "")
    if (s.length < 2) s = (s + "-server").slice(0, 26)
    return s
}

// A draft from `inspect` (PROTOCOL.md): what the form edits. `flags`: what the game's own scripts read
// ([{flag, role}], role port | name | value | ""); inspect has already filled in its port and name flags.
function draftFrom(res) {
    var r = res || {}
    return {
        path: r.path || "", kind: r.kind || "none", name: r.name || "", id: r.id || slugId(r.name),
        exec: r.exec || "", argsText: joinArgs(r.args || []), label: r.label || "", facts: r.facts || [],
        ports: (r.ports || []).map(function (p) { return { proto: p.proto || "udp", port: p.port, label: p.label || "", reach: p.reach || "home" } }),
        players: r.players || null, manifest: !!r.manifest, executable: r.executable !== false,
        problems: r.problems || [], notes: r.notes || [], restart: true, publicName: "", publicVia: "",
        flags: r.flags || []
    }
}

// ---- the game's own options (inspect's `flags`) ------------------------------------------------------
// "-Max-Players" -> "maxplayers": how flags are compared (detect.py's flag_key).
function flagKey(flag) { return String(flag || "").replace(/^-+/, "").toLowerCase().replace(/[-_]/g, "") }

// Flags that set the port or the name even when the game's scripts weren't read (an IL2CPP build, a
// server added before Quasar read them): the owner may have typed them.
var ROLE_FALLBACK = { port: ["-port", "--port"], name: ["-name", "--name", "-servername"] }

function roleOf(d, flag) {
    var low = String(flag || "").toLowerCase(), fl = (d && d.flags) || []
    for (var i = 0; i < fl.length; i++) if (String(fl[i].flag).toLowerCase() === low) return fl[i].role || ""
    for (var role in ROLE_FALLBACK) if (ROLE_FALLBACK[role].indexOf(low) >= 0) return role
    return ""
}

// The flags (lowercase) that play `role`: the game's own, then the fallbacks.
function roleFlags(d, role) {
    var out = ((d && d.flags) || []).filter(function (f) { return f.role === role }).map(function (f) { return String(f.flag).toLowerCase() })
    return out.concat(ROLE_FALLBACK[role] || [])
}

// The word after one of `flags` that equals `oldValue` becomes `newValue`; anything else stays as the owner
// wrote it (the text is only rebuilt when something changed).
function follow(text, flags, oldValue, newValue) {
    var args = splitArgs(text), changed = false
    for (var i = 0; i + 1 < args.length; i++) {
        if (flags.indexOf(args[i].toLowerCase()) >= 0 && args[i + 1] === oldValue && oldValue !== newValue) {
            args[i + 1] = newValue
            changed = true
            i++
        }
    }
    return changed ? joinArgs(args) : String(text || "")
}

// The arguments after the Name changes to `name`: its name flag follows while it still says the old name.
function withName(d, name) {
    return follow(d.argsText, roleFlags(d, "name"), String(d.name || "").trim(), String(name || "").trim())
}

// The arguments after port row `i` changes to `value`: its port flag follows while it still says the old one.
function withPort(d, i, value) {
    var p = (d.ports || [])[i]
    if (!p) return String(d.argsText || "")
    var old = p.port === undefined || p.port === null ? "" : String(p.port)
    return follow(d.argsText, roleFlags(d, "port"), old, String(value === undefined || value === null ? "" : value).trim())
}

function inArgs(args, flag) {
    var low = String(flag).toLowerCase()
    return args.some(function (a) { var x = a.toLowerCase(); return x === low || x.indexOf(low + "=") === 0 })
}

// The chips under Arguments: the game's flags not in the arguments yet, 8 unless `all`.
function flagChips(d, all) {
    var args = splitArgs(d && d.argsText)
    var list = ((d && d.flags) || []).filter(function (f) { return !inArgs(args, f.flag) })
    var n = all ? list.length : Math.min(8, list.length)
    return { shown: list.slice(0, n), more: list.length - n }
}

// The arguments with `flag` added: the port flag with the first port, the name flag with the Name, any other
// flag on its own (the field then takes the cursor for its value).
function addFlag(d, flag) {
    var text = String(d.argsText || "").replace(/\s+$/, ""), role = roleOf(d, flag), piece = flag
    var first = (d.ports || [])[0], name = String(d.name || "").trim()
    if (role === "port" && first && String(first.port) !== "") piece += " " + first.port
    else if (role === "name" && name) piece += " " + quoteArg(name)
    else piece += " "
    return (text ? text + " " : "") + piece
}

// Things in the arguments that would stop the server, in words. Not blocking: a flag that only names a
// port to connect to looks the same. [{ text, fix: { proto, port } | null }]
function argsWarnings(d) {
    var args = splitArgs(d && d.argsText), out = [], seen = {}
    var listed = ((d && d.ports) || []).map(function (p) { return Number(p.port) })
    var first = ((d && d.ports) || [])[0]
    function warn(text, fix) { if (!seen[text]) { seen[text] = true; out.push({ text: text, fix: fix }) } }
    for (var i = 0; i < args.length; i++) {
        var a = args[i], m = /^(--?[A-Za-z0-9_-]*port)(?:=(.*))?$/i.exec(a)
        var role = roleOf(d, m ? m[1] : a)
        var next = m && m[2] !== undefined ? m[2] : args[i + 1]
        var dangling = next === undefined || next === "" || /^-[^\d]/.test(next)
        if (role && dangling && (m ? m[2] === undefined : true)) {
            warn(a + " needs a value after it.", null)
            continue
        }
        if (m && /^\d+$/.test(next || "")) {
            var n = Number(next)
            if (listed.indexOf(n) < 0)
                warn(m[1] + " " + n + " isn’t under Who can join, so the server won’t be allowed to open it.",
                     n >= 1024 && n <= 65535 ? { proto: first && first.proto === "tcp" ? "tcp" : "udp", port: n } : null)
        }
    }
    return out
}

function engineOf(kind) {
    return kind === "unity" ? "unity" : kind === "dotnet" ? "dotnet" : "program"
}

// Can the draft be added? "" or the reason (shown under the form).
function draftProblem(d) {
    if (!d || !d.path) return "Pick the server’s folder."
    if (d.problems && d.problems.length) return d.problems[0].message
    if (!String(d.name || "").trim()) return "Give it a name."
    if (!String(d.exec || "").trim()) return "Enter the program to start."
    if (/(^|\/)\.\.(\/|$)/.test(d.exec) || String(d.exec).charAt(0) === "/") return "The program must be inside the folder."
    var pp = portsProblem(d.ports)
    if (pp) return pp
    return ""
}

// The admin helper's `add` spec (PROTOCOL.md).
function spec(d) {
    var pub = hasInternet(d.ports) && String(d.publicName || "").trim()
        ? { name: String(d.publicName).trim().toLowerCase(), via: String(d.publicVia || "").trim().toLowerCase() } : null
    return {
        name: String(d.name).trim(), id: d.id || slugId(d.name), path: d.path, exec: String(d.exec).trim(),
        kind: engineOf(d.kind), args: splitArgs(d.argsText), env: [],
        ports: (d.ports || []).map(function (p) { return { proto: p.proto, port: Number(p.port), label: String(p.label || "").trim(), reach: p.reach } }),
        "public": pub, options: { crashRestart: d.restart !== false, memoryMax: null, cpuWeight: null },
        players: d.players || null, start: true
    }
}

function previewText(d) {
    var name = String(d.name || "").trim() || "This server"
    var id = d.id || slugId(d.name)
    var s = name + " will run all the time in the background as its own account svc-" + id + ", from " + d.path + "."
    var home = (d.ports || []).filter(function (p) { return p.reach === "home" || p.reach === "internet" })
    var net = internetPorts(d.ports)
    if (net.length) s += " Players anywhere can join on " + net.map(portText).join(" and ") + "."
    else if (home.length) s += " Devices on your home network can join on " + home.map(portText).join(" and ") + "."
    else if ((d.ports || []).length) s += " Only this PC can reach it."
    return s
}

// ---- logs ----------------------------------------------------------------------------------------
// {"type":"log"} (services-query, sites-query) -> { t, m, lvl }.
function logLine(ev) {
    var lvl = ev.lvl || (ev.status >= 500 ? "err" : ev.status >= 400 ? "warn" : "info")
    return { t: clock((ev.t || 0) * 1000), m: String(ev.m || ""), lvl: lvl }
}

// One `journalctl -o json` record -> { t, m, lvl }, or null.
function journalLine(rec) {
    if (!rec) return null
    var msg = rec.MESSAGE
    if (msg && typeof msg === "object" && msg.length !== undefined) msg = utf8(msg)
    if (!msg) return null
    var prio = parseInt(rec.PRIORITY, 10)
    var t = parseInt(rec.__REALTIME_TIMESTAMP, 10) / 1000
    return { t: clock(isNaN(t) ? Date.now() : t), m: String(msg), lvl: prio <= 3 ? "err" : prio === 4 ? "warn" : "info" }
}

// journald's bytes (a list of numbers) as text: UTF-8, with U+FFFD for what isn't.
function utf8(bytes) {
    var out = "", i = 0, n = bytes.length
    function cont(k) { return k < n && (bytes[k] & 0xC0) === 0x80 }
    while (i < n) {
        var b = bytes[i] & 0xFF
        if (b < 0x80) { out += String.fromCharCode(b); i++ }
        else if (b >= 0xC2 && b < 0xE0 && cont(i + 1)) { out += String.fromCharCode(((b & 0x1F) << 6) | (bytes[i + 1] & 0x3F)); i += 2 }
        else if (b >= 0xE0 && b < 0xF0 && cont(i + 1) && cont(i + 2)) {
            out += String.fromCharCode(((b & 0x0F) << 12) | ((bytes[i + 1] & 0x3F) << 6) | (bytes[i + 2] & 0x3F)); i += 3
        } else if (b >= 0xF0 && b < 0xF5 && cont(i + 1) && cont(i + 2) && cont(i + 3)) {
            var cp = (((b & 0x07) << 18) | ((bytes[i + 1] & 0x3F) << 12) | ((bytes[i + 2] & 0x3F) << 6) | (bytes[i + 3] & 0x3F)) - 0x10000
            out += String.fromCharCode(0xD800 + (cp >> 10), 0xDC00 + (cp & 0x3FF)); i += 4
        } else { out += "�"; i++ }
    }
    return out
}

// ---- consoles ------------------------------------------------------------------------------------
// A log event -> lines for LogList ({ t: unix seconds, m, lvl, src?, unit?, user?, acct? }):
// services-query journal's {"type":"lines"} batches, and the one-line {"type":"log"} of `logs ID` and
// sites-query (request lines: 5xx red, 4xx amber).
function linesOf(ev) {
    if (!ev) return []
    if (ev.type === "lines") return ev.lines || []
    if (ev.type === "log")
        return [{ t: typeof ev.t === "number" ? ev.t : Date.now() / 1000, m: String(ev.m || ""), unit: "",
                  lvl: ev.lvl || (ev.status >= 500 ? "err" : ev.status >= 400 ? "warn" : "info") }]
    return []
}

// quasar-services' argument -> the console it asks for: a key, "*" (every service), or "".
//   log  log/*  log/svc:animal-go  log/service:ssh.service,cron.service  log/userservice:pipewire.service
var KEY_RE = /^(svc|site|sys):[a-z][a-z0-9-]{0,40}$|^(service|userservice):[A-Za-z0-9:_.\\@,-]{1,600}$/
function logLink(arg) {
    var a = String(arg || "").trim()
    if (a === "log" || a === "log/" || a === "log/*") return "*"
    if (a.indexOf("log/") !== 0) return ""
    var key = a.slice(4)
    return KEY_RE.test(key) ? key : ""
}

// The units a console reads, as journalctl arguments (Open in Terminal): -u for system units,
// --user-unit= for your own. item: the key's row, when there is one (a site's current slot, a System
// row's bus). "*" -> [] (everything).
function unitArgs(key, item) {
    var out = []
    var kind = key.slice(0, key.indexOf(":")), rest = key.slice(key.indexOf(":") + 1)
    if (kind === "svc") return ["-u", "quasar-svc-folder@" + rest + ".service", "-u", "quasar-svc@" + rest + ".service"]
    if (kind === "site") {
        if (item && item.unit) return ["-u", item.unit]
        return ["-u", "quasar-site-a@" + rest + ".service", "-u", "quasar-site-b@" + rest + ".service"]
    }
    if (kind === "sys") return item && item.unit ? (item.user ? ["--user-unit=" + item.unit] : ["-u", item.unit]) : []
    if (kind === "service" || kind === "userservice")
        rest.split(",").forEach(function (u) { if (u) out = out.concat(kind === "service" ? ["-u", u] : ["--user-unit=" + u]) })
    return out
}

// A console window's title: the row's name, else the unit's (several: "getty@tty1 and 1 more").
function consoleTitle(key, item) {
    if (key === "*") return "Every service"
    if (item && item.name) return item.name
    var units = key.slice(key.indexOf(":") + 1).split(",")
    var first = units[0].replace(/\.service$/, "")
    return units.length > 1 ? first + " and " + (units.length - 1) + " more" : first
}

var SIGNALS = { 1: "SIGHUP", 2: "SIGINT", 3: "SIGQUIT", 4: "SIGILL", 5: "SIGTRAP", 6: "SIGABRT", 7: "SIGBUS", 8: "SIGFPE",
                9: "SIGKILL", 11: "SIGSEGV", 13: "SIGPIPE", 14: "SIGALRM", 15: "SIGTERM", 24: "SIGXCPU", 25: "SIGXFSZ", 31: "SIGSYS" }
function signalName(n) { return SIGNALS[n] || "signal " + n }

// Why a service isn't running (or keeps restarting), in plain words; "" when it runs fine. A server's
// refused start (svc-prepare's words) comes first, then systemd's Result and how the program last ended.
function whyStopped(item) {
    if (!item || item.status === "running") return ""
    var ls = item.server && item.server.lastStart
    if (ls && ls.ok === false && ls.message) return String(ls.message)
    var ex = item.exit || null, res = item.result || ""
    var how = ""
    if (ex && ex.code === "exited") how = "It stopped with exit code " + ex.status + "."
    else if (ex && ex.code === "dumped") how = "It crashed (" + signalName(ex.status) + ") and left a core dump."
    else if (ex && ex.code === "killed") how = ex.status === 11 ? "It crashed (segmentation fault)." : "It was killed (" + signalName(ex.status) + ")."
    var cause = res === "oom-kill" ? "The PC ran out of memory and stopped it."
              : res === "start-limit-hit" ? "It crashed too many times in a row, so it won't restart until you start it."
              : res === "timeout" ? "It didn't finish starting or stopping in time."
              : res === "resources" ? "It couldn't be set up: a folder, account or limit it needs is missing."
              : res === "watchdog" ? "It stopped answering."
              : res === "core-dump" && !how ? "It crashed and left a core dump."
              : !how && (res === "exit-code" || res === "signal" || item.status === "failed") ? "It stopped with an error." : ""
    var words = cause && how && res !== "core-dump" ? cause + " " + how.replace(/^It /, "Last time it ") : cause || how
    if (!words) return ""
    if (item.restarts > 0) words += " Restarted " + item.restarts + (item.restarts === 1 ? " time." : " times.")
    if (item.status === "starting") words += " Starting again…"
    return words
}

// ---- every service on this PC (services-query units) ------------------------------------------------
// A unit row as the list shows it. Quasar's own units go under their Services names and open the same console
// as their main rows (console). A site's other slot is left out (null).
function everyRow(u, items) {
    var main = null, site = /^quasar-site-[ab]@([a-z0-9-]+)\.service$/.exec(u.unit || "")
    for (var i = 0; i < (items || []).length; i++) {
        var it = items[i]
        if (it.unit && it.unit === u.unit && !!it.user === !!u.user) { main = it; break }
        if (site && it.source === "site" && it.id === site[1]) { if (it.unit && it.unit !== u.unit) return null }
    }
    return { key: u.key, console: main ? main.key : u.key, name: main ? main.name : u.name || u.unit, unit: u.unit,
             user: !!u.user, status: u.status || "stopped", sub: u.sub || "", enabled: u.enabled === undefined ? null : u.enabled,
             result: u.result || "", exit: u.exit || null, restarts: u.restarts || 0, quasar: !!main }
}

// Which part of the list: failures first, then what runs, then the rest (finished one-shot jobs too).
function unitSection(r) {
    if (r.status === "failed") return "FAILED"
    if (r.status === "starting" || r.status === "stopping" || (r.status === "running" && r.sub !== "exited")) return "RUNNING"
    return "NOT RUNNING"
}

// The status words and colour token of a unit row.
function unitStatus(r) {
    if (r.status === "failed") return { label: "Failed", color: "fail" }
    if (r.status === "starting") return { label: "Starting", color: "accent" }
    if (r.status === "stopping") return { label: "Stopping", color: "dim" }
    if (r.status === "running") return r.sub === "exited" ? { label: "Finished", color: "dim" } : { label: "Running", color: "accent" }
    return { label: r.enabled === false ? "Off" : "Not running", color: "dim" }
}

function unitSortKey(r) {
    var rank = { "FAILED": 0, "RUNNING": 1, "NOT RUNNING": 2 }[unitSection(r)]
    return rank + "\u0001" + String(r.name || "").toLowerCase() + "\u0001" + r.key
}

function unitMatches(r, query) {
    var q = String(query || "").trim().toLowerCase()
    return !q || (String(r.name || "") + " " + String(r.unit || "")).toLowerCase().indexOf(q) >= 0
}

// "214 services · 61 running · 2 failed"
function unitCounts(rows) {
    var all = rows || [], running = 0, failed = 0
    for (var i = 0; i < all.length; i++) {
        var s = unitSection(all[i])
        if (s === "FAILED") failed++
        else if (s === "RUNNING") running++
    }
    return all.length + (all.length === 1 ? " service" : " services") + "  ·  " + running + " running" + (failed ? "  ·  " + failed + " failed" : "")
}

// ---- DNS check -----------------------------------------------------------------------------------
// verdict -> color token for the result line.
function dnsTone(verdict) {
    return verdict === "ok" ? "ok" : verdict === "proxied" || verdict === "elsewhere" ? "warn" : verdict ? "fail" : ""
}

// ---- copying a new build in (Update…) ------------------------------------------------------------
// argv for `sh -c`: the server folder's contents go to the Trash (the folder itself stays), then the
// new build is copied in from a folder, or unpacked from an archive into a temporary folder beside it
// and moved in (an archive whose only top-level item is a folder lands as that folder's contents).
// All as the owner, through fileop. Prints fileop's JSON lines.
function copyCommand(dest, source, archive, fileop) {
    var fo = fileop || "/usr/libexec/quasar/fileop"
    var script = 'set -e; dest=$1; src=$2; fo=$3\n'
        + 'trash() { set --; for f in "$1"/* "$1"/.[!.]* "$1"/..?*; do [ -e "$f" ] || [ -L "$f" ] && set -- "$@" "$f"; done; [ $# -eq 0 ] || "$fo" trash "$@"; }\n'
        + 'inside() { set --; for f in "$1"/* "$1"/.[!.]* "$1"/..?*; do [ -e "$f" ] || [ -L "$f" ] && set -- "$@" "$f"; done; printf "%s\\n" "$@"; }\n'
        + 'trash "$dest"\n'
    if (archive)
        script += 'tmp=$(mktemp -d "$dest/../.quasar-new-build.XXXXXX")\n'
            + 'trap \'rm -rf "$tmp"\' EXIT\n'
            + '"$fo" extract "$src" "$tmp"\n'
            + 'top="$tmp"; n=$(inside "$tmp" | wc -l)\n'
            + 'if [ "$n" -eq 1 ]; then one=$(inside "$tmp"); [ -d "$one" ] && top="$one"; fi\n'
            + 'if [ "$(inside "$top" | wc -l)" -eq 1 ]; then one=$(inside "$top"); [ -d "$one" ] && top="$one"; fi\n'
            + 'set --; for f in "$top"/* "$top"/.[!.]* "$top"/..?*; do [ -e "$f" ] || [ -L "$f" ] && set -- "$@" "$f"; done\n'
            + '[ $# -eq 0 ] || "$fo" move "$dest" "$@"\n'
    else
        script += 'set --; for f in "$src"/* "$src"/.[!.]* "$src"/..?*; do [ -e "$f" ] || [ -L "$f" ] && set -- "$@" "$f"; done\n'
            + '[ $# -eq 0 ] || "$fo" copy "$dest" "$@"\n'
    return ["sh", "-c", script, "sh", dest, source, fo]
}

function isArchive(path) { return /\.(zip|7z|rar|tar|tgz|tbz2?|txz|tar\.(gz|bz2|xz|zst))$/i.test(String(path || "")) }
