import QtQuick
import Quasar

// Company switcher menu (template "SWITCH COMPANY", 336 px): one row per company with its badge,
// name and status, a check on the one shown, Manage companies, and a footnote on what's separate.
Panel {
    id: root
    property var model: []        // [{ id, name, short, color, sub, subColor, current, alert }]
    property int unplaced: 0      // windows that opened in a company that isn't shown (which one is unclear)
    signal picked(string id)
    signal manageClicked()
    signal showUnplacedClicked()

    radius: 20
    tint: Theme.menuBg
    borderColor: Theme.white(0.11)
    shadowOffsetY: 24
    shadowBlur: 60
    shadowSpread: -18
    implicitWidth: 336
    implicitHeight: col.implicitHeight + 16

    Column {
        id: col
        x: 8; y: 8
        width: root.width - 16
        spacing: 3

        Text {
            leftPadding: 10; topPadding: 6; bottomPadding: 4
            text: "SWITCH COMPANY"
            color: Theme.textFaint
            font.family: Theme.fontUi; font.pixelSize: 11; font.weight: Font.DemiBold; font.letterSpacing: 1.2
        }

        Repeater {
            model: root.model
            delegate: Appear {
                id: rowWrap
                required property var modelData
                required property int index
                width: col.width
                height: 54
                order: index
                Pressable {
                    width: rowWrap.width; height: 54
                    radius: 14
                    color: rowWrap.modelData.current ? Theme.alpha(rowWrap.modelData.color, 0.10) : "transparent"
                    borderColor: rowWrap.modelData.current ? Theme.alpha(rowWrap.modelData.color, 0.32) : "transparent"
                    accessibleName: rowWrap.modelData.name + ", " + rowWrap.modelData.sub
                    Accessible.role: Accessible.RadioButton
                    Accessible.checked: rowWrap.modelData.current
                    onClicked: root.picked(rowWrap.modelData.id)

                    Rectangle {
                        id: badge
                        x: 8
                        anchors.verticalCenter: parent.verticalCenter
                        width: 38; height: 38; radius: 12
                        color: rowWrap.modelData.color
                        Text {
                            anchors.centerIn: parent
                            text: rowWrap.modelData.short
                            textFormat: Text.PlainText
                            color: Theme.accentInk
                            font.family: Theme.fontUi; font.pointSize: Theme.pt(13); font.weight: Font.ExtraBold
                        }
                        Rectangle {
                            visible: rowWrap.modelData.alert
                            x: parent.width - 7; y: -3
                            width: 10; height: 10; radius: 5
                            color: Theme.amber
                            border.width: 2; border.color: "#0E101A"
                        }
                    }
                    Column {
                        anchors.left: badge.right; anchors.leftMargin: 12
                        anchors.right: check.left; anchors.rightMargin: 8
                        anchors.verticalCenter: parent.verticalCenter
                        spacing: 2
                        Text {
                            width: parent.width
                            text: rowWrap.modelData.name
                            textFormat: Text.PlainText
                            elide: Text.ElideRight
                            color: Theme.text
                            font.family: Theme.fontUi; font.pixelSize: 13; font.weight: Font.DemiBold
                        }
                        Text {
                            width: parent.width
                            text: rowWrap.modelData.sub
                            textFormat: Text.PlainText
                            elide: Text.ElideRight
                            color: rowWrap.modelData.subColor || Theme.textDim
                            font.family: Theme.fontUi; font.pointSize: Theme.pt(11.5)
                        }
                    }
                    QIcon {
                        id: check
                        anchors.right: parent.right; anchors.rightMargin: 12
                        anchors.verticalCenter: parent.verticalCenter
                        visible: rowWrap.modelData.current
                        path: Icons.check
                        size: 16
                        color: rowWrap.modelData.color
                    }
                }
            }
        }

        Pressable {
            visible: root.unplaced > 0
            width: col.width; height: 40
            radius: 12
            accessibleName: unplacedText.text
            onClicked: root.showUnplacedClicked()
            QIcon { x: 12; anchors.verticalCenter: parent.verticalCenter; path: Icons.layers; size: 15; color: Theme.amber }
            Text {
                id: unplacedText
                x: 36; width: parent.width - 46
                anchors.verticalCenter: parent.verticalCenter
                text: (root.unplaced === 1 ? "1 window in another company" : root.unplaced + " windows in other companies") + "  ·  Show"
                elide: Text.ElideRight
                color: Theme.text2
                font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
            }
        }

        Item { width: col.width; height: 9; Rectangle { x: 8; y: 4; width: col.width - 16; height: 1; color: Theme.white(0.08) } }

        Pressable {
            width: col.width; height: 38
            radius: 12
            accessibleName: "Manage companies"
            onClicked: root.manageClicked()
            QIcon { x: 12; anchors.verticalCenter: parent.verticalCenter; path: Icons.gear; size: 15; color: Theme.text3 }
            Text {
                x: 36
                anchors.verticalCenter: parent.verticalCenter
                text: "Manage companies"
                color: Theme.text
                font.family: Theme.fontUi; font.pixelSize: 13
            }
        }

        Text {
            width: col.width
            leftPadding: 10; rightPadding: 10; topPadding: 4; bottomPadding: 6
            wrapMode: Text.WordWrap
            text: "Each company has its own account, desktop, localhost, files, keys and sign-ins. Store apps and the clipboard are shared."
            color: Theme.textFaint
            font.family: Theme.fontUi; font.pointSize: Theme.pt(11.5)
            lineHeight: 1.25
        }
    }
}
