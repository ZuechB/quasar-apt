import QtQuick
import Quasar

// A Terminal window's body: one TerminalPane per tab — only the current one is visible; the others
// keep running and painting nothing — plus the close confirmation and the settings sheet. The tab
// strip (TerminalTabBar) sits in the title bar and shares `tabs`.
// Pure view: the app passes in the terminal engine (`engine`) and the settings (`cfg`).
//
//   newTab({ cwd, program, args })  — after the current tab; cwd defaults to the current tab's folder
Item {
    id: root
    property Component engine: null
    property var cfg: ({})
    property string home: ""
    property bool windowActive: true
    readonly property alias tabs: tabModel
    property int current: 0
    property Item currentPane: null
    readonly property string currentTitle: currentPane ? currentPane.tabTitle : "Terminal"
    readonly property string currentCwd: currentPane && currentPane.term ? currentPane.term.cwd : ""

    signal lastTabClosed()
    signal windowCloseConfirmed()
    signal settingChanged(string key, var value)
    signal openUrl(string url)

    property int _uid: 0

    ListModel { id: tabModel }

    function paneAt(i) { return panes.itemAt(i) }
    function indexOfUid(uid) {
        for (let i = 0; i < tabModel.count; ++i) if (tabModel.get(i).uid === uid) return i
        return -1
    }
    function focusCurrent() { Qt.callLater(() => { if (root.currentPane) root.currentPane.focusTerminal() }) }

    function newTab(req) {
        const r = req || {}
        const at = tabModel.count === 0 ? 0 : current + 1
        tabModel.insert(at, {
            uid: ++_uid,
            dir: r.cwd || currentCwd || "",
            prog: r.program || "",
            argsJson: JSON.stringify(r.args || []),
            title: "Terminal",
            activity: 0
        })
        current = at
    }
    function selectTab(i) { if (i >= 0 && i < tabModel.count) current = i }
    function nextTab(step) { if (tabModel.count > 1) current = (current + step + tabModel.count) % tabModel.count }
    function moveTab(from, to) {
        if (from === to || from < 0 || to < 0 || from >= tabModel.count || to >= tabModel.count) return
        tabModel.move(from, to, 1)
        if (current === from) current = to
        else if (from < current && to >= current) current--
        else if (from > current && to <= current) current++
    }
    function closeTab(i, force) {
        if (i < 0 || i >= tabModel.count) return
        const p = paneAt(i)
        if (!force && cfg.confirmClose !== false && p && p.busy) {
            const uid = tabModel.get(i).uid
            confirm.ask("Close this tab?", p.busyName + " is still running and will be stopped.", "Close tab",
                        () => root.closeTab(root.indexOfUid(uid), true))
            return
        }
        tabModel.remove(i)
        if (tabModel.count === 0) { root.lastTabClosed(); return }
        if (current >= tabModel.count) current = tabModel.count - 1
        else if (i < current) current--
        focusCurrent()
    }
    function busyNames() {
        const out = []
        for (let i = 0; i < tabModel.count; ++i) {
            const p = paneAt(i)
            if (p && p.busy) out.push(p.busyName)
        }
        return out
    }
    function listNames(n) {
        if (n.length <= 1) return n.join("")
        if (n.length === 2) return n[0] + " and " + n[1]
        if (n.length === 3) return n[0] + ", " + n[1] + " and " + n[2]
        return n[0] + ", " + n[1] + " and " + (n.length - 2) + " more"
    }
    function requestCloseWindow() {
        const busy = busyNames()
        if (cfg.confirmClose !== false && (tabModel.count > 1 || busy.length)) {
            confirm.ask(tabModel.count > 1 ? "Close " + tabModel.count + " tabs?" : "Close this window?",
                        busy.length ? listNames(busy) + (busy.length === 1 ? " is" : " are") + " still running and will be stopped."
                                    : "The shells in them will be closed.",
                        tabModel.count > 1 ? "Close all" : "Close", () => root.windowCloseConfirmed())
        } else {
            root.windowCloseConfirmed()
        }
    }
    function zoom(step) {
        const size = cfg.fontSize !== undefined ? cfg.fontSize : 12.5
        root.settingChanged("fontSize", step === 0 ? 12.5 : Math.max(8, Math.min(32, size + step)))
    }
    function openSettings() {
        settingsLoader.active = true          // created on first use
        settingsLoader.item.open = true
    }
    function find() { if (currentPane) currentPane.openFind() }
    function confirmPaste(pane, text, lines) {
        confirm.ask(lines === 1 ? "Paste this line?" : "Paste " + lines + " lines?",
                    "This program didn't ask for pasted text as a block, so each line goes in as if you typed it and pressed Enter. In a shell, every line runs as a command.",
                    "Paste", () => { if (pane && pane.term) pane.term.pasteText(text) }, Theme.accent)
    }

    Repeater {
        id: panes
        model: tabModel
        delegate: TerminalPane {
            id: pane
            // Role names differ from TerminalPane's own properties: a `required property` named like
            // one of them would declare a second property that shadows it.
            required property int index
            required property string dir
            required property string prog
            required property string argsJson
            startDir: dir
            program: prog
            anchors.fill: parent
            visible: index === root.current
            active: index === root.current
            windowActive: root.windowActive
            engine: root.engine
            cfg: root.cfg
            home: root.home
            args: JSON.parse(argsJson)
            Component.onCompleted: if (active) root.currentPane = pane
            onActiveChanged: if (active) {
                root.currentPane = pane
                tabModel.setProperty(index, "activity", 0)
            }
            onTabTitleChanged: tabModel.setProperty(index, "title", tabTitle)
            onActivityRaised: (level) => {
                if (!active && level > tabModel.get(index).activity) tabModel.setProperty(index, "activity", level)
            }
            onCloseRequested: root.closeTab(index, true)
            onNewTabRequested: root.newTab()
            onSettingsRequested: root.openSettings()
            onLinkOpened: (url) => root.openUrl(url)
            onZoom: (steps) => root.zoom(steps)
            onPasteConfirm: (text, lines) => root.confirmPaste(pane, text, lines)
        }
    }

    Dialog {
        id: confirm
        property string action: "Close"
        property color tone: Theme.danger
        property var pending: null
        function ask(t, m, a, then, color) {
            title = t; message = m; action = a; pending = then
            tone = color !== undefined ? color : Theme.danger
            open = true
        }
        onDismissed: { open = false; pending = null; root.focusCurrent() }
        buttons: [
            Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: confirm.dismissed() },
            Button {
                text: confirm.action; variant: "primary"; size: 38; tone: confirm.tone
                onClicked: {
                    const then = confirm.pending
                    confirm.pending = null
                    confirm.open = false
                    if (then) then()
                    root.focusCurrent()
                }
            }
        ]
    }

    Loader {
        id: settingsLoader
        anchors.fill: parent
        z: 1000
        active: false
        sourceComponent: TerminalSettingsSheet {
            cfg: root.cfg
            onChanged: (key, value) => root.settingChanged(key, value)
            onDismissed: { open = false; root.focusCurrent() }
        }
    }
}
