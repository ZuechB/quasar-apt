import QtQuick
import QtQuick.Shapes
import Quasar

// Discover hero (template "EDITOR'S PICK"): radius 22, min-height 220, padding 26/28, amber glow
// top-right + accent glow bottom-left over #10131E, orbit drawing top-right (its amber dash orbits
// only when ambient motion is on and the window is visible), Get / Installing (+ Cancel) / Open + Details.
Item {
    id: root
    property var app: null            // catalog entry merged with state ("get"|"queued"|"busy"|"open"|"failed"), progress, cancellable, cancelling
    signal getClicked()
    signal openClicked()
    signal cancelClicked()
    signal detailClicked()

    implicitHeight: 230
    width: parent ? parent.width : 700

    Shape {
        anchors.fill: parent
        layer.enabled: Theme.softwareRender      // clips when scrolled away (see Theme.softwareRender)
        ShapePath {
            strokeColor: Theme.white(0.08)
            strokeWidth: 1
            fillColor: "#10131E"
            PathRectangle { x: 0.5; y: 0.5; width: root.width - 1; height: root.height - 1; radius: 22 }
        }
        ShapePath {
            strokeColor: "transparent"
            fillGradient: RadialGradient {
                centerX: root.width * 0.8; centerY: root.height * 0.2; centerRadius: 420
                focalX: centerX; focalY: centerY
                GradientStop { position: 0.0; color: Theme.alpha(Theme.amber, 0.22) }
                GradientStop { position: 0.6; color: "transparent" }
            }
            PathRectangle { x: 1; y: 1; width: root.width - 2; height: root.height - 2; radius: 21 }
        }
        ShapePath {
            strokeColor: "transparent"
            fillGradient: RadialGradient {
                centerX: root.width * 0.2; centerY: root.height * 1.2; centerRadius: 380
                focalX: centerX; focalY: centerY
                GradientStop { position: 0.0; color: Theme.accentTint }
                GradientStop { position: 0.6; color: "transparent" }
            }
            PathRectangle { x: 1; y: 1; width: root.width - 2; height: root.height - 2; radius: 21 }
        }
    }

    // Orbit drawing (template svg 420x260 at right:-20 top:-10, ellipses rotated -18deg).
    Item {
        id: orbit
        width: 420; height: 260
        x: root.width - width + 20; y: -10
        clip: false
        opacity: 0.9
        layer.enabled: Theme.softwareRender      // around the turned orbits, so they're drawn sharp
        Shape {
            anchors.fill: parent
            transform: Rotation { origin.x: 250; origin.y: 120; angle: -18 }
            ShapePath {
                strokeColor: Theme.white(0.12); fillColor: "transparent"; strokeWidth: 1
                PathAngleArc { centerX: 250; centerY: 120; radiusX: 150; radiusY: 42; startAngle: 0; sweepAngle: 360 }
            }
            ShapePath {
                strokeColor: Theme.white(0.18); fillColor: "transparent"; strokeWidth: 1
                PathAngleArc { centerX: 250; centerY: 120; radiusX: 100; radiusY: 28; startAngle: 0; sweepAngle: 360 }
            }
            ShapePath {
                strokeColor: Theme.amber; fillColor: "transparent"; strokeWidth: 2; capStyle: ShapePath.RoundCap
                PathAngleArc { id: dash; centerX: 250; centerY: 120; radiusX: 150; radiusY: 42; startAngle: 20; sweepAngle: 34 }
            }
            NumberAnimation {
                target: dash; property: "startAngle"
                from: 20; to: 380; duration: 9000
                loops: Animation.Infinite
                running: Theme.ambientMotion && root.visible
            }
        }
    }

    Column {
        anchors { left: parent.left; leftMargin: 28; right: parent.right; rightMargin: 28; bottom: parent.bottom; bottomMargin: 26 }
        spacing: 10
        Text {
            text: "EDITOR'S PICK"
            font.family: Theme.fontMono; font.pixelSize: 11; font.letterSpacing: 1.3
            color: Theme.amber
        }
        Text {
            text: root.app ? root.app.name : ""
            textFormat: Text.PlainText
            font.family: Theme.fontDisplay; font.pixelSize: 34; font.weight: Font.Medium; font.letterSpacing: -0.7
            color: Theme.text
        }
        Text {
            width: Math.min(380, parent.width)
            text: root.app ? root.app.blurb : ""
            textFormat: Text.PlainText
            wrapMode: Text.Wrap
            lineHeight: 1.1
            font.family: Theme.fontUi; font.pixelSize: 14
            color: Theme.text3
        }
        Row {
            spacing: 8
            topPadding: 6
            readonly property string st: root.app ? root.app.state : "get"
            Button {
                visible: parent.st === "get" || parent.st === "failed"
                text: parent.st === "failed" ? "Try again" : "Get"
                variant: "light"; size: 38; radius: 12
                onClicked: root.getClicked()
            }
            Rectangle {
                visible: parent.st === "busy" || parent.st === "queued"
                height: 38; radius: 12
                width: busyText.implicitWidth + 32
                color: Theme.white(0.1)
                Text {
                    id: busyText
                    anchors.centerIn: parent
                    text: parent.parent.st === "queued" ? "Queued"
                        : root.app && root.app.cancelling ? "Cancelling"
                        : (root.app && root.app.action === "update" ? "Updating " : "Installing ") + Math.round((root.app ? root.app.progress : 0) * 100) + "%"
                    font.family: Theme.fontUi; font.pixelSize: 13; font.features: { "tnum": 1 }
                    color: Theme.text
                }
            }
            Button {
                visible: (parent.st === "busy" || parent.st === "queued") && !!(root.app && root.app.cancellable)
                text: "Cancel"
                variant: "outline"; size: 38; radius: 12
                fg: Theme.text
                fontWeight: Font.Medium
                borderColor: Theme.white(0.16)
                accessibleName: !root.app ? "" : parent.st === "queued" ? "Take " + root.app.name + " out of the queue" : "Stop installing " + root.app.name
                onClicked: root.cancelClicked()
            }
            Button {
                visible: parent.st === "open"
                text: "Open"
                variant: "light"; size: 38; radius: 12
                onClicked: root.openClicked()
            }
            Button {
                text: "Details"
                variant: "outline"; size: 38; radius: 12
                fg: Theme.text
                fontWeight: Font.Medium
                borderColor: Theme.white(0.16)
                onClicked: root.detailClicked()
            }
        }
    }
}
