import QtQuick

// Invisible resize band around a window frame, drawn outside it (labwc's own resize area is gone
// for Quasar windows: they draw their own frame). Place it as `anchors.fill: frame;
// anchors.margins: -band`. Edges and L-shaped corners (reaching `corner` px along both edges) each
// show their resize cursor; the host window starts a compositor-driven resize on press
// (startSystemResize(edges)).
Item {
    id: root
    property int band: 8
    property int corner: 20
    signal resizeRequested(int edges)

    component Zone: MouseArea {
        property int edges: 0
        acceptedButtons: Qt.LeftButton
        onPressed: root.resizeRequested(edges)
    }

    readonly property int _c: Math.min(corner, Math.floor(Math.min(width, height) / 2))

    // Sides, between the corners.
    Zone { edges: Qt.TopEdge; cursorShape: Qt.SizeVerCursor; x: root._c; width: root.width - 2 * root._c; height: root.band }
    Zone { edges: Qt.BottomEdge; cursorShape: Qt.SizeVerCursor; x: root._c; y: root.height - root.band; width: root.width - 2 * root._c; height: root.band }
    Zone { edges: Qt.LeftEdge; cursorShape: Qt.SizeHorCursor; y: root._c; width: root.band; height: root.height - 2 * root._c }
    Zone { edges: Qt.RightEdge; cursorShape: Qt.SizeHorCursor; x: root.width - root.band; y: root._c; width: root.band; height: root.height - 2 * root._c }

    // Corners: two arms each.
    Zone { edges: Qt.TopEdge | Qt.LeftEdge; cursorShape: Qt.SizeFDiagCursor; width: root._c; height: root.band }
    Zone { edges: Qt.TopEdge | Qt.LeftEdge; cursorShape: Qt.SizeFDiagCursor; width: root.band; height: root._c }
    Zone { edges: Qt.TopEdge | Qt.RightEdge; cursorShape: Qt.SizeBDiagCursor; x: root.width - root._c; width: root._c; height: root.band }
    Zone { edges: Qt.TopEdge | Qt.RightEdge; cursorShape: Qt.SizeBDiagCursor; x: root.width - root.band; width: root.band; height: root._c }
    Zone { edges: Qt.BottomEdge | Qt.LeftEdge; cursorShape: Qt.SizeBDiagCursor; y: root.height - root.band; width: root._c; height: root.band }
    Zone { edges: Qt.BottomEdge | Qt.LeftEdge; cursorShape: Qt.SizeBDiagCursor; y: root.height - root._c; width: root.band; height: root._c }
    Zone { edges: Qt.BottomEdge | Qt.RightEdge; cursorShape: Qt.SizeFDiagCursor; x: root.width - root._c; y: root.height - root.band; width: root._c; height: root.band }
    Zone { edges: Qt.BottomEdge | Qt.RightEdge; cursorShape: Qt.SizeFDiagCursor; x: root.width - root.band; y: root.height - root._c; width: root.band; height: root._c }
}
