import QtQuick
import Quickshell
import Quickshell.Io

// Runs one command off the UI thread and reports it line by line. Keeps the last `tailLines` lines
// of stderr + stdout so a failure can show its real cause behind a "Details" disclosure.
//   Cmd { id: job; onLine: (l) => …; onFinished: (code) => … }   job.run(["flatpak", "list"])
Process {
    id: root
    property int tailLines: 400
    property var tail: []
    property string lastLine: ""
    signal line(string text)
    signal errorLine(string text)
    signal finished(int code)

    // env: { NAME: "value" } added for this run. Passed through /usr/bin/env, because Process's
    // `environment` (QVariantHash) can't take a JS object held in a var ("Cannot assign QJSValue").
    // input: optional text written to the program's stdin, which is then closed (EOF). Use it for
    // secrets and specs: argv shows up in `ps` and pkexec writes it to the journal.
    function run(cmd, env, input) {
        tail = []
        lastLine = ""
        _hasInput = input !== undefined && input !== null
        _input = _hasInput ? String(input) : ""
        stdinEnabled = _hasInput
        command = env ? ["env"].concat(Object.keys(env).map(k => k + "=" + env[k]), cmd) : cmd
        running = true
    }
    property bool _hasInput: false
    property string _input: ""
    onStarted: if (_hasInput) { write(_input); _input = ""; _hasInput = false; stdinEnabled = false }
    function cancel() { if (running) root.signal(2) }   // SIGINT: let the tool clean up
    // SIGTERM, for helpers that clean up on TERM (flatpak-run). Unlike INT it can't have been ignored
    // further up: a script's background jobs start with SIGINT ignored, and so does all they run.
    function terminate() { if (running) root.signal(15) }
    function kill() { if (running) root.signal(9) }
    function details() { return tail.join("\n") }

    function _keep(t) {
        tail.push(t)
        if (tail.length > tailLines) tail.splice(0, tail.length - tailLines)
    }

    stdout: SplitParser {
        onRead: (data) => { root._keep(data); root.lastLine = data; root.line(data) }
    }
    stderr: SplitParser {
        onRead: (data) => { root._keep(data); root.errorLine(data) }
    }
    onExited: (exitCode, exitStatus) => root.finished(exitCode)
}
