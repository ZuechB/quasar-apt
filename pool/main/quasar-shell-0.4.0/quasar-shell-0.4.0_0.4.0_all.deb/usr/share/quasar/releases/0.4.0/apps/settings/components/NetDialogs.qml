import QtQuick
import Quasar

// The dialogs of Network & Internet's VPN, Mobile hotspot and Encrypted DNS pages, in one place so
// Settings' shell.qml only has one line for them. Pure view (the preview passes stand-ins): each dialog is
// bound to its service's state (open while that state is set) and calls back into the service:
//   vpnSvc      services/Vpn.qml          sheet (a VPN's actions), form (sign in / rename), ask, chooserOpen
//   hotspotSvc  services/Hotspot.qml      formOpen (name and password), secret, copyPassword()
//   dnsSvc      services/EncryptedDns.qml form (NextDNS ID / another server)
Item {
    id: root
    property var vpnSvc: null
    property var hotspotSvc: null
    property var dnsSvc: null
    property string home: "/home/you"
    property string drives: ""
    property string vpnFolder: ""             // where "Add a VPN" opens (default: Downloads)
    anchors.fill: parent

    // ---- VPN: one VPN's actions -----------------------------------------------------------------------
    Dialog {
        id: vpnSheet
        readonly property var s: root.vpnSvc ? root.vpnSvc.sheet : null
        open: s !== null && !(root.vpnSvc.form) && !(root.vpnSvc.ask)
        modal: true
        title: s ? s.name : ""
        message: s ? s.detail + (s.state === "on" ? "  ·  Connected" : s.needsLogin ? "  ·  Needs a sign-in" : "") : ""
        onDismissed: root.vpnSvc.sheetUuid = ""
        SettingsRow {
            width: parent.width
            visible: !!vpnSheet.s && vpnSheet.s.canAutostart
            height: visible ? implicitHeight : 0          // the body is sized by childrenRect, hidden rows too
            label: "Connect when this PC starts"
            sub: "If the server can't be reached then, the internet waits for it"
            trailing: "toggle"
            checked: !!vpnSheet.s && vpnSheet.s.autostart
            busy: !!vpnSheet.s && vpnSheet.s.busy
            onToggled: root.vpnSvc.setAutostart(vpnSheet.s.uuid, !vpnSheet.s.autostart)
        }
        buttons: [
            Button { text: "Remove"; variant: "outline"; tone: Theme.danger; size: 38
                     onClicked: root.vpnSvc.askRemove(vpnSheet.s.uuid) },
            Button { text: "Rename"; variant: "outline"; size: 38
                     onClicked: root.vpnSvc.form = { kind: "rename", uuid: vpnSheet.s.uuid, name: vpnSheet.s.name } },
            Button {
                text: !vpnSheet.s ? "" : vpnSheet.s.state === "off" ? "Connect" : "Disconnect"
                variant: "primary"; size: 38
                busy: !!vpnSheet.s && vpnSheet.s.busy
                onClicked: {
                    const s = vpnSheet.s
                    root.vpnSvc.sheetUuid = ""
                    if (s.state === "off") root.vpnSvc.connect(s.uuid)
                    else root.vpnSvc.disconnect(s.uuid)
                }
            }
        ]
    }

    // ---- VPN: sign in, or rename ------------------------------------------------------------------------
    Dialog {
        id: vpnForm
        readonly property var f: root.vpnSvc ? root.vpnSvc.form : null
        readonly property bool login: !!f && f.kind === "login"
        readonly property var needs: login ? (f.needs || []) : []
        readonly property bool wantsUser: login && (needs.indexOf("user") >= 0 || needs.indexOf("password") >= 0)
        readonly property bool wantsKey: login && needs.indexOf("keyPassword") >= 0
        open: f !== null
        modal: true
        title: !f ? "" : login ? "Sign in to " + f.name : "Rename the VPN"
        message: login ? "The user name and password your VPN provider gave you. They're kept on this PC for this VPN only." : ""
        onDismissed: root.vpnSvc.form = null
        onOpenChanged: {
            if (open) {
                vpnUser.text = ""; vpnPass.text = ""; vpnKey.text = ""
                vpnName.text = f && !login ? f.name : ""
                if (login) (wantsUser ? vpnUser : vpnKey).focusInput(); else vpnName.focusInput()
            } else { vpnPass.text = ""; vpnKey.text = "" }
        }
        function submit() {
            if (!saveBtn.enabled) return
            if (login) root.vpnSvc.submitLogin(wantsUser ? vpnUser.text.trim() : null, wantsUser ? vpnPass.text : null,
                                            wantsKey ? vpnKey.text : "")
            else root.vpnSvc.rename(f.uuid, vpnName.text.trim())
        }
        Column {
            width: parent.width
            spacing: 10
            TextField { id: vpnUser; width: parent.width; visible: vpnForm.wantsUser; placeholder: "User name"; glyph: Icons.user
                        onAccepted: vpnPass.focusInput() }
            TextField { id: vpnPass; width: parent.width; visible: vpnForm.wantsUser; placeholder: "Password"; password: true; glyph: Icons.key
                        onAccepted: vpnForm.wantsKey ? vpnKey.focusInput() : vpnForm.submit() }
            TextField { id: vpnKey; width: parent.width; visible: vpnForm.wantsKey; placeholder: "Password for the VPN's key"; password: true
                        glyph: Icons.lock; onAccepted: vpnForm.submit() }
            TextField { id: vpnName; width: parent.width; visible: !vpnForm.login; placeholder: "Work, Home…"; onAccepted: vpnForm.submit() }
        }
        buttons: [
            Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: root.vpnSvc.form = null },
            Button {
                id: saveBtn
                text: vpnForm.login ? "Save and connect" : "Rename"; variant: "primary"; size: 38
                enabled: vpnForm.login ? ((!vpnForm.wantsUser || (vpnUser.text.trim() !== "" && vpnPass.text !== ""))
                                          && (!vpnForm.wantsKey || vpnKey.text !== ""))
                                       : vpnName.text.trim().length > 0 && vpnName.text.trim().length <= 40
                onClicked: vpnForm.submit()
            }
        ]
    }

    // ---- VPN: confirm removing ---------------------------------------------------------------------------
    Dialog {
        open: !!root.vpnSvc && root.vpnSvc.ask !== null
        modal: true
        title: root.vpnSvc && root.vpnSvc.ask ? root.vpnSvc.ask.title : ""
        message: root.vpnSvc && root.vpnSvc.ask ? root.vpnSvc.ask.message : ""
        onDismissed: root.vpnSvc.ask = null
        buttons: [
            Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: root.vpnSvc.ask = null },
            Button { text: root.vpnSvc && root.vpnSvc.ask ? root.vpnSvc.ask.button : ""; variant: "primary"; tone: Theme.danger; size: 38
                     onClicked: root.vpnSvc.confirm() }
        ]
    }

    // ---- VPN: pick its file -------------------------------------------------------------------------------
    FileChooser {
        open: !!root.vpnSvc && root.vpnSvc.chooserOpen
        title: "Add a VPN"
        message: "Pick the WireGuard (.conf) or OpenVPN (.ovpn) file from your VPN provider, workplace or home server."
        home: root.home
        drives: root.drives
        nameFilters: ["*.conf", "*.ovpn"]
        kindText: "VPN files"
        folder: root.vpnFolder || root.home + "/Downloads"
        chooseText: "Add VPN"
        onChosen: (p) => root.vpnSvc.importFile(p)
        onDismissed: root.vpnSvc.chooserOpen = false
    }

    // ---- Mobile hotspot: name and password -----------------------------------------------------------------
    Dialog {
        id: hsForm
        readonly property var secret: root.hotspotSvc ? root.hotspotSvc.secret : null
        open: !!root.hotspotSvc && root.hotspotSvc.formOpen
        modal: true
        title: "Hotspot name and password"
        message: "Your phone shows the name in its Wi-Fi list. The password lets it join: anyone who has it can use this PC's internet."
            + (root.hotspotSvc && root.hotspotSvc.isOn ? " Saving restarts the hotspot." : "")
        onDismissed: root.hotspotSvc.formOpen = false
        onOpenChanged: if (open) fill(); else hsPass.text = ""
        onSecretChanged: if (open) fill()
        function fill() { hsName.text = secret ? secret.ssid : ""; hsPass.text = secret ? secret.password : "" }
        readonly property bool nameOk: hsName.text.trim().length > 0 && hsName.text.trim().length <= 32
        readonly property bool passOk: hsPass.text.length >= 8 && hsPass.text.length <= 63 && /^[\x20-\x7e]*$/.test(hsPass.text)
        Column {
            width: parent.width
            spacing: 10
            TextField { id: hsName; width: parent.width; placeholder: "Network name"; glyph: Icons.wifi; error: hsName.text !== "" && !hsForm.nameOk }
            TextField { id: hsPass; width: parent.width; placeholder: "Password (8 or more characters)"; glyph: Icons.key; mono: true
                        error: hsPass.text !== "" && !hsForm.passOk }
            Row {
                spacing: 8
                Button { text: "Copy password"; glyph: Icons.copy; variant: "soft"; size: 32; enabled: hsPass.text !== ""
                         onClicked: root.hotspotSvc.copyPassword(hsPass.text) }
                Button { text: "Make a new one"; glyph: Icons.refresh; variant: "soft"; size: 32
                         onClicked: root.hotspotSvc.save({ newPassword: true, keepOpen: true }) }
            }
        }
        buttons: [
            Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: root.hotspotSvc.formOpen = false },
            Button {
                text: "Save"; variant: "primary"; size: 38
                enabled: hsForm.nameOk && hsForm.passOk && !!hsForm.secret
                         && (hsName.text.trim() !== hsForm.secret.ssid || hsPass.text !== hsForm.secret.password)
                onClicked: root.hotspotSvc.save({ ssid: hsName.text.trim(), password: hsPass.text })
            }
        ]
    }

    // ---- Encrypted DNS: NextDNS ID / another server -----------------------------------------------------------
    Dialog {
        id: dnsForm
        readonly property var f: root.dnsSvc ? root.dnsSvc.form : null
        readonly property bool next: !!f && f.kind === "nextdns"
        open: f !== null
        modal: true
        title: next ? "Your NextDNS configuration" : "Another DNS server"
        message: next ? "The 6 letters and digits on your NextDNS Setup page (my.nextdns.io)."
                      : "A DNS-over-TLS server you trust. Its name is checked against its certificate."
        onDismissed: root.dnsSvc.form = null
        onOpenChanged: if (open) {
            const st = root.dnsSvc.st || {}
            dnsId.text = st.nextdnsId || ""
            dnsHost.text = st.host || ""
            dnsAddrs.text = (st.addresses || []).join(", ")
            ;(next ? dnsId : dnsHost).focusInput()
        }
        readonly property bool valid: next ? /^[A-Za-z0-9]{6}$/.test(dnsId.text.trim())
                                           : /^[A-Za-z0-9][A-Za-z0-9.-]*\.[A-Za-z][A-Za-z0-9-]*$/.test(dnsHost.text.trim())
        function submit() {
            if (!valid) return
            root.dnsSvc.submitForm(next ? { nextdnsId: dnsId.text.trim().toLowerCase() }
                                     : { host: dnsHost.text.trim().toLowerCase(),
                                         addresses: dnsAddrs.text.split(/[\s,]+/).filter(x => x !== "") })
        }
        Column {
            width: parent.width
            spacing: 10
            TextField { id: dnsId; width: parent.width; visible: dnsForm.next; placeholder: "abc123"; mono: true; onAccepted: dnsForm.submit() }
            TextField { id: dnsHost; width: parent.width; visible: !dnsForm.next; placeholder: "dns.example.com"; mono: true
                        glyph: Icons.server; onAccepted: dnsForm.submit() }
            TextField { id: dnsAddrs; width: parent.width; visible: !dnsForm.next; placeholder: "Its IP addresses (optional)"; mono: true
                        onAccepted: dnsForm.submit() }
        }
        buttons: [
            Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: root.dnsSvc.form = null },
            Button { text: "Turn on"; variant: "primary"; size: 38; enabled: dnsForm.valid; onClicked: dnsForm.submit() }
        ]
    }
}
