import QtQuick
import Quasar

// Files' right-click menu: Quasar's ContextMenu (the desktop's look) inside the window, flipped to
// stay inside it, with an item's flyout (New ›, Sort by ›) beside it. A click outside or Esc closes it.
//   items: ContextMenu items ([{ key, label, glyph, sub?, checked?, hint? } | { sep }]), bound by the
//   host so they follow what changes while it's open (Paste once the clipboard is checked); show(x, y).
Item {
    id: root
    anchors.fill: parent
    property bool open: false
    property real menuX: 0
    property real menuY: 0
    property var items: []
    signal chosen(string key)
    signal dismissed()

    function show(x, y) { menuX = x; menuY = y; open = true; card.forceActiveFocus() }
    function close() { open = false }

    visible: open
    z: 900

    MouseArea {
        anchors.fill: parent
        acceptedButtons: Qt.AllButtons
        onPressed: root.dismissed()
        onWheel: (w) => root.dismissed()
    }
    // Clicks on a menu's padding or between rows don't close it.
    MouseArea { x: card.x; y: card.y; width: card.width; height: card.height; acceptedButtons: Qt.AllButtons }
    MouseArea { visible: flyout.visible; x: flyout.x; y: flyout.y; width: flyout.width; height: flyout.height; acceptedButtons: Qt.AllButtons }

    ContextMenu {
        id: card
        x: Math.max(6, Math.min(root.menuX, root.width - width - 6))
        y: root.menuY + height > root.height - 6 ? Math.max(6, root.menuY - height) : root.menuY
        width: implicitWidth
        height: implicitHeight
        items: root.items
        focus: true
        onActivated: (key) => root.chosen(key)
        Keys.onEscapePressed: root.dismissed()
        Accessible.role: Accessible.PopupMenu
    }
    ContextMenu {
        id: flyout
        visible: root.open && card.openSub !== "" && card.openSubItems.length > 0
        items: card.openSubItems
        width: 236
        height: implicitHeight
        x: card.x + card.width + 4 + width > root.width - 6 ? card.x - width - 4 : card.x + card.width + 4
        y: Math.max(6, Math.min(card.y + card.openSubY - 6, root.height - height - 6))
        onActivated: (key) => root.chosen(key)
        HoverHandler { onHoveredChanged: card.holdSub = hovered }
    }
}
