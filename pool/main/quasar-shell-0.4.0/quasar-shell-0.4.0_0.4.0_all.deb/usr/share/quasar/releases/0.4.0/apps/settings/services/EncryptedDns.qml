import QtQuick
import Quickshell
import Quickshell.Io
import Quasar
import Quasar.Services
import "../components/dns.js" as D

// Settings > Network & Internet > Encrypted DNS (DNS over TLS through systemd-resolved). Reads with
// `quasar-net dns status` (any user); changes through `pkexec quasar-net dns set|off` (no password for
// active administrators), which checks the provider answers over TLS before switching and switches back
// if lookups don't come back encrypted. Whether it gets through on the network you're on now comes live
// from the state file (NetState.dns.reach), checked by the dispatcher on every new network.
//   QUASAR_NET=/path: a stand-in for quasar-net (tools/fake-net.py), for status too.
Scope {
    id: root
    property bool active: false              // the Network page or the Encrypted DNS page is shown
    property var st: null                    // quasar-net dns status
    property string busy: ""                 // "dns" (on/off/provider), "dns:check"
    property var form: null                  // { kind: "nextdns" | "custom" } for the server dialog
    signal notify(var banner)
    signal pick(string title, var options, string current, var done, string message)

    readonly property string exe: Quickshell.env("QUASAR_NET") || ""
    function helperCmd(args) { return (exe ? [exe] : ["pkexec", "/usr/libexec/quasar/quasar-net"]).concat(args) }
    readonly property var ctx: ({ busy: busy, reach: NetState.dns.reach, icons: Icons, theme: Theme })
    readonly property var networkRow: D.networkRow(st, ctx)
    readonly property var hero: D.hero(st, ctx)
    readonly property var groups: D.groups(st, ctx)
    readonly property bool isOn: D.isOn(st)

    onActiveChanged: if (active) refresh()
    Connections {
        target: NetState
        function onDnsChanged() { if (root.active) root.refresh() }
    }
    property bool _again: false
    function refresh() {
        if (statusProc.running) { _again = true; return }
        statusProc.running = true
    }
    Process {
        id: statusProc
        command: [root.exe || "/usr/libexec/quasar/quasar-net", "dns", "status"]
        stdout: StdioCollector {
            onStreamFinished: { try { const o = JSON.parse(text.trim().split("\n").pop()); if (o.result === "ok") root.st = o } catch (e) { } }
        }
        onExited: (code, status) => { if (root._again) { root._again = false; running = true } }
    }

    // ---- page actions --------------------------------------------------------------------------------
    function heroToggled() {
        if (busy !== "" || !st) return
        if (isOn) run("dns", ["dns", "off"])
        else turnOn(st.provider || "quad9")
    }
    function activate(key) {
        if (key === "dns:provider")
            pick("Look up websites through", D.PROVIDERS, st ? st.provider : "quad9", (k) => root.choose(k),
                 "Your lookups go to this service, encrypted. Pick one you trust: it can see which sites you visit.")
        else if (key === "dns:check")
            check()
    }
    function choose(provider) {
        if (provider === "nextdns" || provider === "custom") { form = { kind: provider }; return }
        turnOn(provider)
    }
    function turnOn(provider, extra) {
        if ((provider === "nextdns" && !(extra && extra.nextdnsId) && !(st && st.nextdnsId))
                || (provider === "custom" && !(extra && extra.host) && !(st && st.host))) {
            form = { kind: provider }
            return
        }
        const s = st || {}
        const spec = Object.assign({ provider: provider }, provider === "nextdns" ? { nextdnsId: s.nextdnsId }
                                                     : provider === "custom" ? { host: s.host, addresses: s.addresses || [] } : {},
                                   extra || {})
        run("dns", ["dns", "set"], JSON.stringify(spec) + "\n", (r) => root.notify({
            tone: "success", title: "Encrypted DNS is on",
            message: "Your lookups go encrypted to " + (r.name || "your provider") + "." }))
    }
    function submitForm(spec) {
        const f = form
        form = null
        if (f) turnOn(f.kind, spec)
    }
    function check() {
        busy = "dns:check"
        checkProc.running = true
    }
    Process {
        id: checkProc
        command: [root.exe || "/usr/libexec/quasar/quasar-net", "dns", "check"]
        stdout: StdioCollector {
            onStreamFinished: {
                root.busy = ""
                let reach = ""
                try { reach = JSON.parse(text.trim().split("\n").pop()).reach || "" } catch (e) { }
                if (reach === "ok") root.notify({ tone: "success", title: D.providerName(root.st) + " answers", message: "Your lookups are encrypted on this network." })
                else if (reach) { const t = D.reasonText(reach, D.providerName(root.st)); root.notify({ tone: "error", title: t.title, message: t.message }) }
            }
        }
    }

    // ---- one change at a time, through pkexec ------------------------------------------------------------
    property var _ok: null
    property var _result: null
    function run(key, args, input, ok) {
        busy = key
        _ok = ok || null
        _result = null
        job.run(helperCmd(args), undefined, input)
    }
    Cmd {
        id: job
        onLine: (l) => { try { const o = JSON.parse(l); if (o.result !== undefined) root._result = o } catch (e) { } }
        onFinished: (code) => {
            const ok = root._ok, r = root._result || {}
            root._ok = null
            root.busy = ""
            if (code === 0) {
                if (ok) ok(r)
            } else if (code === 127) {
                root.notify({ tone: "error", title: "Your account isn't allowed to change this", message: "Ask an administrator." })
            } else if (code !== 126 && r.reason !== "cancelled") {
                const t = D.reasonText(r.reason || "other", D.providerName(root.st))
                root.notify({ tone: "error", title: t.title, message: t.message || r.detail || "", details: job.details() })
            }
            root.refresh()
        }
    }
}
