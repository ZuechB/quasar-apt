import QtQuick

// Segmented control with a sliding pill (Performance: Lite / Balanced / Max), pill springs .6s.
Item {
    id: root
    property var model: ["Lite", "Balanced", "Max"]
    property int currentIndex: 0
    property string accessibleName: ""
    signal picked(int index)

    implicitHeight: 42
    Accessible.role: Accessible.PageTabList
    Accessible.name: accessibleName

    readonly property real _segW: (width - 6) / Math.max(1, model.length)

    Rectangle { anchors.fill: parent; radius: 13; color: Theme.white(0.06) }
    Rectangle {
        y: 3; height: parent.height - 6
        width: root._segW
        x: 3 + root.currentIndex * root._segW
        radius: 10
        color: Theme.white(0.14)
        Behavior on x { NumberAnimation { duration: Motion.dur(Motion.pill); easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.spring } }
    }
    Row {
        x: 3; y: 3
        Repeater {
            model: root.model
            delegate: Item {
                required property int index
                required property var modelData
                width: root._segW
                height: root.height - 6
                activeFocusOnTab: true
                Accessible.role: Accessible.PageTab
                Accessible.name: modelData
                Accessible.onPressAction: root.picked(index)
                Keys.onSpacePressed: root.picked(index)
                Keys.onReturnPressed: root.picked(index)
                Text {
                    anchors.centerIn: parent
                    text: modelData
                    font.family: Theme.fontUi
                    font.pointSize: Theme.pt(12.5)
                    font.weight: Font.Medium
                    color: index === root.currentIndex ? Theme.text : Theme.textMuted
                }
                Rectangle {
                    anchors.fill: parent; radius: 10; color: "transparent"
                    border.width: 2; border.color: Theme.accent; visible: parent.activeFocus
                }
                MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: root.picked(index) }
            }
        }
    }
}
