import QtQuick
import Quasar.Native.Window

// AppWindow's link to the compositor: custom margins + opaque region (native/quasar-native,
// src/WindowShape.h). A file of its own, so that without the plugin only this file fails to load
// and AppWindow falls back to an opaque, square window.
WindowShape { }
