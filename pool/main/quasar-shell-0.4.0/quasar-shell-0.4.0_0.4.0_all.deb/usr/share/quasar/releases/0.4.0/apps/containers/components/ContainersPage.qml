import QtQuick
import Quasar
import "Format.js" as Format

// Containers page: the engine card (state, Clean up, Stop; start with the PC) and the containers —
// Compose projects first, each with project-wide Start/Stop, Restart and Remove — then the others.
Column {
    id: root
    property var containers: []
    property var busy: ({})
    property string version: ""
    property bool autostart: false
    property bool sysBusy: false
    property var df: null
    signal containerAction(var container, string action)
    signal projectAction(string project, string action)
    signal openPort(int port)
    signal cleanUp()
    signal engineAction(string action)

    spacing: 0
    width: parent ? parent.width : 700

    readonly property var projects: {
        const out = []
        for (const c of containers) if (c.project && out.indexOf(c.project) < 0) out.push(c.project)
        return out.sort()
    }
    readonly property var loose: containers.filter(c => !c.project)
    readonly property int running: containers.filter(c => c.state === "running").length
    readonly property bool cleaning: Object.keys(busy).some(k => k.startsWith("prune:"))

    HeroCard {
        width: parent.width
        glyph: Icons.layers
        iconBg: Theme.alpha("#7AB8FF", 0.16)
        iconFg: "#7AB8FF"
        title: "Docker is running"
        sub: [root.version ? "Engine " + root.version : "",
              root.containers.length ? root.running + " of " + root.containers.length + " containers running" : "No containers yet",
              root.df ? Format.bytes(root.df.used) + " on disk" : ""].filter(x => x).join("  ·  ")
        Row {
            spacing: 8
            Button {
                text: root.cleaning ? "Cleaning up" : "Clean up…"
                glyph: Icons.trash
                busy: root.cleaning
                enabled: !root.cleaning
                variant: "soft"; size: 34
                onClicked: root.cleanUp()
            }
            Button {
                text: "Stop"
                glyph: Icons.stop
                enabled: !root.sysBusy
                variant: "outline"; size: 34
                onClicked: root.engineAction("stop")
            }
        }
    }
    Item { width: 1; height: 10 }
    Rectangle {
        width: parent.width
        height: 64
        radius: 16
        color: Theme.white(0.035)
        border.width: 1; border.color: Theme.white(0.06)
        Column {
            anchors { left: parent.left; leftMargin: 16; right: autoSwitch.left; rightMargin: 16; verticalCenter: parent.verticalCenter }
            spacing: 2
            Text {
                text: "Start Docker with the PC"
                font.family: Theme.fontUi; font.pixelSize: 14; font.weight: Font.DemiBold
                color: Theme.text
            }
            Text {
                width: parent.width
                elide: Text.ElideRight
                text: "Needed for containers that should always run. Otherwise Docker starts the first time something uses it."
                font.family: Theme.fontUi; font.pixelSize: 12
                color: Theme.textDim
            }
        }
        QSwitch {
            id: autoSwitch
            anchors { right: parent.right; rightMargin: 16; verticalCenter: parent.verticalCenter }
            checked: root.autostart
            enabled: !root.sysBusy
            opacity: enabled ? 1 : 0.5
            accessibleName: "Start Docker with the PC"
            onToggled: root.engineAction("autostart")
        }
    }

    // Compose projects.
    Repeater {
        model: root.projects
        Column {
            id: proj
            required property var modelData
            readonly property var members: root.containers.filter(c => c.project === modelData)
            readonly property bool anyRunning: members.some(c => c.state === "running")
            readonly property bool working: !!root.busy["project:" + modelData]
            width: root.width
            spacing: 0
            Item { width: 1; height: 24 }
            Item {
                width: parent.width
                height: 34
                Row {
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: 10
                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        text: proj.modelData
                        font.family: Theme.fontDisplay; font.pixelSize: 17; font.weight: Font.Medium
                        color: Theme.text
                    }
                    Chip {
                        anchors.verticalCenter: parent.verticalCenter
                        text: "Compose  ·  " + proj.members.length + (proj.members.length === 1 ? " service" : " services")
                        glyph: Icons.layers
                    }
                }
                Row {
                    anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                    spacing: 2
                    Spinner { visible: proj.working; anchors.verticalCenter: parent.verticalCenter; size: 16 }
                    Item { visible: proj.working; width: 8; height: 1 }
                    Button {
                        enabled: !proj.working
                        text: proj.anyRunning ? "Stop" : "Start"
                        glyph: proj.anyRunning ? Icons.stop : Icons.play
                        variant: "ghost"; size: 30
                        onClicked: root.projectAction(proj.modelData, proj.anyRunning ? "stop" : "start")
                    }
                    Button {
                        visible: proj.anyRunning
                        enabled: !proj.working
                        text: "Restart"; glyph: Icons.cycle
                        variant: "ghost"; size: 30
                        onClicked: root.projectAction(proj.modelData, "restart")
                    }
                    Button {
                        enabled: !proj.working
                        text: "Remove"; glyph: Icons.trash
                        variant: "ghost"; size: 30
                        onClicked: root.projectAction(proj.modelData, "remove")
                    }
                }
            }
            Item { width: 1; height: 8 }
            ContainerList {
                width: parent.width
                containers: proj.members
                busy: root.busy
                onContainerAction: (c, a) => root.containerAction(c, a)
                onOpenPort: (p) => root.openPort(p)
            }
        }
    }

    // Everything else.
    Text {
        visible: root.loose.length > 0
        topPadding: 24; bottomPadding: 10
        text: root.projects.length ? "Other containers" : "Containers"
        font.family: Theme.fontDisplay; font.pixelSize: 17; font.weight: Font.Medium
        color: Theme.text
    }
    ContainerList {
        visible: root.loose.length > 0
        width: parent.width
        containers: root.loose
        busy: root.busy
        onContainerAction: (c, a) => root.containerAction(c, a)
        onOpenPort: (p) => root.openPort(p)
    }
    Text {
        visible: root.containers.length === 0
        width: Math.min(560, parent.width)
        topPadding: 24
        wrapMode: Text.Wrap
        lineHeight: 1.25
        text: "No containers yet. Download an image in Images and run it, or run docker compose up in a project folder. Containers show up here as soon as they exist."
        font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
        color: Theme.textDim
    }
}
