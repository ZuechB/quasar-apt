// Settings > Drivers & Hardware: page rows built from hw-detect's report (/run/quasar/hardware.json).
// Pure, so the Settings app (services/Hardware.qml) and the design preview share it.
//   ctx: { live, softwareRender, fallback (the reason, or ""), safe (Safe graphics switch), job, scanning,
//          icons, theme }
.pragma library

function kindName(k) {
    return ({ wifi: "Wi-Fi", ethernet: "Ethernet", bluetooth: "Bluetooth", audio: "Sound" })[k] || k
}

function kindGlyph(k, icons) {
    return ({ wifi: icons.wifi, ethernet: icons.ethernet, bluetooth: icons.bt, audio: icons.vol })[k] || icons.cpu
}

function offers(r) { return r && r.offers ? r.offers : [] }

// The offer behind a row key ("hw:nvidia", "hw:firmware:firmware-mediatek").
function offerFor(r, key) { return offers(r).find(o => "hw:" + o.id === key) || null }

// The recommended NVIDIA install, if any (the hero card's button).
function recommended(r) { return offers(r).find(o => o.id === "nvidia" && o.action === "install" && o.recommended) || null }

function offerRow(o, ctx) {
    return {
        key: "hw:" + o.id, label: o.title, sub: o.reason, glyph: ctx.icons.download,
        trailing: ctx.live ? "value" : "button",
        value: ctx.live ? "After installing Quasar" : (o.action === "remove" ? "Use open driver" : "Install"),
        busy: ctx.job === o.id
    }
}

function groups(r, ctx) {
    const t = ctx.theme, icons = ctx.icons
    if (!r)
        return [{ label: "Hardware", rows: [{ key: "hw:rescan", label: ctx.scanning ? "Checking this PC's hardware…" : "Hardware details aren't available yet",
                                              trailing: "button", value: "Check", busy: ctx.scanning }] }]
    const gpus = r.gpus || [], devices = r.devices || []
    const graphics = gpus.map(g => ({
        label: g.name, sub: g.driverLabel + (g.advice ? ". " + g.advice : ""), glyph: icons.monitor,
        trailing: "value", value: g.driver ? "In use" : "", valueColor: t.mint
    }))
    graphics.push({
        label: "Rendering",
        sub: ctx.fallback ? ctx.fallback + " Sign out or restart to try the graphics card again."
           : ctx.safe && ctx.softwareRender ? "Drawn in software: Safe graphics is on."
           : ctx.softwareRender ? "Drawn in software: this PC or virtual machine has no graphics acceleration."
           : "The desktop and apps draw with the graphics card.",
        trailing: "value",
        value: ctx.fallback ? "Safe graphics" : ctx.softwareRender ? "Software" : "Accelerated",
        valueColor: ctx.fallback ? t.amber : ctx.softwareRender ? t.textMuted : t.mint
    })
    if (!ctx.live)
        graphics.push({
            key: "hw:safe", label: "Safe graphics", glyph: icons.shield,
            sub: "Draw everything in software, without the graphics card. Slower, but it works when the graphics driver doesn't. Starts at your next sign-in.",
            trailing: "toggle", checked: !!ctx.safe
        })
    const nvidia = offers(r).filter(o => o.id === "nvidia").map(o => offerRow(o, ctx))
    const firmware = offers(r).filter(o => o.id.indexOf("firmware:") === 0).map(o => offerRow(o, ctx))
    const devs = devices.map(d => ({
        label: d.name, sub: kindName(d.kind) + (d.driver ? "  ·  " + d.driver : ""), glyph: kindGlyph(d.kind, icons),
        trailing: "value", value: d.working ? "Working" : "No driver", valueColor: d.working ? t.mint : t.amber
    }))
    const fw = r.firmware && r.firmware.installed ? r.firmware.installed.length : 0
    return [
        { label: "Graphics", rows: graphics.concat(nvidia) },
        { label: "Wi-Fi, Bluetooth & sound", rows: firmware.concat(devs.length ? devs : [{ label: "No Wi-Fi, Bluetooth or sound devices found", trailing: "none" }]) },
        { label: "This PC", rows: [
            { label: "Firmware", glyph: icons.cpu,
              sub: ctx.live ? (r.virtual ? "The live session carries firmware for most PCs. Installing Quasar in a virtual machine keeps all of it."
                                         : "The live session carries firmware for most PCs. Installing Quasar keeps Wi-Fi and Bluetooth firmware and what this PC's other hardware uses.")
                            : "Wi-Fi and Bluetooth firmware always stays installed. Firmware a device here needs but doesn't have is offered above.",
              trailing: "value", value: fw + (fw === 1 ? " package" : " packages") },
            { key: "hw:rescan", label: "Check hardware again", sub: "After you add or change a device", glyph: icons.refresh,
              trailing: "button", value: "Check", busy: ctx.scanning }
        ] }
    ]
}

// Why Settings' Network or Bluetooth page has no adapter to show, from hw-detect's report.
//   kind: "wifi" | "bluetooth"; seen: NetworkManager / BlueZ has one (any state: nothing to explain)
// -> null, or a page banner { tone, title, message, actionText, action } (action: an offer's row key
//    "hw:firmware:PKG", or "go:drivers"). hw-detect's `working` isn't trusted: btusb stays bound to an
//    adapter whose firmware failed to load.
function radioIssue(r, kind, seen) {
    if (seen || !r)
        return null
    const what = kindName(kind)
    const dev = (r.devices || []).find(d => d.kind === kind)
    const offer = offers(r).find(o => o.id.indexOf("firmware:") === 0 && (o.kinds || []).indexOf(kind) >= 0)
    if (offer)
        return { tone: "warning", title: (dev ? dev.name : "This PC's " + what) + " needs firmware",
                 message: offer.packages[0] + " isn't installed" + (r.live ? ". It's included once Quasar is installed."
                          : ". Connect with an Ethernet cable or your phone's USB tethering, then install it."),
                 actionText: r.live ? "" : "Install", action: r.live ? "" : "hw:" + offer.id }
    if (!dev)
        return null
    return { tone: "warning",
             title: dev.driver ? dev.name + " didn't start" : "Quasar has no driver for " + dev.name + " yet",
             message: dev.driver ? "Its driver (" + dev.driver + ") is loaded, but the " + what + " adapter didn't come up. Restart the PC to try again."
                                 : "The " + what + " adapter was found, but no driver in this version of Quasar supports it.",
             actionText: "Drivers & Hardware", action: "go:drivers" }
}

function hero(r, ctx) {
    const gpus = r && r.gpus ? r.gpus : []
    const g = gpus.find(x => x.bootVga) || gpus[0]
    if (!g)
        return null
    const rec = recommended(r)
    return {
        glyph: ctx.icons.monitor, title: g.name,
        sub: g.driverLabel + (rec ? ". NVIDIA's driver is recommended for this card." : ""),
        button: rec && !ctx.live && !ctx.job ? "Install NVIDIA's driver" : "", buttonPrimary: true,
        iconBg: rec ? ctx.theme.accent : ctx.theme.white(0.07), iconFg: rec ? ctx.theme.accentInk : ctx.theme.text3
    }
}
