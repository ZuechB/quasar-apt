import QtQuick
import Quickshell
import Quickshell.Io

// The Vault app's connection to `vaultd session` (JSON lines; see linux/system/vault/quasar_vault/
// session.py). request(op, args, done) sends one request; done(reply) gets {ok, …} or {ok: false,
// error, code}. The helper runs while the app does.
//   QUASAR_VAULTD=/path   another vaultd (tests)
Scope {
    id: root
    readonly property string vaultd: Quickshell.env("QUASAR_VAULTD") || "/usr/libexec/quasar/vaultd"
    property int _next: 1
    property var _waiting: ({})
    signal ready()

    function request(op, args, done) {
        const id = _next++
        const req = Object.assign({}, args || {}, { id: id, op: op })
        if (done) { const w = Object.assign({}, _waiting); w[id] = done; _waiting = w }
        proc.write(JSON.stringify(req) + "\n")
    }

    Process {
        id: proc
        running: true
        command: [root.vaultd, "session"]
        stdinEnabled: true
        onStarted: root.ready()
        stdout: SplitParser {
            onRead: (line) => {
                let r = null
                try { r = JSON.parse(line) } catch (e) { return }
                const done = root._waiting[r.id]
                if (done) {
                    const w = Object.assign({}, root._waiting); delete w[r.id]; root._waiting = w
                    done(r)
                }
            }
        }
        onExited: (code) => {
            // Everything waiting fails; the helper starts again for the next request.
            const w = root._waiting
            root._waiting = ({})
            for (const k in w) w[k]({ ok: false, error: "Vault stopped (exit " + code + ")", code: "failed" })
            restart.restart()
        }
    }
    Timer { id: restart; interval: 1000; onTriggered: proc.running = true }
}
