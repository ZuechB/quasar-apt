import QtQuick
import Quasar

// Inline rename box for a desktop icon or a Files tile/row (Windows-style): sits over the item's
// label, wraps long names and pre-selects the name without its extension. Enter = accepted(text),
// Esc = cancelled(). A list row sets horizontalAlignment to AlignLeft and its own fontSize.
Rectangle {
    id: root
    property bool error: false
    property int horizontalAlignment: TextInput.AlignHCenter
    property int fontSize: 12
    readonly property string text: input.text
    signal accepted(string text)
    signal cancelled()

    function begin(name, wholeName) {
        input.text = name
        input.forceActiveFocus()
        const dot = wholeName ? -1 : name.lastIndexOf(".")
        input.select(0, dot > 0 ? dot : name.length)
    }
    function focusInput() { input.forceActiveFocus() }
    // When the rename is over: give the keyboard back. A hidden field inside a FocusScope would
    // otherwise keep it, and the next Delete or Ctrl+A would go to its text.
    function release() { input.focus = false }

    implicitWidth: 124
    implicitHeight: Math.max(24, input.contentHeight + 8)
    radius: 6
    color: Theme.solid
    border.width: 1
    border.color: error ? Theme.alpha(Theme.danger, 0.85) : Theme.accent

    TextInput {
        id: input
        x: 5; y: 4
        width: root.width - 10
        wrapMode: TextInput.WrapAtWordBoundaryOrAnywhere
        horizontalAlignment: root.horizontalAlignment
        font.family: Theme.fontUi; font.pixelSize: root.fontSize
        color: Theme.text
        selectionColor: Theme.alpha(Theme.accent, 0.45)
        selectedTextColor: Theme.text
        selectByMouse: true
        maximumLength: 240
        validator: RegularExpressionValidator { regularExpression: /[^\/]*/ }
        Accessible.role: Accessible.EditableText
        Accessible.name: "Name"
        onTextEdited: root.error = false
        Keys.onReturnPressed: root.accepted(text)
        Keys.onEnterPressed: root.accepted(text)
        Keys.onEscapePressed: root.cancelled()
    }
}
