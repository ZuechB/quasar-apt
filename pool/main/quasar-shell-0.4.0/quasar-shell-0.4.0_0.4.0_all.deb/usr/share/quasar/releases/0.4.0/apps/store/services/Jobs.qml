import QtQuick
import Quickshell
import Quickshell.Io
import Quasar.Services
import "ErrorMap.js" as ErrorMap
import "../components/state.js" as State

// One queue for every install, update and removal (so two jobs never fight over the package lock).
// Flathub apps: /usr/libexec/quasar/flatpak-run (system installation for administrators — no
// password with Debian's flatpak policy — or a per-user installation for other accounts).
// Debian entries: pkexec /usr/libexec/quasar/quasar-pkg <verb> <entry id>; the root helper looks up
// the entry's packages, vendor feed and setup step itself (the shell's polkit agent asks for the
// password; the live session needs none).
// Developer tools: /usr/libexec/quasar/quasar-dev (mise, installed for this account: no password).
// An entry's `requires` (Rust needs the build tools) are queued in front of it; if one of them
// fails, the entry isn't installed either. Before installing, the free space is checked against
// the app plus any runtime it still needs; on the live USB, free memory counts as the disk.
// Cancel: anything still queued, and a running Flathub install or update (flatpak-run stops the
// transaction and takes back the runtimes it added). Debian packages (dpkg, as root) and developer
// tools (a half-unpacked toolchain) run to the end once they've started.
Scope {
    id: root
    property var catalog: null
    property var installed: null
    // [{ id, action, after: [ids], auto, spec, version, makeDefault, exact, purgeData, thenDefault }]
    property var queue: []
    // id -> { state: "queued" | "busy", progress, phase, action, cancellable, cancelling }
    property var states: ({})
    readonly property bool active: queue.length > 0 || runner !== null
    property var current: null             // the running job
    property var runner: null              // the Cmd running it
    signal failed(string id, var error)    // error = { tone, title, message, details }
    signal finished(string id, string action, var job)
    // The user stopped it (or took it out of the queue). also = queued entries that needed it and
    // were taken out with it.
    signal cancelled(string id, string action, var also)

    function stateOf(id) { return states[id] || null }

    // action: install | remove | update | default (developer tools). opts: { spec, version,
    // makeDefault, exact, purgeData, thenDefault }. Returns false when the entry is already queued.
    function enqueue(id, action, opts) {
        if (states[id] || (current && current.id === id)) return false
        const app = catalog.byId(id)
        if (!app) return false
        const act = action || "install"
        const after = []
        if (act === "install") {
            for (const req of (app.requires || [])) {
                const r = catalog.byId(req)
                if (!r || (installed && installed.isInstalled(r))) continue
                if (!states[req] && !(current && current.id === req)) enqueue(req, "install", { auto: true })
                after.push(req)
            }
        }
        queue = queue.concat([Object.assign({ id: id, action: act, after: after }, opts || {})])
        _set(id, { state: "queued", progress: 0, phase: "", action: act, cancellable: true, cancelling: false })
        _pump()
        return true
    }

    // Take a queued entry out of the queue, or stop the running one if it can be stopped.
    function cancel(id) {
        if (current && current.id === id) {
            if (!current.cancellable || current.cancelling) return
            current.cancelling = true
            _update(id, { phase: "Cancelling", cancellable: false, cancelling: true })
            // No runner yet = still checking free space; that check stops there (see `space`).
            // flatpak-run stops the transaction on TERM and takes back what it had added.
            if (runner) runner.terminate()
            return
        }
        const job = queue.find(j => j.id === id)
        if (!job) return
        const also = _dropQueued(id)
        root.cancelled(id, job.action, also)
    }

    // ---- internals ------------------------------------------------------------------------
    function _set(id, s) { const m = Object.assign({}, states); m[id] = s; states = m }
    function _update(id, patch) { if (states[id]) _set(id, Object.assign({}, states[id], patch)) }
    function _clear(id) { const m = Object.assign({}, states); delete m[id]; states = m }
    function _dependents(id) { return queue.filter(j => (j.after || []).indexOf(id) >= 0).map(j => j.id) }

    // Removes a queued job, the queued jobs that were waiting for it, and the requirements that were
    // queued only for it (Build tools that nothing else needs any more). Returns the ids taken out
    // besides `id`.
    function _dropQueued(id) {
        const job = queue.find(j => j.id === id)
        if (!job) return []
        queue = queue.filter(j => j.id !== id)
        _clear(id)
        let also = []
        for (const d of _dependents(id)) also = also.concat([d], _dropQueued(d))
        for (const r of (job.after || [])) {
            const req = queue.find(j => j.id === r)
            if (req && req.auto && _dependents(r).length === 0) also = also.concat([r], _dropQueued(r))
        }
        return also
    }

    function _pump() {
        if (current || queue.length === 0) return
        const job = queue[0]
        queue = queue.slice(1)
        const app = catalog.byId(job.id)
        // Only Flathub installs and updates can stop part-way (flatpak-run cleans up). A Flathub
        // removal takes seconds; dpkg is never interrupted (and pkexec runs it as root); a
        // half-unpacked developer toolchain helps nobody.
        const canStop = app.source === "flathub" && job.action !== "remove"
        current = Object.assign({ step: 1, steps: 1, cancellable: canStop, cancelling: false }, job)
        _set(job.id, { state: "busy", progress: 0, phase: "Preparing", action: job.action, cancellable: canStop, cancelling: false })
        if (job.action === "install" && app.size && app.size.installed) {
            // Where it lands: per-user tools and Flatpaks of non-admins in the home folder, system
            // Flatpaks in /var/lib/flatpak, Debian packages on the root filesystem.
            space.path = app.source === "mise" || (app.source === "flathub" && !Platform.isAdmin) ? Platform.home
                       : app.source === "flathub" ? "/var/lib/flatpak" : "/"
            space.app = app
            space.running = true          // continues in _start() once the space is known
        } else {
            _start()
        }
    }

    function _start() {
        const job = current
        const app = catalog.byId(job.id)
        if (app.source === "flathub") {
            // Installs go to the system installation for administrators, else to this account's. An
            // update or removal goes where the app is (it may have been installed by another account).
            const userScope = job.action === "install" ? !Platform.isAdmin : (!installed || installed.scopeOf(app.id) === "user")
            const op = job.action === "remove" ? "uninstall" : job.action
            const target = job.action === "install" ? State.refOf(app) : app.id
            runner = flatpakCmd
            flatpakCmd.run(["/usr/libexec/quasar/flatpak-run", op, target].concat(userScope ? ["--user"] : []))
        } else if (app.source === "mise") {
            runner = devCmd
            const track = app.track || "major"
            let args
            if (job.action === "install") {
                const spec = job.spec || ((app.channels || [])[0] || {}).spec || "latest"
                const makeDefault = job.makeDefault !== undefined ? job.makeDefault : !(installed && installed.isInstalled(app))
                args = ["install", app.tool, spec, "--track", track].concat(makeDefault ? ["--default"] : [])
            } else if (job.action === "remove") {
                args = ["remove", app.tool].concat(job.version ? [job.version] : [])
            } else if (job.action === "default") {
                args = ["default", app.tool, job.version, "--track", track].concat(job.exact ? ["--exact"] : [])
            } else {
                args = ["upgrade", app.tool]
            }
            // Installed for the account of the company that is shown (company environments), else for you.
            devCmd.run(Companies.wrapExec(["/usr/libexec/quasar/quasar-dev"].concat(args)))
        } else if (app.source === "debfile") {
            // A .deb the user opened (services/DebFiles.qml): quasar-debfile reads the file on stdin, so
            // root never opens a path the user names, and installs it only if it's the file that was
            // checked (its sha256). `exec` keeps the Store as pkexec's parent.
            runner = debCmd
            if (job.action === "remove") debCmd.runHelper(["remove", app.pkgs[0]])
            else debCmd.run(["sh", "-c", 'exec pkexec /usr/libexec/quasar/quasar-debfile install "$1" < "$2"', "sh", app.sha256, app.file])
        } else {
            runner = pkgCmd
            const verb = job.action === "remove" ? "remove" : job.action === "update" ? "upgrade-ids" : "install"
            pkgCmd.runHelper([verb, app.id].concat(job.action === "remove" && job.purgeData ? ["--purge-data"] : []))
        }
    }

    function _line(l) {
        if (!current) return
        let m = l.match(/^STEP (\d+)\/(\d+)/)
        if (m) { current.step = +m[1]; current.steps = Math.max(1, +m[2]); return }
        m = l.match(/^PROGRESS (\d+)/)
        if (m) {
            const pct = Math.min(100, +m[1]) / 100
            const overall = Math.min(0.99, ((current.step - 1) + pct) / current.steps)
            const s = states[current.id]
            if (s && overall > s.progress) _update(current.id, { progress: overall })
            return
        }
        m = l.match(/^INSTALLED (\S+) (\S+)/)
        if (m) { current.installedVersion = m[2]; return }
        m = l.match(/^PHASE (.+)/)
        if (m && !current.cancelling) _update(current.id, { phase: m[1] })
    }

    function _done(code, log) {
        const job = current
        const app = catalog.byId(job.id)
        runner = null
        current = null
        _clear(job.id)
        // Stopped by the user (flatpak-run exits 130 once it has cleaned up). A job that finished
        // before the stop reached it (exit 0) counts as done: the app is there.
        if (job.cancelling && code !== 0) {
            let also = []
            for (const d of _dependents(job.id)) also = also.concat([d], _dropQueued(d))
            root.cancelled(job.id, job.action, also)
            if (installed) installed.refresh()
            _pump()
            return
        }
        const err = code === 0 ? null : ErrorMap.describe(log, code, app, job.action, Platform.live)
        if (err) {
            // Entries waiting for this one (e.g. Rust for the build tools) can't be installed now.
            const deps = _dependents(job.id)
            if (deps.length) {
                const names = deps.map(d => (catalog.byId(d) || { name: d }).name)
                err.message += " " + names.join(" and ") + (deps.length > 1 ? " need it" : " needs it") + ", so " + (deps.length > 1 ? "they weren't" : "it wasn't") + " installed either."
                for (const d of deps) _dropQueued(d)
            }
            root.failed(job.id, err)
        } else {
            root.finished(job.id, job.action, job)
        }
        if (installed) installed.refresh()
        _pump()
    }

    function _fail(err) {
        const job = current
        current = null
        _clear(job.id)
        for (const d of _dependents(job.id)) _dropQueued(d)
        root.failed(job.id, err)
        _pump()
    }
    // Cancelled while the free space was being checked: nothing has started yet.
    function _stopBeforeStart() {
        const job = current
        current = null
        _clear(job.id)
        let also = []
        for (const d of _dependents(job.id)) also = also.concat([d], _dropQueued(d))
        root.cancelled(job.id, job.action, also)
        _pump()
    }

    Cmd {
        id: flatpakCmd
        onLine: (l) => root._line(l)
        onFinished: (code) => root._done(code, details())
    }
    Cmd {
        id: devCmd
        onLine: (l) => root._line(l)
        onFinished: (code) => root._done(code, details())
    }
    Privileged {
        id: pkgCmd
        helper: "quasar-pkg"
        onLine: (l) => root._line(l)
        onErrorLine: (l) => root._line(l)
        onFinished: (code) => root._done(code, details())
    }
    Privileged {
        id: debCmd
        helper: "quasar-debfile"
        onLine: (l) => root._line(l)
        onErrorLine: (l) => root._line(l)
        onFinished: (code) => root._done(code, details())
    }

    // Free space where the app lands (see _pump); on the live USB that is RAM (tmpfs), whose pages can
    // be swapped out to zram (counted at half: they compress roughly 2:1).
    Process {
        id: space
        property var app: null
        property string path: "/"
        command: ["sh", "-c", "df -B1 --output=avail \"$1\" | tail -1; "
                            + "awk '/^MemAvailable:|^SwapFree:/ { print $1, $2 * 1024 }' /proc/meminfo", "sh", path]
        stdout: StdioCollector {
            onStreamFinished: {
                if (root.current && root.current.cancelling) { root._stopBeforeStart(); return }
                const lines = text.trim().split("\n")
                let avail = parseInt(lines[0]) || 0
                if (Platform.live) {
                    let mem = 0, swap = 0
                    for (const l of lines.slice(1)) {
                        const [k, v] = l.split(" ")
                        if (k === "MemAvailable:") mem = +v
                        if (k === "SwapFree:") swap = +v
                    }
                    avail = Math.min(avail, mem + swap / 2)
                }
                const app = space.app
                const rt = root.catalog ? root.catalog.runtimeSize(app) : (app.runtimeSize || 0)
                const need = (app.size.installed || 0) + (root.installed && !root.installed.hasRuntime(app.runtime) ? rt : 0)
                if (avail > 0 && need * 1.2 > avail) {
                    const gb = (b) => (b / 1e9).toFixed(1) + " GB"
                    root._fail({
                        tone: "error",
                        title: "Not enough space for " + app.name,
                        message: app.name + " needs about " + gb(need) + (rt ? " with its runtime" : "") + ", and " + gb(avail) + " is free."
                                 + (Platform.live ? " You're running from the installer USB, where apps are kept in memory: install Quasar to get the whole disk." : ""),
                        details: "needed " + need + " bytes x 1.2 margin, available " + avail + " bytes",
                        actionText: Platform.live ? "Install Quasar" : ""
                    })
                } else {
                    root._start()
                }
            }
        }
    }
}
