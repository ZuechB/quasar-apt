import QtQuick
import Quasar

// Store "Updates" (template sIsUpdates): title + Update all; one radius-16 box of rows (20px glyph,
// name 14/600, version line 12px, Update pill). Quasar only asks Flathub, Debian, the vendor feeds in
// use and the developer tools' download sites for updates when the user presses Check, so the first
// state explains that instead of showing stale data.
Column {
    id: root
    property var updates: []            // [{ id, name, ver, glyph, hue, icon }]
    property bool checked: false
    property bool checking: false
    property string error: ""
    signal checkClicked()
    signal updateClicked(string id)
    signal updateAllClicked()

    spacing: 14
    width: parent ? parent.width : 700

    Item {
        width: parent.width
        height: 34
        Text {
            anchors.verticalCenter: parent.verticalCenter
            text: "Updates"
            font.family: Theme.fontDisplay; font.pixelSize: 18; font.weight: Font.Medium
            color: Theme.text
        }
        Row {
            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
            spacing: 8
            Button {
                text: root.checking ? "Checking" : "Check for updates"
                busy: root.checking
                enabled: !root.checking
                variant: root.updates.length > 0 ? "soft" : "primary"; size: 34
                onClicked: root.checkClicked()
            }
            Button {
                visible: root.updates.length > 0
                text: "Update all"
                variant: "primary"; size: 34
                onClicked: root.updateAllClicked()
            }
        }
    }

    Rectangle {
        width: parent.width
        height: list.implicitHeight
        radius: 16
        color: Theme.white(0.035)
        border.width: 1; border.color: Theme.white(0.06)
        Column {
            id: list
            width: parent.width
            Repeater {
                model: root.updates
                Item {
                    required property int index
                    required property var modelData
                    width: list.width
                    height: 62
                    Rectangle { visible: index > 0; width: parent.width; height: 1; color: Theme.white(0.05) }
                    AppTile {
                        id: t
                        x: 14; anchors.verticalCenter: parent.verticalCenter
                        size: 36; radius: 11
                        hue: modelData.hue || Theme.accent
                        glyph: modelData.icon ? "" : Icons.get(modelData.glyph)
                        image: modelData.icon || ""
                        glyphSize: 18
                    }
                    Column {
                        anchors { left: t.right; leftMargin: 12; right: upd.left; rightMargin: 12; verticalCenter: parent.verticalCenter }
                        spacing: 2
                        Text { width: parent.width; elide: Text.ElideRight; text: modelData.name; textFormat: Text.PlainText; font.family: Theme.fontUi; font.pixelSize: 14; font.weight: Font.DemiBold; color: Theme.text }
                        Text { width: parent.width; elide: Text.ElideRight; text: modelData.ver; textFormat: Text.PlainText; font.family: Theme.fontUi; font.pixelSize: 12; color: Theme.textDim }
                    }
                    Button {
                        id: upd
                        anchors { right: parent.right; rightMargin: 14; verticalCenter: parent.verticalCenter }
                        text: "Update"
                        variant: "soft"; size: 30; pill: true
                        color: Theme.white(0.1); fg: modelData.hue || Theme.accent
                        onClicked: root.updateClicked(modelData.id)
                    }
                }
            }
            Text {
                visible: root.updates.length === 0
                width: list.width
                leftPadding: 14; rightPadding: 14; topPadding: 18; bottomPadding: 18
                wrapMode: Text.Wrap
                text: root.error !== "" ? root.error
                    : root.checking ? "Looking for newer versions…"
                    : root.checked ? "Everything is up to date."
                    : "Quasar only contacts Flathub, Debian and your developer tools' download sites when you ask. Press Check for updates to look for newer versions."
                font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
                color: root.error !== "" ? Theme.danger : Theme.textDim
            }
        }
    }
}
