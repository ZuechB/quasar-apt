import QtQuick
import Quasar

// Context menu (mockup role="menu"; the desktop's and Files'): 236px, items 36px with icon, hairline
// separators. An item may carry `checked` (a tick on the right, e.g. Show hidden files) or `hint` (its
// shortcut, dim, on the right).
// An item with `sub` (its own list of items, e.g. New ›) opens a flyout: it shows a chevron, and
// pointing at it or clicking it sets openSub / openSubY. The host draws the flyout (another
// ContextMenu) beside this one and sets holdSub while the pointer is on it. Pointing at another item
// closes the flyout after a short grace, so a diagonal move toward the flyout doesn't close it.
Panel {
    id: root
    radius: 16
    tint: Theme.menuBg
    borderColor: Theme.white(0.11)
    shadowOffsetY: 24
    shadowBlur: 60
    shadowSpread: -18

    property var items: []   // [{ key, label, glyph, sub?, checked?, hint? } | { sep: true }]
    signal activated(string key)

    property string openSub: ""          // key of the item whose flyout is open
    property real openSubY: 0            // that item's y in this menu
    property bool holdSub: false         // the pointer is on the flyout
    readonly property var openSubItems: {
        const it = items.find(i => !!i && i.key === openSub)
        return it && it.sub ? it.sub : []
    }
    // New items (e.g. Files' "Open with" list arriving a moment after the menu opened) keep an open
    // flyout open while its item is still there.
    onItemsChanged: if (!items.some(i => !!i && i.key === openSub && !!i.sub)) openSub = ""
    onHoldSubChanged: if (holdSub) closeSub.stop()
    function _point(item, y) {
        if (item.sub) { closeSub.stop(); openSub = item.key; openSubY = y }
        else if (openSub !== "") closeSub.restart()
    }

    implicitWidth: 236
    implicitHeight: col.implicitHeight + 12

    Timer { id: closeSub; interval: 280; onTriggered: if (!root.holdSub) root.openSub = "" }

    Column {
        id: col
        x: 6; y: 6
        width: root.width - 12
        spacing: 1
        Repeater {
            model: root.items
            delegate: Loader {
                id: row
                required property var modelData
                width: col.width
                sourceComponent: modelData.sep ? sepC : itemC
                Component {
                    id: sepC
                    Item { height: 9; Rectangle { x: 8; y: 4; width: col.width - 16; height: 1; color: Theme.white(0.08) } }
                }
                Component {
                    id: itemC
                    Pressable {
                        id: btn
                        readonly property bool hasSub: !!row.modelData.sub
                        readonly property bool hasTick: row.modelData.checked === true
                        readonly property string hint: row.modelData.hint || ""
                        height: 36; radius: 10
                        color: hasSub && root.openSub === row.modelData.key ? Theme.white(0.07) : "transparent"
                        accessibleName: row.modelData.label
                        Accessible.role: Accessible.MenuItem
                        Accessible.checkable: row.modelData.checked !== undefined
                        Accessible.checked: hasTick
                        onHoveredChanged: if (hovered) root._point(row.modelData, row.y + col.y)
                        onClicked: hasSub ? root._point(row.modelData, row.y + col.y) : root.activated(row.modelData.key)
                        QIcon { x: 10; anchors.verticalCenter: parent.verticalCenter; path: row.modelData.glyph; size: 16; color: Theme.text3 }
                        Text {
                            x: 36; width: parent.width - 46 - (btn.hasSub || btn.hasTick ? 20 : 0) - (hintText.visible ? hintText.width + 8 : 0)
                            elide: Text.ElideRight; anchors.verticalCenter: parent.verticalCenter
                            text: row.modelData.label; font.family: Theme.fontUi; font.pixelSize: 13; color: Theme.text
                        }
                        Text {
                            id: hintText
                            visible: btn.hint !== "" && !btn.hasSub && !btn.hasTick
                            anchors { right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter }
                            text: btn.hint; font.family: Theme.fontUi; font.pointSize: Theme.pt(11.5); color: Theme.textDim
                        }
                        QIcon {
                            visible: btn.hasSub || btn.hasTick
                            anchors { right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter }
                            path: btn.hasSub ? Icons.fwd : Icons.check; size: 14; strokeWidth: 2
                            color: btn.hasSub ? Theme.textDim : Theme.accent
                        }
                    }
                }
            }
        }
    }
}
