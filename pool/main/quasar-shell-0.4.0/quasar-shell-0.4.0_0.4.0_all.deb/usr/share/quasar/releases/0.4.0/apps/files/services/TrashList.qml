import QtQuick
import Qt.labs.folderlistmodel
import Quickshell
import Quasar

// What's in the Trash ($XDG_DATA_HOME/Trash, freedesktop layout shared with the desktop and Quasar AI's
// Undo all), for the Trash view: each item under its original name, with the folder it came from and
// when it was deleted (`fileop trash-list` reads the .trashinfo files). Listed only while a window
// shows the Trash, and again whenever the Trash changes.
Scope {
    id: root
    required property var ops
    property string home: Quickshell.env("HOME") || "/root"
    readonly property string dir: (Quickshell.env("XDG_DATA_HOME") || home + "/.local/share") + "/Trash"
    property int viewers: 0                    // windows showing the Trash
    property var rows: []

    onViewersChanged: if (viewers > 0) refresh()

    FolderListModel {
        folder: Theme.fileUrl(root.dir + "/files")
        showHidden: true
        showDotAndDotDot: false
        onCountChanged: changed.restart()
    }
    FolderListModel {
        folder: Theme.fileUrl(root.dir + "/info")
        showHidden: true
        showDotAndDotDot: false
        onCountChanged: changed.restart()
    }
    Timer { id: changed; interval: 150; onTriggered: if (root.viewers > 0) root.refresh() }

    function refresh() {
        ops.run(["trash-list"], null, (code, err, lines) => {
            root.rows = lines.filter(o => o && o.name && !o.error).map(o => {
                const original = o.path ? FileKit.baseName(o.path) : o.name
                const r = FileKit.row(original, root.dir + "/files/" + o.name, o.isDir, o.size || 0, o.deleted ? Date.parse(o.deleted) : 0)
                r.trashName = o.name
                r.origin = o.path ? FileKit.parentOf(o.path) : ""
                r.thumb = ""
                return r
            })
        })
    }
}
