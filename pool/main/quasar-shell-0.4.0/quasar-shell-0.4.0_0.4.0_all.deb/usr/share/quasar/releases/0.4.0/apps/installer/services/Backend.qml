import QtQuick
import Quickshell
import Quickshell.Io
import Quasar.Services

// Talks to the headless install backend (`AvaloniaShell.App --install-backend`, see
// src/AvaloniaShell.App/InstallBackend.cs): JSON lines on stdout, the install settings as one
// JSON line on stdin (so the password never shows up in a process list).
// QUASAR_INSTALL_BACKEND swaps the executable (tools/fake-install-backend.sh for UI tests).
Item {
    id: root
    readonly property string exe: Quickshell.env("QUASAR_INSTALL_BACKEND") || "/usr/lib/quasar/AvaloniaShell.App"
    readonly property var env: ({ DOTNET_SYSTEM_GLOBALIZATION_INVARIANT: "1" })

    // ---- disks ----------------------------------------------------------------------------------
    property var disks: []                 // [{ path, name, size, model, removable }]
    property bool listing: false
    property string listError: ""

    function listDisks() {
        if (lister.running) return
        listing = true
        listError = ""
        lister.run([exe, "--install-backend", "list-disks"], env)
    }
    Cmd {
        id: lister
        property bool gotReply: false
        onLine: (l) => {
            const o = root._parse(l)
            if (!o) return
            if (o.disks) { root.disks = o.disks; gotReply = true }
            else if (o.type === "error") { root.listError = o.message || ""; gotReply = true }
        }
        onFinished: (code) => {
            root.listing = false
            if (!gotReply && code !== 0) root.listError = "Quasar couldn't look for disks (code " + code + ")."
            gotReply = false
        }
    }

    // ---- install --------------------------------------------------------------------------------
    property int percent: 0
    property string step: ""
    property string message: ""
    property string error: ""
    readonly property bool installing: installer.running
    property var _tail: []
    property var _pending: null
    property bool _done: false
    signal finished()
    signal failed(string message)

    function install(cfg) {
        if (installer.running) return
        percent = 0; step = "Preparing"; message = "Starting the installer…"; error = ""
        _tail = []; _done = false
        _pending = cfg
        installer.running = true
    }
    function details() { return _tail.join("\n") }

    Process {
        id: installer
        command: ["env", "DOTNET_SYSTEM_GLOBALIZATION_INVARIANT=1", root.exe, "--install-backend", "install"]
        stdinEnabled: true
        onStarted: {
            installer.write(JSON.stringify(root._pending) + "\n")
            root._pending = null                     // don't keep the password around
        }
        stdout: SplitParser {
            onRead: (l) => {
                const o = root._parse(l)
                if (!o) { root._keep(l); return }
                if (o.type === "progress") {
                    root.percent = o.percent || 0
                    root.step = o.step || ""
                    root.message = o.message || ""
                } else if (o.type === "done") {
                    root._done = true
                } else if (o.type === "error") {
                    root.error = o.message || ""
                }
            }
        }
        stderr: SplitParser { onRead: (l) => root._keep(l) }
        onExited: (code, status) => {
            root._pending = null
            if (root._done && code === 0) { root.percent = 100; root.finished(); return }
            if (!root.error) root.error = code === 0 ? "The installer stopped before it finished."
                                                    : "The installer stopped unexpectedly (code " + code + ")."
            root.failed(root.error)
        }
    }

    // ---- repair: restore an installed PC's system from one of its snapshots ------------------------
    // `quasar-snapshot repair-scan|repair-list DEV|repair-restore DEV ID`, as root through the live
    // session's sudo. The installed PC's own GRUB is put back by the helper.
    //   QUASAR_SNAPSHOT=/path: a stand-in for the helper (UI tests).
    readonly property var snapCmd: Quickshell.env("QUASAR_SNAPSHOT") ? [Quickshell.env("QUASAR_SNAPSHOT")]
                                                                    : ["sudo", "-n", "/usr/libexec/quasar/quasar-snapshot"]
    property var repairDisks: []           // [{ device, size, model, version, snapshots: [...], old: [...] }]
    property bool repairLoading: false
    property string repairPhase: ""
    readonly property bool repairing: repairer.running
    property var _found: []
    signal repaired()
    signal repairFailed(string message)

    function scanRepair() {
        if (repairScan.running || repairList.running) return
        repairLoading = true
        repairDisks = []
        _found = []
        repairScan.run(snapCmd.concat(["repair-scan"]))
    }
    Cmd {
        id: repairScan
        property var disks: []
        onLine: (l) => { const o = root._parse(l); if (o && o.disks) disks = o.disks }
        onFinished: (code) => {
            root._found = disks.filter(d => d && d.device)
            disks = []
            root._listNext([])
        }
    }
    // One disk at a time; disks without a Quasar system on them (other btrfs) drop out.
    function _listNext(acc) {
        if (!_found.length) { repairDisks = acc; repairLoading = false; return }
        const d = _found.shift()
        repairList.acc = acc
        repairList.disk = d
        repairList.run(snapCmd.concat(["repair-list", d.device]))
    }
    Cmd {
        id: repairList
        property var acc: []
        property var disk: null
        property var got: null
        onLine: (l) => { const o = root._parse(l); if (o && o.snapshots) got = o }
        onFinished: (code) => {
            const a = acc.slice()
            if (got && disk) a.push(Object.assign({}, disk, got))
            got = null
            root._listNext(a)
        }
    }
    function restoreSnapshot(device, target) {
        if (repairer.running) return
        repairPhase = "Starting"
        repairer.run(snapCmd.concat(["repair-restore", device, String(target)]))
    }
    Cmd {
        id: repairer
        property bool ok: false
        onLine: (l) => {
            if (l.startsWith("PHASE ")) root.repairPhase = l.slice(6)
            const o = root._parse(l)
            if (o && o.type === "restored") ok = true
        }
        onFinished: (code) => {
            const ok = repairer.ok && code === 0
            repairer.ok = false
            root.repairPhase = ""
            if (ok) { root.repaired(); return }
            const err = repairer.details().split("\n").filter(l => l.startsWith("ERROR ")).map(l => l.slice(6)).pop()
            root.repairFailed(err || "The restore stopped unexpectedly (code " + code + ").")
        }
    }
    function repairDetails() { return repairer.details() }

    // ---- reboot ---------------------------------------------------------------------------------
    function reboot() { rebooter.run([exe, "--install-backend", "reboot"], env) }
    Cmd { id: rebooter }

    // ---- helpers --------------------------------------------------------------------------------
    function _parse(l) {
        const t = (l || "").trim()
        if (!t.startsWith("{")) return null
        try { return JSON.parse(t) } catch (e) { return null }
    }
    function _keep(l) {
        _tail.push(l)
        if (_tail.length > 400) _tail.splice(0, _tail.length - 400)
    }
}
