import QtQuick
import Quasar

// "<App> wants to receive connections" (services/NetGuard.qml): a card above the toasts, bottom right.
// Never takes the keyboard (a stray Enter can't allow anything) and doesn't dim the screen: it only
// asks. Allow opens the app (or for Terminal, just that port) to devices on home networks.
// Pure view: the host passes the prompt in and handles the two buttons.
Item {
    id: root
    property string appName: "An app"
    property string icon: ""                // the app's icon file, if it has one
    property string kind: "app"             // "app" | "port" (Terminal, or something without an app)
    property int port: 0
    property string networkName: ""
    property bool home: true
    property bool hasNetwork: true
    property bool busy: false
    signal allowClicked()
    signal notNowClicked()

    implicitWidth: 380
    implicitHeight: card.height

    readonly property string title: kind === "port" ? appName + " is waiting for connections"
                                                    : appName + " wants to receive connections"
    readonly property string detail: {
        const what = kind === "port" ? "port " + port : appName
        if (!hasNetwork) return "From another device (port " + port + "). Allow it on your home networks?"
        if (home) return kind === "port" ? "Allow port " + port + " for devices on " + networkName + "?"
                                         : "From devices on " + networkName + ", like your phone or another PC."
        return networkName + " is a public network. Allowing makes it one of your home networks, where devices can reach " + what + "."
    }

    Rectangle {
        id: card
        width: parent.width
        height: col.implicitHeight + 36
        radius: 20
        color: Theme.solid
        border.width: 1
        border.color: Theme.white(0.11)
        Accessible.role: Accessible.AlertMessage
        Accessible.name: root.title

        Column {
            id: col
            x: 18; y: 18
            width: parent.width - 36
            spacing: 12

            Row {
                width: parent.width
                spacing: 12
                Rectangle {
                    width: 42; height: 42; radius: 13
                    color: Theme.alpha(Theme.accent, 0.14)
                    Image {
                        anchors.centerIn: parent
                        visible: root.icon !== "" && status === Image.Ready
                        source: root.icon
                        sourceSize: Qt.size(28, 28)
                        width: 28; height: 28
                    }
                    QIcon {
                        anchors.centerIn: parent
                        visible: root.icon === ""
                        path: root.kind === "port" ? Icons.terminal : Icons.shield
                        size: 20; strokeWidth: 1.9; color: Theme.accent
                    }
                }
                Column {
                    width: parent.width - 54
                    spacing: 4
                    Text {
                        width: parent.width
                        wrapMode: Text.Wrap
                        textFormat: Text.PlainText
                        text: root.title
                        font.family: Theme.fontUi; font.pointSize: Theme.pt(14); font.weight: Font.DemiBold
                        color: Theme.text
                    }
                    Text {
                        width: parent.width
                        wrapMode: Text.Wrap
                        textFormat: Text.PlainText
                        text: root.detail
                        font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
                        color: Theme.text3
                    }
                    Text {
                        width: parent.width
                        topPadding: 2
                        wrapMode: Text.Wrap
                        text: "You can change this later in Settings › Firewall."
                        font.family: Theme.fontUi; font.pointSize: Theme.pt(11)
                        color: Theme.textDim
                    }
                }
            }

            Row {
                anchors.right: parent.right
                spacing: 8
                Button { text: "Not now"; variant: "outline"; size: 34; enabled: !root.busy; onClicked: root.notNowClicked() }
                Button { text: "Allow"; variant: "primary"; size: 34; busy: root.busy; enabled: !root.busy; onClicked: root.allowClicked() }
            }
        }
    }
}
