import QtQuick
import Quasar
import "vault.js" as V

// Vault's window content (apps/vault/shell.qml wires it to `vaultd session`). Pure view.
//   phase: "starting" | "locked" | "open" | "live" | "unavailable"
//   page: "passwords" | "passkeys" | "browsers"
// Passwords never sit in the lists: the detail asks for one (`reveal`) and the host fills `revealed`.
Item {
    id: root
    property string phase: "locked"
    property string page: "passwords"
    property var logins: []                  // [{ uuid, title, site, url, username, created, modified }]
    property var passkeys: []                // [{ uuid, rpId, username, displayName, created, used }]
    property var browsers: []                // [{ id, name, state, store }] installed browsers
    property var connected: []               // [{ id, created }] browsers that connected
    property var sites: []                   // sites allowed to fill passwords
    property string selected: ""             // uuid of the shown login / passkey
    property var revealed: null              // the selected login with { password, notes }, once asked for
    property bool showPassword: false
    property bool busy: false
    property string unlockMessage: ""
    property string busyKey: ""              // a browser being set up
    property var now: undefined              // previews pin "now" (seconds)
    signal unlock(string password)
    signal pagePicked(string page)
    signal picked(string uuid)
    signal reveal(string uuid)
    signal copy(string uuid, string field)
    signal addLogin()
    signal editLogin(string uuid)
    signal deleteLogin(string uuid)
    signal deletePasskey(string uuid)
    signal openSite(string url)
    signal importCsv()
    signal exportCsv()
    signal setupBrowser(string id)
    signal storePage(string id)
    signal forgetBrowser(string id)
    signal forgetSite(string site)
    signal lockNow()

    function focusUnlock() { unlockField.focusInput() }
    function clearUnlock() { unlockField.text = "" }
    function setUnlockText(t) { unlockField.text = t }      // previews

    property string query: ""
    readonly property var shownLogins: V.filterLogins(logins, query)
    readonly property var shownPasskeys: V.filterPasskeys(passkeys, query)
    readonly property var login: logins.find(l => l.uuid === selected) || null
    readonly property var passkey: passkeys.find(p => p.uuid === selected) || null

    // ---- locked, live, unavailable -----------------------------------------------------------------------
    Column {
        visible: root.phase !== "open"
        anchors.centerIn: parent
        width: Math.min(360, parent.width - 48)
        spacing: 14
        Rectangle {
            anchors.horizontalCenter: parent.horizontalCenter
            width: 64; height: 64; radius: 20
            color: Theme.alpha("#FFD66B", 0.14)
            QIcon { anchors.centerIn: parent; path: Icons.shield; size: 30; strokeWidth: 1.8; color: "#FFD66B" }
        }
        Text {
            width: parent.width
            horizontalAlignment: Text.AlignHCenter
            text: root.phase === "live" ? "Vault needs an installed Quasar"
                : root.phase === "unavailable" ? "Your keyring isn't running"
                : root.phase === "starting" ? "Vault" : "Vault is locked"
            font.family: Theme.fontDisplay; font.pixelSize: 22; font.weight: Font.Medium
            color: Theme.text
        }
        Text {
            width: parent.width
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.Wrap
            text: root.phase === "live" ? "The live USB forgets everything when it restarts, so Vault doesn't keep passwords there. Install Quasar to use it."
                : root.phase === "unavailable" ? "Vault keeps your passwords in your login keyring, and it isn't answering. Sign out and in again."
                : root.phase === "starting" ? "" : "Type your account password to see your passwords and passkeys."
            font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
            color: Theme.text3
        }
        Row {
            visible: root.phase === "locked"
            anchors.horizontalCenter: parent.horizontalCenter
            spacing: 8
            TextField {
                id: unlockField
                width: 250; height: 42
                glyph: Icons.lock
                password: true
                placeholder: "Your account password"
                error: root.unlockMessage !== ""
                enabled: !root.busy
                onAccepted: if (text !== "" && !root.busy) root.unlock(text)
            }
            Button {
                width: 42; size: 42; pill: true; variant: "primary"; glyph: Icons.fwd
                busy: root.busy; enabled: unlockField.text !== "" && !root.busy
                accessibleName: "Unlock"
                onClicked: root.unlock(unlockField.text)
            }
        }
        Text {
            visible: root.phase === "locked" && root.unlockMessage !== ""
            width: parent.width
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.Wrap
            text: root.unlockMessage
            font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
            color: Theme.danger
        }
    }

    // ---- open -----------------------------------------------------------------------------------------
    Item {
        anchors.fill: parent
        visible: root.phase === "open"

        Column {
            id: nav
            x: 12; y: 12
            width: 200
            spacing: 2
            NavItem { width: parent.width; label: "Passwords"; glyph: Icons.key; selected: root.page === "passwords"; badge: root.logins.length ? String(root.logins.length) : ""; onClicked: root.pagePicked("passwords") }
            NavItem { width: parent.width; label: "Passkeys"; glyph: Icons.user; selected: root.page === "passkeys"; badge: root.passkeys.length ? String(root.passkeys.length) : ""; onClicked: root.pagePicked("passkeys") }
            NavItem { width: parent.width; label: "Browsers"; glyph: Icons.globe; selected: root.page === "browsers"; onClicked: root.pagePicked("browsers") }
        }
        Column {
            anchors { left: parent.left; bottom: parent.bottom; margins: 12 }
            width: 200
            spacing: 6
            Button { width: parent.width; variant: "ghost"; size: 34; glyph: Icons.download; text: "Import from a file…"; visible: root.page === "passwords"; onClicked: root.importCsv() }
            Button { width: parent.width; variant: "ghost"; size: 34; glyph: Icons.send; text: "Export…"; visible: root.page === "passwords"; onClicked: root.exportCsv() }
            Button { width: parent.width; variant: "ghost"; size: 34; glyph: Icons.lock; text: "Lock Vault"; onClicked: root.lockNow() }
        }
        Rectangle { x: 224; y: 0; width: 1; height: parent.height; color: Theme.white(0.06) }

        // List (passwords / passkeys)
        Item {
            id: listPane
            visible: root.page !== "browsers"
            x: 225; y: 0
            width: Math.round((parent.width - 225) * 0.46)
            height: parent.height
            Row {
                id: listHead
                x: 14; y: 12
                width: parent.width - 28
                spacing: 8
                SearchField {
                    width: parent.width - (addBtn.visible ? addBtn.width + 8 : 0)
                    placeholder: root.page === "passwords" ? "Search passwords" : "Search passkeys"
                    onEdited: (t) => root.query = t
                }
                Button { id: addBtn; visible: root.page === "passwords"; size: 34; variant: "primary"; glyph: Icons.plus; text: "Add"; onClicked: root.addLogin() }
            }
            ListView {
                id: list
                anchors { top: listHead.bottom; topMargin: 10; left: parent.left; right: parent.right; bottom: parent.bottom; bottomMargin: 8 }
                clip: true
                boundsBehavior: Flickable.StopAtBounds
                model: root.page === "passwords" ? root.shownLogins : root.shownPasskeys
                delegate: Pressable {
                    id: rowItem
                    required property var modelData
                    readonly property bool isLogin: root.page === "passwords"
                    readonly property string title: isLogin ? (modelData.title || modelData.site || modelData.url) : modelData.rpId
                    readonly property string sub: isLogin ? (modelData.username || "No username") : (modelData.username || modelData.displayName)
                    x: 8
                    width: list.width - 16
                    implicitHeight: 52
                    radius: 10
                    kind: "hov"
                    color: root.selected === modelData.uuid ? Theme.white(0.07) : "transparent"
                    accessibleName: title + ", " + sub
                    onClicked: root.picked(modelData.uuid)
                    Rectangle {
                        id: mono
                        x: 10; anchors.verticalCenter: parent.verticalCenter
                        width: 32; height: 32; radius: 9
                        color: Theme.alpha(Accounts.hue(rowItem.title), 0.16)
                        Text { anchors.centerIn: parent; text: V.letter(rowItem.title); font.family: Theme.fontDisplay; font.pixelSize: 15; font.weight: Font.Medium; color: Accounts.hue(rowItem.title) }
                    }
                    Column {
                        anchors { left: mono.right; leftMargin: 12; right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter }
                        Text { width: parent.width; text: rowItem.title; elide: Text.ElideRight; textFormat: Text.PlainText; font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5); color: Theme.text }
                        Text { width: parent.width; text: rowItem.sub; elide: Text.ElideRight; textFormat: Text.PlainText; font.family: Theme.fontUi; font.pointSize: Theme.pt(12); color: Theme.textDim }
                    }
                }
                Text {
                    visible: list.count === 0
                    anchors.centerIn: parent
                    width: parent.width - 48
                    horizontalAlignment: Text.AlignHCenter
                    wrapMode: Text.Wrap
                    text: root.query !== "" ? "Nothing matches “" + root.query + "”."
                        : root.page === "passwords" ? "No saved passwords yet. Add one, import them from your browser or another password manager, or let your browser save them as you sign in."
                        : "No passkeys yet. When a site offers to make a passkey, your browser saves it here."
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(13)
                    color: Theme.textDim
                }
            }
        }
        Rectangle { visible: listPane.visible; x: listPane.x + listPane.width; y: 0; width: 1; height: parent.height; color: Theme.white(0.06) }

        // Detail
        Item {
            id: detail
            visible: root.page !== "browsers"
            x: listPane.x + listPane.width + 1
            width: parent.width - x
            height: parent.height
            Text {
                visible: !root.login && !root.passkey
                anchors.centerIn: parent
                text: root.page === "passwords" ? "Pick a password to see it" : "Pick a passkey to see it"
                font.family: Theme.fontUi; font.pointSize: Theme.pt(13)
                color: Theme.textFaint
            }
            Column {
                visible: root.page === "passwords" && root.login !== null
                x: 22; y: 22
                width: parent.width - 44
                spacing: 14
                readonly property var l: root.login || ({})
                Text { width: parent.width; text: parent.l.title || ""; elide: Text.ElideRight; textFormat: Text.PlainText; font.family: Theme.fontDisplay; font.pixelSize: 21; font.weight: Font.Medium; color: Theme.text }
                Field { label: "Website"; value: parent.l.url || "—"; action: parent.l.url ? "Open" : ""; onActed: root.openSite(parent.l.url) }
                Field { label: "Username"; value: parent.l.username || "—"; action: parent.l.username ? "Copy" : ""; onActed: root.copy(root.selected, "username") }
                Field {
                    label: "Password"
                    secret: !root.showPassword
                    value: root.revealed && root.revealed.uuid === root.selected ? root.revealed.password : "••••••••••••"
                    sub: root.revealed && root.revealed.uuid === root.selected ? V.strengthLabel(root.revealed.password) : ""
                    action: "Copy"
                    action2: root.showPassword ? "Hide" : "Show"
                    onActed: root.copy(root.selected, "password")
                    onActed2: { if (!root.showPassword) root.reveal(root.selected); root.showPassword = !root.showPassword }
                }
                Field {
                    visible: !!(root.revealed && root.revealed.uuid === root.selected && root.revealed.notes)
                    label: "Notes"; value: root.revealed ? (root.revealed.notes || "") : ""; multiline: true
                }
                Text {
                    text: "Saved " + V.when(parent.l.created, root.now) + (parent.l.modified && parent.l.modified !== parent.l.created ? "  ·  changed " + V.when(parent.l.modified, root.now) : "")
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(12); color: Theme.textFaint
                }
                Row {
                    spacing: 8
                    Button { text: "Edit"; variant: "soft"; size: 34; glyph: Icons.pencil; onClicked: root.editLogin(root.selected) }
                    Button { text: "Delete"; variant: "outline"; size: 34; glyph: Icons.trash; onClicked: root.deleteLogin(root.selected) }
                }
            }
            Column {
                visible: root.page === "passkeys" && root.passkey !== null
                x: 22; y: 22
                width: parent.width - 44
                spacing: 14
                readonly property var p: root.passkey || ({})
                Text { width: parent.width; text: parent.p.rpId || ""; elide: Text.ElideRight; textFormat: Text.PlainText; font.family: Theme.fontDisplay; font.pixelSize: 21; font.weight: Font.Medium; color: Theme.text }
                Field { label: "Account"; value: parent.p.username || parent.p.displayName || "—" }
                Field { label: "Made"; value: V.when(parent.p.created, root.now) || "—" }
                Field { label: "Last used"; value: V.when(parent.p.used, root.now) || "Not yet" }
                Text {
                    width: parent.width
                    wrapMode: Text.Wrap
                    text: "Your browser uses it when you sign in to " + (parent.p.rpId || "the site") + ", after your account password. It never leaves this PC."
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5); color: Theme.textDim
                }
                Button { text: "Delete passkey"; variant: "outline"; size: 34; glyph: Icons.trash; onClicked: root.deletePasskey(root.selected) }
            }
        }

        // Browsers
        ScrollPane {
            visible: root.page === "browsers"
            x: 225; y: 0
            width: parent.width - 225
            height: parent.height
            topPadding: 22; bottomPadding: 22
            Column {
                x: 24
                width: parent.width - 48
                spacing: 14
                Text { text: "Browsers"; font.family: Theme.fontDisplay; font.pixelSize: 21; font.weight: Font.Medium; color: Theme.text }
                Text {
                    width: parent.width
                    wrapMode: Text.Wrap
                    text: "Your browser fills and saves passwords, and makes and uses passkeys, through the free KeePassXC-Browser extension: Vault answers it in KeePassXC's place. Set up a browser, add the extension, then press Connect in the extension's menu. Turn on Passkeys in the extension's settings to use passkeys."
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(13); color: Theme.text3
                }
                SettingsGroup {
                    width: parent.width
                    label: "On this PC"
                    Repeater {
                        model: root.browsers
                        delegate: SettingsRow {
                            required property var modelData
                            width: parent ? parent.width : 0
                            label: modelData.name
                            glyph: Icons.globe
                            sub: V.browserState(modelData)
                            trailing: "button"
                            value: modelData.state === "ready" ? "Get the extension" : modelData.state === "keepassxc" ? "Use Vault instead" : "Set up"
                            busy: root.busyKey === modelData.id
                            onActivated: modelData.state === "ready" ? root.storePage(modelData.id) : root.setupBrowser(modelData.id)
                        }
                    }
                    SettingsRow {
                        visible: root.browsers.length === 0
                        label: "No browser yet"
                        sub: "Get Firefox, Brave or Chromium from the Store, then set it up here"
                        glyph: Icons.globe
                        trailing: "none"
                    }
                }
                SettingsGroup {
                    visible: root.connected.length > 0
                    width: parent.width
                    label: "Connected"
                    Repeater {
                        model: root.connected
                        delegate: SettingsRow {
                            required property var modelData
                            width: parent ? parent.width : 0
                            label: modelData.id
                            sub: "Connected " + V.when(modelData.created, root.now)
                            glyph: Icons.link
                            trailing: "button"; value: "Forget"
                            onActivated: root.forgetBrowser(modelData.id)
                        }
                    }
                }
                SettingsGroup {
                    visible: root.sites.length > 0
                    width: parent.width
                    label: "Sites that can fill your passwords"
                    Repeater {
                        model: root.sites
                        delegate: SettingsRow {
                            required property var modelData
                            width: parent ? parent.width : 0
                            label: modelData
                            glyph: Icons.check
                            trailing: "button"; value: "Remove"
                            onActivated: root.forgetSite(modelData)
                        }
                    }
                }
            }
        }
    }

    // A labelled value with up to two text actions (Copy, Show, Open).
    component Field: Column {
        id: field
        property string label: ""
        property string value: ""
        property string sub: ""
        property bool secret: false
        property bool multiline: false
        property string action: ""
        property string action2: ""
        signal acted()
        signal acted2()
        width: parent ? parent.width : 300
        spacing: 3
        Text { text: field.label; font.family: Theme.fontUi; font.pointSize: Theme.pt(12); color: Theme.textDim }
        Row {
            width: parent.width
            spacing: 6
            Text {
                width: parent.width - (a1.visible ? a1.width + 6 : 0) - (a2.visible ? a2.width + 6 : 0)
                anchors.verticalCenter: parent.verticalCenter
                text: field.secret ? "••••••••••••" : field.value
                elide: field.multiline ? Text.ElideNone : Text.ElideRight
                wrapMode: field.multiline ? Text.Wrap : Text.NoWrap
                textFormat: Text.PlainText
                font.family: field.secret || field.label === "Password" ? Theme.fontMono : Theme.fontUi
                font.pointSize: Theme.pt(14)
                color: Theme.text
            }
            Button { id: a2; visible: field.action2 !== ""; text: field.action2; variant: "ghost"; size: 30; onClicked: field.acted2() }
            Button { id: a1; visible: field.action !== ""; text: field.action; variant: "ghost"; size: 30; onClicked: field.acted() }
        }
        Text { visible: field.sub !== ""; text: field.sub; font.family: Theme.fontUi; font.pointSize: Theme.pt(11.5); color: Theme.textFaint }
    }
}
