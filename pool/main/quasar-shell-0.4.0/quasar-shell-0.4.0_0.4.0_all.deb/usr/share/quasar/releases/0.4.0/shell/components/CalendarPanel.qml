import QtQuick
import Quasar

// Calendar + notifications (mockup aria-label="Calendar and notifications").
Panel {
    id: root
    radius: 24
    tint: Theme.panelBgStrong
    shadowOffsetY: 30
    shadowBlur: 80
    shadowSpread: -24

    property date now: new Date()
    property bool calm: true
    property var notifications: []     // [{ id, title, sub, glyph, hue }]
    signal dismissed(var id)
    signal clearAll()

    implicitWidth: 360
    implicitHeight: col.implicitHeight + 36

    readonly property var _cells: {
        const y = now.getFullYear(), m = now.getMonth()
        const first = new Date(y, m, 1).getDay(), days = new Date(y, m + 1, 0).getDate()
        const out = []
        for (let i = 0; i < first; i++) out.push(0)
        for (let d = 1; d <= days; d++) out.push(d)
        return out
    }

    Column {
        id: col
        x: 18; y: 18
        width: root.width - 36
        spacing: 14

        Column {
            spacing: 2
            Text {
                text: root.now.toLocaleDateString(Qt.locale(), "dddd, MMMM d")
                font.family: Theme.fontDisplay; font.pixelSize: 22; font.weight: Font.Medium; color: Theme.text
            }
            Text {
                text: root.now.toLocaleTimeString(Qt.locale(), "h:mm AP")
                font.family: Theme.fontUi; font.pixelSize: 13; color: Theme.textMuted
            }
        }

        Grid {
            id: cal
            width: parent.width
            columns: 7
            columnSpacing: 2; rowSpacing: 2
            readonly property real cw: (width - 12) / 7
            Repeater {
                model: ["S", "M", "T", "W", "T", "F", "S"]
                Text {
                    required property string modelData
                    width: cal.cw; horizontalAlignment: Text.AlignHCenter
                    topPadding: 4; bottomPadding: 4
                    text: modelData; font.family: Theme.fontUi; font.pixelSize: 11; color: Theme.textFaint
                }
            }
            Repeater {
                model: root._cells
                Item {
                    required property int modelData
                    readonly property bool today: modelData === root.now.getDate()
                    width: cal.cw; height: 34
                    Rectangle {
                        anchors.centerIn: parent
                        width: 34; height: 34; radius: 17
                        color: parent.today ? Theme.accent : "transparent"
                    }
                    Text {
                        anchors.centerIn: parent
                        text: modelData > 0 ? modelData : ""
                        font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
                        font.weight: parent.today ? Font.Bold : Font.Normal
                        color: parent.today ? Theme.accentInk : Theme.text3
                    }
                }
            }
        }

        Column {
            width: parent.width
            spacing: 6
            Rectangle { width: parent.width; height: 1; color: Theme.white(0.06) }
            Item {
                width: parent.width; height: 26
                SectionLabel { x: 2; anchors.verticalCenter: parent.verticalCenter; text: root.calm ? "Notifications · Calm mode" : "Notifications" }
                Text {
                    visible: root.notifications.length > 1
                    anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                    text: "Clear all"; font.family: Theme.fontUi; font.pixelSize: 12; color: Theme.textDim
                    MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: root.clearAll() }
                }
            }
            Text {
                visible: root.notifications.length === 0
                leftPadding: 2
                text: "You're all caught up."
                font.family: Theme.fontUi; font.pixelSize: 13; color: Theme.textDim
            }
            Repeater {
                model: root.notifications
                delegate: Rectangle {
                    required property var modelData
                    width: col.width; height: Math.max(52, nText.implicitHeight + 20); radius: 14
                    color: Theme.white(0.045)
                    QIcon { x: 12; y: 12; path: modelData.glyph || Icons.bell; size: 16; color: modelData.hue || Theme.accent }
                    Column {
                        id: nText
                        x: 38; anchors.verticalCenter: parent.verticalCenter
                        width: parent.width - 38 - 34
                        spacing: 2
                        Text { width: parent.width; wrapMode: Text.WordWrap; maximumLineCount: 2; elide: Text.ElideRight; text: modelData.title; font.family: Theme.fontUi; font.pixelSize: 13; font.weight: Font.Medium; color: Theme.text }
                        Text { width: parent.width; wrapMode: Text.WordWrap; maximumLineCount: 3; elide: Text.ElideRight; text: modelData.sub; font.family: Theme.fontUi; font.pixelSize: 12; color: Theme.textMuted }
                    }
                    Pressable {
                        anchors { right: parent.right; rightMargin: 6; top: parent.top; topMargin: 6 }
                        width: 26; height: 26; radius: 8
                        accessibleName: "Dismiss"
                        onClicked: root.dismissed(modelData.id)
                        QIcon { anchors.centerIn: parent; path: Icons.x; size: 12; strokeWidth: 2; color: Theme.textDim }
                    }
                }
            }
        }
    }
}
