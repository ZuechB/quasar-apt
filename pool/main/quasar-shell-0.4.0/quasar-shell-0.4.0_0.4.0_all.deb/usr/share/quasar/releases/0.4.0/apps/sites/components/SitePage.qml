import QtQuick
import Quasar
import "runtime.js" as RT

// Template Sites › one site: header (status, address, runtime, Open / Folder / Restart / Stop / Start /
// Deploy), a warning banner (failed deploy, runtime end of support), the stats row, the deploy
// progress while one runs, and the tabs: Overview, Deployments, Environment, Logs, Settings.
Item {
    id: root
    property var site: null            // summary from sites-query state
    property var detail: null          // sites-query site ID (env, secrets, deploys, releases)
    property var metrics: ({ rpm: 0, p95: null, hist: [] })
    property var logs: []
    property var deploy: ({ steps: [], current: -1, failed: false, lines: [], message: "" })
    property int tab: 0
    property var revealed: ({})
    property bool confirmRemove: false
    property bool busy: false
    property string error: ""
    property string errorDetails: ""
    property real now: Date.now()
    property string home: ""
    signal openUrl(string url)
    signal openFolder(string path)     // the project folder, in Files (where the example's index.html is)
    signal start()
    signal stop()
    signal restart()
    signal deployNow()
    signal cancelDeploy()
    signal rollback(string release)
    signal tabPicked(int index)
    signal envSet(string name, string value, bool secret)
    signal envRemove(string name)
    signal reveal(string name)
    signal hide(string name)
    signal setOption(string key, bool on)
    signal askRemove()
    signal cancelRemove()
    signal remove()
    signal dismissError()

    readonly property var info: RT.status(site)
    readonly property bool live: !!site && site.state === "live"
    readonly property bool deploying: !!site && site.deploying
    readonly property string url: site ? "https://" + site.hostname : ""
    readonly property var lastFail: {
        const d = detail && detail.deploys ? detail.deploys.find(x => !x.ok) : null
        return d || null
    }
    readonly property var liveDeploy: detail && detail.deploys && site ? detail.deploys.find(x => x.release === site.release) || null : null
    readonly property string warn: !site ? "" : site.lastFailed
        ? "The last deploy failed" + (lastFail && lastFail.hash ? " (" + lastFail.hash + ")" : "") + ". " +
          (site.state === "new" ? "Fix the problem and deploy again." :
           "Visitors still get " + (liveDeploy ? liveDeploy.hash : "the previous version") + ", so nothing is down.")
        : RT.eolWarning(site, now)

    function toneColor(t) {
        return t === "mint" ? Theme.mint : t === "amber" ? Theme.amber : t === "danger" ? Theme.danger
             : t === "accent" ? Theme.accent : Theme.textDim
    }

    implicitHeight: col.implicitHeight

    Column {
        id: col
        width: parent.width
        spacing: 16

        // ---- header ----------------------------------------------------------------------------
        Item {
            width: parent.width
            height: Math.max(headLeft.implicitHeight, actions.implicitHeight)
            Row {
                id: headLeft
                spacing: 14
                width: parent.width - actions.width - 14
                Rectangle {
                    width: 52; height: 52; radius: 16
                    anchors.verticalCenter: parent.verticalCenter
                    border.width: 1; border.color: Theme.white(0.1)
                    gradient: Gradient {
                        GradientStop { position: 0; color: Theme.white(0.14) }
                        GradientStop { position: 0.6; color: "#121522" }
                    }
                    QIcon { anchors.centerIn: parent; path: Icons.web; size: 25; strokeWidth: 1.8; color: Theme.accent }
                }
                Column {
                    anchors.verticalCenter: parent.verticalCenter
                    width: parent.width - 66
                    spacing: 6
                    Row {
                        spacing: 10
                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            text: root.site ? root.site.name : ""
                            textFormat: Text.PlainText
                            font.family: Theme.fontDisplay; font.pixelSize: 24; font.weight: Font.Medium; font.letterSpacing: -0.5
                            color: Theme.text
                        }
                        StatusPill {
                            anchors.verticalCenter: parent.verticalCenter
                            text: root.info.label
                            tone: root.toneColor(root.info.tone)
                            pulse: root.info.live
                        }
                    }
                    Row {
                        spacing: 8
                        Pressable {
                            visible: root.site && root.site.state !== "new"
                            implicitHeight: 26
                            implicitWidth: urlRow.implicitWidth + 16
                            kind: "hov"; radius: 7
                            color: Theme.white(0.05)
                            accessibleName: "Open " + root.url
                            onClicked: root.openUrl(root.url)
                            Row {
                                id: urlRow
                                anchors.centerIn: parent
                                spacing: 6
                                QIcon { anchors.verticalCenter: parent.verticalCenter; path: Icons.open; size: 12; strokeWidth: 2.2; color: Theme.accent }
                                Text {
                                    anchors.verticalCenter: parent.verticalCenter
                                    text: root.url
                                    font.family: Theme.fontMono; font.pointSize: Theme.pt(12.5)
                                    color: Theme.accent
                                }
                            }
                        }
                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            text: RT.rtLabel(root.site)
                            font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
                            color: Theme.textMuted
                        }
                    }
                }
            }
            Row {
                id: actions
                anchors.right: parent.right
                anchors.top: parent.top
                spacing: 6
                Button {
                    visible: root.site && root.site.state !== "new"
                    variant: "outline"; size: 36; glyph: Icons.open; text: "Open"; fg: Theme.text
                    onClicked: root.openUrl(root.url)
                }
                Button {
                    visible: !!root.site && root.site.sourceType === "folder" && (root.site.source || "") !== ""
                    variant: "outline"; size: 36; glyph: Icons.folder; text: "Folder"; fg: Theme.text
                    accessibleName: "Open the project folder"
                    onClicked: root.openFolder(root.site.source)
                }
                Button {
                    visible: root.live && root.site.kind !== "static"
                    variant: "outline"; size: 36; glyph: Icons.refresh; text: "Restart"; fg: Theme.text
                    enabled: !root.busy && !root.deploying
                    onClicked: root.restart()
                }
                Button {
                    visible: root.live || (root.site && root.site.state === "starting")
                    variant: "outline"; size: 36; glyph: Icons.stop; text: "Stop"; fg: Theme.text
                    enabled: !root.busy && !root.deploying
                    onClicked: root.stop()
                }
                Button {
                    visible: root.site && (root.site.state === "stopped" || root.site.state === "crashed")
                    variant: "outline"; size: 36; glyph: Icons.play; text: "Start"; fg: Theme.text
                    enabled: !root.busy && !root.deploying
                    onClicked: root.start()
                }
                Button {
                    variant: "primary"; size: 36; glyph: Icons.up
                    text: root.deploying ? "Deploying" : root.site && root.site.lastFailed ? "Redeploy" : "Deploy"
                    busy: root.deploying
                    enabled: !root.deploying && !root.busy
                    onClicked: root.deployNow()
                }
            }
        }

        Banner {
            visible: root.warn !== ""
            width: parent.width
            tone: root.site && root.site.lastFailed ? "error" : "warning"
            message: root.warn
            actionText: root.site && root.site.lastFailed ? "See what failed" : ""
            onActionClicked: root.tabPicked(1)
        }
        Banner {
            visible: root.error !== ""
            width: parent.width
            tone: "error"
            message: root.error
            details: root.errorDetails
            actionText: "Dismiss"
            onActionClicked: root.dismissError()
        }

        // ---- stats row (template: auto-fit grid of 160px+ tiles) ---------------------------------
        Grid {
            id: stats
            width: parent.width
            columns: width > 640 ? 4 : 2
            spacing: 10
            readonly property real tileW: (width - (columns - 1) * spacing) / columns
            Repeater {
                model: [
                    { label: "Requests per minute", value: root.live ? String(root.metrics.rpm || 0) : "0", spark: true },
                    { label: "Response time", value: !root.live ? "Not running" : root.metrics.p95 === null || root.metrics.p95 === undefined ? "No requests yet" : root.metrics.p95 + " ms" },
                    { label: "Memory", value: !root.live ? "Not running" : root.site.memory ? RT.mem(root.site.memory) : root.site.kind === "static" ? "Shared" : "–" },
                    { label: "Up for", value: root.live && root.site.since ? RT.dur(root.now - root.site.since * 1000) : root.live ? "Served by the proxy" : "Not running" }
                ]
                delegate: Rectangle {
                    required property var modelData
                    width: stats.tileW
                    height: 76
                    radius: 16
                    color: Theme.white(0.035)
                    border.width: 1; border.color: Theme.white(0.06)
                    Column {
                        anchors { left: parent.left; right: parent.right; top: parent.top; margins: 15; topMargin: 13 }
                        spacing: 6
                        Text { text: modelData.label; font.family: Theme.fontUi; font.pixelSize: 12; color: Theme.textMuted }
                        Item {
                            width: parent.width
                            height: big.implicitHeight
                            Text {
                                id: big
                                text: modelData.value
                                elide: Text.ElideRight
                                width: parent.width - (modelData.spark ? 92 : 0)
                                font.family: modelData.spark ? Theme.fontDisplay : Theme.fontUi
                                font.pixelSize: modelData.spark ? 26 : 15
                                font.weight: modelData.spark ? Font.Medium : Font.DemiBold
                                color: Theme.text
                                anchors.bottom: parent.bottom
                            }
                            Sparkline {
                                visible: !!modelData.spark && root.live
                                anchors { right: parent.right; bottom: parent.bottom; bottomMargin: 2 }
                                values: root.metrics.hist || []
                            }
                        }
                    }
                }
            }
        }

        StepList {
            visible: root.deploying || (root.deploy.failed && root.deploy.steps.length > 0)
            width: parent.width
            steps: root.deploy.steps
            current: root.deploy.current
            failed: root.deploy.failed
            lines: root.deploy.lines
        }
        Row {
            visible: root.deploying
            spacing: 8
            Button { variant: "ghost"; size: 30; text: "Cancel deploy"; onClicked: root.cancelDeploy() }
        }

        TabBar {
            width: parent.width
            model: ["Overview", "Deployments", "Environment", "Logs", "Settings"]
            currentIndex: root.tab
            onPicked: (i) => root.tabPicked(i)
        }

        OverviewTab {
            visible: root.tab === 0
            width: parent.width
            site: root.site
            detail: root.detail
            liveDeploy: root.liveDeploy
            home: root.home
        }
        DeploysTab {
            visible: root.tab === 1
            width: parent.width
            site: root.site
            deploys: root.detail ? root.detail.deploys || [] : []
            releases: root.detail ? root.detail.releases || [] : []
            now: root.now
            busy: root.deploying || root.busy
            onRollback: (rel) => root.rollback(rel)
        }
        EnvTab {
            visible: root.tab === 2
            width: parent.width
            env: root.detail ? root.detail.env || [] : []
            secrets: root.detail ? root.detail.secrets || [] : []
            revealed: root.revealed
            busy: root.busy
            onSetVar: (n, v, s) => root.envSet(n, v, s)
            onRemoveVar: (n) => root.envRemove(n)
            onReveal: (n) => root.reveal(n)
            onHide: (n) => root.hide(n)
        }
        ConsoleView {
            visible: root.tab === 3
            width: parent.width
            height: 300
            lines: root.logs
            emptyText: root.site && root.site.state === "new" ? "Logs appear after the first deploy." : "Nothing logged yet."
        }
        SiteSettingsTab {
            visible: root.tab === 4
            width: parent.width
            site: root.site
            confirming: root.confirmRemove
            busy: root.busy
            onSetOption: (k, on) => root.setOption(k, on)
            onAskRemove: root.askRemove()
            onCancelRemove: root.cancelRemove()
            onRemove: root.remove()
        }
    }
}
