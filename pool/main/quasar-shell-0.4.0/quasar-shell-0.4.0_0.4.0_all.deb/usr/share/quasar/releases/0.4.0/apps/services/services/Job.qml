import QtQuick
import Quasar.Services

// One call to a Services helper (services-query, quasar-services, quasar-services-admin; also Sites'
// quasar-sites for site rows) that prints JSON lines (the same shape as Sites' helpers).
// Collects the `result` object and the `error` object, forwards every event, and reports once:
//   done(ok, result, error)   error: { code, message, details } (pkexec 126/127 mapped too)
//   job.start(["/usr/libexec/quasar/services-query", "state"])       job.start(cmd, stdinText)
Cmd {
    id: job
    property var result: null
    property var error: null
    property string tag: ""             // what this run was for (the caller's bookkeeping)
    property var meta: null
    signal event(var ev)
    signal done(bool ok, var result, var error)

    function start(cmd, input, tag, meta) {
        result = null
        error = null
        job.tag = tag || ""
        job.meta = meta === undefined ? null : meta
        run(cmd, undefined, input)
    }

    onLine: (l) => {
        if (l.charAt(0) !== "{") return
        let o
        try { o = JSON.parse(l) } catch (e) { return }
        if (o.type === "result") job.result = o
        else if (o.type === "error") job.error = o
        job.event(o)
    }
    onFinished: (code) => {
        let err = job.error
        if (!err && code !== 0) {
            err = code === 126 ? { code: "cancelled", message: "The password prompt was closed, so nothing changed.", details: "" }
                : code === 127 ? { code: "not-authorized", message: "Your account isn’t allowed to do that. Ask an administrator.", details: details() }
                : { code: "failed", message: "That didn’t work (code " + code + ").", details: details() }
        }
        job.done(code === 0 && !err, job.result, err)
    }
}
