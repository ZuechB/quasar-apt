import QtQuick
import Quickshell
import Quickshell.Io
import Quickshell.Networking
import Quasar.Services

// Settings › Network: Wi-Fi and Ethernet through NetworkManager (Quickshell.Networking; live, nothing
// polled). Scans only while the page is open. Passwords go to NetworkManager over D-Bus (connectWithPsk),
// or on nmcli's stdin for hidden and work/school (802.1X) networks — never on a command line, where
// every local program could read them. Connecting is the only network traffic, and only when asked.
Scope {
    id: root
    property bool active: false              // the Network page is visible
    property bool paused: false              // a password form is open: keep the rows still
    signal connected(string name)
    signal failed(string name, string message, bool askPassword)

    // The Wi-Fi device NetworkManager manages (a second radio or a dongle may be left unmanaged). Never
    // the Mobile hotspot's extra interface (qap0), and an adapter that joins networks before one that's
    // hosting the hotspot.
    readonly property var adapters: Networking.devices.values.filter(d => d && d.type === DeviceType.Wifi && d.name !== "qap0")
    readonly property var device: {
        const st = adapters.filter(d => d.mode !== WifiDeviceMode.AccessPoint)
        return st.find(d => d.nmManaged) || st[0] || adapters.find(d => d.nmManaged) || adapters[0] || null
    }
    readonly property bool hardware: device !== null
    // The only adapter is the hotspot itself (sharing a cable): no networks to list.
    readonly property bool hosting: !!device && device.mode === WifiDeviceMode.AccessPoint
    // Scanning moves the radio off its channel; while a hotspot shares the same adapter its devices
    // would drop, so the list doesn't scan then.
    readonly property bool scan: active && !hosting && !(NetState.hotspotOn && NetState.hotspot.mode === "concurrent")
    readonly property bool enabled: Networking.wifiEnabled
    readonly property bool hardBlocked: !Networking.wifiHardwareEnabled
    readonly property var current: device ? device.networks.values.find(n => n && n.connected) || null : null
    readonly property string connectedName: current ? current.name : ""
    readonly property string connectedSecurity: current ? label(current.security) : ""
    property string busy: ""                 // network being connected to

    // ---- rows for WifiList (keyed by name, so updates land in place) --------------------------------
    function label(s) {
        return s === WifiSecurityType.Sae ? "WPA3" : s === WifiSecurityType.Wpa2Psk ? "WPA2" : s === WifiSecurityType.WpaPsk ? "WPA"
             : s === WifiSecurityType.Owe ? "Enhanced Open" : s === WifiSecurityType.Open ? "Open"
             : s === WifiSecurityType.Wpa2Eap || s === WifiSecurityType.WpaEap || s === WifiSecurityType.Wpa3SuiteB192 ? "Enterprise"
             : s === WifiSecurityType.StaticWep || s === WifiSecurityType.DynamicWep || s === WifiSecurityType.Leap ? "WEP" : "Secured"
    }
    function kindOf(s) {   // how to join: open (no password), psk (password), enterprise (username + password), wep
        const l = label(s)
        return l === "Open" || l === "Enhanced Open" ? "open" : l === "Enterprise" ? "enterprise" : l === "WEP" ? "wep" : "psk"
    }
    function level(n) {
        const s = n.signalStrength > 1 ? n.signalStrength / 100 : n.signalStrength
        return s > 0.75 ? 4 : s > 0.5 ? 3 : s > 0.25 ? 2 : 1
    }
    readonly property var liveRows: {
        if (!device || !enabled || hosting) return []
        const seen = {}
        const out = []
        for (const n of device.networks.values) {
            if (!n || !n.name || seen[n.name]) continue          // hidden networks have no name
            seen[n.name] = true
            out.push({ key: n.name, name: n.name, security: label(n.security), kind: kindOf(n.security), level: level(n),
                       signal: n.signalStrength, connected: n.connected, known: n.known,
                       busy: n.name === busy || n.state === ConnectionState.Connecting })
        }
        out.sort((a, b) => (b.connected - a.connected) || (b.signal - a.signal) || a.name.localeCompare(b.name))
        return out
    }
    property var rows: []
    onLiveRowsChanged: if (!paused) rows = liveRows
    onPausedChanged: if (!paused) rows = liveRows
    ScriptModel { id: networkRows; objectProp: "key"; values: root.rows }
    readonly property var networks: networkRows
    readonly property bool scanning: scan && enabled && hardware && rows.length === 0

    // ---- Ethernet ---------------------------------------------------------------------------------------
    readonly property var wired: Networking.devices.values.filter(d => d && d.type === DeviceType.Wired)
    readonly property string ethernet: {
        const c = wired.find(d => d.connected)
        if (c) return "Connected" + (c.linkSpeed > 0 ? "  ·  " + (c.linkSpeed >= 1000 ? c.linkSpeed / 1000 + " Gb/s" : c.linkSpeed + " Mb/s") : "") + "  ·  " + c.name
        if (wired.some(d => d.hasLink)) return "Cable plugged in, not connected"
        return wired.length ? "No cable detected" : "No Ethernet port"
    }

    // ---- actions ------------------------------------------------------------------------------------------
    function find(name) { return device ? device.networks.values.find(n => n && n.name === name) || null : null }
    onScanChanged: if (device) device.scannerEnabled = scan
    onDeviceChanged: if (device) device.scannerEnabled = scan
    Component.onDestruction: if (device) device.scannerEnabled = false

    function setEnabled(on) {
        if (on) Quickshell.execDetached(["/usr/sbin/rfkill", "unblock", "wifi"])     // a soft block (airplane mode)
        Networking.wifiEnabled = on
    }

    property var pending: null               // the WifiNetwork being joined
    property bool firstTime: false           // not saved before: forget it again if its password is refused
    property string newPsk: ""               // a saved network's new password, sent once it's forgotten
    function start(n) { pending = n; busy = n.name; watchdog.restart() }
    function finish() { pending = null; busy = ""; newPsk = ""; watchdog.stop() }

    function connect(name) {                 // open networks and saved ones
        const n = find(name)
        if (!n) return
        start(n)
        firstTime = !n.known
        n.connect()
    }
    function connectWithPassword(name, password) {
        const n = find(name)
        if (!n) return
        start(n)
        if (n.known) {                       // a saved network with a new password: replace the saved one
            newPsk = password
            n.forget()                       // -> onKnownChanged connects with the new password
        } else {
            firstTime = true
            n.connectWithPsk(password)
        }
    }
    function disconnect(name) { const n = find(name); if (n) n.disconnect() }
    function forget(name) { const n = find(name); if (n) n.forget() }

    Connections {
        target: root.pending
        ignoreUnknownSignals: true
        function onConnectedChanged() {
            if (root.pending && root.pending.connected) {
                const name = root.pending.name
                root.finish()
                root.connected(name)
            }
        }
        function onKnownChanged() {
            if (root.pending && !root.pending.known && root.newPsk !== "") {
                const psk = root.newPsk
                root.newPsk = ""
                root.firstTime = true
                root.pending.connectWithPsk(psk)
            }
        }
        function onConnectionFailed(reason) { root.fail(reason) }
    }
    function fail(reason) {
        const n = pending
        if (!n) return
        const name = n.name, k = kindOf(n.security)
        const passwordLike = reason === ConnectionFailReason.NoSecrets || reason === ConnectionFailReason.WifiClientDisconnected
                          || reason === ConnectionFailReason.WifiClientFailed || reason === ConnectionFailReason.WifiAuthTimeout
        // Never keep a password that was refused. Other failures (no address from the network, out of
        // range) keep it: the password was fine, and the next try needs it.
        if (firstTime && passwordLike) n.forget()
        finish()
        if (k === "psk" && passwordLike) failed(name, "The password for " + name + " wasn't accepted.", true)
        else if (reason === ConnectionFailReason.WifiNetworkLost) failed(name, name + " went out of range.", false)
        else failed(name, "Couldn't connect to " + name + ".", false)
    }
    // Only a safety net: NetworkManager reports failures itself, and its address request alone may take
    // 45 s, so this must outlast association + authentication + DHCP.
    Timer { id: watchdog; interval: 120000; onTriggered: root.fail(ConnectionFailReason.Unknown) }

    // ---- hidden and work/school networks (the nm-join helper; secrets on its stdin) ---------------------
    // spec: { ssid, hidden, security: "open"|"psk"|"sae"|"enterprise", password, identity, eap: "peap"|"ttls",
    //         domain, noCheck }. Quickshell has no API for these, and nmcli's passwd-file isn't reliable
    // (it only answers while it happens to be a registered secret agent), so the helper hands NetworkManager
    // the whole profile over D-Bus. It deletes the profile itself when the password is refused.
    readonly property string joinHelper: Quickshell.env("QUASAR_NM_JOIN") || "/usr/libexec/quasar/nm-join"
    property var joining: null
    function join(spec) {
        if (joining) return
        joining = { ssid: spec.ssid, enterprise: spec.security === "enterprise" }
        busy = spec.ssid
        joiner.run([joinHelper], null, JSON.stringify(Object.assign({}, spec, { ifname: device ? device.name : "" })) + "\n")
    }
    Cmd {
        id: joiner
        onFinished: (code) => {
            const j = root.joining
            root.joining = null
            root.busy = ""
            if (!j) return
            let r = {}
            for (const line of joiner.tail) { try { const o = JSON.parse(line); if (o.result) r = o } catch (e) { } }
            if (r.result === "connected") { root.connected(j.ssid); return }
            console.warn("wifi: joining " + j.ssid + " failed: " + (r.detail || joiner.details()))
            root.failed(j.ssid, r.reason === "password" ? (j.enterprise ? "Couldn't sign in to " + j.ssid + ". Check the details."
                                                                       : "The password for " + j.ssid + " wasn't accepted.")
                              : r.reason === "not-found" ? j.ssid + " wasn't found nearby."
                              : "Couldn't connect to " + j.ssid + ".", false)
        }
    }
}
