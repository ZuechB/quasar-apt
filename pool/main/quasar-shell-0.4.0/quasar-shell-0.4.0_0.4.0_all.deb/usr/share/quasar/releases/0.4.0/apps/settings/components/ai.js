.pragma library
// Settings › Quasar AI: rows and hero card from AiSetup's state (pure: the preview feeds it mock state).
// Row keys: ai:provider · ai:model · ai:key · ai:engine · ai:update · ai:local:<id> · ai:get:<id> ·
// ai:more · ai:other · ai:perm:<p> · ai:plan · ai:enabled

var PROVIDERS = {
    "ollama":       { label: "This PC", long: "On this PC (Ollama)", sub: "Private and free: nothing leaves this PC. Needs a download.", cloud: false },
    "ollama-cloud": { label: "Ollama Cloud", long: "Ollama Cloud", sub: "Large open models on ollama.com, with an Ollama API key.", cloud: true, company: "Ollama", keyUrl: "ollama.com/settings/keys" },
    "anthropic":    { label: "Claude", long: "Claude (Anthropic)", sub: "With an Anthropic API key, billed per use.", cloud: true, company: "Anthropic", keyUrl: "console.anthropic.com" },
    "openai":       { label: "ChatGPT", long: "ChatGPT (OpenAI)", sub: "With an OpenAI API key, billed per use.", cloud: true, company: "OpenAI", keyUrl: "platform.openai.com/api-keys" }
}
var ORDER = ["ollama", "ollama-cloud", "anthropic", "openai"]
var PERMS = [
    ["apps", "Open and arrange apps", "Open apps and switch, minimize or close windows"],
    ["settings", "Change settings", "Wi-Fi, Bluetooth, sound, brightness, Focus, look"],
    ["install", "Install apps", "From the Store. Always asks first"],
    ["files", "Find and manage files", "In your home folder. Moving or deleting asks first"],
    ["commands", "Run commands", "As you, never as root. Shows each command and asks first"]
]
var CLAUDE_MODELS = [
    { key: "claude-sonnet-5-5", label: "Claude Sonnet 5.5", sub: "Fast and capable: the best fit for most tasks" },
    { key: "claude-haiku-5-5", label: "Claude Haiku 5.5", sub: "Fastest and cheapest" },
    { key: "claude-opus-5-5", label: "Claude Opus 5.5", sub: "Most capable, for long and tricky tasks" }
]

function cfg(ai) {
    var a = ai || {}
    var perms = {}
    for (var i = 0; i < PERMS.length; i++) perms[PERMS[i][0]] = !(a.perms && a.perms[PERMS[i][0]] === false)
    return { enabled: a.enabled === true, provider: PROVIDERS[a.provider] ? a.provider : "",
             model: a.model || {}, perms: perms, plan: a.plan !== false }
}
function ready(ai) {
    var c = cfg(ai)
    return c.enabled && c.provider !== "" && !!c.model[c.provider]
}
function gb(bytes) {
    if (!bytes) return ""
    var g = bytes / 1e9
    return g >= 10 ? Math.round(g) + " GB" : g >= 1 ? g.toFixed(1) + " GB" : Math.round(bytes / 1e6) + " MB"
}
function gbOf(n) { return n >= 10 ? Math.round(n) + " GB" : n >= 1 ? n.toFixed(1) + " GB" : Math.round(n * 1000) + " MB" }
function modelName(id, catalog) {
    for (var i = 0; i < (catalog || []).length; i++) if (catalog[i].id === id) return catalog[i].name
    for (var j = 0; j < CLAUDE_MODELS.length; j++) if (CLAUDE_MODELS[j].key === id) return CLAUDE_MODELS[j].label
    return id
}

// How a model would run here: gpu | cpu | slow | no, with the words for it.
function fit(m, hw) {
    var vram = (hw.vramMB || 0) / 1024, ram = (hw.ramMB || 0) / 1024
    if (hw.accel !== "cpu" && vram >= m.sizeGB + 1)
        return { level: "gpu", note: "Runs on your graphics card" }
    if (!ram || ram - 3 >= m.ramGB) {
        if (m.sizeGB > 6 || (hw.accel === "cpu" && m.sizeGB > 3.5 && m.id.indexOf("a1b") < 0 && m.id.indexOf(":30b") < 0))
            return { level: "slow", note: "Fits, but slow without a big graphics card" }
        return { level: "cpu", note: hw.accel === "cpu" ? "Runs on the processor" : "Runs on the processor (too big for the graphics card)" }
    }
    return { level: "no", note: "Needs more memory than this PC has" }
}
// Best first: the largest model the graphics card holds, else a small one that's quick on the CPU.
function ranked(catalog, hw) {
    var order = { gpu: 0, cpu: 1, slow: 2, no: 3 }
    return (catalog || []).map(function (m) { var f = fit(m, hw); return { m: m, f: f } })
        .sort(function (a, b) {
            if (order[a.f.level] !== order[b.f.level]) return order[a.f.level] - order[b.f.level]
            if (a.f.level === "gpu") return b.m.sizeGB - a.m.sizeGB
            return Math.abs(a.m.sizeGB - 2.5) - Math.abs(b.m.sizeGB - 2.5)
        })
}

function _row(key, label, sub, trailing, extra) {
    var r = { key: key, label: label, sub: sub || "", trailing: trailing || "none" }
    for (var k in extra || {}) r[k] = extra[k]
    return r
}

function groups(st, ctx) {
    var c = cfg(st.ai), p = PROVIDERS[c.provider], out = []
    var eng = st.engine || {}, job = st.engineJob
    var setup = [_row("ai:enabled", "Quasar AI", "Ask on the taskbar and Ask Quasar in the launcher", "toggle", { checked: c.enabled }),
                 _row("ai:provider", "Runs on", p ? p.sub : "Choose where Quasar AI thinks", "chevron",
                      { value: p ? p.label : "Not set up" })]
    if (p && p.cloud) {
        var k = (st.keys || {})[c.provider] || {}
        setup.push(_row("ai:key", "API key", k.set ? (k.store === "keyring" ? "Saved in your login keyring" : "Saved on this PC, only your account can read it") + "  ·  " + k.hint
                                                   : "Create one at " + p.keyUrl, "button",
                        { value: st.busy === "ai:key" ? "Checking…" : k.set ? "Change" : "Add key", busy: st.busy === "ai:key" }))
    }
    if (p) {
        var mid = c.model[c.provider] || ""
        var msub = c.provider === "ollama" ? (eng.installed ? (st.local.length ? "Downloaded models on this PC" : "Download a model below first") : "Install the engine first")
                 : ((st.keys || {})[c.provider] || {}).set ? "" : "Add the API key first"
        setup.push(_row("ai:model", "Model", msub, "chevron", { value: mid ? modelName(mid, st.catalog) : "Choose…", busy: st.busy === "ai:model" }))
    }
    out.push({ label: "Quasar AI", rows: setup })

    if (c.provider === "ollama" || eng.installed) {
        var erow
        if (job)
            erow = _row("ai:engine", "Ollama engine", (job.phase || "Starting") + "  ·  " + (job.pct || 0) + "%", "value",
                        { value: job.verb === "remove" ? "Removing" : (job.pct || 0) + "%", busy: true })
        else if (eng.installed)
            erow = _row("ai:engine", "Ollama engine", "Version " + (eng.version || "?") + "  ·  " + (eng.running ? "Running" : "Starts when Quasar AI needs it"),
                        "button", { value: "Remove", valueColor: ctx.theme.textMuted })
        else if (eng.live)
            erow = _row("ai:engine", "Ollama engine", "Install Quasar on a disk to run models on this PC", "value", { value: "Not on the live USB" })
        else
            erow = _row("ai:engine", "Ollama engine", "About 1.5 GB from GitHub. Runs only while Quasar AI needs it", "button", { value: "Install" })
        var rows = [erow]
        var accelText = eng.accel === "cuda" ? "NVIDIA CUDA" : eng.accel === "vulkan" ? "Graphics card (Vulkan)" : "Processor only"
        rows.push(_row("ai:accel", "Acceleration", (eng.gpu ? eng.gpu + "  ·  " : "") + Math.round((eng.ramMB || 0) / 1000) + " GB memory"
                                                   + (eng.vramMB ? ", " + Math.round(eng.vramMB / 1024) + " GB graphics memory" : ""),
                       "value", { value: accelText, valueColor: eng.accel === "cpu" ? ctx.theme.textMuted : ctx.theme.mint }))
        if (eng.installed && !job)
            rows.push(_row("ai:update", "Updates", st.latest && st.latest !== eng.version ? "Version " + st.latest + " is available" : "Checks GitHub only when you press Check",
                           "button", { value: st.busy === "ai:update" ? "Checking…" : st.latest && st.latest !== eng.version ? "Update" : "Check", busy: st.busy === "ai:update" }))
        out.push({ label: "On-device engine", rows: rows })
    }

    if (eng.installed) {
        var hw = { ramMB: eng.ramMB, vramMB: eng.vramMB, accel: eng.accel }
        var have = {}
        var lrows = (st.local || []).map(function (m) {
            have[m.id] = true
            var inUse = c.provider === "ollama" && c.model.ollama === m.id
            return _row("ai:local:" + m.id, modelName(m.id, st.catalog), gb(m.size) + (m.params ? "  ·  " + m.params + " parameters" : ""),
                        "chevron", { value: inUse ? "In use" : "", valueColor: ctx.theme.mint })
        })
        if (!lrows.length) lrows.push(_row("ai:none", "No models yet", "Download one below. Quasar suggests what suits this PC", "none"))
        out.push({ label: "Models on this PC", rows: lrows })

        var pulls = st.pulls || {}
        var picks = ranked(st.catalog, hw).filter(function (x) { return !have[x.m.id] && x.f.level !== "no" }).slice(0, 4)
        var grows = picks.map(function (x, i) {
            var pl = pulls[x.m.id]
            if (pl)
                return _row("ai:get:" + x.m.id, x.m.name, (pl.phase || "Downloading") + "  ·  " + pl.pct + "% of " + gbOf(x.m.sizeGB), "button",
                            { value: "Stop", busy: true })
            return _row("ai:get:" + x.m.id, x.m.name + (i === 0 ? "  ·  Best for this PC" : ""), x.m.blurb + "  " + x.f.note + ".", "button",
                        { value: "Download " + gbOf(x.m.sizeGB) })
        })
        grows.push(_row("ai:more", "All suggested models", (st.catalog || []).length + " models that can act on your PC", "chevron"))
        grows.push(_row("ai:other", "Other model…", "Any model from ollama.com/library, by name", "chevron"))
        out.push({ label: "Get models", rows: grows })
    }

    var prow = PERMS.map(function (x) {
        return _row("ai:perm:" + x[0], x[1], x[2], "toggle", { checked: c.perms[x[0]] })
    })
    prow.push(_row("ai:plan", "Show the plan before running", "Nothing changes until you press Run plan", "toggle", { checked: c.plan }))
    out.push({ label: "What Quasar can do", rows: prow })

    out.push({ label: "Privacy", rows: [
        _row("ai:history", "Conversations", "Kept in memory until you start a new task or the session ends", "value", { value: "Not saved", valueColor: ctx.theme.mint })
    ] })
    return out
}

function hero(st, ctx) {
    var c = cfg(st.ai), p = PROVIDERS[c.provider], eng = st.engine || {}
    var green = { fill: ctx.theme.alpha(ctx.theme.mint, 0.06), line: ctx.theme.alpha(ctx.theme.mint, 0.18), glow: "transparent" }
    var amber = { fill: ctx.theme.alpha(ctx.theme.amber, 0.06), line: ctx.theme.alpha(ctx.theme.amber, 0.2), glow: "transparent" }
    function card(base, extra) { var o = { glyph: ctx.icons.orbit }; for (var k in base) o[k] = base[k]; for (var e in extra) o[e] = extra[e]; return o }
    if (!c.enabled)
        return card({}, { title: "Quasar AI is off",
                          sub: "Turn it on to get Ask on the taskbar and Ask Quasar in the launcher. Nothing runs until you use it.",
                          button: "Turn on", buttonPrimary: true })
    if (!p)
        return card({}, { title: "Choose where Quasar AI runs",
                          sub: "On this PC with Ollama (private and free), or Claude, ChatGPT or Ollama Cloud with your own API key.",
                          button: "Set up", buttonPrimary: true })
    if (!p.cloud) {
        if (!eng.installed)
            return card(green, { title: "Runs entirely on this PC",
                                 sub: eng.live ? "Install Quasar on a disk to run models here. Claude, ChatGPT and Ollama Cloud work in the live session."
                                               : "Install the Ollama engine, then a model. No account, nothing leaves this PC.",
                                 button: eng.live || st.engineJob ? "" : "Install engine", buttonPrimary: true })
        var m = c.model.ollama
        return card(green, { title: "Runs entirely on this PC",
                             sub: m ? "Ollama on localhost  ·  " + modelName(m, st.catalog) + ". No account, nothing sent anywhere."
                                    : "Download a model below to start.",
                             button: m ? "Try it" : "" })
    }
    var key = ((st.keys || {})[c.provider] || {}).set
    return card(amber, { title: "Uses " + p.label,
                         sub: "Your requests go to " + p.company + " with your API key. Files are only sent when a task needs their contents.",
                         button: !key ? "Add API key" : c.model[c.provider] ? "Try it" : "", buttonPrimary: !key })
}
