import QtQuick
import Quickshell
import Quickshell.Io
import Quasar
import Quasar.Services
import "../components/ssh.js" as Ssh

// Settings > Users & Accounts > Remote sign-in (SSH).
// - On/off: `pkexec quasar-pkg install|remove ssh` (openssh-server, installed on demand: never in the
//   image; Quasar's settings: keys only, no root, the quasar-ssh group, home networks only).
// - Who may sign in: `pkexec quasar-users set-ssh` (one JSON line on stdin).
// - Your own keys: /usr/libexec/quasar/quasar-ssh-keys as you (no password); the key on stdin.
//   QUASAR_SSH_KEYS / QUASAR_PKG / QUASAR_USERS=/path: stand-ins (UI tests).
Scope {
    id: root
    property bool active: false               // the Users & Accounts page is shown
    property bool keysActive: false           // the "Your SSH keys" page is shown
    property var people: []
    property string me: Quickshell.env("USER") || ""
    property var st: null
    property string busy: ""
    property int progress: -1
    property var ask: null                    // { key, title, message, button, danger }
    property bool addOpen: false
    property string addError: ""
    signal notify(var banner)
    signal openKeys()

    readonly property string keysExe: Quickshell.env("QUASAR_SSH_KEYS") || "/usr/libexec/quasar/quasar-ssh-keys"
    readonly property string pkgExe: Quickshell.env("QUASAR_PKG") || ""
    readonly property string usersExe: Quickshell.env("QUASAR_USERS") || ""
    function pkg(args) { return (pkgExe ? [pkgExe] : ["pkexec", "/usr/libexec/quasar/quasar-pkg"]).concat(args) }
    function users(verb) { return (usersExe ? [usersExe] : ["pkexec", "/usr/libexec/quasar/quasar-users"]).concat([verb]) }

    readonly property var ctx: ({ people: people, me: me, busy: busy, progress: progress, live: Platform.live,
                                  icons: Icons, theme: Theme })
    readonly property var groups: Ssh.groups(st, ctx)
    readonly property var keyGroups: Ssh.keyGroups(st, ctx)

    onActiveChanged: if (active) refresh()
    onKeysActiveChanged: if (keysActive) refresh()

    property bool _again: false
    function refresh() {
        if (statusProc.running) { _again = true; return }
        statusProc.running = true
    }
    Process {
        id: statusProc
        command: [root.keysExe, "status"]
        stdout: StdioCollector { onStreamFinished: { try { root.st = JSON.parse(text) } catch (e) { } } }
        onExited: (code, status) => { if (root._again) { root._again = false; running = true } }
    }

    function toggle(key) { activate(key) }
    function activate(key) {
        if (key === "ssh:keys") { openKeys(); return }
        if (busy !== "" || Platform.live) return
        if (key === "ssh:on") {
            if (Ssh.isOn(st) || (st && st.installed))
                ask = { key: "off", title: "Turn off remote sign-in?", button: "Turn off", danger: true,
                        message: "Nobody can sign in to this PC from another computer any more. Your keys stay saved for next time." }
            else
                run("ssh:on", pkg(["install", "ssh"]), undefined, () => root.notify({ tone: "success", title: "Remote sign-in is on",
                    message: "Add your other computer's key under Your SSH keys, then connect from it." }))
        } else if (key.startsWith("ssh:allow:")) {
            const name = key.slice(10)
            const on = !((st && st.allowed) || []).includes(name)
            run(key, users("set-ssh"), JSON.stringify({ username: name, ssh: on }) + "\n")
        } else if (key === "sshk:add") {
            addError = ""
            addOpen = true
        } else if (key.startsWith("sshk:rm:")) {
            const k = ((st && st.keys) || []).find(x => "sshk:rm:" + x.fingerprint === key)
            if (k) ask = { key: key, title: "Remove this key?", button: "Remove", danger: true,
                           message: (k.comment || k.type) + " can't sign in as you any more." }
        }
    }
    function confirm() {
        const a = ask
        ask = null
        if (!a) return
        if (a.key === "off") run("ssh:on", pkg(["remove", "ssh"]))
        else if (a.key.startsWith("sshk:rm:")) run(a.key, [keysExe, "remove", a.key.slice(8)])
    }
    function addKey(text) {
        addError = ""
        run("sshk:add", [keysExe, "add"], text.trim() + "\n", () => { root.addOpen = false })
    }

    // One change at a time. Closing the password sheet (126) says nothing.
    property var _done: null
    function run(key, cmd, input, done) {
        busy = key
        progress = -1
        _done = done || null
        job.run(cmd, undefined, input)
    }
    Cmd {
        id: job
        onLine: (l) => { if (l.startsWith("PROGRESS ")) root.progress = parseInt(l.slice(9)) || 0 }
        onFinished: (code) => {
            const key = root.busy
            const done = root._done
            root._done = null
            root.busy = ""
            root.progress = -1
            if (code === 0) {
                if (done) done()
            } else if (code !== 126) {
                const err = job.details().split("\n").filter(l => l.startsWith("ERROR ")).map(l => l.slice(6)).pop()
                if (key === "sshk:add" && root.addOpen) root.addError = err || "That key couldn't be added."
                else root.notify(code === 127 ? { tone: "error", title: "Your account can't change this", message: "Ask an administrator." }
                                              : { tone: "error", title: err || "That didn't work", message: err ? "" : "Nothing was changed.",
                                                  details: job.details() })
            }
            root.refresh()
        }
    }
}
