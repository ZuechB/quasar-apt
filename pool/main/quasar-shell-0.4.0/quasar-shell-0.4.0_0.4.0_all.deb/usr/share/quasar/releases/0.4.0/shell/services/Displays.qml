import QtQuick
import Quickshell
import Quickshell.Io
import Quasar.Services

// The displays as the shell sees them: which one is the main display (desktop icons, toasts, sign-in
// prompts, the company pill), Identify, and hot-plug. Display work itself is
// /usr/libexec/quasar/displays (linux/system/libexec/displays):
//  * At login quasar-session-start runs `displays restore`, which re-applies the arrangement Settings
//    saved for the connected displays and writes $XDG_RUNTIME_DIR/quasar/displays.json: read here
//    before the first frame, so the main display is right from the start.
//  * When a display comes or goes (Quickshell.screens), `displays restore` runs again: the saved
//    arrangement for the new set of displays, or defaults for displays it hasn't seen together.
//  * The main display is the saved profile's (Settings.displays.profiles[key].main), so "Make main"
//    in Settings moves the desktop at once; without one, the helper's choice (built-in, else top-left).
Scope {
    id: root
    readonly property string helper: Quickshell.env("QUASAR_DISPLAYS") || "/usr/libexec/quasar/displays"
    property var state: null                         // the helper's last `state` (see the helper's doc)

    readonly property var screens: {
        const out = [], ss = Quickshell.screens
        for (let i = 0; i < ss.length; i++) out.push(ss[i])
        return out
    }
    readonly property string mainName: {
        const st = root.state
        if (!st) return ""
        const prof = (((Settings.displays || {}).profiles) || {})[st.key]
        if (prof && prof.main) {
            const o = (st.outputs || []).find(x => x.id === prof.main && x.enabled)
            if (o) return o.name
        }
        return st.main || ""
    }
    readonly property var main: {
        const ss = root.screens
        if (!ss.length) return null
        return ss.find(s => s.name === root.mainName)
            || ss.find(s => /^(eDP|LVDS|DSI)-/.test(s.name))
            || ss.slice().sort((a, b) => a.x - b.x || a.y - b.y)[0]
    }
    function has(s) { return !!s && root.screens.indexOf(s) >= 0 }
    function named(n) { return root.screens.find(s => s.name === n) || null }
    function output(s) { return s && root.state ? (root.state.outputs || []).find(o => o.name === s.name) || null : null }

    // ---- Identify: each display shows its number (and name) for a moment (Settings › Arrange displays).
    property var identifying: null                   // { connector name: number } while the badges show
    function identify(map) {
        const m = {}
        if (map) {
            for (const pair of String(map).split(",")) {
                const [n, num] = pair.split("=")
                if (n && Number(num) > 0) m[n.trim()] = Number(num)
            }
        } else if (root.state) {
            for (const o of root.state.outputs || []) m[o.name] = o.number
        }
        root.identifying = m
        identifyTimer.restart()
    }
    Timer { id: identifyTimer; interval: 2500; onTriggered: root.identifying = null }

    // ---- state: the login's file first, then the helper itself.
    FileView {
        path: (Quickshell.env("XDG_RUNTIME_DIR") || "/tmp") + "/quasar/displays.json"
        blockLoading: true
        printErrors: false
        onLoaded: { try { root.take(text()) } catch (e) { stateRun.running = true } }
        onLoadFailed: (error) => stateRun.running = true
    }
    function take(text) {
        const lines = String(text || "").trim().split("\n")
        let s = null
        try { s = JSON.parse(lines[lines.length - 1]) } catch (e) { return }
        if (!s || !s.outputs) return
        root.state = s
        // A display came or went while Settings was trying a change: look again once it's decided.
        if (s.pending && s.deadline) {
            retry.interval = Math.max(500, Math.round((s.deadline - Date.now() / 1000) * 1000) + 1500)
            retry.restart()
        }
    }
    Connections {
        target: Quickshell
        function onScreensChanged() { restoreTimer.restart() }
    }
    Timer {                                          // one restore per burst of output changes
        id: restoreTimer
        interval: 400
        onTriggered: { if (restoreRun.running) restart(); else restoreRun.running = true }
    }
    Timer { id: retry; onTriggered: restoreTimer.restart() }
    Process {
        id: restoreRun
        command: [root.helper, "restore"]
        stdout: StdioCollector { onStreamFinished: root.take(text) }
    }
    Process {
        id: stateRun
        command: [root.helper, "state"]
        stdout: StdioCollector { onStreamFinished: root.take(text) }
    }
    function refresh() { if (!stateRun.running) stateRun.running = true }

    //   qs --path /usr/share/quasar/shell ipc call displays identify "DP-1=1,eDP-1=2"
    IpcHandler {
        target: "displays"
        // Settings › Arrange displays passes its own numbering ("" = the helper's).
        function identify(map: string): void { root.identify(map) }
        function refresh(): void { root.refresh() }
        function state(): string {
            return JSON.stringify({ main: root.main ? root.main.name : "", mainName: root.mainName,
                                    screens: root.screens.map(s => ({ name: s.name, x: s.x, y: s.y, width: s.width, height: s.height })),
                                    key: root.state ? root.state.key : "", identifying: root.identifying })
        }
    }
}
