import QtQuick
import Quasar

// Appearance pickers (template): ACCENT — 44px round swatches with a 2px ring on the chosen one.
// (The wallpaper cards are on the Display page: WallpaperPicker.qml.)
Column {
    id: root
    property string accent: Theme.accent
    signal accentPicked(string color)
    spacing: 0

    SectionLabel { leftPadding: 4; bottomPadding: 10; text: "Accent" }
    Row {
        spacing: 10
        Repeater {
            model: Theme.accents
            Pressable {
                required property var modelData
                readonly property bool on: root.accent.toLowerCase() === modelData.color.toLowerCase()
                width: 44; height: 44; radius: 22
                kind: "chip"
                borderWidth: 2
                borderColor: on ? modelData.color : "transparent"
                hoverBorderColor: on ? modelData.color : Theme.white(0.2)
                accessibleName: modelData.name
                Accessible.role: Accessible.RadioButton
                Accessible.checked: on
                onClicked: root.accentPicked(modelData.color)
                Rectangle { anchors.fill: parent; anchors.margins: 6; radius: width / 2; color: modelData.color }
            }
        }
    }
}
