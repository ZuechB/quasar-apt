import QtQuick

// One settings row (template: min-height 58, padding 10 14 10 16, gap 14): optional 32px icon tile,
// 14px/500 label + 12.5px #8E96A8 sub, then a trailing control:
//   "toggle"  QSwitch            "chevron" value text (valueColor) + ›; the whole row opens a sub page/picker
//   "value"   coloured value     "button"  a soft Button (text = value)
//   "soon"    disabled, "Coming soon" pill — rows whose system feature isn't built yet
//   "custom"  whatever is placed inside the row
Item {
    id: root
    property string label: ""
    property string sub: ""
    property string glyph: ""
    property string trailing: "none"
    property bool checked: false
    property string value: ""
    property color valueColor: Theme.textMuted
    property bool busy: false
    default property alias custom: customSlot.data
    signal toggled()
    signal activated()

    readonly property bool soon: trailing === "soon"
    width: parent ? parent.width : 400
    implicitHeight: Math.max(58, textCol.implicitHeight + 20)
    Accessible.role: trailing === "toggle" ? Accessible.CheckBox : Accessible.ListItem
    Accessible.name: label + (soon ? ", coming soon" : "")

    // Divider above every row except the first in its group.
    Rectangle {
        visible: root.y > 0
        width: parent.width; height: 1
        color: Theme.white(0.05)
    }

    // A chevron row opens a page or a picker: the whole row is its button (the › keeps its own hover).
    // Inset, so the highlight never pokes out of the group's rounded corners.
    Rectangle {
        visible: root.trailing === "chevron"
        x: 6; y: 4
        width: parent.width - 12; height: parent.height - 8
        radius: 12
        color: rowArea.containsMouse ? Theme.white(rowArea.pressed ? 0.05 : 0.03) : "transparent"
        Behavior on color { ColorAnimation { duration: Motion.press } }
    }
    MouseArea {
        id: rowArea
        anchors.fill: parent
        enabled: root.trailing === "chevron"
        hoverEnabled: enabled
        cursorShape: Qt.PointingHandCursor
        onClicked: root.activated()
    }

    Rectangle {
        id: tile
        visible: root.glyph !== ""
        x: 16
        anchors.verticalCenter: parent.verticalCenter
        width: 32; height: 32; radius: 10
        color: Theme.white(0.05)
        QIcon { anchors.centerIn: parent; path: root.glyph; size: 16; strokeWidth: 1.9; color: root.soon ? Theme.textFaint : Theme.text3 }
    }

    Column {
        id: textCol
        anchors {
            left: tile.visible ? tile.right : parent.left; leftMargin: tile.visible ? 14 : 16
            right: trail.left; rightMargin: 14
            verticalCenter: parent.verticalCenter
        }
        spacing: 2
        Text {
            width: parent.width
            text: root.label
            elide: Text.ElideRight
            font.family: Theme.fontUi; font.pixelSize: 14; font.weight: Font.Medium
            color: root.soon ? Theme.textDim : Theme.text
        }
        Text {
            visible: root.sub !== ""
            width: parent.width
            text: root.sub
            wrapMode: Text.Wrap
            font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
            color: Theme.textDim
        }
    }

    // A Row lays out (and sizes itself from) only the visible control, so it stays centred.
    Row {
        id: trail
        anchors { right: parent.right; rightMargin: 14; verticalCenter: parent.verticalCenter }
        spacing: 10

        // A switch whose change is still running (a password prompt, a root helper): dimmed and
        // unclickable, with a spinner, until the new state is read back.
        Spinner {
            anchors.verticalCenter: parent.verticalCenter
            visible: root.busy && root.trailing === "toggle"
            size: 16
        }
        QSwitch {
            anchors.verticalCenter: parent.verticalCenter
            visible: root.trailing === "toggle"
            enabled: !root.busy
            checked: root.checked
            accessibleName: root.label
            onToggled: root.toggled()
        }
        Pressable {
            anchors.verticalCenter: parent.verticalCenter
            visible: root.trailing === "chevron"
            kind: "hov"; radius: 9
            height: 34
            width: chevRow.implicitWidth + 16
            accessibleName: root.label
            onClicked: root.activated()
            Row {
                id: chevRow
                anchors { right: parent.right; rightMargin: 6; verticalCenter: parent.verticalCenter }
                spacing: 6
                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    visible: root.value !== ""
                    text: root.value
                    font.family: Theme.fontUi; font.pixelSize: 13
                    color: root.valueColor
                }
                QIcon { anchors.verticalCenter: parent.verticalCenter; path: Icons.fwd; size: 15; strokeWidth: 2; color: Theme.textMuted }
            }
        }
        Text {
            anchors.verticalCenter: parent.verticalCenter
            visible: root.trailing === "value"
            text: root.value
            horizontalAlignment: Text.AlignRight
            font.family: Theme.fontUi; font.pixelSize: 13
            color: root.valueColor
        }
        Button {
            anchors.verticalCenter: parent.verticalCenter
            visible: root.trailing === "button"
            text: root.value
            variant: "soft"
            size: 34
            busy: root.busy
            onClicked: root.activated()
        }
        Rectangle {
            anchors.verticalCenter: parent.verticalCenter
            visible: root.soon
            height: 22; radius: 11
            width: soonText.implicitWidth + 16
            color: Theme.white(0.05)
            border.width: 1
            border.color: Theme.white(0.06)
            Text {
                id: soonText
                anchors.centerIn: parent
                text: "Coming soon"
                font.family: Theme.fontUi; font.pixelSize: 11; font.weight: Font.Medium
                color: Theme.textFaint
            }
        }
        Item {
            id: customSlot
            anchors.verticalCenter: parent.verticalCenter
            visible: root.trailing === "custom"
            width: childrenRect.width
            height: childrenRect.height
        }
    }
}
