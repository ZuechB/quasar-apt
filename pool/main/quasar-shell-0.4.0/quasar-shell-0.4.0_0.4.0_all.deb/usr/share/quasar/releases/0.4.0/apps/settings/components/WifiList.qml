import QtQuick
import Quasar

// AVAILABLE NETWORKS (template Settings > Network): rows of 58px with signal bars, name + status,
// lock for secured networks, then Connected + Disconnect / a "Connecting" spinner / Connect, and Forget
// for saved networks. Picking a password network that isn't saved (or whose password was refused)
// opens an inline password row under it; work/school (Enterprise) networks ask for a sign-in instead
// (enterprisePicked). "Join other network…" adds a hidden network.
// Pure view: `networks` is an array (preview) or a keyed ScriptModel (the app) of
//   { key, name, security: "WPA3"|"WPA2"|"WPA"|"Enterprise"|"Enhanced Open"|"Open"|"WEP"|…,
//     kind: "open"|"psk"|"enterprise"|"wep", level 1-4, connected, known, busy }
Column {
    id: root
    property var networks: []
    property bool scanning: false
    property string passwordFor: ""
    signal picked(string name)
    signal connectClicked(string name, string password)
    signal cancelled()
    signal disconnectClicked(string name)
    signal forgetClicked(string name)
    signal joinOtherClicked()

    spacing: 0

    Item {
        width: parent.width
        height: label.implicitHeight + 8
        SectionLabel { id: label; x: 4; text: "Available networks" }
        Text {
            anchors { right: parent.right; rightMargin: 4; baseline: label.baseline }
            text: root.scanning ? "Scanning…" : (rep.count + (rep.count === 1 ? " network" : " networks"))
            font.family: Theme.fontUi; font.pixelSize: 12
            color: Theme.textDim
        }
    }

    Rectangle {
        width: parent.width
        height: list.implicitHeight
        radius: 16
        color: Theme.white(0.035)
        border.width: 1; border.color: Theme.white(0.06)
        clip: true

        Column {
            id: list
            width: parent.width
            Repeater {
                id: rep
                model: root.networks
                Rectangle {
                    id: rowRoot
                    required property int index
                    required property var modelData
                    readonly property bool secured: modelData.kind !== "open"
                    readonly property bool open: root.passwordFor === modelData.name && !modelData.busy
                    width: list.width
                    height: main.height + (open ? pwRow.height : 0)
                    color: modelData.connected ? Theme.alpha(Theme.accent, 0.06) : "transparent"
                    Behavior on height { NumberAnimation { duration: Motion.dur(260); easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.soft } }
                    clip: true

                    Rectangle { visible: rowRoot.index > 0; width: parent.width; height: 1; color: Theme.white(0.05) }

                    Item {
                        id: main
                        width: parent.width
                        height: 58
                        SignalBars {
                            id: bars
                            x: 16
                            anchors.verticalCenter: parent.verticalCenter
                            level: modelData.level
                            color: modelData.connected ? Theme.accent : Theme.text3
                        }
                        Column {
                            anchors { left: bars.right; leftMargin: 14; right: trail.left; rightMargin: 12; verticalCenter: parent.verticalCenter }
                            spacing: 2
                            Text { width: parent.width; elide: Text.ElideRight; text: modelData.name; textFormat: Text.PlainText; font.family: Theme.fontUi; font.pixelSize: 14; font.weight: Font.Medium; color: Theme.text }
                            Text {
                                width: parent.width; elide: Text.ElideRight
                                text: modelData.connected ? "Connected  ·  " + modelData.security
                                    : modelData.known ? "Saved  ·  " + modelData.security
                                    : modelData.kind === "enterprise" ? "Work or school sign-in"
                                    : modelData.kind === "wep" ? "WEP  ·  outdated security, not supported"
                                    : rowRoot.secured ? "Secured  ·  " + modelData.security
                                    : modelData.security === "Enhanced Open" ? "Open, encrypted" : "Open network"
                                font.family: Theme.fontUi; font.pixelSize: 12; color: Theme.textDim
                            }
                        }
                        Row {
                            id: trail
                            anchors { right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter }
                            spacing: 10
                            QIcon { visible: rowRoot.secured && !modelData.connected && !modelData.busy; anchors.verticalCenter: parent.verticalCenter; path: Icons.lock; size: 14; strokeWidth: 2; color: Theme.textFaint }
                            Row {
                                visible: modelData.connected && !modelData.busy
                                anchors.verticalCenter: parent.verticalCenter
                                spacing: 6
                                Rectangle { anchors.verticalCenter: parent.verticalCenter; width: 7; height: 7; radius: 3.5; color: Theme.accent }
                                Text { anchors.verticalCenter: parent.verticalCenter; text: "Connected"; font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5); font.weight: Font.DemiBold; color: Theme.accent }
                            }
                            Row {
                                visible: modelData.busy
                                anchors.verticalCenter: parent.verticalCenter
                                spacing: 8
                                Spinner { anchors.verticalCenter: parent.verticalCenter }
                                Text { anchors.verticalCenter: parent.verticalCenter; text: "Connecting"; font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5); color: Theme.text3 }
                            }
                            Button { visible: modelData.connected && !modelData.busy; text: "Disconnect"; variant: "outline"; size: 30; onClicked: root.disconnectClicked(modelData.name) }
                            Button {
                                visible: !modelData.connected && !modelData.busy && !rowRoot.open && modelData.kind !== "wep"
                                text: "Connect"; variant: "soft"; size: 30
                                fontWeight: Font.Medium
                                onClicked: root.picked(modelData.name)
                            }
                            Button { visible: modelData.known && !modelData.busy && !rowRoot.open; text: "Forget"; variant: "outline"; size: 30; onClicked: root.forgetClicked(modelData.name) }
                        }
                    }

                    Row {
                        id: pwRow
                        y: main.height
                        x: 50
                        width: parent.width - 66
                        height: 52
                        spacing: 8
                        visible: rowRoot.open
                        TextField {
                            id: pw
                            width: parent.width - connectBtn.width - cancelBtn.width - 16
                            glyph: Icons.lock
                            placeholder: "Network password"
                            password: true
                            onAccepted: if (connectBtn.enabled) root.connectClicked(modelData.name, text)
                            onEscapePressed: root.cancelled()
                        }
                        // WPA/WPA2 passwords are 8-63 characters; WPA3 allows shorter ones.
                        Button { id: connectBtn; text: "Connect"; variant: "primary"; size: 38; enabled: pw.text.length >= (modelData.security === "WPA3" ? 1 : 8); onClicked: root.connectClicked(modelData.name, pw.text) }
                        Button { id: cancelBtn; text: "Cancel"; variant: "outline"; size: 38; onClicked: root.cancelled() }
                    }
                    onOpenChanged: if (open) { pw.text = ""; pw.focusInput() }
                }
            }
            Text {
                visible: rep.count === 0
                width: list.width
                leftPadding: 16; topPadding: 18; bottomPadding: 18
                text: root.scanning ? "Looking for networks…" : "No Wi-Fi networks found."
                font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5); color: Theme.textDim
            }
            // Hidden networks don't show up in the list: add one by name.
            Pressable {
                width: list.width; height: 50
                radius: 0; kind: "hov"
                color: "transparent"
                accessibleName: "Join other network"
                onClicked: root.joinOtherClicked()
                Rectangle { width: parent.width; height: 1; color: Theme.white(0.05) }
                QIcon { x: 18; anchors.verticalCenter: parent.verticalCenter; path: Icons.plus; size: 15; strokeWidth: 2; color: Theme.text3 }
                Text {
                    x: 50; anchors.verticalCenter: parent.verticalCenter
                    text: "Join other network…"
                    font.family: Theme.fontUi; font.pixelSize: 14; color: Theme.text2
                }
            }
        }
    }
}
