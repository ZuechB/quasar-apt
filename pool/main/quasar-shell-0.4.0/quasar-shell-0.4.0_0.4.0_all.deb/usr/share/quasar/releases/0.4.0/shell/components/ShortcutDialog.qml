import QtQuick
import Quasar

// "New website shortcut" card (Dialog look): an address and an optional name. A bare host gets
// https://; only web and mail links are allowed. Enter in either field creates, Esc cancels.
Rectangle {
    id: root
    property string error: ""
    signal accepted(string url, string name)
    signal cancelled()

    function begin() {
        address.text = ""
        title.text = ""
        error = ""
        address.focusInput()
    }
    function submit() {
        let u = address.text.trim()
        if (!u) { error = "Type a web address"; return }
        if (!/^[a-z][a-z0-9+.-]*:/i.test(u)) u = "https://" + u
        // A host needs a dot (example.com), or is localhost / an IP address.
        const m = /^(?:https?|ftp):\/\/([^\s/?#]+)(?:[/?#]\S*)?$/i.exec(u)
        const host = m ? m[1].replace(/^[^@]*@/, "").replace(/:\d+$/, "") : ""
        const web = !!host && (/^[^.]+(\.[^.]+)+\.?$/.test(host) || host === "localhost" || /^\[[0-9a-f:]+\]$/i.test(host))
        if (!web && !/^mailto:[^\s@]+@[^\s@]+$/i.test(u)) { error = "That doesn't look like a web address"; return }
        accepted(u, title.text.trim())
    }

    implicitWidth: 420
    implicitHeight: col.implicitHeight + 44
    radius: 20
    color: Theme.solid
    border.width: 1
    border.color: Theme.white(0.1)
    Accessible.role: Accessible.Dialog
    Accessible.name: "New website shortcut"

    Column {
        id: col
        x: 22; y: 22
        width: root.width - 44
        spacing: 14
        Text {
            text: "New website shortcut"
            font.family: Theme.fontDisplay; font.pixelSize: 20; font.weight: Font.Medium
            color: Theme.text
        }
        Column {
            width: parent.width
            spacing: 6
            Text { text: "Address"; font.family: Theme.fontUi; font.pixelSize: 12; font.weight: Font.Medium; color: Theme.text3 }
            TextField {
                id: address
                width: parent.width
                glyph: Icons.globe
                placeholder: "example.com"
                error: root.error !== ""
                onEdited: root.error = ""
                onAccepted: root.submit()
                onEscapePressed: root.cancelled()
            }
            Text {
                visible: root.error !== ""
                text: root.error
                font.family: Theme.fontUi; font.pixelSize: 12
                color: Theme.danger
            }
        }
        Column {
            width: parent.width
            spacing: 6
            Text { text: "Name (optional)"; font.family: Theme.fontUi; font.pixelSize: 12; font.weight: Font.Medium; color: Theme.text3 }
            TextField {
                id: title
                width: parent.width
                placeholder: "Shown under the icon"
                onAccepted: root.submit()
                onEscapePressed: root.cancelled()
            }
        }
        Row {
            anchors.right: parent.right
            spacing: 8
            Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: root.cancelled() }
            Button { text: "Create"; variant: "primary"; size: 38; onClicked: root.submit() }
        }
    }
}
