import QtQuick
import Quickshell
import Quickshell.Io

// Read-only facts for About / Storage / Performance, gathered once when Settings opens.
Scope {
    id: root
    property string hostname: ""
    property string osName: "Quasar"
    property string kernel: ""
    property string cpu: ""
    property real memGB: 0
    property string virt: "none"           // systemd-detect-virt (none | kvm | microsoft | …)
    property string encrypted: ""          // "On (LUKS)" | "Off"
    property real diskTotal: 0
    property real diskUsed: 0
    property real homeBytes: 0
    property real flatpakBytes: 0
    function refresh() { facts.running = true }
    function refreshStorage() { storage.running = true }
    Component.onCompleted: refresh()

    Process {
        id: facts
        command: ["sh", "-c",
            "echo \"host=$(hostname)\"; . /etc/os-release 2>/dev/null; echo \"os=$PRETTY_NAME\"; echo \"kernel=$(uname -r)\";"
            + " echo \"cpu=$(sed -n 's/^model name[[:space:]]*: //p' /proc/cpuinfo | head -1)\";"
            + " echo \"mem=$(awk '/^MemTotal:/ {print $2}' /proc/meminfo)\"; echo \"virt=$(systemd-detect-virt 2>/dev/null || echo none)\";"
            + " echo \"crypt=$(lsblk -nro TYPE 2>/dev/null | grep -qx crypt && echo yes || echo no)\""]
        stdout: StdioCollector {
            onStreamFinished: {
                for (const line of text.split("\n")) {
                    const i = line.indexOf("=")
                    if (i < 0) continue
                    const k = line.slice(0, i), v = line.slice(i + 1).trim()
                    if (k === "host") root.hostname = v
                    else if (k === "os") root.osName = v || "Quasar"
                    else if (k === "kernel") root.kernel = v
                    else if (k === "cpu") root.cpu = v
                    else if (k === "mem") root.memGB = Math.round((parseInt(v) || 0) / 1048576)
                    else if (k === "virt") root.virt = v
                    else if (k === "crypt") root.encrypted = v === "yes" ? "On (LUKS)" : "Off"
                }
            }
        }
    }
    Process {
        id: storage
        command: ["sh", "-c", "df -B1 --output=size,used / | tail -1; nice -n 10 du -sb \"$HOME\" 2>/dev/null | cut -f1; "
                            + "nice -n 10 du -sbc /var/lib/flatpak \"$HOME/.local/share/flatpak\" 2>/dev/null | tail -1 | cut -f1"]
        stdout: StdioCollector {
            onStreamFinished: {
                const l = text.trim().split("\n")
                const d = (l[0] || "").trim().split(/\s+/)
                root.diskTotal = parseFloat(d[0]) || 0
                root.diskUsed = parseFloat(d[1]) || 0
                root.homeBytes = parseFloat(l[1]) || 0
                root.flatpakBytes = parseFloat(l[2]) || 0
            }
        }
    }
}
