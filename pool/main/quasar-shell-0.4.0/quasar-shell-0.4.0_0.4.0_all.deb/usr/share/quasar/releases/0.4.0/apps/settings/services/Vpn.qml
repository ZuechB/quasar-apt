import QtQuick
import Quickshell
import Quasar
import Quasar.Services
import "../components/vpn.js" as V

// Settings > Network & Internet > VPN: add a WireGuard or OpenVPN profile from a file, connect and
// disconnect, sign in, rename, remove. Everything goes through `nm-ctl` as the user (NetworkManager's
// polkit rules decide); secrets go on its stdin, never argv. One change at a time; the list is read
// back after each (NmList). The VPN last used is remembered in Settings.network.vpn, so the shell's
// Quick settings tile and the hero switch know which one to connect.
Scope {
    id: root
    property var st: null                    // NmList.st
    property string busy: ""                 // "vpn:<uuid>" or "vpn:add" while a change runs
    property string sheetUuid: ""            // the VPN whose dialog is open
    property var form: null                  // { kind: "login", uuid, name, needs } | { kind: "rename", uuid, name }
    property var ask: null                   // { key, title, message, button, danger }
    property bool chooserOpen: false         // FileChooser for .conf / .ovpn
    signal notify(var banner)
    signal changed()                         // read the list again
    signal pick(string title, var options, string current, var done, string message)

    readonly property string exe: Quickshell.env("QUASAR_NM_CTL") || "/usr/libexec/quasar/nm-ctl"
    readonly property var ctx: ({ busy: busy, last: (Settings.network || {}).vpn || null, icons: Icons, theme: Theme })
    readonly property var networkRow: V.networkRow(st, ctx)
    readonly property var hero: V.hero(st, ctx)
    readonly property var groups: V.groups(st, ctx)
    readonly property var sheet: sheetUuid ? V.sheet(V.byUuid(st, sheetUuid), ctx) : null

    function remember(uuid, name) {
        const n = Object.assign({}, Settings.network || {})
        n.vpn = uuid ? { uuid: uuid, name: name } : null
        Settings.network = n
    }

    // ---- page actions --------------------------------------------------------------------------------
    function activate(key) {
        if (key === "vpn:add") { chooserOpen = true; return }
        if (key.startsWith("vpn:item:")) { sheetUuid = key.slice(9); return }
    }
    function heroActivated() { chooserOpen = true }          // "Add a VPN"
    function heroToggled() {
        if (busy !== "" || !st) return
        const on = V.connected(st)
        if (on) { disconnect(on.uuid); return }
        const v = V.current(st, ctx)
        if (v) { connect(v.uuid); return }
        pick("Connect to", V.vpns(st).map(x => ({ key: x.uuid, label: x.name, sub: V.kindName(x.kind) })), "",
             (u) => root.connect(u), "")
    }

    // ---- changes -------------------------------------------------------------------------------------
    function connect(uuid) {
        const v = V.byUuid(st, uuid)
        if (!v || busy !== "") return
        if (V.needsLogin(v)) { form = { kind: "login", uuid: uuid, name: v.name, needs: v.needs }; return }
        run("vpn:" + uuid, ["vpn-up", uuid], undefined, (r) => {
            root.remember(uuid, v.name)
            root.notify({ tone: "success", title: "Connected to " + v.name, message: "" })
        }, (r) => {
            if (r.reason === "needs-secrets" || r.reason === "password")
                root.form = { kind: "login", uuid: uuid, name: v.name, needs: v.needs.length ? v.needs : ["user", "password"] }
        })
    }
    function disconnect(uuid) {
        if (busy !== "") return
        run("vpn:" + uuid, ["vpn-down", uuid])
    }
    function importFile(path) {
        chooserOpen = false
        run("vpn:add", ["vpn-import"], JSON.stringify({ path: path }) + "\n", (r) => {
            root.remember(r.uuid, r.name)
            if ((r.needs || []).some(n => n === "user" || n === "password" || n === "keyPassword")) {
                root.form = { kind: "login", uuid: r.uuid, name: r.name, needs: r.needs }
                return
            }
            const note = V.noteText(r.notes)
            root.notify({ tone: "success", title: r.name + " is added",
                          message: (note ? note + " " : "") + "The file you picked holds this VPN's key: delete it if you don't need it any more." })
        })
    }
    function submitLogin(user, password, keyPassword) {
        const f = form
        form = null
        if (!f) return
        const spec = { uuid: f.uuid }
        if (user !== undefined && user !== null) spec.user = user
        if (password !== undefined && password !== null) spec.password = password
        if (keyPassword) spec.keyPassword = keyPassword
        run("vpn:" + f.uuid, ["vpn-secrets"], JSON.stringify(spec) + "\n", () => {
            Qt.callLater(() => root.connectAfterLogin(f.uuid, f.name))       // after this run has ended
        })
    }
    // After signing in the list may not be read back yet: connect by uuid without waiting for it.
    function connectAfterLogin(uuid, name) {
        run("vpn:" + uuid, ["vpn-up", uuid], undefined, () => {
            root.remember(uuid, name)
            root.notify({ tone: "success", title: "Connected to " + name, message: "" })
        }, (r) => {
            if (r.reason === "password" || r.reason === "needs-secrets")
                root.form = { kind: "login", uuid: uuid, name: name, needs: ["user", "password"] }
        })
    }
    function rename(uuid, name) {
        form = null
        run("vpn:" + uuid, ["vpn-set"], JSON.stringify({ uuid: uuid, name: name }) + "\n", () => {
            const last = (Settings.network || {}).vpn
            if (last && last.uuid === uuid) root.remember(uuid, name)
        })
    }
    function setAutostart(uuid, on) {
        run("vpn:" + uuid, ["vpn-set"], JSON.stringify({ uuid: uuid, autostart: on }) + "\n")
    }
    function askRemove(uuid) {
        const v = V.byUuid(st, uuid)
        if (!v) return
        ask = { key: "vpn:rm:" + uuid, title: "Remove " + v.name + "?", button: "Remove", danger: true,
                message: "Its settings and keys are deleted from this PC. To use it again you'll need its file." }
    }
    function confirm() {
        const a = ask
        ask = null
        if (!a || !a.key.startsWith("vpn:rm:")) return
        const uuid = a.key.slice(7)
        sheetUuid = ""
        run("vpn:" + uuid, ["vpn-remove", uuid], undefined, () => {
            const last = (Settings.network || {}).vpn
            if (last && last.uuid === uuid) root.remember("", "")
        })
    }

    // ---- one nm-ctl call at a time ---------------------------------------------------------------------
    property var _ok: null
    property var _fail: null
    property var _result: null
    function run(key, args, input, ok, fail) {
        busy = key
        _ok = ok || null
        _fail = fail || null
        _result = null
        job.run([exe].concat(args), undefined, input)
    }
    Cmd {
        id: job
        onLine: (l) => { try { const o = JSON.parse(l); if (o.result !== undefined) root._result = o } catch (e) { } }
        onFinished: (code) => {
            const ok = root._ok, fail = root._fail, r = root._result || {}
            root._ok = null
            root._fail = null
            root.busy = ""
            if (code === 0) {
                if (ok) ok(r)
            } else if (r.reason !== "cancelled") {
                const t = V.reasonText(r.reason || "other")
                root.notify({ tone: "error", title: t.title, message: t.message || r.detail || "",
                              details: r.detail || job.details() })
                if (fail) fail(r)
            }
            root.changed()
        }
    }
}
