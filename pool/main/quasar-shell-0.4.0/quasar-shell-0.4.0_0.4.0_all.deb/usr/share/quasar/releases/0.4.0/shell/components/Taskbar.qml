import QtQuick
import Quasar

// Taskbar content (mockup <footer>): 56px glass bar. Pure view — the Quickshell window binds data in.
// Leaves `tooltipHeadroom` px of transparent space above the bar for magnified icons and tooltips;
// the host window masks input to `bar` (+ the visible tooltip).
Item {
    id: root

    // ---- data in -------------------------------------------------------------------
    property var tasks: []                // [{ key, name, glyph, icon, letter, hue, running, focused, minimized, count }]
    property string menuKey: ""           // key of the task whose window list / menu is open
    property int workspaceCount: 3
    property int currentWorkspace: 0
    property bool showWorkspaces: true
    property bool launcherOpen: false
    property bool quickOpen: false
    property bool calendarOpen: false
    property bool assistantOpen: false
    property bool assistantAvailable: false   // Settings › Quasar AI is on (off by default)
    property string timeText: "9:41 AM"
    property string dateText: "Sun, Nov 15"
    property bool wifiConnected: true
    property bool wiredConnected: false
    property bool vpnOn: false              // a VPN is connected (NetState): a lock on the network icon
    property bool hotspotOn: false          // the Mobile hotspot is on: its icon beside the network's
    property bool deckOn: false             // Command Deck: a phone is connected (its icon shows)
    property bool deckLive: false           // … and sees the screen (accent, with a live dot)
    property bool deckOpen: false           // the phone icon's menu is open
    property int vncViewers: 0              // Remote desktop: computers that see and use this screen now
    property bool vncOpen: false            // its menu is open
    // Services tray (template): shown once a server was added or something failed (BackgroundServices).
    property bool servicesShown: false
    property int servicesRunning: 0
    property int servicesFailed: 0
    property string servicesLabel: ""
    property bool servicesOpen: false       // its menu is open
    property real tooltipHeadroom: 40

    // ---- signals out -----------------------------------------------------------------
    signal launcherClicked()
    signal workspacePicked(int index)
    // x/y: the button's top centre in Taskbar coordinates (= screen x; menus open above it)
    signal taskClicked(int index, real x)
    signal taskRightClicked(int index, real x, real y)
    signal taskMiddleClicked(int index)   // middle-click or Shift+click: new window
    signal assistantClicked()
    signal quickClicked()
    signal deckClicked(real x)              // the phone icon: x = its centre (the menu opens above it)
    signal vncClicked(real x)               // the remote desktop icon: the same
    // The Services tray: x = its centre. A click opens its menu when something failed, else Services; a
    // right-click always opens the menu (shell.qml openServicesMenu).
    signal servicesClicked(real x)
    signal servicesRightClicked(real x)
    signal calendarClicked()
    signal showDesktopClicked()

    readonly property alias bar: bar
    readonly property alias taskRow: taskRow
    property int hoveredTask: -1

    implicitHeight: Theme.taskbarHeight + tooltipHeadroom

    Rectangle {
        id: bar
        anchors { left: parent.left; right: parent.right; bottom: parent.bottom }
        height: Theme.taskbarHeight
        color: Theme.taskbarBg
        Rectangle { anchors { left: parent.left; right: parent.right; top: parent.top } height: 1; color: Theme.white(0.07) }

        // ---------------- left: launcher (search lives in it), workspaces ----------------
        Row {
            id: leftGroup
            anchors { left: parent.left; leftMargin: 8; verticalCenter: parent.verticalCenter }
            spacing: 6

            LauncherButton {
                open: root.launcherOpen
                onClicked: root.launcherClicked()
            }

            Rectangle {
                id: wsGroup
                visible: root.showWorkspaces
                width: wsRow.width + 6; height: 36; radius: 11
                color: Theme.white(0.04)
                anchors.verticalCenter: parent.verticalCenter
                Row {
                    id: wsRow
                    anchors.centerIn: parent
                    spacing: 3
                    Repeater {
                        model: root.workspaceCount
                        delegate: Pressable {
                            required property int index
                            width: 30; height: 30; radius: 8; kind: "plain"
                            color: index === root.currentWorkspace ? Theme.white(0.14) : "transparent"
                            hoverColor: index === root.currentWorkspace ? Theme.white(0.14) : Theme.white(0.06)
                            accessibleName: "Workspace " + (index + 1)
                            onClicked: root.workspacePicked(index)
                            Text {
                                anchors.centerIn: parent
                                text: index + 1
                                font.family: Theme.fontMono; font.pointSize: Theme.pt(11.5)
                                color: index === root.currentWorkspace ? Theme.text : Theme.textFaint
                                Behavior on color { ColorAnimation { duration: Motion.dur(300) } }
                            }
                        }
                    }
                }
            }
        }

        // ---------------- center: tasks ----------------
        Row {
            id: taskRow
            anchors.centerIn: parent
            spacing: 3
            Repeater {
                model: root.tasks
                delegate: Item {
                    id: task
                    required property int index
                    required property var modelData
                    width: 48; height: 46
                    readonly property int dist: root.hoveredTask < 0 ? 99 : Math.abs(index - root.hoveredTask)
                    readonly property real mag: dist === 0 ? 1.2 : dist === 1 ? 1.08 : 1.0
                    readonly property real lift: dist === 0 ? -5 : dist === 1 ? -2 : 0
                    readonly property int count: modelData.count || 0
                    readonly property bool menuOpen: root.menuKey !== "" && modelData.key === root.menuKey
                    readonly property string label: modelData.name + (count > 1 ? " (" + count + ")" : "")

                    Item {
                        id: taskVisual
                        anchors.fill: parent
                        transformOrigin: Item.Bottom
                        scale: tMouse.pressed ? 0.92 : task.mag
                        transform: Translate {
                            y: task.lift
                            Behavior on y { NumberAnimation { duration: Motion.dur(Motion.tile); easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.spring } }
                        }
                        Behavior on scale { NumberAnimation { duration: Motion.dur(Motion.tile); easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.spring } }

                        Rectangle {
                            anchors.fill: parent; radius: 12
                            color: task.modelData.focused ? Theme.white(0.08) : ((task.dist === 0 || task.menuOpen) ? Theme.white(0.06) : "transparent")
                            Behavior on color { ColorAnimation { duration: Motion.dur(200) } }
                        }
                        AppTile {
                            anchors.centerIn: parent
                            size: 34; radius: 11
                            base: Theme.taskTileBase; sheen: 0.13; borderAlpha: 0.08
                            hue: task.modelData.hue || Theme.text3
                            glyph: task.modelData.glyph || ""
                            image: task.modelData.icon || ""
                            letter: task.modelData.letter || ""
                            glyphSize: 19; glyphStroke: 1.9
                        }
                        // Window count (mockup hasBadge): pops in when an app has several windows.
                        Rectangle {
                            id: badge
                            property int shown: 2          // keeps the last count while it pops out
                            anchors { top: parent.top; topMargin: 1; right: parent.right; rightMargin: 2 }
                            height: 18; radius: 9
                            width: Math.max(18, countText.implicitWidth + 8)
                            color: Theme.text3
                            border.width: 2; border.color: Theme.windowOpaque
                            scale: task.count > 1 ? 1 : 0
                            visible: scale > 0.01
                            Behavior on scale { NumberAnimation { duration: Motion.dur(450); easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.spring } }
                            Text {
                                id: countText
                                anchors.centerIn: parent
                                text: badge.shown
                                font.family: Theme.fontUi; font.pixelSize: 10; font.weight: Font.Bold
                                color: Theme.accentInk
                            }
                            Connections {
                                target: task
                                function onCountChanged() { if (task.count > 1) badge.shown = task.count }
                            }
                            Component.onCompleted: if (task.count > 1) shown = task.count
                        }
                        Rectangle {
                            anchors { bottom: parent.bottom; bottomMargin: 1; horizontalCenter: parent.horizontalCenter }
                            height: 3; radius: 1.5
                            width: task.modelData.focused ? 18 : task.modelData.running ? 6 : 0
                            color: task.modelData.focused ? Theme.accent : Theme.textMuted
                            Behavior on width { NumberAnimation { duration: Motion.dur(Motion.tile); easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.spring } }
                            Behavior on color { ColorAnimation { duration: Motion.dur(300) } }
                        }
                    }

                    // Tooltip above the bar (fades + rises like the mockup .tip)
                    Rectangle {
                        id: tip
                        readonly property bool shown: task.dist === 0 && !task.menuOpen
                        anchors.horizontalCenter: parent.horizontalCenter
                        y: -32 + (shown ? 0 : 6)
                        width: Math.min(300, tipText.implicitWidth + 18); height: 25; radius: 8
                        color: Theme.tooltipBg
                        border.width: 1; border.color: Theme.white(0.10)
                        opacity: shown ? 1 : 0
                        visible: opacity > 0.01
                        Behavior on opacity { NumberAnimation { duration: Motion.dur(200) } }
                        Behavior on y { NumberAnimation { duration: Motion.dur(350); easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.soft } }
                        Text {
                            id: tipText
                            anchors.centerIn: parent
                            width: tip.width - 18
                            horizontalAlignment: Text.AlignHCenter
                            elide: Text.ElideRight
                            text: task.label
                            font.family: Theme.fontUi; font.pointSize: Theme.pt(11.5)
                            color: Theme.text
                        }
                    }

                    MouseArea {
                        id: tMouse
                        anchors.fill: parent
                        hoverEnabled: true
                        acceptedButtons: Qt.LeftButton | Qt.RightButton | Qt.MiddleButton
                        cursorShape: Qt.PointingHandCursor
                        onContainsMouseChanged: {
                            if (containsMouse) root.hoveredTask = task.index
                            else if (root.hoveredTask === task.index) root.hoveredTask = -1
                        }
                        onClicked: (e) => {
                            const c = task.mapToItem(root, task.width / 2, 0)
                            if (e.button === Qt.RightButton) root.taskRightClicked(task.index, c.x, c.y)
                            else if (e.button === Qt.MiddleButton || (e.modifiers & Qt.ShiftModifier)) root.taskMiddleClicked(task.index)
                            else root.taskClicked(task.index, c.x)
                        }
                    }
                    Accessible.role: Accessible.Button
                    Accessible.name: label + (modelData.running ? (modelData.minimized ? ", minimized" : ", open") : "")
                }
            }
        }

        // ---------------- right: services, assistant (only when turned on), quick settings, clock, show desktop ----------------
        Row {
            anchors { right: parent.right; rightMargin: 8; verticalCenter: parent.verticalCenter }
            spacing: 4

            // Services (template tray): the cycle glyph and how many run; a pulsing red dot when one failed.
            Pressable {
                id: svcBtn
                visible: root.servicesShown
                width: svcRow.width + 22; height: 40; radius: 11; kind: "hov"
                anchors.verticalCenter: parent.verticalCenter
                color: root.servicesOpen ? Theme.white(0.08) : "transparent"
                accessibleName: root.servicesLabel
                onClicked: root.servicesClicked(svcBtn.mapToItem(root, svcBtn.width / 2, 0).x)
                onRightClicked: (mx, my) => root.servicesRightClicked(svcBtn.mapToItem(root, svcBtn.width / 2, 0).x)
                Row {
                    id: svcRow
                    anchors.centerIn: parent
                    spacing: 7
                    QIcon { anchors.verticalCenter: parent.verticalCenter; path: Icons.cycle; size: 16; strokeWidth: 1.9; color: "#8CF5B0" }
                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        text: root.servicesRunning
                        font.family: Theme.fontUi; font.pixelSize: 12; font.weight: Font.Medium; font.features: { "tnum": 1 }
                        color: Theme.text2
                    }
                }
                Rectangle {
                    visible: root.servicesFailed > 0
                    x: parent.width - 15; y: 5                  // template: a 7px dot at top 7 / right 6 …
                    width: 11; height: 11; radius: 5.5          // … plus its 2px ring (box-shadow) outside it
                    color: "#FF8F8F"
                    border.width: 2; border.color: "#0B0D15"
                    SequentialAnimation on opacity {
                        running: root.servicesFailed > 0 && !Theme.reduceMotion
                        loops: Animation.Infinite
                        NumberAnimation { to: 0.55; duration: 900; easing.type: Easing.InOutSine }
                        NumberAnimation { to: 1; duration: 900; easing.type: Easing.InOutSine }
                    }
                }
            }

            Pressable {
                visible: root.assistantAvailable
                width: askRow.width + 22; height: 38; radius: 12; kind: "chip"
                anchors.verticalCenter: parent.verticalCenter
                color: root.assistantOpen ? Theme.alpha(Theme.accent, 0.16) : Theme.white(0.05)
                borderColor: root.assistantOpen ? Theme.accentLine : Theme.white(0.08)
                accessibleName: "Quasar Assistant"
                onClicked: root.assistantClicked()
                Row {
                    id: askRow
                    anchors.centerIn: parent
                    spacing: 7
                    OrbitMark { size: 18; strokeWidth: 1.8; anchors.verticalCenter: parent.verticalCenter }
                    Text { text: "Ask"; font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5); font.weight: Font.Medium; color: Theme.text; anchors.verticalCenter: parent.verticalCenter }
                }
            }

            // Command Deck: shown only while a phone is connected, so nobody is controlled unseen.
            Pressable {
                id: deckBtn
                visible: root.deckOn
                width: 40; height: 40; radius: 11; kind: "hov"
                anchors.verticalCenter: parent.verticalCenter
                color: root.deckOpen ? Theme.white(0.08) : "transparent"
                accessibleName: root.deckLive ? "A phone sees your screen" : "A phone is connected"
                onClicked: root.deckClicked(deckBtn.mapToItem(root, deckBtn.width / 2, 0).x)
                QIcon {
                    anchors.centerIn: parent
                    path: Icons.phone
                    size: 17; strokeWidth: 2
                    color: root.deckLive ? Theme.accent : Theme.text2
                }
                Rectangle {            // live: the screen is being shared
                    visible: root.deckLive
                    x: parent.width / 2 + 3; y: 9
                    width: 8; height: 8; radius: 4
                    color: Theme.danger
                    border.width: 2; border.color: Theme.windowOpaque
                    SequentialAnimation on opacity {
                        running: root.deckLive && !Theme.reduceMotion
                        loops: Animation.Infinite
                        NumberAnimation { to: 0.35; duration: 900; easing.type: Easing.InOutSine }
                        NumberAnimation { to: 1; duration: 900; easing.type: Easing.InOutSine }
                    }
                }
            }

            // Remote desktop: shown only while another computer sees and uses this screen (always live).
            Pressable {
                id: vncBtn
                visible: root.vncViewers > 0
                width: 40; height: 40; radius: 11; kind: "hov"
                anchors.verticalCenter: parent.verticalCenter
                color: root.vncOpen ? Theme.white(0.08) : "transparent"
                accessibleName: root.vncViewers === 1 ? "Another computer is using your screen"
                                                      : root.vncViewers + " computers are using your screen"
                onClicked: root.vncClicked(vncBtn.mapToItem(root, vncBtn.width / 2, 0).x)
                QIcon {
                    anchors.centerIn: parent
                    path: Icons.monitor
                    size: 17; strokeWidth: 2
                    color: Theme.accent
                }
                Rectangle {
                    x: parent.width / 2 + 4; y: 9
                    width: 8; height: 8; radius: 4
                    color: Theme.danger
                    border.width: 2; border.color: Theme.windowOpaque
                    SequentialAnimation on opacity {
                        running: vncBtn.visible && !Theme.reduceMotion
                        loops: Animation.Infinite
                        NumberAnimation { to: 0.35; duration: 900; easing.type: Easing.InOutSine }
                        NumberAnimation { to: 1; duration: 900; easing.type: Easing.InOutSine }
                    }
                }
            }

            Pressable {
                width: qsRow.width + 20; height: 40; radius: 11; kind: "hov"
                anchors.verticalCenter: parent.verticalCenter
                color: root.quickOpen ? Theme.white(0.08) : "transparent"
                accessibleName: "Quick settings" + (root.vpnOn ? ", VPN on" : "") + (root.hotspotOn ? ", Mobile hotspot on" : "")
                onClicked: root.quickClicked()
                Row {
                    id: qsRow
                    anchors.centerIn: parent
                    spacing: 10
                    // A Mobile hotspot is on: this PC is sharing its internet.
                    QIcon {
                        visible: root.hotspotOn
                        path: Icons.hotspot
                        size: 16; strokeWidth: 2; color: Theme.accent
                    }
                    // Wi-Fi when it's connected (or nothing is), Ethernet when only a cable is; a small
                    // lock on it while a VPN carries the traffic.
                    Item {
                        width: 16; height: 16
                        QIcon {
                            path: root.wiredConnected && !root.wifiConnected ? Icons.ethernet : Icons.wifi
                            size: 16; strokeWidth: 2; color: Theme.text2
                            opacity: root.wifiConnected || root.wiredConnected ? 1 : 0.35
                        }
                        Rectangle {        // ringed like the task buttons' badges, so it doesn't run into the arcs
                            visible: root.vpnOn
                            x: 7; y: 7
                            width: 13; height: 13; radius: 4.5
                            color: Theme.accent
                            border.width: 2; border.color: Theme.windowOpaque
                            QIcon { anchors.centerIn: parent; path: Icons.lock; size: 7; strokeWidth: 2.6; color: Theme.accentInk }
                        }
                    }
                    QIcon { path: Icons.vol; size: 16; strokeWidth: 2; color: Theme.text2 }
                    QIcon { path: Icons.sliders; size: 16; strokeWidth: 2; color: Theme.text2 }
                }
            }

            Pressable {
                width: clockCol.width + 20; height: 44; radius: 11; kind: "hov"
                anchors.verticalCenter: parent.verticalCenter
                color: root.calendarOpen ? Theme.white(0.08) : "transparent"
                accessibleName: "Calendar and notifications"
                onClicked: root.calendarClicked()
                Column {
                    id: clockCol
                    anchors.centerIn: parent
                    spacing: 1
                    Text { anchors.right: parent.right; text: root.timeText; font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5); font.weight: Font.Medium; font.features: { "tnum": 1 }; color: Theme.text }
                    Text { anchors.right: parent.right; text: root.dateText; font.family: Theme.fontUi; font.pixelSize: 11; font.features: { "tnum": 1 }; color: Theme.textMuted }
                }
            }

            Item {
                width: 12; height: 40
                anchors.verticalCenter: parent.verticalCenter
                Accessible.role: Accessible.Button
                Accessible.name: "Show desktop"
                Rectangle { x: 2; width: 1; height: parent.height; color: Theme.white(0.12) }
                MouseArea { anchors.fill: parent; onClicked: root.showDesktopClicked() }
            }
        }
    }
}
