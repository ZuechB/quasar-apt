import QtQuick
import Quasar

// The sign-in screen (greeter/shell.qml shows it on every screen; the card only on the main one): the
// deep-field wallpaper, the time and date, the chosen person's card, the other people underneath,
// and Restart / Shut down. Pure: the host talks to greetd and sets busy / message / prompt.
Item {
    id: root
    property var people: []                  // Accounts.people(...)
    property string selected: ""             // username
    property bool main: true                 // false: another screen (wallpaper and clock only)
    property bool busy: false
    property string message: ""
    property bool messageIsError: false
    property string prompt: "Password"
    property bool echo: false
    property bool allowEmpty: false          // an account without a password (the live session)
    property bool leaving: false             // signed in: fade out before the desktop starts
    property var now: new Date()
    property bool ticking: true              // previews pin the clock
    signal submitted(string password)
    signal picked(string name)
    signal restartClicked()
    signal shutdownClicked()

    function focusInput() { card.focusInput() }
    function clear() { card.clear() }
    function setText(t) { card.setText(t) }         // previews

    readonly property var person: people.find(p => p.name === selected) || people[0] || null

    Timer { running: root.ticking; repeat: true; interval: 5000; onTriggered: root.now = new Date() }

    Wallpaper {
        anchors.fill: parent
        kind: "deep"
        animated: false
    }
    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0.0; color: Qt.rgba(0, 0, 0, 0.12) }
            GradientStop { position: 1.0; color: Qt.rgba(0, 0, 0, 0.5) }
        }
    }

    Item {
        id: content
        anchors.fill: parent
        opacity: root.leaving ? 0 : 1
        Behavior on opacity { NumberAnimation { duration: Motion.dur(280); easing.type: Easing.OutCubic } }

        Column {
            id: clock
            anchors.horizontalCenter: parent.horizontalCenter
            y: Math.round(parent.height * (root.main ? 0.12 : 0.36))
            spacing: 4
            Text {
                anchors.horizontalCenter: parent.horizontalCenter
                text: Qt.formatTime(root.now, "h:mm")
                font.family: Theme.fontDisplay; font.pixelSize: root.main ? 76 : 96; font.weight: Font.Light
                color: Theme.text
            }
            Text {
                anchors.horizontalCenter: parent.horizontalCenter
                text: Qt.formatDate(root.now, "dddd, MMMM d")
                font.family: Theme.fontUi; font.pointSize: Theme.pt(16)
                color: Theme.text3
            }
        }

        SignInCard {
            id: card
            visible: root.main && root.person !== null
            width: 340
            anchors.horizontalCenter: parent.horizontalCenter
            y: Math.round(Math.max(clock.y + clock.height + 40, parent.height * 0.5 - 150))
            name: root.person ? root.person.display : ""
            seed: root.person ? root.person.name : ""
            placeholder: root.prompt
            echo: root.echo
            busy: root.busy
            message: root.message
            messageIsError: root.messageIsError
            onSubmitted: (pw) => root.submitted(pw)
            allowEmpty: root.allowEmpty
            onEscapePressed: card.clear()
        }

        Text {
            visible: root.main && root.people.length === 0
            anchors.centerIn: parent
            width: Math.min(420, parent.width - 40)
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.Wrap
            text: "There's no account on this PC to sign in to."
            font.family: Theme.fontUi; font.pointSize: Theme.pt(14)
            color: Theme.text3
        }

        // Everyone else on this PC: pick to switch the card to them.
        Row {
            visible: root.main && root.people.length > 1
            anchors.horizontalCenter: parent.horizontalCenter
            y: card.y + card.height + 34
            spacing: 10
            Repeater {
                model: root.people
                delegate: Pressable {
                    id: chip
                    required property var modelData
                    readonly property bool current: modelData.name === (root.person ? root.person.name : "")
                    kind: "hov"
                    radius: 14
                    implicitWidth: 112
                    implicitHeight: 92
                    color: current ? Theme.white(0.08) : "transparent"
                    borderColor: current ? Theme.white(0.14) : "transparent"
                    accessibleName: modelData.display
                    enabled: !root.busy
                    onClicked: root.picked(modelData.name)
                    Column {
                        anchors.centerIn: parent
                        spacing: 8
                        UserAvatar {
                            anchors.horizontalCenter: parent.horizontalCenter
                            size: 44
                            name: chip.modelData.display
                            seed: chip.modelData.name
                            opacity: chip.current ? 1 : 0.8
                        }
                        Text {
                            anchors.horizontalCenter: parent.horizontalCenter
                            width: 102
                            horizontalAlignment: Text.AlignHCenter
                            elide: Text.ElideRight
                            text: chip.modelData.display
                            textFormat: Text.PlainText
                            font.family: Theme.fontUi; font.pointSize: Theme.pt(12)
                            color: chip.current ? Theme.text : Theme.text3
                        }
                    }
                }
            }
        }

        Row {
            visible: root.main
            anchors { right: parent.right; bottom: parent.bottom; margins: 24 }
            spacing: 8
            Button {
                variant: "ghost"; size: 38; glyph: Icons.refresh; text: "Restart"
                enabled: !root.busy
                onClicked: root.restartClicked()
            }
            Button {
                variant: "ghost"; size: 38; glyph: Icons.power; text: "Shut down"
                enabled: !root.busy
                onClicked: root.shutdownClicked()
            }
        }
        Row {
            visible: root.main
            anchors { left: parent.left; bottom: parent.bottom; margins: 26 }
            spacing: 10
            QuasarMark { anchors.verticalCenter: parent.verticalCenter; size: 22 }
            Text {
                anchors.verticalCenter: parent.verticalCenter
                text: "Quasar"
                font.family: Theme.fontDisplay; font.pixelSize: 15; font.weight: Font.Medium
                color: Theme.text3
            }
        }
    }
    Rectangle {      // signing in: the screen goes to the desktop's own starting colour
        anchors.fill: parent
        color: Theme.bg
        opacity: root.leaving ? 1 : 0
        Behavior on opacity { NumberAnimation { duration: Motion.dur(320); easing.type: Easing.InCubic } }
    }
}
