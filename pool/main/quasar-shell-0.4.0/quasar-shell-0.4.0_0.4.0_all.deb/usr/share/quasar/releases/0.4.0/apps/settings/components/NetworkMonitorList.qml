import QtQuick
import Quasar

// Settings › Network & Internet › "Network monitor: Apps that used the internet today" (template). One
// row per app: its icon, name, a bar against the busiest, today's total, and Block/Allow for your own
// apps (system services, companies and containers are listed, not blockable here). Counted on this PC
// only (quasar-netguard), and only today's counts are kept.
// Pure view: `model` is an array (preview) or a keyed ScriptModel (services/NetMonitor.qml) of
//   { key, name, icon, glyph, total, blocked, blockable, system }
Column {
    id: root
    property var model: []
    property int rowCount: 0
    property real maxTotal: 1       // the busiest row's total (the bars' scale)
    property string phase: "ok"     // "loading" | "ok" | "unavailable"
    property string busyKey: ""
    signal blockClicked(string key)
    signal allowClicked(string key)

    function size(b) {
        return b >= 1e9 ? (b / 1e9).toFixed(1) + " GB" : b >= 1e6 ? Math.round(b / 1e6) + " MB"
             : b >= 1e3 ? Math.round(b / 1e3) + " KB" : b + " B"
    }

    spacing: 0

    Row {
        spacing: 10
        leftPadding: 4
        bottomPadding: 8
        SectionLabel { id: heading; text: "Network monitor" }
        Text {
            anchors.baseline: heading.baseline
            text: "Apps that used the internet today"
            font.family: Theme.fontUi; font.pointSize: Theme.pt(12)
            color: Theme.textDim
        }
    }

    Rectangle {
        width: parent.width
        height: list.implicitHeight
        radius: 16
        color: Theme.white(0.035)
        border.width: 1
        border.color: Theme.white(0.06)
        clip: true

        Column {
            id: list
            width: parent.width

            Text {
                visible: root.phase !== "ok" || root.rowCount === 0
                width: parent.width
                padding: 16
                wrapMode: Text.Wrap
                text: root.phase === "unavailable" ? "The network monitor isn't running, so there's nothing to show. Restarting the PC usually brings it back."
                    : root.phase === "loading" ? "Counting…"
                    : "No app has used the internet today."
                font.family: Theme.fontUi; font.pointSize: Theme.pt(13)
                color: Theme.textDim
            }

            Repeater {
                model: root.phase === "ok" ? root.model : []
                delegate: Item {
                    id: row
                    required property var modelData
                    required property int index
                    width: list.width
                    height: 52
                    Rectangle { visible: row.index > 0; width: parent.width; height: 1; color: Theme.white(0.05) }

                    Item {
                        id: iconBox
                        x: 16; width: 18; height: 18
                        anchors.verticalCenter: parent.verticalCenter
                        Image {
                            id: appIcon
                            anchors.fill: parent
                            visible: row.modelData.icon !== "" && status === Image.Ready
                            source: row.modelData.icon || ""
                            sourceSize: Qt.size(36, 36)
                            opacity: row.modelData.blocked ? 0.5 : 1
                        }
                        QIcon {
                            anchors.centerIn: parent
                            visible: !appIcon.visible
                            path: row.modelData.glyph || Icons.grid; size: 18; strokeWidth: 1.9
                            color: row.modelData.blocked ? Theme.textMuted : Theme.text3
                        }
                    }
                    Text {
                        id: nameText
                        anchors { left: iconBox.right; leftMargin: 14; verticalCenter: parent.verticalCenter }
                        width: Math.min(190, parent.width * 0.3)
                        elide: Text.ElideRight
                        text: row.modelData.name
                        font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
                        font.strikeout: !!row.modelData.blocked
                        color: row.modelData.blocked ? Theme.textMuted : Theme.text
                    }
                    // the bar: this app against the busiest one today
                    Rectangle {
                        anchors { left: nameText.right; leftMargin: 12; right: amount.left; rightMargin: 12; verticalCenter: parent.verticalCenter }
                        height: 6; radius: 3
                        color: Theme.white(0.06)
                        Rectangle {
                            height: parent.height; radius: 3
                            width: Math.max(4, parent.width * Math.min(1, row.modelData.total / Math.max(1, root.maxTotal)))
                            color: row.modelData.blocked ? Theme.white(0.15) : row.modelData.system ? Theme.text3 : Theme.accent
                            Behavior on width { enabled: !Theme.reduceMotion; NumberAnimation { duration: 260; easing.type: Easing.OutCubic } }
                        }
                    }
                    Text {
                        id: amount
                        anchors { right: chip.left; rightMargin: 12; verticalCenter: parent.verticalCenter }
                        width: 64
                        horizontalAlignment: Text.AlignRight
                        text: root.size(row.modelData.total)
                        font.family: Theme.fontMono; font.pixelSize: 12
                        color: Theme.textDim
                    }
                    Item {
                        id: chip
                        anchors { right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter }
                        width: 72; height: 30
                        Button {
                            anchors.fill: parent
                            visible: !!row.modelData.blockable
                            text: row.modelData.blocked ? "Allow" : "Block"
                            variant: row.modelData.blocked ? "soft" : "outline"
                            size: 30
                            busy: root.busyKey === row.modelData.key
                            enabled: root.busyKey === ""
                            accessibleName: (row.modelData.blocked ? "Allow " : "Block ") + row.modelData.name
                            onClicked: row.modelData.blocked ? root.allowClicked(row.modelData.key) : root.blockClicked(row.modelData.key)
                        }
                        Text {
                            anchors.centerIn: parent
                            visible: !row.modelData.blockable
                            text: "System"
                            font.family: Theme.fontUi; font.pointSize: Theme.pt(11)
                            color: Theme.textMuted
                        }
                    }
                }
            }
        }
    }

    Text {
        width: parent.width
        topPadding: 8; leftPadding: 4
        wrapMode: Text.Wrap
        text: "Counted on this PC only, and only today's use is kept. Blocking an app cuts it off from every network until you allow it again."
        font.family: Theme.fontUi; font.pointSize: Theme.pt(11.5)
        color: Theme.textMuted
    }
}
