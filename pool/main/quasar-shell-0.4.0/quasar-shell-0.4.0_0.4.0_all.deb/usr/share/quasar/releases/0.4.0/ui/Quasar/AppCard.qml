import QtQuick

// Store app card (template sGridA cards): radius 16, white .035 fill, white .06 hairline, padding
// 12, gap 12; 50px icon tile (radius 15, hue glow), 14px/600 name, 2-line 12px blurb, 11px source;
// trailing Get pill (soft, accent text) -> progress ring (28px) -> Open pill (light).
// While queued or installing, the ring holds a stop square when the job can still be cancelled
// ("Queued" sits beside it); cancelling turns the ring into a spinner.
// Clicking the card body opens the detail page.
// Built for long lists (the Store shows all of Flathub): one action button, and the ring, spinner and
// glyph (Shapes) exist only while they're shown. Texts are plain: catalog strings are never markup.
Pressable {
    id: root
    property string name: ""
    property string blurb: ""
    property string source: ""
    property string glyph: ""
    property url icon: ""
    property string letter: ""             // monogram when there's neither an icon nor a glyph
    property color hue: Theme.accent
    property bool highlight: false         // the source line in the accent colour (Quasar's picks)
    property string state_: "get"          // get | queued | busy | open | failed
    property real progress: 0              // 0..1 while busy
    property bool cancellable: false       // queued or busy: the stop button works
    property bool cancelling: false
    property string openText: "Open"       // "Terminal" for command-line tools
    signal getClicked()
    signal openClicked()
    signal cancelClicked()

    readonly property bool _working: state_ === "busy" || state_ === "queued"

    kind: "card"
    interactiveContent: true          // Get / Open / stop take their own clicks; the rest opens the detail
    radius: 16
    color: Theme.white(0.035)
    borderColor: Theme.white(0.06)
    implicitHeight: 74
    implicitWidth: 280
    accessibleName: name

    AppTile {
        id: tile
        x: 12
        anchors.verticalCenter: parent.verticalCenter
        size: 50; radius: 15
        hue: root.hue
        glyph: root.icon.toString() === "" ? root.glyph : ""
        image: root.icon
        letter: root.letter
        glyphSize: 25
        exactDecode: true
    }
    Column {
        anchors { left: tile.right; leftMargin: 12; right: trail.left; rightMargin: 12; verticalCenter: parent.verticalCenter }
        spacing: 3
        Text {
            width: parent.width
            text: root.name
            textFormat: Text.PlainText
            elide: Text.ElideRight
            font.family: Theme.fontUi; font.pixelSize: 14; font.weight: Font.DemiBold
            color: Theme.text
        }
        Text {
            width: parent.width
            text: root.blurb
            textFormat: Text.PlainText
            wrapMode: Text.Wrap
            maximumLineCount: 2
            elide: Text.ElideRight
            lineHeight: 1.12
            font.family: Theme.fontUi; font.pixelSize: 12
            color: Theme.textMuted
        }
        Text {
            width: parent.width
            text: root.source
            textFormat: Text.PlainText
            elide: Text.ElideRight
            font.family: Theme.fontUi; font.pixelSize: 11
            color: root.highlight ? Theme.accent : Theme.textFaint
        }
    }

    Item {
        id: trail
        anchors { right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter }
        width: root._working ? (progress.item ? progress.item.implicitWidth : 30) : action.implicitWidth
        height: 30

        // Get / Retry / Open: one button that changes with the state.
        Button {
            id: action
            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
            visible: !root._working
            readonly property bool isOpen: root.state_ === "open"
            text: isOpen ? root.openText : root.state_ === "failed" ? "Retry" : "Get"
            variant: isOpen ? "light" : "soft"; size: 30; pill: true
            color: isOpen ? Theme.text : Theme.white(0.1)
            fg: isOpen ? Theme.accentInk : root.state_ === "failed" ? Theme.danger : root.hue
            accessibleName: (isOpen ? root.openText : "Get") + " " + root.name
            onClicked: isOpen ? root.openClicked() : root.getClicked()
        }
        Loader {
            id: progress
            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
            active: root._working
            visible: active
            sourceComponent: Row {
                spacing: 6
                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    visible: root.state_ === "queued"
                    text: "Queued"
                    font.family: Theme.fontUi; font.pixelSize: 12
                    color: Theme.textDim
                }
                // Disabled (a job that runs to the end) = clicks fall through to the card.
                Pressable {
                    id: stopBtn
                    anchors.verticalCenter: parent.verticalCenter
                    width: 30; height: 30; radius: 15
                    kind: "hov"
                    enabled: root.cancellable && !root.cancelling
                    accessibleName: (root.state_ === "queued" ? "Take " + root.name + " out of the queue" : "Stop installing " + root.name)
                    onClicked: root.cancelClicked()
                    ProgressRing {
                        anchors.centerIn: parent
                        visible: !root.cancelling
                        size: 28; value: root.state_ === "busy" ? root.progress : 0
                        color: root.state_ === "busy" ? root.hue : "transparent"     // queued: the empty track
                    }
                    Loader {
                        anchors.centerIn: parent
                        active: root.cancelling
                        sourceComponent: Spinner { size: 18; color: Theme.text3 }
                    }
                    Rectangle {
                        anchors.centerIn: parent
                        visible: stopBtn.enabled
                        width: 8; height: 8; radius: 2
                        color: stopBtn.hovered ? Theme.text : root.hue
                        Behavior on color { ColorAnimation { duration: Motion.dur(Motion.hover) } }
                    }
                }
            }
        }
    }
}
