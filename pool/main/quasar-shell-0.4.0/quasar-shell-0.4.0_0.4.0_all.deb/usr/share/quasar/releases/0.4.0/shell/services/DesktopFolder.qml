import QtQuick
import Qt.labs.folderlistmodel
import Quickshell
import Quickshell.Io
import Quasar
import Quasar.Services
import "../components/desktopLayout.js" as Layout

// The desktop's contents: Home / Trash (/ Install) plus everything in ~/Desktop, watched live by Qt's
// FolderListModel. Website and app shortcuts are .desktop files (Type=Link / Type=Application; .url
// files work too). App shortcuts only ever launch an installed app (X-Quasar-App or the file name as
// a desktop id): a desktop file's own Exec= is never run, so a downloaded launcher can't run code.
// File work goes through /usr/libexec/quasar/fileop, one short-lived process per operation.
// Icon spots (key -> [x, y]) live in ~/.local/state/quasar/desktop-icons.json, written only by the
// shell: settings.json is rewritten by every Quasar process, so spots kept there could be reverted
// by another app's stale copy. The arrangement mode itself is a setting (Settings.desktopArrange).
Scope {
    id: root
    required property var apps
    property bool live: false
    property size area: Qt.size(1280, 664)                 // desktop above the taskbar
    property bool areaKnown: true                          // false while there's no display to measure
    readonly property string arrange: ["grid", "free", "auto"].indexOf(Settings.desktopArrange) >= 0 ? Settings.desktopArrange : "grid"

    readonly property string home: Quickshell.env("HOME") || "/root"
    readonly property string dir: home + "/Desktop"
    readonly property string trashDir: (Quickshell.env("XDG_DATA_HOME") || home + "/.local/share") + "/Trash"
    readonly property string stateDir: (Quickshell.env("XDG_STATE_HOME") || home + "/.local/state") + "/quasar"
    readonly property string helper: "/usr/libexec/quasar/fileop"

    signal message(var toast)                  // { title, sub, glyph, hue }
    signal openFolderRequested(string path)
    signal programRequested(string path, string how)   // the shell asks, then runs it (services/Programs.qml)
    signal created(string key)                 // a New folder / New text document the user should name

    // ------------------------------------------------------------------------------------ folder
    property bool ready: false
    Process {
        running: true
        command: ["mkdir", "-p", root.dir, root.trashDir + "/files", root.trashDir + "/info", root.stateDir]
        onExited: root.ready = true
    }
    // Saved icon spots.
    property var spots: ({})
    property bool spotsLoaded: false
    FileView {
        id: spotsFile
        path: root.stateDir + "/desktop-icons.json"
        blockLoading: true
        printErrors: false
        onLoaded: { try { root.spots = JSON.parse(text()) || {} } catch (e) { root.spots = {} } root.spotsLoaded = true }
        onLoadFailed: (error) => root.spotsLoaded = true          // first run
    }
    function setSpots(next) { spots = next; spotsWrite.restart() }
    Timer { id: spotsWrite; interval: 300; onTriggered: spotsFile.setText(JSON.stringify(root.spots)) }
    FolderListModel {
        id: folder
        folder: root.ready ? "file://" + root.dir : ""
        showHidden: false
        showDotAndDotDot: false
        showDirsFirst: true
        sortField: FolderListModel.Name
        sortCaseSensitive: false
        onCountChanged: Qt.callLater(root.rebuild)
        onStatusChanged: Qt.callLater(root.rebuild)
    }
    Connections {
        target: folder
        function onDataChanged() { Qt.callLater(root.rebuild) }
        function onModelReset() { Qt.callLater(root.rebuild) }
        function onRowsMoved() { Qt.callLater(root.rebuild) }
    }
    FolderListModel {
        id: trashModel
        folder: root.ready ? "file://" + root.trashDir + "/files" : ""
        showHidden: true
        showDotAndDotDot: false
    }
    readonly property bool trashFull: trashModel.count > 0
    readonly property int trashCount: trashModel.count
    readonly property bool loaded: ready && folder.status === FolderListModel.Ready
    // Saved spots of vanished files are only pruned once the first listing has surely arrived.
    property bool settled: false
    Timer { running: root.loaded; interval: 1500; onTriggered: root.settled = true }

    property var files: []                     // [{ name, path, url, isDir, suffix }]
    function rebuild() {
        const out = []
        for (let i = 0; i < folder.count; i++) {
            const name = folder.get(i, "fileName")
            out.push({ name: name, path: folder.get(i, "filePath"), url: String(folder.get(i, "fileUrl")),
                       isDir: folder.get(i, "fileIsDir"), suffix: String(folder.get(i, "fileSuffix") || "").toLowerCase() })
        }
        files = out
    }

    // .desktop / .url files are read here (and re-read when they change).
    readonly property var entryPaths: files.filter(f => !f.isDir && (f.suffix === "desktop" || f.suffix === "url")).map(f => f.path)
    property var meta: ({})
    Instantiator {
        // Keyed by path, so a change in the folder doesn't recreate (and re-read) every entry.
        model: ScriptModel { values: root.entryPaths }
        delegate: FileView {
            required property string modelData
            path: modelData
            watchChanges: true
            printErrors: false
            onFileChanged: reload()
            onLoaded: root.parseEntry(modelData, text())
        }
    }
    function parseEntry(path, text) {
        const want = ["Desktop Entry", "InternetShortcut"]
        let group = "", m = {}
        for (const raw of text.split(/\r?\n/)) {
            const line = raw.trim()
            if (line.startsWith("[")) { if (m.group) break; group = line.slice(1, -1); if (want.indexOf(group) >= 0) m.group = group; continue }
            if (!m.group || group !== m.group) continue
            const eq = line.indexOf("=")
            if (eq <= 0) continue
            const k = line.slice(0, eq).trim(), v = line.slice(eq + 1).trim()
            if (["Type", "Name", "URL", "Icon", "X-Quasar-App"].indexOf(k) >= 0 && m[k] === undefined) m[k] = v
        }
        const next = Object.assign({}, meta)
        next[path] = m
        meta = next
    }

    // ------------------------------------------------------------------------------------ items
    readonly property var textExt: ["txt", "md", "log", "json", "xml", "csv", "ini", "conf", "cfg", "yaml", "yml", "toml",
                                    "sh", "bash", "zsh", "py", "js", "ts", "cs", "java", "cpp", "c", "h", "html", "htm", "css", "scss", "rs", "go", "qml"]
    readonly property var codeExt: ["sh", "bash", "zsh", "py", "js", "ts", "cs", "java", "cpp", "c", "h", "html", "htm", "css", "scss", "rs", "go", "qml"]
    readonly property var imageExt: ["png", "jpg", "jpeg", "gif", "bmp", "webp", "ico", "svg", "tiff", "tif"]
    readonly property var videoExt: ["mp4", "mkv", "webm", "mov", "avi", "m4v"]
    readonly property var audioExt: ["mp3", "flac", "ogg", "opus", "wav", "m4a", "aac"]
    readonly property var archiveExt: ["zip", "tar", "gz", "tgz", "xz", "bz2", "zst", "7z", "rar", "deb", "rpm", "flatpakref"]
    // Archives fileop extracts (opening one extracts it next to itself); packages are left alone.
    readonly property var extractExt: ["zip", "7z", "rar", "tar", "gz", "tgz", "xz", "txz", "bz2", "tbz2", "zst", "tzst"]
    readonly property var sheetExt: ["csv", "ods", "xls", "xlsx"]

    function stem(name) { const i = name.lastIndexOf("."); return i > 0 ? name.slice(0, i) : name }
    function hostOf(url) { const m = /^[a-z][a-z0-9+.-]*:\/\/([^/?#:]+)/i.exec(url || ""); return m ? m[1].replace(/^www\./, "") : "" }

    function fileItem(f) {
        const it = { key: f.name, name: f.name, path: f.path, url: f.url, target: false, glyph: Icons.notes, hue: Theme.text3,
                     icon: "", letter: "", thumb: "", kind: "file" }
        const s = f.suffix
        if (f.isDir) return Object.assign(it, { kind: "dir", glyph: Icons.folder, hue: "#7AB8FF", target: true })
        if (s === "desktop" || s === "url") {
            const m = meta[f.path]
            const named = m && m.Name ? m.Name : stem(f.name)
            if (m && (m.group === "InternetShortcut" || m.Type === "Link") && m.URL)
                return Object.assign(it, { kind: "link", name: named, link: m.URL, glyph: Icons.globe, hue: apps.hueFor(hostOf(m.URL) || m.URL) })
            if (m && m.Type === "Application") {
                // Depend on the (async) entry list so shortcuts resolve once it has loaded.
                const e = apps.entries.length ? (apps.byId(m["X-Quasar-App"] || "") || apps.byId(stem(f.name))) : null
                if (e) {
                    const d = apps.decorate(e)
                    return Object.assign(it, { kind: "app", name: m.Name || d.name, glyph: d.glyph, hue: d.hue, icon: d.icon, letter: d.letter, entry: e })
                }
                return Object.assign(it, { kind: "app-missing", name: named, glyph: "", letter: apps.initial(named), hue: Theme.text3 })
            }
            return Object.assign(it, { name: named, glyph: Icons.link, hue: Theme.text3 })
        }
        // Programs and packages by name (FileKit.openAs), before the text kinds: .sh and .py are also code.
        const how = FileKit.openAs(f.name)
        if (how === "program")
            return Object.assign(it, { kind: "program", script: s === "sh" || s === "py",
                                       glyph: s === "sh" || s === "py" ? Icons.code : Icons.cube,
                                       hue: s === "sh" || s === "py" ? "#B9A4FF" : "#7AE7FF" })
        if (how === "package") return Object.assign(it, { kind: "package", glyph: Icons.pkg, hue: "#B9A4FF" })
        if (imageExt.indexOf(s) >= 0) return Object.assign(it, { kind: "image", glyph: Icons.image, hue: "#FF9BD2", thumb: f.url })
        if (sheetExt.indexOf(s) >= 0) return Object.assign(it, { kind: textExt.indexOf(s) >= 0 ? "text" : "file", glyph: Icons.sheet, hue: "#8CF5B0" })
        if (codeExt.indexOf(s) >= 0) return Object.assign(it, { kind: "text", glyph: Icons.code, hue: "#B9A4FF" })
        if (textExt.indexOf(s) >= 0) return Object.assign(it, { kind: "text", glyph: Icons.notes, hue: "#FFD66B" })
        if (videoExt.indexOf(s) >= 0) return Object.assign(it, { glyph: Icons.video, hue: "#FFB86B" })
        if (audioExt.indexOf(s) >= 0) return Object.assign(it, { glyph: Icons.music, hue: "#FF8FB1" })
        if (archiveExt.indexOf(s) >= 0 || extractExt.indexOf(s) >= 0)
            return Object.assign(it, { kind: extractExt.indexOf(s) >= 0 ? "archive" : "file", glyph: Icons.pkg, hue: "#B9A4FF" })
        if (s === "pdf" || s === "odt" || s === "doc" || s === "docx" || s === "rtf") return Object.assign(it, { glyph: Icons.notes, hue: "#FFD66B" })
        return it
    }

    readonly property var fixedItems: [
        { key: "/home", name: "Home", kind: "home", path: home, url: "file://" + home, glyph: Icons.home, hue: "#7AB8FF", target: true },
        { key: "/trash", name: "Trash", kind: "trash", path: trashDir + "/files", url: "trash:///", glyph: Icons.trash, hue: "#C9CFDC", target: true }
    ].concat(live ? [{ key: "/install", name: "Install Quasar", kind: "install", glyph: Icons.download, hue: Theme.accent, target: false }] : [])

    // Display order: Home, Trash (, Install), folders, then files; natural, case-insensitive.
    readonly property var items: {
        const dirs = files.filter(f => f.isDir).map(fileItem)
        const rest = files.filter(f => !f.isDir).map(fileItem)
        const byName = (a, b) => FileKit.naturalCompare(a.name, b.name)
        return fixedItems.map(x => Object.assign({ icon: "", letter: "", thumb: "" }, x)).concat(dirs.sort(byName), rest.sort(byName))
    }
    function find(key) { return items.find(i => i.key === key) || null }

    // ------------------------------------------------------------------------------------ layout
    property var pending: ({})                 // name -> [x, y]: where an item that's being created goes
    readonly property var placed: Layout.layout(items, Object.assign({}, spots, pending), arrange, area)
    readonly property var pos: placed.pos
    readonly property var viewItems: items.map(i => Object.assign({}, i, pos[i.key] || { x: 0, y: 0 }))
    onPlacedChanged: saveSpots.restart()
    // Keep what the layout assigned (new items, snapped spots) so icons never jump later, and forget
    // the spots of files that are gone.
    Timer {
        id: saveSpots
        interval: 400
        onTriggered: {
            // No display yet (or none left): the area is a stand-in, and spots laid out in it aren't real.
            if (!root.loaded || !root.spotsLoaded || !root.areaKnown) return
            const keys = new Set(root.items.map(i => i.key))
            const next = {}
            let changed = false
            for (const k in root.spots) { if (!root.settled || keys.has(k) || root.pending[k]) next[k] = root.spots[k]; else changed = true }
            for (const k in root.placed.assigned) {
                const v = root.placed.assigned[k]
                if (!next[k] || next[k][0] !== v[0] || next[k][1] !== v[1]) { next[k] = v; changed = true }
            }
            const left = {}
            for (const k in root.pending) if (!keys.has(k)) left[k] = root.pending[k]
            if (Object.keys(left).length !== Object.keys(root.pending).length) root.pending = left
            if (changed) root.setSpots(next)
        }
    }
    // Spot for an item that is about to appear (new folder, drop): the layout snaps it in grid mode.
    function reserve(name, x, y) {
        if (x === undefined || x < 0) return
        const next = Object.assign({}, pending)
        next[name] = [x, y]
        pending = next
    }
    // Rearranged by a drag on the desktop: `anchor`'s top-left lands at (x, y), the rest keep their offsets.
    function moveIcons(keys, anchor, x, y) {
        if (arrange === "auto") return
        setSpots(Object.assign({}, spots, Layout.moveGroup(items, pos, keys, anchor, x, y, arrange, area, spots, placed.displaced)))
    }
    function tidy() { setSpots({}) }               // Settings › Desktop › Tidy up (via IPC)

    // ------------------------------------------------------------------------------------ operations
    Component { id: opComp; Cmd { } }
    property int busy: 0
    // Runs fileop; onLine gets each JSON line, onDone(code, lastError).
    // slow: show a busy toast if it takes a while ("Copying…", or the text given).
    function op(args, onLine, onDone, slow) {
        const c = opComp.createObject(root)
        if (slow) busyLabel = typeof slow === "string" ? slow : "Copying…"
        let err = ""
        c.line.connect((l) => {
            let o = null
            try { o = JSON.parse(l) } catch (e) { return }
            if (o.error) err = o.error
            if (onLine) onLine(o)
        })
        c.finished.connect((code) => {
            if (slow) busy--
            if (onDone) onDone(code, err)
            else if (code !== 0 && err) root.message({ title: err, sub: "", glyph: Icons.alert, hue: "#FFB86B" })
            c.destroy()
        })
        if (slow) { busy++; busyToast.restart() }
        c.run([helper].concat(args))
    }
    property string busyLabel: "Copying…"
    Timer {
        id: busyToast
        interval: 700
        onTriggered: if (root.busy > 0) root.message({ title: root.busyLabel, sub: "Your files will show up when it's done", glyph: Icons.folder, hue: "#7AB8FF" })
    }

    function newFolder(x, y) {
        op(["new-folder", dir], (o) => { if (o.name && !o.error) { reserve(o.name, x, y); root._made = o.name } },
           (code, err) => { if (code === 0) root.created(root._made); else if (err) root.message({ title: err, glyph: Icons.alert, hue: "#FFB86B" }) })
    }
    function newTextFile(x, y) {
        op(["new-file", dir, "New text document.txt"], (o) => { if (o.name && !o.error) { reserve(o.name, x, y); root._made = o.name } },
           (code, err) => { if (code === 0) root.created(root._made); else if (err) root.message({ title: err, glyph: Icons.alert, hue: "#FFB86B" }) })
    }
    property string _made: ""
    function newLink(name, url, x, y, dest) {
        op(["new-link", dest || dir, name || "", url], (o) => { if (o.name && !o.error && !dest) reserve(o.name, x, y) })
    }
    function addLauncher(appId, name) {
        op(["new-launcher", dir, appId], null, (code, err) => {
            if (code === 0) root.message({ title: "Added to the desktop", sub: name || "", glyph: Icons.grid, hue: Theme.accent })
            else root.message({ title: err || "Couldn't add it to the desktop", glyph: Icons.alert, hue: "#FFB86B" })
        })
    }
    function isShortcut(it) { return !!it && (it.kind === "link" || it.kind === "app" || it.kind === "app-missing") }
    // onDone(code, err, newKey): 2 = name taken, 4 = invalid name. Shortcuts change their shown Name=.
    function rename(key, newName, onDone) {
        const it = find(key)
        if (!it || !it.path) return
        let made = key
        op([isShortcut(it) ? "retitle" : "rename", it.path, newName], (o) => {
            if (o.name && !o.error && !o.unchanged) {
                made = o.name
                if (root.spots[key]) {                 // the icon keeps its spot under the new name
                    const next = Object.assign({}, root.spots)
                    next[o.name] = next[key]
                    delete next[key]
                    root.setSpots(next)
                }
            }
        }, (code, err) => { if (onDone) onDone(code, err, made) })
    }
    function trashPaths(paths) {
        if (paths.length) op(["trash"].concat(paths), null, (code, err) => {
            if (code !== 0) root.message({ title: err || "Couldn't move it to the Trash", glyph: Icons.alert, hue: "#FFB86B" })
        })
    }
    function isFixed(it) { return !!it && (it.kind === "home" || it.kind === "trash" || it.kind === "install") }
    // Paths of the movable (non-fixed) items among `keys`.
    function pathsOf(keys) { return keys.map(find).filter(i => i && i.path && !isFixed(i)).map(i => i.path) }
    function trash(keys) { trashPaths(pathsOf(keys)) }
    function emptyTrash() {
        op(["empty-trash"], null, (code, err) => root.message(code === 0 ? { title: "Trash emptied", sub: "", glyph: Icons.trash, hue: "#C9CFDC" }
                                                                        : { title: err || "Couldn't empty the Trash", glyph: Icons.alert, hue: "#FFB86B" }))
    }
    function clip(keys, cut) {
        const paths = pathsOf(keys)
        if (paths.length) op([cut ? "clip-cut" : "clip-copy"].concat(paths))
    }
    property bool canPaste: false
    function checkPaste() { op(["can-paste"], null, (code) => root.canPaste = code === 0) }
    function paste(x, y) {
        let i = 0
        op(["paste", dir], (o) => { if (o.name && !o.error && !o.unchanged) reserve(o.name, x, y + (arrange === "free" ? 24 * i++ : 0)) },
           (code, err) => { if (code !== 0) root.message({ title: err || "Couldn't paste", glyph: Icons.alert, hue: "#FFB86B" }) }, true)
    }
    // Files dropped or moved: mode "copy" / "move" / "drop" (from Quasar's Files: a move on the same
    // drive, a copy onto another); dest = a folder path (default ~/Desktop).
    function transfer(mode, paths, dest, x, y) {
        if (!paths.length) return
        const toDesk = !dest || dest === dir
        let i = 0
        op([mode, dest || dir].concat(paths), (o) => { if (toDesk && o.name && !o.error && !o.unchanged) reserve(o.name, x, y + (arrange === "free" ? 24 * i++ : 0)) },
           (code, err) => { if (code !== 0) root.message({ title: err || (mode === "copy" ? "Some files couldn't be copied" : "Some files couldn't be moved"), glyph: Icons.alert, hue: "#FFB86B" }) },
           mode === "copy" ? "Copying…" : "Moving…")
    }

    // ------------------------------------------------------------------------------------ archives
    // Each archive unpacks next to itself; the new icon takes the next free spot.
    function extract(keys) {
        keys.map(find).filter(i => i && i.kind === "archive").forEach(it => {
            let made = ""
            op(["extract", it.path], (o) => { if (o.name && !o.error) made = o.name }, (code, err) => {
                if (code === 0) root.message({ title: "Extracted", sub: made, glyph: Icons.folder, hue: "#7AB8FF" })
                else if (code === 5) root.message({ title: "This archive has a password", sub: "Get PeaZip in the Store to open it", glyph: Icons.lock, hue: "#FFB86B" })
                else root.message({ title: err || "Couldn't extract it", sub: it.name, glyph: Icons.alert, hue: "#FFB86B" })
            }, "Extracting…")
        })
    }
    function compress(keys) {
        const paths = pathsOf(keys)
        if (!paths.length) return
        let made = ""
        op(["compress"].concat(paths), (o) => { if (o.name && !o.error) made = o.name }, (code, err) => {
            if (code === 0) root.message({ title: "Compressed", sub: made, glyph: Icons.pkg, hue: "#B9A4FF" })
            else root.message({ title: err || "Couldn't make the zip file", glyph: Icons.alert, hue: "#FFB86B" })
        }, "Compressing…")
    }

    // ------------------------------------------------------------------------------------ open
    function open(it) {
        if (!it) return
        if (it.kind === "home" || it.kind === "dir" || it.kind === "trash") return root.openFolderRequested(it.path)
        if (it.kind === "archive") return extract([it.key])
        if (it.kind === "install") return apps.launchId("quasar-installer")
        if (it.kind === "app") return apps.launch(it.entry)
        if (it.kind === "app-missing") return root.message({ title: "That app isn't installed", sub: it.name, glyph: Icons.grid, hue: Theme.text3 })
        if (it.kind === "program") return root.programRequested(it.path, "")
        if (it.kind === "package" && apps.launchId("quasar-store", [it.path])) return
        if (it.kind === "text" && apps.launchId("quasar-texteditor", [it.path])) return
        if (it.kind === "image" && apps.launchId("quasar-photos", [it.path])) return
        const target = it.kind === "link" ? it.link : it.path
        op(["open", target], null, (code, err) => {
            if (code === 3 && it.kind === "link")
                root.message({ title: "No web browser yet", sub: "Get one in the Store", glyph: Icons.globe, hue: "#7AE7FF" })
            else if (code === 3)
                root.message({ title: "No app can open this yet", sub: it.name, glyph: Icons.notes, hue: Theme.text3 })
            else if (code !== 0)
                root.message({ title: err || "Couldn't open it", sub: it.name, glyph: Icons.alert, hue: "#FFB86B" })
        })
    }
}
