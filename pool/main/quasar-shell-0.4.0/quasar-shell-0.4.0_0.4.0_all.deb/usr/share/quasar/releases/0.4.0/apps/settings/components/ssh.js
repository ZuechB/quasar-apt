// Settings > Users & Accounts > Remote sign-in (SSH), and the "Your SSH keys" page. Pure, so the Settings
// app (services/RemoteAccess.qml) and the design preview share it.
//   st:  quasar-ssh-keys status { installed, running, host: [{ type, fingerprint }], allowed: [name], address,
//        user, keys: [{ type, bits, fingerprint, comment }] }
//   ctx: { people: [{ name, display, admin }], me, busy: row key, progress, live, icons, theme }
// Keys: "ssh:on", "ssh:keys", "ssh:allow:<name>"; on the keys page "sshk:add", "sshk:rm:<fingerprint>".
.pragma library

function plural(n, one, many) { return n + " " + (n === 1 ? one : (many || one + "s")) }

function isOn(st) { return !!(st && st.installed && st.running) }

function groups(st, ctx) {
    var icons = ctx.icons, live = !!ctx.live
    if (live) return [{ label: "Remote sign-in", rows: [
        { key: "ssh:on", label: "Remote sign-in (SSH)", glyph: icons.terminal, trailing: "value", value: "Off",
          sub: "Installed PCs can let your other computers at home sign in with keys" }] }]
    var on = isOn(st), installing = ctx.busy === "ssh:on"
    var rows = [{ key: "ssh:on", label: "Remote sign-in (SSH)", glyph: icons.terminal, trailing: "toggle",
                  checked: on || installing, busy: installing,
                  sub: installing ? (ctx.progress >= 0 ? "Setting up…  " + ctx.progress + "%" : "Setting up…")
                     : on ? "On  ·  your home networks only  ·  keys only, never passwords"
                     : st && st.installed ? "Installed but not running: turn it off and on again"
                     : "Sign in to this PC from your other computers at home, with keys only" }]
    if (on) {
        var me = st.user || ctx.me
        var n = (st.keys || []).length
        rows.push({ key: "ssh:keys", label: "Your SSH keys", glyph: icons.key, trailing: "chevron",
                    value: n ? plural(n, "key") : "None yet",
                    sub: n ? "The computers that may sign in as you" : "Add your other computer's public key to sign in from it" })
        rows.push({ key: "ssh:how", label: "Connect from another computer", glyph: icons.monitor, trailing: "value", value: "",
                    sub: "ssh " + me + "@" + (st.address || "this PC's address") })
        var h = (st.host || []).filter(function (k) { return k.type === "ED25519" })[0] || (st.host || [])[0]
        if (h) rows.push({ key: "ssh:fp", label: "This PC's fingerprint", glyph: icons.shield, trailing: "value", value: "",
                           sub: h.type + " " + h.fingerprint + "  ·  check it matches the first time you connect" })
    }
    var out = [{ label: "Remote sign-in", rows: rows }]
    if (on) {
        var allowed = st.allowed || []
        out.push({ label: "Who may sign in remotely", rows: (ctx.people || []).map(function (p) {
            var k = "ssh:allow:" + p.name
            return { key: k, label: p.display + (p.name === ctx.me ? " (you)" : ""), glyph: icons.user, trailing: "toggle",
                     checked: allowed.indexOf(p.name) >= 0, busy: ctx.busy === k,
                     sub: (p.admin ? "Administrator" : "Standard account") + "  ·  with their own keys" }
        }) })
    }
    return out
}

// The "Your SSH keys" page.
function keyGroups(st, ctx) {
    var icons = ctx.icons
    var rows = (st && st.keys || []).map(function (k) {
        return { key: "sshk:rm:" + k.fingerprint, label: k.comment || k.type, glyph: icons.key, trailing: "button",
                 value: "Remove", busy: ctx.busy === "sshk:rm:" + k.fingerprint,
                 sub: k.type + (k.bits ? " " + k.bits : "") + "  ·  " + k.fingerprint }
    })
    rows.push({ key: "sshk:add", label: "Add a key…", glyph: icons.plus, trailing: "chevron", value: "",
                sub: "Paste the other computer's public key (the line in ~/.ssh/id_ed25519.pub)" })
    return [{ label: "Computers that may sign in as you", rows: rows },
            { label: "No key yet on the other computer?", rows: [
                { key: "sshk:help", label: "Make one there", glyph: icons.terminal, trailing: "value", value: "",
                  sub: "ssh-keygen -t ed25519, then copy the contents of ~/.ssh/id_ed25519.pub here" }] }]
}
