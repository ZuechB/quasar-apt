//@ pragma AppId quasar-settings
// Quasar Settings — native Qt Quick app run by Quickshell (launched by /usr/bin/quasar-settings).
//   quasar-settings [network|firewall|vpn|hotspot|dns|profiles|bluetooth|commanddeck|drivers|display|arrange|desktop|sound|appearance|notifications|privacy|ai|
//                    apps|performance|storage|users|input|language|updates|about]
// Rows whose system feature isn't built yet are shown with "Coming soon".
import QtQuick
import Quickshell
import Quickshell.Io
import Quickshell.Services.Pipewire
import Quasar
import Quasar.Services
import "components"
import "services"
import "components/drivers.js" as Drivers
import "components/displays.js" as Disp
import "components/firewall.js" as Fw

ShellRoot {
    id: app

    Binding { target: Theme; property: "accent"; value: Settings.accent }
    Binding { target: Theme; property: "reduceMotion"; value: Settings.reduceMotion }
    Binding { target: Theme; property: "softwareRender"; value: Platform.softwareScene }
    Binding { target: Theme; property: "profile"; value: Platform.softwareRender ? 0 : (Settings.profile >= 0 ? Settings.profile : 1) }

    // "firewall" is a sub page of Network & Internet, "arrange" (Arrange displays) one of Display (not in
    // the sidebar; SettingsView.subpages).
    // "vpn", "hotspot" and "dns" are sub pages of Network & Internet too; "history" (Update history) one of
    // Updates; "sshkeys" (Your SSH keys) and "remotedesktop" (Remote desktop) of Users & Accounts; "azure"
    // (one space's Azure DevOps agents) one of Companies & Profiles; "snapshots" one of Storage.
    readonly property var sectionKeys: ["network", "firewall", "vpn", "hotspot", "dns", "profiles", "bluetooth", "commanddeck", "drivers", "display", "arrange", "desktop", "sound", "appearance", "notifications", "privacy",
                                        "ai", "apps", "performance", "storage", "snapshots", "users", "sshkeys", "remotedesktop", "azure", "input", "language", "updates", "history", "about"]
    property string section: "network"
    property var banner: null
    function go(arg) {
        const a = (arg || "").trim()
        if (sectionKeys.indexOf(a) >= 0) { section = a; banner = null }
    }
    Component.onCompleted: go(Quickshell.env("QUASAR_APP_ARGS"))

    // ---- services ---------------------------------------------------------------------------------
    Wifi {              // Network: Wi-Fi + Ethernet through NetworkManager (services/Wifi.qml)
        id: wifi
        active: app.section === "network"
        paused: app.passwordFor !== "" || joinDialog.open
        onConnected: (n) => { app.passwordFor = ""; app.banner = { tone: "success", title: "Connected to " + n, message: "" } }
        onFailed: (n, m, askPassword) => {
            app.banner = { tone: "error", title: m, message: askPassword ? "Type it again: passwords are case-sensitive." : "Check that you're in range, then try again." }
            if (askPassword) app.passwordFor = n
        }
    }
    BluetoothSettings { // Bluetooth: BlueZ devices and pairing (services/BluetoothSettings.qml)
        id: bt
        active: app.section === "bluetooth"
        onNotify: (b) => { if (app.section === "bluetooth") app.banner = b }
    }
    SystemInfo { id: info }
    Firewall {          // Network > Firewall: on/off, home networks, allowed apps and ports (services/Firewall.qml)
        id: fw
        active: app.section === "network" || app.section === "firewall" || app.section === "remotedesktop"
        onNotify: (b) => { if (app.section === "network" || app.section === "firewall" || app.section === "remotedesktop") app.banner = b }
        onPick: (title, options, current, done, message) => picker.ask(title, options, current, done, message)
    }
    NetMonitor {        // Network > Network monitor (apps' internet use today, Block/Allow) and Firewall > Recently blocked
        id: monitor
        active: app.section === "network"
        recentActive: app.section === "firewall"
        onRecentChanged: fw.recent = recent
        onNotify: (b) => { if (app.section === "network") app.banner = b }
    }
    // Network > VPN, Mobile hotspot, Encrypted DNS (services/NmList, Vpn, Hotspot, EncryptedDns.qml;
    // their dialogs are components/NetDialogs.qml).
    readonly property bool netPage: section === "network" || section === "vpn" || section === "hotspot" || section === "dns"
    NmList { id: nmList; active: app.section === "network" || app.section === "vpn" || app.section === "hotspot" }
    Vpn {
        id: vpn
        st: nmList.st
        onChanged: nmList.refresh()
        onNotify: (b) => { if (app.netPage) app.banner = b }
        onPick: (title, options, current, done, message) => picker.ask(title, options, current, done, message)
    }
    Hotspot {
        id: hotspot
        list: nmList.st
        active: app.section === "hotspot"
        networkActive: app.section === "network"
        onChanged: nmList.refresh()
        onNotify: (b) => { if (app.netPage) app.banner = b }
        onPick: (title, options, current, done, message) => picker.ask(title, options, current, done, message)
    }
    EncryptedDns {
        id: edns
        active: app.section === "network" || app.section === "dns"
        onNotify: (b) => { if (app.netPage) app.banner = b }
        onPick: (title, options, current, done, message) => picker.ask(title, options, current, done, message)
    }
    CommandDeck {       // Command Deck: phones as a remote (services/CommandDeck.qml, deckd)
        id: deckSvc
        active: app.section === "commanddeck"
        onNotify: (b) => { if (app.section === "commanddeck") app.banner = b }
        onPick: (title, options, current, done, message) => picker.ask(title, options, current, done, message)
    }
    Hardware {          // Drivers & Hardware: hw-detect's report + driver installs (services/Hardware.qml)
        id: hardware
        property string origin: "drivers"    // the page that started an install shows its progress
        onNotify: (b) => { if (app.section === origin) app.banner = b }
    }
    // Why the Network/Bluetooth page has no adapter (missing firmware, no driver), from hw-detect.
    readonly property var radioIssue: section === "network" ? Drivers.radioIssue(hardware.report, "wifi", wifi.hardware)
                                    : section === "bluetooth" ? Drivers.radioIssue(hardware.report, "bluetooth", bt.present) : null
    Displays {          // Display + Arrange displays: /usr/libexec/quasar/displays (services/Displays.qml)
        id: displays
        active: app.section === "display" || app.section === "arrange"
        onNotify: (b) => { if (app.section === "display" || app.section === "arrange") app.banner = b }
        onPick: (title, options, current, done, message) => picker.ask(title, options, current, done, message)
    }
    readonly property var displayCtx: ({ main: displays.mainName, selected: displays.selected, nightLight: Settings.nightLight,
                                         softwareRender: Platform.softwareRender,
                                         vrr: (Settings.displays || {}).vrr !== false, taskbarAll: (Settings.displays || {}).taskbarAll !== false,
                                         hdr: (Settings.displays || {}).hdr === true, renderer: displays.renderer,
                                         hdrFailed: displays.hdrFailed, hdrBusy: displays.hdrBusy })
    // HDR (displays.js hdrRow): Settings' labwc layer says <hdr>yes</hdr>. labwc can drive HDR only on the
    // Vulkan renderer, which quasar-session starts at sign-in while that's there: on it, the change is live
    // (every display is set up again: displays reapply); otherwise signing out and back in finishes it.
    function toggleHdr() {
        if (displays.hdrBusy) return
        const on = (Settings.displays || {}).hdr !== true
        displays.setOption("hdr", on)
        if (displays.renderer === "vulkan") {
            displays.hdrBusy = true
            labwcLayer.apply([displays.helper, "reapply"], () => displays.hdrApplied())
        } else {
            labwcLayer.apply()
        }
        if (on && displays.renderer !== "vulkan" && !displays.hdrFailed)
            banner = { tone: "info", title: "Sign out to finish turning on HDR",
                       message: "HDR uses a different graphics renderer, which starts when you sign in again. Save your work first.",
                       actionText: "Sign out", action: "session:signout" }
        else if (banner && banner.action === "session:signout")
            banner = null
    }
    CompanyAdmin {      // Companies & Profiles: company environments (services/CompanyAdmin.qml)
        id: companyAdmin
        active: app.section === "profiles"
        azureCount: (space) => azure.countFor(space)
        onNotify: (b) => { if (app.section === "profiles") app.banner = b }
        onPick: (title, options, current, done) => picker.ask(title, options, current, done)
    }
    UserAdmin {         // Users & Accounts: people, automatic sign-in, Vault (services/UserAdmin.qml)
        id: userAdmin
        active: app.section === "users"
        onNotify: (b) => { if (app.section === "users") app.banner = b }
        onPick: (title, options, current, done, message) => picker.ask(title, options, current, done, message)
    }
    AzureDevOps {       // Companies & Profiles › Azure DevOps: one space's build and deploy agents (services/AzureDevOps.qml)
        id: azure
        active: app.section === "azure"
        onNotify: (b) => { if (app.section === "azure") app.banner = b }
    }
    RemoteAccess {      // Users & Accounts › Remote sign-in (SSH): on/off, who may, your keys (services/RemoteAccess.qml)
        id: remote
        active: app.section === "users"
        keysActive: app.section === "sshkeys"
        people: userAdmin.people
        onNotify: (b) => { if (app.section === "users" || app.section === "sshkeys") app.banner = b }
        onOpenKeys: app.go("sshkeys")
    }
    RemoteDesktop {     // Users & Accounts › Remote desktop (VNC): on/off, how to connect, after a restart, router VPN
        id: rdSvc
        active: app.section === "remotedesktop" || app.section === "users"
        users: userAdmin
        firewall: fw
        onNotify: (b) => { if (app.section === "remotedesktop" || app.section === "users") app.banner = b }
    }
    AiSetup {           // Quasar AI: provider, key, model, on-device engine and models (services/AiSetup.qml)
        id: ai
        active: app.section === "ai"
        onNotify: (b) => { if (app.section === "ai") app.banner = b }
        onPick: (title, options, current, done) => picker.ask(title, options, current, done)
    }
    Updates {           // Updates: system updates, automatic updates and restarts (services/Updates.qml, quasar-update)
        id: updates
        active: app.section === "updates" || app.section === "apps" || app.section === "history"
        historyActive: app.section === "history"
        onNotify: (b) => { if (app.section === "updates" || app.section === "history" || app.section === "apps") app.banner = b }
        onPick: (title, options, current, done, message) => picker.ask(title, options, current, done, message)
        onOpenHistory: app.go("history")
        onOpenAi: app.go("ai")
    }
    Snapshots {         // Storage › Safety and Snapshots: btrfs snapshots, restore, start one once (services/Snapshots.qml)
        id: snaps
        active: app.section === "storage" || app.section === "snapshots"
        onNotify: (b) => { if (app.section === "storage" || app.section === "snapshots") app.banner = b }
        onPick: (title, options, current, done, message) => picker.ask(title, options, current, done, message)
        onOpenPage: app.go("snapshots")
    }
    // Apps › Startup and background apps: how many run (the Services app's numbers, while the page shows).
    property int servicesRunning: -1
    Process {
        command: [Quickshell.env("QUASAR_SERVICES_QUERY") || "/usr/libexec/quasar/services-query", "watch", "--summary"]
        running: app.section === "apps"
        stdout: SplitParser {
            onRead: (l) => { try { const o = JSON.parse(l); if (o.type === "summary") app.servicesRunning = o.running || 0 } catch (e) { } }
        }
    }
    // Date & Language › Set time automatically: systemd-timesyncd through timedated (on by default on
    // installed PCs; the live USB never syncs).
    property bool ntp: false
    Process {
        id: ntpRead
        command: ["timedatectl", "show", "-p", "NTP", "--value"]
        running: true
        stdout: StdioCollector { onStreamFinished: app.ntp = text.trim() === "yes" }
    }
    Timer { id: ntpLater; interval: 900; onTriggered: ntpRead.running = true }
    LabwcLayer { id: labwcLayer; input: Settings.input; displays: Settings.displays }   // Settings' labwc layer (input, VRR, HDR)
    PwObjectTracker { objects: [Pipewire.defaultAudioSink, Pipewire.defaultAudioSource] }
    readonly property var sink: Pipewire.defaultAudioSink
    readonly property var sinks: Pipewire.nodes.values.filter(n => n && n.isSink && !n.isStream && n.audio)
    property string passwordFor: ""

    property string timezone: ""
    property var zones: []
    Process {
        id: tz
        command: ["timedatectl", "show", "-p", "Timezone", "--value"]
        running: true
        stdout: StdioCollector { onStreamFinished: app.timezone = text.trim() }
    }
    Process {
        id: tzList
        command: ["timedatectl", "list-timezones"]
        stdout: StdioCollector { onStreamFinished: app.zones = text.trim().split("\n").map(z => ({ key: z, label: z.replace(/_/g, " ") })) }
    }

    onSectionChanged: {
        passwordFor = ""
        if (section === "storage") info.refreshStorage()
        if (section === "display" || section === "arrange") displays.refresh()
    }

    // ---- rows per section --------------------------------------------------------------------------
    function soon(label, sub, glyph) { return { key: label, label: label, sub: sub || "", glyph: glyph || "", trailing: "soon" } }
    function gb(b) { return b >= 1e9 ? (b / 1e9).toFixed(1) + " GB" : Math.round(b / 1e6) + " MB" }
    readonly property var groups: {
        const s = section
        if (s === "network") return [{ label: "More connections", rows: [
            { key: "ethernet", label: "Ethernet", sub: wifi.ethernet, glyph: Icons.ethernet, trailing: "value", value: wifi.ethernet.startsWith("Connected") ? "Connected" : "" , valueColor: Theme.mint },
            vpn.networkRow, hotspot.networkRow, edns.networkRow].concat(fw.networkRows, [
            soon("Proxy", "", Icons.proxy)]) }]
        if (s === "firewall") return fw.groups
        if (s === "vpn") return vpn.groups
        if (s === "hotspot") return hotspot.groups
        if (s === "dns") return edns.groups
        if (s === "drivers") return hardware.groups
        if (s === "commanddeck") return deckSvc.groups
        if (s === "profiles") return companyAdmin.groups
        // Bluetooth devices are BluetoothList (live rows, below the hero); only the options are rows.
        if (s === "bluetooth") return bt.present ? [{ label: "Options", rows: [soon("Receive files over Bluetooth", "Asks before saving")] }] : []
        // The main display's settings, VRR and HDR; Arrange displays: the selected display (displays.js).
        if (s === "display") return Disp.groups(displays.st, displayCtx)
        if (s === "arrange") return Disp.arrangeGroups(displays.st, displayCtx)
        if (s === "desktop") return [{ label: "Icons", rows: [
            { key: "desktopArrange", label: "Arrange icons", sub: (arrangeModes.find(m => m.key === Settings.desktopArrange) || arrangeModes[0]).sub,
              trailing: "chevron", value: (arrangeModes.find(m => m.key === Settings.desktopArrange) || arrangeModes[0]).label },
            { key: "desktopTidy", label: "Tidy up icons", sub: "Put every icon back in order, top left first", trailing: "button", value: "Tidy up" }] },
            { label: "Your desktop", rows: [
            { key: "desktopFolder", label: "Desktop folder", sub: "What's on the desktop is the Desktop folder in your Home", trailing: "button", value: "Open" },
            { key: "desktopWallpaper", label: "Wallpaper", sub: "Set on the Display page", trailing: "chevron" }] }]
        if (s === "sound") return [{ label: "Output", rows: [
            { key: "output", label: "Output device", trailing: sinks.length > 1 ? "chevron" : "value", value: sink ? (sink.description || sink.nickname || sink.name) : "None" },
            { key: "volume", label: "Volume", trailing: "value", value: sink && sink.audio ? Math.round(sink.audio.volume * 100) + "%" : "—" },
            { key: "mute", label: "Mute", trailing: "toggle", checked: !!(sink && sink.audio && sink.audio.muted) },
            soon("Interface sounds", "Soft, spatial UI sounds")] },
            { label: "Input", rows: [soon("Noise suppression", "Runs on this PC")] }]
        if (s === "appearance") return [{ label: "Effects", rows: [
            { key: "glass", label: "Transparency", sub: Platform.softwareRender ? "Needs graphics acceleration" : "Frosted glass on panels and windows", trailing: Platform.softwareRender ? "value" : "toggle", checked: Settings.glass, value: "Off" },
            { key: "motion", label: "Animations", sub: "Spring physics across the interface", trailing: "toggle", checked: !Settings.reduceMotion },
            soon("Font size"), soon("Cursor")] }]
        if (s === "notifications") return [{ label: "Delivery", rows: [
            { key: "dnd", label: "Do not disturb", sub: "Hold notifications until you turn it off", trailing: "toggle", checked: Settings.focus },
            soon("Calm mode", "Bundle non-urgent notifications hourly"), soon("App badges"), soon("Show on lock screen"), soon("Focus schedule")] }]
        if (s === "privacy") return [{ label: "Sensors", rows: [soon("Camera", "See which app is using it"), soon("Microphone", "See which app is using it"), soon("Location services")] },
            { label: "Protection", rows: [
            { key: "telemetry", label: "Telemetry", sub: "Quasar collects nothing. This stays off.", trailing: "value", value: "Off", valueColor: Theme.mint },
            { key: "disk", label: "Disk encryption", sub: "Set up when Quasar is installed", trailing: "value", value: info.encrypted || "…" },
            { key: "sandbox", label: "Prefer sandboxed apps", sub: "The Store shows Flathub apps first", trailing: "toggle", checked: Settings.preferSandbox },
            soon("App permissions", "Camera, files and network, per app")] }]
        if (s === "ai") return ai.groups
        if (s === "apps") return [{ label: "Apps", rows: [
            { key: "installed", label: "Installed apps", trailing: "chevron", value: DesktopEntries.applications.values.length + " apps" },
            soon("Default apps", "Browser, mail, files"),
            { key: "services", label: "Startup and background apps", sub: "Manage them in Services", trailing: "chevron",
              value: app.servicesRunning >= 0 ? app.servicesRunning + " running" : "" },
            { key: "up:apps", label: "Update apps automatically", sub: "Every day, apps and their runtimes, when plugged in",
              trailing: Platform.live ? "value" : "toggle", value: Platform.live ? "Off" : "",
              checked: !!(updates.st && updates.st.apps), busy: updates.busy === "apps" }] },
            { label: "Sources", rows: [
            { label: "Flathub", sub: "Sandboxed apps", trailing: "value", value: "On", valueColor: Theme.mint },
            { label: "Debian", sub: "System packages", trailing: "value", value: "On", valueColor: Theme.mint },
            soon("Quasar Community", "GitHub, signed releases")] }]
        if (s === "performance") return [{ label: "Details", rows: [
            { key: "pc", label: "This PC", sub: (info.virt !== "none" ? "Virtual machine" : "Physical PC") + "  ·  " + info.memGB + " GB memory  ·  " + (Platform.softwareRender ? "software rendering" : "GPU accelerated"),
              trailing: "value", value: info.virt === "microsoft" ? "Hyper-V" : info.virt === "kvm" || info.virt === "qemu" ? "QEMU/KVM" : info.virt !== "none" ? info.virt : "Desktop" },
            soon("Frame rate", "Match display"), soon("Preload frequent apps")] }]
        if (s === "storage") return [{ label: "This PC", rows: [
            { label: "Used", sub: info.diskTotal ? gb(info.diskTotal) + " in total" : "", trailing: "value", value: info.diskUsed ? gb(info.diskUsed) : "…" },
            { label: "Apps (Flatpak)", trailing: "value", value: info.flatpakBytes ? gb(info.flatpakBytes) : "…" },
            { label: "Your files", sub: Platform.home, trailing: "value", value: info.homeBytes ? gb(info.homeBytes) : "…" },
            { key: "cleanup", label: "Clean up", sub: "Remove app runtimes nothing uses any more", trailing: "button", value: "Clean up" }] },
            { label: "Safety", rows: snaps.storageRows }]
        if (s === "users") return userAdmin.groups.concat(remote.groups, rdSvc.entryGroups)
        if (s === "sshkeys") return remote.keyGroups
        if (s === "remotedesktop") return rdSvc.groups
        if (s === "azure") return azure.groups
        if (s === "input") {
            const i = Settings.input || {}
            const speeds = { "-0.5": "Slow", "0": "Default", "0.4": "Fast", "0.8": "Fastest" }
            return [{ label: "Pointer", rows: [
                { key: "tap", label: "Tap to click", sub: "Touchpads", trailing: "toggle", checked: i.tap !== false },
                { key: "natural", label: "Natural scrolling", sub: "Content follows your fingers", trailing: "toggle", checked: !!i.naturalScroll },
                { key: "speed", label: "Pointer speed", trailing: "chevron", value: speeds[String(i.speed !== undefined ? i.speed : 0)] || "Custom" },
                { key: "flat", label: "Steady pointer", sub: "Turn off pointer acceleration", trailing: "toggle", checked: !!i.flat }] },
                { label: "Keyboard", rows: [
                { key: "repeat", label: "Repeat rate", trailing: "chevron", value: (i.repeatRate || 40) >= 55 ? "Fast" : (i.repeatRate || 40) <= 30 ? "Relaxed" : "Default" },
                { label: "Shortcuts", sub: "Super opens the launcher, Super + Return a terminal", trailing: "value", value: "" },
                soon("Layout", "English (US)")] }]
        }
        if (s === "language") return [{ label: "Time", rows: [
            { key: "timezone", label: "Time zone", trailing: "chevron", value: timezone || "…" },
            { key: "clock24", label: "24-hour clock", trailing: "toggle", checked: Settings.clock24 },
            { key: "ntp", label: "Set time automatically", sub: Platform.live ? "Installed PCs set their clock from internet time servers"
                                                                   : "From internet time servers (Debian's). Secure connections and updates need the right time",
              trailing: Platform.live ? "value" : "toggle", value: Platform.live ? "Off" : "", checked: app.ntp }] },
            { label: "Language", rows: [soon("Language", "English (US)"), soon("Formats", "United States")] }]
        if (s === "updates") return updates.groups
        if (s === "history") return updates.historyGroups
        if (s === "snapshots") return snaps.groups
        if (s === "about") return [{ label: "System", rows: [
            { label: "OS", trailing: "value", value: info.osName },
            { label: "Kernel", trailing: "value", value: info.kernel ? "Linux " + info.kernel : "…" },
            { label: "Compositor", trailing: "value", value: Platform.compositor + " (Wayland)" },
            { label: "Shell", trailing: "value", value: "Quickshell · Qt 6.8" },
            { label: "Graphics", trailing: "value", value: Platform.softwareRender ? "Software rendering" : "GPU accelerated" },
            { label: "Memory", trailing: "value", value: info.memGB ? info.memGB + " GB" : "…" },
            { label: "Processor", trailing: "value", value: info.cpu || "…" }] }]
        return []
    }
    readonly property var hero: {
        if (section === "network") return !wifi.hardware
            ? { glyph: Icons.ethernet, title: wifi.ethernet.startsWith("Connected") ? "Wired network" : "No Wi-Fi adapter", sub: wifi.ethernet }
            : wifi.hardBlocked
            ? { glyph: Icons.wifi, title: "Wi-Fi is switched off", sub: "Turn it on with the switch or key on this PC (often the airplane-mode key)." }
            : { glyph: Icons.wifi, toggle: true, checked: wifi.enabled,
                title: wifi.hosting ? "Hosting your Mobile hotspot" : !wifi.enabled ? "Wi-Fi is off" : wifi.connectedName || "Not connected",
                sub: wifi.hosting ? "This Wi-Fi adapter is busy sharing this PC's internet. Stop the hotspot to join a network."
                   : !wifi.enabled ? "Turn it on to see networks"
                   : wifi.connectedName ? "Connected  ·  " + wifi.connectedSecurity + (NetState.dnsOn ? "  ·  Encrypted DNS on" : "")
                   : "Pick a network below",
                iconBg: wifi.enabled && wifi.connectedName ? Theme.accent : Theme.white(0.07),
                iconFg: wifi.enabled && wifi.connectedName ? Theme.accentInk : Theme.text3 }
        if (section === "bluetooth") return !bt.present
            ? { glyph: Icons.bt, title: "No Bluetooth adapter", sub: "This PC has no Bluetooth that Quasar can use right now." }
            : bt.blocked && bt.hardBlocked
            ? { glyph: Icons.bt, title: "Bluetooth is switched off", sub: "Turn it on with the switch or key on this PC (often the airplane-mode key)." }
            : { glyph: Icons.bt, toggle: true, checked: bt.powered,
                title: bt.powered ? "Bluetooth is on" : "Bluetooth is off",
                sub: !bt.powered ? "Turn it on to use headphones, keyboards, mice and controllers"
                   : bt.adding ? "Visible to nearby devices as " + (info.hostname || "this PC") : "Not visible to other devices",
                iconBg: bt.powered ? Theme.accent : Theme.white(0.07), iconFg: bt.powered ? Theme.accentInk : Theme.text3 }
        if (section === "firewall") return fw.hero
        if (section === "vpn") return vpn.hero
        if (section === "hotspot") return hotspot.hero
        if (section === "dns") return edns.hero
        if (section === "drivers") return hardware.hero
        if (section === "commanddeck") return deckSvc.hero
        if (section === "about") return { glyph: Icons.orbit, title: info.hostname || "quasar", sub: info.osName + "  ·  x86_64", button: "Rename" }
        if (section === "ai") return ai.hero
        if (section === "profiles") return companyAdmin.hero
        if (section === "updates") return updates.hero
        if (section === "snapshots") return snaps.hero
        if (section === "azure") return azure.hero
        return null
    }

    // ---- actions ------------------------------------------------------------------------------------------
    function toggled(key) {
        if (key === "fw" || key.startsWith("fw:")) fw.toggle(key)
        else if (key === "night") Settings.nightLight = !Settings.nightLight
        else if (key === "hw:safe") hardware.toggleSafe()
        else if (key === "vrr") { displays.setOption("vrr", (Settings.displays || {}).vrr === false); labwcLayer.apply() }
        else if (key === "hdr") toggleHdr()
        else if (key === "taskbarAll") displays.setOption("taskbarAll", (Settings.displays || {}).taskbarAll === false)
        else if (key === "dsp:on") { const o = displays.sel; if (o) displays.change(o.name, { enabled: !o.enabled }) }
        else if (key === "glass") Settings.glass = !Settings.glass
        else if (key === "motion") Settings.reduceMotion = !Settings.reduceMotion
        else if (key === "dnd") Settings.focus = !Settings.focus
        else if (key === "sandbox") Settings.preferSandbox = !Settings.preferSandbox
        else if (key === "clock24") Settings.clock24 = !Settings.clock24
        else if (key === "mute") { if (sink && sink.audio) sink.audio.muted = !sink.audio.muted }
        else if (key.startsWith("co:")) companyAdmin.toggle(key)
        else if (key.startsWith("cd:")) deckSvc.toggle(key)
        else if (key.startsWith("u:") || key === "autologin" || key === "autologinLock") userAdmin.toggle(key)
        else if (key.startsWith("rd:")) rdSvc.toggle(key)
        else if (key.startsWith("ai:")) ai.toggle(key)
        else if (key.startsWith("up:")) updates.toggle(key)
        else if (key.startsWith("snap:")) snaps.toggle(key)
        else if (key.startsWith("ssh:")) remote.toggle(key)
        else if (key.startsWith("azp:")) azure.toggle(key)
        else if (key === "ntp") { Quickshell.execDetached(["timedatectl", "set-ntp", app.ntp ? "false" : "true"]); ntpLater.restart() }
        else if (key === "tap" || key === "natural" || key === "flat") {
            const i = Object.assign({}, Settings.input || {})
            if (key === "tap") i.tap = i.tap === false
            if (key === "natural") i.naturalScroll = !i.naturalScroll
            if (key === "flat") i.flat = !i.flat
            Settings.input = i
            labwcLayer.input = i
            labwcLayer.apply()
        }
    }
    // Display rows (displays.js keys): on Display they're about the main display, on Arrange displays
    // about the selected one.
    function displayActivated(key) {
        const o = section === "arrange" ? displays.sel : displays.main
        if (!o) return
        if (key === "dsp:res") displays.pickResolution(o.name)
        else if (key === "dsp:hz") displays.pickRefresh(o.name)
        else if (key === "dsp:scale") displays.pickScale(o.name)
        else if (key === "dsp:rot") displays.pickOrientation(o.name)
        else if (key === "dsp:makemain") displays.makeMain(o.name)
    }
    // Desktop icon arrangement (Settings.desktopArrange; the shell lays the icons out).
    readonly property var arrangeModes: [
        { key: "grid", label: "Snap to grid", sub: "Drag icons anywhere; they line up in a grid" },
        { key: "free", label: "Free placement", sub: "Drag icons anywhere; they stay exactly where you drop them" },
        { key: "auto", label: "Auto-arrange", sub: "Sorted by name, folders first; new items find their place" }
    ]
    function activated(key) {
        if (key === "fw:open") { go("firewall"); return }
        if (key === "fw" || key.startsWith("fw:")) { fw.activate(key); return }
        if (key === "vpn:open") { go("vpn"); return }
        if (key === "hs:open") { go("hotspot"); return }
        if (key === "dns:open") { go("dns"); return }
        if (key.startsWith("vpn:")) { vpn.activate(key); return }
        if (key.startsWith("hs:")) { hotspot.activate(key); return }
        if (key.startsWith("dns:")) { edns.activate(key); return }
        if (key === "desktopArrange") { picker.ask("Arrange icons", arrangeModes.map(m => ({ key: m.key, label: m.label })), Settings.desktopArrange, (k) => Settings.desktopArrange = k); return }
        if (key === "desktopTidy") { Quickshell.execDetached(["qs", "--path", "/usr/share/quasar/shell", "ipc", "call", "desktop", "tidy"]); return }
        if (key === "desktopFolder") { Quickshell.execDetached(["/usr/libexec/quasar/fileop", "open", Platform.home + "/Desktop"]); return }   // Files (mimeapps.list)
        if (key === "desktopWallpaper") { go("display"); return }
        if (key === "arrange") { go("arrange"); return }
        if (key.startsWith("dsp:")) { displayActivated(key); return }
        if (key === "output") picker.ask("Output device", sinks.map(n => ({ key: String(n.id), label: n.description || n.nickname || n.name })), sink ? String(sink.id) : "", (k) => { const n = sinks.find(x => String(x.id) === k); if (n) Pipewire.preferredDefaultAudioSink = n })
        else if (key === "speed") picker.ask("Pointer speed", [["-0.5", "Slow"], ["0", "Default"], ["0.4", "Fast"], ["0.8", "Fastest"]].map(x => ({ key: x[0], label: x[1] })), String((Settings.input || {}).speed !== undefined ? Settings.input.speed : 0), (k) => { const i = Object.assign({}, Settings.input || {}); i.speed = parseFloat(k); Settings.input = i; labwcLayer.input = i; labwcLayer.apply() })
        else if (key === "repeat") picker.ask("Key repeat", [["25", "Relaxed"], ["40", "Default"], ["60", "Fast"]].map(x => ({ key: x[0], label: x[1] })), String((Settings.input || {}).repeatRate || 40), (k) => { const i = Object.assign({}, Settings.input || {}); i.repeatRate = parseInt(k); Settings.input = i; labwcLayer.input = i; labwcLayer.apply() })
        else if (key === "timezone") { if (!zones.length) tzList.running = true; picker.ask("Time zone", Qt.binding(() => app.zones), timezone, (k) => { Quickshell.execDetached(["timedatectl", "set-timezone", k]); tzLater.restart() }) }
        else if (key === "installed") Quickshell.execDetached(["quasar-store", "installed"])
        else if (key === "services") Quickshell.execDetached(["quasar-services"])
        else if (key === "appUpdates") Quickshell.execDetached(["quasar-store", "updates"])
        else if (key === "cleanup") Quickshell.execDetached(["sh", "-c", "flatpak uninstall --unused -y --noninteractive >/dev/null 2>&1; notify-send -a Settings 'Clean-up finished' 'Unused app runtimes were removed.'"])
        else if (key.startsWith("hw:")) { hardware.origin = "drivers"; hardware.activate(key) }
        else if (/^co:([a-z][a-z0-9-]{0,21}|personal):azure$/.test(key)) {     // one space's Azure DevOps agents
            const sp = key.split(":")[1]
            const c = Companies.list.find(x => x.id === sp)
            azure.space = sp
            azure.spaceName = sp === "personal" ? "Personal" : (c ? c.name : sp)
            go("azure")
        }
        else if (key.startsWith("co:")) companyAdmin.activate(key)
        else if (key.startsWith("u:") || key === "autologin" || key === "autologinUser" || key === "autologinLock" || key === "vault") userAdmin.activate(key)
        else if (key === "rd:open") go("remotedesktop")
        else if (key.startsWith("rd:")) rdSvc.activate(key)
        else if (key.startsWith("ai:")) ai.activate(key)
        else if (key.startsWith("cd:")) deckSvc.activate(key)
        else if (key.startsWith("up:")) updates.activate(key)
        else if (key.startsWith("snap:")) snaps.activate(key)
        else if (key.startsWith("ssh:") || key.startsWith("sshk:")) remote.activate(key)
        else if (key.startsWith("azp:")) azure.activate(key)
    }
    // A Wi-Fi network picked in the list: join it, or ask for what it needs first.
    function wifiPicked(n) {
        const net = wifi.rows.find(x => x.name === n)
        if (!net) return
        if (net.kind === "wep")
            banner = { tone: "warning", title: n + " uses WEP", message: "WEP is outdated and anyone nearby can break it, so Quasar doesn't join it. Switch the router to WPA2 or WPA3." }
        else if (net.kind === "enterprise" && !net.known) { joinForm.reset(n); joinDialog.open = true }
        else if (net.known || net.kind === "open") wifi.connect(n)
        else passwordFor = n
    }
    Timer { id: tzLater; interval: 800; onTriggered: tz.running = true }

    // ---- window ----------------------------------------------------------------------------------------------
    AppWindow {
        id: win
        appName: "settings"
        title: "Settings"
        glyph: Icons.gear

        SettingsView {
            anchors.fill: parent
            section: app.section
            userName: Platform.userName
            accountSub: Platform.live ? "Live session" : "Local account"
            groups: app.groups
            hero: app.hero
            banner: app.banner || app.radioIssue
            wifiOn: wifi.enabled && !wifi.hardBlocked
            networks: wifi.networks
            scanning: wifi.scanning
            passwordFor: app.passwordFor
            btListVisible: bt.present && bt.powered
            btDevices: bt.pairedModel
            btNearby: bt.nearbyModel
            btAdding: bt.adding
            btPairing: bt.pairingPath
            accent: Settings.accent
            wallpaper: Settings.wallpaper
            wallpaperPhoto: Settings.wallpaperPhoto
            wallpaperFit: Settings.wallpaperFit
            profile: Theme.profile
            profileLocked: Platform.softwareRender
            monitorModel: monitor.model
            monitorCount: monitor.rows.length
            monitorTop: monitor.top
            monitorPhase: monitor.phase
            monitorBusy: monitor.busyKey
            onMonitorBlock: (k) => monitor.setBlocked(k, true)
            onMonitorAllow: (k) => monitor.setBlocked(k, false)
            onNavigate: (k) => app.go(k)
            onRowToggled: (k) => app.toggled(k)
            onRowActivated: (k) => app.activated(k)
            onHeroToggled: {
                if (app.section === "network") wifi.setEnabled(!wifi.enabled)
                else if (app.section === "firewall") fw.activate("fw")
                else if (app.section === "vpn") vpn.heroToggled()
                else if (app.section === "hotspot") hotspot.heroToggled()
                else if (app.section === "dns") edns.heroToggled()
                else if (app.section === "bluetooth") bt.setPowered(!bt.powered)
                else if (app.section === "commanddeck") deckSvc.heroToggled()
            }
            onHeroActivated: {
                if (app.section === "about") rename.open = true
                else if (app.section === "vpn") vpn.heroActivated()
                else if (app.section === "hotspot") hotspot.heroActivated()
                else if (app.section === "drivers") hardware.heroActivated()
                else if (app.section === "profiles") companyAdmin.heroActivated()
                else if (app.section === "ai") ai.heroActivated()
                else if (app.section === "commanddeck") deckSvc.heroActivated()
                else if (app.section === "updates") updates.heroActivated()
                else if (app.section === "snapshots") snaps.heroActivated()
            }
            onBannerAction: {
                const b = app.banner || app.radioIssue
                if (!b) return
                if (b.restart) Platform.power("reboot")
                else if (b.action === "session:signout")      // as the power menu's Sign out does
                    Quickshell.execDetached(["loginctl", "terminate-session", Quickshell.env("XDG_SESSION_ID") || "self"])
                else if (b.action === "go:drivers") app.go("drivers")
                else if (b.action && b.action.startsWith("hw:")) { hardware.origin = app.section; hardware.activate(b.action) }
            }
            onWifiPicked: (n) => app.wifiPicked(n)
            onWifiConnect: (n, pw) => { app.passwordFor = ""; wifi.connectWithPassword(n, pw) }
            onWifiCancel: app.passwordFor = ""
            onWifiDisconnect: (n) => wifi.disconnect(n)
            onWifiForget: (n) => wifi.forget(n)
            onWifiJoinOther: { joinForm.reset(""); joinDialog.open = true }
            onBtConnect: (k) => bt.connectDevice(k)
            onBtDisconnect: (k) => bt.disconnectDevice(k)
            onBtForget: (k) => bt.forget(k)
            onBtPair: (k) => bt.pair(k)
            onBtAdd: bt.startAdding()
            onBtStop: bt.stopAdding()
            onAccentPicked: (c) => Settings.accent = c
            onWallpaperPicked: (k) => Settings.wallpaper = k
            onWallpaperChoose: photoChooser.open = true
            onWallpaperFitPicked: (f) => Settings.wallpaperFit = f
            onProfilePicked: (i) => Settings.profile = i
            displayOutputs: displays.outputs
            selectedDisplay: displays.selected
            displayMain: displays.mainName
            displayBusy: displays.pending
            onDisplayChosen: (n) => displays.selected = n
            onDisplayMoved: (n, x, y) => displays.moveTo(n, x, y)
            onDisplayIdentify: displays.identify()
            deckCard: deckSvc.canPair ? { url: deckSvc.pairing.url || "", code: deckSvc.pairing.code || "", left: deckSvc.pairing.left || 0,
                                          address: deckSvc.status.url || "", pcName: deckSvc.status.pcName || "" } : null
        }
        NetDialogs {            // Network › VPN, Mobile hotspot, Encrypted DNS: their dialogs
            vpnSvc: vpn
            hotspotSvc: hotspot
            dnsSvc: edns
            home: Platform.home
            drives: "/media/" + (Quickshell.env("USER") || "")
        }
        PhotoChooser {          // Display: Choose a photo… (Settings.useWallpaperPhoto keeps a copy)
            id: photoChooser
            home: Platform.home
            drives: "/media/" + (Quickshell.env("USER") || "")
            onChosen: (p) => { open = false; Settings.useWallpaperPhoto(p) }
            onDismissed: open = false
        }
        Connections {
            target: Settings
            function onPhotoFailed(path) {
                app.banner = { tone: "error", title: "Couldn't use " + path.slice(path.lastIndexOf("/") + 1),
                               message: "Quasar couldn't read that picture. Pick another one, or copy it to your Pictures folder first." }
            }
        }

        ChoiceSheet {
            id: picker
            property var pickCallback: null
            function ask(t, opts, cur, cb, msg) { title = t; message = msg || ""; options = opts; current = cur; pickCallback = cb; open = true }
            onChosen: (k) => { open = false; if (pickCallback) pickCallback(k) }
            onDismissed: open = false
        }
        Dialog {
            id: rename
            title: "Rename this PC"
            message: "Other devices on your network see this name."
            onDismissed: open = false
            onOpenChanged: if (open) { nameField.text = info.hostname; nameField.focusInput() }
            TextField { id: nameField; width: parent.width; placeholder: "quasar-desktop" }
            buttons: [
                Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: rename.open = false },
                Button {
                    text: "Rename"; variant: "primary"; size: 38
                    enabled: /^[a-zA-Z0-9][a-zA-Z0-9-]{0,62}$/.test(nameField.text)
                    onClicked: { Quickshell.execDetached(["hostnamectl", "set-hostname", nameField.text]); rename.open = false; renameLater.restart() }
                }
            ]
        }
        Timer { id: renameLater; interval: 1000; onTriggered: info.refresh() }
        Dialog {        // Network: join a hidden network, or sign in to a work/school (Enterprise) network
            id: joinDialog
            modal: true
            title: joinForm.hidden ? "Join other network" : "Sign in to " + joinForm.ssid
            message: joinForm.hidden ? "For a network that doesn't show its name, or one you set up by hand."
                                     : "This work or school network signs you in with your own account."
            function submit() {
                if (!joinForm.valid) return
                const spec = joinForm.spec()
                open = false
                app.banner = { tone: "info", title: "Connecting to " + spec.ssid + "…", message: "" }
                wifi.join(spec)
            }
            onDismissed: open = false
            onOpenChanged: if (open) joinForm.focusFirst(); else joinForm.clearSecrets()
            JoinNetworkForm { id: joinForm; width: parent.width; onSubmitted: joinDialog.submit() }
            buttons: [
                Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: joinDialog.open = false },
                Button { text: joinForm.hidden ? "Join" : "Sign in"; variant: "primary"; size: 38; enabled: joinForm.valid; onClicked: joinDialog.submit() }
            ]
        }
        Dialog {        // Firewall: confirm turning it off, or forgetting a home network
            open: fw.ask !== null
            modal: true
            title: fw.ask ? fw.ask.title : ""
            message: fw.ask ? fw.ask.message : ""
            onDismissed: fw.ask = null
            buttons: [
                Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: fw.ask = null },
                Button { text: fw.ask ? fw.ask.button : ""; variant: "primary"; tone: fw.ask && fw.ask.danger ? Theme.danger : Theme.accent; size: 38; onClicked: fw.confirm() }
            ]
        }
        Dialog {        // Azure DevOps: add a build or deploy agent (the token in a password field, sent on stdin)
            id: azpDialog
            open: azure.form !== null
            modal: true
            readonly property bool build: !azure.form || azure.form.role === "build"
            title: build ? "Add a build agent" : "Add a deploy agent"
            message: (build ? "In Azure DevOps, make an agent pool (Organization settings › Agent pools) and a personal access token with Agent Pools (Read & manage)."
                            : "In Azure DevOps, make an environment in the project and a personal access token with Environment (Read & manage).")
                     + " The token is used once and never saved: a short expiry is fine."
            onDismissed: azure.form = null
            onOpenChanged: if (open) { azpUrl.text = ""; azpPool.text = ""; azpEnv.text = ""; azpProj.text = ""; azpToken.text = ""; azpUrl.focusInput() }
            function spec() {
                return build ? { url: azpUrl.text.trim(), pool: azpPool.text.trim(), token: azpToken.text.trim() }
                             : { url: azpUrl.text.trim(), project: azpProj.text.trim(), environment: azpEnv.text.trim(), token: azpToken.text.trim() }
            }
            Column {
                width: parent.width
                spacing: 8
                TextField { id: azpUrl; width: parent.width; placeholder: "https://dev.azure.com/your-organization" }
                TextField { id: azpPool; width: parent.width; visible: azpDialog.build; placeholder: "Agent pool (e.g. Quasar)" }
                TextField { id: azpProj; width: parent.width; visible: !azpDialog.build; placeholder: "Project" }
                TextField { id: azpEnv; width: parent.width; visible: !azpDialog.build; placeholder: "Environment (e.g. production)" }
                TextField { id: azpToken; width: parent.width; password: true; placeholder: "Personal access token" }
                Text {
                    width: parent.width
                    visible: azure.formError !== ""
                    text: azure.formError
                    color: Theme.danger
                    wrapMode: Text.Wrap
                    font.family: Theme.fontUi
                    font.pointSize: Theme.pt(13)
                }
            }
            buttons: [
                Button { text: azure.busy.startsWith("azp:add:") ? "Adding…" : "Add"; variant: "primary"; size: 38
                         enabled: azure.busy === "" && azpUrl.text.trim() !== "" && azpToken.text.trim().length >= 20
                                  && (azpDialog.build ? azpPool.text.trim() !== "" : azpProj.text.trim() !== "" && azpEnv.text.trim() !== "")
                         onClicked: azure.submit(azpDialog.spec()) },
                Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: azure.form = null }
            ]
        }
        Dialog {        // Azure DevOps: confirm removing an agent (an optional token also unregisters it)
            open: azure.ask !== null
            modal: true
            title: azure.ask ? azure.ask.title : ""
            message: azure.ask ? azure.ask.message : ""
            onDismissed: azure.ask = null
            onOpenChanged: if (open) azpRmToken.text = ""
            TextField { id: azpRmToken; width: parent.width; password: true; placeholder: "Access token (optional)" }
            buttons: [
                Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: azure.ask = null },
                Button { text: azure.ask ? azure.ask.button : ""; variant: "primary"; tone: Theme.danger; size: 38; onClicked: azure.confirm(azpRmToken.text.trim()) }
            ]
        }
        Dialog {        // Remote sign-in: confirm turning it off, or removing one of your keys
            open: remote.ask !== null
            modal: true
            title: remote.ask ? remote.ask.title : ""
            message: remote.ask ? remote.ask.message : ""
            onDismissed: remote.ask = null
            buttons: [
                Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: remote.ask = null },
                Button { text: remote.ask ? remote.ask.button : ""; variant: "primary"; tone: remote.ask && remote.ask.danger ? Theme.danger : Theme.accent; size: 38; onClicked: remote.confirm() }
            ]
        }
        Dialog {        // Remote desktop: confirm removing it from this PC
            open: rdSvc.ask !== null
            modal: true
            title: rdSvc.ask ? rdSvc.ask.title : ""
            message: rdSvc.ask ? rdSvc.ask.message : ""
            onDismissed: rdSvc.ask = null
            buttons: [
                Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: rdSvc.ask = null },
                Button { text: rdSvc.ask ? rdSvc.ask.button : ""; variant: "primary"; tone: Theme.danger; size: 38; onClicked: rdSvc.confirm() }
            ]
        }
        Dialog {        // Your SSH keys › Add a key: the other computer's public key (as you, no password)
            id: sshKeyDialog
            open: remote.addOpen
            modal: true
            title: "Add a key"
            message: "On the other computer, copy the line in ~/.ssh/id_ed25519.pub (make one with ssh-keygen -t ed25519). Never paste a private key."
            onDismissed: remote.addOpen = false
            onOpenChanged: if (open) { sshKeyField.text = ""; sshKeyField.focusInput() }
            Column {
                width: parent.width
                spacing: 8
                TextField { id: sshKeyField; width: parent.width; mono: true; placeholder: "ssh-ed25519 AAAA… you@laptop" }
                Text {
                    width: parent.width
                    visible: remote.addError !== ""
                    text: remote.addError
                    color: Theme.danger
                    wrapMode: Text.Wrap
                    font.family: Theme.fontUi
                    font.pointSize: Theme.pt(13)
                }
            }
            buttons: [
                Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: remote.addOpen = false },
                Button { text: "Add"; variant: "primary"; size: 38; enabled: sshKeyField.text.trim().length > 20 && remote.busy === ""
                         onClicked: remote.addKey(sshKeyField.text) }
            ]
        }
        Dialog {        // Updates: confirm restarting now, or turning automatic updates off
            open: updates.ask !== null
            modal: true
            title: updates.ask ? updates.ask.title : ""
            message: updates.ask ? updates.ask.message : ""
            onDismissed: updates.ask = null
            buttons: [
                Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: updates.ask = null },
                Button { text: updates.ask ? updates.ask.button : ""; variant: "primary"; tone: updates.ask && updates.ask.danger ? Theme.danger : Theme.accent; size: 38; onClicked: updates.confirm() }
            ]
        }
        Dialog {        // Snapshots: confirm a restore, starting one once, deleting, turning automatic snapshots off
            open: snaps.ask !== null
            modal: true
            title: snaps.ask ? snaps.ask.title : ""
            message: snaps.ask ? snaps.ask.message : ""
            onDismissed: snaps.ask = null
            buttons: [
                Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: snaps.ask = null },
                Button { text: snaps.ask ? snaps.ask.button : ""; variant: "primary"; tone: snaps.ask && snaps.ask.danger ? Theme.danger : Theme.accent; size: 38; onClicked: snaps.confirm() }
            ]
        }
        Dialog {        // Firewall › Advanced: allow a port or range on home networks
            id: fwPortDialog
            open: fw.portFormOpen
            modal: true
            title: "Allow a port or range"
            message: "Devices on your home networks can connect to this port. Public networks stay closed."
            function submit() { if (fwPortForm.valid) fw.submitPort(fwPortForm.spec()) }
            onDismissed: fw.portFormOpen = false
            onOpenChanged: if (open) { fwPortForm.reset(); fwPortForm.focusFirst() }
            FirewallPortForm { id: fwPortForm; width: parent.width; networks: Fw.homeOffers(fw.st); onSubmitted: fwPortDialog.submit() }
            buttons: [
                Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: fw.portFormOpen = false },
                Button { text: "Allow"; variant: "primary"; size: 38; enabled: fwPortForm.valid; onClicked: fwPortDialog.submit() }
            ]
        }
        Dialog {        // Firewall › Advanced: a home network's router VPN (its devices count as home devices)
            id: fwVpnDialog
            open: fw.vpnFor !== ""
            modal: true
            title: "Router VPN" + (fw.vpnHome ? " for " + fw.vpnHome.name : "")
            message: Fw.vpnMessage(fw.vpnHome)
            property bool touched: false
            readonly property string error: Fw.vpnError(fwVpnField.text)
            function submit() { if (error === "") fw.submitVpn(Fw.vpnParse(fwVpnField.text)) }
            onDismissed: fw.vpnFor = ""
            onOpenChanged: if (open) {
                fwVpnField.text = ((fw.vpnHome && fw.vpnHome.vpn) || []).join(", ")
                touched = false
                fwVpnField.focusInput()
            }
            Column {
                width: parent.width
                spacing: 10
                TextField {
                    id: fwVpnField
                    width: parent.width
                    glyph: Icons.lock
                    mono: true
                    placeholder: "The VPN's range, e.g. 192.168.3.0/24"
                    error: fwVpnDialog.touched && fwVpnDialog.error !== ""
                    onEdited: fwVpnDialog.touched = true
                    onAccepted: fwVpnDialog.submit()
                }
                Text {
                    width: parent.width
                    wrapMode: Text.Wrap
                    text: fwVpnDialog.touched && fwVpnDialog.error !== "" ? fwVpnDialog.error
                        : "Leave it empty to stop trusting this router's VPN."
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(12)
                    color: fwVpnDialog.touched && fwVpnDialog.error !== "" ? Theme.danger : Theme.textDim
                }
            }
            buttons: [
                Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: fw.vpnFor = "" },
                Button { text: "Save"; variant: "primary"; size: 38; enabled: fwVpnDialog.error === ""; onClicked: fwVpnDialog.submit() }
            ]
        }
        Dialog {        // Firewall › Advanced: what the firewall stopped since this PC started
            open: fw.recentOpen
            title: "Recently blocked"
            message: "Connections from other devices that the firewall stopped. Kept in memory only, until you restart."
            cardWidth: 480
            onDismissed: fw.recentOpen = false
            BlockedList { width: parent.width; entries: fw.recent; clock24: Settings.clock24 }
            buttons: [ Button { text: "Close"; variant: "outline"; size: 38; onClicked: fw.recentOpen = false } ]
        }
        Dialog {        // Drivers & Hardware: confirm a driver install/removal
            open: hardware.ask !== null
            modal: true
            title: hardware.ask ? hardware.ask.title : ""
            message: hardware.ask ? hardware.ask.message : ""
            onDismissed: hardware.ask = null
            buttons: [
                Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: hardware.ask = null },
                Button { text: hardware.ask ? hardware.ask.button : ""; variant: "primary"; size: 38; onClicked: hardware.confirm() }
            ]
        }
        Dialog {
            open: hardware.restartPending
            modal: true
            title: "Restart to finish?"
            message: "The driver change takes effect after a restart. Save your work in other apps first."
            onDismissed: hardware.restartPending = false
            buttons: [
                Button { text: "Later"; variant: "outline"; size: 38; onClicked: hardware.restartPending = false },
                Button { text: "Restart now"; variant: "primary"; size: 38; onClicked: Platform.power("reboot") }
            ]
        }
        Dialog {        // Companies & Profiles: add a company, rename one, or set its git identity
            id: companyForm
            readonly property var f: companyAdmin.form
            readonly property bool isGit: !!f && f.kind === "git"
            property string color: ""
            open: f !== null
            modal: true
            title: !f ? "" : f.kind === "add" ? "Add a company" : f.kind === "rename" ? "Rename the company" : "Git identity"
            message: !f ? "" : f.kind === "add"
                ? "It gets its own account on this PC: its own network and localhost, home folder, dev tools, keys, sign-ins and desktop." + (Platform.live ? " In the live session it's gone after a restart." : "")
                : isGit ? "Used for the commits you make in this company." : ""
            onDismissed: companyAdmin.form = null
            onOpenChanged: if (open) { coName.text = f.name || ""; coEmail.text = f.email || ""; color = f.color || ""; coName.focusInput() }
            Column {
                width: parent.width
                spacing: 10
                TextField { id: coName; width: parent.width; placeholder: companyForm.isGit ? "Your name" : "Company name" }
                TextField { id: coEmail; width: parent.width; visible: companyForm.isGit; placeholder: "you@company.com" }
                Row {
                    visible: !!companyForm.f && companyForm.f.kind === "add"
                    spacing: 10
                    Repeater {
                        model: Theme.accents
                        delegate: Pressable {
                            required property var modelData
                            width: 30; height: 30; radius: 15
                            color: modelData.color
                            borderWidth: 2
                            borderColor: companyForm.color === modelData.color ? Theme.text : "transparent"
                            hoverBorderColor: Theme.text3
                            accessibleName: modelData.name
                            onClicked: companyForm.color = modelData.color
                        }
                    }
                }
            }
            buttons: [
                Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: companyAdmin.form = null },
                Button {
                    text: !companyForm.f ? "" : companyForm.f.kind === "add" ? "Add company" : companyForm.isGit ? "Save" : "Rename"
                    variant: "primary"; size: 38
                    enabled: coName.text.trim().length > 0 && coName.text.trim().length <= 64
                             && (!companyForm.isGit || /^[^@\s]+@[^@\s]+$/.test(coEmail.text.trim()))
                    onClicked: companyAdmin.submitForm(coName.text.trim(), coEmail.text.trim(), companyForm.color)
                }
            ]
        }
        Dialog {        // Companies & Profiles: confirm deleting a company
            open: companyAdmin.ask !== null
            modal: true
            title: companyAdmin.ask ? companyAdmin.ask.title : ""
            message: companyAdmin.ask ? companyAdmin.ask.message : ""
            onDismissed: companyAdmin.ask = null
            buttons: [
                Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: companyAdmin.ask = null },
                Button { text: companyAdmin.ask ? companyAdmin.ask.button : ""; variant: "primary"; tone: Theme.danger; size: 38; onClicked: companyAdmin.confirm() }
            ]
        }
        Dialog {        // Users & Accounts: add a person, your name, your password, someone else's password
            id: userDialog
            readonly property var f: userAdmin.form
            open: f !== null
            modal: true
            title: !f ? "" : f.kind === "add" ? "Add a user" : f.kind === "rename" ? "Your name"
                 : f.kind === "password" ? "Change your password" : "New password for " + f.display
            message: !f ? "" : f.kind === "add" ? "They sign in with their own password and get their own desktop." : ""
            onDismissed: userAdmin.closeForm()
            onOpenChanged: {
                if (open) { userForm.reset(f.kind === "rename" ? f.value : ""); userForm.focusFirst() }
                else userForm.clearSecrets()
            }
            UserForm {
                id: userForm
                kind: userDialog.f ? userDialog.f.kind : "add"
                display: userDialog.f && userDialog.f.display ? userDialog.f.display : ""
                taken: userAdmin.takenNames
                error: userAdmin.formError
                busy: userAdmin.formBusy
                onSubmitted: userAdmin.submitForm(userForm.spec())
            }
            buttons: [
                Button { text: "Cancel"; variant: "outline"; size: 38; enabled: !userAdmin.formBusy; onClicked: userAdmin.closeForm() },
                Button {
                    text: !userDialog.f ? "" : userDialog.f.kind === "add" ? "Add user" : userDialog.f.kind === "rename" ? "Save" : "Change password"
                    variant: "primary"; size: 38
                    busy: userAdmin.formBusy
                    enabled: userForm.valid
                    onClicked: userForm.submitIfValid()
                }
            ]
        }
        Dialog {        // Users & Accounts: confirm removing someone
            open: userAdmin.ask !== null
            modal: true
            title: userAdmin.ask ? userAdmin.ask.title : ""
            message: userAdmin.ask ? userAdmin.ask.message : ""
            onDismissed: userAdmin.ask = null
            buttons: [
                Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: userAdmin.ask = null },
                Button { text: userAdmin.ask ? userAdmin.ask.button : ""; variant: "primary"; tone: Theme.danger; size: 38; onClicked: userAdmin.confirm() }
            ]
        }
        Dialog {        // Quasar AI: an API key (password field, sent to quasar-ai on stdin) or another model's name
            id: aiForm
            readonly property var f: ai.form
            readonly property bool isKey: !!f && f.kind === "key"
            open: f !== null
            modal: true
            title: f ? f.title : ""
            message: f ? f.message : ""
            onDismissed: ai.form = null
            onOpenChanged: if (open) { aiField.text = ""; aiField.focusInput() } else aiField.text = ""
            TextField {
                id: aiField
                width: parent.width
                password: aiForm.isKey
                mono: true
                placeholder: aiForm.f ? aiForm.f.placeholder : ""
                onAccepted: if (aiSave.enabled) ai.submitForm(aiField.text)
            }
            buttons: [
                Button { text: "Remove key"; variant: "outline"; tone: Theme.danger; size: 38; visible: aiForm.isKey && !!aiForm.f.canRemove; onClicked: ai.removeKey() },
                Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: ai.form = null },
                Button {
                    id: aiSave
                    text: aiForm.isKey ? "Check and save" : "Download"; variant: "primary"; size: 38
                    enabled: aiForm.isKey ? /^\S{8,4096}$/.test(aiField.text.trim()) : /^[A-Za-z0-9][A-Za-z0-9._\/:-]{0,199}$/.test(aiField.text.trim())
                    onClicked: ai.submitForm(aiField.text)
                }
            ]
        }
        Dialog {        // Quasar AI: confirm removing the engine or a model
            open: ai.ask !== null
            modal: true
            title: ai.ask ? ai.ask.title : ""
            message: ai.ask ? ai.ask.message : ""
            onDismissed: ai.ask = null
            buttons: [
                Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: ai.ask = null },
                Repeater {
                    model: ai.ask ? ai.ask.buttons : []
                    delegate: Button {
                        required property var modelData
                        text: modelData.text; size: 38
                        variant: modelData.primary || modelData.danger ? "primary" : "outline"
                        tone: modelData.danger ? Theme.danger : Theme.accent
                        onClicked: ai.answer(modelData.key)
                    }
                }
            ]
        }
        Dialog {
            open: displays.pending
            modal: true
            title: "Keep these display settings?"
            message: "Reverting in " + displays.countdown + " seconds."
            buttons: [
                Button { text: "Revert"; variant: "outline"; size: 38; onClicked: displays.revert() },
                Button { text: "Keep"; variant: "primary"; size: 38; onClicked: displays.keep() }
            ]
        }
    }

    IpcHandler {
        target: "app"
        function open(arg: string): void { app.go(arg); win.visible = true }
    }
}
