import QtQuick
import Qt.labs.folderlistmodel
import Quickshell
import Quickshell.Io
import Quasar
import Quasar.Services

// The sidebar's places and devices, shared by every Files window.
//   places: Home, then the user folders from ~/.config/user-dirs.dirs (Desktop, Documents, Downloads,
//   Pictures, Music, Videos; each only while it exists), Projects when ~/Projects exists, and Trash.
//   devices: drives mounted under /media/$USER or /run/media/$USER.
//   rootFree / rootTotal: how full the system drive is ("This PC"), refreshed after file jobs.
Scope {
    id: root
    required property var ops
    property string home: Quickshell.env("HOME") || "/root"
    readonly property string user: Quickshell.env("USER") || FileKit.baseName(home)
    readonly property string trashFiles: (Quickshell.env("XDG_DATA_HOME") || home + "/.local/share") + "/Trash/files"
    property real rootFree: -1
    property real rootTotal: -1

    // ---- user folders ------------------------------------------------------------------------------
    property var dirs: ({})                    // DESKTOP, DOCUMENTS, … -> path
    function dirOf(key, fallback) { return dirs[key] || (home + "/" + fallback) }
    FileView {
        path: (Quickshell.env("XDG_CONFIG_HOME") || root.home + "/.config") + "/user-dirs.dirs"
        blockLoading: true
        printErrors: false
        watchChanges: true
        onFileChanged: reload()
        onLoaded: {
            const out = {}
            text().split("\n").forEach(l => {
                const m = /^\s*XDG_([A-Z]+)_DIR\s*=\s*"(.*)"\s*$/.exec(l)
                if (m) out[m[1]] = m[2].replace(/^\$HOME(?=\/|$)/, root.home)
            })
            root.dirs = out
        }
    }
    // Which folders are there (a place shows only while its folder exists).
    FolderListModel {
        id: homeList
        folder: Theme.fileUrl(root.home)
        showFiles: false
        showHidden: false
        showDotAndDotDot: false
    }
    readonly property var homeNames: {
        const n = homeList.count            // re-evaluated as folders come and go
        const out = {}
        if (decodeURIComponent(String(homeList.folder)) !== decodeURIComponent(Theme.fileUrl(home))) return out
        for (let i = 0; i < n; i++) out[homeList.get(i, "fileName")] = true
        return out
    }
    function present(path) {
        // Folders right in home are checked against its listing; others are taken as there.
        if (FileKit.parentOf(path) === home) return homeNames[FileKit.baseName(path)] === true
        return true
    }
    readonly property var places: {
        const list = [
            { label: "Desktop", path: dirOf("DESKTOP", "Desktop"), glyph: Icons.monitor },
            { label: "Documents", path: dirOf("DOCUMENTS", "Documents"), glyph: Icons.notes },
            { label: "Downloads", path: dirOf("DOWNLOAD", "Downloads"), glyph: Icons.download },
            { label: "Pictures", path: dirOf("PICTURES", "Pictures"), glyph: Icons.image },
            { label: "Music", path: dirOf("MUSIC", "Music"), glyph: Icons.music },
            { label: "Videos", path: dirOf("VIDEOS", "Videos"), glyph: Icons.video },
            { label: "Projects", path: home + "/Projects", glyph: Icons.code }
        ].filter(p => p.path !== home && present(p.path))
        return [{ label: "Home", path: home, glyph: Icons.home }].concat(list, [{ label: "Trash", path: trashFiles, glyph: Icons.trash }])
    }

    // ---- drives ------------------------------------------------------------------------------------
    component Mounts: FolderListModel {
        property string base: ""
        folder: Theme.fileUrl(base)
        showFiles: false
        showHidden: false
        showDotAndDotDot: false
        function list() {
            if (decodeURIComponent(String(folder)) !== decodeURIComponent(Theme.fileUrl(base))) return []
            const out = []
            for (let i = 0; i < count; i++) out.push({ label: get(i, "fileName"), path: get(i, "filePath") })
            return out
        }
    }
    Mounts { id: media; base: "/media/" + root.user }
    Mounts { id: runMedia; base: "/run/media/" + root.user }
    readonly property var mounted: media.count >= 0 && runMedia.count >= 0 ? media.list().concat(runMedia.list()) : []

    // USB sticks and SD cards, mounted or not, from UDisks2 (/usr/libexec/quasar/drives watch: it
    // tells us about every change, nothing is polled). Without it (no UDisks2, the nested test
    // session) the folders under /media/$USER stand in. QUASAR_DRIVES points at another helper (tests).
    readonly property string drivesHelper: Quickshell.env("QUASAR_DRIVES") || "/usr/libexec/quasar/drives"
    property var drives: []
    property bool drivesOk: false
    property var busyDrives: ({})              // device -> "mounting" | "ejecting"
    readonly property var devices: drivesOk
        ? drives.map(d => ({ label: d.label, path: d.path, device: d.device, mounted: d.path !== "",
                             ejectable: d.ejectable, busy: busyDrives[d.device] || "" }))
        : mounted.map(m => ({ label: m.label, path: m.path, device: "", mounted: true, ejectable: false, busy: "" }))
    Process {
        id: watcher
        command: [root.drivesHelper, "watch"]
        running: true
        stdinEnabled: true                     // the helper exits when this closes (Files quit)
        stdout: SplitParser {
            onRead: (l) => {
                let o = null
                try { o = JSON.parse(l) } catch (e) { return }
                if (o.drives) { root.drives = o.drives; root.drivesOk = true }
            }
        }
        onExited: (code) => {
            root.drivesOk = false
            if (code !== 3 && code !== 64) rewatch.start()      // 3: no UDisks2 here
        }
    }
    Timer { id: rewatch; interval: 5000; onTriggered: watcher.running = true }

    Component { id: driveCmd; Cmd { } }
    function _drive(verb, device, busy, done) {
        const c = driveCmd.createObject(root)
        let out = null, err = ""
        busyDrives = Object.assign({}, busyDrives, { [device]: busy })
        c.line.connect((l) => { try { const o = JSON.parse(l); if (o.error) err = o.error; else out = o } catch (e) { } })
        c.finished.connect((code) => {
            const next = Object.assign({}, root.busyDrives)
            delete next[device]
            root.busyDrives = next
            if (done) done(code === 0 ? out : null, err || (code === 0 ? "" : "The drive didn't answer"))
            c.destroy()
        })
        c.run([drivesHelper, verb, device])
    }
    // done(result, error): result {path} after a mount, {ejected, label} after an eject.
    function mount(device, done) { _drive("mount", device, "mounting", done) }
    function eject(device, done) { _drive("eject", device, "ejecting", done) }

    // ---- This PC -----------------------------------------------------------------------------------
    function refreshUsage() {
        ops.run(["info", "/"], null, (code, err, lines) => {
            const o = lines[0]
            if (o && o.total) { root.rootFree = o.free; root.rootTotal = o.total }
        })
    }
    Timer { id: usageSoon; interval: 500; onTriggered: root.refreshUsage() }
    Connections { target: root.ops; function onJobDone() { usageSoon.restart() } }
    Component.onCompleted: refreshUsage()
}
