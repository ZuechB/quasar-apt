import QtQuick

// Numbered steps with a live console (template Sites › deploy): a card of 24px circles that go
// number -> spinner -> check, the running row tinted with the accent, and an optional console
// underneath (#06070B, JetBrains Mono 11.5px, newest line at the bottom, at most 150px tall).
//   steps:   ["Copy the project", "Install packages", …]
//   current: index of the running step (steps before it are done); steps.length = all done
//   failed:  true when `current` stopped with an error (its circle turns red)
//   lines:   console lines: strings, or { t: "text", c: color }; "$ cmd" lines are drawn brighter
Rectangle {
    id: root
    property var steps: []
    property int current: -1
    property bool failed: false
    property var lines: []
    property bool showConsole: lines.length > 0
    property real consoleHeight: 150

    implicitWidth: 520
    implicitHeight: col.implicitHeight
    radius: 18
    color: Theme.white(0.035)
    border.width: 1; border.color: Theme.white(0.06)
    clip: true

    Column {
        id: col
        width: parent.width

        Repeater {
            model: root.steps
            delegate: Rectangle {
                id: stepRow
                required property int index
                required property var modelData
                readonly property bool done: index < root.current
                readonly property bool running: index === root.current && !root.failed
                readonly property bool broke: index === root.current && root.failed
                width: col.width
                height: 44
                color: running ? Theme.alpha(Theme.accent, 0.06) : broke ? Theme.alpha(Theme.danger, 0.06) : "transparent"
                Behavior on color { ColorAnimation { duration: Motion.dur(300) } }
                Accessible.role: Accessible.StaticText
                Accessible.name: String(modelData) + (done ? ", done" : running ? ", running" : broke ? ", failed" : "")

                Rectangle {
                    visible: stepRow.index > 0
                    anchors { left: parent.left; right: parent.right; top: parent.top }
                    height: 1; color: Theme.white(0.05)
                }
                Rectangle {
                    id: circle
                    anchors { left: parent.left; leftMargin: 14; verticalCenter: parent.verticalCenter }
                    width: 24; height: 24; radius: 12
                    border.width: 1.5
                    border.color: stepRow.broke ? Theme.danger : (stepRow.done || stepRow.running) ? Theme.accent : Theme.white(0.18)
                    color: stepRow.done ? Theme.accent : stepRow.broke ? Theme.alpha(Theme.danger, 0.15) : "transparent"
                    Behavior on color { ColorAnimation { duration: Motion.dur(Motion.pop) } }
                    Text {
                        anchors.centerIn: parent
                        visible: !stepRow.done && !stepRow.running && !stepRow.broke
                        text: stepRow.index + 1
                        font.family: Theme.fontUi; font.pixelSize: 11; font.weight: Font.DemiBold
                        color: Theme.textMuted
                    }
                    Spinner {
                        anchors.centerIn: parent
                        visible: stepRow.running
                        size: 13; color: Theme.accent
                    }
                    QIcon {
                        anchors.centerIn: parent
                        visible: stepRow.done || stepRow.broke
                        path: stepRow.broke ? Icons.x : Icons.check
                        size: 13; strokeWidth: 3
                        color: stepRow.broke ? Theme.danger : Theme.accentInk
                    }
                }
                Text {
                    anchors { left: circle.right; leftMargin: 12; right: parent.right; rightMargin: 14; verticalCenter: parent.verticalCenter }
                    text: String(stepRow.modelData)
                    textFormat: Text.PlainText
                    elide: Text.ElideRight
                    font.family: Theme.fontUi; font.pixelSize: 13; font.weight: Font.DemiBold
                    color: (stepRow.done || stepRow.running || stepRow.broke) ? Theme.text : Theme.textMuted
                }
            }
        }

        Rectangle {
            visible: root.showConsole
            width: col.width
            height: Math.min(root.consoleHeight, consoleList.contentHeight + 20)
            color: "#06070B"
            Rectangle { anchors { left: parent.left; right: parent.right; top: parent.top } height: 1; color: Theme.white(0.06) }
            ListView {
                id: consoleList
                anchors { fill: parent; leftMargin: 14; rightMargin: 14; topMargin: 10; bottomMargin: 10 }
                clip: true
                model: root.lines
                boundsBehavior: Flickable.StopAtBounds
                onCountChanged: Qt.callLater(positionViewAtEnd)
                delegate: Text {
                    required property var modelData
                    width: consoleList.width
                    readonly property string line: typeof modelData === "string" ? modelData : (modelData.t || "")
                    text: line
                    textFormat: Text.PlainText
                    wrapMode: Text.WrapAnywhere
                    font.family: Theme.fontMono; font.pointSize: Theme.pt(11.5)
                    lineHeight: 1.25
                    color: typeof modelData === "object" && modelData.c ? modelData.c
                         : line.startsWith("$ ") ? Theme.text : Theme.textMuted
                }
            }
        }
    }
}
