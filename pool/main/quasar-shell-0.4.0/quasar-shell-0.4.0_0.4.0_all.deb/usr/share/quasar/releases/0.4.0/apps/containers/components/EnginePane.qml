import QtQuick
import Quasar

// What the Containers window shows when Docker isn't running or reachable: not installed (Get it
// from the Store), no access yet (log out and in, or give access), stopped (Start), starting, or a
// problem (details + Try again).
Item {
    id: root
    property string engine: "starting"
    property string error: ""
    property bool busy: false
    property var banner: null
    property string company: ""           // the company that is shown (company environments), else ""
    signal action(string action)          // get | access | start | retry | companySetup
    signal bannerAction()

    readonly property var info: ({
        // In a company: Docker is that company's own rootless engine, in its account and network.
        companyOff: { glyph: Icons.layers, title: "Docker isn't on for " + company + " yet", button: "Turn on Docker", act: "companySetup",
                      text: company + " gets its own Docker engine in its own account. Its containers, images and published ports "
                          + "(localhost:5432 and so on) stay inside " + company + " and never clash with another company's." },
        companyNoRootless: { glyph: Icons.download, title: "Docker needs an update for companies", button: "Open the Store", act: "get",
                      text: "Companies use Docker's rootless engine, which this Docker install doesn't have yet. Update Docker from the Store." },
        settingUp:  { glyph: Icons.layers, title: "Setting up Docker for " + company + "…", button: "", act: "",
                      text: "It runs in " + company + "'s account; this takes a few seconds." },
        missing:  { glyph: Icons.download, title: "Docker isn't installed", button: "Get Docker", act: "get",
                    text: "Get Docker from the Store to build and run containers. Everything you run shows up here, and you can use docker in a terminal too." },
        noAccess: { glyph: Icons.lock, title: "Your account can't use Docker yet", button: "Give access", act: "access",
                    text: "If you installed Docker a moment ago, log out and back in. Or give your account access now (an administrator's password is needed)." },
        stopped:  { glyph: Icons.power, title: "Docker is stopped", button: "Start Docker", act: "start",
                    text: "Start it to see your containers. It also starts by itself the next time something uses it." },
        starting: { glyph: Icons.layers, title: "Starting Docker…", button: "", act: "",
                    text: "This takes a few seconds the first time after the PC starts." },
        stopping: { glyph: Icons.power, title: "Stopping Docker…", button: "", act: "",
                    text: "Running containers stop too. Docker starts again the next time something uses it." },
        error:    { glyph: Icons.alert, title: "Docker has a problem", button: "Try again", act: "retry",
                    text: "It didn't answer the way it should. The details below show what it reported." }
    })
    readonly property var cur: info[engine] || info.starting

    Column {
        anchors.centerIn: parent
        width: Math.min(460, parent.width - 48)
        spacing: 14

        Banner {
            visible: !!root.banner
            width: parent.width
            tone: root.banner ? (root.banner.tone || "error") : "error"
            title: root.banner ? root.banner.title || "" : ""
            message: root.banner ? root.banner.message || "" : ""
            details: root.banner ? root.banner.details || "" : ""
            actionText: root.banner ? root.banner.actionText || "" : ""
            onActionClicked: root.bannerAction()
        }
        Rectangle {
            anchors.horizontalCenter: parent.horizontalCenter
            width: 72; height: 72; radius: 22
            color: Theme.alpha("#7AB8FF", 0.14)
            readonly property bool waiting: root.engine === "starting" || root.engine === "stopping" || root.engine === "settingUp"
            QIcon { visible: !parent.waiting; anchors.centerIn: parent; path: root.cur.glyph; size: 32; strokeWidth: 1.8; color: "#7AB8FF" }
            Spinner { visible: parent.waiting; anchors.centerIn: parent; size: 28; color: "#7AB8FF" }
        }
        Text {
            width: parent.width
            horizontalAlignment: Text.AlignHCenter
            text: root.cur.title
            font.family: Theme.fontDisplay; font.pixelSize: 22; font.weight: Font.Medium
            color: Theme.text
        }
        Text {
            width: parent.width
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.Wrap
            lineHeight: 1.25
            text: root.cur.text
            font.family: Theme.fontUi; font.pointSize: Theme.pt(14)
            color: Theme.textMuted
        }
        Button {
            visible: root.cur.button !== ""
            anchors.horizontalCenter: parent.horizontalCenter
            text: root.cur.button
            busy: root.busy
            enabled: !root.busy
            variant: "primary"; size: 42
            onClicked: root.action(root.cur.act)
        }
        Rectangle {
            visible: root.engine === "error" && root.error !== ""
            width: parent.width
            height: Math.min(160, errText.implicitHeight + 24)
            radius: 12
            color: Theme.white(0.04)
            border.width: 1; border.color: Theme.white(0.06)
            clip: true
            Text {
                id: errText
                x: 12; y: 12
                width: parent.width - 24
                wrapMode: Text.WrapAnywhere
                text: root.error
                font.family: Theme.fontMono; font.pointSize: Theme.pt(11.5)
                color: Theme.textDim
            }
        }
    }
}
