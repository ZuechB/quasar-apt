import QtQuick
import Qt.labs.folderlistmodel
import Quasar

// "Choose a file" (Settings › VPN › Add a VPN: a .conf or .ovpn file) or, with `folders`, "choose a
// folder" (Sites › New site › Browse…) as a list. Places (Downloads first, then Desktop, Documents, Home,
// and Drives while one is mounted; `placeList` replaces them) and the path above the list, like
// PhotoChooser. Click a folder to open it and a file to pick it; double-click a file, or the main button,
// to use it. In folder mode files are shown dimmed (you can see what's in the folder) and the main button
// uses the folder you're in. Pure Qt (FolderListModel), so the preview can browse a real folder.
Dialog {
    id: root
    property string home: "/home/you"
    property string drives: ""                 // /media/<user>; offered while something is mounted there
    property string folder: home + "/Downloads"
    property var nameFilters: ["*"]
    property bool folders: false               // choose the folder you're in, not a file
    property var placeList: null               // [{label, path, glyph}] instead of the default places
    property var allowFolder: (path) => true   // folder mode: whether the main button may use this folder
    property string kindText: "files"          // "No <kindText> here"
    property string chooseText: "Choose"       // file mode; folder mode says Use “<folder name>”
    property string picked: ""
    signal chosen(string path)

    title: folders ? "Choose a folder" : "Choose a file"
    cardWidth: 620
    onOpenChanged: if (open) picked = ""
    function go(path) { if (path && path !== folder) { folder = path; picked = "" } }

    readonly property string folderName: folder === "/" ? "/" : folder.slice(folder.lastIndexOf("/") + 1)
    readonly property bool canChoose: folders ? !!files && root.allowFolder(folder) : picked !== ""

    readonly property var places: (placeList || [
        { label: "Downloads", path: home + "/Downloads", glyph: Icons.download },
        { label: "Desktop", path: home + "/Desktop", glyph: Icons.monitor },
        { label: "Documents", path: home + "/Documents", glyph: Icons.file },
        { label: "Home", path: home, glyph: Icons.home }
    ]).concat(hasDrives ? [{ label: "Drives", path: drives, glyph: Icons.drive }] : [])
    readonly property string place: {
        let best = ""
        for (const p of places)
            if ((folder === p.path || folder.startsWith(p.path + "/")) && p.path.length > best.length) best = p.path
        return best
    }
    readonly property var crumbs: {
        const f = folder
        let base = "", label = "Computer"
        if (f === home || f.startsWith(home + "/")) { base = home; label = "Home" }
        else if (drives && (f === drives || f.startsWith(drives + "/"))) { base = drives; label = "Drives" }
        const out = [{ label: label, path: base || "/" }]
        let p = base
        f.slice(base.length).split("/").filter(s => s !== "").forEach(s => { p += "/" + s; out.push({ label: s, path: p }) })
        return out.length > 4 ? [{ label: "…", path: out[out.length - 4].path }].concat(out.slice(-3)) : out
    }
    readonly property string parentFolder: {
        const i = folder.lastIndexOf("/")
        return i > 0 ? folder.slice(0, i) : (folder.length > 1 && folder.startsWith("/") ? "/" : "")
    }

    // A FolderListModel made with a missing folder lists the working directory instead: a listing only
    // counts while it really is the folder asked for (CLAUDE.md, QML gotchas).
    FolderListModel {
        id: fileList
        folder: Theme.fileUrl(root.folder)
        nameFilters: root.nameFilters
        caseSensitive: false
        showDirsFirst: true
        showDotAndDotDot: false
        showHidden: false
        sortField: FolderListModel.Name
        sortCaseSensitive: false
    }
    FolderListModel {
        id: driveList
        folder: Theme.fileUrl(root.visible && root.drives ? root.drives : root.home)
        showFiles: false
        showDotAndDotDot: false
    }
    function listing(m, path) {
        try { return !!path && decodeURIComponent(String(m.folder)) === decodeURIComponent(Theme.fileUrl(path)) }
        catch (e) { return false }
    }
    readonly property var files: listing(fileList, folder) ? fileList : null
    readonly property bool hasDrives: visible && listing(driveList, drives) && driveList.count > 0

    Column {
        width: parent.width
        spacing: 10

        Flow {
            width: parent.width
            spacing: 6
            Repeater {
                model: root.places
                Button {
                    required property var modelData
                    text: modelData.label
                    glyph: modelData.glyph
                    size: 30
                    variant: root.place === modelData.path ? "soft" : "ghost"
                    fg: root.place === modelData.path ? Theme.text : Theme.text3
                    onClicked: root.go(modelData.path)
                }
            }
        }

        Row {
            width: parent.width
            height: 30
            spacing: 4
            Button {
                glyph: Icons.up
                size: 30
                variant: "ghost"
                accessibleName: "Up one folder"
                enabled: root.parentFolder !== ""
                onClicked: root.go(root.parentFolder)
            }
            Repeater {
                model: root.crumbs
                Row {
                    id: crumb
                    required property var modelData
                    required property int index
                    readonly property bool last: index === root.crumbs.length - 1
                    height: 30
                    spacing: 4
                    QIcon {
                        visible: crumb.index > 0
                        anchors.verticalCenter: parent.verticalCenter
                        path: Icons.fwd; size: 12; strokeWidth: 2; color: Theme.textFaint
                    }
                    Pressable {
                        anchors.verticalCenter: parent.verticalCenter
                        width: Math.min(crumbText.implicitWidth, 200) + 12; height: 26
                        radius: 8
                        kind: "hov"
                        enabled: !crumb.last
                        cursorShape: crumb.last ? Qt.ArrowCursor : Qt.PointingHandCursor
                        accessibleName: crumb.modelData.label
                        onClicked: root.go(crumb.modelData.path)
                        Text {
                            id: crumbText
                            x: 6; width: Math.min(implicitWidth, 200)
                            anchors.verticalCenter: parent.verticalCenter
                            elide: Text.ElideMiddle
                            text: crumb.modelData.label
                            font.family: Theme.fontUi; font.pixelSize: 13
                            font.weight: crumb.last ? Font.DemiBold : Font.Normal
                            color: crumb.last ? Theme.text : Theme.textMuted
                        }
                    }
                }
            }
        }

        Item {
            width: parent.width
            height: Math.max(180, Math.min(320, root.height - 300))
            Rectangle { anchors.fill: parent; radius: 14; color: Theme.white(0.025); border.width: 1; border.color: Theme.white(0.06) }
            ListView {
                id: list
                anchors.fill: parent
                anchors.margins: 6
                clip: true
                boundsBehavior: Flickable.StopAtBounds
                model: root.visible ? root.files : null
                Connections { target: root; function onFolderChanged() { list.positionViewAtBeginning() } }
                delegate: Item {
                    id: rowItem
                    required property string fileName
                    required property string filePath
                    required property bool fileIsDir
                    required property var fileModified
                    readonly property bool sel: root.picked === filePath
                    readonly property bool inert: root.folders && !fileIsDir     // folder mode: files are only shown
                    width: list.width; height: 40
                    Pressable {
                        anchors.fill: parent
                        anchors.margins: 2
                        radius: 10
                        kind: "plain"
                        enabled: !rowItem.inert
                        opacity: rowItem.inert ? 0.45 : 1
                        color: rowItem.sel ? Theme.accentTint : "transparent"
                        hoverColor: rowItem.sel ? Theme.accentTint : Theme.white(0.05)
                        borderWidth: 1.5
                        borderColor: rowItem.sel ? Theme.accent : "transparent"
                        hoverBorderColor: rowItem.sel ? Theme.accent : "transparent"
                        accessibleName: rowItem.fileName
                        Accessible.role: rowItem.fileIsDir ? Accessible.Button : Accessible.RadioButton
                        Accessible.checked: rowItem.sel
                        onClicked: { if (rowItem.fileIsDir) root.go(rowItem.filePath); else if (!root.folders) root.picked = rowItem.filePath }
                        onDoubleClicked: if (!rowItem.fileIsDir && !root.folders) root.chosen(rowItem.filePath)
                        QIcon {
                            x: 10
                            anchors.verticalCenter: parent.verticalCenter
                            path: rowItem.fileIsDir ? Icons.folder : Icons.file
                            size: 18; strokeWidth: 1.8
                            color: rowItem.fileIsDir ? "#7AB8FF" : Theme.text3
                        }
                        Text {
                            x: 38
                            width: parent.width - 38 - dateText.width - 20
                            anchors.verticalCenter: parent.verticalCenter
                            elide: Text.ElideMiddle
                            text: rowItem.fileName
                            font.family: Theme.fontUi; font.pixelSize: 13
                            color: rowItem.sel ? Theme.text : Theme.text2
                        }
                        Text {
                            id: dateText
                            anchors { right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter }
                            visible: !rowItem.fileIsDir
                            text: rowItem.fileModified ? Qt.formatDate(rowItem.fileModified, "d MMM yyyy") : ""
                            font.family: Theme.fontUi; font.pointSize: Theme.pt(12)
                            color: Theme.textDim
                        }
                    }
                }
            }
            Column {
                anchors.centerIn: parent
                visible: !root.files || (root.files.count === 0 && root.files.status !== FolderListModel.Loading)
                spacing: 8
                QIcon { anchors.horizontalCenter: parent.horizontalCenter; path: root.folders ? Icons.folder : Icons.file; size: 26; color: Theme.textFaint }
                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    text: root.folders ? "This folder is empty" : "No " + root.kindText + " here"
                    font.family: Theme.fontUi; font.pixelSize: 14; font.weight: Font.Medium
                    color: Theme.text3
                }
                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    visible: !root.folders
                    text: "Try Downloads, or the folder you saved it in"
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
                    color: Theme.textDim
                }
            }
        }
    }

    buttons: [
        Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: root.dismissed() },
        Button {
            // Folder mode names the folder it will use ("Use “my-site”"), or asks for one while the folder
            // you're in can't be used (allowFolder: Home itself, say).
            text: !root.folders ? root.chooseText
                : !root.allowFolder(root.folder) ? "Open a folder"
                : "Use “" + (root.folderName.length > 28 ? root.folderName.slice(0, 27) + "…" : root.folderName) + "”"
            variant: "primary"; size: 38
            enabled: root.canChoose
            onClicked: root.chosen(root.folders ? root.folder : root.picked)
        }
    ]
}
