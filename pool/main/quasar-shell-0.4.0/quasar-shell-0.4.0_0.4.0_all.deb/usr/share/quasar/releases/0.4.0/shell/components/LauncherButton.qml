import QtQuick
import QtQuick.Shapes
import Quasar

// Taskbar launcher button: the Quasar mark on a 44px chip. Pure view.
// Hover puts a faint wash under the mark (the mockup's chip brightened over it) and wakes the mark; a
// press sinks the chip; while the launcher is open the mark is ignited and lights the chip from its core.
Pressable {
    id: root
    property bool open: false
    // The pointer state the visuals follow (bound to the mouse; previews set them).
    property bool hot: hovered
    property bool down: pressed

    width: 44; height: 44; radius: 13
    kind: "plain"
    accessibleName: "Launcher and search"

    Item {
        anchors.fill: parent
        scale: root.down ? 0.9 : 1
        Behavior on scale { NumberAnimation { duration: Motion.dur(Motion.press); easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.spring } }

        Rectangle {
            anchors.fill: parent
            radius: root.radius
            color: Theme.white(0.07)
            opacity: root.hot && !root.open ? 1 : 0
            Behavior on opacity { NumberAnimation { duration: Motion.dur(Motion.hover) } }
        }

        // open: accent light from the center, brighter while hovered
        Shape {
            anchors.fill: parent
            opacity: root.open ? (root.hot ? 1 : 0.85) : 0
            Behavior on opacity { NumberAnimation { duration: Motion.dur(260) } }
            preferredRendererType: Shape.CurveRenderer
            ShapePath {
                strokeColor: Theme.alpha(Theme.accent, 0.30)
                strokeWidth: 1
                fillGradient: RadialGradient {
                    centerX: 22; centerY: 22; centerRadius: 31
                    focalX: 22; focalY: 22
                    GradientStop { position: 0.0; color: Theme.alpha(Theme.accent, 0.30) }
                    GradientStop { position: 0.6; color: Theme.alpha(Theme.accent, 0.12) }
                    GradientStop { position: 1.0; color: Theme.alpha(Theme.accent, 0.06) }
                }
                PathRectangle { x: 0.5; y: 0.5; width: 43; height: 43; radius: root.radius - 0.5 }
            }
        }

        QuasarMark {
            anchors.centerIn: parent
            size: 28
            hovered: root.hot
            active: root.open
        }
    }
}
