import QtQuick
import Quickshell.Io

// A long-running sites-query follow (metrics -f, logs -f, follow ID RUN): one parsed JSON object per
// event. Runs while `active` is true; changing `cmd` restarts it. Managed imperatively (no binding
// on `running`, which restarting would break).
Process {
    id: stream
    property var cmd: []
    property bool active: false
    signal event(var ev)
    signal ended(int code)

    function _sync() {
        if (running) running = false
        if (active && cmd && cmd.length > 0) {
            command = cmd
            Qt.callLater(() => { if (stream.active && stream.cmd.length > 0 && !stream.running) stream.running = true })
        }
    }
    onActiveChanged: _sync()
    onCmdChanged: _sync()
    Component.onCompleted: _sync()

    stdout: SplitParser {
        onRead: (l) => {
            if (l.charAt(0) !== "{") return
            try { stream.event(JSON.parse(l)) } catch (e) { }
        }
    }
    onExited: (code) => stream.ended(code)
}
