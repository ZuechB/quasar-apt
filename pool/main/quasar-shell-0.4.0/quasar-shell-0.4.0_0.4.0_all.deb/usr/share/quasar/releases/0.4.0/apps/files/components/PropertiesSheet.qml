import QtQuick
import Quasar

// Properties of the selected items, or of the folder shown: what it is, how big (folders are added
// up while the sheet is open, so a big one counts up in front of you), where it is, when it last
// changed, who owns it and what you may do with it. Several items: how many, their total size and
// where they are. Data from `fileop props` (items, then running totals).
Dialog {
    id: root
    property var items: []                 // fileop props "item" objects
    property real size: 0
    property int files: 0
    property int folders: 0
    property bool counting: false          // folders are still being added up
    property bool clock24: false
    property string home: ""

    readonly property var one: items.length === 1 ? items[0] : null
    function plain(path) { return home && FileKit.within(path, home) ? "~" + path.slice(home.length) : path }
    function bytes(n) {
        const exact = Number(n).toLocaleString(Qt.locale(), "f", 0)
        return n < 1000 ? FileKit.formatSize(n) : FileKit.formatSize(n) + " (" + exact + " bytes)"
    }
    function when(ms) {
        return ms ? Qt.formatDateTime(new Date(ms), clock24 ? "MMMM d, yyyy, HH:mm" : "MMMM d, yyyy, h:mm AP") : ""
    }
    function count(n, word) { return Number(n).toLocaleString(Qt.locale(), "f", 0) + " " + word + (n === 1 ? "" : "s") }
    readonly property bool anyDir: items.some(i => i.isDir)
    readonly property string sizeText: {
        if (!items.length) return ""
        let s = bytes(size)
        if (anyDir) s += " · " + count(files, "file") + ", " + count(folders, "folder")
        return counting ? s + " so far…" : s
    }
    readonly property var rows: {
        if (!items.length) return []
        if (!one) {
            const parents = items.map(i => i.parent)
            const same = parents.every(p => p === parents[0])
            const dirs = items.filter(i => i.isDir).length
            return [
                { label: "Items", value: (items.length - dirs ? count(items.length - dirs, "file") : "") + (dirs && items.length - dirs ? ", " : "") + (dirs ? count(dirs, "folder") : "") },
                { label: "Size", value: sizeText },
                { label: "Location", value: same ? plain(parents[0]) : "Several folders" }
            ]
        }
        const out = [
            { label: "Kind", value: (one.isDir ? "Folder" : one.kind ? one.kind.charAt(0).toUpperCase() + one.kind.slice(1) : "File")
                                    + (one.mime && !one.isDir ? " (" + one.mime + ")" : "") },
            { label: "Size", value: sizeText },
            { label: "Location", value: plain(one.parent) }
        ]
        if (one.link) out.push({ label: "Points to", value: plain(one.link) })
        out.push({ label: "Modified", value: when(one.mtime) },
                 { label: "Owner", value: one.owner },
                 { label: "You can", value: one.writable ? (one.isDir ? "Open it and change what's in it" : "Open and change it")
                                                         : one.readable ? (one.isDir ? "Only look inside" : "Only open it") : "Not open it" },
                 { label: "Permissions", value: one.perms + (one.executable ? " (runs as a program)" : ""), mono: true })
        return out
    }

    title: one ? one.name : items.length ? count(items.length, "item") : ""
    cardWidth: 480

    Column {
        width: parent.width
        spacing: 2
        Repeater {
            model: root.rows
            delegate: Item {
                required property var modelData
                width: parent.width
                height: Math.max(26, value.implicitHeight + 8)
                Text {
                    width: 108
                    y: 4
                    text: modelData.label
                    font.family: Theme.fontUi; font.pixelSize: 13
                    color: Theme.textDim
                }
                Text {
                    id: value
                    x: 116; y: 4
                    width: parent.width - x
                    wrapMode: Text.WrapAnywhere
                    text: modelData.value
                    textFormat: Text.PlainText
                    font.family: modelData.mono ? Theme.fontMono : Theme.fontUi
                    font.pixelSize: modelData.mono ? 12 : 13
                    color: Theme.text2
                }
            }
        }
    }
    buttons: [ Button { text: "Close"; variant: "soft"; onClicked: root.dismissed() } ]
}
