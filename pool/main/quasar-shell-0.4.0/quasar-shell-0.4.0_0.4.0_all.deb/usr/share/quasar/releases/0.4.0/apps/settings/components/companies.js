// Settings > Companies & Profiles: page rows for the company environments. Each company is a hidden
// account with its own network (its own localhost), home folder, dev tools, keys and desktop.
// Pure, so the Settings app (services/CompanyAdmin.qml) and the design preview share it.
//   list: Companies.list  [{ id, name, short, color, wallpaper, home, personal, autostart }]
//   ctx:  { state(id) -> "running" | "starting" | "stopped" | "failed", failed: { id: text },
//           info: { id: { git, ssh, tools, size } }, busy: row key, live, docker (installed),
//           azure: (space) -> Azure Pipelines agents here (optional), icons, theme }
.pragma library

var COLOURS = [["#7AE7FF", "Ice"], ["#B9A4FF", "Violet"], ["#FFB86B", "Amber"], ["#8CF5B0", "Mint"], ["#FF8FB1", "Rose"]]
var WALLPAPERS = [["deep", "Deep field"], ["aurora", "Aurora"], ["graphite", "Graphite"]]

function size(b) {
    return b >= 1e9 ? (b / 1e9).toFixed(1) + " GB" : b >= 1e6 ? Math.round(b / 1e6) + " MB" : b > 0 ? "under 1 MB" : ""
}
function colourName(c) {
    var hit = COLOURS.filter(function (x) { return x[0].toLowerCase() === String(c).toLowerCase() })[0]
    return hit ? hit[1] : String(c)
}
function wallpaperName(k) {
    var hit = WALLPAPERS.filter(function (x) { return x[0] === k })[0]
    return hit ? hit[1] : k
}

// "co:<id>:<what>" -> { id, what }
function parseKey(key) {
    var m = /^co:([a-z][a-z0-9-]{0,21}|personal):([a-z]+)$/.exec(key || "")
    return m ? { id: m[1], what: m[2] } : null
}

function azureRow(space, name, ctx) {
    var n = ctx.azure ? ctx.azure(space) : 0
    return { key: "co:" + space + ":azure", label: "Azure DevOps", glyph: ctx.icons.server, trailing: ctx.live ? "value" : "chevron",
             value: ctx.live ? "" : n ? (n === 1 ? "1 agent" : n + " agents") : "",
             sub: ctx.live ? "Installed PCs can run " + name + "'s pipelines" : n ? "Pipelines run on this PC as their own accounts"
                : "Run " + name + "'s pipelines on this PC: builds, tests, deployments" }
}

function groups(list, ctx) {
    var t = ctx.theme, icons = ctx.icons, out = []
    for (var i = 0; i < list.length; i++) {
        var c = list[i]
        if (c.personal) {
            out.push({ label: "Personal", rows: [
                { key: "co:personal:info", label: "Your own account", glyph: icons.user, trailing: "value", value: "",
                  sub: "What you open while Personal is shown runs here, on this PC's own network" },
                azureRow("personal", "Personal", ctx)] })
            continue
        }
        var st = ctx.state(c.id), running = st === "running", info = (ctx.info || {})[c.id] || {}
        var p = "co:" + c.id + ":"
        var later = running ? "" : "Start " + c.name + " to change this"
        out.push({ label: c.name, rows: [
            { key: p + "running", label: "Running", glyph: icons.bolt, trailing: "toggle", checked: running || st === "starting",
              busy: ctx.busy === p + "running",
              sub: st === "starting" ? "Starting…" : st === "failed" ? "Couldn't start: " + ((ctx.failed || {})[c.id] || "")
                 : running ? "Its programs keep running while another company is shown" : "Starts when you switch to it" },
            { key: p + "autostart", label: "Start when you sign in", glyph: icons.clock, trailing: "toggle", checked: !!c.autostart,
              sub: "Its databases and servers are ready before you switch to it" },
            { key: p + "env", label: "Environment", glyph: icons.shield, trailing: "value", value: "Isolated", valueColor: t.mint,
              sub: "Its own network and localhost: ports never clash with other companies" },
            { key: p + "home", label: "Home folder", glyph: icons.folder, trailing: "button", value: "Open",
              sub: c.home + (info.size ? "  ·  " + size(info.size) : "") },
            { key: p + "tools", label: "Developer tools", glyph: icons.code, trailing: "chevron", value: "",
              sub: info.tools || "Node.js, .NET, Python… installed for " + c.name + " only, from the Store" },
            { key: p + "docker", label: "Docker", glyph: icons.layers, trailing: "button", value: ctx.docker ? "Open" : "Get Docker",
              sub: ctx.docker ? c.name + "'s own engine: its containers, images and ports stay inside " + c.name
                              : "Install Docker from the Store, then turn it on for " + c.name },
            { key: p + "git", label: "Git identity", glyph: icons.branch, trailing: running ? "chevron" : "value", value: "",
              sub: info.git || later || "Not set" },
            { key: p + "ssh", label: "SSH key", glyph: icons.key, trailing: running ? "button" : "value",
              value: running ? "Copy public key" : "", busy: ctx.busy === p + "ssh",
              sub: info.ssh ? "id_ed25519, for " + c.name + " only" : later || "Made the first time you copy it" },
            { key: p + "terminal", label: "Terminal", glyph: icons.terminal, trailing: "button", value: "Open",
              sub: "A shell in " + c.name + "'s account and network" },
            azureRow(c.id, c.name, ctx),
            { key: p + "name", label: "Name", glyph: icons.pencil, trailing: "chevron", value: c.name },
            { key: p + "color", label: "Colour", glyph: icons.palette, trailing: "chevron", value: colourName(c.color) },
            { key: p + "wallpaper", label: "Wallpaper", glyph: icons.image, trailing: "chevron", value: wallpaperName(c.wallpaper) },
            { key: p + "delete", label: "Delete " + c.name, glyph: icons.trash, trailing: "button", value: "Delete…",
              busy: ctx.busy === p + "delete", sub: "Removes its account, files, keys and sign-ins from this PC" }
        ] })
    }
    out.push({ label: "Manage", rows: [
        { key: "co:add", label: "Add a company", glyph: icons.plus, trailing: "chevron", busy: ctx.busy === "co:add",
          sub: ctx.live ? "In the live session, companies are kept in memory and are gone after a restart"
                        : "A new account with its own network, home folder, keys and desktop" }] })
    return out
}

function hero(list, ctx) {
    var n = list.filter(function (c) { return !c.personal }).length
    return {
        glyph: ctx.icons.brief, iconFg: ctx.theme.mint,
        title: n ? (n === 1 ? "1 company on this PC" : n + " companies on this PC") : "One account per company",
        sub: "Each company runs as its own account: its own desktop, network and localhost (two companies can both use "
           + "port 3000), home folder, dev tools, keys and sign-ins. Store apps work in every company; only the "
           + "clipboard is shared.",
        button: "Add a company", buttonPrimary: true
    }
}
