//@ pragma AppId quasar-vault
// Quasar Vault — your saved passwords and passkeys, kept in your login keyring on this PC. Native Qt
// Quick app run by Quickshell (launched by /usr/bin/quasar-vault; Settings › Users & Accounts ›
// Passkeys and passwords opens it).   quasar-vault [passwords|passkeys|browsers]
// It opens locked: your account password (checked by vaultd with PAM) shows the lists, and it locks
// again when the window closes or sits unused for 5 minutes. Browsers reach Vault through
// /usr/libexec/quasar/vaultd daemon; the Browsers page sets them up.
import QtQuick
import Quickshell
import Quickshell.Io
import Quasar
import Quasar.Services
import "components"
import "services"

ShellRoot {
    id: app

    Binding { target: Theme; property: "accent"; value: Settings.accent }
    Binding { target: Theme; property: "reduceMotion"; value: Settings.reduceMotion }
    Binding { target: Theme; property: "softwareRender"; value: Platform.softwareScene }
    Binding { target: Theme; property: "profile"; value: Platform.softwareRender ? 0 : (Settings.profile >= 0 ? Settings.profile : 1) }

    property string page: "passwords"
    property string phase: "starting"
    property var banner: null
    property var data: ({ logins: [], passkeys: [], browsers: [], sites: [] })
    property var browsers: []
    property string selected: ""
    property var revealed: null
    property bool showPassword: false
    property bool busy: false
    property string unlockMessage: ""
    property string busyKey: ""
    function go(arg) {
        const a = (arg || "").trim()
        if (["passwords", "passkeys", "browsers"].indexOf(a) >= 0) page = a
    }
    Component.onCompleted: go(Quickshell.env("QUASAR_APP_ARGS"))

    VaultSession {
        id: vault
        onReady: app.status()
    }
    function status() {
        vault.request("status", {}, (r) => {
            if (!r.ok) { phase = "unavailable"; return }
            phase = r.live ? "live" : !r.available ? "unavailable" : r.verified ? "open" : "locked"
            if (phase === "open") refresh()
            if (phase === "locked") focusTimer.restart()
        })
    }
    function refresh() {
        vault.request("list", {}, (r) => {
            if (r.ok) data = r
            else if (r.code === "locked") lock()
            else banner = { tone: "error", title: r.error || "Vault didn't answer", message: "" }
        })
        vault.request("browsers", {}, (r) => { if (r.ok) browsers = r.browsers })
    }
    function unlock(password) {
        busy = true
        unlockMessage = ""
        vault.request("verify", { password: password }, (r) => {
            busy = false
            view.clearUnlock()
            if (r.ok) { phase = "open"; banner = null; refresh(); idle.restart() }
            else { unlockMessage = r.error || "That didn't work"; focusTimer.restart() }
        })
    }
    function lock() {
        vault.request("lock", {}, null)
        phase = "locked"; revealed = null; showPassword = false; selected = ""
        data = ({ logins: [], passkeys: [], browsers: [], sites: [] })
        focusTimer.restart()
    }
    function result(r, done) {
        if (r.ok) { if (done) done(r); return }
        if (r.code === "locked") { lock(); return }
        banner = { tone: "error", title: r.error || "That didn't work", message: "" }
    }
    // Locks itself after 5 minutes without a click or a key.
    Timer { id: idle; interval: 5 * 60 * 1000; onTriggered: if (app.phase === "open") app.lock() }
    Timer { id: focusTimer; interval: 60; onTriggered: if (app.phase === "locked") view.focusUnlock() }

    // ---- dialogs ----------------------------------------------------------------------------------
    property var form: null                  // { uuid?, title, url, username, password, notes }
    property var confirm: null               // { title, message, button, run }
    property string pathAsk: ""              // "import" | "export"

    IpcHandler {
        target: "app"
        function open(arg: string): void { app.go(arg); win.visible = true }
    }

    AppWindow {
        id: win
        appName: "vault"
        title: "Vault"
        glyph: Icons.shield
        glyphColor: "#FFD66B"
        defaultSize: Qt.size(760, 520)
        onVisibleChanged: if (!visible && app.phase === "open") app.lock()

        MouseArea {        // any activity keeps it open
            anchors.fill: parent
            acceptedButtons: Qt.NoButton
            hoverEnabled: true
            onPositionChanged: if (app.phase === "open") idle.restart()
        }
        VaultView {
            id: view
            anchors.fill: parent
            phase: app.phase
            page: app.page
            logins: app.data.logins || []
            passkeys: app.data.passkeys || []
            connected: app.data.browsers || []
            sites: app.data.sites || []
            browsers: app.browsers
            selected: app.selected
            revealed: app.revealed
            showPassword: app.showPassword
            busy: app.busy
            unlockMessage: app.unlockMessage
            busyKey: app.busyKey
            onUnlock: (pw) => app.unlock(pw)
            onLockNow: app.lock()
            onPagePicked: (p) => { app.page = p; app.selected = ""; app.revealed = null; app.showPassword = false; idle.restart() }
            onPicked: (u) => { app.selected = u; app.revealed = null; app.showPassword = false; idle.restart() }
            onReveal: (u) => vault.request("get", { uuid: u }, (r) => app.result(r, () => app.revealed = r.login))
            onCopy: (u, field) => vault.request("copy", { uuid: u, field: field }, (r) => app.result(r, () => {
                app.banner = { tone: "success", title: field === "password" ? "Password copied" : "Username copied",
                               message: field === "password" ? "It's cleared from the clipboard in " + r.seconds + " seconds." : "" }
                bannerTimer.restart()
            }))
            onOpenSite: (url) => Quickshell.execDetached(["xdg-open", url])
            onAddLogin: app.form = { title: "", url: "", username: "", password: "", notes: "" }
            onEditLogin: (u) => vault.request("get", { uuid: u }, (r) => app.result(r, () => app.form = r.login))
            onDeleteLogin: (u) => {
                const l = (app.data.logins || []).find(x => x.uuid === u)
                app.confirm = { title: "Delete this password?", message: (l ? (l.username || "Your login") + " for " + (l.title || l.site) : "It") + " is deleted from Vault.",
                                button: "Delete", run: () => vault.request("delete", { uuid: u }, (r) => app.result(r, () => { app.selected = ""; app.refresh() })) }
            }
            onDeletePasskey: (u) => {
                const p = (app.data.passkeys || []).find(x => x.uuid === u)
                app.confirm = { title: "Delete this passkey?", message: "You won't be able to sign in to " + (p ? p.rpId : "the site") + " with it any more. Make sure the site has another way in first.",
                                button: "Delete passkey", run: () => vault.request("delete-passkey", { uuid: u }, (r) => app.result(r, () => { app.selected = ""; app.refresh() })) }
            }
            onImportCsv: app.pathAsk = "import"
            onExportCsv: app.pathAsk = "export"
            onSetupBrowser: (id) => {
                app.busyKey = id
                vault.request("setup", { id: id }, (r) => {
                    app.busyKey = ""
                    app.result(r, () => {
                        app.refresh()
                        vault.request("store-page", { id: id }, null)
                        app.banner = { tone: "success", title: "Now add the extension",
                                       message: "Its page opens in the browser: add KeePassXC-Browser, then press Connect in its menu and type your password." }
                    })
                })
            }
            onStorePage: (id) => vault.request("store-page", { id: id }, null)
            onForgetBrowser: (id) => vault.request("forget-browser", { id: id }, (r) => app.result(r, () => app.refresh()))
            onForgetSite: (s) => vault.request("forget-site", { site: s }, (r) => app.result(r, () => app.refresh()))
        }
        Banner {
            anchors { left: parent.left; right: parent.right; bottom: parent.bottom; margins: 14 }
            visible: app.banner !== null
            tone: app.banner ? app.banner.tone : "info"
            title: app.banner ? app.banner.title : ""
            message: app.banner ? app.banner.message : ""
        }
        Timer { id: bannerTimer; interval: 4000; onTriggered: app.banner = null }

        Dialog {        // add or edit a password
            id: editDlg
            readonly property var f: app.form
            open: f !== null
            modal: true
            title: f && f.uuid ? "Edit password" : "Add a password"
            onOpenChanged: {
                if (open) { fTitle.text = f.title || ""; fUrl.text = f.url || ""; fUser.text = f.username || ""; fPass.text = f.password || ""; fNotes.text = f.notes || ""; fUrl.focusInput() }
                else { fPass.text = ""; fNotes.text = "" }
            }
            Column {
                width: parent.width
                spacing: 10
                TextField { id: fUrl; width: parent.width; glyph: Icons.globe; placeholder: "Website, e.g. github.com" }
                TextField { id: fTitle; width: parent.width; glyph: Icons.pencil; placeholder: "Name (optional)" }
                TextField { id: fUser; width: parent.width; glyph: Icons.user; placeholder: "Username or email" }
                Row {
                    width: parent.width
                    spacing: 8
                    TextField { id: fPass; width: parent.width - genBtn.width - 8; glyph: Icons.key; mono: true; placeholder: "Password" }
                    Button { id: genBtn; text: "Make one"; variant: "soft"; size: 38
                             onClicked: vault.request("generate", { length: 20 }, (r) => { if (r.ok) fPass.text = r.password }) }
                }
                TextField { id: fNotes; width: parent.width; glyph: Icons.notes; placeholder: "Notes (optional)" }
            }
            buttons: [
                Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: app.form = null },
                Button {
                    text: "Save"; variant: "primary"; size: 38
                    enabled: fPass.text !== "" && fUrl.text.trim() !== ""
                    onClicked: {
                        const f = app.form
                        vault.request("save", { uuid: f.uuid || "", url: fUrl.text.trim(), title: fTitle.text.trim(), username: fUser.text.trim(),
                                                password: fPass.text, notes: fNotes.text }, (r) => app.result(r, () => {
                            app.form = null; app.selected = r.uuid; app.revealed = null; app.refresh()
                        }))
                    }
                }
            ]
        }
        Dialog {        // confirmations
            open: app.confirm !== null
            modal: true
            title: app.confirm ? app.confirm.title : ""
            message: app.confirm ? app.confirm.message : ""
            onDismissed: app.confirm = null
            buttons: [
                Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: app.confirm = null },
                Button { text: app.confirm ? app.confirm.button : ""; variant: "primary"; tone: Theme.danger; size: 38
                         onClicked: { const c = app.confirm; app.confirm = null; if (c) c.run() } }
            ]
        }
        Dialog {        // import or export: a file in your home
            id: pathDlg
            open: app.pathAsk !== ""
            modal: true
            title: app.pathAsk === "import" ? "Import passwords" : "Export your passwords"
            message: app.pathAsk === "import"
                ? "Export a CSV file from your browser or password manager (Chrome, Brave, Firefox, Bitwarden, KeePassXC, 1Password), then give its place here. Delete the file afterwards: it isn't encrypted."
                : "This writes every password into a CSV file that ISN'T encrypted: anyone who gets the file can read them. Keep it somewhere safe and delete it when you're done."
            onOpenChanged: if (open) { pathField.text = app.pathAsk === "import" ? Platform.home + "/Downloads/" : Platform.home + "/Documents/vault-passwords.csv"; pathField.focusInput() }
            onDismissed: app.pathAsk = ""
            TextField { id: pathField; width: parent.width; glyph: Icons.file; mono: true; placeholder: "/home/you/Downloads/passwords.csv" }
            buttons: [
                Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: app.pathAsk = "" },
                Button {
                    text: app.pathAsk === "import" ? "Import" : "Export"; variant: "primary"; size: 38
                    tone: app.pathAsk === "export" ? Theme.danger : Theme.accent
                    enabled: /\.csv$/i.test(pathField.text.trim())
                    onClicked: {
                        const kind = app.pathAsk, path = pathField.text.trim()
                        app.pathAsk = ""
                        vault.request(kind, { path: path }, (r) => app.result(r, () => {
                            app.banner = { tone: "success", title: (kind === "import" ? "Imported " : "Exported ") + r.count + (r.count === 1 ? " password" : " passwords"),
                                           message: "Delete " + path + " when you're done: it isn't encrypted." }
                            app.refresh()
                        }))
                    }
                }
            ]
        }
    }
}
