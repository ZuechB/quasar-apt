import QtQuick
import Quickshell
import Quickshell.Io
import Quasar
import Quasar.Services

// Quasar AI in the shell: the assistant panel's state, and the tools that act on the desktop.
//   The model, the tool loop, files, commands and API keys live in /usr/libexec/quasar/quasar-ai serve
//   (linux/system/ai/quasar_ai/session.py; protocol there). It starts the first time the assistant is
//   used and exits after 10 idle minutes; nothing runs before that.
//   Here: apps and windows, settings, Store installs, Settings pages, the Terminal ("call" -> "result").
//   Where it runs, the model and the permission switches come from Settings.ai (Settings › Quasar AI).
//   QUASAR_AI=/path swaps the helper (tools/fake-ai.py in the nested-session tests).
Item {
    id: root
    visible: false

    property var appSvc: null                // services/Apps.qml (not `apps`: it would shadow the shell's id)
    property var sysSvc: null                // services/SystemControls.qml
    signal openSettings(string page)
    signal openTerminal(string dir)
    signal toast(var t)

    readonly property string helperPath: Quickshell.env("QUASAR_AI") || "/usr/libexec/quasar/quasar-ai"
    readonly property var ai: Settings.ai || ({})
    readonly property var names: ({ "ollama": "On-device", "ollama-cloud": "Ollama Cloud", "anthropic": "Claude", "openai": "ChatGPT" })
    readonly property var companies: ({ "ollama-cloud": "Ollama", "anthropic": "Anthropic", "openai": "OpenAI" })
    readonly property bool enabled: ai.enabled === true    // off until turned on in Settings › Quasar AI
    readonly property string provider: names[ai.provider] ? ai.provider : ""
    readonly property string model: provider ? ((ai.model || {})[provider] || "") : ""
    readonly property bool ready: enabled && provider !== "" && model !== ""
    readonly property bool cloud: provider !== "" && provider !== "ollama"
    readonly property string destination: names[provider] || "Not set up"
    readonly property string company: companies[provider] || ""

    // ---- panel state ------------------------------------------------------------------------------
    property bool open: false
    property bool busy: false
    property var steps: ({})                 // id -> { state, title, detail, tag, risk, tool, summary, lines }
    property int rev: 0
    property var planIds: []
    property string askId: ""
    property bool canUndo: false
    property string lastAsk: ""
    property int requestStart: 0             // first block of the current request
    readonly property alias blocks: blockModel
    ListModel { id: blockModel }

    readonly property var suggestions: [
        { label: "Clean up my Downloads folder", sub: "Sorts by type, archives old files", glyph: Icons.folder },
        { label: "Install a photo editor", sub: "Store, taskbar", glyph: Icons.download },
        { label: "What's using my disk space?", sub: "Storage, files", glyph: Icons.drive }
    ]

    function toggle() { open = !open; if (open && sysSvc) sysSvc.refresh() }
    function show(text) {
        open = true
        if (sysSvc) sysSvc.refresh()
        if (text) ask(text)
    }

    // ---- requests -----------------------------------------------------------------------------------
    function ask(text) {
        text = String(text || "").trim()
        if (!text || busy) return
        open = true
        if (!ready) return                      // the panel shows how to set it up
        lastAsk = text
        planIds = []
        askId = ""
        requestStart = blockModel.count
        _append("user", text)
        busy = true
        send({ type: "ask", text: text, config: config() })
    }
    function config() {
        const co = Companies.inCompany ? Companies.current : null
        return { provider: provider, model: model, perms: ai.perms || {}, plan: ai.plan !== false,
                 wrap: co ? Companies.wrapExec([]) : [], company: co ? co.name : "" }
    }
    function runPlan() { if (planIds.length) { send({ type: "run" }); planIds = [] } }
    function cancelPlan() { if (planIds.length) { send({ type: "cancel" }); planIds = [] } }
    function allow() { if (askId) { send({ type: "allow", id: askId }); askId = "" } }
    function deny() { if (askId) { send({ type: "deny", id: askId }); askId = "" } }
    function stop() { if (busy) send({ type: "stop" }) }
    function undo() { if (canUndo && !busy) { busy = true; send({ type: "undo" }) } }
    function retry() { if (lastAsk && !busy) ask(lastAsk) }
    function newTask() {
        if (busy) send({ type: "stop" })
        if (proc.running) send({ type: "reset" })
        blockModel.clear()
        steps = ({}); rev++
        planIds = []; askId = ""; canUndo = false; lastAsk = ""
    }

    // ---- the helper ---------------------------------------------------------------------------------
    property bool alive: false
    property var pending: []
    function send(o) {
        const line = JSON.stringify(o) + "\n"
        if (alive && proc.running) { proc.write(line); return }
        pending = pending.concat([line])
        if (!proc.running) {
            // Its own scope, so the Network monitor shows the assistant's cloud calls as "Quasar AI",
            // not as the shell (the same scopes the app launcher uses).
            proc.command = Quickshell.env("QUASAR_NO_SCOPES") === "1" ? [root.helperPath, "serve"]
                : ["systemd-run", "--user", "--scope", "--quiet", "--collect", "--slice=app.slice",
                   "--unit=app-quasar-quasar-ai-" + Date.now(), "--", root.helperPath, "serve"]
            proc.running = true
        }
    }
    Process {
        id: proc
        command: [root.helperPath, "serve"]
        stdinEnabled: true
        stdout: SplitParser { onRead: (l) => root.handle(l) }
        stderr: SplitParser { onRead: (l) => console.log("quasar-ai: " + l) }
        onExited: (code, status) => {
            const wasBusy = root.busy
            root.alive = false
            root.pending = []
            root.busy = false
            root.planIds = []
            root.askId = ""
            root.canUndo = false                 // its undo list went with it
            if (wasBusy) root._append("error", code === 127 || code === 126 ? "Quasar AI isn't installed on this PC." : "Quasar AI stopped unexpectedly. Try again.", "retry")
        }
    }

    function handle(line) {
        let e
        try { e = JSON.parse(line) } catch (x) { return }
        switch (e.type) {
        case "ready":
            alive = true
            for (const l of pending) proc.write(l)
            pending = []
            break
        case "busy": busy = !!e.on; break
        case "text": _text(e.delta || ""); break
        case "step": _step(e); break
        case "plan": planIds = e.ids || []; break
        case "ask": askId = e.id || ""; break
        case "call": _call(e); break
        case "line": _line(e.id, e.text); break
        case "done": _done(e); break
        case "undone":
            canUndo = false
            if (e.count || (e.failed || []).length) {
                _append("note", (e.failed || []).length ? "Undone, except: " + e.failed.join("; ") : "Changes undone.")
                root.toast({ title: "Changes undone", sub: (e.failed || []).length ? "Some couldn't be undone" : "Everything is back the way it was",
                             glyph: Icons.restore, hue: Theme.accent })
            }
            break
        case "error":
            if (e.code === "inflight") break        // an ask while the last one still runs: the panel shows that
            _append("error", e.message || "Something went wrong.", e.action || "", e.details || "")
            break
        }
    }

    function _append(kind, text, action, details) {
        blockModel.append({ kind: kind, text: text || "", ids: "", action: action || "", details: details || "" })
    }
    function _last() { return blockModel.count ? blockModel.get(blockModel.count - 1) : null }
    function _text(delta) {
        if (!delta) return
        const last = _last()
        if (last && last.kind === "text") blockModel.setProperty(blockModel.count - 1, "text", last.text + delta)
        else _append("text", delta.replace(/^\s+/, ""))
    }
    function _step(e) {
        const all = Object.assign({}, steps)
        const had = all[e.id]
        all[e.id] = Object.assign({}, had || {}, { state: e.state, title: e.title, detail: e.detail || "", tag: e.tag || "",
                                                   risk: e.risk || "", tool: e.tool || "", summary: e.summary || "" })
        steps = all
        rev++
        if (!had) {
            const last = _last()
            if (last && last.kind === "steps") blockModel.setProperty(blockModel.count - 1, "ids", last.ids + "," + e.id)
            else blockModel.append({ kind: "steps", text: "", ids: e.id, action: "", details: "" })
        }
        if (e.state === "running" && planIds.indexOf(e.id) >= 0) planIds = []
        if (e.state !== "asking" && askId === e.id) askId = ""
    }
    function _line(id, text) {
        const s = steps[id]
        if (!s) return
        const all = Object.assign({}, steps)
        all[id] = Object.assign({}, s, { lines: (s.lines || []).concat([String(text)]).slice(-200) })
        steps = all
        rev++
    }
    function _done(e) {
        planIds = []
        askId = ""
        canUndo = !!e.undoable
        if (e.stopped) { _append("note", "Stopped."); return }
        if (!e.changed) return
        let stepsSeen = false
        for (let i = requestStart; i < blockModel.count; i++) if (blockModel.get(i).kind === "steps") stepsSeen = true
        const last = _last()
        if (stepsSeen && last && last.kind === "text") blockModel.setProperty(blockModel.count - 1, "kind", "done")
        else _append("done", "Done.")
    }

    // ---- shell-side tools ---------------------------------------------------------------------------
    function _call(e) {
        const f = tools[e.tool]
        const reply = (r) => send({ type: "result", id: e.id, ok: r.ok !== false, output: r.output || "", summary: r.summary || "",
                                    undo: r.undo || [], changed: !!r.changed })
        if (!f) { reply({ ok: false, output: "That tool isn't available here." }); return }
        try {
            const r = f(e.args || {}, reply)
            if (r) reply(r)
        } catch (x) {
            reply({ ok: false, output: "It failed: " + x })
        }
    }
    function bool(v) { return v === true || v === 1 || /^(true|on|yes|1)$/i.test(String(v)) }
    function num(v, lo, hi) { const n = Math.round(Number(v)); return isNaN(n) ? NaN : Math.max(lo, Math.min(hi, n)) }
    function home(p) { const s = String(p || ""); return s === "~" ? Platform.home : s.startsWith("~/") ? Platform.home + s.slice(1) : s }

    // Windows get short ids ("w3") for the model; the list grows for the life of the shell.
    property var windowList: []
    function wid(t) {
        let i = windowList.indexOf(t)
        if (i < 0) { windowList.push(t); i = windowList.length - 1 }
        return "w" + (i + 1)
    }
    function win(id) {
        const t = windowList[parseInt(String(id).replace(/^w/, "")) - 1]
        return t && appSvc.toplevels.indexOf(t) >= 0 ? t : null
    }
    function findApp(name) {
        const n = String(name || "").trim()
        if (!n) return null
        const e = appSvc.byId(n) || appSvc.byId(n.replace(/\.desktop$/, ""))
                  || appSvc.listed.find(x => (x.name || "").toLowerCase() === n.toLowerCase())
        if (e) return e
        const hit = appSvc.search(n, 1)[0]
        return hit ? hit.entry : null
    }

    readonly property var accentNames: Theme.accents.map(a => a.name.toLowerCase())
    readonly property var settingsPages: [
        ["network", "Network & Internet", "wi-fi wifi internet ethernet proxy firewall"],
        ["vpn", "VPN", "vpn wireguard openvpn tunnel"],
        ["hotspot", "Mobile hotspot", "hotspot tethering share internet"],
        ["dns", "Encrypted DNS", "dns encrypted private secure quad9 cloudflare nextdns"],
        ["profiles", "Companies & Profiles", "company companies workspace profile environment"],
        ["bluetooth", "Bluetooth & Devices", "bluetooth pair headphones mouse keyboard controller"],
        ["drivers", "Drivers & Hardware", "drivers nvidia graphics gpu firmware hardware"],
        ["display", "Display", "screen resolution scale refresh rate night light wallpaper background monitor"],
        ["desktop", "Desktop", "desktop icons arrange grid tidy"],
        ["sound", "Sound", "sound audio volume speakers microphone output input"],
        ["appearance", "Appearance", "accent color colour theme transparency animations"],
        ["notifications", "Notifications", "notifications do not disturb focus"],
        ["privacy", "Privacy & Security", "privacy camera microphone location telemetry encryption sandbox"],
        ["ai", "Quasar AI", "ai assistant ollama claude chatgpt model api key"],
        ["apps", "Apps", "apps installed default startup flathub"],
        ["performance", "Performance", "performance lite balanced max speed"],
        ["storage", "Storage", "storage disk space clean up"],
        ["users", "Users & Accounts", "users accounts password"],
        ["input", "Keyboard & Input", "keyboard mouse touchpad pointer speed tap scrolling repeat shortcuts"],
        ["language", "Date & Language", "time zone date clock 24-hour language region"],
        ["updates", "Updates", "updates upgrade system"],
        ["about", "About", "about version system hostname name of this pc kernel memory processor"]
    ]

    function settingsNow() {
        const s = sysSvc
        const prof = Settings.profile < 0 ? "auto" : ["lite", "balanced", "max"][Settings.profile]
        const acc = Theme.accents.find(a => a.color.toLowerCase() === String(Settings.accent).toLowerCase())
        return "wifi: " + s.wifiOn + (s.wifiSsid ? " (connected to “" + s.wifiSsid + "”)" : "") + (s.wifiAvailable ? "" : " (no Wi-Fi adapter)")
             + "\nbluetooth: " + s.btOn + (s.btAvailable ? "" : " (no Bluetooth adapter)")
             + "\nairplane: " + s.airplane
             // Read only here: VPN, hotspot and Encrypted DNS are changed in their Settings pages.
             + "\nvpn: " + (NetState.vpnOn ? "connected to “" + NetState.vpnName + "”" : "off") + " (change it in Settings › VPN)"
             + "\nhotspot: " + (NetState.hotspotOn ? "on (“" + (NetState.hotspot.ssid || "") + "”)" : "off") + " (Settings › Mobile hotspot)"
             + "\nencryptedDns: " + (NetState.dnsOn ? "on, " + (NetState.dns.name || NetState.dns.provider) : "off") + " (Settings › Encrypted DNS)"
             + "\nvolume: " + Math.round(s.volume) + (s.audioAvailable ? "" : " (no sound output)")
             + "\nmute: " + s.muted
             + "\nbrightness: " + (s.brightnessAvailable ? Math.round(s.brightness) : "can't be changed on this screen")
             + "\nnightLight: " + Settings.nightLight + "\nfocus: " + Settings.focus + "\nprofile: " + prof
             + "\naccent: " + (acc ? acc.name.toLowerCase() : Settings.accent) + "\nwallpaper: " + Settings.wallpaper
             + (Settings.wallpaperPhoto && Settings.wallpaper !== "photo" ? " (the user's own picture is also available: photo)" : "")
             + "\ndesktopArrange: " + Settings.desktopArrange + "\nreduceMotion: " + Settings.reduceMotion
    }

    // set_setting: { key, value } -> result with the old value as the undo.
    function setSetting(key, value) {
        const s = sysSvc
        const fail = (m) => ({ ok: false, output: m })
        const done = (label, old) => ({ output: label, changed: true, undo: [{ tool: "set_setting", args: { key: key, value: old } }] })
        const b = bool(value)
        switch (key) {
        case "wifi":
            if (!s.wifiAvailable) return fail("This PC has no Wi-Fi adapter Quasar can use.")
            if (s.wifiHardBlocked) return fail("Wi-Fi is switched off with a hardware switch or key on this PC.")
            { const old = s.wifiOn; s.setWifi(b); return done("Wi-Fi is " + (b ? "on." : "off."), old) }
        case "bluetooth":
            if (!s.btAvailable) return fail("This PC has no Bluetooth adapter Quasar can use.")
            { const old = s.btOn; s.setBluetooth(b); return done("Bluetooth is " + (b ? "on." : "off."), old) }
        case "airplane":
            { const old = s.airplane; s.setAirplane(b); return done("Airplane mode is " + (b ? "on." : "off."), old) }
        case "volume": {
            const v = num(value, 0, 100)
            if (isNaN(v)) return fail("Volume must be a number from 0 to 100.")
            const old = Math.round(s.volume); s.setVolume(v); return done("Volume is " + v + "%.", old)
        }
        case "mute": {
            const old = s.muted
            Quickshell.execDetached(["wpctl", "set-mute", "@DEFAULT_AUDIO_SINK@", b ? "1" : "0"])
            s.muted = b
            return done(b ? "Sound is muted." : "Sound is on.", old)
        }
        case "brightness": {
            if (!s.brightnessAvailable) return fail("This screen's brightness can't be changed from Quasar (an external monitor uses its own buttons).")
            const v = num(value, 1, 100)
            if (isNaN(v)) return fail("Brightness must be a number from 1 to 100.")
            const old = Math.round(s.brightness); s.setBrightness(v); return done("Brightness is " + v + "%.", old)
        }
        case "nightLight": { const old = Settings.nightLight; Settings.nightLight = b; return done("Night light is " + (b ? "on." : "off."), old) }
        case "focus": { const old = Settings.focus; Settings.focus = b; return done(b ? "Focus is on: notifications are held." : "Focus is off.", old) }
        case "reduceMotion": { const old = Settings.reduceMotion; Settings.reduceMotion = b; return done("Animations are " + (b ? "reduced." : "on."), old) }
        case "profile": {
            const names = { lite: 0, balanced: 1, max: 2, auto: -1 }
            const v = String(value).toLowerCase()
            if (!(v in names)) return fail("profile must be lite, balanced or max.")
            const old = Settings.profile < 0 ? "auto" : ["lite", "balanced", "max"][Settings.profile]
            Settings.profile = names[v]
            return done("The performance profile is " + v + ".", old)
        }
        case "accent": {
            const v = String(value).toLowerCase()
            const a = Theme.accents.find(x => x.name.toLowerCase() === v || x.color.toLowerCase() === v)
            if (!a) return fail("accent must be one of: " + accentNames.join(", ") + ".")
            const old = Settings.accent
            Settings.accent = a.color
            return done("The accent color is " + a.name + ".", old)
        }
        case "wallpaper": {
            const v = String(value).toLowerCase()
            // "photo" = the user's own picture (chosen in Settings › Display), once there is one.
            const photo = v === "photo" && Settings.wallpaperPhoto !== ""
            if (["deep", "aurora", "graphite"].indexOf(v) < 0 && !photo)
                return fail("wallpaper must be deep, aurora or graphite" + (Settings.wallpaperPhoto ? ", or photo (the user's own picture)." : "."))
            const old = Settings.wallpaper; Settings.wallpaper = v; return done("The wallpaper is " + v + ".", old)
        }
        case "desktopArrange": {
            const v = String(value).toLowerCase()
            if (["grid", "free", "auto"].indexOf(v) < 0) return fail("desktopArrange must be grid, free or auto.")
            const old = Settings.desktopArrange; Settings.desktopArrange = v; return done("Desktop icons: " + v + ".", old)
        }
        }
        return fail("Quasar AI can't change “" + key + "”.")
    }

    readonly property var tools: ({
        search_apps: (a) => {
            const hits = appSvc.search(String(a.query || ""), 8)
            return { output: hits.length ? hits.map(h => h.name + " · id " + h.entry.id + (h.entry.comment ? " · " + h.entry.comment : "")).join("\n")
                                         : "No installed app matches “" + a.query + "”. It may be in the Store (search_store).",
                     summary: hits.length + " found" }
        },
        open_app: (a) => {
            const e = root.findApp(a.app)
            if (!e) return { ok: false, output: "No installed app called “" + a.app + "”. Search the Store for it." }
            appSvc.launch(e, (a.args || []).map(x => root.home(x)))
            return { output: "Opened " + e.name + "." }
        },
        list_windows: () => {
            const ts = appSvc.shown.filter(t => !t.parent)
            if (!ts.length) return { output: "No windows are open.", summary: "None open" }
            return { output: ts.map(t => root.wid(t) + " · " + (t.appId || "?") + " · “" + (t.title || "") + "”"
                                         + (t.activated ? " · focused" : "") + (t.minimized ? " · minimized" : "")).join("\n"),
                     summary: ts.length + " open" }
        },
        focus_window: (a) => {
            const t = root.win(a.window)
            if (!t) return { ok: false, output: "That window isn't open any more. List the windows again." }
            appSvc.focusWindow(t)
            return { output: "Brought “" + (t.title || t.appId) + "” to the front." }
        },
        minimize_window: (a) => {
            const t = root.win(a.window)
            if (!t) return { ok: false, output: "That window isn't open any more." }
            t.minimized = true
            return { output: "Minimized “" + (t.title || t.appId) + "”.", changed: true, undo: [{ tool: "restore_windows", args: { windows: [a.window] } }] }
        },
        close_window: (a) => {
            const t = root.win(a.window)
            if (!t) return { ok: false, output: "That window isn't open any more." }
            t.close()
            return { output: "Asked “" + (t.title || t.appId) + "” to close.", changed: true }
        },
        show_desktop: () => {
            const ts = appSvc.shown.filter(t => !t.minimized && !t.parent)
            const ids = ts.map(t => root.wid(t))
            ts.forEach(t => t.minimized = true)
            return { output: "Minimized " + ids.length + " windows.", changed: ids.length > 0,
                     undo: ids.length ? [{ tool: "restore_windows", args: { windows: ids } }] : [] }
        },
        restore_windows: (a) => {
            for (const id of a.windows || []) { const t = root.win(id); if (t) t.minimized = false }
            return { output: "Restored the windows." }
        },
        get_settings: () => ({ output: root.settingsNow() }),
        set_setting: (a) => root.setSetting(String(a.key), a.value),
        find_setting: (a) => {
            const words = String(a.query || "").toLowerCase().split(/\s+/).filter(w => w.length > 1)
            const hits = root.settingsPages.map(p => ({ p: p, n: words.filter(w => (p[1] + " " + p[2]).toLowerCase().includes(w)).length }))
                                           .filter(x => x.n > 0).sort((x, y) => y.n - x.n).slice(0, 3)
            return { output: hits.length ? hits.map(x => "Settings › " + x.p[1] + " (page " + x.p[0] + "): " + x.p[2]).join("\n")
                                         : "No Settings page matches. Pages: " + root.settingsPages.map(p => p[1]).join(", ") + "." }
        },
        open_settings: (a) => { root.openSettings(String(a.page || "")); return { output: "Opened Settings" + (a.page ? " at " + a.page : "") + "." } },
        open_terminal: (a) => { root.openTerminal(root.home(a.folder || "")); return { output: "Opened the Terminal" + (a.folder ? " in " + a.folder : "") + "." } },
        install_app: (a, reply) => { storeJob.begin("install", a, reply); return null },
        remove_app: (a, reply) => { storeJob.begin("remove", a, reply); return null }
    })

    // install_app / remove_app: the Store does the work (and shows it): open it at the app, hand it the job
    // over IPC once it is up, then follow the job state it publishes (apps/store/shell.qml).
    QtObject {
        id: storeJob
        property string verb: ""
        property var args: null
        property var reply: null
        property real since: 0
        property int tries: 0
        property string queued: ""
        function begin(v, a, r) {
            if (reply) { r({ ok: false, output: "Another Store job is still running." }); return }
            verb = v; args = a; reply = r; since = Date.now(); tries = 0; queued = ""
            root.appSvc.launchId("quasar-store", ["app:" + a.id])
            ipcTimer.restart()
        }
        function finish(res) {
            const r = reply
            reply = null
            ipcTimer.stop(); pollTimer.stop()
            if (r) r(res)
        }
        function name() { return args.name || args.id }
    }
    Timer { id: ipcTimer; interval: 700; onTriggered: { storeJob.tries++; storeIpc.running = true } }
    Process {
        id: storeIpc
        command: ["qs", "--path", "/usr/share/quasar/apps/store", "ipc", "call", "app", storeJob.verb || "install", String(storeJob.args ? storeJob.args.id : "")]
        stdout: StdioCollector { id: ipcOut }
        onExited: (code, status) => {
            if (!storeJob.reply) return
            const out = ipcOut.text.trim()
            if (code !== 0 || !out) {
                if (storeJob.tries < 40) ipcTimer.restart()
                else storeJob.finish({ ok: false, output: "The Store didn't start." })
                return
            }
            if (out === "unknown") storeJob.finish({ ok: false, output: "The Store has no app with the id " + storeJob.args.id + "." })
            else if (out === "refused") storeJob.finish({ ok: false, output: storeJob.name() + " needs Quasar installed on a disk; it can't be installed on the live USB." })
            else { storeJob.queued = out; pollTimer.restart() }
        }
    }
    Timer {
        id: pollTimer
        interval: 1000
        repeat: true
        property int ticks: 0
        onRunningChanged: if (running) ticks = 0
        onTriggered: { ticks++; jobsFile.reload(); if (ticks > 2700) storeJob.finish({ ok: false, output: "The Store job took longer than 45 minutes." }) }
    }
    FileView {
        id: jobsFile
        path: (Quickshell.env("XDG_RUNTIME_DIR") || "/tmp") + "/quasar-store-jobs.json"
        printErrors: false
        onLoaded: {
            if (!storeJob.reply) return
            let j
            try { j = JSON.parse(text()) } catch (x) { return }
            const r = (j.results || {})[storeJob.args.id]
            if (!r || r.at < storeJob.since) return
            const n = storeJob.name(), install = storeJob.verb === "install"
            if (r.ok) storeJob.finish({ output: (install ? "Installed " : "Removed ") + n + ".", changed: true,
                                         undo: [{ tool: install ? "remove_app" : "install_app", args: { id: storeJob.args.id, name: n } }] })
            else if (r.cancelled) storeJob.finish({ ok: false, output: "The user cancelled " + (install ? "installing " : "removing ") + n
                                                                       + " in the Store, so nothing changed. Don't try it again unless they ask." })
            else storeJob.finish({ ok: false, output: (install ? "Installing " : "Removing ") + n + " failed: " + (r.message || "see the Store") })
        }
    }
}
