import QtQuick

// App icon tile from the mockup: dark tile with a soft top sheen
// (linear-gradient(160deg, white .14 → white .02 @60%), #121522), hairline border, and an inset glow
// rising from the bottom in the app's hue (inset 0 -14px 22px -12px hue@.55).
// First-party apps pass `glyph` (Icons path); third-party apps pass `image` (theme icon file).
// `letter` is the fallback for apps with neither a glyph nor a loadable icon: a monogram in `hue`.
Item {
    id: root
    property real size: 50
    property real radius: Math.round(size * 0.3)
    property color hue: Theme.text
    property string glyph: ""
    property url image: ""
    property string letter: ""
    property real glyphSize: Math.round(size / 2)
    property real glyphStroke: 1.8
    property color base: Theme.tileBase
    property real sheen: 0.14
    property real borderAlpha: 0.10
    property real glow: 1.0
    // Under the software renderer, decode the icon at the size it's drawn instead of 2× (no smooth
    // scaling of every icon on every frame). For long scrolling lists (the Store's cards).
    property bool exactDecode: false

    implicitWidth: size
    implicitHeight: size

    Rectangle {
        anchors.fill: parent
        radius: root.radius
        color: root.base
    }
    Rectangle {
        anchors.fill: parent
        radius: root.radius
        gradient: Gradient {
            GradientStop { position: 0.0; color: Theme.white(root.sheen) }
            GradientStop { position: 0.6; color: Theme.white(0.02) }
            GradientStop { position: 1.0; color: Theme.white(0.02) }
        }
    }
    Rectangle {
        anchors.fill: parent
        radius: root.radius
        visible: root.glow > 0
        gradient: Gradient {
            GradientStop { position: 0.52; color: Theme.alpha(root.hue, 0) }
            GradientStop { position: 1.0; color: Theme.alpha(root.hue, 0.42 * root.glow) }
        }
    }
    Rectangle {
        anchors.fill: parent
        radius: root.radius
        color: "transparent"
        border.width: 1
        border.color: Theme.white(root.borderAlpha)
    }

    // Glyph (a Shape) and monogram are made only when shown: a tile with an image holds neither.
    Loader {
        anchors.centerIn: parent
        active: root.glyph !== "" && root.image.toString() === ""
        sourceComponent: QIcon {
            path: root.glyph
            size: root.glyphSize
            color: root.hue
            strokeWidth: root.glyphStroke
        }
    }
    Loader {
        anchors.centerIn: parent
        active: root.glyph === "" && root.letter !== "" && (root.image.toString() === "" || img.status === Image.Error)
        sourceComponent: Text {
            text: root.letter
            textFormat: Text.PlainText
            font.family: Theme.fontUi
            font.pixelSize: Math.round(root.size * 0.44)
            font.weight: Font.DemiBold
            color: root.hue
        }
    }
    Image {
        id: img
        readonly property bool exact: root.exactDecode && Theme.softwareRender
        anchors.centerIn: parent
        visible: root.image.toString() !== ""
        source: root.image
        width: Math.round(root.size * 0.62)
        height: width
        sourceSize: exact ? Qt.size(width, height) : Qt.size(width * 2, height * 2)
        asynchronous: true
        smooth: true
        mipmap: !exact
        fillMode: Image.PreserveAspectFit
    }
}
