import QtQuick
import Quickshell
import Quickshell.Wayland
import Quasar
import Quasar.Services
import "components"

// The company switcher's windows on the primary screen (company environments): the pill at the top
// right, which reserves the strip the template keeps above maximized windows; its menu; and the
// full-screen switch overlay. Only there once a company exists (and labwc runs: see CompanyDesk).
Scope {
    id: root
    property var desk: null
    property var ui: null
    property var screen: null
    signal manageRequested()

    readonly property bool shown: desk !== null && desk.showSwitcher
    readonly property bool menuOpen: ui !== null && ui.open === "companies"
    readonly property var cur: Companies.current
    readonly property bool anyAlert: Object.keys(Companies.alerts).some(k => Companies.alerts[k] > 0)
                                     || (desk !== null && desk.unplaced.length > 0)
    readonly property var rows: Companies.list.map(c => {
        const st = Companies.stateOf(c.id)
        const held = Companies.alerts[c.id] || 0
        const current = c.id === Companies.active
        let sub = "", subColor = ""
        if (current) sub = c.personal ? "Current  ·  your own account" : "Current"
        else if (c.personal) sub = "Your own account"
        else if (st === "starting") sub = "Starting…"
        else if (st === "failed") { sub = "Couldn't start: " + Companies.failed[c.id]; subColor = Theme.danger }
        else if (st === "running") sub = "Running"
        else sub = "Stopped  ·  starts when you switch"
        if (held && !current) { sub += "  ·  " + held + (held === 1 ? " new notification" : " new notifications"); subColor = Theme.amber }
        return { id: c.id, name: c.name, short: c.short, color: c.color, sub: sub, subColor: subColor,
                 current: current, alert: held > 0 && !current }
    })

    PanelWindow {
        screen: root.screen
        visible: root.shown
        anchors { top: true; left: true; right: true }
        implicitHeight: 54
        exclusiveZone: 54
        color: "transparent"
        WlrLayershell.layer: WlrLayer.Top
        WlrLayershell.namespace: "quasar-company-pill"
        WlrLayershell.keyboardFocus: WlrKeyboardFocus.None
        mask: Region { item: pill }

        CompanyPill {
            id: pill
            anchors.top: parent.top; anchors.topMargin: 8
            anchors.right: parent.right; anchors.rightMargin: 10
            name: root.cur.name
            initials: root.cur.short
            hue: root.cur.color
            alert: root.anyAlert
            open: root.menuOpen
            onClicked: root.ui.toggle("companies")
        }
    }

    // The menu takes the keyboard (Esc closes it): a popup of a no-focus layer surface gets no keys.
    PanelWindow {
        id: menuWin
        readonly property int sm: Theme.profile > 0 ? 24 : 0
        screen: root.screen
        visible: root.shown && root.menuOpen
        anchors { top: true; right: true }
        margins { top: Math.max(0, 54 - sm); right: 0 }
        implicitWidth: 336 + 10 + sm
        implicitHeight: switcher.implicitHeight + 2 * sm
        exclusionMode: ExclusionMode.Ignore
        color: "transparent"
        WlrLayershell.layer: WlrLayer.Overlay
        WlrLayershell.namespace: "quasar-company-menu"
        WlrLayershell.keyboardFocus: WlrKeyboardFocus.Exclusive
        mask: Region { item: switcher }

        Item {
            anchors.fill: parent
            focus: true
            Keys.onEscapePressed: root.ui.close()
            CompanySwitcher {
                id: switcher
                x: menuWin.sm; y: menuWin.sm
                width: 336; height: implicitHeight
                model: root.rows
                unplaced: root.desk ? root.desk.unplaced.length : 0
                wallpaperKind: Companies.wallpaper
                screenSize: Qt.size(root.screen ? root.screen.width : 1440, root.screen ? root.screen.height : 900)
                screenPos: Qt.point((root.screen ? root.screen.width : 1440) - 346, 54)
                onPicked: (id) => { root.ui.close(); root.desk.switchTo(id) }
                onManageClicked: { root.ui.close(); root.manageRequested() }
                onShowUnplacedClicked: { root.ui.close(); root.desk.showUnplaced() }
            }
        }
    }

    PanelWindow {
        screen: root.screen
        visible: root.desk !== null && root.desk.switching !== null
        anchors { top: true; bottom: true; left: true; right: true }
        exclusionMode: ExclusionMode.Ignore
        color: "transparent"
        WlrLayershell.layer: WlrLayer.Overlay
        WlrLayershell.namespace: "quasar-company-switch"
        WlrLayershell.keyboardFocus: WlrKeyboardFocus.None

        CompanySwitchOverlay {
            readonly property var s: root.desk ? root.desk.switching : null
            readonly property var to: s ? Companies.byId(s.to) : null
            anchors.fill: parent
            phase: s ? s.phase : ""
            name: to ? to.name : ""
            initials: to ? to.short : ""
            hue: to ? to.color : Theme.accent
            failed: !!(s && s.failed)
            sub: !s ? "" : s.failed ? "Couldn't start: " + s.failed
               : s.cold ? "Starting " + (to ? to.name : "") + "…" : "Its own desktop, network and sign-ins"
        }
    }
}
