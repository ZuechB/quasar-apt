import QtQuick

// The sign-in card shared by the sign-in screen (greeter/) and the lock screen (shell): the person's
// initials, their name, a password field with a round arrow, a message line (a wrong password, a
// PAM notice) and an optional text action underneath ("Sign out", "Someone else"). Pure: the host
// runs the authentication and sets `busy` / `message`.
Item {
    id: root
    property string name: ""                 // display name
    property string seed: ""                 // username: picks the avatar's hue
    property string sub: ""                  // e.g. "Locked" or "Administrator"
    property string placeholder: "Password"
    property bool echo: false                // a non-secret PAM prompt (shown as typed)
    property bool busy: false
    property bool allowEmpty: false          // an account without a password (the live session)
    property string message: ""
    property bool messageIsError: false
    property string actionText: ""
    property real avatarSize: 96
    signal submitted(string password)
    signal actionClicked()
    signal escapePressed()

    // A wrong-password message fades once the person starts typing again.
    property bool _stale: false
    onMessageChanged: _stale = false
    readonly property string shownMessage: _stale && messageIsError ? "" : message

    function focusInput() { field.focusInput() }
    function clear() { field.text = "" }
    function setText(t) { field.text = t }          // previews
    readonly property alias text: field.text

    implicitWidth: 340
    implicitHeight: col.implicitHeight

    Column {
        id: col
        width: parent.width
        spacing: 0

        UserAvatar {
            anchors.horizontalCenter: parent.horizontalCenter
            size: root.avatarSize
            name: root.name
            seed: root.seed
        }
        Item { width: 1; height: 18 }
        Text {
            width: parent.width
            horizontalAlignment: Text.AlignHCenter
            text: root.name
            elide: Text.ElideRight
            textFormat: Text.PlainText
            font.family: Theme.fontDisplay; font.pixelSize: 26; font.weight: Font.Medium
            color: Theme.text
        }
        Item { width: 1; height: root.sub !== "" ? 4 : 0 }
        Text {
            width: parent.width
            visible: root.sub !== ""
            horizontalAlignment: Text.AlignHCenter
            text: root.sub
            elide: Text.ElideRight
            textFormat: Text.PlainText
            font.family: Theme.fontUi; font.pointSize: Theme.pt(13)
            color: Theme.text3
        }
        Item { width: 1; height: 22 }
        Row {
            anchors.horizontalCenter: parent.horizontalCenter
            spacing: 8
            TextField {
                id: field
                width: Math.min(260, root.width - 58)
                height: 42
                glyph: Icons.lock
                placeholder: root.placeholder.replace(/:\s*$/, "")
                password: !root.echo
                error: root.messageIsError && root.shownMessage !== ""
                enabled: !root.busy
                onAccepted: if ((text !== "" || root.allowEmpty) && !root.busy) root.submitted(text)
                onEscapePressed: root.escapePressed()
                onEdited: root._stale = true
            }
            Button {
                width: 42
                size: 42
                pill: true
                variant: "primary"
                glyph: Icons.fwd
                busy: root.busy
                enabled: (field.text !== "" || root.allowEmpty) && !root.busy
                accessibleName: "Sign in"
                onClicked: root.submitted(field.text)
            }
        }
        Item { width: 1; height: 12 }
        Text {
            width: parent.width
            height: Math.max(implicitHeight, 18)
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.Wrap
            text: root.shownMessage
            textFormat: Text.PlainText
            font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
            color: root.messageIsError ? Theme.danger : Theme.textDim
            Accessible.role: Accessible.StaticText
            Accessible.name: text
        }
        Item { width: 1; height: root.actionText !== "" ? 10 : 0 }
        Pressable {
            anchors.horizontalCenter: parent.horizontalCenter
            visible: root.actionText !== ""
            kind: "hov"
            radius: 8
            implicitWidth: actionLabel.implicitWidth + 20
            implicitHeight: 30
            accessibleName: root.actionText
            onClicked: root.actionClicked()
            Text {
                id: actionLabel
                anchors.centerIn: parent
                text: root.actionText
                textFormat: Text.PlainText
                font.family: Theme.fontUi; font.pointSize: Theme.pt(13)
                color: Theme.text3
            }
        }
    }
}
