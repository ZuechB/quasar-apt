import QtQuick
import Quasar
import "runtime.js" as RT

// Template Sites › New site: pick a project (detected in the usual folders, chosen with Browse…, typed
// as a path, or the example page), check what Quasar found (runtime, build and run commands), choose the
// https://….localhost address and deploy. Adds a toolchain row when the project needs an SDK this
// account doesn't have yet.
Item {
    id: root
    property var projects: []          // sites-query scan
    property bool scanning: false
    property bool makingStarter: false     // the example page's folder is being made
    property var draft: null           // detection result + edits {id, path, kind, label, …, hostname}
    property bool detecting: false
    property string detectError: ""
    property var tools: ({})
    property var toolJob: ({ active: false, percent: 0, phase: "", error: "" })
    property bool deploying: false
    property var deploy: ({ steps: [], current: -1, failed: false, lines: [], message: "" })
    property string error: ""
    property string errorDetails: ""
    property string home: ""
    signal pick(string path)
    signal pathEdited(string path)
    signal browse()                    // open the folder chooser (SitesView owns it: it covers the window)
    signal starter()                   // the example page: ~/Sites/my-site with an index.html
    signal edited(string field, string value)
    signal installTool(string name, string spec)
    signal deploySite()
    signal cancel()

    readonly property var missing: RT.missingTool(draft, tools)
    readonly property bool ready: !!draft && !deploying && !missing && !toolJob.active
                                  && (draft.kind === "static" || (draft.run || "") !== "")
                                  && /^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)*\.localhost$/.test(draft.hostname || "")

    implicitHeight: col.implicitHeight

    component FieldLabel: Text {
        font.family: Theme.fontUi; font.pixelSize: 12
        color: Theme.textMuted
    }

    Column {
        id: col
        width: Math.min(parent.width, 760)
        spacing: 16

        Column {
            width: parent.width
            spacing: 6
            Text {
                text: "New site"
                font.family: Theme.fontDisplay; font.pixelSize: 26; font.weight: Font.Medium; font.letterSpacing: -0.4
                color: Theme.text
            }
            Text {
                width: parent.width
                text: "Pick a project. Quasar works out how to build and run it, gives it an HTTPS address and keeps it running."
                wrapMode: Text.WordWrap
                font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5); lineHeight: 1.15
                color: Theme.textMuted
            }
        }

        Column {
            width: parent.width
            spacing: 10
            SectionLabel { text: "Project" }
            Text {
                visible: root.scanning && root.projects.length === 0
                text: "Looking in your project folders…"
                font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5); color: Theme.textDim
            }
            Text {
                visible: !root.scanning && root.projects.length === 0
                width: parent.width
                wrapMode: Text.WordWrap
                text: "No projects found in ~/Sites, ~/Projects, ~/src or ~/code. Choose a folder below, or start with the example page."
                font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5); color: Theme.textDim
            }
            Flow {
                width: parent.width
                spacing: 10
                Repeater {
                    model: root.projects
                    delegate: Pressable {
                        id: card
                        required property var modelData
                        readonly property bool on: !!root.draft && root.draft.path === modelData.path
                        width: Math.floor((col.width - 20) / 3)
                        implicitHeight: 58
                        kind: "card"
                        radius: 14
                        enabled: !root.deploying
                        color: on ? Theme.alpha(Theme.accent, 0.07) : Theme.white(0.03)
                        borderColor: on ? Theme.accent : Theme.white(0.07)
                        hoverBorderColor: on ? Theme.accent : Theme.white(0.16)
                        accessibleName: modelData.id + ", " + modelData.label
                        Accessible.role: Accessible.RadioButton
                        Accessible.checked: on
                        onClicked: root.pick(modelData.path)
                        Rectangle {
                            id: ptile
                            x: 12; anchors.verticalCenter: parent.verticalCenter
                            width: 34; height: 34; radius: 10
                            color: Theme.white(0.05)
                            QIcon {
                                anchors.centerIn: parent
                                path: Icons.get(RT.kindGlyph(card.modelData.kind))
                                size: 17; color: card.on ? Theme.accent : Theme.textDim
                            }
                        }
                        Column {
                            anchors { left: ptile.right; leftMargin: 10; right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter }
                            spacing: 2
                            Text {
                                width: parent.width
                                text: card.modelData.id
                                textFormat: Text.PlainText
                                elide: Text.ElideRight
                                font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5); font.weight: Font.DemiBold
                                color: Theme.text
                            }
                            Text {
                                width: parent.width
                                text: card.modelData.label
                                elide: Text.ElideRight
                                font.family: Theme.fontUi; font.pixelSize: 12
                                color: Theme.textDim
                            }
                        }
                    }
                }
                // Always there: a ready static site to start from (or to make another one later).
                Pressable {
                    id: exampleCard
                    width: Math.floor((col.width - 20) / 3)
                    implicitHeight: 58
                    kind: "card"
                    radius: 14
                    enabled: !root.deploying && !root.makingStarter
                    color: Theme.alpha(Theme.accent, 0.03)
                    borderColor: Theme.alpha(Theme.accent, 0.22)
                    hoverBorderColor: Theme.alpha(Theme.accent, 0.45)
                    accessibleName: "Example page. A ready index.html you can edit"
                    onClicked: root.starter()
                    Rectangle {
                        id: etile
                        x: 12; anchors.verticalCenter: parent.verticalCenter
                        width: 34; height: 34; radius: 10
                        color: Theme.alpha(Theme.accent, 0.1)
                        Spinner { anchors.centerIn: parent; visible: root.makingStarter; size: 15 }
                        QIcon {
                            anchors.centerIn: parent
                            visible: !root.makingStarter
                            path: Icons.plus
                            size: 17; strokeWidth: 2; color: Theme.accent
                        }
                    }
                    Column {
                        anchors { left: etile.right; leftMargin: 10; right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter }
                        spacing: 2
                        Text {
                            width: parent.width
                            text: "Example page"
                            elide: Text.ElideRight
                            font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5); font.weight: Font.DemiBold
                            color: Theme.text
                        }
                        Text {
                            width: parent.width
                            text: "A ready index.html you can edit"
                            elide: Text.ElideRight
                            font.family: Theme.fontUi; font.pixelSize: 12
                            color: Theme.textDim
                        }
                    }
                }
            }
            Column {
                width: parent.width
                spacing: 6
                FieldLabel { text: "Project folder" }
                Row {
                    width: parent.width
                    spacing: 8
                    TextField {
                        id: pathField
                        width: parent.width - browseBtn.width - parent.spacing
                        mono: true
                        text: root.draft ? RT.shortHome(root.draft.path, root.home) : ""
                        placeholder: "~/Sites/my-site"
                        enabled: !root.deploying
                        Accessible.name: "Project folder"
                        onAccepted: { pathTimer.stop(); root.pathEdited(pathField.text) }
                        onEdited: (t) => pathTimer.restart()
                        // A Timer has no `parent`, so it names the field: parent.text once read the page's
                        // parent, and typing did nothing until Enter.
                        Timer { id: pathTimer; interval: 700; onTriggered: root.pathEdited(pathField.text) }
                    }
                    Button {
                        id: browseBtn
                        size: 38
                        variant: "outline"
                        glyph: Icons.folder
                        text: "Browse…"
                        fg: Theme.text
                        enabled: !root.deploying
                        onClicked: root.browse()
                    }
                }
            }
        }

        Rectangle {
            visible: root.detecting || root.detectError !== "" || !!root.draft
            width: parent.width
            height: det.implicitHeight + 28
            radius: 18
            color: Theme.white(0.035)
            border.width: 1; border.color: Theme.white(0.06)
            Column {
                id: det
                anchors { left: parent.left; right: parent.right; top: parent.top; margins: 14; leftMargin: 16; rightMargin: 16 }
                spacing: 12
                Row {
                    width: parent.width
                    spacing: 10
                    Item {
                        width: 18; height: 18
                        anchors.verticalCenter: parent.verticalCenter
                        Spinner { anchors.centerIn: parent; visible: root.detecting; size: 16 }
                        QIcon {
                            anchors.centerIn: parent
                            visible: !root.detecting
                            path: root.detectError !== "" ? Icons.alert : Icons.check
                            size: 18; strokeWidth: 2
                            color: root.detectError !== "" ? Theme.amber : Theme.mint
                        }
                    }
                    Column {
                        width: parent.width - 28
                        spacing: 2
                        Text {
                            text: root.detecting ? "Looking at the project…" : root.detectError !== "" ? "Can’t use that folder"
                                : RT.rtLabel(root.draft)
                            font.family: Theme.fontUi; font.pixelSize: 14; font.weight: Font.DemiBold
                            color: Theme.text
                        }
                        Text {
                            width: parent.width
                            visible: text !== ""
                            text: root.detecting ? "" : root.detectError !== "" ? root.detectError : (root.draft ? root.draft.detect : "")
                            wrapMode: Text.WordWrap
                            font.family: Theme.fontUi; font.pixelSize: 12
                            color: Theme.textDim
                        }
                    }
                }

                // SDK this project needs but this account doesn't have yet (installed per account by
                // quasar-dev, no password; downloaded from its maker only when you press Install).
                Rectangle {
                    visible: !!root.draft && !root.detecting && (!!root.missing || root.toolJob.active || root.toolJob.error !== "")
                    width: parent.width
                    height: toolRow.implicitHeight + 20
                    radius: 12
                    color: Theme.alpha(Theme.amber, 0.08)
                    border.width: 1; border.color: Theme.alpha(Theme.amber, 0.25)
                    Row {
                        id: toolRow
                        anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; leftMargin: 12; rightMargin: 12 }
                        spacing: 10
                        QIcon { anchors.verticalCenter: parent.verticalCenter; path: Icons.download; size: 16; color: Theme.amber }
                        Column {
                            width: parent.width - 26 - installBtn.width - 20
                            anchors.verticalCenter: parent.verticalCenter
                            spacing: 2
                            Text {
                                width: parent.width
                                wrapMode: Text.WordWrap
                                text: root.toolJob.active ? (root.toolJob.phase || "Installing…") + "  " + Math.round(root.toolJob.percent) + "%"
                                    : root.toolJob.error !== "" ? root.toolJob.error
                                    : root.missing ? "This project needs " + root.missing.label + "." : ""
                                font.family: Theme.fontUi; font.pixelSize: 13; font.weight: Font.Medium
                                color: Theme.text
                            }
                            Text {
                                visible: !!root.missing && !root.toolJob.active
                                text: root.missing ? "Installed for your account only, " + root.missing.size + " from " + root.missing.from + "." : ""
                                font.family: Theme.fontUi; font.pixelSize: 12
                                color: Theme.textDim
                            }
                        }
                        Button {
                            id: installBtn
                            anchors.verticalCenter: parent.verticalCenter
                            size: 30
                            variant: "soft"
                            text: root.toolJob.error !== "" ? "Try again" : "Install"
                            busy: root.toolJob.active
                            enabled: !root.toolJob.active && !!root.missing
                            onClicked: root.installTool(root.missing.name, root.missing.spec)
                        }
                    }
                }

                Column {
                    visible: !!root.draft && !root.detecting && root.draft.kind !== "static" || (!!root.draft && (root.draft.build || "") !== "")
                    width: parent.width
                    spacing: 6
                    FieldLabel { text: "Build" }
                    TextField {
                        width: parent.width
                        mono: true
                        text: root.draft ? (root.draft.build || "") : ""
                        placeholder: "Nothing to build"
                        enabled: !root.deploying
                        onTextChanged: if (!inputItem.activeFocus) inputItem.ensureVisible(0)
                        onEdited: (t) => root.edited("build", t)
                    }
                }
                Column {
                    visible: !!root.draft && !root.detecting && root.draft.kind !== "static"
                    width: parent.width
                    spacing: 6
                    FieldLabel { text: "Run" }
                    TextField {
                        width: parent.width
                        mono: true
                        text: root.draft ? (root.draft.run || "") : ""
                        placeholder: "How to start it. It must listen on $PORT."
                        onTextChanged: if (!inputItem.activeFocus) inputItem.ensureVisible(0)
                        error: !!root.draft && root.draft.kind !== "static" && (root.draft.run || "") === ""
                        enabled: !root.deploying
                        onEdited: (t) => root.edited("run", t)
                    }
                }
            }
        }

        Column {
            visible: !!root.draft
            width: parent.width
            spacing: 8
            SectionLabel { text: "Address" }
            Row {
                width: parent.width
                spacing: 8
                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: "https://"
                    font.family: Theme.fontMono; font.pointSize: Theme.pt(12.5)
                    color: Theme.textDim
                }
                TextField {
                    width: parent.width - 70
                    mono: true
                    text: root.draft ? (root.draft.hostname || "") : ""
                    placeholder: "my-site.localhost"
                    enabled: !root.deploying
                    Accessible.name: "Site address"
                    onEdited: (t) => root.edited("hostname", t.trim().toLowerCase())
                }
            }
            Text {
                text: "Trusted HTTPS on this PC right away. You can share it with your home network or the internet later."
                width: parent.width
                wrapMode: Text.WordWrap
                font.family: Theme.fontUi; font.pixelSize: 12
                color: Theme.textDim
            }
        }

        Banner {
            visible: root.error !== ""
            width: parent.width
            tone: "error"
            title: "The site wasn’t created"
            message: root.error
            details: root.errorDetails
        }

        Row {
            visible: !root.deploying
            spacing: 8
            Button { variant: "primary"; size: 38; text: "Deploy site"; enabled: root.ready; onClicked: root.deploySite() }
            Button { variant: "outline"; size: 38; text: "Cancel"; onClicked: root.cancel() }
        }

        StepList {
            visible: root.deploying || root.deploy.failed
            width: parent.width
            steps: root.deploy.steps
            current: root.deploy.current
            failed: root.deploy.failed
            lines: root.deploy.lines
        }
    }
}
