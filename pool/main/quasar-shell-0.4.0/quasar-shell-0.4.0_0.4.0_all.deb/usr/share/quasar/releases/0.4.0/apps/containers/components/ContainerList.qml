import QtQuick
import Quasar
import "Format.js" as Format

// One radius-16 box of container rows (template list box, like the Store's Updates): state dot,
// name, image and status; published ports as chips that open http://localhost:<port>; actions —
// logs, a terminal inside it, start/stop, restart, remove. A spinner replaces them while one runs.
Rectangle {
    id: root
    property var containers: []
    property var busy: ({})
    signal containerAction(var container, string action)
    signal openPort(int port)

    height: list.implicitHeight
    radius: 16
    color: Theme.white(0.035)
    border.width: 1; border.color: Theme.white(0.06)

    Column {
        id: list
        width: parent.width
        Repeater {
            model: root.containers
            Item {
                id: rowItem
                required property int index
                required property var modelData
                readonly property bool isRunning: modelData.state === "running"
                readonly property string working: root.busy[modelData.id] || ""
                width: list.width
                height: 62

                Rectangle { visible: rowItem.index > 0; width: parent.width; height: 1; color: Theme.white(0.05) }
                Rectangle {
                    id: dot
                    x: 18
                    anchors.verticalCenter: parent.verticalCenter
                    width: 8; height: 8; radius: 4
                    color: Format.stateTone(rowItem.modelData.state, Theme)
                }
                Column {
                    anchors { left: dot.right; leftMargin: 14; right: ports.left; rightMargin: 12; verticalCenter: parent.verticalCenter }
                    spacing: 3
                    Text {
                        width: parent.width
                        elide: Text.ElideRight
                        text: rowItem.modelData.service || rowItem.modelData.name
                        font.family: Theme.fontUi; font.pixelSize: 14; font.weight: Font.DemiBold
                        color: Theme.text
                    }
                    Text {
                        width: parent.width
                        elide: Text.ElideRight
                        text: rowItem.modelData.image + "  ·  " + rowItem.modelData.status
                        font.family: Theme.fontUi; font.pixelSize: 12
                        color: Theme.textDim
                    }
                }
                Row {
                    id: ports
                    anchors { right: actions.left; rightMargin: 10; verticalCenter: parent.verticalCenter }
                    spacing: 6
                    Repeater {
                        model: rowItem.isRunning ? rowItem.modelData.ports.slice(0, 3) : []
                        Pressable {
                            required property var modelData
                            kind: "chip"
                            radius: 7
                            color: Theme.alpha(Theme.accent, 0.1)
                            implicitWidth: portText.implicitWidth + 18
                            implicitHeight: 24
                            accessibleName: "Open localhost:" + modelData.host + " in the browser"
                            onClicked: root.openPort(modelData.host)
                            Text {
                                id: portText
                                anchors.centerIn: parent
                                text: "localhost:" + modelData.host + " ↗"
                                font.family: Theme.fontMono; font.pointSize: Theme.pt(11.5)
                                color: Theme.accent
                            }
                        }
                    }
                }
                Row {
                    id: actions
                    anchors { right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter }
                    spacing: 0
                    Row {
                        visible: rowItem.working !== ""
                        anchors.verticalCenter: parent.verticalCenter
                        spacing: 8
                        rightPadding: 8
                        Spinner { anchors.verticalCenter: parent.verticalCenter; size: 14 }
                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            text: rowItem.working.split(" ")[0]
                            font.family: Theme.fontUi; font.pixelSize: 12
                            color: Theme.textDim
                        }
                    }
                    Repeater {
                        model: rowItem.working !== "" ? [] : (rowItem.isRunning
                               ? [["logs", Icons.report, "Logs"], ["terminal", Icons.terminal, "Open a terminal in it"], ["restart", Icons.cycle, "Restart"], ["stop", Icons.stop, "Stop"], ["remove", Icons.trash, "Remove"]]
                               : [["logs", Icons.report, "Logs"], ["start", Icons.play, "Start"], ["remove", Icons.trash, "Remove"]])
                        Button {
                            required property var modelData
                            anchors.verticalCenter: parent.verticalCenter
                            glyph: modelData[1]
                            variant: "ghost"; size: 30
                            fg: modelData[0] === "remove" ? Theme.textDim : Theme.text3
                            accessibleName: modelData[2] + " " + (rowItem.modelData.service || rowItem.modelData.name)
                            onClicked: root.containerAction(rowItem.modelData, modelData[0])
                        }
                    }
                }
            }
        }
    }
}
