.pragma library

// Desktop icon layout: pure functions shared by the shell and the design preview.
// Tiles are 96x92 on a 100x96 cell pitch starting at (10, 14); columns fill top to bottom.
// Modes: "grid" (default) snaps saved spots to cells, "free" keeps saved pixels, "auto" ignores saved
// spots and lays the items out in the order given (the caller sorts: fixed, folders, files).

var CELL_W = 100
var CELL_H = 96
var ORIGIN_X = 10
var ORIGIN_Y = 14
var TILE_W = 96
var TILE_H = 92

function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)) }

// area: { width, height } of the desktop above the taskbar.
function grid(area) {
    return {
        cols: Math.max(1, Math.floor((area.width - ORIGIN_X - TILE_W) / CELL_W) + 1),
        rows: Math.max(1, Math.floor((area.height - ORIGIN_Y - 8 - TILE_H) / CELL_H) + 1)
    }
}

function cellPos(c, r) { return { x: ORIGIN_X + c * CELL_W, y: ORIGIN_Y + r * CELL_H } }

// The cell nearest to a tile whose top-left corner is at (x, y).
function cellAt(x, y, g) {
    return { c: clamp(Math.round((x - ORIGIN_X) / CELL_W), 0, g.cols - 1),
             r: clamp(Math.round((y - ORIGIN_Y) / CELL_H), 0, g.rows - 1) }
}

function cellKey(c) { return c.c + "," + c.r }

// The free cell closest to `cell` (columns may run past the screen when every cell is taken).
function nearestFree(cell, taken, g) {
    var best = null, bestD = Infinity
    for (var c = 0; c < g.cols + 4; c++) {
        for (var r = 0; r < g.rows; r++) {
            if (taken[c + "," + r] !== undefined) continue
            var d = (c - cell.c) * (c - cell.c) * 1.05 + (r - cell.r) * (r - cell.r)
            if (d < bestD) { bestD = d; best = { c: c, r: r } }
        }
    }
    return best
}

function firstFree(taken, g) {
    for (var c = 0; ; c++)
        for (var r = 0; r < g.rows; r++)
            if (taken[c + "," + r] === undefined) return { c: c, r: r }
}

function overlaps(a, b) {
    return a.x < b.x + TILE_W && b.x < a.x + TILE_W && a.y < b.y + TILE_H && b.y < a.y + TILE_H
}

// A saved spot that doesn't fit `area` (a smaller main display, a lower resolution).
function outside(p, mode, area, g) {
    if (mode === "free") return p[0] > Math.max(0, area.width - TILE_W) || p[1] > Math.max(0, area.height - TILE_H)
    return Math.round((p[0] - ORIGIN_X) / CELL_W) >= g.cols || Math.round((p[1] - ORIGIN_Y) / CELL_H) >= g.rows
}

// items: [{ key }] in display order. positions: { key: [x, y] } saved spots.
// Returns { pos: { key: {x, y} }, assigned: { key: [x, y] } (spots to save), displaced: { key: true },
// width, height }. When saved spots don't fit the area (the desktop is on a smaller display for now),
// those icons are shown clamped in but `displaced`, and nothing but new items is saved, so the icons
// go back to their spots when the bigger display returns.
function layout(items, positions, mode, area) {
    var g = grid(area)
    var pos = {}, assigned = {}, taken = {}, displaced = {}
    var saved = positions || {}
    var i, key, p, cell, cramped = false

    if (mode === "auto") {
        for (i = 0; i < items.length; i++)
            pos[items[i].key] = cellPos(Math.floor(i / g.rows), i % g.rows)
        return finish(pos, assigned, displaced)
    }

    var pending = []
    for (i = 0; i < items.length; i++) {
        key = items[i].key
        p = saved[key]
        if (!p || p.length !== 2 || !isFinite(p[0]) || !isFinite(p[1])) { pending.push(key); continue }
        if (outside(p, mode, area, g)) { displaced[key] = true; cramped = true }
        if (mode === "free") {
            var fx = clamp(p[0], 0, Math.max(0, area.width - TILE_W))
            var fy = clamp(p[1], 0, Math.max(0, area.height - TILE_H))
            pos[key] = { x: fx, y: fy }
            if (fx !== p[0] || fy !== p[1]) assigned[key] = [fx, fy]
            continue
        }
        cell = cellAt(p[0], p[1], g)
        if (taken[cellKey(cell)] !== undefined) cell = nearestFree(cell, taken, g)
        taken[cellKey(cell)] = key
        pos[key] = cellPos(cell.c, cell.r)
        if (pos[key].x !== p[0] || pos[key].y !== p[1]) assigned[key] = [pos[key].x, pos[key].y]
    }
    if (cramped) assigned = {}                  // only the new items below are saved

    if (mode === "free") {
        // Unsaved items take the first cell whose tile doesn't overlap a placed icon.
        for (i = 0; i < pending.length; i++) {
            for (var c = 0, placed = false; !placed; c++) {
                for (var r = 0; r < g.rows && !placed; r++) {
                    var cand = cellPos(c, r)
                    var clash = false
                    for (var k in pos) if (overlaps(cand, pos[k])) { clash = true; break }
                    if (!clash) { pos[pending[i]] = cand; assigned[pending[i]] = [cand.x, cand.y]; placed = true }
                }
            }
        }
        return finish(pos, assigned, displaced)
    }

    for (i = 0; i < pending.length; i++) {
        cell = firstFree(taken, g)
        taken[cellKey(cell)] = pending[i]
        pos[pending[i]] = cellPos(cell.c, cell.r)
        assigned[pending[i]] = [pos[pending[i]].x, pos[pending[i]].y]
    }
    return finish(pos, assigned, displaced)
}

function finish(pos, assigned, displaced) {
    var w = 0, h = 0
    for (var k in pos) { w = Math.max(w, pos[k].x + TILE_W); h = Math.max(h, pos[k].y + TILE_H) }
    return { pos: pos, assigned: assigned, displaced: displaced || {}, width: w, height: h }
}

// Move `keys` so that `anchor`'s tile top-left lands at (x, y); the others keep their offsets from
// it. In grid mode each lands on the nearest cell not used by an icon that stays put. Returns the
// spots to save for every item, so nothing else shifts afterwards. Icons `displaced` by a smaller
// area (layout()) keep their `saved` spots instead of the clamped ones they are shown at.
function moveGroup(items, pos, keys, anchor, x, y, mode, area, saved, displaced) {
    var g = grid(area)
    var out = {}, taken = {}, moving = {}
    var i, key
    for (i = 0; i < keys.length; i++) moving[keys[i]] = true
    for (i = 0; i < items.length; i++) {
        key = items[i].key
        if (moving[key] || !pos[key]) continue
        out[key] = displaced && displaced[key] && saved && saved[key] ? saved[key] : [pos[key].x, pos[key].y]
        if (mode !== "free") taken[cellKey(cellAt(pos[key].x, pos[key].y, g))] = key
    }
    var a = pos[anchor] || { x: x, y: y }
    var dx = x - a.x, dy = y - a.y
    // The anchor first, then the rest in reading order, so the dragged icon gets its exact spot.
    var order = keys.filter(function (k) { return !!pos[k] }).sort(function (p, q) {
        if (p === anchor) return -1
        if (q === anchor) return 1
        return pos[p].x - pos[q].x || pos[p].y - pos[q].y
    })
    for (i = 0; i < order.length; i++) {
        key = order[i]
        var tx = pos[key].x + dx, ty = pos[key].y + dy
        if (mode === "free") {
            out[key] = [clamp(Math.round(tx), 0, Math.max(0, area.width - TILE_W)),
                        clamp(Math.round(ty), 0, Math.max(0, area.height - TILE_H))]
            continue
        }
        var cell = cellAt(tx, ty, g)
        if (taken[cellKey(cell)] !== undefined) cell = nearestFree(cell, taken, g)
        taken[cellKey(cell)] = key
        var cp = cellPos(cell.c, cell.r)
        out[key] = [cp.x, cp.y]
    }
    return out
}

// Keys whose icon (the tile minus a small margin) intersects the band { x, y, width, height }.
function hit(pos, band) {
    var out = []
    var m = 10
    for (var k in pos) {
        var p = pos[k]
        if (p.x + m < band.x + band.width && band.x < p.x + TILE_W - m
                && p.y + m < band.y + band.height && band.y < p.y + TILE_H - m)
            out.push(k)
    }
    return out
}

// Key of the tile under a point, or "".
function at(pos, x, y) {
    for (var k in pos) {
        var p = pos[k]
        if (x >= p.x && x < p.x + TILE_W && y >= p.y && y < p.y + TILE_H) return k
    }
    return ""
}
// (Natural name order lives in ui/Quasar/files.js: FileKit.naturalCompare.)
