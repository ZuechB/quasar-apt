import QtQuick
import Quasar

// The Users & Accounts forms: add a person, change your name, change your password, or reset someone
// else's. Goes inside a Dialog; the host reads `valid` / `spec()` for its primary button and shows the
// helper's refusal through `error`. Pure view.
//   kind "add":      spec() -> { fullName, username, password, admin }
//   kind "rename":   spec() -> { fullName }
//   kind "password": spec() -> { current, password }
//   kind "reset":    spec() -> { password }
Column {
    id: root
    property string kind: "add"
    property var taken: []                   // usernames and group names already on the PC
    property string display: ""              // "reset": whose password
    property string error: ""                // the helper's refusal
    property bool busy: false
    property bool admin: false
    property bool _userEdited: false
    property bool _touched: false
    signal submitted()

    readonly property string fullName: nameField.text.trim().replace(/\s+/g, " ")
    readonly property string username: userField.text.trim()
    readonly property string problem: {
        if (kind === "add") {
            if (fullName === "") return "Type their name"
            return Accounts.usernameProblem(username, taken) || Accounts.passwordProblem(passField.text, confirmField.text)
        }
        if (kind === "rename") return fullName.length > 64 ? "At most 64 characters" : /[:,=\\]/.test(fullName) ? "Without : , = or \\" : ""
        if (kind === "password" && currentField.text === "") return "Type your current password"
        return Accounts.passwordProblem(passField.text, confirmField.text)
    }
    readonly property bool valid: problem === "" && !busy
    readonly property string shownMessage: error !== "" ? error : (_touched ? problem : "")

    function reset(initialName) {
        nameField.text = initialName || ""
        userField.text = ""; currentField.text = ""; passField.text = ""; confirmField.text = ""
        admin = false; _userEdited = false; _touched = false
    }
    function focusFirst() {
        if (kind === "add" || kind === "rename") nameField.focusInput()
        else if (kind === "password") currentField.focusInput()
        else passField.focusInput()
    }
    // Previews: a filled-in form.
    function fill(name, user, password, confirm) {
        nameField.text = name; userField.text = user; passField.text = password; confirmField.text = confirm
        _userEdited = true; _touched = true
    }
    function clearSecrets() { currentField.text = ""; passField.text = ""; confirmField.text = "" }
    function spec() {
        if (kind === "add") return { fullName: fullName, username: username, password: passField.text, admin: admin }
        if (kind === "rename") return { fullName: fullName }
        if (kind === "password") return { current: currentField.text, password: passField.text }
        return { password: passField.text }
    }
    function submitIfValid() { _touched = true; if (valid) submitted() }

    width: parent ? parent.width : 380
    spacing: 10

    TextField {
        id: nameField
        visible: root.kind === "add" || root.kind === "rename"
        width: parent.width
        glyph: Icons.user
        placeholder: root.kind === "add" ? "Their name, e.g. Alex Morgan" : "Your name"
        enabled: !root.busy
        onEdited: (t) => {
            if (root.kind === "add" && !root._userEdited) userField.text = Accounts.suggestUsername(t, root.taken)
        }
        onAccepted: root.kind === "add" ? userField.focusInput() : root.submitIfValid()
    }
    TextField {
        id: userField
        visible: root.kind === "add"
        width: parent.width
        glyph: Icons.user
        mono: true
        placeholder: "Username, e.g. alex"
        enabled: !root.busy
        onEdited: { root._userEdited = true; root._touched = true }
        onAccepted: passField.focusInput()
    }
    TextField {
        id: currentField
        visible: root.kind === "password"
        width: parent.width
        glyph: Icons.lock
        password: true
        placeholder: "Current password"
        enabled: !root.busy
        onAccepted: passField.focusInput()
    }
    TextField {
        id: passField
        visible: root.kind !== "rename"
        width: parent.width
        glyph: Icons.key
        password: true
        placeholder: root.kind === "add" ? "Password" : "New password"
        enabled: !root.busy
        onAccepted: confirmField.focusInput()
    }
    TextField {
        id: confirmField
        visible: root.kind !== "rename"
        width: parent.width
        glyph: Icons.key
        password: true
        placeholder: "Type it again"
        enabled: !root.busy
        onEdited: root._touched = true
        onAccepted: root.submitIfValid()
    }
    Segmented {
        visible: root.kind === "add"
        width: parent.width
        model: ["Standard", "Administrator"]
        currentIndex: root.admin ? 1 : 0
        accessibleName: "Account type"
        onPicked: (i) => root.admin = i === 1
    }
    Text {
        width: parent.width
        wrapMode: Text.Wrap
        textFormat: Text.PlainText
        visible: text !== ""
        text: root.kind === "add"
              ? (root.admin ? "Administrators can also install apps, add and remove people, and change the whole PC."
                            : "They get their own files, apps, settings and passwords. Installing apps or changing the PC asks for an administrator.")
            : root.kind === "password" ? "Your saved passwords and passkeys in Vault switch to the new password too."
            : root.kind === "reset" ? root.display + "'s saved passwords and passkeys stay locked until they type their old password once. Only reset it if they forgot it."
            : "Shown when you sign in and when the screen is locked."
        font.family: Theme.fontUi; font.pointSize: Theme.pt(12)
        color: root.kind === "reset" ? Theme.amber : Theme.textDim
    }
    Text {
        width: parent.width
        wrapMode: Text.Wrap
        textFormat: Text.PlainText
        visible: root.shownMessage !== ""
        text: root.shownMessage
        font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
        color: root.error !== "" ? Theme.danger : Theme.text3
    }
}
