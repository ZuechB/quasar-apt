import QtQuick
import Quickshell
import Quickshell.Io
import Quasar
import Quasar.Services

// Remote desktop (VNC), the shell's half. Starts and stops quasar-vnc.service with
// Settings.remoteDesktop.enabled (vnc-run keeps wayvnc running while an administrator allowed this account
// and the PC is on a home network), follows who is connected through wayvncctl's events (the taskbar shows
// them, so nobody uses this PC unseen) and keeps viewers on the main display, where the lock screen's
// password card and polkit's password dialog are. When the last viewer leaves, the PC locks (on by default:
// a server's own screen shouldn't stay open after you disconnect).
//   QUASAR_WAYVNCCTL=/path   a stand-in for wayvncctl (tests)
Scope {
    id: root
    required property var lock               // services/ScreenLock.qml
    property string mainName: ""             // the main display's connector: what viewers see

    readonly property var cfg: Settings.remoteDesktop || ({})
    readonly property bool enabled: cfg.enabled === true
    readonly property bool lockOnLeave: cfg.lockOnLeave !== false
    readonly property string runDir: (Quickshell.env("XDG_RUNTIME_DIR") || "/tmp") + "/quasar"
    readonly property string sock: runDir + "/wayvncctl.sock"
    readonly property string ctl: Quickshell.env("QUASAR_WAYVNCCTL") || "wayvncctl"
    property var status: ({})               // vnc-run's $XDG_RUNTIME_DIR/quasar/vnc.json
    readonly property bool listening: status.state === "listening"
    property var viewers: []                // [{ id, address, username }] connected now
    readonly property int count: viewers.length
    signal toast(var t)

    // ---- the service --------------------------------------------------------------------------------
    onEnabledChanged: apply()
    Component.onCompleted: apply()
    function apply() {
        Quickshell.execDetached(["systemctl", "--user", enabled ? "start" : "stop", "quasar-vnc.service"])
        if (!enabled) viewers = []
    }
    // Settings asks for a fresh start after an administrator allowed this account (users.json changed while
    // vnc-run was already waiting is noticed by vnc-run itself; this covers a failed unit).
    function restart() { if (enabled) Quickshell.execDetached(["systemctl", "--user", "restart", "quasar-vnc.service"]) }

    // quasar-session-start makes the file before the shell loads, so the watch holds.
    FileView {
        path: root.runDir + "/vnc.json"
        watchChanges: true
        printErrors: false
        onFileChanged: reload()
        onLoaded: {
            let st = {}
            try { st = JSON.parse(text()) } catch (e) { return }
            root.status = st
            if (st.state !== "listening") root.viewers = []
        }
    }

    // ---- who is connected ----------------------------------------------------------------------------
    // One wayvncctl for the whole session: --wait for wayvnc's socket, --reconnect when wayvnc starts again
    // (another network, a display came or went).
    Process {
        id: events
        running: root.enabled
        command: [root.ctl, "--socket=" + root.sock, "--json", "--wait", "--reconnect", "event-receive"]
        stdout: SplitParser { onRead: (line) => root.onEvent(line) }
        stderr: SplitParser { onRead: (line) => console.warn("wayvncctl: " + line) }
        onExited: (code) => { root.viewers = []; if (root.enabled) eventsAgain.restart() }
    }
    Timer { id: eventsAgain; interval: 3000; onTriggered: events.running = root.enabled }

    function onEvent(line) {
        let e = null
        try { e = JSON.parse(line) } catch (err) { return }
        if (!e || typeof e !== "object") return
        const kind = e.method || e.event || e.name || ""
        const p = e.params || e.data || {}
        if (kind === "wayvnc-startup") { list(); showMain(); return }
        if (kind === "wayvnc-shutdown") { viewers = []; return }
        if (kind === "client-connected") {
            const v = viewer(p)
            if (!v.id || viewers.some(x => x.id === v.id)) return
            viewers = viewers.concat([v])
            showMain()
            toast({ title: (v.address || "Another computer") + " is using your screen",
                    sub: "Remote desktop" + (v.username ? "  ·  signed in as " + v.username : ""),
                    glyph: Icons.monitor, hue: Theme.accent })
        } else if (kind === "client-disconnected") {
            const id = String(p.id || "")
            const was = viewers.length
            viewers = viewers.filter(x => x.id !== id)
            const left = p.connection_count !== undefined ? Number(p.connection_count) : viewers.length
            if (was > 0 && left === 0 && viewers.length === 0 && lockOnLeave && !root.lock.locked) root.lock.lock()
        }
    }
    function viewer(p) {
        return { id: String(p.id || ""), address: String(p.address || ""), username: String(p.username || "") }
    }

    // The clients wayvnc has now (after a shell restart, or when wayvnc starts again).
    Process {
        id: listProc
        command: [root.ctl, "--socket=" + root.sock, "--json", "client-list"]
        stdout: StdioCollector {
            onStreamFinished: {
                let a = []
                try { a = JSON.parse(text) } catch (e) { return }
                if (Array.isArray(a)) root.viewers = a.map(c => root.viewer(c)).filter(v => v.id)
            }
        }
    }
    function list() { if (enabled && !listProc.running) listProc.running = true }
    onListeningChanged: if (listening) { list(); showMain() }

    // ---- what viewers see -----------------------------------------------------------------------------
    onMainNameChanged: showMain()
    function showMain() {
        if (enabled && listening && mainName)
            Quickshell.execDetached([ctl, "--socket=" + sock, "output-set", mainName])
    }

    // ---- the taskbar menu ------------------------------------------------------------------------------
    function disconnect(id) {
        Quickshell.execDetached([ctl, "--socket=" + sock, "client-disconnect", String(id)])
    }
    function disconnectAll() { for (const v of viewers) disconnect(v.id) }
}
