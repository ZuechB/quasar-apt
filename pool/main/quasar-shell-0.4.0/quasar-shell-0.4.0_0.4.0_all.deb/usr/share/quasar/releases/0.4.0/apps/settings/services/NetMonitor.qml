import QtQuick
import Quickshell
import Quasar
import Quasar.Services

// Settings › Network & Internet › Network monitor, and Firewall › Recently blocked: quasar-netguard
// counts each app's internet use today (per app scope) and lets you block your own apps (no password:
// it only restricts you). Asks over /run/quasar/netguard.sock; the service answers for whoever asks.
//   rows     [{ key, name, icon, glyph, rx, tx, total, blocked, blockable, running, system }]
//   phase    "loading" | "ok" | "unavailable"
//   recent   [{ time, from, port, proto, app, network }] for the firewall's "Recently blocked"
Scope {
    id: root
    property bool active: false             // the Network page is shown: usage, every few seconds
    property bool recentActive: false       // the Firewall page is shown: recently blocked
    property var rows: []
    // Keyed by app, so the list updates in place every few seconds instead of being rebuilt.
    readonly property ScriptModel model: ScriptModel { values: root.rows; objectProp: "key" }
    readonly property real top: rows.reduce((m, r) => Math.max(m, r.total), 1)
    property string phase: "loading"
    property var recent: []
    property string busyKey: ""
    signal notify(var banner)

    property var client: null
    readonly property Component _clientComponent: Component { NetGuardClient { } }
    function ensure() {
        if (client && !client.dead) return client
        if (client) client.destroy()
        client = _clientComponent.createObject(root)
        return client
    }

    function refresh() {
        ensure().request({ op: "usage" }, (r) => {
            if (!r.ok) { root.phase = "unavailable"; return }
            root.rows = (r.rows || []).map(root.decorate)
            root.phase = "ok"
        })
    }
    function refreshRecent() {
        ensure().request({ op: "recent" }, (r) => {
            if (!r.ok) return
            root.recent = (r.rows || []).map(x => ({ time: x.time, from: x.from, port: x.port, proto: x.proto,
                                                    app: x.key ? root.nameOf(x) : "", network: x.network || "" }))
        })
    }

    function nameOf(x) {
        if (x.key && x.key.startsWith("app:")) {
            const e = DesktopEntries.byId(x.key.slice(4))
            if (e && e.name) return e.name
        }
        return x.label || x.key || ""
    }
    // What a row looks like: an app's own icon when it has one, otherwise a glyph for what it is.
    function decorate(x) {
        const e = x.kind === "app" ? DesktopEntries.byId(x.id) : null
        const glyph = x.kind === "company" ? Icons.brief : x.key === "containers" ? Icons.layers
                    : x.key === "other" ? Icons.globe : x.kind === "sys" ? Icons.server
                    : x.kind === "unit" ? Icons.orbit : Icons.grid
        return { key: x.key, name: (e && e.name) ? e.name : x.label, icon: e && e.icon ? Quickshell.iconPath(e.icon, true) : "",
                 glyph: glyph, rx: x.rx, tx: x.tx, total: x.rx + x.tx, blocked: !!x.blocked, blockable: !!x.blockable,
                 running: !!x.running, system: !!x.system }
    }

    function setBlocked(key, on) {
        if (busyKey) return
        busyKey = key
        ensure().request({ op: on ? "block" : "unblock", key: key }, (r) => {
            root.busyKey = ""
            if (!r.ok) root.notify({ tone: "error", title: on ? "That app couldn't be blocked" : "That app couldn't be allowed",
                                     message: r.error || "The network guard didn't answer." })
            root.refresh()
        })
    }

    onActiveChanged: if (active) refresh()
    onRecentActiveChanged: if (recentActive) refreshRecent()
    Timer {
        interval: 5000
        repeat: true
        running: root.active
        onTriggered: root.refresh()
    }
    Timer {
        interval: 10000
        repeat: true
        running: root.recentActive
        onTriggered: root.refreshRecent()
    }
}
