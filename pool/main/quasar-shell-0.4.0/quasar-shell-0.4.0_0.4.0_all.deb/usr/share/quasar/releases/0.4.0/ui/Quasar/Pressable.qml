import QtQuick

// Interactive base matching the mockup's hover classes:
//   "hov"  : hover bg white .07, press scale .97 (spring .4s)
//   "chip" : hover lift 1px + brighten, press scale .95 (spring .45s)
//   "tile" : hover lift 4px + scale 1.05 + bg white .06, press scale .94 (spring .5s)
//   "card" : hover lift 3px + brighter border/bg (spring .5s)
//   "plain": background change only
// Keyboard: Tab focus, Enter/Space activate, accent focus ring (mockup :focus-visible).
Item {
    id: root
    property string kind: "hov"
    property real radius: 10
    property color color: "transparent"
    property color hoverColor: kind === "tile" ? Theme.white(0.06)
                             : kind === "hov" ? Theme.white(0.07)
                             : kind === "card" ? Theme.white(0.06) : color
    property color borderColor: "transparent"
    property color hoverBorderColor: kind === "card" ? Theme.white(0.16) : borderColor
    property real borderWidth: 1
    property string accessibleName: ""
    property int cursorShape: Qt.PointingHandCursor
    // The content holds its own buttons (a Store card's Get / stop): stack it above this item's
    // MouseArea so they get the pointer first. Text and shapes take no events, so clicks anywhere
    // else still reach this item. Off by default: this MouseArea is on top of everything else.
    property bool interactiveContent: false
    // With interactiveContent, the pointer over a nested button still counts (no 3px drop of a card).
    readonly property bool hovered: mouse.containsMouse || (interactiveContent && hoverAll.hovered)
    readonly property alias pressed: mouse.pressed
    // Keyboard modifiers of the last mouse press (Ctrl+click on a desktop icon adds it to the selection).
    readonly property alias modifiers: mouse.pressModifiers
    default property alias content: inner.data

    signal clicked()
    signal doubleClicked()
    signal rightClicked(real x, real y)
    // draggable: a left press that moves past the platform drag distance emits dragStarted(press point)
    // instead of a click. Detected here because a DragHandler stacked above would take the press away
    // from this MouseArea. After a system drag call resetPress(): its release may never arrive.
    property bool draggable: false
    signal dragStarted(real x, real y)
    function resetPress() { mouse.enabled = false; mouse.enabled = Qt.binding(() => root.enabled) }

    activeFocusOnTab: enabled
    Accessible.role: Accessible.Button
    Accessible.name: accessibleName
    Accessible.focusable: true
    Accessible.onPressAction: root.clicked()
    Keys.onReturnPressed: root.clicked()
    Keys.onEnterPressed: root.clicked()
    Keys.onSpacePressed: root.clicked()

    readonly property int _dur: kind === "tile" || kind === "card" ? Motion.tile : kind === "chip" ? Motion.chip : Motion.press
    readonly property real _lift: !hovered ? 0 : kind === "tile" ? -4 : kind === "card" ? -3 : kind === "chip" ? -1 : 0
    readonly property real _scale: (kind === "tile" && hovered ? 1.05 : 1)
                                 * (!pressed ? 1 : kind === "tile" ? 0.94 : kind === "chip" ? 0.95 : kind === "hov" ? 0.97 : 1)

    Item {
        id: visual
        anchors.fill: parent
        z: root.interactiveContent ? 1 : 0
        scale: root._scale
        transform: Translate {
            y: root._lift
            Behavior on y { NumberAnimation { duration: Motion.dur(root._dur); easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.spring } }
        }
        Behavior on scale { NumberAnimation { duration: Motion.dur(root._dur); easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.spring } }

        Rectangle {
            anchors.fill: parent
            radius: root.radius
            color: root.hovered && root.enabled ? root.hoverColor : root.color
            border.width: (root.hovered ? root.hoverBorderColor : root.borderColor).a > 0 ? root.borderWidth : 0
            border.color: root.hovered ? root.hoverBorderColor : root.borderColor
            Behavior on color { ColorAnimation { duration: Motion.dur(Motion.hover) } }
        }
        Item { id: inner; anchors.fill: parent }
        // chip hover = filter: brightness(1.12)
        Rectangle {
            anchors.fill: parent
            radius: root.radius
            color: Theme.white(0.07)
            visible: root.kind === "chip" && root.hovered && root.enabled
        }
    }

    Rectangle {
        anchors.fill: parent
        anchors.margins: -4
        radius: root.radius + 4
        color: "transparent"
        border.width: 2
        border.color: Theme.accent
        visible: root.activeFocus
    }

    HoverHandler { id: hoverAll; enabled: root.interactiveContent && root.enabled }

    MouseArea {
        id: mouse
        anchors.fill: parent
        enabled: root.enabled
        hoverEnabled: true
        acceptedButtons: Qt.LeftButton | Qt.RightButton
        cursorShape: root.cursorShape
        property point pressAt: Qt.point(0, 0)
        property bool dragged: false
        property int pressModifiers: 0
        onPressed: (e) => { pressAt = Qt.point(e.x, e.y); dragged = false; pressModifiers = e.modifiers }
        onPositionChanged: (e) => {
            if (!root.draggable || dragged || !(pressedButtons & Qt.LeftButton)) return
            const d = Application.styleHints.startDragDistance
            if (Math.abs(e.x - pressAt.x) > d || Math.abs(e.y - pressAt.y) > d) { dragged = true; root.dragStarted(pressAt.x, pressAt.y) }
        }
        onClicked: (e) => { if (dragged) return; if (e.button === Qt.RightButton) root.rightClicked(e.x, e.y); else root.clicked() }
        onDoubleClicked: (e) => { if (e.button === Qt.LeftButton && !dragged) root.doubleClicked() }
    }
}
