import QtQuick

// Soft drop shadow for a rounded rectangle: CSS `box-shadow: x y blur spread color`.
// Place it as a sibling *behind* the casting item and point `target` at it.
// The item grows past the target by the blur extent; nothing is rendered offscreen.
Item {
    id: root
    property Item target: parent
    property real radius: 16
    property real offsetX: 0
    property real offsetY: 24
    property real blur: 48          // CSS blur radius (sigma = blur / 2)
    property real spread: -12
    property color color: Qt.rgba(0, 0, 0, 0.9)

    readonly property real _sigma: Math.max(0.5, blur / 2)
    readonly property real _extent: Math.ceil(_sigma * 3 + Math.abs(spread))
    readonly property real _bw: (target ? target.width : 0) + 2 * spread
    readonly property real _bh: (target ? target.height : 0) + 2 * spread

    x: (target ? target.x : 0) + offsetX - spread - _extent
    y: (target ? target.y : 0) + offsetY - spread - _extent
    width: Math.max(0, _bw) + 2 * _extent
    height: Math.max(0, _bh) + 2 * _extent
    // Lite (Raspberry Pi, software rendering): solid surfaces, no shadow shader passes.
    visible: Theme.profile > 0 && _bw > 0 && _bh > 0

    ShaderEffect {
        anchors.fill: parent
        property color shadowColor: root.color
        property size itemSize: Qt.size(width, height)
        property rect box: Qt.rect(root._extent, root._extent, root._bw, root._bh)
        property real radius: Math.max(0, root.radius + root.spread)
        property real sigma: root._sigma
        fragmentShader: Qt.resolvedUrl("shaders/roundedshadow.frag.qsb")
    }
}
