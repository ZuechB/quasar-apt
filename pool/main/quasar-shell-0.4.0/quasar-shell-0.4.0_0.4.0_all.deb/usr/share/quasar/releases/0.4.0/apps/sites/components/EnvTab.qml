import QtQuick
import Quasar

// Template Sites › Environment: variables and secrets (names mono; secrets show •••• with an
// "Encrypted" badge and Reveal/Hide), an add row (NAME, value, Add, Add as secret) and the footnote.
Column {
    id: root
    property var env: []               // [[name, value]]
    property var secrets: []           // [name]
    property var revealed: ({})        // name -> value
    property bool busy: false
    signal setVar(string name, string value, bool secret)
    signal removeVar(string name)
    signal reveal(string name)
    signal hide(string name)

    spacing: 12
    readonly property var rows: env.map(e => ({ k: e[0], v: e[1], secret: false }))
                                   .concat(secrets.map(n => ({ k: n, v: "", secret: true })))
    readonly property bool nameOk: /^[A-Za-z_][A-Za-z0-9_]*$/.test(newK.text)

    Rectangle {
        width: parent.width
        height: Math.max(56, list.implicitHeight)
        radius: 18
        color: Theme.white(0.035)
        border.width: 1; border.color: Theme.white(0.06)
        Text {
            visible: root.rows.length === 0
            anchors.centerIn: parent
            text: "No variables yet."
            font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
            color: Theme.textFaint
        }
        Column {
            id: list
            width: parent.width
            Repeater {
                model: root.rows
                delegate: Item {
                    id: row
                    required property var modelData
                    required property int index
                    readonly property bool shown: modelData.secret && root.revealed[modelData.k] !== undefined
                    width: list.width
                    height: 48
                    Rectangle { visible: row.index > 0; anchors { left: parent.left; right: parent.right; top: parent.top } height: 1; color: Theme.white(0.05) }
                    Text {
                        id: key
                        x: 16
                        width: Math.round(parent.width * 0.34)
                        anchors.verticalCenter: parent.verticalCenter
                        text: row.modelData.k
                        elide: Text.ElideRight
                        font.family: Theme.fontMono; font.pointSize: Theme.pt(12.5)
                        color: Theme.text
                    }
                    Text {
                        anchors { left: key.right; leftMargin: 16; right: tail.left; rightMargin: 12; verticalCenter: parent.verticalCenter }
                        text: !row.modelData.secret ? row.modelData.v : row.shown ? root.revealed[row.modelData.k] : "••••••••••••"
                        textFormat: Text.PlainText
                        elide: Text.ElideRight
                        font.family: Theme.fontMono; font.pointSize: Theme.pt(12.5)
                        color: Theme.textMuted
                    }
                    Row {
                        id: tail
                        anchors { right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter }
                        spacing: 6
                        Rectangle {
                            visible: row.modelData.secret
                            anchors.verticalCenter: parent.verticalCenter
                            width: badge.implicitWidth + 16; height: 22; radius: 7
                            color: Theme.alpha("#FFD66B", 0.12)
                            Row {
                                id: badge
                                anchors.centerIn: parent
                                spacing: 5
                                QIcon { anchors.verticalCenter: parent.verticalCenter; path: Icons.lock; size: 11; strokeWidth: 2.2; color: "#FFD66B" }
                                Text { anchors.verticalCenter: parent.verticalCenter; text: "Encrypted"; font.family: Theme.fontUi; font.pixelSize: 11; font.weight: Font.DemiBold; color: "#FFD66B" }
                            }
                        }
                        Button {
                            visible: row.modelData.secret
                            variant: "ghost"; size: 28
                            text: row.shown ? "Hide" : "Reveal"
                            onClicked: row.shown ? root.hide(row.modelData.k) : root.reveal(row.modelData.k)
                        }
                        Pressable {
                            anchors.verticalCenter: parent.verticalCenter
                            implicitWidth: 28; implicitHeight: 28
                            kind: "hov"; radius: 8
                            accessibleName: "Remove " + row.modelData.k
                            enabled: !root.busy
                            onClicked: root.removeVar(row.modelData.k)
                            QIcon { anchors.centerIn: parent; path: Icons.trash; size: 14; color: Theme.textDim }
                        }
                    }
                }
            }
        }
    }

    Row {
        width: parent.width
        spacing: 8
        TextField {
            id: newK
            width: Math.round(parent.width * 0.28)
            mono: true
            placeholder: "NAME"
            error: text !== "" && !root.nameOk
            Accessible.name: "Variable name"
        }
        TextField {
            id: newV
            width: parent.width - newK.width - addBtn.width - secretBtn.width - 24
            mono: true
            placeholder: "value"
            Accessible.name: "Value"
            onAccepted: if (root.nameOk) { root.setVar(newK.text, newV.text, false); newK.text = ""; newV.text = "" }
        }
        Button {
            id: addBtn
            size: 38; variant: "soft"; text: "Add"
            enabled: root.nameOk && !root.busy
            onClicked: { root.setVar(newK.text, newV.text, false); newK.text = ""; newV.text = "" }
        }
        Button {
            id: secretBtn
            size: 38; variant: "soft"; text: "Add as secret"; glyph: Icons.lock; fg: "#FFD66B"
            enabled: root.nameOk && !root.busy
            onClicked: { root.setVar(newK.text, newV.text, true); newK.text = ""; newV.text = "" }
        }
    }
    Text {
        width: parent.width
        wrapMode: Text.WordWrap
        text: "Changes apply on the next restart. Secrets are encrypted with this PC’s key and never written to disk in plain text."
        font.family: Theme.fontUi; font.pixelSize: 12
        color: Theme.textDim
    }
}
