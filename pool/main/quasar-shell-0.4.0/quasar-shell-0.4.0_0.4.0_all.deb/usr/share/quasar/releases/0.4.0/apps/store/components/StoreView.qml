import QtQuick
import Quasar
import "state.js" as State
import "search.js" as Search

// Store window content (template data-win="store"): 210px sidebar | page.
// Pure view. The host passes the catalog as it is (all of Flathub plus Quasar's picks, about 3,400
// entries, never copied or modified), the live install state (jobStates, installed) and reacts to the
// signals. Lists are ids shown by a GridView (ListPage), so only the cards on screen exist.
Item {
    id: root
    // ---- data in ------------------------------------------------------------------------------
    property var apps: []               // catalog entries in recommended order (picks, then most installed)
    property var index: ({})            // id -> entry
    property var categories: []         // [{ id, label, glyph, chips: [{ id, label }] }] (from the catalog)
    property var collections: ({})      // { picks, popular, trending, new }: ids
    property var runtimes: ({})         // runtime ref -> installed size
    property string storeDir: ""        // where the catalog's icons are
    property var jobStates: ({})        // id -> { state, progress, phase, action, cancellable, cancelling }
    property var installed: ({ flatpaks: ({}), debs: ({}), tools: ({}) })
    property bool live: false
    property var details: null          // the open app's details (description, licence, privacy label…)
    property string page: "discover"    // discover | <category id> | collection:<id> | installed | updates
    property string query: ""
    property string detailId: ""
    property var updates: []
    property bool updatesChecked: false
    property bool checkingUpdates: false
    property string updatesError: ""
    property var banner: null           // { tone, title, message, details, actionText }
    property bool softwareRender: false
    property var online: []             // ids found by an explicit online Flathub search
    property bool onlineSearching: false
    property string versionsLoading: ""  // developer tool whose release list is being fetched

    // ---- signals out ------------------------------------------------------------------------
    signal navigate(string page)
    signal queryEdited(string text)
    signal openDetail(string id)
    signal closeDetail()
    signal getApp(string id)
    signal openApp(string id)
    signal removeApp(string id)
    signal cancelApp(string id)
    signal checkUpdates()
    signal updateApp(string id)
    signal updateAll()
    signal bannerAction()
    signal bannerDismissed()
    signal searchOnline(string text)
    signal openHomepage(string id, string url)
    signal installTool(string id, string spec)            // developer tools (mise)
    signal setToolDefault(string id, string version)
    signal removeToolVersion(string id, string version)
    signal otherVersions(string id)

    // The five categories of catalogs from before Learn (no `categories` in the file).
    readonly property var categoryList: categories && categories.length ? categories : [
        { id: "create", label: "Create", glyph: "brush", chips: [] }, { id: "work", label: "Work", glyph: "brief", chips: [] },
        { id: "develop", label: "Develop", glyph: "code", chips: [] }, { id: "games", label: "Games", glyph: "gamepad", chips: [] },
        { id: "utilities", label: "Utilities", glyph: "wrench", chips: [] }]
    readonly property var category: { for (const c of categoryList) if (c.id === page) return c; return null }
    readonly property var collectionTitles: ({ picks: "Quasar picks", popular: "Popular on Flathub",
                                               trending: "Trending on Flathub", "new": "New on Flathub" })

    // Search waits for a pause in typing (150 ms): ranking ~3,400 apps on every key isn't needed.
    property string q: ""
    Timer { id: debounce; interval: 150; onTriggered: root.q = root.query.trim().toLowerCase() }
    onQueryChanged: { if (query.trim() === "") { debounce.stop(); q = "" } else debounce.restart() }

    property string chip: ""
    property int sortIndex: 0                       // Recommended | Name | Recently updated
    readonly property var sortKeys: ["rec", "name", "updated"]

    readonly property string mode: q !== "" ? "list" : page === "discover" ? "discover" : page === "updates" ? "updates" : "list"
    readonly property var detailApp: detailId ? State.merged(index[detailId], jobStates, installed, live, details, runtimes, storeDir) : null

    function _have(ids) { return (ids || []).filter(id => !!index[id]) }
    readonly property var listIds: {
        if (q !== "") return Search.run(apps, q)
        if (page.startsWith("collection:")) {
            const c = page.slice(11)
            if (c === "picks") return apps.filter(a => a.pick && !a.online).map(a => a.id)
            return _have(collections[c])
        }
        if (page === "installed") return apps.filter(a => State.isInstalled(a, installed)).map(a => a.id)
        if (category) return Search.category(apps, page, chip, sortKeys[sortIndex])
        return []
    }
    readonly property var chipCounts: category && q === "" ? Search.counts(apps, page) : ({})
    readonly property string listTitle: q !== "" ? "Results for “" + query.trim() + "”"
                                      : category ? category.label
                                      : page === "installed" ? "Installed"
                                      : page.startsWith("collection:") ? (collectionTitles[page.slice(11)] || "Apps") : ""
    readonly property string countText: q !== "" || !category ? ""
                                       : (chip ? (chipCounts[chip] || 0) : (chipCounts[""] || 0)).toLocaleString(Qt.locale("en_US"), "f", 0) + " apps"

    // Discover
    readonly property var heroEntry: { for (const a of apps) if (a.featured) return a; return apps.length ? apps[0] : null }
    readonly property var heroApp: heroEntry ? State.merged(heroEntry, jobStates, installed, live, null, runtimes, storeDir) : null
    readonly property var shelves: {
        const c = collections || {}
        let picks = _have(c.picks)
        if (!picks.length) picks = apps.filter(a => a.popular).map(a => a.id)
        return [{ id: "picks", title: "Quasar picks", ids: picks },
                { id: "popular", title: "Popular on Flathub", ids: _have(c.popular) },
                { id: "trending", title: "Trending on Flathub", ids: _have(c.trending) },
                { id: "new", title: "New on Flathub", ids: _have(c["new"]) }].filter(s => s.ids.length > 0)
    }
    readonly property int cols: Math.max(1, Math.floor((pageArea.width - 44 + 10) / (250 + 10)))

    // A new list starts at the top; Back from a detail page returns to where you were.
    onPageChanged: { chip = ""; sortIndex = 0; Qt.callLater(listPage.toTop); discoverPane.scrollToTop() }
    onQChanged: Qt.callLater(listPage.toTop)
    onChipChanged: Qt.callLater(listPage.toTop)
    onSortIndexChanged: Qt.callLater(listPage.toTop)
    onDetailIdChanged: detailPane.scrollToTop()

    // Test hooks (the Store's `stats` / `scrollDemo` IPC): cards created so far, and a scripted scroll
    // through the current list for frame-time measurements.
    readonly property int cardsCreated: listPage.created
    function scrollDemo(ms) {
        demo.from = listPage.originY - listPage.topMargin
        demo.to = Math.max(demo.from, listPage.originY + listPage.contentHeight + listPage.bottomMargin - listPage.height)
        demo.duration = ms || 6000
        demo.restart()
    }
    NumberAnimation { id: demo; target: listPage; property: "contentY" }

    // ---- sidebar ----------------------------------------------------------------------------
    Item {
        id: side
        width: 210
        height: parent.height
        SearchField {
            id: search
            x: 10; y: 12
            width: parent.width - 20
            placeholder: "Search apps"
            text: root.query
            onEdited: (t) => root.queryEdited(t)
            onAccepted: { root.q = root.query.trim().toLowerCase(); if (root.listIds.length === 0 && root.q !== "") root.searchOnline(root.query.trim()) }
        }
        // The nav scrolls when the window is short; Sources shows only when it fits under it.
        readonly property real navTop: search.y + search.height + 8
        readonly property bool sourcesFit: navCol.implicitHeight + sources.implicitHeight + 36 <= height - navTop
        ScrollPane {
            id: navPane
            x: 10; y: side.navTop
            width: parent.width - 20
            height: parent.height - y - (side.sourcesFit ? sources.implicitHeight + 24 : 6)
            Column {
                id: navCol
                width: navPane.width
                spacing: 2
                Repeater {
                    model: [["discover", "Discover", Icons.compass]]
                           .concat(root.categoryList.map(c => [c.id, c.label, Icons.get(c.glyph)]))
                           .concat([["sep"], ["installed", "Installed", Icons.check], ["updates", "Updates", Icons.refresh]])
                    NavItem {
                        required property var modelData
                        width: navCol.width
                        separator: modelData[0] === "sep"
                        label: modelData[1] || ""
                        glyph: modelData[2] || ""
                        selected: root.q === "" && !root.detailId && root.page === modelData[0]
                        badge: modelData[0] === "updates" && root.updates.length > 0 ? String(root.updates.length) : ""
                        onClicked: root.navigate(modelData[0])
                    }
                }
            }
        }
        Column {
            id: sources
            visible: side.sourcesFit
            anchors { left: parent.left; leftMargin: 20; bottom: parent.bottom; bottomMargin: 14 }
            spacing: 8
            SectionLabel { text: "Sources"; font.pointSize: Theme.pt(10) }
            Repeater {
                model: [["Flathub", true], ["Debian", true], ["Quasar Community", false]]
                Row {
                    required property var modelData
                    spacing: 8
                    Rectangle { y: 5; width: 6; height: 6; radius: 3; color: modelData[1] ? Theme.mint : Theme.white(0.2) }
                    Column {
                        Text { text: modelData[0]; font.family: Theme.fontUi; font.pixelSize: 12; color: modelData[1] ? Theme.textMuted : Theme.textFaint }
                        Text { visible: !modelData[1]; text: "Coming soon"; font.family: Theme.fontUi; font.pixelSize: 11; color: Theme.textFaint }
                    }
                }
            }
        }
    }
    Rectangle { x: side.width; width: 1; height: parent.height; color: Theme.white(0.05) }

    // ---- page ---------------------------------------------------------------------------------
    Item {
        id: pageArea
        x: side.width + 1
        width: parent.width - x
        height: parent.height

        // Messages stay in view, above whatever page is scrolled.
        Banner {
            id: bannerStrip
            visible: !!root.banner
            x: 22; y: 14
            width: parent.width - 44
            tone: root.banner ? (root.banner.tone || "error") : "error"
            title: root.banner ? root.banner.title || "" : ""
            message: root.banner ? root.banner.message || "" : ""
            details: root.banner ? root.banner.details || "" : ""
            actionText: root.banner ? root.banner.actionText || "" : ""
            onActionClicked: root.bannerAction()
        }
        Item {
            id: body
            y: bannerStrip.visible ? bannerStrip.y + bannerStrip.height + 2 : 0
            width: parent.width
            height: parent.height - y

            // Discover: the hero and one-row shelves (a few dozen cards).
            ScrollPane {
                id: discoverPane
                anchors.fill: parent
                visible: root.mode === "discover" && !root.detailId
                topPadding: 20; bottomPadding: 28
                Column {
                    x: 22
                    width: discoverPane.width - 44
                    spacing: 26
                    StoreHero {
                        visible: !!root.heroApp
                        width: parent.width
                        app: root.heroApp
                        onGetClicked: root.getApp(root.heroApp.id)
                        onOpenClicked: root.openApp(root.heroApp.id)
                        onCancelClicked: root.cancelApp(root.heroApp.id)
                        onDetailClicked: root.openDetail(root.heroApp.id)
                    }
                    Repeater {
                        model: root.shelves
                        Shelf {
                            required property var modelData
                            width: parent.width
                            title: modelData.title
                            ids: modelData.ids
                            view: root
                            cols: root.cols
                            onSeeAll: root.navigate("collection:" + modelData.id)
                        }
                    }
                }
            }

            // Categories, collections, search results, Installed.
            ListPage {
                id: listPage
                anchors.fill: parent
                visible: root.mode === "list" && !root.detailId
                ids: root.listIds
                view: root
                header: Column {
                    id: head
                    width: listPage.contentW - 10
                    spacing: 0
                    readonly property bool sortable: !!root.category && root.q === ""
                    // The sort control sits beside the title when there's room, else on its own row.
                    readonly property bool sortBeside: titleText.implicitWidth + countLabel.implicitWidth + 40 + 300 <= width
                    Item {
                        width: parent.width
                        height: 44
                        Text {
                            id: titleText
                            anchors.verticalCenter: parent.verticalCenter
                            width: Math.min(implicitWidth, parent.width - (countLabel.visible ? countLabel.implicitWidth + 10 : 0))
                            elide: Text.ElideRight
                            text: root.listTitle
                            textFormat: Text.PlainText
                            font.family: Theme.fontDisplay; font.pixelSize: 18; font.weight: Font.Medium
                            color: Theme.text
                        }
                        Text {
                            id: countLabel
                            anchors { left: titleText.right; leftMargin: 10; baseline: titleText.baseline }
                            visible: root.countText !== ""
                            text: root.countText
                            font.family: Theme.fontUi; font.pixelSize: 12; font.features: { "tnum": 1 }
                            color: Theme.textDim
                        }
                        Segmented {
                            visible: head.sortable && head.sortBeside
                            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                            width: 300
                            height: 34
                            model: ["Recommended", "Name", "Updated"]
                            accessibleName: "Sort"
                            currentIndex: root.sortIndex
                            onPicked: (i) => root.sortIndex = i
                        }
                    }
                    Segmented {
                        visible: head.sortable && !head.sortBeside
                        width: Math.min(300, parent.width)
                        height: 34
                        model: ["Recommended", "Name", "Updated"]
                        accessibleName: "Sort"
                        currentIndex: root.sortIndex
                        onPicked: (i) => root.sortIndex = i
                    }
                    Item { visible: head.sortable && !head.sortBeside; width: 1; height: 8 }
                    Flow {
                        visible: !!root.category && root.q === "" && root.category.chips.length > 0
                        width: parent.width
                        spacing: 6
                        topPadding: 4
                        bottomPadding: 14
                        FilterChip {
                            text: "All"
                            selected: root.chip === ""
                            onClicked: root.chip = ""
                        }
                        Repeater {
                            model: root.category ? root.category.chips : []
                            FilterChip {
                                required property var modelData
                                text: modelData.label
                                count: root.chipCounts[modelData.id] || 0
                                selected: root.chip === modelData.id
                                onClicked: root.chip = selected ? "" : modelData.id
                            }
                        }
                    }
                    Item { visible: !(!!root.category && root.q === "" && root.category.chips.length > 0); width: 1; height: 8 }
                    Text {
                        visible: root.listIds.length === 0
                        topPadding: 4
                        bottomPadding: 8
                        width: parent.width
                        wrapMode: Text.Wrap
                        text: root.q !== "" ? "Nothing in the Store matches."
                             : root.page === "installed" ? "Apps you get from the Store show up here."
                             : "Nothing here yet."
                        font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
                        color: Theme.textDim
                    }
                }
                // Search: apps newer than this Store are on Flathub only when the user asks (it sends the
                // search words to flathub.org).
                footer: Column {
                    width: listPage.contentW - 10
                    visible: root.q !== ""
                    height: visible ? implicitHeight : 0
                    spacing: 0
                    Item {
                        visible: root.online.length === 0
                        width: parent.width
                        height: 54
                        Button {
                            y: 14
                            text: root.onlineSearching ? "Searching Flathub" : "Search Flathub online for newer apps"
                            glyph: Icons.globe
                            busy: root.onlineSearching
                            enabled: !root.onlineSearching
                            variant: "soft"; size: 34
                            onClicked: root.searchOnline(root.query.trim())
                        }
                    }
                    Text {
                        visible: root.online.length > 0
                        topPadding: 24; bottomPadding: 12
                        text: "On Flathub"
                        font.family: Theme.fontDisplay; font.pixelSize: 18; font.weight: Font.Medium
                        color: Theme.text
                    }
                    Grid {
                        id: onlineGrid
                        visible: root.online.length > 0
                        width: parent.width
                        columns: listPage.cols
                        spacing: 10
                        Repeater {
                            model: root.online
                            StoreCard {
                                required property string modelData
                                appId: modelData
                                view: root
                                width: (onlineGrid.width - (listPage.cols - 1) * 10) / listPage.cols
                                height: 74
                            }
                        }
                    }
                }
            }

            ScrollPane {
                id: detailPane
                anchors.fill: parent
                visible: !!root.detailId
                topPadding: 20; bottomPadding: 28
                Loader {
                    x: 22
                    width: detailPane.width - 44
                    active: !!root.detailApp
                    sourceComponent: AppDetail {
                        width: detailPane.width - 44
                        app: root.detailApp
                        softwareRender: root.softwareRender
                        versionsLoading: !!root.detailApp && root.versionsLoading === root.detailApp.id
                        onBackClicked: root.closeDetail()
                        onGetClicked: root.getApp(root.detailApp.id)
                        onOpenClicked: root.openApp(root.detailApp.id)
                        onRemoveClicked: root.removeApp(root.detailApp.id)
                        onCancelClicked: root.cancelApp(root.detailApp.id)
                        onHomepageClicked: root.openHomepage(root.detailApp.id, root.detailApp.home)
                        onInstallSpec: (spec) => root.installTool(root.detailApp.id, spec)
                        onDefaultClicked: (version) => root.setToolDefault(root.detailApp.id, version)
                        onRemoveVersionClicked: (version) => root.removeToolVersion(root.detailApp.id, version)
                        onOtherVersionsClicked: root.otherVersions(root.detailApp.id)
                    }
                }
                Text {
                    visible: !!root.detailId && !root.detailApp
                    x: 22
                    text: "This app isn't in the Store."
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
                    color: Theme.textDim
                }
            }

            ScrollPane {
                id: updatesPane
                anchors.fill: parent
                visible: root.mode === "updates" && !root.detailId
                topPadding: 20; bottomPadding: 28
                Loader {
                    x: 22
                    width: updatesPane.width - 44
                    active: updatesPane.visible
                    sourceComponent: UpdatesPage {
                        width: updatesPane.width - 44
                        updates: root.updates
                        checked: root.updatesChecked
                        checking: root.checkingUpdates
                        error: root.updatesError
                        onCheckClicked: root.checkUpdates()
                        onUpdateClicked: (id) => root.updateApp(id)
                        onUpdateAllClicked: root.updateAll()
                    }
                }
            }
        }
    }
}
