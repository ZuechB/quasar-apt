import QtQuick
import Quasar
import "services.js" as S

// A service's console (its own window, services/LogWindow.qml): what it writes, live, and why it stopped.
// Pure: lines come in through append(batch) (LogList); everything else through properties; actions go out
// through signals.
//   item      the service's row (status, why it stopped, start/stop/restart where the row allows them), or
//             null (a unit the app doesn't list yet: just the log)
//   combined  every service's log (a service column; clicking a name opens that service's own console)
//   notice    shown above the log (this account can't read system services' logs)
//   ended     the stream stopped by itself: why (a Retry button)
Item {
    id: root
    property string title: ""
    property var item: null
    property bool combined: false
    property string notice: ""
    property bool live: false
    property string ended: ""
    property bool busy: false
    property var unitNames: ({})
    property real now: Date.now()
    signal act(string name)
    signal openTerminal()
    signal openUnit(var line)
    signal copyText(string text)
    signal retry()

    property var selected: null
    function append(batch) { log.append(batch) }
    function clear() { log.clear(); selected = null }
    readonly property int lineCount: log.total
    readonly property int shownCount: log.shownCount
    readonly property bool following: log.following
    readonly property alias logList: log                 // previews and tests
    function setQuery(q) { search.text = q; log.query = q }
    function setLevel(l) { log.level = l }

    // A unit the "Every service" list knows (source "unit") has systemd's states; Services' own rows the
    // template's (statusOf: "Up 2h 5m", "Starts when it's needed" …).
    readonly property var status: !item ? null : item.source === "unit" ? S.unitStatus(item) : S.statusOf(item, now)
    readonly property string why: S.whyStopped(item)
    readonly property color statusTone: !status ? Theme.textDim : status.color === "fail" ? Theme.danger
                                      : status.color === "accent" ? Theme.accent : status.color === "sched" ? "#B9A4FF" : Theme.textDim

    // ---- header: status, why it stopped, actions ------------------------------------------------------
    Item {
        id: header
        anchors { left: parent.left; right: parent.right; top: parent.top; leftMargin: 18; rightMargin: 18; topMargin: 12 }
        height: Math.max(34, headText.implicitHeight)
        Row {
            id: headText
            anchors { left: parent.left; right: actions.left; rightMargin: 14; verticalCenter: parent.verticalCenter }
            spacing: 10
            StatusPill {
                id: pill
                anchors.verticalCenter: parent.verticalCenter
                visible: !!root.status || root.combined
                text: root.combined ? "Every service" : root.status ? root.status.label : ""
                tone: root.combined ? Theme.accent : root.statusTone
                pulse: !!root.item && (root.item.status === "starting")
            }
            Text {
                anchors.verticalCenter: parent.verticalCenter
                width: headText.width - (pill.visible ? pill.width + 10 : 0)
                text: root.combined ? "What every service on this PC writes, as it happens. Click a name to open that one."
                    : root.why !== "" ? root.why
                    : root.status ? (root.status.meta || "") : "What it writes, as it happens."
                textFormat: Text.PlainText
                wrapMode: Text.Wrap
                maximumLineCount: 2
                elide: Text.ElideRight
                font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
                color: root.why !== "" ? (root.item && root.item.status === "failed" ? "#FF9B9B" : Theme.amber) : Theme.textMuted
            }
        }
        Row {
            id: actions
            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
            spacing: 8
            Button {
                visible: !!root.item && S.can(root.item, "start") && root.item.status !== "running" && root.item.status !== "starting"
                variant: "primary"; size: 32; glyph: Icons.play2; text: "Start"
                enabled: !root.busy
                onClicked: root.act("start")
            }
            Button {
                visible: !!root.item && S.can(root.item, "restart") && (root.item.status === "running" || root.item.status === "starting")
                variant: "soft"; size: 32; glyph: Icons.refresh; text: "Restart"
                enabled: !root.busy
                onClicked: root.act("restart")
            }
            Button {
                visible: !!root.item && S.can(root.item, "stop") && (root.item.status === "running" || root.item.status === "starting")
                variant: "soft"; size: 32; glyph: Icons.stop; text: "Stop"
                enabled: !root.busy
                onClicked: root.act("stop")
            }
            Button {
                variant: "soft"; size: 32; glyph: Icons.terminal; text: "Open in Terminal"
                onClicked: root.openTerminal()
            }
        }
    }

    // ---- toolbar: following, what to show, search, copy -----------------------------------------------------
    Item {
        id: toolbar
        anchors { left: parent.left; right: parent.right; top: header.bottom; leftMargin: 18; rightMargin: 18; topMargin: 12 }
        height: 34
        Pressable {
            id: followPill
            anchors { left: parent.left; verticalCenter: parent.verticalCenter }
            width: followInner.width
            height: 22
            radius: 11
            kind: "plain"
            enabled: !log.following
            accessibleName: log.following ? "Following new lines" : "Paused. Go to the newest line"
            onClicked: log.jumpToEnd()
            StatusPill {
                id: followInner
                text: log.following ? (root.live ? "Following" : "Loading…")
                    : log.newCount > 0 ? "Paused · " + log.newCount + " new" : "Paused"
                tone: log.following ? Theme.accent : Theme.amber
                pulse: log.following && root.live && root.ended === ""
            }
        }
        Segmented {
            id: levels
            anchors { left: followPill.right; leftMargin: 12; verticalCenter: parent.verticalCenter }
            width: 246
            height: 32
            model: ["All", "Problems", "Errors"]
            accessibleName: "Show"
            currentIndex: Math.max(0, ["all", "problems", "errors"].indexOf(log.level))
            onPicked: (i) => log.level = ["all", "problems", "errors"][i]
        }
        SearchField {
            id: search
            anchors { left: levels.right; leftMargin: 12; verticalCenter: parent.verticalCenter }
            width: Math.max(150, Math.min(260, toolbar.width - levels.x - levels.width - copyBtn.width - 40))
            implicitHeight: 32
            placeholder: root.combined ? "Search lines or services" : "Search lines"
            onEdited: (t) => log.query = t
            onEscapePressed: { text = ""; log.query = "" }
        }
        Button {
            id: copyBtn
            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
            variant: "ghost"; size: 32; glyph: Icons.copy; text: "Copy all"
            enabled: log.shownCount > 0
            onClicked: root.copyText(log.shownText())
        }
    }

    // ---- notices ---------------------------------------------------------------------------------------------
    Column {
        id: notices
        anchors { left: parent.left; right: parent.right; top: toolbar.bottom; leftMargin: 18; rightMargin: 18; topMargin: 10 }
        spacing: 8
        Banner {
            width: parent.width
            visible: root.notice !== ""
            tone: "warning"
            title: root.notice
        }
        Banner {
            width: parent.width
            visible: root.ended !== ""
            tone: "error"
            title: "The log stopped."
            message: root.ended
            actionText: "Try again"
            onActionClicked: root.retry()
        }
    }

    // ---- the log ---------------------------------------------------------------------------------------------
    Rectangle {
        id: box
        anchors { left: parent.left; right: parent.right; top: notices.bottom; bottom: strip.visible ? strip.top : parent.bottom
                  leftMargin: 18; rightMargin: 18; topMargin: notices.height > 0 ? 10 : 2; bottomMargin: strip.visible ? 10 : 18 }
        radius: 12
        color: "#06070B"
        border.width: 1
        border.color: Theme.white(0.06)
        LogList {
            id: log
            anchors.fill: parent
            anchors.margins: 8
            showUnit: root.combined
            unitNames: root.unitNames
            emptyText: root.notice !== "" ? "" : !root.live ? "Reading its log…"
                     : root.combined ? "No service has written anything yet."
                     : "Nothing here yet. Lines appear as soon as it writes them."
            onLineClicked: (l) => root.selected = l
            onLineMenu: (l, x, y) => {
                root.selected = l
                const p = log.mapToItem(root, x, y)
                menu.show(p.x, p.y)
            }
            onUnitClicked: (l) => root.openUnit(l)
        }
    }

    // ---- the clicked line, in full ------------------------------------------------------------------
    Rectangle {
        id: strip
        visible: !!root.selected
        anchors { left: parent.left; right: parent.right; bottom: parent.bottom; leftMargin: 18; rightMargin: 18; bottomMargin: 16 }
        height: Math.min(180, stripText.contentHeight + 52)
        radius: 12
        color: Theme.white(0.04)
        border.width: 1
        border.color: Theme.white(0.06)
        Text {
            id: stripMeta
            anchors { left: parent.left; right: stripButtons.left; top: parent.top; leftMargin: 14; rightMargin: 10; topMargin: 10 }
            text: {
                const l = root.selected
                if (!l) return ""
                const when = new Date(l.ts * 1000)
                return when.toLocaleString(Qt.locale(), "ddd d MMM, HH:mm:ss") + "  ·  " + (l.acct ? l.acct + ": " : "") + (l.unit || "")
                     + (l.src === "systemd" ? "  ·  from systemd" : "") + (l.lvl === "err" ? "  ·  error" : l.lvl === "warn" ? "  ·  warning" : "")
            }
            elide: Text.ElideRight
            font.family: Theme.fontMono; font.pointSize: Theme.pt(10.5)
            color: Theme.textFaint
        }
        Row {
            id: stripButtons
            anchors { right: parent.right; top: parent.top; rightMargin: 8; topMargin: 4 }
            spacing: 2
            Button { variant: "ghost"; size: 28; glyph: Icons.copy; text: "Copy"; onClicked: root.copyText(root.selected ? root.selected.m : "") }
            Button { variant: "ghost"; size: 28; glyph: Icons.x; accessibleName: "Close"; onClicked: { root.selected = null; log.selectedN = -1 } }
        }
        Flickable {
            anchors { left: parent.left; right: parent.right; top: stripMeta.bottom; bottom: parent.bottom
                      leftMargin: 14; rightMargin: 14; topMargin: 6; bottomMargin: 10 }
            clip: true
            contentHeight: stripText.contentHeight
            boundsBehavior: Flickable.StopAtBounds
            TextEdit {
                id: stripText
                width: parent.width
                readOnly: true
                selectByMouse: true
                textFormat: TextEdit.PlainText
                wrapMode: TextEdit.WrapAnywhere
                text: root.selected ? root.selected.m : ""
                font.family: Theme.fontMono; font.pointSize: Theme.pt(12)
                color: !root.selected ? Theme.text3 : root.selected.lvl === "err" ? Theme.danger
                     : root.selected.lvl === "warn" ? Theme.amber : Theme.text2
                selectionColor: Theme.alpha(Theme.accent, 0.35)
                selectedTextColor: Theme.text
            }
        }
    }

    // ---- right-click: copy -----------------------------------------------------------------------------------
    Item {
        id: menu
        anchors.fill: parent
        property bool open: false
        property real menuX: 0
        property real menuY: 0
        visible: open
        z: 900
        function show(x, y) { menuX = x; menuY = y; open = true; card.forceActiveFocus() }
        MouseArea {
            anchors.fill: parent
            acceptedButtons: Qt.AllButtons
            onPressed: menu.open = false
            onWheel: (w) => { menu.open = false }
        }
        MouseArea { x: card.x; y: card.y; width: card.width; height: card.height; acceptedButtons: Qt.AllButtons }
        ContextMenu {
            id: card
            x: Math.max(6, Math.min(menu.menuX, menu.width - width - 6))
            y: menu.menuY + height > menu.height - 6 ? Math.max(6, menu.menuY - height) : menu.menuY
            width: implicitWidth
            height: implicitHeight
            items: [{ key: "line", label: "Copy line", glyph: Icons.copy },
                    { key: "all", label: "Copy all", glyph: Icons.list }].concat(root.combined && root.selected && !root.selected.acct
                    ? [{ sep: true }, { key: "unit", label: "Open " + log.nameOf(root.selected) + "'s log", glyph: Icons.terminal }] : [])
            focus: true
            onActivated: (key) => {
                menu.open = false
                if (key === "line" && root.selected) root.copyText(root.selected.m)
                else if (key === "all") root.copyText(log.shownText())
                else if (key === "unit" && root.selected) root.openUnit(root.selected)
            }
            Keys.onEscapePressed: menu.open = false
            Accessible.role: Accessible.PopupMenu
        }
    }
}
