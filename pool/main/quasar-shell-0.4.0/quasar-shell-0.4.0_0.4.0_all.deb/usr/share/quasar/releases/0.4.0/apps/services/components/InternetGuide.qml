import QtQuick
import Quasar
import "services.js" as S

// "Let players join from the internet": a page over the list and the detail, for a server with an
// internet port. Four steps, each with the exact values (and a Copy button): a fixed address for this
// PC, the router's port forward (that one port only: never UPnP or DMZ), a DNS-only name at Cloudflare
// that follows the router's dynamic DNS, and a test from outside the home (the firewall's counter for
// this server rises as packets arrive). Written for UniFi first, with a line for other routers.
Rectangle {
    id: root
    property var item: ({})
    property var m: ({})
    property real now: Date.now()
    signal act(string name, var a, var b, var c)
    signal copy(string text)
    function call(name, b, c) { root.act(name, root.item.key, b === undefined ? null : b, c === undefined ? null : c) }

    color: Theme.windowOpaque

    readonly property var server: item && item.server ? item.server : ({ ports: [] })
    readonly property var port: S.internetPorts(server.ports)[0] || { proto: "udp", port: 0, label: "" }
    readonly property string portWord: S.portText(port)
    readonly property var lan: m.lan || null
    readonly property string ip: lan && lan.ip ? lan.ip : "this PC’s address"
    readonly property var pub: server["public"] || null
    readonly property string name: pub && pub.name ? pub.name : ""
    readonly property string via: pub && pub.via ? pub.via : ""
    // "animalgo.zuech.io" -> host "animalgo" in zone "zuech.io" (Cloudflare's Name field takes the host).
    readonly property string host: name.indexOf(".") > 0 ? name.slice(0, name.indexOf(".")) : name
    readonly property string zone: name.indexOf(".") > 0 ? name.slice(name.indexOf(".") + 1) : ""
    readonly property var dns: m.dns || ({})
    readonly property var stats: m.stats || null
    readonly property var wan: stats && stats.wan ? stats.wan : null

    // Entrance: the template's rowIn.
    opacity: 0
    Component.onCompleted: enter.start()
    NumberAnimation { id: enter; target: root; property: "opacity"; to: 1; duration: Motion.dur(300) }

    component Step: Rectangle {
        id: step
        property int n: 1
        property string title: ""
        default property alias body: stepBody.data
        width: parent ? parent.width : 600
        height: stepBody.implicitHeight + 70
        radius: 16
        color: Theme.white(0.03)
        border.width: 1
        border.color: Theme.white(0.07)
        Rectangle {
            x: 18; y: 18
            width: 26; height: 26; radius: 13
            color: Theme.alpha(Theme.accent, 0.14)
            border.width: 1
            border.color: Theme.accentLine
            Text { anchors.centerIn: parent; text: step.n; font.family: Theme.fontMono; font.pointSize: Theme.pt(12); font.weight: Font.DemiBold; color: Theme.accent }
        }
        Text {
            x: 56; y: 20
            width: parent.width - 74
            text: step.title
            textFormat: Text.PlainText
            wrapMode: Text.Wrap
            font.family: Theme.fontUi; font.pointSize: Theme.pt(15); font.weight: Font.DemiBold
            color: Theme.text
        }
        Column {
            id: stepBody
            x: 56; y: 52
            width: parent.width - 74
            spacing: 10
        }
    }
    component Para: Text {
        width: parent ? parent.width : 400
        textFormat: Text.PlainText
        wrapMode: Text.Wrap
        lineHeight: 1.2
        font.family: Theme.fontUi; font.pointSize: Theme.pt(13)
        color: Theme.text3
    }
    // One value to type into the router or Cloudflare: label, value (mono) and Copy.
    component Value: Item {
        id: val
        property string label: ""
        property string value: ""
        property bool strong: false
        width: parent ? parent.width : 400
        height: 36
        Rectangle { anchors.fill: parent; radius: 9; color: val.strong ? Theme.alpha(Theme.accent, 0.08) : Theme.white(0.035) }
        Text {
            x: 12
            width: 150
            anchors.verticalCenter: parent.verticalCenter
            text: val.label
            elide: Text.ElideRight
            font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
            color: Theme.textMuted
        }
        Text {
            anchors { left: parent.left; leftMargin: 170; right: cp.left; rightMargin: 8; verticalCenter: parent.verticalCenter }
            text: val.value
            textFormat: Text.PlainText
            elide: Text.ElideMiddle
            font.family: Theme.fontMono; font.pointSize: Theme.pt(12.5)
            color: val.strong ? Theme.accent : Theme.text2
        }
        Pressable {
            id: cp
            anchors { right: parent.right; rightMargin: 4; verticalCenter: parent.verticalCenter }
            width: 28; height: 28; radius: 7; kind: "hov"
            accessibleName: "Copy " + val.value
            onClicked: root.copy(val.value)
            QIcon { anchors.centerIn: parent; path: Icons.copy; size: 13; strokeWidth: 2; color: Theme.textMuted }
        }
    }

    ScrollPane {
        id: pane
        anchors.fill: parent
        topPadding: 20
        bottomPadding: 30
        Column {
            x: Math.max(24, (pane.width - 720) / 2)
            width: Math.min(720, pane.width - 48)
            spacing: 16

            Button {
                variant: "ghost"; size: 30; glyph: Icons.back; text: "Back to " + (root.item.name || "the server")
                onClicked: root.call("closeGuide")
            }
            Column {
                width: parent.width
                spacing: 6
                Text {
                    width: parent.width
                    text: "Let players join from the internet"
                    wrapMode: Text.Wrap
                    font.family: Theme.fontDisplay; font.pixelSize: 26; font.weight: Font.Medium
                    color: Theme.text
                }
                Text {
                    width: parent.width
                    text: (root.item.name || "") + "  ·  " + root.portWord + (root.port.label ? " (" + root.port.label + ")" : "")
                    textFormat: Text.PlainText
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(13)
                    color: Theme.textDim
                }
            }
            Para {
                text: "Players outside your home reach this PC through your router. It takes four steps and about ten minutes. Only "
                      + root.portWord + " opens: nothing else on this PC can be reached, and the server runs as its own account."
            }

            // 1 ---------------------------------------------------------------------------------------
            Step {
                n: 1
                title: "Give this PC a fixed address"
                Para { text: "Your router hands out addresses on your network. Ask it to always give this PC the same one, so the forward in step 2 keeps pointing here." }
                Value { label: "This PC"; value: root.lan && root.lan.ip ? root.lan.ip : "Not connected"; strong: true }
                Value { visible: !!(root.lan && root.lan.mac); label: "Its network adapter"; value: root.lan && root.lan.mac ? root.lan.mac : "" }
                Para {
                    text: "UniFi: open UniFi Network › Client Devices, pick this PC (its adapter is above), open Settings and turn on Fixed IP Address with "
                          + root.ip + ". Other routers call it a DHCP reservation or a static lease."
                }
            }

            // 2 ---------------------------------------------------------------------------------------
            Step {
                n: 2
                title: "Forward " + root.portWord + " to this PC"
                Para { text: "UniFi: in UniFi Network, search Settings for “Port Forwarding” and create a rule with these values:" }
                Value { label: "Name"; value: root.item.name || "Game server" }
                Value { label: "WAN interface"; value: "Primary (WAN1)" }
                Value { label: "From"; value: "Any" }
                Value { label: "Port"; value: String(root.port.port); strong: true }
                Value { label: "Forward IP"; value: root.lan && root.lan.ip ? root.lan.ip : "this PC’s fixed address"; strong: true }
                Value { label: "Forward port"; value: String(root.port.port) }
                Value { label: "Protocol"; value: root.port.proto === "tcp" ? "TCP" : "UDP"; strong: true }
                Rectangle {
                    width: parent.width
                    height: warnText.implicitHeight + 20
                    radius: 10
                    color: Theme.alpha(Theme.amber, 0.08)
                    border.width: 1
                    border.color: Theme.alpha(Theme.amber, 0.3)
                    Text {
                        id: warnText
                        x: 12; y: 10
                        width: parent.width - 24
                        text: "Only this port. Leave UPnP and DMZ off: they open far more than this server needs."
                        wrapMode: Text.Wrap
                        font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
                        color: Theme.text2
                    }
                }
                Para { text: "Other routers put it under NAT, Virtual servers or Port forwarding." }
            }

            // 3 ---------------------------------------------------------------------------------------
            Step {
                n: 3
                title: "Point your name at your home"
                Para {
                    text: root.name
                        ? "Players type a name, not your address (which your internet provider can change). In Cloudflare, open " + (root.zone || "your domain") + " › DNS › Records › Add record:"
                        : "Players type a name, not your address (which your internet provider can change). Add the name in Settings, then make this record in Cloudflare › DNS › Records:"
                }
                Value { label: "Type"; value: "CNAME" }
                Value { label: "Name"; value: root.host || "game"; strong: true }
                Value { label: "Target"; value: root.via || "your router’s dynamic DNS name"; strong: !!root.via }
                Value { label: "Proxy status"; value: "DNS only (grey cloud)"; strong: true }
                Value { label: "TTL"; value: "Auto" }
                Para {
                    text: "The cloud must be grey. Cloudflare’s proxy (orange) and its tunnels only carry websites, so game packets would never arrive. "
                          + (root.via ? "Your router keeps " + root.via + " pointed at your home, and this name follows it." : "")
                }
                Row {
                    spacing: 8
                    Button {
                        visible: root.name !== ""
                        variant: "soft"; size: 34; glyph: Icons.search; text: "Check " + root.name
                        busy: !!root.dns.checking
                        enabled: !root.dns.checking
                        onClicked: root.call("dnsCheck", root.name)
                    }
                    Button {
                        variant: "ghost"; size: 34; glyph: Icons.gear; text: root.name ? "Change the name…" : "Add the name…"
                        onClicked: root.call("openSettings")
                    }
                }
                Column {
                    readonly property var r: root.dns.result || null
                    visible: !!r && !root.dns.checking
                    width: parent.width
                    spacing: 4
                    Row {
                        width: parent.width
                        spacing: 8
                        QIcon {
                            readonly property string tone: parent.parent.r ? S.dnsTone(parent.parent.r.verdict) : ""
                            path: tone === "ok" ? Icons.check : Icons.alert
                            size: 15; strokeWidth: 2.2
                            color: tone === "ok" ? Theme.mint : tone === "warn" ? Theme.amber : Theme.danger
                        }
                        Text {
                            width: parent.width - 23
                            text: parent.parent.r ? parent.parent.r.message || "" : ""
                            textFormat: Text.PlainText
                            wrapMode: Text.Wrap
                            font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
                            color: Theme.text2
                        }
                    }
                    Repeater {
                        model: parent.r ? (parent.r.chain || []).concat((parent.r.addresses || []).map(a => "→ " + a)) : []
                        delegate: Text {
                            required property var modelData
                            x: 23
                            text: modelData
                            textFormat: Text.PlainText
                            font.family: Theme.fontMono; font.pointSize: Theme.pt(11.5)
                            color: Theme.textDim
                        }
                    }
                }
            }

            // 4 ---------------------------------------------------------------------------------------
            Step {
                n: 4
                title: "Test from outside your home"
                Para { text: "A test from your own Wi-Fi only shows that your router loops back, so use a phone’s mobile data:" }
                Para { text: "1.  Turn Wi-Fi off on a phone and share its mobile data (hotspot) with the device that plays." }
                Para { text: "2.  In the game, join " + (root.name ? root.name + ":" + root.port.port : "your public address on port " + root.port.port) + "." }
                Para { text: "3.  Watch the count below: it goes up as packets arrive from outside, and the log shows who joined." }
                Para { text: "Or, from any computer outside your home, send one packet and watch the count:" }
                Value { label: "Command"; value: "echo hi | nc -u -w1 " + (root.name || "your-name") + " " + root.port.port }
                Rectangle {
                    width: parent.width
                    height: 56
                    radius: 12
                    color: root.wan && root.wan.packets > 0 ? Theme.alpha(Theme.mint, 0.08) : Theme.white(0.035)
                    border.width: 1
                    border.color: root.wan && root.wan.packets > 0 ? Theme.alpha(Theme.mint, 0.3) : Theme.white(0.06)
                    Column {
                        anchors { left: parent.left; leftMargin: 14; right: parent.right; rightMargin: 14; verticalCenter: parent.verticalCenter }
                        spacing: 3
                        Text { text: "From outside your home"; font.family: Theme.fontUi; font.pixelSize: 11; color: Theme.textFaint }
                        Text {
                            width: parent.width
                            text: !root.m.netguard ? "The count needs the firewall on (Settings › Network & Internet)."
                                : root.item.status !== "running" ? "Start the server first."
                                : !root.wan ? "Counting…"
                                : root.wan.packets === 0 ? "No packets from outside yet."
                                : S.grouped(root.wan.packets) + (root.wan.packets === 1 ? " packet" : " packets") + " arrived"
                                  + (root.stats && root.stats.wanAt ? ", the last " + S.ago(root.stats.wanAt, root.now) : "") + ". It works."
                            elide: Text.ElideRight
                            font.family: Theme.fontUi; font.pointSize: Theme.pt(13); font.weight: Font.Medium
                            color: root.wan && root.wan.packets > 0 ? Theme.mint : Theme.text3
                        }
                    }
                }
                Para {
                    text: "Nothing arrives? Check that UniFi’s WAN address (UniFi Network › Dashboard) matches the address your name points at. If UniFi shows an address starting with 100.64 to 100.127, or 10., 172.16 to 172.31 or 192.168, your provider shares one address between customers and forwarding can’t work; ask them for a public address."
                    color: Theme.textDim
                    font.pointSize: Theme.pt(12.5)
                }
            }
        }
    }
}
