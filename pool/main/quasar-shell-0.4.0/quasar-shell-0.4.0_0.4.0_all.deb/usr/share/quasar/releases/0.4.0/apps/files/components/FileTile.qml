import QtQuick
import Quasar

// One item in the grid (template Files tile): 52px glyph box with a 30px kind glyph (or the picture
// itself), the name below on up to two lines. Selected: accent .14 wash + .35 hairline; hover: lift
// 4px + scale 1.05 + white .06; pressed: scale .94 (spring .5s); a drop target: a stronger wash.
// Visual only: ItemsView does all the pointer work for every tile at once.
Item {
    id: root
    property var item: null              // FileKit.row()
    property bool selected: false
    property bool hovered: false
    property bool pressed: false
    property bool dropTarget: false
    property bool dimmed: false          // being dragged
    property bool cursor: false          // keyboard cursor on an unselected item
    property bool renaming: false        // the rename field covers the label
    property bool focusedView: true      // the view has the keyboard (full-strength selection)
    property bool thumbs: true           // picture previews (off in Lite)
    property var cache: null             // services/Thumbs.qml (null: no saved thumbnails, e.g. previews)

    // A picture's saved thumbnail when there is one; otherwise the picture, saved as one once loaded.
    readonly property string cacheName: cache && item && item.thumb ? cache.key(item) : ""
    readonly property bool fromCache: cacheName !== "" && cache.has(cacheName)
    readonly property string pictureUrl: !thumbs || !item || !item.thumb ? ""
                                       : fromCache ? Theme.fileUrl(cache.dir + "/" + cacheName) : item.thumb
    function keep() {
        const name = cacheName, src = String(img.source)
        if (!name || fromCache || !img.implicitWidth) return
        img.grabToImage((r) => {
            if (String(img.source) !== src || img.status !== Image.Ready) return     // reused for another file
            if (r.saveToFile(root.cache.dir + "/" + name)) root.cache.saved(name)
        }, Qt.size(img.implicitWidth, img.implicitHeight))
    }

    readonly property real _wash: dropTarget ? 0.24 : focusedView ? 0.14 : 0.08
    readonly property bool _lit: selected || dropTarget

    opacity: dimmed ? 0.4 : 1

    Item {
        id: face
        anchors.fill: parent
        transform: Translate {
            y: root.hovered && !root.pressed ? -4 : 0
            Behavior on y { NumberAnimation { duration: Motion.dur(Motion.tile); easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.spring } }
        }
        scale: root.pressed ? 0.94 : root.hovered ? 1.05 : 1
        Behavior on scale { NumberAnimation { duration: Motion.dur(Motion.tile); easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.spring } }

        Rectangle {
            anchors.fill: parent
            radius: 14
            color: root._lit ? Theme.alpha(Theme.accent, root._wash) : root.hovered ? Theme.white(0.06) : "transparent"
            border.width: root._lit || root.cursor ? 1 : 0
            border.color: root._lit ? Theme.alpha(Theme.accent, root.dropTarget ? 0.6 : root.focusedView ? 0.35 : 0.2)
                                    : Theme.alpha(Theme.accent, 0.5)
            Behavior on color { ColorAnimation { duration: Motion.dur(Motion.hover) } }
        }

        Item {
            id: glyphBox
            x: (parent.width - 52) / 2
            y: 12
            width: 52; height: 52
            QIcon {
                visible: !photo.visible
                anchors.centerIn: parent
                path: root.item ? Icons.get(root.item.glyph) : ""
                size: 30; strokeWidth: 1.6
                color: root.item && root.item.hue ? root.item.hue : Theme.text3
                fill: root.item && root.item.fill ? root.item.fill : "transparent"
            }
            // A picture: the image itself in a thin light frame (no masks: software rendering).
            Rectangle {
                id: photo
                visible: root.pictureUrl !== "" && img.status === Image.Ready
                anchors.centerIn: parent
                width: img.width * img.scale + 4; height: img.height * img.scale + 4
                radius: 3
                color: Qt.rgba(0.93, 0.94, 0.97, 0.95)
                // At its decoded size (at most 112 px), scaled down to fit: a grab of it is the
                // thumbnail itself, pixel for pixel.
                Image {
                    id: img
                    anchors.centerIn: parent
                    width: implicitWidth; height: implicitHeight
                    scale: implicitWidth > 0 ? Math.min(56 / implicitWidth, 50 / implicitHeight, 1) : 1
                    source: root.pictureUrl
                    sourceSize: Qt.size(112, 112)
                    asynchronous: true
                    autoTransform: true
                    smooth: true
                    onStatusChanged: if (status === Image.Ready) root.keep()
                }
            }
        }

        Text {
            x: 6
            y: 72
            width: parent.width - 12
            visible: !root.renaming
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.Wrap
            maximumLineCount: 2
            elide: Text.ElideRight
            text: root.item ? root.item.name : ""
            textFormat: Text.PlainText
            font.family: Theme.fontUi; font.pixelSize: 12
            lineHeight: 1.3
            color: Theme.text2
        }
    }
}
