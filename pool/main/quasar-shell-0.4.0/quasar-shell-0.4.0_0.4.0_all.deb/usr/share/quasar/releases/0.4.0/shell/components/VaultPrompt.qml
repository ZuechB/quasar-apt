import QtQuick
import Quasar

// Vault's questions (services/VaultPrompts.qml): a browser wants to connect, a site wants your saved
// passwords for the first time, or a site makes or uses a passkey. Every one takes your account
// password (Vault checks it). Dims the screen like the system password sheet; Esc cancels. Pure view.
//   kind: connect | fill | passkey-save | passkey-use | delete | unlock
Item {
    id: root
    property string kind: "passkey-use"
    property string browser: ""
    property string site: ""
    property string username: ""
    property int count: 0
    property var accounts: []                // passkey-use: [{ key, label, sub }]
    property string choice: ""               // the chosen account's key
    property bool busy: false
    property string message: ""
    property bool messageIsError: false
    signal submitted(string password, string choice)
    signal picked(string key)
    signal cancelled()

    function focusInput() { field.focusInput() }
    function clear() { field.text = "" }
    function setText(t) { field.text = t }          // previews

    readonly property string who: browser !== "" ? browser : "A browser"
    readonly property string title: kind === "connect" ? "Connect " + who + " to Vault?"
        : kind === "fill" ? "Use your saved passwords on " + site + "?"
        : kind === "passkey-save" ? "Save a passkey for " + site + "?"
        : kind === "passkey-use" ? "Sign in to " + site + " with a passkey"
        : kind === "delete" ? "Delete your login for " + site + "?"
        : "Unlock Vault"
    readonly property string detail: kind === "connect" ? who + " can then fill and save your passwords, and make and use passkeys. It asks before each new site and each passkey."
        : kind === "fill" ? who + " fills " + (count === 1 ? "your saved login" : "your " + count + " saved logins") + " for " + site + ". Vault remembers that you allowed this site."
        : kind === "passkey-save" ? (username !== "" ? "As " + username + ". " : "") + "It stays on this PC, in Vault. You'll sign in to " + site + " with it and your password, without the site's password."
        : kind === "passkey-use" ? (accounts.length > 1 ? "Choose the account, then type your password." : "As " + (accounts.length ? accounts[0].label : username) + ".")
        : kind === "delete" ? who + " asked to delete " + (username !== "" ? username + "'s" : "this") + " saved login."
        : who + " needs your saved passwords. They stay locked until you type your password once."
    readonly property string action: kind === "connect" ? "Connect" : kind === "fill" ? "Allow"
        : kind === "passkey-save" ? "Save passkey" : kind === "passkey-use" ? "Sign in"
        : kind === "delete" ? "Delete" : "Unlock"

    Rectangle {
        anchors.fill: parent
        color: Qt.rgba(0, 0, 0, 0.5)
        MouseArea { anchors.fill: parent }
    }

    Rectangle {
        id: card
        anchors.centerIn: parent
        width: Math.min(440, parent.width - 40)
        height: col.implicitHeight + 48
        radius: 22
        color: Theme.solid
        border.width: 1
        border.color: Theme.white(0.11)
        Accessible.role: Accessible.Dialog
        Accessible.name: root.title

        Column {
            id: col
            x: 24; y: 24
            width: parent.width - 48
            spacing: 14

            Row {
                spacing: 12
                Rectangle {
                    width: 46; height: 46; radius: 15
                    color: Theme.alpha(Theme.amber, 0.14)
                    QIcon { anchors.centerIn: parent; path: root.kind.startsWith("passkey") ? Icons.key : Icons.shield; size: 22; strokeWidth: 1.9; color: Theme.amber }
                }
                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: "Vault"
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(13); font.weight: Font.Medium
                    color: Theme.text3
                }
            }
            Text {
                width: parent.width
                text: root.title
                wrapMode: Text.Wrap
                textFormat: Text.PlainText
                font.family: Theme.fontDisplay; font.pixelSize: 20; font.weight: Font.Medium
                color: Theme.text
            }
            Text {
                width: parent.width
                text: root.detail
                wrapMode: Text.Wrap
                textFormat: Text.PlainText
                font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
                color: Theme.text3
            }
            // Several accounts on this site: pick one.
            Column {
                width: parent.width
                spacing: 6
                visible: root.kind === "passkey-use" && root.accounts.length > 1
                Repeater {
                    model: root.kind === "passkey-use" && root.accounts.length > 1 ? root.accounts : []
                    delegate: Pressable {
                        id: acct
                        required property var modelData
                        readonly property bool current: root.choice === modelData.key
                        width: parent.width
                        implicitHeight: 48
                        radius: 12
                        kind: "hov"
                        color: current ? Theme.alpha(Theme.accent, 0.12) : Theme.white(0.03)
                        borderColor: current ? Theme.accentLine : Theme.white(0.06)
                        accessibleName: modelData.label
                        onClicked: root.picked(modelData.key)
                        Row {
                            x: 12
                            anchors.verticalCenter: parent.verticalCenter
                            spacing: 10
                            UserAvatar { anchors.verticalCenter: parent.verticalCenter; size: 28; name: acct.modelData.label }
                            Column {
                                anchors.verticalCenter: parent.verticalCenter
                                Text {
                                    text: acct.modelData.label
                                    textFormat: Text.PlainText
                                    font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
                                    color: Theme.text
                                }
                                Text {
                                    visible: (acct.modelData.sub || "") !== "" && acct.modelData.sub !== acct.modelData.label
                                    text: acct.modelData.sub || ""
                                    textFormat: Text.PlainText
                                    font.family: Theme.fontUi; font.pointSize: Theme.pt(12)
                                    color: Theme.textDim
                                }
                            }
                        }
                    }
                }
            }
            TextField {
                id: field
                width: parent.width
                glyph: Icons.lock
                placeholder: "Your account password"
                password: true
                error: root.messageIsError && root.message !== ""
                enabled: !root.busy
                onAccepted: if (text !== "" && !root.busy) root.submitted(text, root.choice)
                onEscapePressed: root.cancelled()
            }
            Text {
                width: parent.width
                visible: root.message !== ""
                text: root.message
                wrapMode: Text.Wrap
                textFormat: Text.PlainText
                font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
                color: root.messageIsError ? Theme.danger : Theme.textDim
            }
            Row {
                anchors.right: parent.right
                spacing: 8
                Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: root.cancelled() }
                Button {
                    text: root.action; variant: "primary"; size: 38
                    tone: root.kind === "delete" ? Theme.danger : Theme.accent
                    busy: root.busy
                    enabled: field.text !== "" && !root.busy
                    onClicked: root.submitted(field.text, root.choice)
                }
            }
        }
    }
}
