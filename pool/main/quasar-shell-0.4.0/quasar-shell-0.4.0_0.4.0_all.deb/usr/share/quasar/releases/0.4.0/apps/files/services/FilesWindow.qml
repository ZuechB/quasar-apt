import QtQuick
import Quickshell
import Quasar
import Quasar.Services
import "../components"
import "../components/selection.js" as Sel

// One Files window: the Toolbar in the title bar, the folder's live listing (Folder) and FilesView,
// and everything the view asks for, done with fileop (FileOps, shared by all windows).
//   Ctrl+L type a path · Ctrl+F search · Ctrl+N new window · Ctrl+W close · Ctrl+H hidden files
//   Ctrl+Shift+N new folder · F5 refresh · Alt+←/→ back/forward · Alt+↑ up · Alt+Home home
// (Enter, Delete, F2, Ctrl+A/C/X/V, arrows, Backspace and typing a name are the items' own keys.)
AppWindow {
    id: win
    required property int windowId
    property var request: ({})               // { path, select }
    property var ops: null                   // FileOps
    property var places: null                // Places
    property var trash: null                 // TrashList
    property var thumbs: null                // Thumbs
    property var cfg: ({})                   // Settings.files with Files' defaults
    property string home: Quickshell.env("HOME") || "/root"
    signal closeWindow(int id)
    signal newWindow(string path)
    signal settingChanged(string key, var value)

    appName: "files"
    title: view.title
    glyph: ""
    defaultSize: Qt.size(820, 520)
    quitOnClose: false
    onCloseRequested: win.closeWindow(win.windowId)

    titleItem: Toolbar {
        id: toolbar
        crumbs: view.crumbs
        fullPath: view.isTrash ? view.trashPath : view.path
        canBack: view.backStack.length > 0
        canForward: view.forwardStack.length > 0
        mode: view.viewMode
        trash: view.isTrash
        listOnly: view.isSearch
        active: win.focused
        onBack: view.back()
        onForward: view.forward()
        onNavigate: (p) => view.go(p)
        onPathTyped: (t) => view.typed(t)
        onQueryEdited: (t) => view.query = t
        onSearchDone: view.itemsArea.forceActiveFocus()
        onSearchSubmitted: view.deepSearch()
        onModePicked: (m) => win.settingChanged("view", m)
        onDropped: (p, d) => view.handleDrop(p, d)
    }

    Folder {
        id: folder
        path: view.isTrash ? "" : view.path
        showHidden: view.showHidden
    }

    FilesView {
        id: view
        anchors.fill: parent
        home: win.home
        trashPath: win.places ? win.places.trashFiles : home + "/.local/share/Trash/files"
        path: win.request.path || win.home
        rows: folder.rows
        loading: folder.loading
        trashRows: win.trash ? win.trash.rows : []
        places: win.places ? win.places.places : []
        devices: win.places ? win.places.devices : []
        rootFree: win.places ? win.places.rootFree : -1
        rootTotal: win.places ? win.places.rootTotal : -1
        viewMode: win.cfg.view === "list" ? "list" : "grid"
        showHidden: !!win.cfg.hidden
        sortKey: ["name", "size", "modified"].indexOf(win.cfg.sort) >= 0 ? win.cfg.sort : "name"
        sortReversed: !!win.cfg.reversed
        thumbs: Theme.profile > 0
        clock24: Settings.clock24
        windowActive: win.focused
        jobs: win.ops ? win.ops.shownJobs : []
        thumbCache: win.thumbs
        onRequest: (action, args) => win.handle(action, args)
        onSettingChanged: (key, value) => win.settingChanged(key, value)
        onNavigated: toolbar.clearSearch()
        onIsTrashChanged: win.syncTrash()
    }
    // The Trash is listed only while some window shows it.
    property bool countedInTrash: false
    function syncTrash() {
        if (!trash || view.isTrash === countedInTrash) return
        trash.viewers += view.isTrash ? 1 : -1
        countedInTrash = view.isTrash
    }
    Component.onDestruction: {
        if (countedInTrash && trash) trash.viewers -= 1
        stopSearch()
        stopProps()
    }

    // ---- the folder shown: there? readable? writable? free space? ----------------------------------
    property bool firstInfo: true
    function checkInfo() {
        if (!ops || view.isTrash) { view.info = null; return }
        const p = view.path
        ops.run(["info", p], null, (code, err, lines) => {
            if (view.path !== p) return
            const o = lines[0] || null
            // Opened on a file (`quasar-files ~/notes.txt`): show its folder with it selected.
            if (win.firstInfo && o && o.exists && !o.dir) {
                win.firstInfo = false
                view.pendingSelect = p
                view.setPath(FileKit.parentOf(p))
                return
            }
            win.firstInfo = false
            view.info = o
        })
    }
    Connections { target: view; function onPathChanged() { view.info = null; win.checkInfo() } }
    Connections { target: win.ops; function onJobDone() { win.checkInfo() } }
    Component.onCompleted: {
        if (request.select) view.pendingSelect = request.select
        syncTrash()
        checkInfo()
    }

    // ---- what the view asks for --------------------------------------------------------------------
    function failed(err, fallback, name) { view.showError(err || fallback, name || "") }
    // Paths fileop made or placed in this window's folder (what a paste or a drop brought here).
    function arrivedHere(lines) {
        return lines.filter(o => o && o.path && !o.error && !o.unchanged && !o.trashed
                                 && FileKit.parentOf(o.path) === view.path).map(o => o.path)
    }
    function handle(action, a) {
        if (!ops) return
        if (action === "open") {
            // A program runs only when it's the only one opened, a .deb opens only the first: opening a
            // whole selection must not queue a dozen questions.
            const rows = a.rows
            const progs = rows.filter(r => !r.isDir && FileKit.openAs(r.name) === "program")
            let pkg = false
            rows.forEach(r => {
                const how = r.isDir ? "" : FileKit.openAs(r.name)
                if (r.isDir) win.newWindow(r.path)
                else if (how === "program") { if (rows.length === 1) runProgram(r.path, a.how || "open") }
                else if (how === "package") { if (!pkg) { pkg = true; Quickshell.execDetached(["/usr/bin/quasar-store", r.path]) } }
                else if (r.archive) extract([r.path])
                else openFile(r)
            })
            if (progs.length && rows.length > 1)
                view.showInfo("Open programs one at a time", progs.length === 1 ? progs[0].name : progs.length + " programs weren't opened")
        } else if (action === "edit") {
            ops.run(["open-with", "quasar-texteditor", a.path], null, (code, err) => { if (code !== 0) failed(err, "Couldn't open it in Text Editor") })
        } else if (action === "runProgram") {
            runProgram(a.path, a.how)
        } else if (action === "window") {
            win.newWindow(a.path)
        } else if (action === "terminal") {
            // The shell opens it (a company that is shown gets its own terminal); without the shell,
            // Quasar's Terminal directly.
            Quickshell.execDetached(["sh", "-c", 'qs --path /usr/share/quasar/shell ipc call launch terminalIn "$1" >/dev/null 2>&1 || exec quasar-terminal --cwd "$1"', "sh", a.path])
        } else if (action === "setwall") {
            Settings.useWallpaperPhoto(a.path)
            view.showInfo("Wallpaper changed", FileKit.baseName(a.path))
        } else if (action === "copy" || action === "cut") {
            ops.run([action === "cut" ? "clip-cut" : "clip-copy"].concat(a.paths), null, (code, err) => {
                if (code !== 0) failed(err, "Couldn't reach the clipboard")
            })
        } else if (action === "canPaste") {
            ops.run(["can-paste"], null, (code) => view.canPaste = code === 0)
        } else if (action === "paste") {
            ops.run(["paste", a.dest], null, (code, err, lines) => {
                if (code === 3) return                          // nothing to paste
                if (code !== 0 && code !== 130) failed(err, "Some files couldn't be pasted")
                const here = arrivedHere(lines)
                if (here.length) view.selectWhenListed(here)
            }, "Pasting…")
        } else if (action === "transfer") {
            const n = FileKit.countText(a.paths.length)
            ops.run([a.mode, a.dest].concat(a.paths), null, (code, err, lines) => {
                if (code !== 0 && code !== 130) failed(err, a.mode === "copy" ? "Some files couldn't be copied" : "Some files couldn't be moved")
                const here = arrivedHere(lines)
                if (here.length) view.selectWhenListed(here)
            }, (a.mode === "copy" ? "Copying " : "Moving ") + n + "…")
        } else if (action === "cancel") {
            ops.cancel(a.id)                                    // a cancel is the user's choice: no message
        } else if (action === "search") {
            stopSearch()
            win.searchId = ops.run(["search", a.dir, a.query].concat(a.hidden ? ["--hidden"] : []),
                (o) => { if (o.path && !o.error) a.onRow(o) },
                (code, err, lines) => {
                    win.searchId = 0
                    const end = lines.find(o => o.done)
                    if (code !== 0 && code !== 130 && err) failed(err, "Couldn't search")
                    a.done(code, end ? end.more : false)
                })
        } else if (action === "stopSearch") {
            stopSearch()
        } else if (action === "appsFor") {
            ops.run(["apps-for", a.path], null, (code, err, lines) => a.done(code === 0 && lines[0] ? lines[0] : { mime: "", apps: [] }))
        } else if (action === "openWith") {
            ops.run(["open-with", a.app].concat(a.paths), null, (code, err) => { if (code !== 0) failed(err, "Couldn't open it with that app") })
        } else if (action === "setDefault") {
            ops.run(["set-default", a.app, a.mime], null, (code, err) => a.done(code, err))
        } else if (action === "store") {
            Quickshell.execDetached(["quasar-store"])
        } else if (action === "props") {
            stopProps()
            win.propsId = ops.run(["props"].concat(a.paths), a.onLine, () => { win.propsId = 0; a.done() })
        } else if (action === "stopProps") {
            stopProps()
        } else if (action === "mount") {
            if (places) places.mount(a.device, a.done)
        } else if (action === "eject") {
            if (places) places.eject(a.device, a.done)
        } else if (action === "links") {
            a.urls.forEach((u, i) => ops.run(["new-link", a.dest, i === 0 ? (a.title || "") : "", u], null, (code, err) => {
                if (code !== 0) failed(err, "Couldn't make a shortcut to that page")
            }))
        } else if (action === "trash") {
            ops.run(["trash"].concat(a.paths), null, (code, err, lines) => {
                if (code !== 0 && code !== 130) failed(err, "Couldn't move it to the Trash")
                if (a.done) a.done(code, lines)
            }, "Moving to the Trash…")
        } else if (action === "restore") {
            ops.run(["restore"].concat(a.names), null, (code, err) => {
                if (code !== 0 && code !== 130) failed(err, "Couldn't put it back")
            }, "Restoring…")
        } else if (action === "deleteForever") {
            ops.run(["trash-delete"].concat(a.names), null, (code, err) => {
                if (code !== 0) failed(err, "Couldn't delete it")
            }, "Deleting…")
        } else if (action === "emptyTrash") {
            ops.run(["empty-trash"], null, (code, err) => {
                if (code !== 0) failed(err, "Couldn't empty the Trash")
            }, "Emptying the Trash…")
        } else if (action === "extract") {
            extract(a.paths)
        } else if (action === "compress") {
            ops.run(["compress"].concat(a.paths), null, (code, err, lines) => {
                if (code !== 0) return failed(err, "Couldn't make the zip file")
                const here = arrivedHere(lines)
                if (here.length) view.selectWhenListed(here.slice(-1))
            }, "Compressing…")
        } else if (action === "rename") {
            ops.run(["rename", a.path, a.name], null, (code, err, lines) => {
                const made = lines.find(o => o && o.path && !o.error)
                a.done(code, err, made ? made.path : "")
            })
        } else if (action === "newfolder" || action === "newtext") {
            ops.run(action === "newfolder" ? ["new-folder", a.dir] : ["new-file", a.dir, "New text document.txt"], null, (code, err, lines) => {
                const made = lines.filter(o => o && o.path && !o.error).pop()
                a.done(code, err, made ? made.path : "")
            })
        }
    }
    property int searchId: 0                 // the search running in this window
    property int propsId: 0                  // Properties still adding folders up
    function stopSearch() { if (searchId) { ops.cancel(searchId); searchId = 0 } }
    function stopProps() { if (propsId) { ops.cancel(propsId); propsId = 0 } }
    function extract(paths) {
        paths.forEach(p => ops.run(["extract", p], null, (code, err, lines) => {
            if (code === 5) return view.showInfo("This archive has a password", "Get PeaZip in the Store to open it.")
            if (code !== 0) return failed(err, "Couldn't extract it", FileKit.baseName(p))
            const here = arrivedHere(lines)
            if (here.length) view.selectWhenListed(here.slice(-1))
        }, "Extracting…"))
    }
    // Programs (scripts, AppImages, .exe files) go to the shell, which asks first and runs them
    // (services/Programs.qml); a double-click here counts as the user's own, so a file they said yes to
    // before runs straight away. how: open | terminal | apps. Without the shell, `program open-external`
    // retries and then says so; it never runs the file itself.
    function runProgram(path, how) {
        Quickshell.execDetached(["sh", "-c", 'qs --path /usr/share/quasar/shell ipc call programs "$1" "$2" >/dev/null 2>&1 || exec /usr/libexec/quasar/program open-external "$2"',
                                 "sh", how === "terminal" ? "terminal" : how === "apps" ? "toApps" : "open", path])
    }
    function openFile(r) {
        ops.run(["open", r.path], null, (code, err) => {
            if (code === 3) view.showInfo("No app can open this yet", r.name + ": the Store may have one.")
            else if (code !== 0) failed(err, "Couldn't open it", r.name)
        })
    }

    // What tests read (IPC `app state`).
    function stateInfo() {
        return { path: view.path, mode: view.viewMode, trash: view.isTrash, count: view.shown.length,
                 selected: Sel.list(view.selection, view.paths), query: view.query, busy: ops ? ops.busy : 0,
                 search: view.searchFor, searching: view.searching, devices: view.devices,
                 jobs: ops ? ops.jobs.map(j => ({ label: j.label, done: j.done, total: j.total })) : [] }
    }

    Shortcut { sequences: ["Ctrl+L", "Alt+D"]; onActivated: toolbar.editPath() }
    Shortcut { sequences: ["Ctrl+F"]; onActivated: toolbar.focusSearch() }
    Shortcut { sequences: ["Ctrl+N"]; onActivated: win.newWindow(view.isTrash ? win.home : view.path) }
    Shortcut { sequences: ["Ctrl+W"]; onActivated: win.closeWindow(win.windowId) }
    Shortcut { sequences: ["Ctrl+H"]; onActivated: view.toggleHidden() }
    Shortcut { sequences: ["Ctrl+Shift+N"]; onActivated: view.newItem("folder") }
    Shortcut { sequences: ["F5", "Ctrl+R"]; onActivated: { folder.rebuild(); win.checkInfo(); if (view.isTrash && win.trash) win.trash.refresh() } }
    Shortcut { sequences: ["Alt+Left"]; onActivated: view.back() }
    Shortcut { sequences: ["Alt+Right"]; onActivated: view.forward() }
    Shortcut { sequences: ["Alt+Up"]; onActivated: view.up() }
    Shortcut { sequences: ["Alt+Home"]; onActivated: view.go(win.home) }
}
