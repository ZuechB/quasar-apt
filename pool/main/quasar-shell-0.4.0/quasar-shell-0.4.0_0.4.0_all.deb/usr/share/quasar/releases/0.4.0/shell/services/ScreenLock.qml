import QtQuick
import Quickshell
import Quickshell.Io
import Quickshell.Wayland
import Quickshell.Services.Pam
import Quasar
import Quasar.Services
import "../components"

// The lock screen: ext-session-lock (WlSessionLock) with Quasar's own card on every screen, your
// password checked by PAM (/etc/pam.d/quasar-lock: common-auth, plus pam_gnome_keyring so the first
// unlock after automatic sign-in also unlocks your keyring and Vault).
// Locks on: lock() (Super+L, the launcher, the power menu, IPC `shell lock`), logind's Lock signal
// (loginctl lock-session) and before the PC sleeps (session-events holds a delay inhibitor until the
// screen is locked). If the shell restarts while locked, the marker file locks it again at once.
//   QUASAR_LOCK_PAM=NAME   another PAM service (tests)
Scope {
    id: root
    property var controls: null              // SystemControls: lockRequested(), logout()
    property string displayName: ""
    // The password card's display: the main one (shell.main), which is also the one Remote desktop's
    // viewers see, so a viewer can always unlock. Without it, the first screen.
    property var mainScreen: null
    readonly property string user: Quickshell.env("USER") || ""
    readonly property string pamConfig: Quickshell.env("QUASAR_LOCK_PAM") || "quasar-lock"
    readonly property string marker: (Quickshell.env("XDG_RUNTIME_DIR") || "/tmp") + "/quasar/locked"

    property bool locked: false
    property bool busy: false
    property string message: ""
    property bool messageIsError: false
    property string prompt: "Password"
    property bool echo: false
    property var queued: null                // the password typed before PAM asked for it

    // Your name as it is now (Settings can change it during the session).
    property string liveName: ""
    Process {
        id: nameProc
        command: ["getent", "passwd", root.user]
        stdout: StdioCollector { onStreamFinished: { const f = text.split(":"); if (f.length > 4) root.liveName = f[4].split(",")[0].trim() } }
    }
    function lock() {
        if (locked) return
        if (root.user) nameProc.running = true
        message = ""; messageIsError = false; prompt = "Password"; echo = false; busy = false; queued = null
        locked = true
        markerFile.setText("1\n")
    }
    function unlock() {
        if (pam.active) pam.abort()
        locked = false
        busy = false
        markerFile.setText("0\n")
    }

    Connections {
        target: root.controls
        function onLockRequested() { root.lock() }
    }

    // A shell that restarts while the screen was locked locks it again straight away.
    FileView {
        id: markerFile
        path: root.marker
        blockLoading: true
        printErrors: false
        onLoaded: if (text().trim() === "1") root.lock()
    }

    // ---- password --------------------------------------------------------------------------------
    function submit(text) {
        if (busy) return
        message = ""
        busy = true
        if (pam.active && pam.responseRequired) { pam.respond(text); return }
        queued = text
        pam.user = root.user
        if (!pam.start()) failed("Couldn't check your password")
    }
    function failed(text) {
        busy = false; queued = null
        prompt = "Password"; echo = false
        message = text; messageIsError = true
        for (const s of surfaces) s.clearAndFocus()
    }
    PamContext {
        id: pam
        config: root.pamConfig
        onPamMessage: {
            if (responseRequired) {
                if (root.queued !== null) { const t = root.queued; root.queued = null; respond(t); return }
                const m = String(message || "").trim(), cut = m.lastIndexOf(". ")
                root.busy = false
                root.prompt = cut > 0 ? m.slice(cut + 2) : (m || "Password")
                root.echo = responseVisible
                root.message = cut > 0 ? m.slice(0, cut + 1) : ""; root.messageIsError = false
                for (const s of root.surfaces) s.clearAndFocus()
            } else if (message !== "") {
                root.message = message; root.messageIsError = messageIsError
            }
        }
        onCompleted: (result) => {
            if (result === PamResult.Success) root.unlock()
            else root.failed(result === PamResult.MaxTries ? "Too many tries. Wait a moment, then try again." : "That password isn't right")
        }
        onError: (error) => root.failed("Couldn't check your password")
    }

    // ---- logind: lock-session, Unlock, sleep ---------------------------------------------------------
    Process {
        id: events
        running: true
        command: ["/usr/libexec/quasar/session-events"]
        stdinEnabled: true
        stdout: SplitParser {
            onRead: (line) => {
                let e = ""
                try { e = JSON.parse(line).event } catch (err) { return }
                if (e === "lock" || e === "sleep") {
                    root.lock()
                    if (e === "sleep") sleepAck.restart()
                } else if (e === "unlock") {
                    root.unlock()             // loginctl unlock-session (an administrator, or root)
                }
            }
        }
        onExited: (code) => { if (code !== 3) restartEvents.restart() }
    }
    // Sleep goes on once the lock surfaces are up (the compositor shows them from the next frame).
    Timer { id: sleepAck; interval: 250; onTriggered: if (events.running) events.write("locked\n") }
    Timer { id: restartEvents; interval: 5000; onTriggered: events.running = true }

    // ---- the lock surfaces ---------------------------------------------------------------------------
    property var surfaces: []
    WlSessionLock {
        id: sessionLock
        locked: root.locked
        WlSessionLockSurface {
            id: surface
            color: Theme.bg
            readonly property bool main: Quickshell.screens.length <= 1
                || (root.mainScreen ? screen === root.mainScreen : screen === Quickshell.screens[0])
            onMainChanged: if (main && root.locked) focusTimer.restart()
            function clearAndFocus() { view.clear(); if (main) view.focusInput() }
            Component.onCompleted: root.surfaces = root.surfaces.concat([surface])
            Component.onDestruction: root.surfaces = root.surfaces.filter(s => s !== surface)
            LockScreen {
                id: view
                anchors.fill: parent
                main: surface.main
                name: root.liveName || root.displayName || root.user
                seed: root.user
                wallpaper: Settings.wallpaper || "deep"
                busy: root.busy
                message: root.message
                messageIsError: root.messageIsError
                prompt: root.prompt
                echo: root.echo
                onSubmitted: (pw) => root.submit(pw)
                onSignOut: { if (root.controls) root.controls.logout() }
                Component.onCompleted: if (surface.main) focusTimer.restart()
            }
            Timer { id: focusTimer; interval: 60; onTriggered: view.focusInput() }
        }
    }
}
