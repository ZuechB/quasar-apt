// Quasar's sign-in screen: a Quickshell config run by /usr/libexec/quasar/quasar-greeter as the
// _greetd account, inside its own labwc, whenever greetd shows the default session (startup without
// automatic sign-in, after Sign out). The people are the regular accounts in /etc/passwd; the
// password goes to greetd, which runs PAM (/etc/pam.d/greetd: pam_gnome_keyring unlocks the login
// keyring with it) and starts /usr/bin/quasar-session once the greeter has exited.
//   QUASAR_ACCOUNTS_ETC=DIR  read DIR/passwd and DIR/group instead (tests)
//   QUASAR_GREETER_STATE=DIR where last-user lives (default /var/lib/quasar-greeter)
import QtQuick
import Quickshell
import Quickshell.Wayland
import Quickshell.Io
import Quickshell.Services.Greetd
import Quasar
import "components"

ShellRoot {
    id: g
    readonly property string etc: Quickshell.env("QUASAR_ACCOUNTS_ETC") || "/etc"
    readonly property string stateDir: Quickshell.env("QUASAR_GREETER_STATE") || "/var/lib/quasar-greeter"
    readonly property bool live: Quickshell.env("QUASAR_LIVE") === "1"

    Binding { target: Theme; property: "softwareRender"; value: Quickshell.env("QT_QUICK_BACKEND") === "software" }
    Binding { target: Theme; property: "profile"; value: Quickshell.env("QT_QUICK_BACKEND") === "software" ? 0 : 1 }

    // ---- this start reached the sign-in screen -------------------------------------------------------
    // quasar-boot-ok.path counts the start as good once something is on screen (here, or the desktop's shell),
    // so GRUB's menu stays hidden next time. A greeter that crashes in its first moments writes nothing.
    Timer {
        running: true; interval: 2000
        onTriggered: Quickshell.execDetached(["sh", "-c", "date +%s > /run/quasar/desktop-ready/greeter 2>/dev/null; true"])
    }

    // ---- Restart / Shut down --------------------------------------------------------------------------
    // Not while Quasar installs something a restart would break (a logind block inhibitor from hold-restart:
    // a driver install, updates). The desktop's power menu can wait or override; here it only says why.
    property string powerAction: ""
    function power(action) { powerAction = action; powerCheck.running = true }
    Process {
        id: powerCheck
        command: ["busctl", "--system", "--json=short", "call", "org.freedesktop.login1", "/org/freedesktop/login1",
                  "org.freedesktop.login1.Manager", "ListInhibitors"]
        stdout: StdioCollector {
            onStreamFinished: {
                let why = []
                try {
                    why = (JSON.parse(text).data[0] || [])
                        .filter(x => x[3] === "block" && String(x[0]).split(":").indexOf("shutdown") >= 0).map(x => x[2] || x[1])
                } catch (e) { }
                if (why.length === 0) {
                    Quickshell.execDetached(["systemctl", g.powerAction === "poweroff" ? "poweroff" : "reboot"])
                } else {
                    g.messageIsError = false
                    g.message = why.join(", ") + ". " + (g.powerAction === "poweroff" ? "Shut down" : "Restart") + " when it's done."
                }
            }
        }
    }

    // ---- people ----------------------------------------------------------------------------------
    property string passwdText: ""
    property string groupText: ""
    property string lastUser: ""
    readonly property var people: Accounts.people(passwdText, groupText, { live: live })
    property string chosen: ""
    readonly property string selected: people.some(p => p.name === chosen) ? chosen
        : people.some(p => p.name === lastUser) ? lastUser : (people.length ? people[0].name : "")
    FileView { path: g.etc + "/passwd"; blockLoading: true; printErrors: false; onLoaded: g.passwdText = text() }
    FileView { path: g.etc + "/group"; blockLoading: true; printErrors: false; onLoaded: g.groupText = text() }
    FileView {
        id: lastFile
        path: g.stateDir + "/last-user"
        blockLoading: true; printErrors: false
        onLoaded: g.lastUser = text().trim()
    }
    // The live session's account has no password: Enter on an empty field signs in.
    readonly property bool allowEmpty: live && selected === "live"

    // ---- greetd ----------------------------------------------------------------------------------
    property bool busy: false
    property string message: ""
    property bool messageIsError: false
    property string prompt: "Password"
    property bool echo: false
    property bool leaving: false
    property var queued: null               // the password typed before greetd asked for it
    property bool answering: false          // greetd asked a further question (a new password, a code)

    function pick(name) {
        if (busy) return
        if (Greetd.state !== GreetdState.Inactive) Greetd.cancelSession()
        chosen = name
        answering = false; prompt = "Password"; echo = false; message = ""
        focusTimer.restart()
    }
    function submit(text) {
        if (busy || !selected) return
        message = ""
        busy = true
        if (answering) {
            answering = false
            Greetd.respond(text)
            return
        }
        queued = text
        if (Greetd.state !== GreetdState.Inactive) Greetd.cancelSession()
        Greetd.createSession(selected)
    }
    function failed(text) {
        busy = false; queued = null; answering = false
        prompt = "Password"; echo = false
        message = text; messageIsError = true
        for (const v of views.instances) if (v.view) v.view.clear()
        focusTimer.restart()
    }
    Connections {
        target: Greetd
        function onAuthMessage(message, error, responseRequired, echoResponse) {
            if (responseRequired) {
                if (g.queued !== null) { const t = g.queued; g.queued = null; Greetd.respond(t); return }
                // A further question from PAM: an expired password's new one, a one-time code…
                // "You are required to change your password immediately. New password:": the
                // explanation goes under the field, the question itself into it.
                const m = String(message || "").trim(), cut = m.lastIndexOf(". ")
                g.busy = false; g.answering = true
                g.prompt = cut > 0 ? m.slice(cut + 2) : (m || "Password"); g.echo = echoResponse
                g.message = cut > 0 ? m.slice(0, cut + 1) : ""; g.messageIsError = false
                for (const v of views.instances) if (v.view) v.view.clear()
                focusTimer.restart()
            } else if (message !== "") {
                g.message = message; g.messageIsError = error
            }
        }
        function onAuthFailure(message) { g.failed("That password isn't right") }
        function onError(error) {
            g.failed("Couldn't sign in: " + error)
            if (Greetd.state !== GreetdState.Inactive) Greetd.cancelSession()
        }
        function onReadyToLaunch() {
            lastFile.setText(g.selected + "\n")
            g.leaving = true
            launchTimer.restart()
        }
    }
    // The fade to the desktop's colour runs first: greetd starts the session once this process exits.
    Timer {
        id: launchTimer
        interval: Theme.reduceMotion ? 0 : 340
        onTriggered: Greetd.launch(["/usr/bin/quasar-session"], [], true)
    }
    Timer { id: focusTimer; interval: 30; onTriggered: { for (const v of views.instances) if (v.view && v.main) v.view.focusInput() } }

    // ---- screens -----------------------------------------------------------------------------------
    Variants {
        id: views
        model: Quickshell.screens
        PanelWindow {
            id: win
            required property var modelData
            readonly property bool main: modelData === Quickshell.screens[0]
            property alias view: view
            screen: modelData
            anchors { top: true; bottom: true; left: true; right: true }
            exclusionMode: ExclusionMode.Ignore
            color: Theme.bg
            WlrLayershell.layer: WlrLayer.Overlay
            WlrLayershell.namespace: "quasar-greeter"
            WlrLayershell.keyboardFocus: main ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None
            GreeterView {
                id: view
                anchors.fill: parent
                main: win.main
                people: g.people
                selected: g.selected
                busy: g.busy
                message: g.message
                messageIsError: g.messageIsError
                prompt: g.prompt
                echo: g.echo
                allowEmpty: g.allowEmpty && !g.answering
                leaving: g.leaving
                onSubmitted: (pw) => g.submit(pw)
                onPicked: (name) => g.pick(name)
                onRestartClicked: g.power("reboot")
                onShutdownClicked: g.power("poweroff")
                Component.onCompleted: if (win.main) focusTimer.restart()
            }
        }
    }
}
