#version 440
// "Deep field" wallpaper from the mockup (SVG scene, viewBox 1440x900, xMidYMid slice) as one shader:
// background radial gradients, twinkling stars (cell-hashed, O(1)/pixel), tilted orbit rings with a
// moving dash each (true arc-length dashes), accent jet, breathing core, center dot, film grain.
// detail = 0 renders a soft low-detail version used as "procedural glass" behind panels.
layout(location = 0) in vec2 qt_TexCoord0;
layout(location = 0) out vec4 fragColor;

layout(std140, binding = 0) uniform buf {
    mat4 qt_Matrix;
    float qt_Opacity;
    vec2 itemSize;     // size of this item (px)
    vec2 screenSize;   // full wallpaper size (px) — equals itemSize unless used as a glass backdrop
    vec2 offset;       // position of this item inside the full wallpaper (px)
    vec4 accent;
    float time;        // seconds
    float stars;       // 1 = draw stars
    float detail;      // 1 = full, 0 = low-detail glass backdrop
    float cornerRadius; // >0: mask to a rounded rect (glass backdrop)
};

const vec2 C = vec2(1008.0, 324.0);           // core / orbit center (viewBox units)
const float TAU = 6.28318530718;

float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}
vec2 hash22(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * vec3(0.1031, 0.1030, 0.0973));
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.xx + p3.yz) * p3.zy);
}

// CSS radial-gradient(ellipse radii at center, color, transparent stopEnd): coverage 0..1
float radialStop(vec2 px, vec2 center, vec2 radii, float stopEnd) {
    float d = length((px - center) / radii);
    return clamp(1.0 - d / stopEnd, 0.0, 1.0);
}

// Signed distance (approx) to an axis-aligned ellipse.
float ellipseDist(vec2 p, vec2 r) {
    float k0 = length(p / r);
    float k1 = length(p / (r * r));
    return k0 * (k0 - 1.0) / max(k1, 1e-4);
}

// Arc length from the ellipse's start point (rightmost) to parametric angle th, by midpoint rule.
float arcLen(float th, vec2 r) {
    float acc = 0.0;
    float h = th / 24.0;
    for (int i = 0; i < 24; i++) {
        float a = (float(i) + 0.5) * h;
        float s = sin(a), c = cos(a);
        acc += sqrt(r.x * r.x * s * s + r.y * r.y * c * c);
    }
    return acc * h;
}

// Stroke coverage of an ellipse ring (width in viewBox units, px = viewBox->px scale).
float ring(vec2 p, vec2 r, float width, float pxScale) {
    float d = abs(ellipseDist(p, r)) * pxScale;
    float hw = 0.5 * width * pxScale;
    return clamp(hw + 0.5 - d, 0.0, 1.0);
}

// Moving dash on an ellipse: dash `len` of `period` units, travelling at period/T units per second.
float dash(vec2 p, vec2 r, float width, float pxScale, float len, float period, float T) {
    float cov = ring(p, r, width, pxScale);
    if (cov <= 0.0) return 0.0;
    vec2 q = p / r;
    float th = atan(q.y, q.x);
    if (th < 0.0) th += TAU;
    float s = arcLen(th, r);
    float head = mod(time / T, 1.0) * period;          // dash start moves forward (dashoffset -> -period)
    float u = mod(s - head + period, period);
    // round caps: soften dash ends by half the stroke width
    float capW = 0.5 * width;
    float inDash = smoothstep(-capW, 0.0, u) * (1.0 - smoothstep(len, len + capW, u));
    float wrap = smoothstep(period - capW, period, u);   // cap that wraps past 0
    return cov * max(inDash, wrap);
}

float roundedMask(vec2 local, vec2 size, float r) {
    if (r <= 0.0) return 1.0;
    vec2 q = abs(local - 0.5 * size) - (0.5 * size - vec2(r));
    float d = length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;
    return clamp(0.5 - d, 0.0, 1.0);
}

void main() {
    vec2 px = qt_TexCoord0 * itemSize + offset;          // pixel in full-wallpaper space
    vec2 S = screenSize;

    // Background + the two CSS radial gradients (px space).
    vec3 col = vec3(0.0196, 0.0235, 0.0392);             // #05060A
    float g1 = radialStop(px, vec2(0.70, 0.36) * S, vec2(1100.0, 760.0), 0.62);
    col = mix(col, vec3(0.478, 0.906, 1.0), 0.08 * g1);  // rgba(122,231,255,.08)
    float g2 = radialStop(px, vec2(0.08, 1.05) * S, vec2(900.0, 700.0), 0.60);
    col = mix(col, vec3(0.549, 0.431, 1.0), 0.07 * g2);  // rgba(140,110,255,.07)

    // viewBox mapping (xMidYMid slice)
    float sc = max(S.x / 1440.0, S.y / 900.0);
    vec2 v = (px - 0.5 * (S - vec2(1440.0, 900.0) * sc)) / sc;
    vec3 acc = accent.rgb;

    // breathing core (7s ease-in-out between scale 1..1.35, opacity .85..1)
    float ph = 0.5 - 0.5 * cos(TAU * mod(time, 7.0) / 7.0);
    float breathe = (detail > 0.5) ? ph : 0.5;
    float coreR = 70.0 * mix(1.0, 1.35, breathe);
    float coreOp = mix(0.85, 1.0, breathe);

    if (detail < 0.5) {
        // Low detail: blurred core glow only (what 28px blur leaves of the scene).
        float d = length(v - C) / (coreR * 1.6);
        float glow = clamp(1.0 - d, 0.0, 1.0);
        col = mix(col, acc, 0.30 * glow * glow);
        fragColor = vec4(col, 1.0) * roundedMask(qt_TexCoord0 * itemSize, itemSize, cornerRadius) * qt_Opacity;
        return;
    }

    // Stars: one per 120x120 viewBox cell, 85% small / 15% large, independent twinkle.
    if (stars > 0.5) {
        vec2 cell = floor(v / 120.0);
        vec2 h = hash22(cell + 11.0);
        vec2 sp = (cell + 0.06 + 0.88 * h) * 120.0;
        float hr = hash12(cell + 3.7);
        float r = (hr < 0.85) ? 0.5 + 0.6 * fract(hr * 13.1) : 1.1 + 0.8 * fract(hr * 7.3);
        float dpx = length(v - sp) * sc;
        float rpx = r * sc;
        if (dpx < rpx + 1.0) {
            float dur = 3.0 + 5.0 * hash12(cell + 5.1);
            float delay = 6.0 * hash12(cell + 9.4);
            float tw = 0.5 - 0.5 * cos(TAU * mod(time + delay, dur) / dur);
            float op = mix(0.12, 0.95, tw);
            float cov = clamp(rpx + 0.5 - dpx, 0.0, 1.0);
            col = mix(col, vec3(0.867, 0.902, 1.0), op * cov);   // #DDE6FF
        }
    }

    // Tilted orbit system: group rotate(-14 1008 324). Local = inverse rotation (+14°).
    vec2 d0 = v - C;
    float cr = cos(radians(14.0)), sr = sin(radians(14.0));
    vec2 L = vec2(cr * d0.x - sr * d0.y, sr * d0.x + cr * d0.y);

    // accent jet: 1.2 wide, from y=-260..910 (local y -584..586), alpha .5 peak at center
    float jx = abs(L.x) * sc;
    if (jx < 1.6 * sc + 1.0) {
        float jcov = clamp(0.6 * sc + 0.5 - jx, 0.0, 1.0);
        float jy = clamp(1.0 - abs(L.y - 1.0) / 585.0, 0.0, 1.0);
        col = mix(col, acc, 0.5 * jy * jcov);
    }

    // Static rings (white, stroke 1)
    float rr = 0.0;
    if (abs(L.y) < 160.0 && abs(L.x) < 632.0) {
        rr = max(rr, 0.08 * ring(L, vec2(170.0, 40.0), 1.0, sc));
        rr = max(rr, 0.06 * ring(L, vec2(290.0, 70.0), 1.0, sc));
        rr = max(rr, 0.045 * ring(L, vec2(440.0, 106.0), 1.0, sc));
        rr = max(rr, 0.03 * ring(L, vec2(620.0, 150.0), 1.0, sc));
        col = mix(col, vec3(1.0), rr);

        // Moving accent dashes: orbitA 28s (110 of 1239), orbitB 15s (46 of 724)
        float da = 0.7 * dash(L, vec2(290.0, 70.0), 1.6, sc, 110.0, 1239.0, 28.0);
        float db = 0.55 * dash(L, vec2(170.0, 40.0), 1.4, sc, 46.0, 724.0, 15.0);
        col = mix(col, acc, max(da, db));
    }

    // Core: radial gradient white .95 @0 -> accent .55 @18% -> accent 0 @100%
    float cd = length(v - C) / coreR;
    if (cd < 1.0) {
        vec4 c0 = vec4(1.0, 1.0, 1.0, 0.95);
        vec4 c1 = vec4(acc, 0.55);
        vec4 c2 = vec4(acc, 0.0);
        vec4 cc = (cd < 0.18) ? mix(c0, c1, cd / 0.18) : mix(c1, c2, (cd - 0.18) / 0.82);
        col = mix(col, cc.rgb, cc.a * coreOp);
    }
    // center dot r=2.6 white
    float dd = length(v - C) * sc;
    col = mix(col, vec3(1.0), clamp(2.6 * sc + 0.5 - dd, 0.0, 1.0));

    // film grain (feTurbulence, desaturated, opacity .06) — static per pixel
    float n = hash12(floor(px) + 0.5);
    col += (n - 0.5) * 0.035 + 0.006;

    fragColor = vec4(col, 1.0) * roundedMask(qt_TexCoord0 * itemSize, itemSize, cornerRadius) * qt_Opacity;
}
