import QtQuick
import QtQuick.Shapes
import Quasar

// Full-screen company switch overlay (template): the desktop fades to near-black with a glow in the
// company's colour, its badge and name, and a progress sheen while it comes up. Phases: "out" covers
// the screen (380 ms), "in" reveals the new desktop (750 ms, slight zoom). No shaders and no blur, so it
// renders the same on the software renderer; in Lite it appears and goes without animating.
Item {
    id: root
    property string name: ""
    property string initials: ""
    property color hue: Theme.accent
    property string sub: ""
    property string phase: ""          // "out" | "in" | ""
    property bool failed: false
    readonly property bool animate: Theme.profile > 0 && !Theme.reduceMotion

    visible: opacity > 0.001
    opacity: phase === "out" ? 1 : 0
    scale: phase === "in" ? 1.05 : 1
    Behavior on opacity {
        NumberAnimation {
            duration: root.animate ? (root.phase === "out" ? 380 : 750) : 1
            easing.type: root.phase === "out" ? Easing.OutQuad : Easing.BezierSpline
            easing.bezierCurve: Motion.soft
        }
    }
    Behavior on scale {
        NumberAnimation { duration: root.animate ? 750 : 1; easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.soft }
    }

    Rectangle { anchors.fill: parent; color: "#05060A" }
    // radial-gradient(760px 480px at 50% 46%, accent .22, transparent 70%)
    Shape {
        anchors.fill: parent
        ShapePath {
            strokeWidth: -1
            fillGradient: RadialGradient {
                centerX: root.width / 2; centerY: root.height * 0.46; centerRadius: 760
                focalX: centerX; focalY: centerY
                GradientStop { position: 0.0; color: Theme.alpha(root.hue, 0.22) }
                GradientStop { position: 0.7; color: Theme.alpha(root.hue, 0.0) }
            }
            // Taller than the screen: squashed to the ellipse below, it must still reach past the
            // point where the glow has faded out (70 % of 760 px), or its edges show.
            PathRectangle { x: 0; y: -root.height; width: root.width; height: root.height * 3 }
        }
        transform: Scale { origin.x: root.width / 2; origin.y: root.height * 0.46; yScale: 480 / 760 }
    }

    Column {
        anchors.horizontalCenter: parent.horizontalCenter
        y: root.height * 0.46 - 120
        spacing: 0
        Rectangle {
            anchors.horizontalCenter: parent.horizontalCenter
            width: 80; height: 80; radius: 26
            color: root.hue
            Text {
                anchors.centerIn: parent
                text: root.initials
                textFormat: Text.PlainText
                color: Theme.accentInk
                font.family: Theme.fontDisplay; font.pixelSize: 26; font.weight: Font.Bold
            }
        }
        Item { width: 1; height: 22 }
        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: root.name
            textFormat: Text.PlainText
            color: Theme.text
            font.family: Theme.fontDisplay; font.pixelSize: 36; font.weight: Font.DemiBold
        }
        Item { width: 1; height: 8 }
        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: root.sub
            textFormat: Text.PlainText
            color: root.failed ? Theme.danger : Theme.textMuted
            font.family: Theme.fontUi; font.pixelSize: 14
        }
        Item { width: 1; height: 22 }
        Rectangle {
            id: track
            anchors.horizontalCenter: parent.horizontalCenter
            visible: !root.failed
            width: 180; height: 3; radius: 2
            color: Theme.white(0.08)
            clip: true
            Rectangle {
                id: bar
                width: track.width * 0.4; height: 3; radius: 2
                color: root.hue
                x: root.animate ? 0 : track.width * 0.3
                NumberAnimation on x {
                    running: root.animate && root.phase === "out"
                    loops: Animation.Infinite
                    from: -bar.width; to: track.width
                    duration: 900
                }
            }
        }
    }
}
