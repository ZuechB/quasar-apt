import QtQuick
import Quasar
import "runtime.js" as RT

// Template Sites › Overview: the Address card (addresses, certificate, what serves it, and who can
// reach it) next to the App card (runtime, project, build, run, health check, live version).
Item {
    id: root
    property var site: null
    property var detail: null
    property var liveDeploy: null
    property string home: ""

    implicitHeight: grid.implicitHeight

    readonly property var addressFacts: {
        if (!site) return []
        const f = [{ label: "Local address", value: "https://" + site.hostname, mono: true },
                   { label: "Certificate", value: "Trusted local certificate from Quasar (this PC)" },
                   { label: "Served by", value: site.kind === "static" ? "Caddy, straight from /srv/sites/" + site.id
                                                   : "Caddy, forwarding to 127.0.0.1:" + site.port + " and :" + (site.port + 1) + " (two slots, no downtime)" }]
        if (site.lan && site.lan.on)
            f.push({ label: "Home network", value: "https://" + site.lan.name, mono: true })
        const pub = site["public"] || {}           // "public" is reserved in QML's JS parser: no dot access
        if (pub.on && pub.domain)
            f.push({ label: "Public address", value: "https://" + pub.domain + (pub.mode === "tunnel" ? ", through Cloudflare Tunnel" : ", certificate from Let’s Encrypt"), mono: true })
        return f
    }
    readonly property var appFacts: {
        if (!site) return []
        const f = [{ label: "Runtime", value: RT.rtLabel(site) },
                   { label: "Project", value: RT.shortHome(site.source, home), mono: true }]
        if (site.build) f.push({ label: "Build", value: site.build, mono: true })
        if (site.kind !== "static") f.push({ label: "Run", value: site.run, mono: true })
        f.push({ label: "Health check", value: site.kind === "static" ? "Not needed for static files"
                                              : "GET " + (site.health || "/") + (site.state === "live" ? ", answering" : "") })
        if (site.data) f.push({ label: "Data folder", value: site.data + " (kept between deploys)", mono: true })
        f.push({ label: "Live version", value: root.liveDeploy ? root.liveDeploy.hash + ", " + root.liveDeploy.msg
                                               : site.release ? site.release : "Not deployed yet" })
        return f
    }

    Grid {
        id: grid
        width: parent.width
        columns: width > 700 ? 2 : 1
        spacing: 12
        readonly property real cardW: (width - (columns - 1) * spacing) / columns

        FactCard {
            width: grid.cardW
            title: "Address"
            facts: root.addressFacts
            Column {
                width: parent.width
                Rectangle { width: parent.width; height: 1; color: Theme.white(0.05) }
                // Sharing arrives with the home-network and public-hosting updates; until then the
                // rows say so instead of pretending to work.
                SettingsRow {
                    width: parent.width
                    label: "Home network"
                    sub: "Phones and laptops on your Wi-Fi at https://" + (root.site ? root.site.id : "") + ".local"
                    trailing: "soon"
                }
                SettingsRow {
                    width: parent.width
                    label: "Public on the internet"
                    sub: "Your own domain, with a guided setup for the router and DNS"
                    trailing: "soon"
                }
            }
        }
        FactCard {
            width: grid.cardW
            title: "App"
            facts: root.appFacts
        }
    }
}
