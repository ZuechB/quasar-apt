import QtQuick
import "accounts.js" as Accounts

// A person's picture: their initials on a disc in a hue that stays the same for that name
// (Settings › Users & Accounts, the sign-in screen, the lock screen, the password sheet).
// `name` is the account's display name; `seed` (the username) picks the hue when given.
Rectangle {
    id: root
    property string name: ""
    property string seed: ""
    property real size: 40
    readonly property color hue: Accounts.hue(seed !== "" ? seed : name)

    implicitWidth: size
    implicitHeight: size
    width: size
    height: size
    radius: size / 2
    color: Theme.alpha(hue, 0.16)
    border.width: Math.max(1, size / 48)
    border.color: Theme.alpha(hue, 0.42)
    Accessible.ignored: true

    Text {
        anchors.centerIn: parent
        text: Accounts.initials(root.name)
        font.family: Theme.fontDisplay
        font.pixelSize: Math.round(root.size * (text.length > 1 ? 0.36 : 0.42))
        font.weight: Font.Medium
        color: root.hue
    }
}
