import QtQuick
import Quickshell
import Quickshell.Io
import Quasar
import Quasar.Services
import "../components/users.js" as Users

// Settings > Users & Accounts: the people who use this PC, automatic sign-in and the way to Vault.
// Reads /etc/passwd, /etc/group and greetd's config.toml (world-readable) whenever the page opens
// and after every change: shadow tools replace those files, and a watch doesn't follow a rename.
// Changes go through helpers, each taking one JSON line on stdin (passwords never in argv):
//   pkexec quasar-users …        add / remove / set-admin / reset-password / rename / autologin
//   pkexec quasar-account rename your own name (your own password, not an administrator's)
//   change-password              your own password, through passwd, so the login keyring follows
// Stand-ins for tests: QUASAR_USERS, QUASAR_ACCOUNT, QUASAR_CHANGE_PASSWORD (tools/fake-users.py),
// QUASAR_ACCOUNTS_ETC (a folder holding passwd, group and greetd.toml to read instead).
Scope {
    id: root
    property bool active: false               // the page is shown
    property string busy: ""                  // row key of the change in progress
    property var ask: null                    // confirmation: { kind, name, title, message, button }
    property var form: null                   // dialog: { kind: "add" | "rename" | "password" | "reset", name, display, value }
    property string formError: ""             // the helper's refusal, shown in the open form
    property bool formBusy: false
    signal notify(var banner)
    signal pick(string title, var options, string current, var done, string message)

    readonly property string usersExe: Quickshell.env("QUASAR_USERS") || ""
    readonly property string accountExe: Quickshell.env("QUASAR_ACCOUNT") || ""
    readonly property string passwordExe: Quickshell.env("QUASAR_CHANGE_PASSWORD") || "/usr/libexec/quasar/change-password"
    readonly property string etc: Quickshell.env("QUASAR_ACCOUNTS_ETC") || ""
    readonly property string me: Quickshell.env("USER") || Quickshell.env("LOGNAME") || ""

    property string passwdText: ""
    property string groupText: ""
    property string greetdText: ""
    readonly property var people: Accounts.people(passwdText, groupText)
    readonly property string autologin: Accounts.autologinUser(greetdText)
    readonly property bool autologinLocked: Accounts.autologinLocked(greetdText)
    property var signedIn: []
    readonly property var takenNames: Accounts.parsePasswd(passwdText).map(a => a.name)
        .concat(Object.keys(Accounts.parseGroups(groupText)))
    readonly property var ctx: ({ me: me, people: people, autologin: autologin, autologinLocked: autologinLocked,
                                  live: Platform.live, busy: busy,
                                  signedIn: signedIn, myName: Platform.userName, meAdmin: Platform.isAdmin,
                                  icons: Icons, theme: Theme })
    readonly property var groups: Users.groups(ctx)
    function byName(n) { return people.find(p => p.name === n) || null }

    onActiveChanged: if (active) refresh()
    function refresh() {
        passwdFile.reload(); groupFile.reload(); greetdFile.reload()
        if (!sessions.running) sessions.running = true
    }
    FileView {
        id: passwdFile
        path: root.etc ? root.etc + "/passwd" : "/etc/passwd"
        blockLoading: true; printErrors: false
        onLoaded: root.passwdText = text()
    }
    FileView {
        id: groupFile
        path: root.etc ? root.etc + "/group" : "/etc/group"
        blockLoading: true; printErrors: false
        onLoaded: root.groupText = text()
    }
    FileView {
        id: greetdFile
        path: root.etc ? root.etc + "/greetd.toml" : "/etc/greetd/config.toml"
        blockLoading: true; printErrors: false
        onLoaded: root.greetdText = text()
        onLoadFailed: root.greetdText = ""
    }
    Process {
        id: sessions
        command: ["loginctl", "list-users", "--output=json"]
        stdout: StdioCollector {
            onStreamFinished: {
                try {
                    root.signedIn = JSON.parse(text || "[]").filter(u => u.state === "active" || u.state === "online").map(u => u.user)
                } catch (e) { root.signedIn = [] }
            }
        }
    }

    // ---- rows -> actions -----------------------------------------------------------------------------
    function activate(key) {
        if (Platform.live && key !== "vault") return
        if (key === "vault") { Quickshell.execDetached(["quasar-vault"]); return }
        if (key === "u:add") { open({ kind: "add" }); return }
        if (key === "autologin") { toggleAutologin(); return }
        if (key === "autologinUser") { chooseAutologin(); return }
        if (key === "autologinLock") { setAutologin(autologin, !autologinLocked, "autologinLock"); return }
        const k = Users.parseKey(key)
        if (!k) return
        const p = byName(k.name)
        if (k.name === me) {
            if (k.what === "name") open({ kind: "rename", name: me, value: p ? p.fullName : Platform.userName })
            else if (k.what === "password") open({ kind: "password", name: me })
            return
        }
        if (!p) return
        if (k.what === "type") {
            pick("Account type for " + p.display, [
                { key: "standard", label: "Standard", sub: "Uses apps and their own files. Asks an administrator to install apps or change the system." },
                { key: "admin", label: "Administrator", sub: "Can also install apps, add and remove people, and change the whole PC." }],
                p.admin ? "admin" : "standard",
                (v) => { if ((v === "admin") !== p.admin) root.run(key, "users", "set-admin", { username: p.name, admin: v === "admin" }) }, "")
        } else if (k.what === "password") {
            open({ kind: "reset", name: p.name, display: p.display })
        } else if (k.what === "remove") {
            if (signedIn.indexOf(p.name) >= 0) {
                notify({ tone: "warning", title: p.display + " is signed in", message: "They need to sign out before their account can be removed." })
                return
            }
            ask = { kind: "remove", name: p.name, title: "Remove " + p.display + "?",
                    message: p.display + "'s account and everything in it leave this PC: their files, apps, settings, "
                           + "saved passwords and passkeys, companies and websites. This can't be undone.",
                    button: "Remove " + p.display }
        }
    }
    function toggle(key) { activate(key) }

    function toggleAutologin() {
        if (autologin !== "") { run("autologin", "users", "autologin", { username: "" }); return }
        if (people.length > 1) { chooseAutologin(); return }
        run("autologin", "users", "autologin", { username: me })
    }
    // Remote desktop's "Sign in automatically after a restart" and "Lock the screen right away": one person,
    // locked or not ("" turns automatic sign-in off).
    function setAutologin(name, locked, key, done) {
        run(key || "autologin", "users", "autologin", { username: name, locked: !!locked }, done)
    }
    function chooseAutologin() {
        pick("Sign in automatically as", people.map(p => ({ key: p.name, label: p.display, sub: Users.sub(p) })),
             autologin || me, (v) => root.run("autologin", "users", "autologin", { username: v }),
             "The PC opens this person's desktop at startup without asking for a password.")
    }

    function open(f) { formError = ""; formBusy = false; form = f }
    function closeForm() { if (!formBusy) { form = null; formError = "" } }

    // The dialogs (Settings' shell.qml) call these. Values arrive as one object.
    function submitForm(v) {
        const f = form
        if (!f || formBusy) return
        formError = ""
        if (f.kind === "add") {
            formRun("u:add", "users", "add", { username: v.username, fullName: v.fullName, password: v.password, admin: !!v.admin },
                    () => notify({ tone: "success", title: (v.fullName || v.username) + " can sign in now",
                                   message: "They choose their account on the sign-in screen, or you can sign out to let them in." }))
        } else if (f.kind === "rename") {
            formRun("u:" + me + ":name", "account", "rename", { fullName: v.fullName }, () => { })
        } else if (f.kind === "reset") {
            formRun("u:" + f.name + ":password", "users", "reset-password", { username: f.name, password: v.password },
                    () => notify({ tone: "success", title: f.display + "'s password is changed",
                                   message: "Their saved passwords and passkeys stay locked until they type their old password once. "
                                          + "If they don't remember it, they can make a new Vault." }))
        } else if (f.kind === "password") {
            formRun("u:" + me + ":password", "password", "", { current: v.current, new: v.password },
                    () => notify({ tone: "success", title: "Your password is changed", message: "Use it the next time you sign in or unlock the screen." }))
        }
    }
    function confirm() {
        const a = ask
        ask = null
        if (a && a.kind === "remove")
            run("u:" + a.name + ":remove", "users", "remove", { username: a.name },
                () => notify({ tone: "success", title: "The account is removed", message: "" }))
    }

    // ---- running the helpers ---------------------------------------------------------------------------
    function command(tool, verb) {
        if (tool === "users") return (usersExe ? [usersExe] : ["pkexec", "/usr/libexec/quasar/quasar-users"]).concat([verb])
        if (tool === "account") return (accountExe ? [accountExe] : ["pkexec", "/usr/libexec/quasar/quasar-account"]).concat([verb])
        return [passwordExe]
    }
    // A form keeps its dialog open until the helper answers; its refusal shows inside the form.
    property var _done: null
    property bool _inForm: false
    function formRun(key, tool, verb, spec, done) {
        formBusy = true
        _inForm = true
        start(key, tool, verb, spec, done)
    }
    function run(key, tool, verb, spec, done) {
        _inForm = false
        start(key, tool, verb, spec, done)
    }
    function start(key, tool, verb, spec, done) {
        if (job.running) return
        busy = key
        _done = done || null
        job.run(command(tool, verb), undefined, JSON.stringify(spec) + "\n")
    }
    Cmd {
        id: job
        onFinished: (code) => {
            const done = root._done, inForm = root._inForm
            root._done = null
            root.busy = ""
            root.formBusy = false
            const err = job.details().split("\n").filter(l => l.startsWith("ERROR ")).map(l => l.slice(6)).pop() || ""
            if (code === 0) {
                if (inForm) { root.form = null; root.formError = "" }
                if (done) done()
            } else if (code === 126) {
                // The password sheet was closed: nothing happened, nothing to say.
            } else if (inForm) {
                root.formError = code === 127 ? "Your account isn't allowed to do this. Ask an administrator." : (err || "That didn't work.")
            } else {
                root.notify(code === 127
                    ? { tone: "error", title: "Your account isn't allowed to change accounts", message: "Ask an administrator." }
                    : { tone: "error", title: err || "That didn't work", message: err ? "" : "Nothing was changed.", details: job.details() })
            }
            root.refresh()
        }
    }
}
