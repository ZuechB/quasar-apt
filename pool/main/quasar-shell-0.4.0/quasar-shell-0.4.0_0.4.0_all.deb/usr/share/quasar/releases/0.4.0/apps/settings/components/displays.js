// Settings › Display and its sub page Arrange displays: rows and picker options built from
// `displays state` (linux/system/libexec/displays). Pure, so the Settings app (services/Displays.qml)
// and the design preview share it; tested by tools/test-displays-js.py.
//   st:  { outputs: [{ name, id, label, builtin, enabled, modes: [{ width, height, refresh, preferred,
//          current }], mode: [w, h, hz] | null, x, y, scale, transform, number, vrr, vrrRange, hdr,
//          hdrOn, recommendedScale }], key, saved, main, pending }          (null while loading)
//   ctx: { main: connector name of the main display, selected: the Arrange page's display,
//          vrr: Settings.displays.vrr, hdr: Settings.displays.hdr === true, renderer: the session's
//          WLR_RENDERER ("vulkan" while HDR can work, "" = the default one), hdrFailed: labwc couldn't
//          start on Vulkan this session, hdrBusy: a change is being applied, taskbarAll, nightLight,
//          softwareRender }
// Row keys stay the same whichever display a group is about, so a row updates in place; the page
// knows which display it means (main on Display, the selected one on Arrange displays).
.pragma library

var SCALES = [1, 1.25, 1.5, 1.75, 2]
var ORIENTATIONS = [
    { key: "normal", label: "Landscape" },
    { key: "90", label: "Portrait" },
    { key: "180", label: "Landscape, flipped" },
    { key: "270", label: "Portrait, flipped" }
]

function outputs(st) { return (st && st.outputs) || [] }
function find(st, name) { return outputs(st).filter(function (o) { return o.name === name })[0] || null }
function lit(st) { return outputs(st).filter(function (o) { return o.enabled }) }

function sizeText(w, h) { return w + " × " + h }
// "60 Hz", "59.94 Hz", "143.86 Hz": a whole number when the rate is within 0.09 % of one (59.951 is a
// 60 Hz mode's timing), otherwise the real rate, so 59.94 / 29.97 / 23.976 stay apart from 60 / 30 / 24.
function hzText(r) {
    var n = Math.round(r)
    return (n > 0 && Math.abs(r - n) / n < 0.0009 ? String(n) : (Math.round(r * 100) / 100).toFixed(2).replace(/0$/, "")) + " Hz"
}
function scaleText(s) { return Math.round((s || 1) * 100) + "%" }
function orientationText(t) {
    var o = ORIENTATIONS.filter(function (x) { return x.key === t })[0]
    return o ? o.label : "Landscape"
}
function title(o) { return o ? o.number + "  ·  " + o.label : "" }

// ---- picker options ------------------------------------------------------------------------------
// One entry per size, largest first; "Recommended" on the display's preferred size.
function resolutions(o) {
    var seen = {}, out = [], pref = (o.modes || []).filter(function (m) { return m.preferred })[0]
    var modes = (o.modes || []).slice().sort(function (a, b) { return b.width * b.height - a.width * a.height || b.width - a.width })
    for (var i = 0; i < modes.length; i++) {
        var k = modes[i].width + "x" + modes[i].height
        if (seen[k]) continue
        seen[k] = true
        out.push({ key: k, label: sizeText(modes[i].width, modes[i].height),
                   sub: pref && pref.width === modes[i].width && pref.height === modes[i].height ? "Recommended" : "" })
    }
    return out
}
// The rates the display offers at a size, fastest first (keys are the exact rates, 3 decimals).
function refreshRates(o, w, h) {
    var seen = {}, out = []
    var modes = (o.modes || []).filter(function (m) { return m.width === w && m.height === h })
                               .sort(function (a, b) { return b.refresh - a.refresh })
    for (var i = 0; i < modes.length; i++) {
        var label = hzText(modes[i].refresh)
        if (seen[label]) continue
        seen[label] = true
        out.push({ key: modes[i].refresh.toFixed(3), label: label, sub: "" })
    }
    return out
}
// The fastest mode at a size: what picking a resolution gives.
function fastest(o, w, h) {
    var best = null
    for (var i = 0; i < (o.modes || []).length; i++) {
        var m = o.modes[i]
        if (m.width === w && m.height === h && (!best || m.refresh > best.refresh)) best = m
    }
    return best ? [best.width, best.height, best.refresh] : null
}
function scales(o) {
    var list = SCALES.slice()
    if (o.scale && list.indexOf(o.scale) < 0) list.push(o.scale)
    list.sort(function (a, b) { return a - b })
    return list.map(function (s) {
        return { key: String(s), label: scaleText(s), sub: s === o.recommendedScale ? "Recommended" : "" }
    })
}
function orientations() { return ORIENTATIONS.map(function (x) { return { key: x.key, label: x.label, sub: "" } }) }

// ---- rows ----------------------------------------------------------------------------------------
// Resolution, refresh rate, scale (and, on Arrange displays, orientation) of one display that's on.
function modeRows(o, withOrientation) {
    var rows = []
    if (!o || !o.mode) return rows
    var rates = refreshRates(o, o.mode[0], o.mode[1])
    rows.push({ key: "dsp:res", label: "Resolution", trailing: "chevron", value: sizeText(o.mode[0], o.mode[1]) })
    rows.push({ key: "dsp:scale", label: "Scale", trailing: "chevron", value: scaleText(o.scale),
                sub: o.recommendedScale && Math.abs(o.recommendedScale - o.scale) > 0.001
                     ? "Recommended for this display: " + scaleText(o.recommendedScale) : "" })
    rows.push({ key: "dsp:hz", label: "Refresh rate", trailing: rates.length > 1 ? "chevron" : "value", value: hzText(o.mode[2]) })
    if (withOrientation)
        rows.push({ key: "dsp:rot", label: "Orientation", trailing: "chevron", value: orientationText(o.transform) })
    return rows
}

function vrrCapable(st) { return lit(st).filter(function (o) { return o.vrr }) }
function hdrCapable(st) { return lit(st).filter(function (o) { return o.hdr }) }
function hdrShowing(st) { return lit(st).filter(function (o) { return o.hdrOn }) }
function names(list) { return list.map(function (o) { return o.label }).join(", ") }

function vrrRow(st, ctx) {
    // Software rendering (no GPU: VMs, a missing driver) runs with adaptive sync off (xdg-software).
    if (ctx.softwareRender)
        return { key: "vrr", label: "Variable refresh rate", trailing: "value", value: "Off", sub: "Needs graphics acceleration" }
    var cap = vrrCapable(st)
    return { key: "vrr", label: "Variable refresh rate", trailing: "toggle", checked: ctx.vrr !== false,
             sub: cap.length ? "Smoother full-screen games and video" : "Needs a compatible display" }
}
// HDR: one switch for every display that can do it (labwc's <hdr> is global). While it's on, the
// session runs on wlroots' Vulkan renderer, the one that can drive a display in HDR10 (quasar-session
// picks it at sign-in), and each capable display switches to HDR when labwc sets it up. "On for …" comes
// from the displays themselves (hdrOn: what the compositor last sent them), never from the setting alone.
function hdrRow(st, ctx) {
    var cap = hdrCapable(st), showing = hdrShowing(st)
    if (ctx.softwareRender)
        return { key: "hdr", label: "HDR", trailing: "value", value: "Off", sub: "Needs graphics acceleration" }
    if (!ctx.hdr) {
        // Off: offered only when a display here can show it (turning it on changes the renderer at the
        // next sign-in, which buys nothing without an HDR display).
        if (!cap.length)
            return { key: "hdr", label: "HDR", trailing: "value", value: "Off", sub: "Needs an HDR display" }
        return { key: "hdr", label: "HDR", trailing: "toggle", checked: false,
                 sub: "Brighter highlights and richer colour in HDR games and video" }
    }
    var sub
    if (ctx.hdrFailed) sub = "Couldn't start HDR with this graphics card"
    else if (showing.length) sub = "On for " + names(showing)
    else if (!cap.length) sub = "Turns on when an HDR display is connected"
    else if (ctx.renderer !== "vulkan") sub = "Sign out and back in to finish turning it on"
    else if (ctx.hdrBusy) sub = "Turning on…"                // the displays are being set up again
    else sub = "Couldn't turn on HDR for " + names(cap)
    return { key: "hdr", label: "HDR", trailing: "toggle", checked: true, sub: sub }
}

// Settings › Display: the main display's mode rows, VRR, HDR; then Night light and Arrange displays.
function groups(st, ctx) {
    var m = find(st, ctx.main) || lit(st)[0] || null
    var n = outputs(st).length
    var rows = m ? modeRows(m, false) : [{ key: "dsp:res", label: "Resolution", trailing: "value", value: st ? "Unknown" : "" }]
    rows.push(vrrRow(st, ctx), hdrRow(st, ctx))
    return [
        { key: "dsp:main", label: n > 1 && m ? "Main display  ·  " + m.label : "Display", rows: rows },
        { key: "dsp:comfort", label: "Comfort", rows: [
            { key: "night", label: "Night light", sub: "Warmer colours in the evening", trailing: "toggle", checked: !!ctx.nightLight },
            { key: "arrange", label: "Arrange displays", trailing: "chevron", value: n === 1 ? "1 connected" : n + " connected" }] }
    ]
}

// Settings › Arrange displays: the selected display's own settings, then (with several) the taskbar.
function arrangeGroups(st, ctx) {
    var o = find(st, ctx.selected) || find(st, ctx.main) || outputs(st)[0] || null
    if (!o) return []
    var on = lit(st)
    var rows = []
    if (outputs(st).length > 1) {
        if (o.enabled && on.length === 1)
            rows.push({ key: "dsp:on", label: "Use this display", sub: "It's the only display that's on", trailing: "value", value: "On" })
        else
            rows.push({ key: "dsp:on", label: "Use this display", trailing: "toggle", checked: o.enabled })
    }
    if (o.enabled && on.length > 1) {
        if (o.name === ctx.main)
            rows.push({ key: "dsp:main", label: "Main display", sub: "Desktop icons and notifications show here", trailing: "value", value: "This display" })
        else
            rows.push({ key: "dsp:makemain", label: "Main display", sub: "Desktop icons and notifications show here", trailing: "button", value: "Make main" })
    }
    rows = rows.concat(modeRows(o.enabled ? o : null, true))
    rows.push({ key: "dsp:vrrinfo", label: "Variable refresh rate", trailing: "value",
                value: o.vrr ? (o.vrrRange ? "Supported  ·  " + o.vrrRange[0] + "–" + o.vrrRange[1] + " Hz" : "Supported") : "Not supported" })
    rows.push({ key: "dsp:hdrinfo", label: "HDR", trailing: "value",
                value: o.hdrOn ? "On" : o.hdr ? "Supported" : "Not supported" })
    var out = [{ key: "dsp:selected", label: title(o), rows: rows }]
    if (outputs(st).length > 1)
        out.push({ key: "dsp:multi", label: "Multiple displays", rows: [
            { key: "taskbarAll", label: "Taskbar on every display", sub: ctx.taskbarAll !== false ? "Each display has one, with all your apps" : "Only on the main display",
              trailing: "toggle", checked: ctx.taskbarAll !== false }] })
    return out
}

// ---- profiles -------------------------------------------------------------------------------------
// What Settings saves for the displays connected now: their layout (keyed by display id) and the
// main display, as Settings.displays.profiles[st.key]. `layout` is keyed by connector name.
function profile(st, layout, mainName, now) {
    var out = {}, mainId = ""
    for (var i = 0; i < outputs(st).length; i++) {
        var o = st.outputs[i]
        var e = layout[o.name]
        if (o.name === mainName) mainId = o.id
        if (!e) continue
        out[o.id] = e.enabled === false ? { enabled: false }
            : { enabled: true, mode: e.mode, x: e.x, y: e.y, scale: e.scale, transform: e.transform || "normal" }
    }
    return { main: mainId, saved: now, outputs: out }
}

// The live layout (connector name → settings), as `displays try` / `apply` take it.
function layoutOf(st) {
    var out = {}
    for (var i = 0; i < outputs(st).length; i++) {
        var o = st.outputs[i]
        out[o.name] = o.enabled && o.mode
            ? { enabled: true, mode: o.mode, x: o.x, y: o.y, scale: o.scale, transform: o.transform || "normal" }
            : { enabled: false }
    }
    return out
}

// The main display: the profile's choice when it's on, else the helper's.
function mainName(st, profiles) {
    if (!st) return ""
    var p = (profiles || {})[st.key]
    if (p && p.main) {
        var o = outputs(st).filter(function (x) { return x.id === p.main && x.enabled })[0]
        if (o) return o.name
    }
    return st.main || ""
}
