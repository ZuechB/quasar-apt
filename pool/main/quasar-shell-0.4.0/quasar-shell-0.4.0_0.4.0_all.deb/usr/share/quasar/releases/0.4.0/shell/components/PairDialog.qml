import QtQuick
import Quasar

// Bluetooth pairing questions (the shell is BlueZ's pairing agent, services/BluetoothAgent.qml): dims
// the screen, centred card with the device, the question and its answer buttons. AuthDialog's style.
//   confirm          "Does <device> show 123 456?"           Cancel / Pair
//   authorize        "<device> wants to pair"                Don't allow / Allow
//   service          "<device> wants to use audio"           Don't allow / Allow
//   pin | passkey    type the PIN / passkey for the device   Cancel / Pair   (Enter submits)
//   display-pin | display-passkey   "Type 123 456 on <device>"   Cancel
// Only the typed answers take Enter: a stray key press never approves a pairing.
// Pure view: the host connects it to the agent's current request.
Item {
    id: root
    property string mode: "confirm"
    property string deviceName: "Device"
    property string deviceGlyph: "bt"           // Icons key (BtDevices.kind(icon).glyph)
    property string code: ""                    // the number/PIN to compare (confirm) or type (display-*)
    property int entered: 0                     // display-passkey: digits typed on the device so far
    property string serviceName: ""             // service: what the device wants to use
    signal accepted(string value)
    signal declined()

    readonly property bool typing: mode === "pin" || mode === "passkey"
    readonly property bool showing: mode === "display-pin" || mode === "display-passkey"
    readonly property bool valid: mode === "pin" ? field.text.length >= 1 && field.text.length <= 16
                                : mode === "passkey" ? /^[0-9]{1,6}$/.test(field.text) : true

    // A passkey is always six digits (leading zeros included); a PIN is shown as it is.
    readonly property string shown: (mode === "confirm" || mode === "display-passkey") && /^[0-9]{1,6}$/.test(code)
                                    ? ("000000" + code).slice(-6) : code

    function focusInput() { if (typing) field.focusInput() }
    function clear() { field.text = "" }
    // The host's window may show before `mode` reaches us: focus the field once it's actually there.
    onTypingChanged: if (typing) Qt.callLater(focusInput)
    onVisibleChanged: if (visible && typing) Qt.callLater(focusInput)
    function grouped(c) { return c.length === 6 ? c.slice(0, 3) + " " + c.slice(3) : c }

    Rectangle {
        anchors.fill: parent
        color: Qt.rgba(0, 0, 0, 0.5)
        MouseArea { anchors.fill: parent }       // modal: clicks outside do nothing
    }

    Rectangle {
        id: card
        anchors.centerIn: parent
        width: Math.min(420, parent.width - 40)
        height: col.implicitHeight + 48
        radius: 22
        color: Theme.solid
        border.width: 1
        border.color: Theme.white(0.11)
        Accessible.role: Accessible.Dialog
        Accessible.name: title.text

        Column {
            id: col
            x: 24; y: 24
            width: parent.width - 48
            spacing: 14

            Rectangle {
                width: 46; height: 46; radius: 15
                color: Theme.alpha(Theme.accent, 0.14)
                QIcon { anchors.centerIn: parent; path: Icons.get(root.deviceGlyph); size: 22; strokeWidth: 1.9; color: Theme.accent }
            }
            Text {
                id: title
                width: parent.width
                wrapMode: Text.Wrap
                textFormat: Text.PlainText
                text: root.mode === "authorize" ? root.deviceName + " wants to pair"
                    : root.mode === "service" ? root.deviceName + " wants to connect"
                    : root.showing ? "Type this code on " + root.deviceName
                    : "Pair with " + root.deviceName + "?"
                font.family: Theme.fontDisplay; font.pixelSize: 20; font.weight: Font.Medium
                color: Theme.text
            }
            Text {
                width: parent.width
                wrapMode: Text.Wrap
                textFormat: Text.PlainText
                text: root.mode === "confirm" ? "Pair only if " + root.deviceName + " shows the same number."
                    : root.mode === "authorize" ? "Only allow it if you're pairing " + root.deviceName + " with this PC right now."
                    : root.mode === "service" ? root.deviceName + " wants to use " + (root.serviceName || "a service") + " on this PC."
                    : root.mode === "pin" ? "Enter the PIN for " + root.deviceName + ". It's often 0000 or 1234; check its manual."
                    : root.mode === "passkey" ? "Enter the 6-digit passkey " + root.deviceName + " shows."
                    : root.mode === "display-passkey" ? "Then press Enter on it."
                    : "Type it on " + root.deviceName + ", then press Enter on it if it asks."
                font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
                color: Theme.text3
            }

            // The number to compare or to type on the device: digits typed so far light up.
            Row {
                visible: root.mode === "confirm" || root.showing
                anchors.horizontalCenter: parent.horizontalCenter
                spacing: 2
                Repeater {
                    model: root.grouped(root.shown).split("")
                    delegate: Text {
                        required property string modelData
                        required property int index
                        readonly property int digit: index > 2 && root.shown.length === 6 ? index - 1 : index
                        text: modelData
                        font.family: Theme.fontMono; font.pixelSize: 34; font.weight: Font.Medium
                        font.letterSpacing: 2
                        color: root.mode === "display-passkey" && modelData !== " " && digit < root.entered ? Theme.accent : Theme.text
                    }
                }
            }

            TextField {
                id: field
                visible: root.typing
                width: parent.width
                glyph: Icons.bt
                mono: true
                placeholder: root.mode === "passkey" ? "6-digit passkey" : "PIN"
                inputItem.maximumLength: root.mode === "passkey" ? 6 : 16
                inputItem.inputMethodHints: root.mode === "passkey" ? Qt.ImhDigitsOnly : Qt.ImhNone
                onAccepted: if (root.valid) root.accepted(text)
                onEscapePressed: root.declined()
            }

            Row {
                anchors.right: parent.right
                spacing: 8
                Button {
                    text: root.mode === "authorize" || root.mode === "service" ? "Don't allow" : "Cancel"
                    variant: "outline"; size: 38
                    onClicked: root.declined()
                }
                Button {
                    visible: !root.showing
                    text: root.mode === "authorize" || root.mode === "service" ? "Allow" : "Pair"
                    variant: "primary"; size: 38
                    enabled: root.valid
                    onClicked: root.accepted(root.typing ? field.text : "")
                }
            }
        }
    }
}
