import QtQuick
import Quasar

// One tab: the terminal itself — created from `engine`, Quasar.Native's Terminal in the app and a
// mock in the design preview — plus an overlay scrollbar, the "program exited" strip, the
// right-click menu, IME pre-edit text and the visual bell.
//
// When the shell exits (`exit`, Ctrl+D) the tab closes; a -e command that failed keeps its tab open
// with the output and offers Restart (or Enter).
Item {
    id: pane
    property Component engine: null
    property bool active: false
    property bool windowActive: true
    // What runs. Read once, when the tab opens.
    property string startDir: ""
    property string program: ""
    property var args: []
    property string home: ""
    property var cfg: ({})

    readonly property real fontSize: cfg.fontSize !== undefined ? cfg.fontSize : 12.5
    readonly property real lineHeight: cfg.lineHeight !== undefined ? cfg.lineHeight : 1.6
    readonly property Item term: _term
    readonly property bool busy: !!_term && _term.running && _term.foregroundProcess !== ""
    readonly property string busyName: busy ? _term.foregroundProcess : ""
    readonly property bool failed: _failed
    // Tab title: what's running in front (unless it set its own title), else the shell's title
    // (Quasar's bash sets it to the folder), else the folder.
    readonly property string tabTitle: {
        const t = _term
        if (!t) return "Terminal"
        if (t.foregroundProcess !== "")
            return t.title !== "" && t.title !== _titleAtStart ? t.title : t.foregroundProcess
        if (t.title !== "") return t.title
        return shortPath(t.cwd)
    }

    signal closeRequested()
    signal newTabRequested()
    signal settingsRequested()
    signal linkOpened(string url)
    signal zoom(int steps)
    signal activityRaised(int level)       // 1 output, 2 bell — while this tab is in the background
    signal pasteConfirm(string text, int lines)   // several lines into a program without bracketed paste

    property Item _term: null
    property bool _failed: false
    property bool _everRan: false
    property string _titleAtStart: ""

    function shortPath(p) {
        if (!p) return "Terminal"
        if (home !== "" && p === home) return "~"
        if (home !== "" && p.startsWith(home + "/")) return "~" + p.slice(home.length)
        return p
    }
    function focusTerminal() { if (_term && active && !findBar.open) _term.forceActiveFocus() }
    function restart() { if (_term) { _term.restart(); focusTerminal() } }
    function showMenu(x, y) { menuLoader.active = true; menuLoader.item.show(x, y) }
    function openFind() { if (_term) findBar.show() }

    Component.onCompleted: {
        if (!engine || engine.status !== Component.Ready) { _failed = true; return }
        _term = engine.createObject(host, {
            workingDirectory: startDir,
            program: program,
            arguments: args || [],
            // Terminal › Settings › "Ignore upper/lower case" (read by /usr/share/quasar/bash/quasar.bash)
            environment: cfg.ignoreCase === false ? ["QUASAR_SHELL_NOCASE=0"] : [],
            fontFamily: Theme.fontMono,
            fontSize: fontSize,
            lineHeight: lineHeight,
            cursorStyle: cfg.cursorStyle || 0,
            cursorBlink: !!cfg.cursorBlink,
            scrollbackLines: cfg.scrollback || 10000,
            confirmMultilinePaste: cfg.confirmPaste !== false,
            cursorColor: Theme.accent,
            selectionColor: Theme.alpha(Theme.accent, 0.3)
        })
        if (!_term) { _failed = true; return }
        _term.anchors.fill = host
        _everRan = _term.running
        focusTerminal()
    }

    Binding { target: pane._term; property: "fontSize"; value: pane.fontSize; when: !!pane._term }
    Binding { target: pane._term; property: "lineHeight"; value: pane.lineHeight; when: !!pane._term }
    Binding { target: pane._term; property: "cursorStyle"; value: pane.cfg.cursorStyle || 0; when: !!pane._term }
    Binding { target: pane._term; property: "cursorBlink"; value: !!pane.cfg.cursorBlink; when: !!pane._term }
    Binding { target: pane._term; property: "scrollbackLines"; value: pane.cfg.scrollback || 10000; when: !!pane._term }
    Binding { target: pane._term; property: "confirmMultilinePaste"; value: pane.cfg.confirmPaste !== false; when: !!pane._term }
    Binding { target: pane._term; property: "cursorColor"; value: Theme.accent; when: !!pane._term }
    Binding { target: pane._term; property: "selectionColor"; value: Theme.alpha(Theme.accent, 0.3); when: !!pane._term }

    onActiveChanged: if (active) Qt.callLater(focusTerminal)
    onWindowActiveChanged: if (windowActive) focusTerminal()

    Connections {
        target: pane._term
        function onForegroundProcessChanged() { pane._titleAtStart = pane._term.title }
        function onRunningChanged() { if (pane._term.running) pane._everRan = true }
        // A shell's exit status is just its last command's (Ctrl+D after a failed `ls` is 2), so
        // a shell tab always closes; a -e command stays open on failure so its errors can be read.
        function onExited(code) { if (code === 0 || pane.program === "") pane.closeRequested() }
        function onContextMenuRequested(x, y) { pane.showMenu(x + host.x, y + host.y) }
        function onPasteConfirmationRequested(text, lines) { pane.pasteConfirm(text, lines) }
        function onLinkActivated(url) { pane.linkOpened(url) }
        function onZoomRequested(steps) { pane.zoom(steps) }
        function onBell() {
            if (pane.active) flash.restart()
            else pane.activityRaised(2)
        }
        function onOutputWhileHidden() { pane.activityRaised(1) }
        function onScrollChanged() { scrollbar.poke() }
    }

    // Enter on a tab whose program failed starts it again.
    Keys.onPressed: (e) => {
        if (exitStrip.shown && (e.key === Qt.Key_Return || e.key === Qt.Key_Enter)) {
            pane.restart()
            e.accepted = true
        }
    }

    // Template padding: 12px top/bottom, 16px left; the scrollbar sits in the right margin.
    Item {
        id: host
        anchors { fill: parent; leftMargin: 16; rightMargin: 12; topMargin: 12; bottomMargin: 8 }
    }

    Text {
        visible: pane._failed
        anchors.centerIn: parent
        width: Math.min(parent.width - 48, 460)
        horizontalAlignment: Text.AlignHCenter
        wrapMode: Text.Wrap
        text: "The terminal engine (Quasar.Native) isn't installed, so this tab can't run a shell."
        font.family: Theme.fontUi; font.pixelSize: 13
        color: Theme.textMuted
    }

    // ---- visual bell ------------------------------------------------------------------------------
    Rectangle {
        id: bellFlash
        anchors.fill: host
        color: Theme.accent
        opacity: 0
        radius: 6
        SequentialAnimation {
            id: flash
            NumberAnimation { target: bellFlash; property: "opacity"; to: 0.10; duration: Theme.reduceMotion ? 0 : 40 }
            PauseAnimation { duration: Theme.reduceMotion ? 120 : 0 }
            NumberAnimation { target: bellFlash; property: "opacity"; to: 0; duration: Theme.reduceMotion ? 0 : 220 }
        }
    }

    // ---- IME pre-edit (text being composed) -------------------------------------------------------
    Rectangle {
        visible: !!pane._term && pane._term.preeditText !== ""
        x: host.x + (pane._term ? pane._term.cursorRectangle.x : 0)
        y: host.y + (pane._term ? pane._term.cursorRectangle.y : 0)
        width: preedit.implicitWidth + 6
        height: pane._term ? pane._term.cellHeight : 20
        radius: 3
        color: Theme.solid
        border.width: 1
        border.color: Theme.alpha(Theme.accent, 0.5)
        Text {
            id: preedit
            x: 3
            anchors.verticalCenter: parent.verticalCenter
            text: pane._term ? pane._term.preeditText : ""
            font.family: Theme.fontMono; font.pointSize: Theme.pt(pane.fontSize); font.underline: true
            color: Theme.text
        }
    }

    // ---- overlay scrollbar: shows while scrolled back, scrolling or hovered -----------------------
    Item {
        id: scrollbar
        property bool recent: false
        function poke() { recent = true; hideLater.restart() }
        readonly property int hist: pane._term ? pane._term.historySize : 0
        readonly property int rows: pane._term ? Math.max(1, pane._term.rows) : 1
        readonly property int off: pane._term ? pane._term.scrollOffset : 0
        anchors { right: parent.right; rightMargin: 1; top: host.top; bottom: host.bottom }
        width: 10
        visible: hist > 0 && !!pane._term && !pane._term.altScreen
        opacity: off > 0 || recent || area.containsMouse || area.pressed ? 1 : 0
        Behavior on opacity { NumberAnimation { duration: Motion.dur(200) } }
        Timer { id: hideLater; interval: 1200; onTriggered: scrollbar.recent = false }

        Rectangle {
            id: thumb
            x: area.containsMouse || area.pressed ? 2 : 4
            width: area.containsMouse || area.pressed ? 6 : 4
            radius: width / 2
            color: Theme.white(area.pressed ? 0.42 : 0.26)
            height: Math.max(28, scrollbar.height * scrollbar.rows / (scrollbar.rows + scrollbar.hist))
            y: (scrollbar.height - height) * (1 - scrollbar.off / Math.max(1, scrollbar.hist))
        }
        MouseArea {
            id: area
            anchors.fill: parent
            hoverEnabled: true
            property real grab: 0
            function drag(y) {
                const travel = Math.max(1, scrollbar.height - thumb.height)
                const f = Math.min(1, Math.max(0, (y - grab) / travel))
                pane._term.scrollOffset = Math.round((1 - f) * scrollbar.hist)
            }
            onPressed: (m) => {
                grab = m.y >= thumb.y && m.y <= thumb.y + thumb.height ? m.y - thumb.y : thumb.height / 2
                drag(m.y)
            }
            onPositionChanged: (m) => { if (pressed) drag(m.y) }
            onReleased: pane.focusTerminal()
        }
    }

    // ---- the program exited with an error (or couldn't start) -------------------------------------
    Item {
        id: exitStrip
        readonly property bool shown: !!pane._term && !pane._term.running && (pane._everRan || pane._term.errorString !== "")
        visible: shown
        anchors { left: parent.left; right: parent.right; bottom: parent.bottom }
        height: 48
        // It reaches the window's rounded bottom corners. The fill is opaque, so not per-corner radii
        // (the software scene graph would punch holes): a rounded rect taller than the strip, clipped.
        clip: true
        Rectangle {
            anchors { left: parent.left; right: parent.right; bottom: parent.bottom }
            height: parent.height + radius
            radius: Theme.windowCorner(Window.visibility)
            color: Theme.solid
        }
        Rectangle { width: parent.width; height: 1; color: Theme.white(0.08) }
        Row {
            x: 16
            anchors.verticalCenter: parent.verticalCenter
            spacing: 10
            QIcon {
                anchors.verticalCenter: parent.verticalCenter
                path: Icons.alert; size: 16; strokeWidth: 2
                color: Theme.amber
            }
            Text {
                anchors.verticalCenter: parent.verticalCenter
                width: Math.min(implicitWidth, exitStrip.width - 330)
                elide: Text.ElideRight
                text: !pane._term ? "" : pane._term.errorString !== "" ? "Couldn't start: " + pane._term.errorString
                     : "The program exited with code " + pane._term.exitCode + "."
                font.family: Theme.fontUi; font.pixelSize: 13
                color: Theme.text2
            }
            Text {
                anchors.verticalCenter: parent.verticalCenter
                text: "Enter starts it again"
                font.family: Theme.fontUi; font.pixelSize: 12
                color: Theme.textFaint
            }
        }
        Row {
            anchors { right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter }
            spacing: 8
            Button { text: "Restart"; variant: "soft"; size: 30; onClicked: pane.restart() }
            Button { text: "Close tab"; variant: "outline"; size: 30; onClicked: pane.closeRequested() }
        }
    }

    TerminalFindBar {
        id: findBar
        // Top right, unless the current match is right there: then the bottom corner. Tested
        // against the top spot, not `y`, so the move can't feed back into the test.
        readonly property bool dodge: {
            const t = pane._term
            if (!open || !t || !t.findRectangle || t.findRectangle.width <= 0) return false
            const r = t.findRectangle
            const m = t.mapToItem(pane, r.x, r.y, r.width, r.height)
            return m.y < 8 + height + 4 && m.x + m.width > pane.width - 14 - width - 4
        }
        anchors { right: parent.right; rightMargin: 14 }
        y: dodge ? pane.height - height - 12 : 8
        Behavior on y { NumberAnimation { duration: Motion.dur(160); easing.type: Easing.OutCubic } }
        z: 800
        onSearch: (text, backwards, caseSensitive) => found = !!pane._term && pane._term.find(text, backwards, caseSensitive)
        onClosed: {
            open = false
            if (pane._term) pane._term.clearFind()
            pane.focusTerminal()
        }
    }

    // Created on first use: most tabs never open it.
    Loader {
        id: menuLoader
        anchors.fill: parent
        z: 900
        active: false
        sourceComponent: menuComponent
    }
    Component {
        id: menuComponent
        TerminalMenu {
            items: [
                { key: "copy", label: "Copy", glyph: "copy", hint: "Ctrl+Shift+C", enabled: !!pane._term && pane._term.hasSelection },
                { key: "paste", label: "Paste", glyph: "paste", hint: "Ctrl+Shift+V" },
                { key: "selectAll", label: "Select all", glyph: "check" },
                { key: "find", label: "Find…", glyph: "search", hint: "Ctrl+Shift+F" },
                { sep: true },
                { key: "clear", label: "Clear scrollback", glyph: "trash" },
                { sep: true },
                { key: "newTab", label: "New tab", glyph: "plus", hint: "Ctrl+Shift+T" },
                { key: "settings", label: "Settings", glyph: "gear", hint: "Ctrl+," }
            ]
            onDismissed: { open = false; pane.focusTerminal() }
            onChosen: (key) => {
                open = false
                const t = pane._term
                if (key === "copy" && t) t.copy()
                else if (key === "paste" && t) t.paste()
                else if (key === "selectAll" && t) t.selectAll()
                else if (key === "find") { pane.openFind(); return }
                else if (key === "clear" && t) t.clearScrollback()
                else if (key === "newTab") pane.newTabRequested()
                else if (key === "settings") pane.settingsRequested()
                pane.focusTerminal()
            }
        }
    }
}
