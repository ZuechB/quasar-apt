//@ pragma AppId quasar-sites
// Quasar Sites — host websites from this PC (native Qt Quick app run by Quickshell, launched by
// /usr/bin/quasar-sites). The engine is linux/system/sites (Caddy + one sandboxed service per site):
//   reads    /usr/libexec/quasar/sites-query        (this account, no password)
//   routine  pkexec /usr/libexec/quasar/quasar-sites (no password for administrators at the PC)
//   big      pkexec /usr/libexec/quasar/quasar-sites-admin (password every time)
// Tests swap them with QUASAR_SITES_QUERY / QUASAR_SITES_HELPER / QUASAR_SITES_ADMIN
// (tools/fake-sites-backend.sh). Deep links: quasar-sites [new|server|site/<id>]
import QtQuick
import Quickshell
import Quickshell.Io
import Quasar
import Quasar.Services
import "components"
import "services"

ShellRoot {
    id: app

    Binding { target: Theme; property: "accent"; value: Settings.accent }
    Binding { target: Theme; property: "reduceMotion"; value: Settings.reduceMotion }
    Binding { target: Theme; property: "softwareRender"; value: Platform.softwareScene }
    Binding { target: Theme; property: "profile"; value: Platform.softwareRender ? 0 : (Settings.profile >= 0 ? Settings.profile : 1) }

    // ---- helpers -----------------------------------------------------------------------------------
    readonly property string queryExe: Quickshell.env("QUASAR_SITES_QUERY") || "/usr/libexec/quasar/sites-query"
    readonly property string routineExe: Quickshell.env("QUASAR_SITES_HELPER") || ""
    readonly property string adminExe: Quickshell.env("QUASAR_SITES_ADMIN") || ""
    function q(args) { return [queryExe].concat(args) }
    function routine(args) { return (routineExe ? [routineExe] : ["pkexec", "/usr/libexec/quasar/quasar-sites"]).concat(args) }
    function admin(args) { return (adminExe ? [adminExe] : ["pkexec", "/usr/libexec/quasar/quasar-sites-admin"]).concat(args) }
    function notify(title, body) { Quickshell.execDetached(["notify-send", "-a", "Sites", "-i", "network-server", title, body || ""]) }

    // ---- state ---------------------------------------------------------------------------------------
    property var st: ({ active: false, sites: [], proxy: "inactive", live: false, caddy: true })
    property bool loaded: false
    property string view: "auto"                 // auto | new | server
    property string selectedId: ""
    property int tab: 0
    property var detail: null
    property var metrics: ({ rpm: 0, p95: null, hist: [] })
    property var logs: []
    property var revealed: ({})
    property bool confirmRemove: false
    property bool confirmOff: false
    property bool busy: false
    property string siteError: ""
    property string siteErrorDetails: ""
    property string serverMessage: ""
    property string serverError: ""
    property string serverErrorDetails: ""
    property var activation: ({ working: false, current: -1, failed: false, error: "", details: "" })
    property var projects: []
    property var roots: []                       // the usual project folders that exist (the chooser's places)
    property bool scanning: false
    property bool makingStarter: false           // sites-query starter is making the example's folder
    property var draft: null
    property bool detecting: false
    property string detectError: ""
    property var tools: ({})
    property var toolJob: ({ active: false, percent: 0, phase: "", error: "" })
    property var newDeploy: ({ running: false, steps: [], current: -1, failed: false, lines: [] })
    property string newError: ""
    property string newErrorDetails: ""
    property var deploy: ({ siteId: "", running: false, steps: [], current: -1, failed: false, lines: [] })
    property real now: Date.now()

    readonly property var site: (st.sites || []).find(s => s.id === selectedId) || null
    // The Turn on page stays up until the whole first run is done, example site included.
    readonly property string page: !loaded ? "loading" : !st.active || activation.working ? "turnon" : view === "new" ? "new"
                                 : view === "server" ? "server" : (st.sites || []).length === 0 ? "empty" : "site"

    readonly property var model: ({
        page: page === "loading" ? "empty" : page, active: st.active, live: st.live, caddy: st.caddy, proxy: st.proxy,
        caCode: st.caCode, everywhere: st.everywhere, home: Quickshell.env("HOME") || "", sites: st.sites || [],
        selectedId: selectedId, activation: activation, projects: projects, roots: roots,
        drives: "/media/" + (Quickshell.env("USER") || ""), scanning: scanning, makingStarter: makingStarter, draft: draft,
        detecting: detecting, detectError: detectError, tools: tools, toolJob: toolJob, newDeploy: newDeploy,
        newError: newError, newErrorDetails: newErrorDetails, detail: detail, metrics: metrics, logs: logs,
        deploy: deploy.siteId === selectedId ? deploy : { steps: [], current: -1, failed: false, lines: [] },
        tab: tab, revealed: revealed, confirmRemove: confirmRemove, confirmOff: confirmOff, busy: busy,
        siteError: siteError, siteErrorDetails: siteErrorDetails, serverMessage: serverMessage,
        serverError: serverError, serverErrorDetails: serverErrorDetails, now: now
    })

    // ---- polling -------------------------------------------------------------------------------------
    Job {
        id: stateJob
        onDone: (ok, res) => {
            if (ok && res) {
                app.st = res
                app.loaded = true
                const ids = (res.sites || []).map(s => s.id)
                if (!ids.includes(app.selectedId)) app.selectedId = ids.length ? ids[0] : ""
                // A deploy started elsewhere (a timer, another window): show its progress.
                const s = (res.sites || []).find(x => x.id === app.selectedId)
                if (s && s.deploying && !app.deploy.running) app.followDeploy(s.id, "")
            } else if (!app.loaded) {
                app.loaded = true
            }
        }
    }
    function refresh() { if (!stateJob.running) stateJob.start(q(["state"])) }
    Timer {
        interval: app.deploy.running ? 2000 : 5000
        repeat: true
        running: win.visible
        triggeredOnStart: true
        onTriggered: { app.now = Date.now(); app.refresh(); if (app.page === "site" && app.tab === 1) app.loadDetail() }
    }

    Job {
        id: detailJob
        onDone: (ok, res) => { if (ok && res && res.site && res.site.id === app.selectedId) app.detail = res.site }
    }
    function loadDetail() { if (selectedId && !detailJob.running) detailJob.start(q(["site", selectedId])) }
    onSelectedIdChanged: { detail = null; logs = []; metrics = { rpm: 0, p95: null, hist: [] }; revealed = {}; confirmRemove = false; siteError = ""; loadDetail() }

    Stream {
        id: metricsStream
        active: win.visible && app.page === "site" && !!app.site && app.site.state === "live"
        cmd: app.selectedId ? app.q(["metrics", app.selectedId, "-f"]) : []
        onEvent: (ev) => { if (ev.type === "result" && ev.metrics) app.metrics = ev.metrics }
    }
    Stream {
        id: logStream
        active: win.visible && app.page === "site" && app.tab === 3 && !!app.selectedId
        cmd: app.selectedId ? app.q(["logs", app.selectedId, "-f"]) : []
        onActiveChanged: if (active) app.logs = []
        onEvent: (ev) => {
            if (ev.type !== "log") return
            const tone = / 5\d\d in /.test(ev.m) ? Theme.danger : / 4\d\d in /.test(ev.m) ? Theme.amber : ""
            const d = new Date((ev.t || 0) * 1000)
            const pad = (n) => (n < 10 ? "0" : "") + n
            const line = { t: pad(d.getHours()) + ":" + pad(d.getMinutes()) + ":" + pad(d.getSeconds()), m: ev.m, c: tone }
            const next = app.logs.concat([line])
            app.logs = next.length > 400 ? next.slice(next.length - 400) : next
        }
    }

    // ---- deploy progress -------------------------------------------------------------------------------
    Stream {
        id: followStream
        active: false
        onEvent: (ev) => app.onDeployEvent(ev)
        onEnded: (code) => { if (app.deploy.running) app.onDeployEvent({ type: "done", ok: false, message: "The deploy stopped unexpectedly." }) }
    }
    function followDeploy(id, run, starter) {
        deploy = { siteId: id, running: true, steps: [], current: -1, failed: false, lines: [],
                   fromNew: view === "new" && !!draft, fromStarter: !!starter }
        if (deploy.fromNew) newDeploy = deploy
        followStream.active = false
        followStream.cmd = q(["follow", id].concat(run ? [run] : []))
        followStream.active = true
    }
    function onDeployEvent(ev) {
        const d = Object.assign({}, deploy)
        if (ev.type === "plan") { d.steps = ev.steps || []; d.current = -1; d.kind = ev.kind }
        else if (ev.type === "step") { d.current = (ev.n || 1) - 1; if (ev.cmd) d.lines = d.lines.concat(["$ " + ev.cmd]) }
        else if (ev.type === "line") { d.lines = d.lines.concat([ev.text]); if (d.lines.length > 300) d.lines = d.lines.slice(d.lines.length - 300) }
        else if (ev.type === "done") {
            d.running = false
            followStream.active = false
            if (d.fromStarter) finishFirstRun(d.siteId)
            if (ev.ok) {
                d.current = d.steps.length
                const s = (st.sites || []).find(x => x.id === d.siteId)
                if (d.fromStarter) {
                    notify("Your example site is live", "https://" + (s ? s.hostname : d.siteId + ".localhost"))
                } else if (d.fromNew) {
                    notify(d.siteId + " is live", "https://" + (s ? s.hostname : d.siteId + ".localhost"))
                    view = "auto"; draft = null; selectedId = d.siteId; tab = 0
                } else if (d.kind === "rollback") {
                    notify("Rolled back " + d.siteId, "Traffic switched over with no downtime")
                } else {
                    notify("Deployed " + (ev.hash || ""), d.siteId + " switched over with no downtime")
                }
            } else {
                d.failed = true
                if (ev.message) d.lines = d.lines.concat([ev.message])
                if (!win.visible) notify(d.siteId + " didn’t deploy", ev.message || "")
            }
            refresh()
            loadDetail()
        }
        deploy = d
        if (d.fromNew) newDeploy = d
    }

    // ---- actions ---------------------------------------------------------------------------------------
    Job {
        id: action
        property var then: null
        onDone: (ok, res, err) => {
            const next = action.then
            action.then = null
            app.busy = false
            if (next) next(ok, res, err)
            app.refresh()
            app.loadDetail()
        }
    }
    function act(cmd, input, then) {
        if (action.running) return
        busy = true
        action.then = then || null
        action.start(cmd, input)
    }
    function siteFail(err) {
        if (!err || err.code === "cancelled") { if (err) siteError = err.message; return }
        siteError = err.message || "That didn’t work."
        siteErrorDetails = err.details || ""
    }

    Job {
        id: activateJob
        onEvent: (ev) => { if (ev.type === "phase") app.activation = Object.assign({}, app.activation, { current: (ev.step || 1) - 1 }) }
        onDone: (ok, res, err) => {
            const starter = !!app.activation.starter
            if (ok && starter) {
                // Step 4: make ~/Sites/my-site, then create and deploy it like any new site.
                app.activation = Object.assign({}, app.activation, { current: 3 })
                app.refresh()
                starterJob.first = true
                starterJob.start(app.q(["starter"]))
                return
            }
            app.activation = ok ? { working: false, current: 3, failed: false, error: "", details: "", starter: starter }
                                : { working: false, current: app.activation.current, failed: !!err && err.code !== "cancelled",
                                    error: err ? err.message : "", details: err ? err.details || "" : "", starter: starter }
            if (ok) app.notify("Sites is on", "Quasar’s certificate authority is trusted on this PC.")
            app.refresh()
        }
    }
    // The first run is over (the example site deployed, or couldn't be made): show the site, or the
    // empty page if there's none. Sites itself is on either way.
    function finishFirstRun(siteId) {
        activation = { working: false, current: 4, failed: false, error: "", details: "", starter: true }
        view = "auto"; tab = 0
        if (siteId) selectedId = siteId
        refresh()
    }
    function firstRunFailed(err) {
        finishFirstRun("")
        notify("The example site wasn’t created", (err && err.message) || "Sites is on. Make a site with New site.")
    }

    // The example site's folder (~/Sites/my-site with an index.html), from the first run or New site's
    // "Example page" card.
    Job {
        id: starterJob
        property bool first: false
        onDone: (ok, res, err) => {
            app.makingStarter = false
            const p = ok && res ? res.project : null
            if (starterJob.first) {
                starterJob.first = false
                if (!p) { app.firstRunFailed(err); return }
                app.createAndDeploy(Object.assign({}, p, { hostname: p.id + ".localhost" }), true)
                return
            }
            if (app.view !== "new") return
            if (!p) { app.detectError = err ? err.message : "The example page couldn’t be made."; return }
            app.detectError = ""
            app.draft = Object.assign({}, p, { hostname: p.id + ".localhost" })
        }
    }

    Job {
        id: scanJob
        onDone: (ok, res) => { app.scanning = false; app.projects = ok && res ? res.projects || [] : []; app.roots = ok && res ? res.roots || [] : [] }
    }
    Job {
        id: toolsJob
        onDone: (ok, res) => { if (ok && res) app.tools = res.tools || {} }
    }
    Job {
        id: detectJob
        onDone: (ok, res, err) => {
            app.detecting = false
            if (ok && res && res.project) {
                const p = res.project
                app.detectError = ""
                app.draft = Object.assign({}, p, { hostname: p.id + ".localhost" })
            } else {
                app.detectError = err ? err.message : "Sites couldn’t read that folder."
            }
        }
    }
    Cmd {
        id: toolCmd
        onLine: (l) => {
            if (l.startsWith("PROGRESS ")) app.toolJob = Object.assign({}, app.toolJob, { percent: parseInt(l.slice(9)) || 0 })
            else if (l.startsWith("PHASE ")) app.toolJob = Object.assign({}, app.toolJob, { phase: l.slice(6) })
            else if (l.startsWith("ERROR ")) app.toolJob = Object.assign({}, app.toolJob, { error: l.slice(6) })
        }
        onFinished: (code) => {
            app.toolJob = { active: false, percent: 0, phase: "", error: code === 0 ? "" : (app.toolJob.error || "The download didn’t finish. Check the internet connection and try again.") }
            toolsJob.start(app.q(["tools"]))
        }
    }

    // A typed or pasted folder: ~ and ~/…, file:// URLs (pasted from Files), paths relative to Home
    // ("Sites/my-site"), no trailing slash.
    function expandHome(p) {
        const home = Quickshell.env("HOME") || ""
        p = (p || "").trim()
        if (p.startsWith("file://")) { try { p = decodeURIComponent(p.slice(7)) } catch (e) { p = p.slice(7) } }
        if (p === "") return ""
        p = p === "~" ? home : p.startsWith("~/") ? home + p.slice(1) : p.startsWith("/") ? p : home + "/" + p
        while (p.length > 1 && p.endsWith("/")) p = p.slice(0, -1)
        return p
    }

    // Create a site from a draft, deploy it and follow the deploy (New site's Deploy, and the first run's
    // example site with `starter`).
    function createAndDeploy(d, starter) {
        const first = (d.hostname || "").split(".")[0]
        const sid = /^[a-z][a-z0-9-]{0,24}[a-z0-9]$/.test(first) ? first : d.id
        const spec = { id: sid, kind: d.kind, label: d.label, framework: d.framework, tool: d.tool,
                       source: { type: "folder", path: d.path }, build: d.build || "", run: d.run || "",
                       output: d.output, health: d.health, hostname: d.hostname }
        newError = ""
        const fail = (err, fallback) => {
            if (starter) { firstRunFailed(err); return }
            newError = err ? err.message : fallback; newErrorDetails = err ? err.details || "" : ""
        }
        if (action.running) { if (starter) firstRunFailed(null); return }     // act() would drop it
        act(routine(["create"]), JSON.stringify(spec) + "\n", (ok, res, err) => {
            if (!ok) { fail(err, "The site wasn’t created."); return }
            act(routine(["deploy", sid]), undefined, (ok2, res2, err2) => {
                if (!ok2) { fail(err2, "The deploy didn’t start."); return }
                followDeploy(sid, res2 ? res2.run : "", starter)
            })
        })
    }

    function handle(name, a, b, c) {
        const id = selectedId
        switch (name) {
        case "turnOn":
            // No sites on this PC yet: the first run also publishes the example site (step 4).
            activation = { working: true, current: 0, failed: false, error: "", details: "", starter: (st.sites || []).length === 0 }
            activateJob.start(admin(["activate"]))
            break
        case "openNew":
            view = "new"; draft = null; detectError = ""; newError = ""; projects = []; scanning = true
            newDeploy = { running: false, steps: [], current: -1, failed: false, lines: [] }
            scanJob.start(q(["scan"])); toolsJob.start(q(["tools"]))
            break
        case "select": view = "auto"; selectedId = a; tab = 0; break
        case "openServer": view = "server"; serverMessage = ""; serverError = ""; confirmOff = false; break
        case "pick":
        case "pathEdited": {
            const path = expandHome(a)
            if (!path) break
            if (draft && draft.path === path) break
            detecting = true; detectError = ""
            detectJob.start(q(["detect", path]))
            break
        }
        case "draftEdited": {
            const d = Object.assign({}, draft); d[a] = b; draft = d
            break
        }
        case "installTool":
            toolJob = { active: true, percent: 0, phase: "Starting…", error: "" }
            toolCmd.run(["/usr/libexec/quasar/quasar-dev", "install", a, b])
            break
        case "createSite": createAndDeploy(draft, false); break
        case "starter":
            if (starterJob.running) break
            makingStarter = true; detectError = ""
            starterJob.first = false
            starterJob.start(q(["starter"]))
            break
        case "cancelNew": view = "auto"; draft = null; break
        case "openUrl": Quickshell.execDetached(["/usr/libexec/quasar/fileop", "open", a]); break      // its own scope (Network monitor)
        case "openFolder": if (a) Quickshell.execDetached(["/usr/libexec/quasar/fileop", "open", a]); break   // Files (inode/directory)
        case "start": siteError = ""; act(routine(["start", id]), undefined, (ok, r, e) => { if (!ok) siteFail(e) }); break
        case "stop": siteError = ""; act(routine(["stop", id]), undefined, (ok, r, e) => { if (!ok) siteFail(e) }); break
        case "restart": siteError = ""; act(routine(["restart", id]), undefined, (ok, r, e) => { if (ok) notify(id + " restarted", ""); else siteFail(e) }); break
        case "deploy":
            siteError = ""
            act(routine(["deploy", id]), undefined, (ok, res, e) => { if (ok) followDeploy(id, res ? res.run : ""); else siteFail(e) })
            break
        case "cancelDeploy": act(routine(["cancel", id])); break
        case "rollback":
            act(routine(["rollback", id, a]), undefined, (ok, res, e) => { if (ok) followDeploy(id, res ? res.run : ""); else siteFail(e) })
            break
        case "tab": tab = a; if (a === 1 || a === 2) loadDetail(); break
        case "envSet":
            act(routine(["env-set", id, a].concat(c ? ["--secret"] : [])), b, (ok, r, e) => {
                if (ok) notify(a + (c ? " saved encrypted" : " added"), "Applies on the next restart"); else siteFail(e)
            })
            break
        case "envRemove": act(routine(["env-unset", id, a]), undefined, (ok, r, e) => { if (!ok) siteFail(e) }); break
        case "reveal":
            act(admin(["secret-reveal", id, a]), undefined, (ok, r, e) => {
                if (!ok) { siteFail(e); return }
                const ev = action.tail.map(l => { try { return JSON.parse(l) } catch (x) { return null } }).find(o => o && o.type === "secret")
                if (ev) { const rv = Object.assign({}, revealed); rv[a] = ev.value; revealed = rv }
            })
            break
        case "hide": { const rv = Object.assign({}, revealed); delete rv[a]; revealed = rv; break }
        case "setOption": act(routine(["set-option", id, a, b ? "on" : "off"]), undefined, (ok, r, e) => { if (!ok) siteFail(e) }); break
        case "askRemove": confirmRemove = true; break
        case "cancelRemove": confirmRemove = false; break
        case "remove":
            act(admin(["remove", id]), undefined, (ok, r, e) => {
                confirmRemove = false
                if (ok) notify(id + " removed", "Your project folder was not touched"); else siteFail(e)
            })
            break
        case "dismissError": siteError = ""; siteErrorDetails = ""; break
        case "trustAgain":
            serverMessage = ""; serverError = ""
            act(admin(["trust"]), undefined, (ok, r, e) => { if (ok) serverMessage = "This PC trusts Quasar’s certificate authority again."; else if (e) { serverError = e.message; serverErrorDetails = e.details || "" } })
            break
        case "trustBrowsers":
            serverMessage = ""; serverError = ""
            act(q(["trust-browsers"]), undefined, (ok, r, e) => {
                if (ok) serverMessage = r && r.trusted && r.trusted.length ? "Chrome and your other browsers trust Quasar’s certificates. Restart them to pick it up." : "No other browser stores were found."
                else if (e) { serverError = e.message; serverErrorDetails = e.details || "" }
            })
            break
        case "askTurnOff": confirmOff = true; break
        case "cancelTurnOff": confirmOff = false; break
        case "turnOff":
            act(admin(["deactivate"]), undefined, (ok, r, e) => { confirmOff = false; if (ok) { view = "auto"; notify("Sites is off", "Nothing on this PC answers web requests now.") } else if (e) { serverError = e.message; serverErrorDetails = e.details || "" } })
            break
        }
    }

    // ---- deep links ------------------------------------------------------------------------------------
    function navigateTo(arg) {
        arg = (arg || "").trim()
        if (arg === "new") handle("openNew")
        else if (arg === "server") handle("openServer")
        else if (arg.startsWith("site/")) { view = "auto"; selectedId = arg.slice(5) }
    }
    Component.onCompleted: navigateTo(Quickshell.env("QUASAR_APP_ARGS"))

    AppWindow {
        id: win
        appName: "sites"
        title: "Sites"
        glyph: Icons.web
        glyphColor: Theme.accent
        defaultSize: Qt.size(1150, 730)
        // Deploys run in their own systemd unit, so closing the window never interrupts one.
        SitesView {
            anchors.fill: parent
            m: app.model
            onAct: (name, a, b, c) => app.handle(name, a, b, c)
        }
    }

    IpcHandler {
        target: "app"
        function open(arg: string): void { app.navigateTo(arg); win.visible = true }
    }
}
