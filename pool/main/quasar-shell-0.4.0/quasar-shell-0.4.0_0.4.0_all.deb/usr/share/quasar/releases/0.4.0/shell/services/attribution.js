.pragma library
// Which company owns each window (company environments). Quickshell's toplevels carry no workspace,
// pid or sandbox id, so the shell infers ownership. The rules, strongest first:
//   1. follow apps (Quasar Settings, Store, Installer) belong to everyone: "*";
//   2. a window still activated 150 ms after focus or the desktop changed belongs to the company
//      whose desktop is shown (labwc switches desktops to activate a window). The delay ignores the
//      flicker of a window that labwc focuses on map and then, after a "send to desktop" rule,
//      un-focuses again;
//   3. a window of a desktop entry the shell launched into a company in the last 30 s belongs to
//      that company (the newest launch wins and isn't used up: apps open several windows);
//   4. a window that isn't activated within 800 ms of appearing opened on another desktop: it
//      belongs to the one running company that isn't shown, or, with several, it is "?" (unplaced);
//   5. windows that were already there when the shell started belong to the company shown then.
// Dialogs (toplevels with a parent) follow their main window.
// The caller (CompanyDesk) supplies time and context and runs the timers; nothing here touches QML.

var ACTIVATION_DELAY = 150
var BIRTH_DELAY = 800
var LAUNCH_WINDOW = 30000

function create() {
    return { owner: new Map(), born: new Map(), pending: [] }
}

function mainOf(t) {
    var m = t
    for (var i = 0; i < 8 && m && m.parent; i++) m = m.parent
    return m
}

// The shell started desktop entry `entryId` inside company `co` at time `now`.
function noteLaunch(s, co, entryId, now) {
    s.pending = s.pending.filter(function (p) { return now - p.at < LAUNCH_WINDOW })
    s.pending.push({ co: co, entryId: entryId, at: now })
}

// The toplevel list changed. ctx: { active, now, initial, entryIdOf(t) -> id|"", isFollow(id) }.
// Returns { changed, born: [toplevels whose fate waits for activation or the birth timeout] }.
function sync(s, toplevels, ctx) {
    var changed = false, born = []
    var alive = new Set(toplevels)
    s.owner.forEach(function (o, t) { if (!alive.has(t)) { s.owner.delete(t); changed = true } })
    s.born.forEach(function (at, t) { if (!alive.has(t)) s.born.delete(t) })
    for (var i = 0; i < toplevels.length; i++) {
        var t = toplevels[i]
        if (s.owner.has(t) || s.born.has(t)) continue
        var m = mainOf(t)
        var eid = ctx.entryIdOf(m) || ""
        if (eid && ctx.isFollow(eid)) { s.owner.set(t, "*"); changed = true; continue }
        if (m !== t && s.owner.has(m)) { s.owner.set(t, s.owner.get(m)); changed = true; continue }
        var launch = null
        for (var j = s.pending.length - 1; j >= 0; j--) {
            var p = s.pending[j]
            if (p.entryId === eid && eid && ctx.now - p.at < LAUNCH_WINDOW) { launch = p; break }
        }
        if (launch) { s.owner.set(t, launch.co); changed = true; continue }
        if (ctx.initial) { s.owner.set(t, ctx.active); changed = true; continue }
        s.born.set(t, ctx.now)
        born.push(t)
    }
    return { changed: changed, born: born }
}

// Rule 2: `t` has been activated for ACTIVATION_DELAY while company `active` was shown.
function activated(s, t, active) {
    var o = s.owner.get(t)
    s.born.delete(t)
    if (o === "*" || o === active) return false
    s.owner.set(t, active)
    return true
}

// Rule 4: BIRTH_DELAY after `t` appeared. ctx: { active, running: [ids] } (running includes "personal").
function birthTimeout(s, t, ctx) {
    if (!s.born.has(t)) return false
    s.born.delete(t)
    var others = ctx.running.filter(function (id) { return id !== ctx.active })
    s.owner.set(t, others.length === 1 ? others[0] : "?")
    return true
}

function ownerOf(s, t) {
    var m = mainOf(t)
    if (s.owner.has(m)) return s.owner.get(m)
    if (s.owner.has(t)) return s.owner.get(t)
    return null
}

// Shown in the taskbar of company `active`? Undecided windows show while they have the focus.
function isShown(s, t, active) {
    var o = ownerOf(s, t)
    if (o === null) return !!t.activated
    return o === "*" || o === active
}

function unplaced(s) {
    var out = []
    s.owner.forEach(function (o, t) { if (o === "?") out.push(t) })
    return out
}

// Windows a company owns (for counts and for "stop company"): owner === id.
function windowsOf(s, id) {
    var out = []
    s.owner.forEach(function (o, t) { if (o === id && !t.parent) out.push(t) })
    return out
}
