import QtQuick
import Quickshell
import Quickshell.Io
import Quickshell.Networking
import Quickshell.Bluetooth

// System controls behind quick settings and the taskbar.
//   Wi-Fi/Ethernet: NetworkManager (Quickshell.Networking) · Bluetooth: BlueZ (Quickshell.Bluetooth) ·
//   radio blocks/airplane: one `rfkill event` stream — all live, nothing polled.
//   volume: wpctl · brightness: brightnessctl (queried when quick settings opens) · night light:
//   wlsunset · performance: powerprofilesctl · session: systemctl/loginctl (lock: services/ScreenLock.qml)
Item {
    id: sys
    visible: false

    // ---- Wi-Fi / Ethernet -------------------------------------------------------------------------
    // The one NetworkManager manages, if there are several. Never the Mobile hotspot's extra interface
    // (qap0), and an adapter that joins networks before one that's hosting the hotspot.
    readonly property var wifiDevice: {
        const all = Networking.devices.values.filter(d => d && d.type === DeviceType.Wifi && d.name !== "qap0")
        const st = all.filter(d => d.mode !== WifiDeviceMode.AccessPoint)
        return st.find(d => d.nmManaged) || st[0] || all.find(d => d.nmManaged) || all[0] || null
    }
    readonly property bool wifiAvailable: wifiDevice !== null
    // The only adapter is busy hosting the hotspot (it shares a cable): it isn't on any Wi-Fi.
    readonly property bool wifiHosting: !!wifiDevice && wifiDevice.mode === WifiDeviceMode.AccessPoint
    readonly property bool wifiOn: wifiAvailable && Networking.wifiEnabled && !wifiSoftBlocked && !wifiHardBlocked
    readonly property var wifiNetwork: wifiDevice ? wifiDevice.networks.values.find(n => n && n.connected) || null : null
    readonly property string wifiSsid: wifiNetwork ? wifiNetwork.name : ""
    // 1-4 bars for the taskbar (signalStrength is 0-1; tolerate 0-100)
    readonly property int wifiLevel: {
        if (!wifiNetwork) return 0
        const s = wifiNetwork.signalStrength > 1 ? wifiNetwork.signalStrength / 100 : wifiNetwork.signalStrength
        return s > 0.75 ? 4 : s > 0.5 ? 3 : s > 0.25 ? 2 : 1
    }
    readonly property bool wiredConnected: Networking.devices.values.some(d => d && d.type === DeviceType.Wired && d.connected)

    // ---- Bluetooth -----------------------------------------------------------------------------------
    readonly property var adapter: Bluetooth.defaultAdapter
    readonly property bool btAvailable: adapter !== null
    readonly property bool btOn: !!adapter && adapter.enabled
    readonly property int btDevices: Bluetooth.devices.values.filter(d => d && d.connected).length
    property bool btWantOn: false           // turn the adapter on once its rfkill block is gone

    // ---- rfkill (kernel radio switches) ---------------------------------------------------------------
    property var radios: ({})              // idx -> { type: 1 wlan | 2 bluetooth | …, soft, hard }
    function blocked(type, field) {
        return Object.keys(radios).some(k => radios[k].type === type && radios[k][field])
    }
    readonly property bool wifiSoftBlocked: blocked(1, "soft")
    readonly property bool wifiHardBlocked: blocked(1, "hard")
    readonly property bool btSoftBlocked: blocked(2, "soft")
    readonly property bool btHardBlocked: blocked(2, "hard")
    readonly property var radioList: Object.keys(radios).map(k => radios[k]).filter(r => r.type === 1 || r.type === 2)
    readonly property bool airplane: radioList.length > 0 && radioList.every(r => r.soft)
    property var beforeAirplane: null       // { wifi, bt } to restore when airplane mode ends

    // ---- sound, brightness, night light ------------------------------------------------------------
    property bool brightnessAvailable: false
    property real brightness: 70
    property real volume: 50
    property bool muted: false
    property bool audioAvailable: true     // a default output sink exists (false in Hyper-V: no sound card)
    property bool nightLight: false

    function run(cmd) { Quickshell.execDetached(cmd) }

    function refresh() {
        volQuery.running = true
        briQuery.running = true
    }

    function setWifi(on) {
        if (on && wifiSoftBlocked) run(["/usr/sbin/rfkill", "unblock", "wifi"])
        Networking.wifiEnabled = on
    }
    function setBluetooth(on) {
        if (!adapter) return
        if (on && (btSoftBlocked || adapter.state === BluetoothAdapterState.Blocked)) {
            btWantOn = true                      // enabled when BlueZ sees the block go (Connections below)
            run(["/usr/sbin/rfkill", "unblock", "bluetooth"])
        } else {
            btWantOn = false
            adapter.enabled = on
        }
    }
    // Airplane mode blocks every radio through rfkill (NetworkManager and BlueZ follow) and puts back
    // what was on before when it ends: NetworkManager keeps its own Wi-Fi on/off, and a Bluetooth
    // adapter comes back powered off after a block.
    function setAirplane(on) {
        if (on) {
            beforeAirplane = { wifi: Networking.wifiEnabled, bt: btOn }
            run(["/usr/sbin/rfkill", "block", "all"])
        } else {
            const b = beforeAirplane || { wifi: true, bt: true }
            beforeAirplane = null
            run(["/usr/sbin/rfkill", "unblock", "all"])
            Networking.wifiEnabled = b.wifi
            btWantOn = b.bt
        }
    }
    function setVolume(v) { volume = v; muted = false; run(["wpctl", "set-volume", "-l", "1.0", "@DEFAULT_AUDIO_SINK@", (v / 100).toFixed(2)]) }
    function setBrightness(v) { brightness = v; run(["brightnessctl", "-q", "set", Math.max(1, Math.round(v)) + "%"]) }
    function setNightLight(on) { nightLight = on }
    function setProfile(i) { run(["powerprofilesctl", "set", ["power-saver", "balanced", "performance"][i]]) }

    // The lock screen is the shell's own (services/ScreenLock.qml listens for this).
    signal lockRequested()
    function lock() { lockRequested() }
    function logout() { run(["loginctl", "terminate-session", Quickshell.env("XDG_SESSION_ID") || "self"]) }
    function setMuted(on) { muted = on; run(["wpctl", "set-mute", "@DEFAULT_AUDIO_SINK@", on ? "1" : "0"]) }
    function suspend() { run(["systemctl", "suspend"]) }
    function reboot() { run(["systemctl", "reboot"]) }
    function poweroff() { run(["systemctl", "poweroff"]) }

    Connections {
        target: sys.adapter
        ignoreUnknownSignals: true
        function onStateChanged() {
            if (sys.btWantOn && sys.adapter && sys.adapter.state !== BluetoothAdapterState.Blocked) {
                sys.btWantOn = false
                sys.adapter.enabled = true
            }
        }
    }

    // "<time>: idx 0 type 1 op 0 soft 0 hard 0" per change; the current state of every switch first.
    Process {
        id: rfkillEvents
        running: true
        command: ["/usr/sbin/rfkill", "event"]
        stdout: SplitParser {
            onRead: (line) => {
                const m = line.match(/idx (\d+) type (\d+) op (\d+) soft (\d+) hard (\d+)/)
                if (!m) return
                const r = Object.assign({}, sys.radios)
                if (m[3] === "1") delete r[m[1]]
                else r[m[1]] = { type: parseInt(m[2]), soft: m[4] === "1", hard: m[5] === "1" }
                sys.radios = r
            }
        }
        onStarted: sys.radios = ({})                          // it lists every switch again first
        onExited: (code, status) => rfkillRetry.restart()     // e.g. rfkill missing: try again later
    }
    Timer { id: rfkillRetry; interval: 30000; onTriggered: rfkillEvents.running = true }

    // Night light: a constant warm temperature while on (wlsunset needs low < high).
    Process {
        running: sys.nightLight
        command: ["wlsunset", "-t", "4000", "-T", "4001"]
    }

    Process {
        id: volQuery
        command: ["wpctl", "get-volume", "@DEFAULT_AUDIO_SINK@"]
        stdout: StdioCollector {
            onStreamFinished: {
                // No output (no sound card, or PipeWire not running): wpctl prints nothing to stdout.
                const m = this.text.match(/Volume:\s*([0-9.]+)/)
                sys.audioAvailable = !!m
                if (m) sys.volume = Math.round(parseFloat(m[1]) * 100)
                sys.muted = this.text.indexOf("MUTED") >= 0
            }
        }
    }
    Process {
        id: briQuery
        command: ["sh", "-c", "ls /sys/class/backlight 2>/dev/null | grep -q . && brightnessctl -m info 2>/dev/null | cut -d, -f4 | tr -d '%' || echo none"]
        stdout: StdioCollector {
            onStreamFinished: {
                const t = this.text.trim()
                sys.brightnessAvailable = t !== "none" && t !== ""
                if (sys.brightnessAvailable) sys.brightness = parseInt(t) || 70
            }
        }
    }
}
