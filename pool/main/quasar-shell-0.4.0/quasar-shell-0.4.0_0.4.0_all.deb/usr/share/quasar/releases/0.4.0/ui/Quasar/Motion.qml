pragma Singleton
import QtQuick

// Motion tokens. The mockup's CSS `linear()` easings (--spring, --soft) are piecewise-linear;
// they are converted EXACTLY into Easing.BezierSpline segments whose control points lie on each
// chord. Positions omitted in the CSS are spread evenly between the neighbours, per spec.
QtObject {
    id: motion

    // Durations from the mockup, in ms. dur() collapses them when motion is reduced.
    readonly property int hover: 150
    readonly property int press: 400
    readonly property int chip: 450
    readonly property int tile: 500
    readonly property int pop: 600
    readonly property int row: 450
    readonly property int panel: 550
    readonly property int launcher: 600
    readonly property int menu: 300
    readonly property int toast: 550
    readonly property int windowOpen: 650
    readonly property int windowClose: 220
    readonly property int geometry: 550
    readonly property int knob: 500
    readonly property int pill: 600
    readonly property int fade: 200

    function dur(ms) { return Theme.reduceMotion ? 1 : ms }

    // ---- curves ------------------------------------------------------------------
    // IMPORTANT: Qt's BezierSpline easing preallocates 10 segments (qeasingcurve.cpp BezierEase
    // `_curves(10), _intervals(10)`); longer splines write out of bounds and corrupt the heap.
    // So each CSS curve is fitted with a smooth Hermite spline through 11 key points of its
    // linear() data (<= 10 segments). Control points sit at x/3 and 2x/3, keeping x monotonic.
    //
    // --spring: linear(0, 0.009, 0.035 2.1%, 0.141, 0.281 6.7%, 0.723 12.9%, 0.938 16.7%, 1.017, 1.077,
    //   1.121, 1.149 24.3%, 1.159, 1.163, 1.161, 1.154 29.9%, 1.129 32.8%, 1.051 39.6%, 1.017 43.1%,
    //   0.991, 0.977 51%, 0.974 53.8%, 0.975 57.1%, 0.997 69.8%, 1.003 76.9%, 1.004 83.8%, 1)
    readonly property var spring: _spline([
        [0, 0], [4.4, 0.141], [12.9, 0.723], [18.6, 1.017], [24.3, 1.149], [28.5, 1.161],
        [32.8, 1.129], [43.1, 1.017], [53.8, 0.974], [69.8, 0.997], [100, 1]
    ], 0.857)
    // --soft: linear(0, 0.006, 0.025 2.8%, 0.101 6.1%, 0.539 18.9%, 0.721 25.3%, 0.849 31.5%,
    //   0.937 38.1%, 0.968 41.8%, 0.991 45.7%, 1.006 50.1%, 1.015 55%, 1.017 63.9%, 1.001)
    readonly property var soft: _spline([
        [0, 0], [2.8, 0.025], [6.1, 0.101], [18.9, 0.539], [25.3, 0.721], [31.5, 0.849],
        [38.1, 0.937], [45.7, 0.991], [55, 1.015], [63.9, 1.017], [100, 1]
    ], 0.43)

    // Key points ([percent, value]) -> BezierSpline control list via cubic Hermite with
    // finite-difference tangents; startSlope from the CSS data, end slope 0 (settled).
    function _spline(stops, startSlope) {
        const n = stops.length
        if (n - 1 > 10) console.warn("Motion: spline has", n - 1, "segments; Qt supports at most 10")
        const x = stops.map(s => s[0] / 100), y = stops.map(s => s[1])
        const m = []
        for (let i = 0; i < n; i++) {
            if (i === 0) m.push(startSlope)
            else if (i === n - 1) m.push(0)
            else m.push((y[i + 1] - y[i - 1]) / (x[i + 1] - x[i - 1]))
        }
        const out = []
        for (let i = 1; i < n; i++) {
            const dx = x[i] - x[i - 1]
            out.push(x[i - 1] + dx / 3, y[i - 1] + m[i - 1] * dx / 3,
                     x[i] - dx / 3, y[i] - m[i] * dx / 3,
                     x[i], y[i])
        }
        out[out.length - 2] = 1; out[out.length - 1] = 1    // must end exactly at (1,1)
        return out
    }
}
