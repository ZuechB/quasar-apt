import QtQuick
import Quasar

// Where the window is (template Files title bar): a folder glyph, then "Home / Documents / Taxes".
// Each part opens that folder and takes drops. A long path shows its start, "…" and its last two
// parts. Clicking the last part (or Ctrl+L) turns it into a text field for typing a path.
Item {
    id: root
    property var crumbs: []              // [{ label, path }]
    property bool active: true           // the window is focused (brighter current folder)
    property bool editing: false
    property string fullPath: ""         // what the text field starts with
    signal navigate(string path)
    signal pathTyped(string text)
    signal dropped(string path, var drop)

    implicitHeight: 32
    function edit() { editing = true; field.text = fullPath; Qt.callLater(() => { field.focusInput(); field.inputItem.selectAll() }) }

    // At most four parts: the first, "…" (opens the folder above the last two), the last two.
    readonly property var shown: {
        if (crumbs.length <= 4) return crumbs
        return [crumbs[0], { label: "…", path: crumbs[crumbs.length - 3].path }].concat(crumbs.slice(-2))
    }
    property string dropOn: ""

    Row {
        id: row
        visible: !root.editing
        anchors.verticalCenter: parent.verticalCenter
        spacing: 2
        QIcon {
            anchors.verticalCenter: parent.verticalCenter
            path: Icons.folder; size: 16; strokeWidth: 1.9
            color: Theme.hues.files || "#7AB8FF"
            fill: Theme.alpha(Theme.hues.files || "#7AB8FF", 0.18)
        }
        Item { width: 4; height: 1 }
        Repeater {
            model: root.shown
            delegate: Row {
                id: part
                required property var modelData
                required property int index
                readonly property bool last: index === root.shown.length - 1
                readonly property bool hot: root.dropOn === modelData.path && !last
                spacing: 2
                Text {
                    visible: part.index > 0
                    anchors.verticalCenter: parent.verticalCenter
                    text: "/"
                    font.family: Theme.fontUi; font.pixelSize: 13
                    color: "#5B6275"
                }
                Pressable {
                    width: Math.min(label.implicitWidth, 160) + 12
                    height: 26
                    radius: 7
                    kind: "plain"
                    color: part.hot ? Theme.alpha(Theme.accent, 0.2) : "transparent"
                    hoverColor: part.hot ? Theme.alpha(Theme.accent, 0.2) : Theme.white(0.07)
                    accessibleName: part.last ? "Type a path" : modelData.label
                    onClicked: part.last ? root.edit() : root.navigate(modelData.path)
                    Text {
                        id: label
                        anchors.centerIn: parent
                        width: Math.min(implicitWidth, 160)
                        elide: Text.ElideMiddle
                        text: part.modelData.label
                        textFormat: Text.PlainText
                        font.family: Theme.fontUi; font.pixelSize: 13
                        font.weight: part.last ? Font.DemiBold : Font.Normal
                        color: part.last ? (root.active ? Theme.text : Theme.textDim) : Theme.textDim
                    }
                    DropArea {
                        anchors.fill: parent
                        enabled: !part.last
                        onEntered: root.dropOn = part.modelData.path
                        onExited: if (root.dropOn === part.modelData.path) root.dropOn = ""
                        onDropped: (d) => { root.dropOn = ""; root.dropped(part.modelData.path, d) }
                    }
                }
            }
        }
    }

    TextField {
        id: field
        visible: root.editing
        anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter }
        height: 30
        glyph: Icons.folder
        placeholder: "Type a folder, like ~/Documents"
        onAccepted: { root.editing = false; root.pathTyped(text) }
        onEscapePressed: root.editing = false
        Connections {
            target: field.inputItem
            function onActiveFocusChanged() { if (!field.inputItem.activeFocus) root.editing = false }
        }
    }
}
