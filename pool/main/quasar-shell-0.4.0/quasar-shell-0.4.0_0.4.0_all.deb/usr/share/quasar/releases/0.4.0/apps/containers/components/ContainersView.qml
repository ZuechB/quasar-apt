import QtQuick
import Quasar
import "Format.js" as Format

// Containers window content: 210px sidebar (Containers / Images / Volumes, Docker's state at the
// bottom) | the page, the logs of one container, or — when Docker isn't running or reachable — what
// to do about it. Pure view: the host passes Docker's state and lists and reacts to the signals.
Item {
    id: root
    // ---- data in ------------------------------------------------------------------------------
    property string page: "containers"          // containers | images | volumes
    property string engine: "running"           // missing | noAccess | stopped | starting | stopping | running | error
    property string version: ""
    property string engineError: ""
    property bool autostart: false
    property bool sysBusy: false                // a root-only change is running (password sheet, systemctl)
    property string company: ""                 // the company shown (its own Docker engine), else ""
    property var containers: []
    property var images: []                     // with inUse
    property var volumes: []                    // with inUse
    property var df: null
    property var busy: ({})                     // item key -> what is running on it
    property bool pulling: false
    property string pullStatus: ""
    property var logs: null                     // { id, name } while a container's logs are open
    property string logText: ""
    property var banner: null                   // { tone, title, message, details, actionText }

    // ---- signals out ------------------------------------------------------------------------
    signal navigate(string page)
    signal containerAction(var container, string action)   // start | stop | restart | remove | logs | terminal
    signal projectAction(string project, string action)    // start | stop | restart | remove
    signal openPort(int port)
    signal closeLogs()
    signal pullImage(string ref)
    signal imageAction(var image, string action)           // run | remove
    signal volumeAction(var volume, string action)         // remove
    signal removeUnusedVolumes()
    signal cleanUp()
    signal engineAction(string action)                     // start | stop | autostart | access | get | retry
    signal bannerAction()

    readonly property bool ready: engine === "running"
    readonly property int runningCount: containers.filter(c => c.state === "running").length
    readonly property var stateInfo: ({
        running: ["Running", Theme.mint], starting: ["Starting", Theme.accent], stopping: ["Stopping", Theme.amber], stopped: ["Stopped", Theme.textDim],
        noAccess: ["No access", Theme.amber], missing: ["Not installed", Theme.textDim], error: ["Problem", Theme.danger]
    })

    // ---- sidebar ----------------------------------------------------------------------------
    Item {
        id: side
        width: 210
        height: parent.height
        Column {
            x: 10; y: 12
            width: parent.width - 20
            spacing: 2
            Repeater {
                model: [["containers", "Containers", Icons.layers], ["images", "Images", Icons.cube], ["volumes", "Volumes", Icons.drive]]
                NavItem {
                    required property var modelData
                    width: parent.width
                    label: modelData[1]
                    glyph: modelData[2]
                    selected: !root.logs && root.page === modelData[0]
                    badge: modelData[0] === "containers" && root.ready && root.runningCount > 0 ? String(root.runningCount) : ""
                    onClicked: root.navigate(modelData[0])
                }
            }
        }
        Column {
            anchors { left: parent.left; leftMargin: 20; right: parent.right; rightMargin: 14; bottom: parent.bottom; bottomMargin: 16 }
            spacing: 8
            SectionLabel { text: "Docker"; font.pointSize: Theme.pt(10) }
            StatusPill {
                readonly property var info: root.stateInfo[root.engine] || ["", Theme.textDim]
                text: info[0]
                tone: info[1]
            }
            Text {
                visible: root.ready && (root.version !== "" || !!root.df)
                width: parent.width
                elide: Text.ElideRight
                text: [root.version ? "Engine " + root.version : "", root.df ? Format.bytes(root.df.used) + " on disk" : ""].filter(x => x).join("  ·  ")
                font.family: Theme.fontUi; font.pixelSize: 12
                color: Theme.textFaint
            }
        }
    }
    Rectangle { x: side.width; width: 1; height: parent.height; color: Theme.white(0.05) }

    // ---- content ------------------------------------------------------------------------------
    Item {
        id: content
        x: side.width + 1
        width: parent.width - x
        height: parent.height

        EnginePane {
            visible: !root.ready
            anchors.fill: parent
            engine: root.engine
            error: root.engineError
            busy: root.sysBusy
            company: root.company
            banner: root.banner
            onAction: (a) => root.engineAction(a)
            onBannerAction: root.bannerAction()
        }

        LogsView {
            visible: root.ready && !!root.logs
            anchors.fill: parent
            name: root.logs ? root.logs.name : ""
            text: root.logText
            onBack: root.closeLogs()
        }

        ScrollPane {
            id: scroll
            visible: root.ready && !root.logs
            anchors.fill: parent
            topPadding: 20; bottomPadding: 28

            Column {
                id: pageCol
                x: 22
                width: scroll.width - 44
                spacing: 0

                Banner {
                    visible: !!root.banner
                    width: parent.width
                    tone: root.banner ? (root.banner.tone || "error") : "error"
                    title: root.banner ? root.banner.title || "" : ""
                    message: root.banner ? root.banner.message || "" : ""
                    details: root.banner ? root.banner.details || "" : ""
                    actionText: root.banner ? root.banner.actionText || "" : ""
                    onActionClicked: root.bannerAction()
                }
                Item { visible: !!root.banner; width: 1; height: 16 }

                Loader {
                    active: root.page === "containers"
                    visible: active
                    width: parent.width
                    sourceComponent: ContainersPage {
                        width: pageCol.width
                        containers: root.containers
                        busy: root.busy
                        version: root.version
                        autostart: root.autostart
                        sysBusy: root.sysBusy
                        df: root.df
                        onContainerAction: (c, a) => root.containerAction(c, a)
                        onProjectAction: (p, a) => root.projectAction(p, a)
                        onOpenPort: (p) => root.openPort(p)
                        onCleanUp: root.cleanUp()
                        onEngineAction: (a) => root.engineAction(a)
                    }
                }
                Loader {
                    active: root.page === "images"
                    visible: active
                    width: parent.width
                    sourceComponent: ImagesPage {
                        width: pageCol.width
                        images: root.images
                        busy: root.busy
                        pulling: root.pulling
                        pullStatus: root.pullStatus
                        onPull: (ref) => root.pullImage(ref)
                        onImageAction: (i, a) => root.imageAction(i, a)
                    }
                }
                Loader {
                    active: root.page === "volumes"
                    visible: active
                    width: parent.width
                    sourceComponent: VolumesPage {
                        width: pageCol.width
                        volumes: root.volumes
                        busy: root.busy
                        onVolumeAction: (v, a) => root.volumeAction(v, a)
                        onRemoveUnused: root.removeUnusedVolumes()
                    }
                }
            }
        }
    }

    onPageChanged: scroll.scrollToTop()
}
