import QtQuick
import Quasar

// A Discover shelf: a title, "See all" and one row of cards (as many as fit the width).
Column {
    id: root
    property string title: ""
    property var ids: []
    property var view: null
    property int cols: 3
    signal seeAll()

    spacing: 12
    width: parent ? parent.width : 700

    Item {
        width: parent.width
        height: 30
        Text {
            anchors.verticalCenter: parent.verticalCenter
            text: root.title
            textFormat: Text.PlainText
            font.family: Theme.fontDisplay; font.pixelSize: 18; font.weight: Font.Medium
            color: Theme.text
        }
        Button {
            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
            visible: root.ids.length > root.cols
            text: "See all"
            glyph: Icons.fwd
            variant: "ghost"; size: 30
            accessibleName: "See all: " + root.title
            onClicked: root.seeAll()
        }
    }
    Grid {
        id: grid
        width: parent.width
        columns: root.cols
        spacing: 10
        Repeater {
            model: root.ids.slice(0, root.cols)
            StoreCard {
                required property string modelData
                appId: modelData
                view: root.view
                width: (grid.width - (root.cols - 1) * 10) / root.cols
                height: 74
            }
        }
    }
}
