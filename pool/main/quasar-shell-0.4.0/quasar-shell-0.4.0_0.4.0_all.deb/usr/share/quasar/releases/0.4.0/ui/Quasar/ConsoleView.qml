import QtQuick

// A log console (template Sites › Logs): #06070B, 14px radius, hairline border, JetBrains Mono 12px.
// Each line is { t: "12:04:31", m: "GET / 200 in 3 ms", c: color }; the time is dim (#5B6275).
// Newest line at the bottom; it follows new lines unless you scrolled up to read.
Rectangle {
    id: root
    property var lines: []
    property string emptyText: "Nothing logged yet."

    implicitWidth: 520
    implicitHeight: 300
    radius: 14
    color: "#06070B"
    border.width: 1; border.color: Theme.white(0.06)
    clip: true

    Text {
        anchors.centerIn: parent
        visible: root.lines.length === 0
        text: root.emptyText
        font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
        color: Theme.textFaint
    }

    ListView {
        id: list
        anchors { fill: parent; leftMargin: 14; rightMargin: 14; topMargin: 12; bottomMargin: 12 }
        clip: true
        model: root.lines
        boundsBehavior: Flickable.StopAtBounds
        property bool follow: true
        onMovementEnded: follow = atYEnd
        onCountChanged: if (follow) Qt.callLater(positionViewAtEnd)
        Component.onCompleted: positionViewAtEnd()
        delegate: Item {
            required property var modelData
            width: list.width
            height: msg.implicitHeight + 2
            Text {
                id: time
                visible: !!modelData.t
                text: modelData.t || ""
                textFormat: Text.PlainText
                font.family: Theme.fontMono; font.pixelSize: 12
                color: "#5B6275"
            }
            Text {
                id: msg
                anchors { left: time.visible ? time.right : parent.left; leftMargin: time.visible ? 12 : 0; right: parent.right }
                text: modelData.m || ""
                textFormat: Text.PlainText
                wrapMode: Text.WrapAnywhere
                font.family: Theme.fontMono; font.pixelSize: 12
                color: modelData.c || Theme.text3
            }
        }
    }
}
