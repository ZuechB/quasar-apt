pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io
import Quasar

// Company environments: Personal (this account) plus the companies registered on this PC. A company
// is a hidden account with its own network (its own localhost), home folder, keys, sign-ins and
// desktop; see /usr/libexec/quasar/quasar-company-admin.
//   - The registry (/etc/quasar/companies.json: id, name, uid, owner) is root-owned and watched here.
//   - Colour, wallpaper and "start at sign-in" are preferences: Settings.companies[id].
//   - Which company is shown and which run is the shell's state. The shell sets `active`, `running`
//     and `starting` and calls publish(); every other Quasar process reads them back from
//     $XDG_RUNTIME_DIR/quasar/companies-state.json.
// run()/exec() start programs inside a running company through its agent (CompanyAgent).
Singleton {
    id: root

    readonly property string home: Quickshell.env("HOME") || "/root"
    readonly property string runtimeDir: (Quickshell.env("XDG_RUNTIME_DIR") || "/tmp") + "/quasar"
    // This account's uid (logind's runtime folder is /run/user/<uid>); -1 when unknown.
    readonly property int myUid: {
        const m = /^\/run\/user\/(\d+)\/?$/.exec(Quickshell.env("XDG_RUNTIME_DIR") || "")
        return m ? parseInt(m[1]) : -1
    }
    readonly property var reserved: ["personal", "quasar", "live", "root", "admin", "current", "last",
                                     "left", "right", "all", "none", "new"]
    readonly property var wallpaperCycle: ["graphite", "aurora", "deep"]

    // ---- state (written by the shell, read back everywhere else) ------------------------------
    property string active: "personal"
    property var running: []
    property var starting: []
    property var failed: ({})            // id -> what went wrong last time it was started
    property var alerts: ({})            // id -> number of notifications held while it was hidden

    // ---- registry -----------------------------------------------------------------------------
    property var registry: []
    // False until the registry has been read once: the shell must not act on an empty list it hasn't
    // read yet (rewriting labwc's desktops from it would move company windows to Personal's desktop).
    property bool registryLoaded: false
    // The file exists from boot (tmpfiles quasar-companies.conf); if it was missing when this process
    // started, nothing can watch it, so creating a company also asks the shell to reload it.
    function reloadRegistry() { registryFile.reload() }
    FileView {
        id: registryFile
        path: "/etc/quasar/companies.json"
        watchChanges: true
        blockLoading: true
        printErrors: false
        onFileChanged: reload()
        onLoaded: {
            try {
                const c = JSON.parse(text()).companies
                // Only this account's companies: on a PC with several people, each sees their own.
                root.registry = Array.isArray(c) ? c.filter(x => x && /^[a-z][a-z0-9-]{0,21}$/.test(x.id)
                                                                && (root.myUid < 0 || x.owner === undefined || Number(x.owner) === root.myUid)) : []
            } catch (e) { root.registry = [] }
            root.registryLoaded = true
        }
        onLoadFailed: (error) => { root.registry = []; root.registryLoaded = true }
    }

    FileView {
        id: stateFile
        path: root.runtimeDir + "/companies-state.json"
        watchChanges: true
        blockLoading: true
        printErrors: false
        onFileChanged: reload()
        onLoaded: {
            if (root.writer) return
            try {
                const s = JSON.parse(text())
                root.active = typeof s.active === "string" ? s.active : "personal"
                root.running = Array.isArray(s.running) ? s.running : []
                root.starting = Array.isArray(s.starting) ? s.starting : []
                root.failed = s.failed || {}
                root.alerts = s.alerts || {}
            } catch (e) { }
        }
    }
    FileView { id: activeFile; path: root.runtimeDir + "/active-company"; printErrors: false }
    // The shell sets this: it owns the state and is the only process that writes it.
    property bool writer: false
    function publish() {
        if (!writer) return
        stateFile.setText(JSON.stringify({ active: active, running: running, starting: starting,
                                           failed: failed, alerts: alerts }))
        activeFile.setText(active + "\n")
    }

    // ---- entries --------------------------------------------------------------------------------
    // [{ id, name, short, color, wallpaper, home, personal, uid, autostart }]; Personal first.
    readonly property var list: {
        const prefs = Settings.companies || {}
        const out = [{ id: "personal", name: "Personal", short: "P", color: String(Settings.accent),
                       wallpaper: Settings.wallpaper, home: root.home, personal: true, autostart: false }]
        registry.forEach((c, i) => {
            const p = prefs[c.id] || {}
            out.push({ id: c.id, name: c.name || c.id, short: p.short || shortFor(c.name || c.id),
                       color: p.color || defaultColor(i), wallpaper: p.wallpaper || wallpaperCycle[i % wallpaperCycle.length],
                       home: "/home/companies/" + c.id, personal: false, uid: c.uid, autostart: !!p.autostart })
        })
        return out
    }
    readonly property var companies: list.filter(c => !c.personal)
    readonly property var current: list.find(c => c.id === active) || list[0]
    readonly property string accent: current.color
    readonly property string wallpaper: current.wallpaper
    readonly property bool inCompany: !current.personal

    function byId(id) { return list.find(c => c.id === id) || null }
    function isRunning(id) { return id === "personal" || running.indexOf(id) >= 0 }
    function stateOf(id) {
        if (id === "personal") return "running"
        if (starting.indexOf(id) >= 0) return "starting"
        if (running.indexOf(id) >= 0) return "running"
        return failed[id] ? "failed" : "stopped"
    }
    function homeOf(id) { const c = byId(id); return c ? c.home : root.home }

    // Template-style badge letters: "AskOtter" -> "AO", "Acme Labs" -> "AL", "INDEAL" -> "IN".
    function shortFor(name) {
        const s = String(name || "").trim()
        const words = s.split(/[\s._-]+/).filter(w => w.length)
        if (words.length > 1) return (words[0][0] + words[1][0]).toUpperCase()
        const humps = s.match(/[A-Z]/g)
        if (humps && humps.length >= 2 && s !== s.toUpperCase()) return (humps[0] + humps[1])
        return s.slice(0, 2).toUpperCase() || "?"
    }
    // The preset accents have pre-rendered wallpaper stills; a new company takes the first unused one.
    function defaultColor(i) {
        const presets = Theme.accents.map(a => a.color)
        return presets[(i + 1) % presets.length]
    }
    function nextColor() {
        const used = list.map(c => String(c.color).toUpperCase())
        const free = Theme.accents.map(a => a.color).filter(c => used.indexOf(c.toUpperCase()) < 0)
        return free.length ? free[0] : Theme.accents[list.length % Theme.accents.length].color
    }
    // A free account id for a display name: "Acme Corp" -> "acme-corp".
    function slug(name) {
        let s = String(name || "").toLowerCase().normalize("NFKD").replace(/[̀-ͯ]/g, "")
                    .replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "")
        if (!/^[a-z]/.test(s)) s = "co-" + s
        s = s.slice(0, 22).replace(/-+$/, "")
        if (s === "co-" || s === "co") s = "company"
        let id = s, n = 2
        while (reserved.indexOf(id) >= 0 || byId(id)) { const tail = "-" + n++; id = s.slice(0, 22 - tail.length) + tail }
        return id
    }
    function validId(id) { return /^[a-z][a-z0-9-]{0,21}$/.test(id) && reserved.indexOf(id) < 0 }

    // ---- programs inside a company --------------------------------------------------------------
    property var _agents: ({})
    readonly property Component _agentComponent: Component { CompanyAgent { } }
    // A connection to the company's agent; a new one after the last failed or closed (a company that
    // was stopped when it was first asked, then started).
    function agent(id) {
        let a = _agents[id]
        if (a && a.dead) { a.destroy(); a = null }
        if (!a) { a = _agentComponent.createObject(root, { company: id }); _agents[id] = a }
        return a
    }
    // Start a program inside a running company (it keeps running): done({ ok, error }).
    function run(id, argv, cwd, done) {
        agent(id).request({ op: "spawn", argv: argv, cwd: cwd || homeOf(id) }, { onReply: (r) => { if (done) done(r) } })
    }
    // Run a command inside a company and stream it: onLine(kind "out"|"err", text), onExit(code).
    // Returns a handle for cancel(handle).
    function exec(id, argv, opts) {
        const o = opts || {}
        const a = agent(id)
        const rid = a.request({ op: "exec", argv: argv, cwd: o.cwd || homeOf(id), stdin: o.stdin },
                              { onLine: o.onLine, onExit: o.onExit, onReply: o.onError })
        return { company: id, rid: rid }
    }
    function cancel(handle) { if (handle && _agents[handle.company]) _agents[handle.company].cancel(handle.rid) }

    // Commands for a Process/Cmd that must run in the shown company's account (or as you in Personal):
    // exec waits and streams its output and exit code back (e.g. the Store's dev tools, quasar-dev);
    // run starts a program there and returns at once.
    function wrapExec(argv) { return inCompany ? ["quasar-company", "exec", active, "--"].concat(argv) : argv }
    function wrapRun(argv) { return inCompany ? ["quasar-company", "run", active, "--"].concat(argv) : argv }
}
