import QtQuick
import Quickshell
import Quickshell.Io
import Quasar
import Quasar.Services
import "../components/remotedesktop.js" as Rd
import "../components/firewall.js" as Fw

// Settings › Users & Accounts › Remote desktop (VNC).
// - Turning it on: Settings.remoteDesktop.enabled, after `pkexec quasar-vnc-admin enable` the first time for
//   this account (one administrator password: wayvnc installed on demand, this account allowed, the firewall
//   entry). The shell starts quasar-vnc.service from the setting; vnc-run writes the state this page shows
//   ($XDG_RUNTIME_DIR/quasar/vnc.json, made by quasar-session-start so the watch holds).
// - A headless server: while it's on, Settings' labwc layer gets LABWC_FALLBACK_OUTPUT=NOOP-fallback (a
//   virtual display whenever none is connected; labwc reads it when the session starts).
// - After a restart: automatic sign-in, locked (Users & Accounts' quasar-users autologin, "locked").
// - From outside your home: the router VPN of the home network you're on (Settings › Firewall's dialog).
//   QUASAR_VNC_ADMIN / QUASAR_WAYVNCCTL=/path: stand-ins (UI tests).
Scope {
    id: root
    property bool active: false                 // the Remote desktop page (or Users & Accounts) is shown
    property var users: null                    // services/UserAdmin.qml: automatic sign-in
    property var firewall: null                 // services/Firewall.qml: home networks, the Router VPN dialog
    signal notify(var banner)

    readonly property var cfg: Settings.remoteDesktop || ({})
    readonly property bool enabled: cfg.enabled === true
    readonly property string me: Quickshell.env("USER") || ""
    readonly property int uid: {
        const m = /\/run\/user\/(\d+)/.exec(Quickshell.env("XDG_RUNTIME_DIR") || "")
        return m ? parseInt(m[1]) : -1
    }
    readonly property string runDir: (Quickshell.env("XDG_RUNTIME_DIR") || "/tmp") + "/quasar"
    readonly property string adminExe: Quickshell.env("QUASAR_VNC_ADMIN") || ""
    readonly property string ctl: Quickshell.env("QUASAR_WAYVNCCTL") || "wayvncctl"
    readonly property string envFile: (Quickshell.env("XDG_CONFIG_HOME") || (Quickshell.env("HOME") + "/.config"))
                                      + "/quasar/xdg/labwc/environment.d/50-remote-desktop.env"
    function admin(args) { return (adminExe ? [adminExe] : ["pkexec", "/usr/libexec/quasar/quasar-vnc-admin"]).concat(args) }

    property var status: ({})
    property var adminSt: null
    property var viewers: []
    property string busy: ""
    property int progress: -1
    property string phase: ""
    property var ask: null                      // { key, title, message, button, danger }
    property real size: 0                       // what the first install downloads (system.json)

    readonly property var fwSt: firewall ? firewall.st : null
    readonly property var connection: Fw.connections(fwSt)[0] || null
    readonly property var home: connection && connection.state === "home" ? Fw.homeFor(fwSt, connection.uuid) : null
    readonly property var st: ({ status: status, admin: adminSt, viewers: viewers })
    readonly property var ctx: ({ enabled: enabled, lockOnLeave: cfg.lockOnLeave, uid: uid, me: me, busy: busy,
                                  progress: progress, phase: phase, size: size, live: Platform.live,
                                  autologin: { user: users ? users.autologin : "", locked: users ? users.autologinLocked : false },
                                  connection: connection, home: home, icons: Icons, theme: Theme })
    readonly property var groups: Rd.groups(st, ctx)
    readonly property var entryGroups: Rd.entryGroups(st, ctx)

    function patch(p) { Settings.remoteDesktop = Object.assign({}, Settings.remoteDesktop || {}, p) }

    onActiveChanged: if (active) refresh()
    function refresh() {
        if (!adminStatus.running) adminStatus.running = true
        if (status.state === "listening" && !listProc.running) listProc.running = true
    }

    // ---- reading ------------------------------------------------------------------------------------
    FileView {
        path: root.runDir + "/vnc.json"
        watchChanges: true
        printErrors: false
        onFileChanged: reload()
        onLoaded: { try { root.status = JSON.parse(text()) } catch (e) { } }
    }
    FileView {
        path: "/usr/share/quasar/store/system.json"
        printErrors: false
        onLoaded: {
            try { const r = JSON.parse(text()).recipes.vnc; root.size = r && r.size ? r.size.download || 0 : 0 } catch (e) { }
        }
    }
    Process {
        id: adminStatus
        command: root.adminExe ? [root.adminExe, "status"] : ["/usr/libexec/quasar/quasar-vnc-admin", "status"]
        stdout: StdioCollector {
            onStreamFinished: {
                for (const l of text.split("\n")) {
                    try { const o = JSON.parse(l); if (o && o.type === "result") root.adminSt = o } catch (e) { }
                }
            }
        }
    }
    // Who is connected, while this page is shown (the shell keeps its own list for the taskbar).
    readonly property string sock: runDir + "/wayvncctl.sock"
    Process {
        id: events
        running: root.active && root.status.state === "listening"
        command: [root.ctl, "--socket=" + root.sock, "--json", "event-receive"]
        stdout: SplitParser {
            onRead: (line) => {
                let e = null
                try { e = JSON.parse(line) } catch (err) { return }
                const kind = e && (e.method || e.event || e.name)
                if (kind === "client-connected" || kind === "client-disconnected") root.refresh()
            }
        }
        onRunningChanged: if (!running) root.viewers = []
    }
    Process {
        id: listProc
        command: [root.ctl, "--socket=" + root.sock, "--json", "client-list"]
        stdout: StdioCollector {
            onStreamFinished: {
                let a = []
                try { a = JSON.parse(text) } catch (e) { return }
                if (Array.isArray(a))
                    root.viewers = a.map(c => ({ id: String(c.id || ""), address: String(c.address || ""), username: String(c.username || "") }))
                                    .filter(v => v.id)
            }
        }
    }
    onStatusChanged: { if (status.state === "listening") refresh(); else viewers = [] }

    // ---- changing -------------------------------------------------------------------------------------
    function toggle(key) {
        if (key === "rd:on") { if (enabled) turnOff(); else turnOn(); return }
        if (key === "rd:lockleave") { patch({ lockOnLeave: cfg.lockOnLeave === false }); return }
        if (key === "rd:auto") { autoSignIn(); return }
    }
    function activate(key) {
        if (key === "rd:continue") { allow(); return }
        if (key === "rd:home") {
            if (firewall && connection) firewall.activate("fw:home:" + connection.uuid)
            return
        }
        if (key === "rd:retry") { Quickshell.execDetached(["systemctl", "--user", "restart", "quasar-vnc.service"]); return }
        if (key === "rd:vpn") { if (firewall && home) firewall.openVpn(home.uuid); return }
        if (key === "rd:remove") { ask = Rd.confirmRemove(); return }
        if (key.startsWith("rd:viewer:")) {
            Quickshell.execDetached([ctl, "--socket=" + sock, "client-disconnect", key.slice(10)])
            return
        }
        toggle(key)
    }
    function confirm() {
        const a = ask
        ask = null
        if (a && a.key === "rd:remove")
            run("rd:remove", ["remove"], () => {
                patch({ enabled: false })
                fallbackDisplay(false)
                root.notify({ tone: "success", title: "Remote desktop is removed", message: "Turn it on again any time." })
            })
    }

    function turnOn() {
        if (busy !== "" || Platform.live) return
        const a = adminSt
        if (a && a.installed && (a.enabled || []).indexOf(uid) >= 0) { switchOn(); return }
        allow()
    }
    // One administrator password: installs wayvnc the first time, allows this account, opens the firewall.
    function allow() {
        if (busy !== "") return
        run(enabled ? "rd:continue" : "rd:on", ["enable"], () => switchOn())
    }
    function switchOn() {
        patch({ enabled: true })
        fallbackDisplay(true)
        Quickshell.execDetached(["systemctl", "--user", "restart", "quasar-vnc.service"])
    }
    function turnOff() {
        patch({ enabled: false })
        fallbackDisplay(false)
    }
    // A virtual display whenever no real one is connected (a server without a monitor), from the next sign-in.
    function fallbackDisplay(on) {
        if (on)
            Quickshell.execDetached(["sh", "-c", 'mkdir -p "$(dirname "$1")" && printf "%s\\n" "# Remote desktop (Settings): a virtual display when none is connected" "LABWC_FALLBACK_OUTPUT=NOOP-fallback" > "$1"', "sh", envFile])
        else
            Quickshell.execDetached(["rm", "-f", envFile])
    }
    // "Sign in automatically after a restart": you, with the screen locked. Off: no automatic sign-in.
    function autoSignIn() {
        if (!users) return
        const mine = users.autologin === me
        if (mine && users.autologinLocked) users.setAutologin("", false, "autologin")
        else users.setAutologin(me, true, "autologin", () => root.notify({ tone: "success",
            title: "Remote desktop comes back after a restart",
            message: "This PC signs you in when it starts and locks the screen right away." }))
    }

    // One change at a time; quasar-vnc-admin answers in JSON lines. Closing the password sheet (126) says nothing.
    property var _done: null
    function run(key, args, done) {
        busy = key
        progress = -1
        phase = ""
        _done = done || null
        job.run(admin(args))
    }
    Cmd {
        id: job
        onLine: (l) => {
            try {
                const o = JSON.parse(l)
                if (o.type === "progress") root.progress = o.value
                else if (o.type === "phase") root.phase = o.text
            } catch (e) { }
        }
        onFinished: (code) => {
            const done = root._done
            root._done = null
            root.busy = ""
            root.progress = -1
            root.phase = ""
            let res = null
            for (const l of job.tail) { try { const o = JSON.parse(l); if (o && (o.type === "result" || o.type === "error")) res = o } catch (e) { } }
            if (code === 0 && res && res.type === "result") {
                if (done) done()
            } else if (code !== 126) {
                root.notify(code === 127
                    ? { tone: "error", title: "An administrator has to allow this", message: "Ask someone with an administrator account." }
                    : { tone: "error", title: res && res.message ? res.message : "Remote desktop couldn't be turned on",
                        message: res ? "" : "Nothing was changed.", details: job.details() })
            }
            root.refresh()
        }
    }
}
