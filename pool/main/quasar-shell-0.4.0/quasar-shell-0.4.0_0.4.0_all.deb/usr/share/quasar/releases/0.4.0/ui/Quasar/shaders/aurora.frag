#version 440
// "Aurora" wallpaper: three heavily blurred radial orbs drifting slowly (mockup drift 22/28/26s alternate).
layout(location = 0) in vec2 qt_TexCoord0;
layout(location = 0) out vec4 fragColor;

layout(std140, binding = 0) uniform buf {
    mat4 qt_Matrix;
    float qt_Opacity;
    vec2 itemSize;
    vec2 screenSize;
    vec2 offset;
    vec4 accent;
    float time;
    float stars;
    float detail;
    float cornerRadius; // >0: mask to a rounded rect (glass backdrop)
};

// ease-in-out ping-pong 0..1 with period T (alternate), phase in seconds
float drift(float T, float phase, bool reverse) {
    float t = mod(time + phase, 2.0 * T) / T;     // 0..2
    float u = t < 1.0 ? t : 2.0 - t;
    u = u * u * (3.0 - 2.0 * u);
    return reverse ? 1.0 - u : u;
}

// Orb: center c (px), radius r (px), color rgba, soft edge (blur widens the falloff).
vec3 orb(vec3 col, vec2 px, vec2 c, float r, vec4 rgba, float blur) {
    float d = length(px - c);
    float a = 1.0 - smoothstep(0.0, 0.65 * r + blur, d);
    return mix(col, rgba.rgb, rgba.a * a);
}

float roundedMask(vec2 local, vec2 size, float r) {
    if (r <= 0.0) return 1.0;
    vec2 q = abs(local - 0.5 * size) - (0.5 * size - vec2(r));
    float d = length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;
    return clamp(0.5 - d, 0.0, 1.0);
}

void main() {
    vec2 px = qt_TexCoord0 * itemSize + offset;
    vec2 S = screenSize;
    vec3 col = vec3(0.0235, 0.0275, 0.0471);           // #06070C
    float vw = S.x / 100.0;

    float u1 = drift(22.0, 0.0, false);
    float r1 = 23.0 * vw * mix(1.0, 1.15, u1);
    vec2 c1 = vec2(0.08 * S.x + 23.0 * vw, 0.12 * S.y + 23.0 * vw) + vec2(60.0, -40.0) * u1;
    col = orb(col, px, c1, r1, vec4(accent.rgb, 0.40), 40.0);

    float u2 = drift(28.0, -6.0, true);
    float r2 = 20.0 * vw * mix(1.0, 1.15, u2);
    vec2 c2 = vec2(S.x - 0.04 * S.x - 20.0 * vw, 0.30 * S.y + 20.0 * vw) + vec2(60.0, -40.0) * u2;
    col = orb(col, px, c2, r2, vec4(0.725, 0.643, 1.0, 0.35), 50.0);

    float u3 = drift(26.0, -12.0, false);
    float r3 = 19.0 * vw * mix(1.0, 1.15, u3);
    vec2 c3 = vec2(0.34 * S.x + 19.0 * vw, S.y + 0.14 * S.y - 19.0 * vw) + vec2(60.0, -40.0) * u3;
    col = orb(col, px, c3, r3, vec4(1.0, 0.722, 0.420, 0.22), 50.0);

    fragColor = vec4(col, 1.0) * roundedMask(qt_TexCoord0 * itemSize, itemSize, cornerRadius) * qt_Opacity;
}
