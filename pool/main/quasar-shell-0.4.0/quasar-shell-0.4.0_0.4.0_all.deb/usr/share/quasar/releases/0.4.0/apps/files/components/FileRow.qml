import QtQuick
import Quasar

// One item in the list: kind glyph, name, then Size and Modified (the Trash: where it came from and
// when it was deleted). Selected: accent wash + hairline; hover: white .05; a drop target: a stronger
// wash. Visual only: ItemsView does all the pointer work for every row at once.
Item {
    id: root
    property var item: null              // FileKit.row() (+ origin, for the Trash)
    property string kind: "folder"       // folder | trash (From, Deleted) | search (Folder, Modified)
    property bool selected: false
    property bool hovered: false
    property bool dropTarget: false
    property bool dimmed: false
    property bool cursor: false
    property bool renaming: false
    property bool focusedView: true
    property bool clock24: false
    // Column widths (the header uses the same ones).
    property real sizeW: 96
    property real dateW: 168
    property real originW: 0             // the Trash's "From" and a search's "Folder" column

    readonly property bool _lit: selected || dropTarget
    opacity: dimmed ? 0.4 : 1

    function when(ms) {
        if (!ms) return ""
        const d = new Date(ms), now = new Date()
        const time = Qt.formatTime(d, clock24 ? "HH:mm" : "h:mm AP")
        if (d.toDateString() === now.toDateString()) return "Today, " + time
        const y = new Date(now); y.setDate(now.getDate() - 1)
        if (d.toDateString() === y.toDateString()) return "Yesterday, " + time
        return Qt.formatDate(d, d.getFullYear() === now.getFullYear() ? "MMM d" : "MMM d, yyyy") + (d.getFullYear() === now.getFullYear() ? ", " + time : "")
    }

    Rectangle {
        anchors { fill: parent; leftMargin: 6; rightMargin: 6; topMargin: 1; bottomMargin: 1 }
        radius: 8
        color: root._lit ? Theme.alpha(Theme.accent, root.dropTarget ? 0.24 : root.focusedView ? 0.14 : 0.08)
                         : root.hovered ? Theme.white(0.05) : "transparent"
        border.width: root._lit || root.cursor ? 1 : 0
        border.color: root._lit ? Theme.alpha(Theme.accent, root.dropTarget ? 0.6 : root.focusedView ? 0.3 : 0.18)
                                : Theme.alpha(Theme.accent, 0.5)
    }

    QIcon {
        x: 18
        anchors.verticalCenter: parent.verticalCenter
        path: root.item ? Icons.get(root.item.glyph) : ""
        size: 18; strokeWidth: 1.7
        color: root.item && root.item.hue ? root.item.hue : Theme.text3
        fill: root.item && root.item.fill ? root.item.fill : "transparent"
    }
    Text {
        id: name
        x: 46
        width: parent.width - x - root.sizeW - root.dateW - root.originW - 16
        anchors.verticalCenter: parent.verticalCenter
        visible: !root.renaming
        elide: Text.ElideMiddle
        text: root.item ? root.item.name : ""
        textFormat: Text.PlainText
        font.family: Theme.fontUi; font.pixelSize: 13
        color: Theme.text2
    }
    Text {
        visible: root.kind !== "folder"
        x: name.x + name.width + 8
        width: root.originW - 8
        anchors.verticalCenter: parent.verticalCenter
        elide: Text.ElideMiddle
        text: root.item && root.item.origin ? root.item.origin : ""
        textFormat: Text.PlainText
        font.family: Theme.fontUi; font.pixelSize: 12
        color: Theme.textDim
    }
    Text {
        visible: root.kind === "folder"
        anchors { right: parent.right; rightMargin: root.dateW + 16; verticalCenter: parent.verticalCenter }
        width: root.sizeW - 8
        horizontalAlignment: Text.AlignRight
        text: root.item && !root.item.isDir ? FileKit.formatSize(root.item.size) : ""
        font.family: Theme.fontUi; font.pixelSize: 12
        color: Theme.textDim
    }
    Text {
        anchors { right: parent.right; rightMargin: 18; verticalCenter: parent.verticalCenter }
        width: root.dateW - 10
        horizontalAlignment: Text.AlignRight
        elide: Text.ElideRight
        text: root.item ? root.when(root.item.mtime) : ""
        font.family: Theme.fontUi; font.pixelSize: 12
        color: Theme.textDim
    }
}
