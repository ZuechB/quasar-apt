// Settings > Network & Internet > Mobile hotspot: rows built from `nm-ctl list` (.hotspot), `nm-ctl
// hotspot-plan` and `nm-ctl hotspot-show`/`hotspot-devices`. Pure (services/Hotspot.qml and the preview).
//   st:  { info: { saved, state: "off" | "starting" | "on", ssid, band, device, mode: "direct" | "concurrent" },
//          plan: { possible, mode, device, uplink: { kind, name }, bands, band, bandFixed } | { possible: false, reason },
//          secret: { ssid, password, band } | null, devices: [{ mac, name, ip }] }        (null while loading)
//   ctx: { busy: "hs" while it starts or stops, icons, theme }
.pragma library

function info(st) { return (st && st.info) || {} }
function isOn(st) { return info(st).state === "on" }
function starting(st, ctx) { return info(st).state === "starting" || (ctx.busy === "hs" && !isOn(st)) }

function bandName(b) { return b === "a" ? "5 GHz" : "2.4 GHz" }

function uplinkText(up) {
    if (!up) return ""
    if (up.kind === "wifi") return (up.name || "Wi-Fi") + " (Wi-Fi)"
    if (up.kind === "usb") return "your phone (USB)"
    if (up.kind === "mobile") return "mobile data"
    if (up.kind === "ethernet") return "Ethernet"
    return up.name || "this PC's connection"
}

function ssid(st) { return (st && st.secret && st.secret.ssid) || info(st).ssid || "" }

function networkRow(st, ctx) {
    var t = ctx.theme
    var row = { key: "hs:open", label: "Mobile hotspot", glyph: ctx.icons.hotspot, trailing: "chevron",
                sub: "Share this PC's internet with your phone", value: "" }
    if (!st) return row
    if (isOn(st)) {
        var n = (st.devices || []).length
        row.sub = ssid(st) + (n ? "  ·  " + n + (n === 1 ? " device" : " devices") : "")
        row.value = "On"
        row.valueColor = t.mint
    } else if (starting(st, ctx)) {
        row.value = "Starting…"
    } else if (st.plan && st.plan.possible === false && ["no-wifi", "no-ap", "same-adapter", "channel", "no-dnsmasq"].indexOf(st.plan.reason) >= 0) {
        row.value = "Not available"
        row.sub = reasonText(st.plan.reason).title
    } else {
        row.value = "Off"
    }
    return row
}

function hero(st, ctx) {
    var icons = ctx.icons, t = ctx.theme
    if (!st)
        return { glyph: icons.hotspot, title: "Mobile hotspot", sub: "Checking…" }
    if (isOn(st)) {
        var p = st.plan || {}
        var how = info(st).mode === "concurrent" ? ", on the same Wi-Fi adapter" : ""
        var up = uplinkText(p.uplink)
        return { glyph: icons.hotspot, title: "Join " + ssid(st) + " from your phone", toggle: true, checked: true,
                 busy: ctx.busy === "hs", iconBg: t.accent, iconFg: t.accentInk,
                 sub: up ? "Sharing " + up + how + ". Devices that join can use this PC's internet, nothing else on it."
                         : "Devices that join can use this PC's internet, nothing else on it." }
    }
    if (starting(st, ctx))
        return { glyph: icons.hotspot, title: "Starting the hotspot…", toggle: true, checked: true, busy: true,
                 sub: "Nearby devices will see " + (ssid(st) || "it") + " in a moment." }
    var plan = st.plan
    if (plan && plan.possible === false && plan.reason !== "offline") {
        var r = reasonText(plan.reason)
        var h = { glyph: icons.hotspot, title: r.title, sub: r.message, iconFg: t.amber }
        if (plan.reason === "wifi-off") { h.button = "Turn on Wi-Fi"; h.buttonPrimary = true }
        return h
    }
    return { glyph: icons.hotspot, title: "Mobile hotspot is off", toggle: true, checked: false, busy: false,
             sub: plan && plan.possible === false ? reasonText(plan.reason).message
                  : plan && plan.dropsWifi ? "Share " + uplinkText(plan.uplink) + " over Wi-Fi. This PC's Wi-Fi network disconnects while it's on."
                  : "Share this PC's internet over Wi-Fi with your phone, tablet or another computer." }
}

function groups(st, ctx) {
    if (!st) return []
    var icons = ctx.icons
    var plan = st.plan || {}
    var join = { label: "Join from your phone", rows: [
        { key: "hs:name", label: "Network name", glyph: icons.wifi, trailing: "chevron", value: ssid(st) || "Not set yet",
          sub: "What your phone shows in its Wi-Fi list" },
        { key: "hs:password", label: "Password", glyph: icons.key, trailing: "chevron", value: st.secret ? "Show" : "",
          sub: "WPA2. Only devices that know it can join" }] }
    var out = [join]
    if (isOn(st)) {
        var devs = (st.devices || []).map(function (d) {
            return { key: "hs:dev:" + d.mac, label: d.name || "A device", sub: d.ip ? d.ip : "Connected", glyph: icons.phone,
                     trailing: "none" }
        })
        if (!devs.length)
            devs = [{ key: "hs:dev:none", label: "No devices yet", sub: "Join " + ssid(st) + " from a phone or tablet", trailing: "none" }]
        out.push({ label: "Devices", rows: devs })
    }
    var fixed = plan.bandFixed || info(st).mode === "concurrent"
    var band = (st.secret && st.secret.band) || info(st).band || "bg"
    var adv = [{ key: "hs:band", label: "Band", glyph: icons.sliders,
                 trailing: fixed ? "value" : "chevron",
                 value: fixed ? "Same as your Wi-Fi (" + bandName(plan.band || band) + ")" : bandName(band),
                 sub: fixed ? "This adapter hosts on the channel its own Wi-Fi uses" : "2.4 GHz works with every device; 5 GHz is faster nearby" }]
    if (plan.uplink)
        adv.push({ key: "hs:sharing", label: "Sharing", glyph: icons.link, trailing: "value", value: uplinkText(plan.uplink),
                   sub: plan.mode === "concurrent" ? "Over the same Wi-Fi adapter" : "" })
    out.push({ label: "Advanced", rows: adv })
    return out
}

function bandChoices(st) {
    var bands = ((st && st.plan && st.plan.bands) || ["bg"])
    return bands.map(function (b) {
        return { key: b, label: bandName(b), sub: b === "a" ? "Faster, shorter range; some older devices can't see it" : "Works with every device" }
    })
}

// nm-ctl hotspot reasons (reasons.py HOTSPOT) in plain words.
var REASONS = {
    "no-wifi": ["This PC has no Wi-Fi", "A hotspot needs a Wi-Fi adapter."],
    "no-ap": ["This PC's Wi-Fi can't host a hotspot", "Its adapter can only join networks. A USB Wi-Fi adapter that can host would work."],
    "wifi-off": ["Wi-Fi is off", "Turn on Wi-Fi to share this PC's internet."],
    "blocked": ["Wi-Fi is switched off", "Turn it on with the switch or key on this PC (often the airplane-mode key)."],
    "offline": ["This PC isn't online", "Connect to the internet first: a cable, Wi-Fi or your phone over USB."],
    "same-adapter": ["This PC can't share the Wi-Fi it's connected to", "Its Wi-Fi adapter can't do both at once. Connect a cable or a phone over USB, or add a second Wi-Fi adapter."],
    "channel": ["The Wi-Fi you're on uses a channel this adapter can't host on", "Join a 2.4 GHz network, or connect a cable."],
    "no-dnsmasq": ["Mobile hotspot is missing a part", "This copy of Quasar can't hand out addresses. Update Quasar."],
    "ap-refused": ["The Wi-Fi adapter wouldn't start the hotspot", "Try 2.4 GHz, or turn Wi-Fi off and on, then try again."],
    "timeout": ["Starting the hotspot took too long", "Try again."],
    "bad-name": ["That name is too long", "Up to 32 letters, digits and spaces."],
    "bad-password": ["That password won't work", "Use 8 to 63 letters, digits and symbols (no accents)."],
    "not-allowed": ["Your account isn't allowed to share this PC's connection", "Ask an administrator."],
    "cancelled": ["", ""],
    "other": ["That didn't work", ""]
}

function reasonText(code) {
    var r = REASONS[code] || REASONS.other
    return { title: r[0], message: r[1] }
}
