import QtQuick
import Quickshell.Io

// One connection to a running company's agent (/run/quasar/companies/<id>/agent.sock): JSON lines,
// see /usr/lib/quasar/quasar-company-agent. Connects on the first request and stays open.
//   request(obj, { onReply(r), onLine(kind, text), onExit(code) }) -> request id
//     single-reply ops (spawn, ping, display…) call onReply; exec streams onLine and ends with onExit
//     (an exec that couldn't start calls onReply with ok:false first).
//   event(obj): messages without an id ({ event: "notify" | "close", … } after a subscribe).
//   lost(): the connection closed (the company stopped). Every unanswered request fails.
// Agent output is untrusted text: callers show it as plain text.
Socket {
    id: root
    property string company: ""
    path: company ? "/run/quasar/companies/" + company + "/agent.sock" : ""

    property int _seq: 0
    property var _pending: ({})
    property var _queue: []
    // Set once the connection failed or closed. A Socket that failed doesn't connect again, so
    // Companies.agent() replaces a dead CompanyAgent with a new one.
    property bool dead: false
    signal event(var obj)
    signal lost()

    parser: SplitParser { onRead: (line) => root._received(line) }

    function request(obj, handlers) {
        const id = ++_seq
        _pending[id] = handlers || {}
        const line = JSON.stringify(Object.assign({}, obj, { id: id })) + "\n"
        if (connected) { write(line); flush(); return id }
        _queue.push(line)
        if (_queue.length === 1) connected = true
        return id
    }
    function cancel(id) { if (id && _pending[id]) request({ op: "cancel", ref: id }) }

    function _failAll(why) {
        const pending = _pending
        _pending = {}
        _queue = []
        for (const id in pending) {
            const h = pending[id]
            if (h.onReply) h.onReply({ ok: false, error: why })
            if (h.onExit) h.onExit(-1)
        }
    }
    onConnectionStateChanged: {
        if (connected) {
            for (const l of _queue) write(l)
            _queue = []
            flush()
        } else {
            dead = true
            _failAll("The company isn't running")
            lost()
        }
    }
    onError: (e) => { if (!connected) { dead = true; _failAll("The company isn't running") } }

    function _received(line) {
        let r
        try { r = JSON.parse(line) } catch (e) { return }
        if (r === null || typeof r !== "object") return
        if (r.id === undefined || r.id === null) { event(r); return }
        const h = _pending[r.id]
        if (!h) return
        if (r.out !== undefined) { if (h.onLine) h.onLine("out", String(r.out)); return }
        if (r.err !== undefined) { if (h.onLine) h.onLine("err", String(r.err)); return }
        if (r.exit !== undefined) { delete _pending[r.id]; if (h.onExit) h.onExit(Number(r.exit)); return }
        if (!h.onExit) delete _pending[r.id]       // a single-reply request is done
        if (h.onReply) h.onReply(r)
    }
}
