// Bluetooth device helpers shared by the shell (pairing dialog) and Settings (device lists). Pure: no
// Quickshell types, so the design preview can use it.
//   BtDevices.kind(icon) -> { glyph, label }     icon: BlueZ's Icon property (freedesktop icon names)
//   BtDevices.service(uuid) -> "audio" | …         readable name of a Bluetooth service UUID
.pragma library

// glyph: an Icons.qml key (Icons.get(glyph))
function kind(icon) {
    const i = String(icon || "")
    if (i === "audio-headset" || i === "audio-headphones") return { glyph: "headphones", label: "Headphones" }
    if (i.indexOf("audio") === 0) return { glyph: "speaker", label: "Speaker" }
    if (i === "input-keyboard") return { glyph: "keyboard", label: "Keyboard" }
    if (i === "input-mouse") return { glyph: "mouse", label: "Mouse" }
    if (i === "input-tablet") return { glyph: "pen", label: "Pen tablet" }
    if (i === "input-gaming") return { glyph: "gamepad", label: "Controller" }
    if (i === "phone") return { glyph: "phone", label: "Phone" }
    if (i === "computer") return { glyph: "monitor", label: "Computer" }
    if (i === "video-display") return { glyph: "monitor", label: "Display" }
    if (i === "multimedia-player") return { glyph: "music", label: "Media player" }
    if (i.indexOf("camera") === 0) return { glyph: "camera", label: "Camera" }
    return { glyph: "bt", label: "Device" }
}

// Short UUIDs (0000xxxx-0000-1000-8000-00805f9b34fb) of the services a device asks to use.
const SERVICES = {
    "1101": "a serial connection", "1105": "file sharing", "1106": "file sharing", "110a": "audio", "110b": "audio",
    "110c": "media controls", "110d": "audio", "110e": "media controls", "1108": "calls (headset)", "1112": "calls (headset)",
    "111e": "calls (hands-free)", "111f": "calls (hands-free)", "1115": "network sharing", "1116": "network sharing",
    "1124": "keyboard or mouse input", "112f": "phone book", "1132": "messages", "1812": "keyboard or mouse input"
}

function service(uuid) {
    const u = String(uuid || "").toLowerCase()
    const m = u.match(/^0000([0-9a-f]{4})-0000-1000-8000-00805f9b34fb$/)
    return (m && SERVICES[m[1]]) || "a service"
}
