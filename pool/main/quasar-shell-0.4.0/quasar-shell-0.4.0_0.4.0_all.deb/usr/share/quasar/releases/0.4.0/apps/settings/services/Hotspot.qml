import QtQuick
import Quickshell
import Quickshell.Networking
import Quasar
import Quasar.Services
import "../components/hotspot.js" as H

// Settings > Network & Internet > Mobile hotspot: start/stop, name and password, band, who's connected.
// `nm-ctl hotspot-*` as the user; a hotspot that shares the Wi-Fi its adapter is on also runs
// `pkexec quasar-net ap-add` (nm-ctl does that itself; admins aren't asked for a password). The plan
// (which adapter, which channel, or why it can't) is read when the page opens and after each change.
Scope {
    id: root
    property var list: null                 // NmList.st (its .hotspot)
    property bool active: false             // the Mobile hotspot page is shown
    property bool networkActive: false      // the Network page is shown (its row says whether it's possible)
    property string busy: ""                // "hs" (start/stop), "hs:set"
    property var plan: null
    property var secret: null               // { ssid, password, band } (hotspot-show)
    property var devices: []
    property bool formOpen: false           // name + password dialog
    signal notify(var banner)
    signal changed()
    signal pick(string title, var options, string current, var done, string message)

    readonly property string exe: Quickshell.env("QUASAR_NM_CTL") || "/usr/libexec/quasar/nm-ctl"
    readonly property var st: list ? { info: list.hotspot || {}, plan: plan, secret: secret, devices: devices } : null
    readonly property var ctx: ({ busy: busy, icons: Icons, theme: Theme })
    readonly property var networkRow: H.networkRow(st, ctx)
    readonly property var hero: H.hero(st, ctx)
    readonly property var groups: H.groups(st, ctx)
    readonly property bool isOn: H.isOn(st)

    onActiveChanged: if (active) { readPlan(); show() }
    onNetworkActiveChanged: if (networkActive) readPlan()
    onIsOnChanged: { readPlan(); if (!isOn) devices = [] }
    Connections {
        target: NetState
        function onHotspotChanged() { if (root.active || root.networkActive) root.readPlan() }
    }

    // Who's connected: only while this page shows a running hotspot (like the Network monitor).
    Timer {
        interval: 10000
        repeat: true
        triggeredOnStart: true
        running: root.active && root.isOn
        onTriggered: devicesProc.run([root.exe, "hotspot-devices"])
    }
    Cmd {
        id: devicesProc
        onLine: (l) => { try { const o = JSON.parse(l); if (o.result === "ok") root.devices = o.devices || [] } catch (e) { } }
    }
    Cmd {
        id: planProc
        onLine: (l) => { try { const o = JSON.parse(l); if (o.result === "ok") root.plan = o } catch (e) { } }
    }
    function readPlan() { if (!planProc.running) planProc.run([exe, "hotspot-plan"]) }
    // The name and password (makes the profile the first time). The password isn't kept in Cmd's tail.
    Cmd {
        id: showProc
        onLine: (l) => { try { const o = JSON.parse(l); if (o.result === "ok") root.secret = { ssid: o.ssid, password: o.password, band: o.band } } catch (e) { } }
        onFinished: tail = []
    }
    function show() { if (!showProc.running) showProc.run([exe, "hotspot-show"]) }

    // ---- page actions --------------------------------------------------------------------------------
    function heroToggled() {
        if (busy !== "") return
        if (isOn) run("hs", ["hotspot-stop"])
        else start()
    }
    function heroActivated() {                               // "Turn on Wi-Fi"
        if (plan && plan.reason === "wifi-off") Networking.wifiEnabled = true
    }
    function activate(key) {
        if (key === "hs:name" || key === "hs:password") { if (!secret) show(); formOpen = true; return }
        if (key === "hs:band") pick("Band", H.bandChoices(st), (secret && secret.band) || "bg", (b) => root.save({ band: b }), "")
    }
    function start() {
        run("hs", ["hotspot-start"], "{}\n", (r) => {
            const n = Object.assign({}, Settings.network || {})
            n.hotspot = true
            Settings.network = n
            root.notify({ tone: "success", title: "Mobile hotspot is on",
                          message: "Join " + (r.ssid || "it") + " from your phone with the password on this page." })
        })
    }
    // From the name/password dialog or the band picker; a running hotspot restarts with them.
    function save(spec) {
        const s = Object.assign({}, spec)
        if (!s.keepOpen) formOpen = false           // "Make a new one" keeps the dialog open on the new password
        delete s.keepOpen
        run("hs:set", ["hotspot-set"], JSON.stringify(s) + "\n", (r) => {
            root.show()
            if (r.result === "on") root.notify({ tone: "info", title: "The hotspot restarted", message: "Devices need to join again with the new details." })
        })
    }

    // "Copy password": wl-copy reads it on stdin (never argv); the tail is cleared after.
    function copyPassword(text) {
        copyJob.run(["wl-copy"], undefined, text)
        notify({ tone: "success", title: "Password copied", message: "" })
    }
    Cmd { id: copyJob; onFinished: tail = [] }

    property var _ok: null
    property var _result: null
    function run(key, args, input, ok) {
        busy = key
        _ok = ok || null
        _result = null
        job.run([exe].concat(args), undefined, input)
    }
    Cmd {
        id: job
        onLine: (l) => { try { const o = JSON.parse(l); if (o.result !== undefined) root._result = o } catch (e) { } }
        onFinished: (code) => {
            const ok = root._ok, r = root._result || {}
            root._ok = null
            root.busy = ""
            job.tail = []
            if (code === 0) {
                if (ok) ok(r)
            } else if (r.reason !== "cancelled") {
                const t = H.reasonText(r.reason || "other")
                root.notify({ tone: "error", title: t.title, message: t.message || r.detail || "", details: r.detail || "" })
            }
            root.changed()
            root.readPlan()
        }
    }
}
