import QtQuick
import Quasar

// Terminal › Settings (Ctrl+, or the right-click menu): text size, line spacing, cursor, scrollback,
// Windows-style case-insensitive folders and commands, and closing confirmations. Changes apply
// to every open terminal at once, except the case setting, which new tabs pick up.
// Pure view: reads `cfg`, reports `changed(key, value)`. Fits the Terminal's default 980×600 window.
Dialog {
    id: root
    property var cfg: ({})
    signal changed(string key, var value)

    title: "Terminal settings"
    cardWidth: 520

    readonly property var sizes: [11, 12.5, 14, 16]
    readonly property var spacings: [1.2, 1.4, 1.6]
    readonly property var scrollbacks: [1000, 10000, 100000]
    readonly property int scrollback: cfg.scrollback || 10000
    function nearest(list, v) {
        let best = 0
        for (let i = 1; i < list.length; ++i)
            if (Math.abs(list[i] - v) < Math.abs(list[best] - v)) best = i
        return best
    }

    component Labeled: Column {
        property alias label: caption.text
        default property alias control: slot.data
        width: parent.width
        spacing: 6
        SectionLabel { id: caption; leftPadding: 4 }
        Item { id: slot; width: parent.width; height: childrenRect.height }
    }

    Column {
        width: parent.width
        spacing: 10

        Row {
            width: parent.width
            spacing: 10
            Labeled {
                width: (parent.width - parent.spacing) / 2
                label: "Text size"
                Segmented {
                    width: parent.width; height: 36
                    accessibleName: "Text size"
                    model: ["S", "M", "L", "XL"]
                    currentIndex: root.nearest(root.sizes, root.cfg.fontSize !== undefined ? root.cfg.fontSize : 12.5)
                    onPicked: (i) => root.changed("fontSize", root.sizes[i])
                }
            }
            Labeled {
                width: (parent.width - parent.spacing) / 2
                label: "Line spacing"
                Segmented {
                    width: parent.width; height: 36
                    accessibleName: "Line spacing"
                    model: ["Compact", "Normal", "Relaxed"]
                    currentIndex: root.nearest(root.spacings, root.cfg.lineHeight !== undefined ? root.cfg.lineHeight : 1.6)
                    onPicked: (i) => root.changed("lineHeight", root.spacings[i])
                }
            }
        }
        Labeled {
            label: "Cursor"
            Item {
                width: parent.width
                height: 36
                Segmented {
                    width: parent.width - blink.width - 14; height: 36
                    accessibleName: "Cursor shape"
                    model: ["Bar", "Block", "Underline"]
                    currentIndex: root.cfg.cursorStyle || 0
                    onPicked: (i) => root.changed("cursorStyle", i)
                }
                Row {
                    id: blink
                    anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                    spacing: 8
                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        text: "Blink"
                        font.family: Theme.fontUi; font.pixelSize: 13
                        color: Theme.textMuted
                    }
                    QSwitch {
                        anchors.verticalCenter: parent.verticalCenter
                        accessibleName: "Blinking cursor"
                        checked: !!root.cfg.cursorBlink
                        onToggled: root.changed("cursorBlink", !root.cfg.cursorBlink)
                    }
                }
            }
        }
        Item { width: 1; height: 2 }
        SettingsGroup {
            SettingsRow {
                label: "Ignore upper/lower case"
                sub: "cd music opens Music, LS runs ls (new tabs)"
                trailing: "toggle"
                checked: root.cfg.ignoreCase !== false
                onToggled: root.changed("ignoreCase", root.cfg.ignoreCase === false)
            }
            SettingsRow {
                label: "Ask before closing running programs"
                trailing: "toggle"
                checked: root.cfg.confirmClose !== false
                onToggled: root.changed("confirmClose", root.cfg.confirmClose === false)
            }
            SettingsRow {
                label: "Ask before pasting several lines"
                trailing: "toggle"
                checked: root.cfg.confirmPaste !== false
                onToggled: root.changed("confirmPaste", root.cfg.confirmPaste === false)
            }
            SettingsRow {
                label: "Scrollback"
                trailing: "chevron"
                value: root.scrollback.toLocaleString(Qt.locale("en_US"), "f", 0) + " lines"
                onActivated: {
                    const i = root.nearest(root.scrollbacks, root.scrollback)
                    root.changed("scrollback", root.scrollbacks[(i + 1) % root.scrollbacks.length])
                }
            }
        }
    }
    buttons: [
        Button { text: "Done"; variant: "primary"; size: 38; onClicked: root.dismissed() }
    ]
}
