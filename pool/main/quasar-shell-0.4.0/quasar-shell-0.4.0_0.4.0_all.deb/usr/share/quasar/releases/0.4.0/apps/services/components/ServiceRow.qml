import QtQuick
import Quasar
import "services.js" as S

// One row of the list (template data-win="svc" rows): the 38px icon tile, name (+ "System" badge),
// trigger line, status with its icon and meta on the right, and the on/off switch (only when the row
// can be switched: `toggle` in its actions). Hover white .07, press .97; selected white .07 + accent
// hairline. Rises in with the template's rowIn (25 ms stagger).
Appear {
    id: root
    property var item: ({})
    property real now: Date.now()
    property bool selected: false
    property bool forceHover: false        // previews: draw the hover state
    signal select()
    signal toggle()
    signal openConsole()                   // double-click: its log in its own window

    stagger: 25
    implicitHeight: 56
    height: 56

    readonly property var st: S.statusOf(item || {}, now)
    readonly property bool on: !!(item && item.enabled)
    readonly property color statusColor: st.color === "accent" ? Theme.accent : st.color === "fail" ? "#FF8F8F"
                                       : st.color === "sched" ? Theme.text3 : Theme.textDim
    readonly property color hue: item && item.hue ? item.hue : Theme.accent

    Pressable {
        id: body
        width: root.width
        height: 56
        kind: "hov"
        radius: 13
        interactiveContent: true          // the switch takes its own clicks
        color: root.selected || root.forceHover ? Theme.white(0.07) : "transparent"
        hoverColor: Theme.white(0.07)
        borderColor: root.selected ? Theme.alpha(Theme.accent, 0.35) : "transparent"
        hoverBorderColor: borderColor
        accessibleName: (root.item.name || "") + ", " + root.st.label
        onClicked: root.select()
        onDoubleClicked: root.openConsole()

        AppTile {
            id: tile
            x: 8
            anchors.verticalCenter: parent.verticalCenter
            size: 38; radius: 12
            base: Theme.taskTileBase
            sheen: 0.13; borderAlpha: 0.08
            glyph: Icons[root.item.icon] || Icons.cycle
            glyphSize: 19; glyphStroke: 1.9
            hue: root.hue
            glow: 0.8
            opacity: root.on ? 1 : 0.5
        }

        Column {
            anchors { left: tile.right; leftMargin: 12; right: statusCol.left; rightMargin: 12; verticalCenter: parent.verticalCenter }
            spacing: 3
            Row {
                width: parent.width
                spacing: 8
                Text {
                    id: nameText
                    width: Math.min(implicitWidth, parent.width - (badge.visible ? badge.width + 8 : 0))
                    text: root.item.name || ""
                    textFormat: Text.PlainText
                    elide: Text.ElideRight
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5); font.weight: Font.DemiBold
                    color: root.on ? Theme.text : Theme.textMuted
                }
                Rectangle {
                    id: badge
                    visible: !!root.item.system
                    anchors.verticalCenter: nameText.verticalCenter
                    width: badgeText.implicitWidth + 12; height: 18; radius: 5
                    color: Theme.white(0.08)
                    Text {
                        id: badgeText
                        anchors.centerIn: parent
                        text: "System"
                        font.family: Theme.fontUi; font.pointSize: Theme.pt(10.5)
                        color: Theme.textMuted
                    }
                }
            }
            Text {
                width: parent.width
                text: S.trigger(root.item || {})
                textFormat: Text.PlainText
                elide: Text.ElideRight
                font.family: Theme.fontUi; font.pixelSize: 12
                color: Theme.textDim
            }
        }

        Column {
            id: statusCol
            anchors { right: sw.visible ? sw.left : parent.right; rightMargin: sw.visible ? 12 : 10; verticalCenter: parent.verticalCenter }
            width: Math.max(112, statusRow.implicitWidth, metaText.implicitWidth)
            spacing: 3
            Row {
                id: statusRow
                anchors.right: parent.right
                spacing: 6
                QIcon {
                    id: statusIcon
                    anchors.verticalCenter: parent.verticalCenter
                    path: Icons[root.st.icon] || ""
                    size: 12; strokeWidth: 2.5
                    color: root.statusColor
                    RotationAnimation on rotation {
                        running: root.st.spin && !Theme.reduceMotion
                        from: 0; to: 360; duration: 1000; loops: Animation.Infinite
                        onRunningChanged: if (!running) statusIcon.rotation = 0
                    }
                }
                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: root.st.label
                    font.family: Theme.fontUi; font.pixelSize: 12; font.weight: Font.DemiBold
                    color: root.statusColor
                }
            }
            Text {
                id: metaText
                anchors.right: parent.right
                text: root.st.meta
                textFormat: Text.PlainText
                font.family: Theme.fontUi; font.pointSize: Theme.pt(11.5); font.features: { "tnum": 1 }
                color: Theme.textFaint
            }
        }

        QSwitch {
            id: sw
            visible: S.can(root.item || {}, "toggle")
            anchors { right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter }
            checked: root.on
            accessibleName: (root.on ? "Turn off " : "Turn on ") + (root.item.name || "")
            onToggled: root.toggle()
        }
    }
}
