import QtQuick

// Vertical scroll area for app content: Flickable with pixel-aligned content, no overshoot, and a
// thin overlay scrollbar that appears while scrolling (or hovered) and fades out — no timers or
// animations run while idle.
Flickable {
    id: root
    default property alias content: inner.data
    property real topPadding: 0
    property real bottomPadding: 0

    contentWidth: width
    contentHeight: inner.implicitHeight + topPadding + bottomPadding
    clip: true
    pixelAligned: true
    boundsBehavior: Flickable.StopAtBounds
    flickDeceleration: 3000
    maximumFlickVelocity: 5000

    Item {
        id: inner
        y: root.topPadding
        width: root.width
        implicitHeight: childrenRect.height
        height: implicitHeight
    }

    Rectangle {
        id: bar
        parent: root
        visible: root.contentHeight > root.height + 1
        x: root.width - width - 3
        y: 3 + root.visibleArea.yPosition * (root.height - 6)
        width: barArea.containsMouse || barArea.pressed ? 6 : 4
        height: Math.max(28, root.visibleArea.heightRatio * (root.height - 6))
        radius: width / 2
        color: Theme.white(barArea.pressed ? 0.32 : 0.22)
        opacity: root.moving || barArea.containsMouse || barArea.pressed || fade.running ? 1 : 0
        Behavior on opacity { NumberAnimation { duration: Motion.dur(220) } }
        Behavior on width { NumberAnimation { duration: Motion.dur(120) } }

        MouseArea {
            id: barArea
            anchors.fill: parent
            anchors.margins: -4
            hoverEnabled: true
            // Without this the Flickable takes the press once the pointer moves, and dragging the bar
            // scrolled nothing.
            preventStealing: true
            property real grabY: 0
            property real grabContentY: 0
            onPressed: (e) => { grabY = mapToItem(root, e.x, e.y).y; grabContentY = root.contentY }
            onPositionChanged: (e) => {
                if (!pressed) return
                const dy = mapToItem(root, e.x, e.y).y - grabY
                const range = root.contentHeight - root.height
                root.contentY = Math.max(0, Math.min(range, grabContentY + dy / Math.max(1, root.height - bar.height) * range))
            }
        }
    }
    // Keep the bar visible for a moment after wheel scrolling (the wheel does not set `moving`).
    Timer { id: fade; interval: 700 }
    onContentYChanged: fade.restart()

    function scrollToTop() { contentY = 0 }
}
