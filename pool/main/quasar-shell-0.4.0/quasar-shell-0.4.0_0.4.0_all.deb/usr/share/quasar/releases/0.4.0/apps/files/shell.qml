//@ pragma AppId quasar-files
// Quasar Files: folders and files, one process for all windows (launched by /usr/bin/quasar-files ->
// quasar-app). Every launch opens a new window:
//   quasar-files [PATH | file://URI | ~/… | trash:///]     (a file: its folder, with it selected)
// The desktop, Super+E, the taskbar, xdg-open (inode/directory), Settings and Quasar AI all land here.
// Drags are Wayland drags (text/uri-list + application/x-quasar-files), so they reach the desktop and
// any app, and the desktop's reach Files. File work goes through /usr/libexec/quasar/fileop.
// Settings: "files" in ~/.config/quasar/settings.json: view, hidden, sort, reversed.
// (No curly brace above the imports, even in a comment: Quickshell's scanner stops reading imports
// at the first line with one, and the folders imported below would then hold no types.)
import QtQuick
import Quickshell
import Quickshell.Io
import Quasar
import Quasar.Services
import "services"

ShellRoot {
    id: app

    Binding { target: Theme; property: "accent"; value: Settings.accent }
    Binding { target: Theme; property: "reduceMotion"; value: Settings.reduceMotion }
    Binding { target: Theme; property: "softwareRender"; value: Platform.softwareScene }
    Binding { target: Theme; property: "profile"; value: Platform.softwareRender ? 0 : (Settings.profile >= 0 ? Settings.profile : 1) }

    readonly property string home: Quickshell.env("HOME") || "/root"

    // ---- settings -----------------------------------------------------------------------------------
    readonly property var defaults: ({ view: "grid", hidden: false, sort: "name", reversed: false })
    readonly property var cfg: Object.assign({}, defaults, Settings.files || {})
    function setting(key, value) {
        const t = Object.assign({}, Settings.files || {})
        t[key] = value
        Settings.files = t
    }

    FileOps { id: fileOps }
    Places { id: placeList; ops: fileOps; home: app.home }
    TrashList { id: trashList; ops: fileOps; home: app.home }
    Thumbs { id: thumbCache; home: app.home }

    // ---- windows ------------------------------------------------------------------------------------
    ListModel { id: windows }
    property int nextId: 1
    property var requests: ({})

    function openWindow(req) {
        const id = nextId++
        requests[id] = req || {}
        windows.append({ wid: id })
    }
    function closeWindow(id) {
        for (let i = 0; i < windows.count; ++i)
            if (windows.get(i).wid === id) { windows.remove(i); break }
        delete requests[id]
        quitIfDone()
    }
    // The last window closed: quit, but only once running copies and moves have finished.
    function quitIfDone() { if (windows.count === 0 && fileOps.busy === 0) Qt.quit() }
    Connections { target: fileOps; function onJobDone() { app.quitIfDone() } }

    Instantiator {
        id: inst
        model: windows
        delegate: FilesWindow {
            required property int wid
            windowId: wid
            request: app.requests[wid] || ({})
            ops: fileOps
            places: placeList
            trash: trashList
            thumbs: thumbCache
            cfg: app.cfg
            home: app.home
            onCloseWindow: (id) => app.closeWindow(id)
            onNewWindow: (path) => app.openWindow({ path: path })
            onSettingChanged: (key, value) => app.setting(key, value)
        }
    }

    // ---- requests -----------------------------------------------------------------------------------
    // One launch argument (quasar-app passes them joined by spaces, so a path with spaces arrives whole).
    function handle(arg) {
        const a = String(arg || "").trim()
        let path = ""
        if (/^trash:/i.test(a)) path = placeList.trashFiles
        else path = FileKit.argPath(a, home) || (a === "" ? "" : home)
        openWindow({ path: path || home })
    }

    IpcHandler {
        target: "app"
        function open(arg: string): void { app.handle(arg) }
        // Tests: every window's folder, view and selection, as JSON.
        function state(): string {
            const out = []
            for (let i = 0; i < inst.count; i++) {
                const w = inst.objectAt(i)
                if (w) out.push(w.stateInfo())
            }
            return JSON.stringify(out)
        }
    }

    Component.onCompleted: handle(Quickshell.env("QUASAR_APP_ARGS") || "")
}
