import QtQuick
import Quasar

// Settings › Bluetooth device lists (WifiList's look): "Your devices" (paired: Connected · battery,
// Connect/Disconnect, Forget) and, while adding, "Nearby devices" (Pair / Pairing…). Rows are 58px with
// a device glyph. Pure view: models are arrays (preview) or keyed ScriptModels (the app) of
//   { key, name, kind, glyph, connected, paired, battery (0-100, -1 unknown), busy }
Column {
    id: root
    property var devices: []
    property var nearby: []
    property bool adding: false
    property bool canAdd: true              // the adapter is on
    property string pairingKey: ""
    signal connectClicked(string key)
    signal disconnectClicked(string key)
    signal forgetClicked(string key)
    signal pairClicked(string key)
    signal addClicked()
    signal stopClicked()

    spacing: 22

    component DeviceRow: Rectangle {
        id: row
        required property var entry
        required property int index
        property bool nearbyRow: false
        signal pair()
        signal toggleConnection()
        signal forget()
        width: parent ? parent.width : 0
        height: 58
        color: entry.connected ? Theme.alpha(Theme.accent, 0.06) : "transparent"

        Rectangle { visible: row.index > 0; width: parent.width; height: 1; color: Theme.white(0.05) }
        Rectangle {
            id: tile
            x: 12; anchors.verticalCenter: parent.verticalCenter
            width: 34; height: 34; radius: 11
            color: row.entry.connected ? Theme.accent : Theme.white(0.07)
            QIcon { anchors.centerIn: parent; path: Icons.get(row.entry.glyph); size: 17; strokeWidth: 1.9; color: row.entry.connected ? Theme.accentInk : Theme.text3 }
        }
        Column {
            anchors { left: tile.right; leftMargin: 12; right: trail.left; rightMargin: 12; verticalCenter: parent.verticalCenter }
            spacing: 2
            Text { width: parent.width; elide: Text.ElideRight; text: row.entry.name; textFormat: Text.PlainText; font.family: Theme.fontUi; font.pixelSize: 14; font.weight: Font.Medium; color: Theme.text }
            Text {
                width: parent.width; elide: Text.ElideRight
                text: row.nearbyRow ? row.entry.kind
                    : (row.entry.connected ? "Connected" : "Not connected") + (row.entry.battery >= 0 ? "  ·  " + row.entry.battery + "% battery" : "")
                font.family: Theme.fontUi; font.pixelSize: 12; color: Theme.textDim
            }
        }
        Row {
            id: trail
            anchors { right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter }
            spacing: 8
            Row {
                visible: row.entry.busy
                anchors.verticalCenter: parent.verticalCenter
                spacing: 8
                Spinner { anchors.verticalCenter: parent.verticalCenter }
                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: row.nearbyRow ? "Pairing" : row.entry.connected ? "Disconnecting" : "Connecting"
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5); color: Theme.text3
                }
            }
            Button {
                visible: row.nearbyRow && !row.entry.busy
                enabled: root.pairingKey === ""
                text: "Pair"; variant: "soft"; size: 30; fontWeight: Font.Medium
                onClicked: row.pair()
            }
            Button {
                visible: !row.nearbyRow && !row.entry.busy
                text: row.entry.connected ? "Disconnect" : "Connect"
                variant: row.entry.connected ? "outline" : "soft"; size: 30; fontWeight: Font.Medium
                onClicked: row.toggleConnection()
            }
            Button {
                visible: !row.nearbyRow
                text: "Forget"; variant: "outline"; size: 30
                onClicked: row.forget()
            }
        }
    }

    // ---- Your devices -------------------------------------------------------------------------------
    Column {
        width: parent.width
        spacing: 0
        Item {
            width: parent.width
            height: yours.implicitHeight + 8
            SectionLabel { id: yours; x: 4; text: "Your devices" }
        }
        Rectangle {
            width: parent.width
            height: mine.implicitHeight
            radius: 16
            color: Theme.white(0.035)
            border.width: 1; border.color: Theme.white(0.06)
            clip: true
            Column {
                id: mine
                width: parent.width
                Repeater {
                    id: mineRep
                    model: root.devices
                    delegate: DeviceRow {
                        required property var modelData
                        entry: modelData
                        onToggleConnection: entry.connected ? root.disconnectClicked(entry.key) : root.connectClicked(entry.key)
                        onForget: root.forgetClicked(entry.key)
                    }
                }
                Text {
                    visible: mineRep.count === 0
                    width: mine.width
                    leftPadding: 16; topPadding: 18; bottomPadding: 18
                    text: "No devices yet. Headphones, keyboards, mice and controllers you pair show up here."
                    wrapMode: Text.Wrap
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5); color: Theme.textDim
                }
            }
        }
    }

    // ---- Add a device / Nearby devices ---------------------------------------------------------------
    Column {
        width: parent.width
        spacing: 0
        Item {
            width: parent.width
            height: Math.max(near.implicitHeight + 8, addBtn.height + 8)
            SectionLabel { id: near; x: 4; anchors.verticalCenter: addBtn.verticalCenter; text: root.adding ? "Nearby devices" : "Add a device" }
            Row {
                anchors { right: parent.right; rightMargin: 2; verticalCenter: addBtn.verticalCenter }
                spacing: 10
                visible: root.adding
                Spinner { anchors.verticalCenter: parent.verticalCenter }
                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: "Looking…"
                    font.family: Theme.fontUi; font.pixelSize: 12; color: Theme.textDim
                }
                Button { text: "Stop"; variant: "outline"; size: 28; onClicked: root.stopClicked() }
            }
            Button {
                id: addBtn
                visible: !root.adding
                anchors { right: parent.right; rightMargin: 2; top: parent.top }
                text: "Add a device"; variant: "primary"; size: 32
                enabled: root.canAdd
                onClicked: root.addClicked()
            }
        }
        Rectangle {
            visible: root.adding
            width: parent.width
            height: others.implicitHeight
            radius: 16
            color: Theme.white(0.035)
            border.width: 1; border.color: Theme.white(0.06)
            clip: true
            Column {
                id: others
                width: parent.width
                Repeater {
                    id: nearRep
                    model: root.adding ? root.nearby : []
                    delegate: DeviceRow {
                        required property var modelData
                        nearbyRow: true
                        entry: modelData
                        onPair: root.pairClicked(entry.key)
                    }
                }
                Text {
                    visible: nearRep.count === 0
                    width: others.width
                    leftPadding: 16; topPadding: 18; bottomPadding: 18
                    text: "Put the device in pairing mode (often: hold its power or Bluetooth button until a light blinks)."
                    wrapMode: Text.Wrap
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5); color: Theme.textDim
                }
            }
        }
        Text {
            visible: !root.adding
            width: parent.width
            leftPadding: 4; topPadding: 2
            text: root.canAdd ? "Headphones, speakers, keyboards, mice and controllers." : "Turn Bluetooth on to add a device."
            font.family: Theme.fontUi; font.pixelSize: 12; color: Theme.textDim
        }
    }
}
