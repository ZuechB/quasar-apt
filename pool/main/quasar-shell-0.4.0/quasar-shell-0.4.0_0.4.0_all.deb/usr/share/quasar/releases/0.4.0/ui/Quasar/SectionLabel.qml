import QtQuick

// Small monospace caps label used for panel/settings sections ("PERFORMANCE", "PLACES", …).
Text {
    font.family: Theme.fontMono
    font.pointSize: Theme.pt(10.5)
    font.letterSpacing: 1.05
    color: Theme.textFaint
    font.capitalization: Font.AllUppercase
}
