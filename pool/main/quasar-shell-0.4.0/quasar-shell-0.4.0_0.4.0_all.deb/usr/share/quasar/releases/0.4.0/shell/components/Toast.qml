import QtQuick
import Quasar

// Notification toast (mockup role="status"): 320px, slides in from the right with the spring curve.
Panel {
    id: root
    radius: 16
    tint: Theme.menuBg
    borderColor: Theme.white(0.11)
    shadowOffsetY: 20
    shadowBlur: 50
    shadowSpread: -18

    property string title: ""
    property string sub: ""
    property string glyph: Icons.check
    property color hue: Theme.mint
    property url image: ""
    signal dismissed()
    signal clicked()

    implicitWidth: 320
    implicitHeight: Math.max(60, textCol.implicitHeight + 24)

    // entrance: translateX(40px) scale(.94) -> none, spring .55s (declarative: one progress value)
    property real enter: Theme.reduceMotion ? 1 : 0
    NumberAnimation on enter {
        running: !Theme.reduceMotion
        from: 0; to: 1
        duration: Motion.toast
        easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.spring
    }
    opacity: Math.min(1, enter * 2)
    scale: 0.94 + 0.06 * enter
    transform: Translate { x: 40 * (1 - root.enter) }

    MouseArea { anchors.fill: parent; onClicked: root.clicked() }

    Rectangle {
        x: 14; anchors.verticalCenter: parent.verticalCenter
        width: 36; height: 36; radius: 11
        color: Theme.white(0.06)
        QIcon { anchors.centerIn: parent; visible: root.image.toString() === ""; path: root.glyph; size: 18; color: root.hue }
        Image { anchors.centerIn: parent; visible: root.image.toString() !== ""; source: root.image; width: 22; height: 22; sourceSize: Qt.size(44, 44); asynchronous: true }
    }
    Column {
        id: textCol
        x: 62; anchors.verticalCenter: parent.verticalCenter
        width: root.width - 62 - 46
        spacing: 2
        Text { width: parent.width; elide: Text.ElideRight; text: root.title; font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5); font.weight: Font.DemiBold; color: Theme.text }
        Text { width: parent.width; wrapMode: Text.WordWrap; maximumLineCount: 2; elide: Text.ElideRight; text: root.sub; font.family: Theme.fontUi; font.pixelSize: 12; color: Theme.textMuted }
    }
    Pressable {
        anchors { right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter }
        width: 30; height: 30; radius: 9
        accessibleName: "Dismiss"
        onClicked: root.dismissed()
        QIcon { anchors.centerIn: parent; path: Icons.x; size: 14; strokeWidth: 2; color: Theme.textDim }
    }
}
