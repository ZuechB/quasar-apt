import QtQuick
import Quasar

// Proxy and HTTPS (opened from the sidebar footer): the web server, Quasar's local certificate
// authority and where it's trusted, who can reach the sites, and turning Sites off.
Item {
    id: root
    property bool active: false
    property string proxyState: "inactive"
    property string caCode: ""
    property bool everywhere: false
    property int siteCount: 0
    property bool busy: false
    property string message: ""
    property string error: ""
    property string errorDetails: ""
    property bool confirmOff: false
    signal trustAgain()
    signal trustBrowsers()
    signal askTurnOff()
    signal cancelTurnOff()
    signal turnOff()

    implicitHeight: col.implicitHeight

    Column {
        id: col
        width: Math.min(parent.width, 760)
        spacing: 16

        Row {
            spacing: 12
            Text {
                anchors.verticalCenter: parent.verticalCenter
                text: "Proxy and HTTPS"
                font.family: Theme.fontDisplay; font.pixelSize: 26; font.weight: Font.Medium; font.letterSpacing: -0.4
                color: Theme.text
            }
            StatusPill {
                anchors.verticalCenter: parent.verticalCenter
                text: !root.active ? "Off" : root.proxyState === "active" ? "Running" : root.proxyState === "failed" ? "Stopped" : "Starting"
                tone: !root.active ? Theme.textDim : root.proxyState === "active" ? Theme.mint : root.proxyState === "failed" ? Theme.danger : Theme.amber
                pulse: root.active && root.proxyState === "active"
            }
        }
        Text {
            width: parent.width
            wrapMode: Text.WordWrap
            text: "Caddy answers on ports 80 and 443 and sends each address to its site. Quasar’s own certificate authority signs the local addresses; it can only vouch for names ending in .localhost or .local, so trusting it can’t expose anything else."
            font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5); lineHeight: 1.15
            color: Theme.textMuted
        }

        Banner { visible: root.message !== ""; width: parent.width; tone: "success"; message: root.message }
        Banner { visible: root.error !== ""; width: parent.width; tone: "error"; message: root.error; details: root.errorDetails }

        SettingsGroup {
            width: parent.width
            label: "Web server"
            SettingsRow {
                width: parent.width
                glyph: Icons.server
                label: "Caddy"
                sub: root.siteCount === 1 ? "Serving 1 site" : "Serving " + root.siteCount + " sites"
                trailing: "value"
                value: !root.active ? "Off" : root.proxyState === "active" ? "Running" : root.proxyState
                valueColor: root.active && root.proxyState === "active" ? Theme.mint : Theme.textDim
            }
            SettingsRow {
                width: parent.width
                glyph: Icons.lock
                label: "Who can reach the sites"
                sub: root.everywhere ? "Other devices can reach the sites you shared" : "Only this PC. Nothing is reachable from other devices."
                trailing: "value"
                value: root.everywhere ? "Shared" : "This PC"
            }
        }

        SettingsGroup {
            width: parent.width
            label: "Certificates"
            SettingsRow {
                width: parent.width
                glyph: Icons.shield
                label: "Quasar’s local certificate authority"
                sub: "Fingerprint code " + (root.caCode || "–") + ". Compare it when you trust this PC on another device."
                trailing: "value"
                value: "This PC trusts it"
                valueColor: Theme.mint
            }
            SettingsRow {
                width: parent.width
                glyph: Icons.globe
                label: "Chrome and other browsers"
                sub: "Firefox and system tools trust it already. Chrome and Flatpak browsers keep their own list."
                trailing: "button"
                value: "Trust"
                busy: root.busy
                onActivated: root.trustBrowsers()
            }
            SettingsRow {
                width: parent.width
                glyph: Icons.refresh
                label: "Trust it on this PC again"
                sub: "If a browser warns about a local address"
                trailing: "button"
                value: "Trust again"
                busy: root.busy
                onActivated: root.trustAgain()
            }
        }

        SettingsGroup {
            width: parent.width
            label: "Sharing"
            SettingsRow { width: parent.width; glyph: Icons.wifi; label: "Home network"; sub: "Names like shop.local for phones and laptops on your Wi-Fi"; trailing: "soon" }
            SettingsRow { width: parent.width; glyph: Icons.globe; label: "Internet"; sub: "Your own domain: router, DNS, dynamic address and Let’s Encrypt, step by step"; trailing: "soon" }
            SettingsRow { width: parent.width; glyph: Icons.cloud; label: "Cloudflare Tunnel"; sub: "For connections that can’t accept incoming traffic (carrier-grade NAT)"; trailing: "soon" }
        }

        Button {
            visible: root.active && !root.confirmOff
            variant: "outline"; size: 36
            glyph: Icons.power; text: "Turn off Sites"
            fg: Theme.danger
            enabled: !root.busy
            onClicked: root.askTurnOff()
        }
        Rectangle {
            visible: root.confirmOff
            width: parent.width
            height: offCol.implicitHeight + 28
            radius: 16
            color: Theme.alpha(Theme.danger, 0.08)
            border.width: 1; border.color: Theme.alpha(Theme.danger, 0.3)
            Column {
                id: offCol
                anchors { left: parent.left; right: parent.right; top: parent.top; margins: 14 }
                spacing: 12
                Text {
                    width: parent.width
                    wrapMode: Text.WordWrap
                    text: "Turn off Sites? Every site stops and the web server closes ports 80 and 443. Nothing is deleted: turning Sites on again brings everything back."
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
                    color: Theme.text
                }
                Row {
                    spacing: 8
                    Button { variant: "primary"; tone: Theme.danger; size: 34; text: "Turn off"; busy: root.busy; enabled: !root.busy; onClicked: root.turnOff() }
                    Button { variant: "outline"; size: 34; text: "Keep it on"; onClicked: root.cancelTurnOff() }
                }
            }
        }
    }
}
