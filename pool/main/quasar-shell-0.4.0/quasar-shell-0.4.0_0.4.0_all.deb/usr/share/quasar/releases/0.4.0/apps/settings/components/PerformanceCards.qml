import QtQuick
import Quasar

// Performance profile cards (template): Lite / Balanced / Max — 22px glyph (ACTIVE tag when chosen),
// 16px/600 name, 12.5px description; chosen card has an accent ring and tint. Without a GPU only Lite
// is available (the others show why).
Grid {
    id: root
    property int profile: 1
    property bool locked: false
    signal picked(int index)

    readonly property var cards: [
        ["Lite", "For Raspberry Pi, older hardware and PCs without graphics acceleration. Solid panels, no blur, still wallpaper.", Icons.server, Theme.mint],
        ["Balanced", "Full glass and motion with an adaptive frame rate. The default.", Icons.bolt, Theme.accent],
        ["Max", "Highest frame rate and richer effects. For desktops with a GPU.", Icons.activity, Theme.amber]
    ]
    readonly property int cols: Math.max(1, Math.floor((width + 10) / (200 + 10)))
    columns: cols
    spacing: 10

    Repeater {
        model: root.cards
        Pressable {
            required property int index
            required property var modelData
            readonly property bool on: root.profile === index
            readonly property bool unavailable: root.locked && index > 0
            width: (root.width - (root.cols - 1) * 10) / root.cols
            height: col.implicitHeight + 32
            radius: 18
            kind: "card"
            enabled: !unavailable
            opacity: unavailable ? 0.55 : 1
            color: on ? Theme.alpha(Theme.accent, 0.07) : Theme.white(0.03)
            borderWidth: 1.5
            borderColor: on ? Theme.accent : Theme.white(0.07)
            hoverBorderColor: on ? Theme.accent : Theme.white(0.16)
            accessibleName: modelData[0]
            Accessible.role: Accessible.RadioButton
            Accessible.checked: on
            onClicked: root.picked(index)
            Column {
                id: col
                x: 16; y: 16
                width: parent.width - 32
                spacing: 10
                Item {
                    width: parent.width; height: 22
                    QIcon { path: modelData[2]; size: 22; strokeWidth: 1.9; color: modelData[3] }
                    Text {
                        anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                        visible: on || unavailable
                        text: on ? "ACTIVE" : "NEEDS A GPU"
                        font.family: Theme.fontMono; font.pointSize: Theme.pt(10.5)
                        color: on ? Theme.accent : Theme.textFaint
                    }
                }
                Text { text: modelData[0]; font.family: Theme.fontUi; font.pixelSize: 16; font.weight: Font.DemiBold; color: Theme.text }
                Text {
                    width: parent.width
                    text: modelData[1]
                    wrapMode: Text.Wrap
                    lineHeight: 1.1
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
                    color: Theme.textMuted
                }
            }
        }
    }
}
