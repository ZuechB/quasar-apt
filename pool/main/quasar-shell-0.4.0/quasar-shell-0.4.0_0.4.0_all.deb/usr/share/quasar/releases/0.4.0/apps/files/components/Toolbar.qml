import QtQuick
import Quasar

// Files' title-bar content (template: the title bar is the toolbar): back / forward, where the
// window is (Breadcrumb), search this folder, and grid | list. Sits in AppWindow.titleItem; its
// empty parts still move the window.
Item {
    id: root
    property var crumbs: []
    property string fullPath: ""
    property bool canBack: false
    property bool canForward: false
    property string query: ""
    property string mode: "grid"
    property bool trash: false
    property bool listOnly: false            // search results: always a list
    property bool active: true
    signal back()
    signal forward()
    signal navigate(string path)
    signal pathTyped(string text)
    signal queryEdited(string text)
    signal searchDone()                      // Esc on an empty search: back to the items
    signal searchSubmitted()                 // Enter: look in every folder below
    signal modePicked(string mode)
    signal dropped(string path, var drop)

    function focusSearch() { search.focusInput() }
    function editPath() { bread.edit() }
    function clearSearch() { search.text = "" }

    implicitHeight: 46

    Row {
        id: nav
        anchors.verticalCenter: parent.verticalCenter
        spacing: 2
        component NavButton: Pressable {
            id: navButton
            property string glyph: ""
            width: 32; height: 32; radius: 9
            opacity: enabled ? 1 : 0.35
            QIcon { anchors.centerIn: parent; path: navButton.glyph; size: 16; strokeWidth: 2; color: Theme.text3 }
        }
        NavButton { glyph: Icons.back; enabled: root.canBack; accessibleName: "Back"; onClicked: root.back() }
        NavButton { glyph: Icons.fwd; enabled: root.canForward; accessibleName: "Forward"; onClicked: root.forward() }
    }

    Breadcrumb {
        id: bread
        anchors { left: nav.right; leftMargin: 8; right: search.left; rightMargin: 10; verticalCenter: parent.verticalCenter }
        crumbs: root.crumbs
        fullPath: root.fullPath
        active: root.active
        onNavigate: (p) => root.navigate(p)
        onPathTyped: (t) => root.pathTyped(t)
        onDropped: (p, d) => root.dropped(p, d)
    }

    SearchField {
        id: search
        anchors { right: toggle.visible ? toggle.left : parent.right; rightMargin: toggle.visible ? 8 : 4; verticalCenter: parent.verticalCenter }
        width: 180; height: 30
        radius: 9
        placeholder: root.trash ? "Search the Trash" : "Search this folder"
        text: root.query
        onEdited: (t) => root.queryEdited(t)
        onEscapePressed: root.searchDone()
        onAccepted: root.searchSubmitted()
    }

    // grid | list (the Trash is always a list)
    Rectangle {
        id: toggle
        visible: !root.trash && !root.listOnly
        anchors { right: parent.right; rightMargin: 4; verticalCenter: parent.verticalCenter }
        width: 66; height: 30; radius: 9
        color: Theme.white(0.06)
        Rectangle {
            x: root.mode === "list" ? 33 : 3; y: 3
            width: 30; height: 24; radius: 7
            color: Theme.white(0.14)
            Behavior on x { NumberAnimation { duration: Motion.dur(Motion.pill); easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.spring } }
        }
        Repeater {
            model: [{ key: "grid", glyph: Icons.grid, name: "Show as tiles" }, { key: "list", glyph: Icons.list, name: "Show as a list" }]
            delegate: MouseArea {
                required property var modelData
                required property int index
                x: 3 + index * 30; y: 3
                width: 30; height: 24
                cursorShape: Qt.PointingHandCursor
                Accessible.role: Accessible.Button
                Accessible.name: modelData.name
                onClicked: root.modePicked(modelData.key)
                QIcon {
                    anchors.centerIn: parent
                    path: parent.modelData.glyph; size: 14; strokeWidth: 2
                    color: root.mode === parent.modelData.key ? Theme.text : Theme.textMuted
                }
            }
        }
    }
}
