import QtQuick

// Settings/quick-settings switch: 46×28, accent when on, white knob springs 18px (mockup role="switch").
Item {
    id: root
    property bool checked: false
    property string accessibleName: ""
    signal toggled()

    implicitWidth: 46
    implicitHeight: 28
    opacity: enabled ? 1 : 0.5
    activeFocusOnTab: enabled
    Accessible.role: Accessible.CheckBox
    Accessible.checkable: true
    Accessible.checked: checked
    Accessible.name: accessibleName
    Accessible.onToggleAction: root.toggled()
    Accessible.onPressAction: root.toggled()
    Keys.onSpacePressed: root.toggled()
    Keys.onReturnPressed: root.toggled()

    Rectangle {
        id: track
        anchors.fill: parent
        radius: 14
        color: root.checked ? Theme.accent : Theme.white(0.14)
        Behavior on color { ColorAnimation { duration: Motion.dur(300) } }

        Shadow {
            target: knob
            radius: 11
            offsetY: 2
            blur: 6
            spread: 0
            color: Qt.rgba(0, 0, 0, 0.35)
        }
        Rectangle {
            id: knob
            x: 3 + (root.checked ? 18 : 0)
            y: 3
            width: 22; height: 22; radius: 11
            color: "#FFFFFF"
            Behavior on x { NumberAnimation { duration: Motion.dur(Motion.knob); easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.spring } }
        }
    }
    Rectangle {
        anchors.fill: parent; anchors.margins: -4; radius: 18
        color: "transparent"; border.width: 2; border.color: Theme.accent
        visible: root.activeFocus
    }
    MouseArea {
        anchors.fill: parent
        enabled: root.enabled
        cursorShape: root.enabled ? Qt.PointingHandCursor : Qt.ForbiddenCursor
        onClicked: root.toggled()
    }
}
