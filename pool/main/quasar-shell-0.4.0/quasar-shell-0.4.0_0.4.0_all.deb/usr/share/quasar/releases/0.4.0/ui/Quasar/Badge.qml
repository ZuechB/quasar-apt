import QtQuick

// Status pill with a dot, e.g. "On-device" (mint) in the launcher search and assistant header.
Rectangle {
    id: root
    property string text: "On-device"
    property color tone: Theme.mint
    implicitHeight: 26
    implicitWidth: row.implicitWidth + 18
    radius: 8
    color: Theme.alpha(tone, 0.10)
    border.width: 1
    border.color: Theme.alpha(tone, 0.22)

    Row {
        id: row
        anchors.centerIn: parent
        spacing: 6
        Rectangle { width: 6; height: 6; radius: 3; color: root.tone; anchors.verticalCenter: parent.verticalCenter }
        Text {
            text: root.text
            font.family: Theme.fontMono
            font.pointSize: Theme.pt(10.5)
            color: root.tone
            anchors.verticalCenter: parent.verticalCenter
        }
    }
}
