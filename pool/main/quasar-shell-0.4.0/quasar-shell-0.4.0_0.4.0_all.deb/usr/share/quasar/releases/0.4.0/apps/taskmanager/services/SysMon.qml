import QtQuick
import Quickshell
import Quickshell.Io

// Task Manager's numbers: /usr/libexec/quasar/sysmon watch (linux/system/sysmon/quasar_sysmon has the
// protocol), one line a second while Task Manager runs; it ends when this process does (stdin EOF). Keeps a
// minute of history per device for the graphs (TM.devices / TM.detail name the keys).
//   QUASAR_SYSMON=/path: another helper (tests, the preview's fake).
Item {
    id: root
    visible: false
    property var info: null
    property var tick: null
    property var history: ({})
    readonly property int keep: 60
    readonly property string helper: Quickshell.env("QUASAR_SYSMON") || "/usr/libexec/quasar/sysmon"
    property var expanded: []
    property int restarts: 0

    // The groups whose processes the Processes page shows (sysmon reads them only for these).
    function expand(keys) {
        expanded = keys || []
        if (proc.running) proc.write(JSON.stringify({ expand: expanded }) + "\n")
    }

    function push(h, key, v) {
        const a = (h[key] || []).concat([v === null || v === undefined ? 0 : Number(v) || 0])
        if (a.length > keep) a.splice(0, a.length - keep)
        h[key] = a
    }
    function take(t) {
        const h = Object.assign({}, history)
        push(h, "cpu", t.cpu ? t.cpu.total : 0)
        push(h, "mem", t.mem && t.mem.total ? t.mem.used / t.mem.total * 100 : 0)
        for (const d of t.disks || []) { push(h, "disk:" + d.key, d.busy); push(h, "diskr:" + d.key, d.readBps); push(h, "diskw:" + d.key, d.writeBps) }
        for (const n of t.nets || []) { push(h, "netrx:" + n.key, n.rxBps); push(h, "nettx:" + n.key, n.txBps) }
        for (const g of t.gpus || []) {
            push(h, "gpu:" + g.key, g.busy)
            push(h, "gpumem:" + g.key, g.vramUsed && g.vramTotal ? g.vramUsed / g.vramTotal * 100 : 0)
        }
        history = h
        tick = t
        restarts = 0
    }

    Process {
        id: proc
        command: [root.helper, "watch"]
        stdinEnabled: true
        stdout: SplitParser {
            onRead: (line) => {
                let m
                try { m = JSON.parse(line) } catch (e) { return }
                if (m.type === "info") root.info = m
                else if (m.type === "tick") root.take(m)
            }
        }
        onStarted: if (root.expanded.length) write(JSON.stringify({ expand: root.expanded }) + "\n")
        onExited: (code) => retry.restart()          // a crash: start it again (1 s, 2 s, 4 s … at most 30 s)
    }
    Timer {
        id: retry
        interval: Math.min(30000, 1000 * Math.pow(2, Math.min(5, root.restarts)))
        onTriggered: { root.restarts++; proc.running = true }
    }
    Component.onCompleted: proc.running = true
}
