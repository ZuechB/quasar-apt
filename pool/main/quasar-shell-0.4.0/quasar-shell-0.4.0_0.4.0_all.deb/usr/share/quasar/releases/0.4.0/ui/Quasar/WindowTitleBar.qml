import QtQuick

// App window title bar (template: <section data-win> > first <div>): 46px, padding 0 6px 0 14px,
// 16px glyph + 13px/600 title, extras slot, then 34x30 "hov" buttons (minimize, maximize/restore,
// close). The Terminal uses 44px with a company-colour tint fading out at 55%.
// Pure view: the host window turns the signals into startSystemMove()/minimize/maximize/close.
Rectangle {
    id: root
    property string title: ""
    property string glyph: ""                    // Icons path
    property color glyphColor: Theme.text3
    property bool active: true                   // window focused: brighter title
    property bool maximized: false
    property color tint: "transparent"           // e.g. Theme.alpha(companyColor, 0.12)
    property bool showMinimize: true
    property bool showMaximize: true
    default property alias extras: extraRow.data // e.g. a status pill or a "+" button
    // Replaces the title text and fills the space up to the extras (the Terminal's tab strip).
    // Empty parts of it still drag the window: give it no MouseArea of its own there.
    property Item leadingItem: null
    // The window's top corners (AppWindow passes its corner radius; 0 = square). The fills are
    // translucent, so per-corner radii are safe on the software scene graph (see CLAUDE.md).
    property real cornerRadius: 0
    onLeadingItemChanged: if (leadingItem) { leadingItem.parent = leadSlot; leadingItem.anchors.fill = leadSlot }

    signal moveRequested()
    signal minimizeClicked()
    signal maximizeClicked()
    signal closeClicked()

    implicitHeight: 46
    color: Theme.white(0.02)
    topLeftRadius: cornerRadius
    topRightRadius: cornerRadius

    Rectangle {
        anchors.fill: parent
        visible: root.tint.a > 0
        topLeftRadius: root.cornerRadius
        topRightRadius: root.cornerRadius
        gradient: Gradient {
            orientation: Gradient.Horizontal
            GradientStop { position: 0.0; color: root.tint }
            GradientStop { position: 0.55; color: "transparent" }
        }
    }
    Rectangle {
        anchors.bottom: parent.bottom
        width: parent.width; height: 1
        color: Theme.white(0.06)
    }

    // Drag anywhere on the bar: after 4px of movement the compositor takes over the move (1:1 with
    // the pointer, with snapping). Double-click toggles maximize. Buttons sit above this area.
    MouseArea {
        anchors.fill: parent
        acceptedButtons: Qt.LeftButton
        property point origin
        property bool handedOff: false
        onPressed: (e) => { origin = Qt.point(e.x, e.y); handedOff = false }
        onPositionChanged: (e) => {
            if (pressed && !handedOff && Math.abs(e.x - origin.x) + Math.abs(e.y - origin.y) >= 4) {
                handedOff = true
                root.moveRequested()
            }
        }
        onDoubleClicked: root.maximizeClicked()
    }

    Row {
        id: lead
        x: 14
        anchors.verticalCenter: parent.verticalCenter
        spacing: 9
        QIcon {
            anchors.verticalCenter: parent.verticalCenter
            visible: root.glyph !== ""
            path: root.glyph; size: 16; strokeWidth: 1.9
            color: root.glyphColor
        }
        Text {
            anchors.verticalCenter: parent.verticalCenter
            visible: !root.leadingItem
            width: Math.min(implicitWidth, root.width - lead.x - extraRow.width - buttons.width - 60)
            text: root.title
            elide: Text.ElideRight
            textFormat: Text.PlainText
            font.family: Theme.fontUi; font.pixelSize: 13; font.weight: Font.DemiBold
            color: root.active ? Theme.text : Theme.textDim
            Behavior on color { ColorAnimation { duration: Motion.dur(300) } }
        }
    }

    Item {
        id: leadSlot
        visible: !!root.leadingItem
        anchors { top: parent.top; bottom: parent.bottom; bottomMargin: 1 }
        x: lead.x + lead.width + (lead.width > 0 ? 6 : 0)
        width: Math.max(0, extraRow.x - (extraRow.width > 0 ? 6 : 0) - x)
    }

    Row {
        id: extraRow
        anchors.right: buttons.left
        anchors.rightMargin: 6
        anchors.verticalCenter: parent.verticalCenter
        spacing: 6
    }

    Row {
        id: buttons
        anchors.right: parent.right
        anchors.rightMargin: 6
        anchors.verticalCenter: parent.verticalCenter
        spacing: 2

        Pressable {
            visible: root.showMinimize
            width: 34; height: 30; radius: 8; kind: "hov"
            accessibleName: "Minimize"
            onClicked: root.minimizeClicked()
            QIcon { anchors.centerIn: parent; path: "M6 12h12"; size: 14; strokeWidth: 2; color: Theme.textMuted }
        }
        Pressable {
            visible: root.showMaximize
            width: 34; height: 30; radius: 8; kind: "hov"
            accessibleName: root.maximized ? "Restore" : "Maximize"
            onClicked: root.maximizeClicked()
            QIcon { anchors.centerIn: parent; path: root.maximized ? Icons.restore : Icons.square; size: 13; strokeWidth: 2; color: Theme.textMuted }
        }
        Pressable {
            width: 34; height: 30; radius: 8; kind: "hov"
            accessibleName: "Close"
            onClicked: root.closeClicked()
            QIcon { anchors.centerIn: parent; path: Icons.x; size: 14; strokeWidth: 2; color: Theme.textMuted }
        }
    }
}
