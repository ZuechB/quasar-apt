import QtQuick
import QtQuick.Shapes

// A performance graph (Task Manager's Performance page): one or more series drawn left to right over a light
// grid, the first one with a soft fill under it. Values are scaled to `max` (0 = the largest value, at least
// `floor`). `capacity` points fill the width, so a series that grows (one sample a second) scrolls in from the
// right the way it does in other task managers. Like Sparkline, the Shape sits in a fixed-size Item and is
// layered on the software path (clips when scrolled away; see Theme.softwareRender).
//   series: [{ values: [...], color }]
Item {
    id: root
    property var series: []
    property real max: 100
    property real floor: 1
    property int capacity: 60
    property bool fill: true
    property int rows: 4
    property int columns: 6
    property color gridColor: Theme.white(0.05)
    property color frameColor: Theme.white(0.10)

    implicitWidth: 400
    implicitHeight: 180

    readonly property real peak: {
        if (max > 0) return max
        let m = floor
        for (const s of series || [])
            for (const v of s.values || []) m = Math.max(m, Number(v) || 0)
        return m
    }

    function points(values) {
        const n = values ? values.length : 0, out = []
        if (n < 2 || width <= 0 || height <= 0) return out
        const step = width / Math.max(1, capacity - 1)
        const x0 = width - (n - 1) * step
        for (let i = 0; i < n; i++) {
            const v = Math.min(root.peak, Math.max(0, Number(values[i]) || 0))
            out.push(Qt.point(x0 + i * step, height - 1 - v / root.peak * (height - 2)))
        }
        return out
    }

    // The grid and the frame.
    Repeater {
        model: root.rows - 1
        Rectangle { required property int index; y: Math.round((index + 1) * root.height / root.rows); width: root.width; height: 1; color: root.gridColor }
    }
    Repeater {
        model: root.columns - 1
        Rectangle { required property int index; x: Math.round((index + 1) * root.width / root.columns); width: 1; height: root.height; color: root.gridColor }
    }
    Rectangle { anchors.fill: parent; color: "transparent"; border.width: 1; border.color: root.frameColor; radius: 2 }

    Repeater {
        model: root.series || []
        Item {
            id: s
            required property var modelData
            required property int index
            anchors.fill: parent
            readonly property var pts: root.points(modelData.values)
            // The area under the first series: the line's points closed along the bottom.
            readonly property var area: pts.length > 1 ? [Qt.point(pts[0].x, root.height)].concat(pts, [Qt.point(pts[pts.length - 1].x, root.height)]) : []
            Shape {
                anchors.fill: parent
                visible: s.pts.length > 1
                preferredRendererType: Shape.CurveRenderer
                layer.enabled: Theme.softwareRender
                ShapePath {
                    strokeWidth: 0
                    strokeColor: "transparent"
                    fillColor: root.fill && s.index === 0 ? Theme.alpha(s.modelData.color || Theme.accent, 0.12) : "transparent"
                    PathPolyline { path: root.fill && s.index === 0 ? s.area : [] }
                }
                ShapePath {
                    strokeColor: s.modelData.color || Theme.accent
                    strokeWidth: 1.6
                    fillColor: "transparent"
                    joinStyle: ShapePath.RoundJoin
                    capStyle: ShapePath.RoundCap
                    PathPolyline { path: s.pts }
                }
            }
        }
    }
}
