import QtQuick
import Quasar

// The whole Sites window body (template data-win="sites" minus the title bar): the 232px sidebar and
// the page on the right. Pure: everything comes in through `m` (the app's model object, built by
// shell.qml or by preview/SitesPreview.qml) and goes out through `act(name, args…)`.
//   m.page: "turnon" | "empty" | "new" | "site" | "server"
// The folder chooser (New site › Browse…) is view state: `browsing` opens it, and a chosen folder goes
// out as act("pick", path), like a project card.
Item {
    id: root
    property var m: ({})
    property bool browsing: false
    signal act(string name, var a, var b, var c)

    function call(name, a, b, c) { root.act(name, a === undefined ? null : a, b === undefined ? null : b, c === undefined ? null : c) }

    readonly property var site: (m.sites || []).find(s => s.id === m.selectedId) || null

    SiteNav {
        id: nav
        anchors { left: parent.left; top: parent.top; bottom: parent.bottom }
        width: 232
        sites: root.m.sites || []
        selectedId: root.m.selectedId || ""
        highlightNew: root.m.page === "new"
        serverOpen: root.m.page === "server"
        active: !!root.m.active
        proxyState: root.m.proxy || "inactive"
        onOpenNew: root.call("openNew")
        onSelect: (id) => root.call("select", id)
        onOpenServer: root.call("openServer")
    }

    ScrollPane {
        id: pane
        anchors { left: nav.right; right: parent.right; top: parent.top; bottom: parent.bottom }
        topPadding: 22
        bottomPadding: 28

        Item {
            id: host
            x: 26
            width: pane.width - 52
            height: Math.max(pane.height - 50, page.item ? page.item.implicitHeight : 0)
            Loader {
                id: page
                width: parent.width
                height: root.m.page === "empty" ? host.height : (item ? item.implicitHeight : 0)
                sourceComponent: root.m.page === "turnon" ? turnOn
                               : root.m.page === "new" ? newSite
                               : root.m.page === "site" && root.site ? sitePage
                               : root.m.page === "server" ? server : empty
            }
        }
    }

    Component {
        id: turnOn
        TurnOnPage {
            // The first time (no sites on this PC when Turn on was pressed) it also publishes the example
            // site. Decided once by the app, so the list doesn't shrink when that site shows up.
            steps: ["Create Quasar’s certificate authority", "Trust it on this PC", "Start the web server"]
                   .concat(root.m.activation && root.m.activation.starter ? ["Publish an example site"] : [])
            liveUsb: !!root.m.live
            caddyInstalled: root.m.caddy !== false
            working: !!(root.m.activation && root.m.activation.working)
            current: root.m.activation ? root.m.activation.current : -1
            failed: !!(root.m.activation && root.m.activation.failed)
            error: root.m.activation ? root.m.activation.error || "" : ""
            errorDetails: root.m.activation ? root.m.activation.details || "" : ""
            onTurnOn: root.call("turnOn")
        }
    }
    Component {
        id: empty
        EmptyPage { onOpenNew: root.call("openNew") }
    }
    Component {
        id: newSite
        NewSitePage {
            projects: root.m.projects || []
            scanning: !!root.m.scanning
            makingStarter: !!root.m.makingStarter
            draft: root.m.draft || null
            detecting: !!root.m.detecting
            detectError: root.m.detectError || ""
            tools: root.m.tools || ({})
            toolJob: root.m.toolJob || ({ active: false, percent: 0, phase: "", error: "" })
            deploying: !!(root.m.newDeploy && root.m.newDeploy.running)
            deploy: root.m.newDeploy || ({ steps: [], current: -1, failed: false, lines: [] })
            error: root.m.newError || ""
            errorDetails: root.m.newErrorDetails || ""
            home: root.m.home || ""
            onPick: (p) => root.call("pick", p)
            onPathEdited: (p) => root.call("pathEdited", p)
            onBrowse: root.browsing = true
            onStarter: root.call("starter")
            onEdited: (f, v) => root.call("draftEdited", f, v)
            onInstallTool: (n, s) => root.call("installTool", n, s)
            onDeploySite: root.call("createSite")
            onCancel: root.call("cancelNew")
        }
    }
    Component {
        id: sitePage
        SitePage {
            site: root.site
            detail: root.m.detail || null
            metrics: root.m.metrics || ({ rpm: 0, p95: null, hist: [] })
            logs: root.m.logs || []
            deploy: root.m.deploy || ({ steps: [], current: -1, failed: false, lines: [] })
            tab: root.m.tab || 0
            revealed: root.m.revealed || ({})
            confirmRemove: !!root.m.confirmRemove
            busy: !!root.m.busy
            error: root.m.siteError || ""
            errorDetails: root.m.siteErrorDetails || ""
            now: root.m.now || Date.now()
            home: root.m.home || ""
            onOpenUrl: (u) => root.call("openUrl", u)
            onOpenFolder: (p) => root.call("openFolder", p)
            onStart: root.call("start")
            onStop: root.call("stop")
            onRestart: root.call("restart")
            onDeployNow: root.call("deploy")
            onCancelDeploy: root.call("cancelDeploy")
            onRollback: (r) => root.call("rollback", r)
            onTabPicked: (i) => root.call("tab", i)
            onEnvSet: (n, v, s) => root.call("envSet", n, v, s)
            onEnvRemove: (n) => root.call("envRemove", n)
            onReveal: (n) => root.call("reveal", n)
            onHide: (n) => root.call("hide", n)
            onSetOption: (k, on) => root.call("setOption", k, on)
            onAskRemove: root.call("askRemove")
            onCancelRemove: root.call("cancelRemove")
            onRemove: root.call("remove")
            onDismissError: root.call("dismissError")
        }
    }
    Component {
        id: server
        ServerPage {
            active: !!root.m.active
            proxyState: root.m.proxy || "inactive"
            caCode: root.m.caCode || ""
            everywhere: !!root.m.everywhere
            siteCount: (root.m.sites || []).length
            busy: !!root.m.busy
            message: root.m.serverMessage || ""
            error: root.m.serverError || ""
            errorDetails: root.m.serverErrorDetails || ""
            confirmOff: !!root.m.confirmOff
            onTrustAgain: root.call("trustAgain")
            onTrustBrowsers: root.call("trustBrowsers")
            onAskTurnOff: root.call("askTurnOff")
            onCancelTurnOff: root.call("cancelTurnOff")
            onTurnOff: root.call("turnOff")
        }
    }

    // ---- New site › Browse…: the project folder ------------------------------------------------------
    FileChooser {
        id: chooser
        open: root.browsing && root.m.page === "new"
        folders: true
        title: "Choose the project folder"
        message: "Pick the folder with your site’s files, like index.html, package.json or a .csproj."
        home: root.m.home || ""
        drives: root.m.drives || ""
        // Home, then the usual project folders that exist (~/Sites, ~/Projects …).
        placeList: [{ label: "Home", path: chooser.home, glyph: Icons.home }].concat((root.m.roots || []).slice(0, 4).map(r => ({
            label: r.slice(r.lastIndexOf("/") + 1), path: r, glyph: Icons.folder })))
        // Home itself or anything above it would copy the whole home folder into the site.
        allowFolder: (p) => p !== "/" && p !== chooser.home && !chooser.home.startsWith(p + "/")
        onOpenChanged: {
            if (!open) return
            const d = root.m.draft
            const roots = root.m.roots || []
            folder = d && d.path ? d.path.slice(0, d.path.lastIndexOf("/")) || "/" : roots.length ? roots[0] : chooser.home
        }
        onChosen: (p) => { root.browsing = false; root.call("pick", p) }
        onDismissed: root.browsing = false
    }
}
