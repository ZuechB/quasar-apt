// Settings > Network & Internet > VPN: rows built from `nm-ctl list` (linux/system/net/quasar_net/nmctl.py).
// Pure, so the Settings app (services/Vpn.qml) and the design preview share it.
//   st:  { vpns: [{ uuid, name, kind: "wireguard" | "openvpn", server, state: "off" | "connecting" | "on",
//          fullTunnel, autostart, needs: ["user", "password", "keyPassword"] }] }   (null while loading)
//   ctx: { busy: "vpn:<uuid>" while one connects or disconnects, last: Settings.network.vpn ({ uuid, name }),
//          icons, theme }
// Plain words: a VPN is "your VPN", it "connects", traffic "goes through" it.
.pragma library

function vpns(st) { return (st && st.vpns) || [] }
function byUuid(st, uuid) { return vpns(st).find(function (v) { return v.uuid === uuid }) || null }
function connected(st) { return vpns(st).find(function (v) { return v.state === "on" }) || null }
function connecting(st, ctx) {
    return vpns(st).find(function (v) { return v.state === "connecting" || (ctx.busy === "vpn:" + v.uuid && v.state !== "on") }) || null
}

// The VPN the hero switch (and the shell's tile) acts on: the connected one, else the last one used,
// else the only one.
function current(st, ctx) {
    var on = connected(st) || connecting(st, ctx)
    if (on) return on
    var last = ctx.last && byUuid(st, ctx.last.uuid)
    if (last) return last
    return vpns(st).length === 1 ? vpns(st)[0] : null
}

function kindName(k) { return k === "wireguard" ? "WireGuard" : "OpenVPN" }

function needsLogin(v) { return !!v && (v.needs || []).some(function (n) { return n === "user" || n === "password" }) }

function stateValue(v, ctx) {
    var t = ctx.theme
    if (!v) return { value: "", color: t.textMuted }
    if (v.state === "on") return { value: "Connected", color: t.mint }
    if (v.state === "connecting" || ctx.busy === "vpn:" + v.uuid) return { value: "Connecting…", color: t.textMuted }
    if (needsLogin(v)) return { value: "Needs password", color: t.amber }
    return { value: "Off", color: t.textMuted }
}

// Network & Internet › More connections: the VPN row (a status row that opens the VPN page).
function networkRow(st, ctx) {
    var row = { key: "vpn:open", label: "VPN", glyph: ctx.icons.lock, trailing: "chevron", sub: "WireGuard and OpenVPN", value: "" }
    if (!st) return row
    if (!vpns(st).length) { row.value = "Set up"; return row }
    var v = current(st, ctx)
    var s = stateValue(v, ctx)
    row.sub = v ? v.name : vpns(st).length + " VPNs"
    row.value = v ? s.value : "Off"
    row.valueColor = s.color
    return row
}

function hero(st, ctx) {
    var icons = ctx.icons, t = ctx.theme
    if (!st)
        return { glyph: icons.lock, title: "VPN", sub: "Checking…" }
    if (!vpns(st).length)
        return { glyph: icons.lock, title: "Add your VPN", button: "Add a VPN", buttonPrimary: true,
                 sub: "Use the file your VPN provider, workplace or home server gave you: WireGuard (.conf) or OpenVPN (.ovpn)." }
    var on = connected(st)
    if (on)
        return { glyph: icons.lock, title: "Connected to " + on.name, toggle: true, checked: true, busy: ctx.busy === "vpn:" + on.uuid,
                 iconBg: t.accent, iconFg: t.accentInk,
                 sub: on.fullTunnel ? "All your internet traffic goes through " + on.name + "."
                                    : "Only " + on.name + "'s own network goes through it. The rest goes straight to the internet." }
    var c = connecting(st, ctx)
    if (c)
        return { glyph: icons.lock, title: "Connecting to " + c.name + "…", toggle: true, checked: true, busy: true,
                 sub: "This takes a few seconds." }
    var v = current(st, ctx)
    return { glyph: icons.lock, title: "VPN is off", toggle: true, checked: false, busy: false,
             sub: v ? "Your traffic goes straight to the internet. Turn this on to connect to " + v.name + "."
                    : "Your traffic goes straight to the internet. Pick a VPN below to connect." }
}

function groups(st, ctx) {
    if (!st) return []
    var rows = vpns(st).map(function (v) {
        var s = stateValue(v, ctx)
        var sub = [kindName(v.kind), v.server, v.fullTunnel ? "All traffic" : ""].filter(function (x) { return x }).join("  ·  ")
        return { key: "vpn:item:" + v.uuid, label: v.name, sub: sub, glyph: ctx.icons.lock, trailing: "chevron",
                 value: s.value === "Off" ? "" : s.value, valueColor: s.color }
    })
    rows.push({ key: "vpn:add", label: "Add a VPN", sub: "A WireGuard (.conf) or OpenVPN (.ovpn) file", glyph: ctx.icons.plus,
                trailing: "button", value: "Choose file…", busy: ctx.busy === "vpn:add" })
    var out = [{ label: vpns(st).length ? "Your VPNs" : "Add one", rows: rows }]
    if (vpns(st).length)
        out.push({ label: "Options", rows: [
            { key: "vpn:killswitch", label: "Block the internet when the VPN drops", sub: "Nothing leaves this PC outside the VPN",
              trailing: "soon" }] })
    return out
}

// What the VPN dialog shows for one VPN.
function sheet(v, ctx) {
    if (!v) return null
    return { uuid: v.uuid, name: v.name, kind: v.kind, state: v.state, autostart: !!v.autostart,
             canAutostart: v.kind === "wireguard", needsLogin: needsLogin(v),
             detail: [kindName(v.kind), v.server].filter(function (x) { return x }).join("  ·  "),
             busy: ctx.busy === "vpn:" + v.uuid }
}

// nm-ctl reasons (linux/system/net/quasar_net/reasons.py IMPORT + VPN_UP) in plain words.
var REASONS = {
    "unreadable": ["Quasar couldn't read that file", "Check that it's still there, then try again."],
    "too-big": ["That file is too big for a VPN profile", "Pick the .conf or .ovpn file your provider gave you."],
    "not-vpn": ["That isn't a VPN profile", "Pick a WireGuard (.conf) or OpenVPN (.ovpn) file from your VPN provider."],
    "bad-config": ["Something in that VPN file isn't right", ""],
    "missing-file": ["The VPN file needs another file that isn't there", "Put the files your provider sent together in one folder, then try again."],
    "otp": ["This VPN asks for a one-time code every time", "Quasar can't ask for codes yet. Ask your provider for a profile without one, or use their app from the Store."],
    "no-openvpn": ["OpenVPN support is missing", "This copy of Quasar can't add OpenVPN profiles. Update Quasar."],
    "nm-refused": ["The VPN couldn't be added", ""],
    "needs-secrets": ["Sign in to connect", "Type the user name and password your VPN provider gave you."],
    "password": ["The user name or password wasn't accepted", "Type them again: passwords are case-sensitive."],
    "unreachable": ["The VPN server didn't answer", "Check that you're online and the server is running, then try again."],
    "no-network": ["This PC isn't connected to a network", "Connect to Wi-Fi or a cable first."],
    "service": ["The VPN stopped while connecting", "Try again. If it keeps happening, ask your provider for a new profile."],
    "timeout": ["Connecting took too long", "The VPN server may be busy or out of reach. Try again."],
    "not-found": ["That VPN isn't there any more", ""],
    "not-allowed": ["Your account isn't allowed to change network settings", "Ask an administrator."],
    "cancelled": ["", ""],
    "other": ["That didn't work", ""]
}

function reasonText(code) {
    var r = REASONS[code] || REASONS.other
    return { title: r[0], message: r[1] }
}

// nm-ctl's notes on an import ("PostUp" lines in a WireGuard file…).
function noteText(notes) {
    if ((notes || []).indexOf("scripts-ignored") >= 0)
        return "Its file had commands to run when it connects. Quasar doesn't run them; the VPN works without."
    return ""
}
