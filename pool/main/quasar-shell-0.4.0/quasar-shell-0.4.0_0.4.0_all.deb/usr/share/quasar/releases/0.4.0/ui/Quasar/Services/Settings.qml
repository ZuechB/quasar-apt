pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io

// One settings file for the shell and every Quasar app: ~/.config/quasar/settings.json.
// Each process watches the file and reloads it, so a change made in Settings restyles the shell
// (and every open app) live. System settings (time zone, hostname, Wi-Fi…) are NOT stored here —
// they live in the system's own tools; this file only holds Quasar preferences.
// First run: migrates ~/.config/quasar/shell.json (the shell's earlier file), else writes defaults.
Singleton {
    id: root
    readonly property string dir: (Quickshell.env("XDG_CONFIG_HOME") || (Quickshell.env("HOME") + "/.config")) + "/quasar"
    readonly property string path: dir + "/settings.json"
    property bool loaded: false

    // -1 = automatic (Lite on software rendering, otherwise Balanced)
    property alias profile: data.profile
    property alias accent: data.accent
    // "deep" | "aurora" | "graphite" | "photo" (wallpaperPhoto, placed per wallpaperFit: "fill" | "fit").
    property alias wallpaper: data.wallpaper
    property alias wallpaperPhoto: data.wallpaperPhoto
    property alias wallpaperFit: data.wallpaperFit
    property alias glass: data.glass
    property alias reduceMotion: data.reduceMotion
    property alias pins: data.pins
    property alias focus: data.focus
    property alias nightLight: data.nightLight
    property alias clock24: data.clock24
    property alias preferSandbox: data.preferSandbox
    property alias input: data.input
    // Displays (Settings › Display, the shell, /usr/libexec/quasar/displays): { vrr (variable refresh
    // rate in full-screen apps, default on), hdr (HDR on every display that can show it, default off:
    // Settings' labwc layer, and the Vulkan renderer from the next sign-in), taskbarAll (a taskbar on every display,
    // default on), profiles: { KEY: { main: ID, saved: EPOCH, outputs: { ID: { enabled, mode: [w, h,
    // hz], x, y, scale, transform } } } } }. KEY = the connected displays' sorted IDs joined by "+"; ID =
    // "make|model|serial". Only Settings writes it; the helper re-applies a profile at login and when
    // the connected displays change. Missing keys take their defaults.
    property alias displays: data.displays
    // Desktop icons: "grid" (snap to cells, default), "free" (anywhere), "auto" (sorted, no saved spots).
    // The spots themselves are shell state (~/.local/state/quasar/desktop-icons.json), not a setting.
    property alias desktopArrange: data.desktopArrange
    // Terminal (apps/terminal): { fontSize, lineHeight, cursorStyle, cursorBlink, scrollback,
    // ignoreCase, confirmClose }; missing keys take the Terminal's defaults.
    property alias terminal: data.terminal
    // Files (apps/files): { view: "grid" | "list", hidden: bool, sort: "name" | "size" | "modified",
    // reversed: bool }; missing keys take Files' defaults.
    property alias files: data.files
    // Company environments: per-company look and behaviour, { id: { color, wallpaper, short,
    // autostart } }. Which companies exist is the root-owned registry (Companies), not this file.
    property alias companies: data.companies
    // Quasar AI (shell assistant + Settings › Quasar AI): { enabled, provider (ollama | ollama-cloud |
    // anthropic | openai), model: { provider: id }, perms: { apps, settings, install, files, commands },
    // plan, ready }. API keys never go here: quasar-ai keeps them in the login keyring.
    property alias ai: data.ai
    // Command Deck (phone remote): {enabled, screen, files}. Choices only; phones and keys live with deckd.
    property alias commandDeck: data.commandDeck
    // Remote desktop (VNC): {enabled, lockOnLeave}. Choices only; who may use it is root's
    // (/etc/quasar/vnc/users.json) and the keys live in ~/.local/share/quasar/vnc.
    property alias remoteDesktop: data.remoteDesktop
    // Firewall: ask (the shell's "wants to receive connections" card) when an app on this PC waits for a
    // connection the firewall stopped. What's blocked or allowed is the system's (quasar-firewall).
    property alias firewallAsk: data.firewallAsk
    // VPN / Mobile hotspot, the user's side: { vpn: { uuid, name } (the VPN last used: the Quick settings
    // tile and Settings' switch connect it), hotspot: true once a hotspot has been set up }. The profiles
    // themselves (and their secrets) are NetworkManager's.
    property alias network: data.network

    FileView {
        id: file
        path: root.path
        watchChanges: true
        blockLoading: true
        printErrors: false
        onFileChanged: reload()
        onAdapterUpdated: writeAdapter()
        onLoaded: root.loaded = true
        onLoadFailed: (error) => root._migrate = true     // first run

        JsonAdapter {
            id: data
            property int version: 1
            property int profile: -1
            property string accent: "#7AE7FF"
            property string wallpaper: "deep"
            property string wallpaperPhoto: ""
            property string wallpaperFit: "fill"
            property bool glass: true
            property bool reduceMotion: false
            // Missing ids are skipped and duplicates of one app collapse, so the terminal pin works
            // whichever id the installed foot ships (and quasar-terminal once it exists).
            property var pins: ["quasar-files", "quasar-terminal", "org.codeberg.dnkl.footclient", "footclient",
                                "firefox-esr", "quasar-store", "quasar-settings"]
            property bool focus: false
            property bool nightLight: false
            property bool clock24: false
            property bool preferSandbox: true
            property var input: ({})          // pointer/keyboard choices mirrored into labwc (Settings)
            property var displays: ({})       // layouts per set of displays, VRR, taskbars (see above)
            property string desktopArrange: "grid"
            property var terminal: ({})
            property var files: ({})
            property var companies: ({})
            property var ai: ({})
            property var commandDeck: ({})
            property var remoteDesktop: ({})
            property bool firewallAsk: true
            property var network: ({})
        }
    }

    // A photo as the wallpaper (Settings › Display, the desktop's "Set as wallpaper"). The wallpaper is a
    // copy, ~/.local/share/quasar/wallpaper/<stamp>/<name>, so moving or deleting the original (or
    // unplugging its drive) doesn't blank the desktop; only the newest copy is kept. Every pick gets a
    // new folder: an unchanged path would keep showing the old picture.
    readonly property string photoDir: (Quickshell.env("XDG_DATA_HOME") || (Quickshell.env("HOME") + "/.local/share")) + "/quasar/wallpaper"
    signal photoFailed(string path)
    function useWallpaperPhoto(path) {
        path = String(path || "")
        if (!path.startsWith("/") || photoCopy.running) return
        const stamp = String(Date.now())
        photoCopy.src = path
        photoCopy.dest = photoDir + "/" + stamp + "/" + path.slice(path.lastIndexOf("/") + 1)
        photoCopy.command = ["sh", "-c",
            'set -e; dir=$1; stamp=$2; src=$3; [ -f "$src" ] && [ -r "$src" ]; mkdir -p "$dir/$stamp"; cp -- "$src" "$dir/$stamp/"; '
            + 'for d in "$dir"/*; do [ "$d" = "$dir/$stamp" ] || rm -rf -- "$d"; done',
            "sh", photoDir, stamp, path]
        photoCopy.running = true
    }
    Process {
        id: photoCopy
        property string src: ""
        property string dest: ""
        onExited: (code) => {
            if (code !== 0) { root.photoFailed(src); return }
            data.wallpaperPhoto = dest
            data.wallpaper = "photo"
        }
    }

    // One-time migration from shell.json (same keys), then the defaults are written.
    property bool _migrate: false
    FileView {
        id: legacy
        path: root._migrate ? root.dir + "/shell.json" : ""
        blockLoading: true
        printErrors: false
        onLoaded: {
            try {
                const o = JSON.parse(text())
                for (const k of ["profile", "accent", "wallpaper", "glass", "reduceMotion", "pins", "focus", "nightLight"])
                    if (o[k] !== undefined) data[k] = o[k]
            } catch (e) { }
            root._finishMigration()
        }
        onLoadFailed: (error) => root._finishMigration()
    }
    function _finishMigration() {
        _migrate = false
        file.writeAdapter()
        loaded = true
    }
}
