#version 440
// Analytic Gaussian shadow of a rounded rectangle (after Evan Wallace, "Fast rounded rectangle shadows").
// One quad, no offscreen passes — replaces box-shadow from the mockup. Qt 6.8 has no RectangularShadow.
layout(location = 0) in vec2 qt_TexCoord0;
layout(location = 0) out vec4 fragColor;

layout(std140, binding = 0) uniform buf {
    mat4 qt_Matrix;
    float qt_Opacity;
    vec4 shadowColor;   // straight (non-premultiplied) RGBA
    vec2 itemSize;      // ShaderEffect size in px
    vec4 box;           // casting rect inside the item: x, y, w, h (px)
    float radius;       // corner radius (px)
    float sigma;        // blur sigma (px), > 0
};

vec2 erf2(vec2 x) {
    vec2 s = sign(x);
    vec2 a = abs(x);
    x = 1.0 + (0.278393 + (0.230389 + 0.078108 * (a * a)) * a) * a;
    x *= x;
    return s - s / (x * x);
}

float boxShadowX(float x, float y, float s, float corner, vec2 halfSize) {
    float delta = min(halfSize.y - corner - abs(y), 0.0);
    float curved = halfSize.x - corner + sqrt(max(0.0, corner * corner - delta * delta));
    vec2 integral = 0.5 + 0.5 * erf2((x + vec2(-curved, curved)) * (sqrt(0.5) / s));
    return integral.y - integral.x;
}

float gaussian(float x, float s) {
    return exp(-(x * x) / (2.0 * s * s)) / (2.50662827463 * s);
}

void main() {
    vec2 p = qt_TexCoord0 * itemSize;
    vec2 halfSize = box.zw * 0.5;
    vec2 point = p - (box.xy + halfSize);
    float corner = min(radius, min(halfSize.x, halfSize.y));
    float low = point.y - halfSize.y;
    float high = point.y + halfSize.y;
    float start = clamp(-3.0 * sigma, low, high);
    float end = clamp(3.0 * sigma, low, high);
    float stepY = (end - start) / 4.0;
    float y = start + stepY * 0.5;
    float value = 0.0;
    for (int i = 0; i < 4; i++) {
        value += boxShadowX(point.x, point.y - y, sigma, corner, halfSize) * gaussian(y, sigma) * stepY;
        y += stepY;
    }
    float a = clamp(value, 0.0, 1.0) * shadowColor.a * qt_Opacity;
    fragColor = vec4(shadowColor.rgb * a, a);
}
