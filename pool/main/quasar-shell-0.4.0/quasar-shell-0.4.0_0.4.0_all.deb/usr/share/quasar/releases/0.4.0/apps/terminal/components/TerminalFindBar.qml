import QtQuick
import Quasar

// Find in the terminal's output (Ctrl+Shift+F), top right of the pane: typing searches from the
// newest line up; Enter finds the next older match, Shift+Enter the next newer; Esc closes.
// Matches are selected in the terminal. Pure view: `search()` asks, `found` is the answer.
Rectangle {
    id: root
    property bool open: false
    property bool found: true
    property bool caseSensitive: false
    readonly property alias text: input.text
    signal search(string text, bool backwards, bool caseSensitive)
    signal closed()

    function show() {
        open = true
        input.forceActiveFocus()
        input.selectAll()
    }

    visible: open
    width: 352
    height: 44
    radius: 12
    color: Theme.menuBg
    border.width: 1
    border.color: Theme.white(0.1)
    Accessible.role: Accessible.Dialog
    Accessible.name: "Find"

    Rectangle {
        id: box
        x: 6
        anchors.verticalCenter: parent.verticalCenter
        width: parent.width - 6 - buttons.width - 10
        height: 32
        radius: 9
        color: Qt.rgba(0, 0, 0, 0.3)
        border.width: 1
        border.color: !root.found && input.text !== "" ? Theme.alpha(Theme.danger, 0.7)
                    : input.activeFocus ? Theme.accentLine : Theme.white(0.1)
        QIcon {
            id: glyph
            x: 10
            anchors.verticalCenter: parent.verticalCenter
            path: Icons.search; size: 13; strokeWidth: 2
            color: Theme.textDim
        }
        TextInput {
            id: input
            anchors { left: glyph.right; leftMargin: 8; right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter }
            font.family: Theme.fontUi; font.pointSize: Theme.pt(13)
            color: Theme.text
            selectionColor: Theme.alpha(Theme.accent, 0.35)
            selectedTextColor: Theme.text
            selectByMouse: true
            clip: true
            Accessible.role: Accessible.EditableText
            Accessible.name: "Find"
            onTextEdited: root.search(text, true, root.caseSensitive)
            Keys.onPressed: (e) => {
                if (e.key === Qt.Key_Return || e.key === Qt.Key_Enter) {
                    root.search(text, !(e.modifiers & Qt.ShiftModifier), root.caseSensitive)
                    e.accepted = true
                } else if (e.key === Qt.Key_Escape) {
                    root.closed()
                    e.accepted = true
                }
            }
            Text {
                anchors.fill: parent
                verticalAlignment: Text.AlignVCenter
                visible: input.text === ""
                text: "Find"
                font: input.font
                color: Theme.textFaint
            }
        }
    }

    Row {
        id: buttons
        anchors { right: parent.right; rightMargin: 6; verticalCenter: parent.verticalCenter }
        spacing: 2
        Pressable {
            width: 32; height: 30; radius: 8; kind: "hov"
            accessibleName: "Match case"
            color: root.caseSensitive ? Theme.white(0.1) : "transparent"
            onClicked: { root.caseSensitive = !root.caseSensitive; input.forceActiveFocus(); root.search(input.text, true, root.caseSensitive) }
            Text {
                anchors.centerIn: parent
                text: "Aa"
                font.family: Theme.fontUi; font.pixelSize: 12; font.weight: Font.DemiBold
                color: root.caseSensitive ? Theme.accent : Theme.textMuted
            }
        }
        Pressable {
            width: 32; height: 30; radius: 8; kind: "hov"
            accessibleName: "Previous match (older)"
            onClicked: { input.forceActiveFocus(); root.search(input.text, true, root.caseSensitive) }
            QIcon { anchors.centerIn: parent; path: Icons.up; size: 14; strokeWidth: 2; color: Theme.textMuted }
        }
        Pressable {
            width: 32; height: 30; radius: 8; kind: "hov"
            accessibleName: "Next match (newer)"
            onClicked: { input.forceActiveFocus(); root.search(input.text, false, root.caseSensitive) }
            QIcon { anchors.centerIn: parent; path: Icons.down; size: 14; strokeWidth: 2; color: Theme.textMuted }
        }
        Pressable {
            width: 32; height: 30; radius: 8; kind: "hov"
            accessibleName: "Close find"
            onClicked: root.closed()
            QIcon { anchors.centerIn: parent; path: Icons.x; size: 13; strokeWidth: 2.2; color: Theme.textMuted }
        }
    }
}
