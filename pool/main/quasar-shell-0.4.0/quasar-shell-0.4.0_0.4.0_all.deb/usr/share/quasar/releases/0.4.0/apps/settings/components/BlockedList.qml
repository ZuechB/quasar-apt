import QtQuick
import Quasar

// Settings › Firewall › Advanced › "Recently blocked": connections the firewall stopped since this PC
// started (quasar-netguard keeps them in memory only; nothing is written to disk). Goes inside a
// Dialog. Pure view.
//   entries: [{ time (seconds since 1970), from (address), port, proto: "tcp" | "udp",
//               app: "" | the app that was waiting for it, network: "" | the network's name }]
Column {
    id: root
    property var entries: []
    property bool clock24: false

    function when(t) {
        const d = new Date((t || 0) * 1000)
        return Qt.formatTime(d, root.clock24 ? "HH:mm" : "h:mm AP")
    }

    width: parent ? parent.width : 400
    spacing: 8

    Text {
        visible: !root.entries.length
        width: parent.width
        wrapMode: Text.Wrap
        text: "Nothing was blocked since this PC started."
        font.family: Theme.fontUi; font.pointSize: Theme.pt(13)
        color: Theme.textDim
    }
    ListView {
        visible: root.entries.length > 0
        width: parent.width
        height: Math.min(contentHeight, 340)
        clip: true
        boundsBehavior: Flickable.StopAtBounds
        model: root.entries
        delegate: Item {
            required property var modelData
            required property int index
            width: ListView.view.width
            height: 52
            Rectangle {
                visible: index > 0
                width: parent.width; height: 1
                color: Theme.white(0.05)
            }
            QIcon {
                x: 4
                anchors.verticalCenter: parent.verticalCenter
                path: Icons.shield; size: 16; strokeWidth: 1.9
                color: Theme.textMuted
            }
            Column {
                anchors { left: parent.left; leftMargin: 32; right: time.left; rightMargin: 10; verticalCenter: parent.verticalCenter }
                spacing: 2
                Text {
                    width: parent.width
                    elide: Text.ElideRight
                    text: (modelData.app ? modelData.app + " · port " : "Port ") + modelData.port + " (" + String(modelData.proto || "").toUpperCase() + ")"
                    font.family: Theme.fontUi; font.pixelSize: 14; font.weight: Font.Medium
                    color: Theme.text
                }
                Text {
                    width: parent.width
                    elide: Text.ElideRight
                    text: "From " + modelData.from + (modelData.network ? " on " + modelData.network : "")
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(12)
                    color: Theme.textDim
                }
            }
            Text {
                id: time
                anchors { right: parent.right; rightMargin: 4; verticalCenter: parent.verticalCenter }
                text: root.when(modelData.time)
                font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
                color: Theme.textMuted
            }
        }
    }
}
