import QtQuick
import Quickshell
import Quickshell.Io
import Quickshell.Services.Mpris

// Media keys → the player that's playing, else the one that played last (MPRIS; browsers, Spotify, mpv…).
// Keyboards' play/pause/next/previous keys and Bluetooth headset buttons both arrive here: BlueZ turns a
// headset's AVRCP commands into key presses. labwc binds XF86AudioPlay/Pause/Next/Prev/Stop to
// `qs ipc call media …` (linux/session/labwc/rc.xml). Event-driven: nothing runs until a key is pressed.
Item {
    id: media
    visible: false

    readonly property var players: Mpris.players.values.filter(p => p && p.canControl)
    readonly property var playing: players.find(p => p.isPlaying) || null
    property string lastPlayed: ""          // dbusName of the player that played most recently
    onPlayingChanged: if (playing) lastPlayed = playing.dbusName
    readonly property var current: playing || players.find(p => p.dbusName === lastPlayed) || players[0] || null

    // A keyboard's single play/pause key sends XF86AudioPlay, so "play" toggles.
    function playPause() {
        const p = current
        if (!p) return
        if (p.canTogglePlaying) p.togglePlaying()
        else if (p.isPlaying && p.canPause) p.pause()
        else if (p.canPlay) p.play()
    }
    function pause() { const p = current; if (p && p.canPause) p.pause() }
    function next() { const p = current; if (p && p.canGoNext) p.next() }
    function previous() { const p = current; if (p && p.canGoPrevious) p.previous() }
    function stop() { const p = current; if (p) p.stop() }

    IpcHandler {
        target: "media"
        function playPause(): void { media.playPause() }
        function pause(): void { media.pause() }
        function next(): void { media.next() }
        function previous(): void { media.previous() }
        function stop(): void { media.stop() }
        // "<identity> playing|paused|stopped", or "none" (tests, scripts)
        function state(): string {
            const p = media.current
            return p ? p.identity + " " + (p.isPlaying ? "playing" : "paused") : "none"
        }
    }
}
