.pragma library

// Turn a failed install/remove/update into one plain sentence + the raw log for "Details".
// Looks at the WHOLE log (case-insensitive), not just the last line.
//   describe(log, exitCode, app, action, live) -> { tone, title, message, details } | null (= success)
function describe(log, code, app, action, live) {
    const text = log || ""
    const L = text.toLowerCase()
    const name = app ? app.name : "The app"
    // Where it comes from: Flathub, Debian, a vendor feed ("Docker's package feed"), or for developer
    // tools the project's own server ("nodejs.org", "go.dev" …).
    const source = !app ? "Flathub"
                 : app.source === "debian" ? (app.sourceLabel || "Debian")
                 : app.source === "debfile" ? "Debian's servers"
                 : app.source === "mise" ? (app.from || "its download server").replace(/ \(.*$/, "")
                 : "Flathub"
    const verb = action === "remove" ? "removed" : action === "update" ? "updated" : action === "default" ? "switched" : "installed"
    let title = name + " couldn't be " + verb
    let message
    let actionText = ""

    // A package from a file (quasar-debfile): its refusals are already plain sentences, after a word
    // (`ERROR files: Its files would replace …`). Checked first: none of them is a success.
    if (app && app.source === "debfile" && code !== 126 && code !== 127) {
        const m = /(?:^|\n)ERROR ([a-z]+): ([^\n]+)/.exec(text)
        if (m && m[1] !== "install") {
            const word = m[1]
            title = word === "changed" ? name + " changed since you opened it" : name + " wasn't " + verb
            return { tone: "error", title: title, message: m[2], details: text, actionText: "" }
        }
    }

    if (/already installed/.test(L) && action !== "remove")
        return null
    if (code === 126) {
        title = name + " wasn't " + verb
        message = "The password prompt was closed, so nothing changed."
    } else if (code === 127 && /not authorized|authentication|polkit|agent/.test(L)) {
        message = "Your account isn't allowed to change apps for everyone on this PC. Ask an administrator."
    } else if (/needs quasar installed on a disk/.test(L)) {
        title = name + " needs Quasar installed on this PC"
        message = "It can't run from the installer USB, which keeps everything in memory. Install Quasar first, then get " + name + " again."
        actionText = "Install Quasar"
    } else if (/mise is not installed/.test(L)) {
        message = "Developer tools need mise, which comes with Quasar but is missing on this PC."
    } else if (/no space left|enospc|not enough disk space|not enough space|insufficient space/.test(L)) {
        message = "There isn't enough free space." + (live ? " You're running from the installer USB, where apps are kept in memory: install Quasar to get more room." : " Remove apps or files you don't need and try again.")
    } else if (/rate limit|api\.github\.com.*\b403\b|\b403\b.*api\.github\.com/.test(L)) {
        message = "GitHub is limiting downloads from your network right now. Try again in an hour."
    } else if (/could not resolve|temporary failure in name resolution|unable to connect|network is unreachable|couldn't connect|connection refused|timed out|timeout was reached|failed to connect|unable to fetch|error sending request|dns error/.test(L)) {
        message = "Quasar can't reach " + source + ". Check that you're online and try again."
    } else if (/not valid yet|certificate.*(expired|not yet valid)|is not yet valid/.test(L)) {
        message = "Your PC's clock is wrong, so secure downloads are refused. Set the time in Settings › Date & Language, then try again."
    } else if (/could not get lock|unable to acquire the dpkg frontend lock|is another process using it/.test(L)) {
        message = "Another install is still running. Try again in a moment."
    } else if (/failed to execute command: git|git: not found|"git": executable file not found/.test(L)) {
        message = name + " needs Build tools (it uses git). Get Build tools from the Store, then try again."
    } else if (/linker [`'"]?cc[`'"]? not found|error: linker|cc: not found|command not found: (cc|gcc)/.test(L)) {
        message = name + " needs the C build tools. Get Build tools from the Store, then try again."
    } else if (/checksum|signature (verification )?failed|attestation/.test(L) && app && app.source === "mise") {
        message = "The download from " + source + " didn't pass its integrity check, so it wasn't installed. Try again later."
    } else if (/no versions? (found|matching)|version .* not found|no matching version/.test(L)) {
        message = "That version of " + name + " isn't available from " + source + "."
    } else if (/nothing matches|no remote refs found|unable to locate package|has no installation candidate|not found|404/.test(L)) {
        message = name + " isn't available from " + source + " right now."
    } else if (/is not a store package/.test(L)) {
        message = name + " can't be managed by the Store."
    } else if (/setting up .* failed/.test(L)) {
        message = name + " was installed but couldn't be set up. The details below show what went wrong; removing it and getting it again usually helps."
    } else {
        message = (app && app.source === "mise" ? "mise" : "The installer") + " stopped with an error (code " + code + "). The details below show what it reported."
    }
    return { tone: "error", title: title, message: message, details: text, actionText: actionText }
}
