import QtQuick
import QtQuick.Shapes

// Install progress ring (template: 28x28 viewBox, r=11, stroke 3, white .12 track, round-capped
// accent arc from 12 o'clock; the arc eases between updates like the CSS dashoffset transition).
Item {
    id: root
    property real value: 0                 // 0..1
    property real size: 28
    property color color: Theme.accent
    property color trackColor: Theme.white(0.12)
    property real _shown: Math.max(0, Math.min(1, value))
    Behavior on _shown { NumberAnimation { duration: Motion.dur(200) } }

    // Ring thickness; the template's is size*3/28. A thinner ring keeps the same outer edge.
    property real thickness: size * 3 / 28
    readonly property real _stroke: thickness
    readonly property real _r: size * 12.5 / 28 - thickness / 2

    implicitWidth: size
    implicitHeight: size
    Accessible.role: Accessible.ProgressBar
    Accessible.name: Math.round(root.value * 100) + "%"

    Shape {
        anchors.fill: parent
        layer.enabled: Theme.softwareRender      // clips when scrolled away (see Theme.softwareRender)
        ShapePath {
            strokeColor: root.trackColor
            strokeWidth: root._stroke
            fillColor: "transparent"
            PathAngleArc { centerX: root.size / 2; centerY: root.size / 2; radiusX: root._r; radiusY: root._r; startAngle: 0; sweepAngle: 360 }
        }
        ShapePath {
            strokeColor: root.color
            strokeWidth: root._stroke
            fillColor: "transparent"
            capStyle: ShapePath.RoundCap
            PathAngleArc {
                centerX: root.size / 2; centerY: root.size / 2; radiusX: root._r; radiusY: root._r
                startAngle: -90
                sweepAngle: Math.max(0.5, 360 * root._shown)
            }
        }
    }
}
