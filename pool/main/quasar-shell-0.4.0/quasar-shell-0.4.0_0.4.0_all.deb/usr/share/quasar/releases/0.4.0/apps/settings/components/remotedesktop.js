// Settings > Users & Accounts > Remote desktop (VNC): your other computers see and use this PC's screen.
// Pure, so the Settings app (services/RemoteDesktop.qml) and the design preview share it.
//   st:  { status: vnc-run's $XDG_RUNTIME_DIR/quasar/vnc.json
//                  { state, address, port, user, host, network, fingerprints: { tls, rsa }, problem },
//          admin: quasar-vnc-admin status { enabled: [uid], installed, live } (null while loading),
//          viewers: [{ id, address, username }] }
//   ctx: { enabled: Settings.remoteDesktop.enabled, lockOnLeave, uid, me, busy: row key, progress, phase,
//          size: download bytes the first time (system.json), autologin: { user, locked },
//          connection: the network this PC is on now { uuid, name, state } (firewall-net.json) or null,
//          home: that network as a saved home network { uuid, name, vpn } or null, live, icons, theme }
// Keys: "rd:on", "rd:continue", "rd:home", "rd:retry", "rd:viewer:<id>", "rd:lockleave", "rd:auto", "rd:vpn",
// "rd:remove"; on Users & Accounts "rd:open". Everyone should understand every line: no jargon.
.pragma library

function mb(bytes) { return bytes > 0 ? Math.max(1, Math.round(bytes / 1e6)) + " MB" : "" }

function allowed(st, ctx) {
    return !!(st && st.admin && st.admin.installed && (st.admin.enabled || []).indexOf(ctx.uid) >= 0)
}

// What the switch's line says, and which extra row goes with it.
function state(st, ctx) {
    var s = (st && st.status) || {}
    if (ctx.live || (st && st.admin && st.admin.live)) return "live"
    if (ctx.busy === "rd:on" || ctx.busy === "rd:continue") return "installing"
    if (!ctx.enabled) return "off"
    if (st && st.admin && !allowed(st, ctx)) return "admin"
    switch (s.state) {
    case "listening": return (st.viewers || []).length ? "connected" : "ready"
    case "not-home": return "nothome"
    case "error": return "error"
    case "not-enabled": case "not-installed": return "admin"
    default: return "starting"
    }
}

function entryGroups(st, ctx) {
    var k = state(st, ctx)
    var on = k === "ready" || k === "connected"
    return [{ label: "Remote desktop", rows: [
        { key: "rd:open", label: "Remote desktop", glyph: ctx.icons.monitor, trailing: "chevron",
          value: k === "live" || k === "off" ? "Off" : on ? "On" : k === "nothome" ? "Not at home" : "Starting…",
          sub: k === "connected" ? "Another computer is using this screen now"
             : "See and use this PC's screen from your other computers" }] }]
}

function groups(st, ctx) {
    var icons = ctx.icons
    var k = state(st, ctx)
    var s = (st && st.status) || {}
    if (k === "live")
        return [{ label: "Remote desktop", rows: [
            { key: "rd:on", label: "Remote desktop", glyph: icons.monitor, trailing: "value", value: "Off",
              sub: "Install Quasar on a disk to see and use this PC from your other computers" }] }]

    var first = !(st && st.admin && st.admin.installed)
    var subs = {
        off: "See and use this PC's screen from your other computers at home"
             + (first && ctx.size ? "  ·  downloads about " + mb(ctx.size) + " the first time" : ""),
        installing: (ctx.phase || "Setting up") + "…" + (ctx.progress >= 0 ? "  " + ctx.progress + "%" : ""),
        admin: "An administrator needs to allow it on this PC",
        starting: "Starting…",
        nothome: (ctx.connection ? ctx.connection.name + " isn't one of your home networks" : "Not connected to a network")
                 + ". Remote desktop answers only at home.",
        error: s.problem || "Remote desktop stopped",
        ready: "On  ·  your home networks only" + (s.network ? "  ·  " + s.network : ""),
        connected: "On  ·  another computer is using this screen now"
    }
    var main = [{ key: "rd:on", label: "Remote desktop", glyph: icons.monitor, trailing: "toggle",
                  checked: k !== "off", busy: k === "installing", sub: subs[k] }]
    if (k === "admin")
        main.push({ key: "rd:continue", label: "Allow remote desktop", glyph: icons.shield, trailing: "button", value: "Continue",
                    sub: "Asks for an administrator's password once" + (first && ctx.size ? ", then downloads about " + mb(ctx.size) : "") })
    if (k === "nothome" && ctx.connection && ctx.connection.uuid && ctx.connection.state === "public")
        main.push({ key: "rd:home", label: "Is " + ctx.connection.name + " your home network?", glyph: icons.home,
                    trailing: "button", value: "It's my home", busy: ctx.busy === "rd:home",
                    sub: "Then your devices on it can reach the apps you allow, Remote desktop too" })
    if (k === "error")
        main.push({ key: "rd:retry", label: "Start it again", glyph: icons.refresh, trailing: "button", value: "Try again" })
    if (k === "ready" || k === "connected") {
        main.push({ key: "rd:address", label: "Connect to", glyph: icons.link, trailing: "value", value: s.address || "",
                    sub: "Type this address in a VNC viewer on your other computer" + (s.port && s.port !== 5900 ? " (port " + s.port + ")" : "") })
        main.push({ key: "rd:signin", label: "Sign in with", glyph: icons.user, trailing: "value", value: s.user || ctx.me,
                    sub: "Your account name and password, the same as on this PC" })
        var fp = s.fingerprints || {}
        if (fp.tls || fp.rsa)
            main.push({ key: "rd:fp", label: "Check the first time you connect", glyph: icons.shield, trailing: "none",
                        sub: (fp.tls ? "TigerVNC and Remmina show:\n" + fp.tls : "")
                           + (fp.tls && fp.rsa ? "\n" : "") + (fp.rsa ? "Over RSA-AES (RealVNC Viewer):  " + fp.rsa : "") })
    }
    var out = [{ label: "Remote desktop", rows: main }]

    var viewers = (st && st.viewers) || []
    if (viewers.length)
        out.push({ label: "Connected now", rows: viewers.map(function (v) {
            var key = "rd:viewer:" + v.id
            return { key: key, label: v.address || "A computer", glyph: icons.monitor, trailing: "button", value: "Disconnect",
                     busy: ctx.busy === key, sub: v.username ? "Signed in as " + v.username : "Signed in" }
        }) })

    if (k === "off" || !ctx.enabled) return out

    // When nobody is at this PC (a server): it locks behind you, and comes back by itself after a restart.
    var a = ctx.autologin || {}
    var mine = a.user === ctx.me, autoOn = mine && a.locked
    out.push({ label: "When you're away", rows: [
        { key: "rd:lockleave", label: "Lock this PC when the last viewer leaves", glyph: icons.lock, trailing: "toggle",
          checked: ctx.lockOnLeave !== false,
          sub: "So this PC's own screen doesn't stay open after you disconnect" },
        { key: "rd:auto", label: "Sign in automatically after a restart", glyph: icons.refresh, trailing: "toggle",
          checked: autoOn, busy: ctx.busy === "rd:auto",
          sub: autoOn ? "After updates restart this PC, remote desktop is back. This screen shows only the lock screen."
             : mine ? "You're signed in automatically, but the screen isn't locked: turn this on to lock it right away"
             : a.user ? a.user + " is signed in automatically now: turning this on signs you in instead, locked"
             : "Without it, remote desktop waits until someone signs in at this PC after a restart" },
        { label: "No display connected?", glyph: icons.monitor, trailing: "none",
          sub: "Remote desktop still works: Quasar adds a virtual display, starting the next time you sign in" }] })

    var h = ctx.home
    out.push({ label: "From outside your home", rows: [
        h ? { key: "rd:vpn", label: "Through " + h.name + "'s router VPN", glyph: icons.globe, trailing: "button",
              value: (h.vpn || []).length ? "Change…" : "Set up…",
              sub: (h.vpn || []).length ? "Connect to the VPN, then use " + (s.address || "this PC's address") + " as at home  ·  "
                                          + h.vpn.join(", ")
                                        : "Connect to your router's VPN first (WireGuard or UniFi Teleport). Nothing is opened to the internet." }
          : { label: "Through your router's VPN", glyph: icons.globe, trailing: "none",
              sub: "Connect this PC to your home network to set it up. Nothing is opened to the internet." }] })

    out.push({ label: "Viewer apps", rows: [
        { label: "On your other computer", glyph: icons.download, trailing: "none",
          sub: "TigerVNC or RealVNC Viewer (Windows, Mac), Remmina (Linux), bVNC (phones)" }] })

    if (st && st.admin && st.admin.installed)
        out.push({ label: "Remove", rows: [
            { key: "rd:remove", label: "Remove remote desktop from this PC", glyph: icons.trash, trailing: "button", value: "Remove…",
              busy: ctx.busy === "rd:remove", sub: "Turns it off for every account and removes it. You can add it again later." }] })
    return out
}

function confirmRemove() {
    return { key: "rd:remove", title: "Remove remote desktop?", button: "Remove", danger: true,
             message: "Nobody can see or use this PC's screen from another computer any more, and computers connected now are "
                    + "disconnected. You can turn it on again later; it downloads again then." }
}
