import QtQuick
import Quickshell
import Quickshell.Io
import Quasar

// Restart and Shut down wait for installs a restart would break. Root helpers hold a logind "block"
// inhibitor while they do such work (/usr/libexec/quasar/hold-restart: a driver install, updates, the
// Store's system packages, a snapshot restore) and name it ("Installing NVIDIA's driver"); unattended-
// upgrades only holds dpkg's lock, which update-state.json reports as "running".
// Before, nothing checked: the owner restarted in the middle of the NVIDIA install and got a black screen.
//
// check(cb) asks logind (busctl ListInhibitors) only when needed: when the power menu opens, when a restart
// is asked for, and every 5 s while one waits. request() is what the power menu and Command Deck call:
// nothing installing → it goes ahead; otherwise `asking` holds the reasons for the shell's dialog, whose
// buttons are whenDone() (restart once nothing installs any more), anyway() (logind asks for an
// administrator's password through polkit's ignore-inhibit actions) and cancel().
Item {
    id: root
    visible: false
    required property var sys               // services/SystemControls.qml
    signal toast(var t)

    property var reasons: []                // what's installing right now (the last check)
    property var asking: null               // { action: "reboot" | "poweroff", reasons: [...] }: the dialog
    property string waiting: ""             // a restart or shutdown that goes ahead when the installs are over
    // The power menu's hint beside Restart / Shut down (the menu is 236 px: the dialog names what installs).
    readonly property string hint: reasons.length ? "Installing…" : ""
    property bool updatesRunning: false     // update-state.json: someone holds dpkg's lock
    property var queue: []

    function verb(action) { return action === "poweroff" ? "shut down" : "restart" }

    function check(cb) {
        if (cb) queue = queue.concat([cb])
        if (!probe.running) probe.running = true
    }
    // The power menu's Restart / Shut down (and Command Deck's): done(true) when it goes ahead now.
    function request(action, done) {
        check(r => {
            if (r.length === 0) { perform(action); if (done) done(true, r) }
            else { if (!done) asking = { action: action, reasons: r }; else done(false, r) }
        })
    }
    function perform(action) {
        waiting = ""
        asking = null
        if (action === "poweroff") sys.poweroff()
        else sys.reboot()
    }
    function whenDone(action) {
        asking = null
        waiting = action
        toast({ title: action === "poweroff" ? "Shuts down when the install is done" : "Restarts when the install is done",
                sub: "Keep working meanwhile. The power menu can cancel it.", glyph: Icons.refresh, hue: Theme.accent })
    }
    function anyway(action) {
        asking = null
        waiting = ""
        // -i: don't stop at the inhibitor here; logind still asks for an administrator's password.
        Quickshell.execDetached(["systemctl", action === "poweroff" ? "poweroff" : "reboot", "-i"])
    }
    function cancel() { asking = null }
    function cancelWaiting() { waiting = "" }

    Timer {
        interval: 5000
        repeat: true
        running: root.waiting !== ""
        onTriggered: root.check(r => { if (r.length === 0 && root.waiting !== "") root.perform(root.waiting) })
    }

    Process {
        id: probe
        command: ["busctl", "--system", "--json=short", "call", "org.freedesktop.login1", "/org/freedesktop/login1",
                  "org.freedesktop.login1.Manager", "ListInhibitors"]
        stdout: StdioCollector {
            onStreamFinished: {
                let r = []
                try {
                    // a(ssssuu): what, who, why, mode, uid, pid
                    const rows = JSON.parse(text).data[0] || []
                    r = rows.filter(x => x[3] === "block" && String(x[0]).split(":").indexOf("shutdown") >= 0)
                            .map(x => x[2] || x[1])
                } catch (e) { }
                if (root.updatesRunning) r.push("Installing updates")
                r = r.filter((x, i) => r.indexOf(x) === i)
                root.reasons = r
                const q = root.queue
                root.queue = []
                for (const cb of q) cb(r)
            }
        }
    }
    FileView {
        path: Quickshell.env("QUASAR_UPDATE_STATE") || "/run/quasar/update-state.json"
        watchChanges: true
        printErrors: false
        onFileChanged: reload()
        onLoaded: { try { root.updatesRunning = !!JSON.parse(text()).running } catch (e) { } }
    }
}
