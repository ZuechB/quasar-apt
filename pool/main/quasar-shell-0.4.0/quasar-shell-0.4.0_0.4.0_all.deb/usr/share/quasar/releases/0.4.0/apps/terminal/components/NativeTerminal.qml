import QtQuick
import Quasar.Native

// The real terminal engine (C++, native/quasar-native). TerminalPane creates it from the Component
// the app passes in, so the window also renders in the design preview, where MockTerminal stands in.
Terminal { }
