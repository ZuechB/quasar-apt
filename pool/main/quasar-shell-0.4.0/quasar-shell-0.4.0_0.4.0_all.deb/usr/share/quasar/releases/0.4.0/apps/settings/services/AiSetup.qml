import QtQuick
import Quickshell
import Quickshell.Io
import Quasar
import Quasar.Services
import "../components/ai.js" as Ai

// Settings › Quasar AI: where the assistant runs (Ollama on this PC, Ollama Cloud, Claude, ChatGPT), the
// API key, the model, the on-device engine and its models, and what the assistant may do.
//   /usr/libexec/quasar/quasar-ai (as the user): engine status, model lists, downloads, keys (on stdin)
//   /usr/libexec/quasar/quasar-ollama (pkexec, org.quasar.ai): install / update / remove the engine
// Settings.ai holds only choices; keys stay in the login keyring. Nothing here touches the network
// unless the user presses something (a cloud model list, a key check, a download, Check for updates).
Scope {
    id: root
    property bool active: false                 // the Quasar AI page is shown
    signal notify(var banner)
    signal pick(string title, var options, string current, var done)
    property var ask: null                      // { title, message, buttons: [{ text, key, primary, danger }] }
    property var form: null                     // { kind: "key" | "model", provider, title, message, placeholder }

    readonly property string helperPath: Quickshell.env("QUASAR_AI") || "/usr/libexec/quasar/quasar-ai"
    readonly property var cfg: Ai.cfg(Settings.ai)
    property var engine: ({})
    property var local: []
    property var keys: ({})
    property var pulls: ({})
    property string pulling: ""
    property var engineJob: null
    property string latest: ""
    property string busy: ""                    // row key waiting for an answer
    property var catalog: []
    property var cloudModels: ({})

    readonly property var st: ({ ai: Settings.ai, engine: engine, local: local, keys: keys, pulls: pulls,
                                    engineJob: engineJob, latest: latest, busy: busy, catalog: catalog })
    readonly property var ctx: ({ icons: Icons, theme: Theme })
    readonly property var groups: Ai.groups(st, ctx)
    readonly property var hero: Ai.hero(st, ctx)

    // ---- settings.json ---------------------------------------------------------------------------
    function patch(p) { Settings.ai = Object.assign({}, Settings.ai || {}, p) }
    function setModel(pid, id) {
        const m = Object.assign({}, (Settings.ai || {}).model || {})
        m[pid] = id
        patch({ model: m })
    }
    function setProvider(pid) {
        patch({ provider: pid })
        if (Ai.PROVIDERS[pid].cloud) {
            keyStatus(pid)
            if (pid === "anthropic" && !cfg.model.anthropic) setModel(pid, "claude-sonnet-5-5")
        } else if (engine.installed) listLocal()
    }

    onActiveChanged: if (active) refresh()
    function refresh() {
        engineCmd.run([helperPath, "engine"])
        if (cfg.provider && Ai.PROVIDERS[cfg.provider].cloud) keyStatus(cfg.provider)
    }
    function keyStatus(pid) { if (!keyCmd.running) { keyCmd.verb = "status"; keyCmd.run([helperPath, "key", "status", pid]) } }
    function listLocal() { if (!listCmd.running) listCmd.run([helperPath, "models", "ollama"]) }

    // ---- what the page's buttons do ---------------------------------------------------------------
    function chooseProvider() {
        pick("Where should Quasar AI run?", Ai.ORDER.map(k => ({ key: k, label: Ai.PROVIDERS[k].long, sub: Ai.PROVIDERS[k].sub })),
             cfg.provider, (k) => root.setProvider(k))
    }
    function heroActivated() {
        const h = hero
        if (!h || !h.button) return
        if (h.button === "Turn on") patch({ enabled: true })
        else if (h.button === "Set up") chooseProvider()
        else if (h.button === "Install engine") installEngine()
        else if (h.button === "Add API key") openKeyForm(cfg.provider)
        else if (h.button === "Try it") Quickshell.execDetached(["qs", "--path", "/usr/share/quasar/shell", "ipc", "call", "assistant", "toggle"])
    }
    function openKeyForm(pid) {
        const p = Ai.PROVIDERS[pid]
        const k = keys[pid] || {}
        form = { kind: "key", provider: pid, title: (k.set ? "Change your " : "Add your ") + p.label + " API key",
                 message: "Create one at " + p.keyUrl + ". Quasar checks it once with " + p.company
                          + ", then keeps it in your login keyring. Requests are billed to your " + p.company + " account.",
                 placeholder: pid === "anthropic" ? "sk-ant-…" : pid === "openai" ? "sk-…" : "Paste the key", canRemove: !!k.set }
    }
    function submitForm(text) {
        const f = form
        form = null
        if (!f) return
        if (f.kind === "key") {
            busy = "ai:key"
            keyCmd.verb = "set"
            keyCmd.pid = f.provider
            keyCmd.run([helperPath, "key", "set", f.provider], undefined, text.trim() + "\n")
        } else if (f.kind === "model") pull(text.trim())
    }
    function removeKey() {
        const f = form
        form = null
        if (!f) return
        keyCmd.verb = "clear"
        keyCmd.pid = f.provider
        keyCmd.run([helperPath, "key", "clear", f.provider])
        setModel(f.provider, "")
    }

    function activate(key) {
        if (key === "ai:provider") chooseProvider()
        else if (key === "ai:key") openKeyForm(cfg.provider)
        else if (key === "ai:model") chooseModel()
        else if (key === "ai:engine") { if (engine.installed) confirmRemove(); else installEngine() }
        else if (key === "ai:update") {
            if (latest && latest !== engine.version) runEngine("update")
            else { busy = "ai:update"; latestCmd.run([helperPath, "runtime-latest"]) }
        }
        else if (key.startsWith("ai:local:")) localMenu(key.slice(9))
        else if (key.startsWith("ai:get:")) {
            const id = key.slice(7)
            if (pulls[id]) pullCmd.cancel(); else pull(id)
        }
        else if (key === "ai:more")
            pick("Suggested models", Ai.ranked(catalog, engine).map(x => ({ key: x.m.id, label: x.m.name + "  ·  " + Ai.gbOf(x.m.sizeGB), sub: x.f.note })),
                 "", (k) => root.pull(k))
        else if (key === "ai:other")
            form = { kind: "model", title: "Download another model", placeholder: "e.g. mistral-small:24b",
                     message: "Any model from ollama.com/library. Only models with tool support can act on your PC; others can still answer questions." }
    }
    function toggle(key) {
        if (key.startsWith("ai:perm:")) {
            const p = key.slice(8)
            const perms = Object.assign({}, (Settings.ai || {}).perms || {})
            perms[p] = !cfg.perms[p]
            patch({ perms: perms })
        } else if (key === "ai:plan") patch({ plan: !cfg.plan })
        else if (key === "ai:enabled") patch({ enabled: !cfg.enabled })
    }

    function chooseModel() {
        const pid = cfg.provider
        if (!pid) return chooseProvider()
        if (pid === "ollama") {
            if (!local.length) { notify({ tone: "info", title: "No models on this PC yet", message: "Download one under Get models." }); return }
            pick("Model", local.map(m => ({ key: m.id, label: Ai.modelName(m.id, catalog), sub: Ai.gb(m.size) })), cfg.model.ollama || "",
                 (k) => root.setModel("ollama", k))
            return
        }
        if (!(keys[pid] || {}).set) { openKeyForm(pid); return }
        if (pid === "anthropic" && !cloudModels.anthropic) {
            pick("Model", Ai.CLAUDE_MODELS, cfg.model.anthropic || "", (k) => root.setModel("anthropic", k))
            return
        }
        if (cloudModels[pid]) { showCloudModels(pid); return }
        busy = "ai:model"
        modelsCmd.pid = pid
        modelsCmd.run([helperPath, "models", pid])
    }
    function showCloudModels(pid) {
        pick("Model", cloudModels[pid].map(m => ({ key: m.id, label: m.name || m.id, sub: m.name && m.name !== m.id ? m.id : "" })),
             cfg.model[pid] || "", (k) => root.setModel(pid, k))
    }
    function localMenu(id) {
        const inUse = cfg.provider === "ollama" && cfg.model.ollama === id
        pick(Ai.modelName(id, catalog), (inUse ? [] : [{ key: "use", label: "Use this model" }]).concat([{ key: "delete", label: "Delete from this PC", sub: "Frees its disk space" }]),
             "", (k) => {
                 if (k === "use") { root.setModel("ollama", id); if (root.cfg.provider !== "ollama") root.patch({ provider: "ollama" }) }
                 else root.ask = { title: "Delete " + Ai.modelName(id, root.catalog) + "?", message: "You can download it again later.",
                                   buttons: [{ text: "Delete", key: "delete:" + id, danger: true }] }
             })
    }
    function confirmRemove() {
        ask = { title: "Remove the on-device engine?",
                message: "Quasar AI stops working on this PC until you install it again. Keep the models to skip their downloads next time.",
                buttons: [{ text: "Remove all", key: "remove:purge", danger: true }, { text: "Keep models", key: "remove:keep", primary: true }] }
    }
    function answer(key) {
        ask = null
        if (key.startsWith("delete:")) {
            const id = key.slice(7)
            delCmd.run([helperPath, "delete", id])
            if (cfg.model.ollama === id) setModel("ollama", "")
        } else if (key === "remove:purge") runEngine("remove", ["--purge-models"])
        else if (key === "remove:keep") runEngine("remove")
    }

    // ---- engine ------------------------------------------------------------------------------------
    function installEngine() {
        if (engine.live) { notify({ tone: "info", title: "Install Quasar first", message: "On the live USB, models would fill the memory. Claude, ChatGPT and Ollama Cloud work here." }); return }
        if (!cfg.provider) patch({ provider: "ollama" })
        runEngine("install")
    }
    function runEngine(verb, extra) {
        if (engineJob) return
        engineJob = { verb: verb, pct: 0, phase: verb === "remove" ? "Removing" : "Starting" }
        engineHelper.runHelper([verb].concat(extra || []))
    }
    Privileged {
        id: engineHelper
        helper: "quasar-ollama"
        property string err: ""
        onStarted: err = ""
        onLine: (l) => {
            if (!root.engineJob) return
            const j = Object.assign({}, root.engineJob)
            if (l.startsWith("PROGRESS ")) j.pct = parseInt(l.slice(9)) || j.pct
            else if (l.startsWith("PHASE ")) j.phase = l.slice(6)
            else if (l.startsWith("ERROR ")) err = l.slice(6)
            root.engineJob = j
        }
        onFinished: (code) => {
            const verb = root.engineJob ? root.engineJob.verb : ""
            root.engineJob = null
            if (code === 0)
                root.notify({ tone: "success", title: verb === "remove" ? "The on-device engine was removed" : "The on-device engine is ready",
                              message: verb === "remove" ? "" : root.local.length ? "" : "Now download a model: Quasar suggests one that suits this PC." })
            else if (!engineHelper.cancelledByUser)
                root.notify({ tone: "error", title: err || "That didn't work", message: "Nothing else was changed.", details: engineHelper.details() })
            root.latest = ""
            root.refresh()
        }
    }

    // ---- models ------------------------------------------------------------------------------------
    function pull(id) {
        if (!id) return
        if (pullCmd.running) { notify({ tone: "info", title: "One download at a time", message: "Wait for " + Ai.modelName(pulling, catalog) + " to finish." }); return }
        pulling = id
        const p = Object.assign({}, pulls)
        p[id] = { pct: 0, phase: "Starting" }
        pulls = p
        pullCmd.err = ""
        pullCmd.run([helperPath, "pull", id])
    }
    function _setPull(id, v) { const p = Object.assign({}, pulls); if (v) p[id] = v; else delete p[id]; pulls = p }

    Cmd {
        id: pullCmd
        property string err: ""
        onLine: (l) => {
            let e
            try { e = JSON.parse(l) } catch (x) { return }
            const cur = root.pulls[root.pulling] || { pct: 0, phase: "" }
            if (e.type === "progress") root._setPull(root.pulling, { pct: e.percent, phase: cur.phase })
            else if (e.type === "phase") root._setPull(root.pulling, { pct: cur.pct, phase: e.text })
            else if (e.type === "error") err = e.message
        }
        onFinished: (code) => {
            const id = root.pulling
            root._setPull(id, null)
            root.pulling = ""
            if (code === 0) {
                if (!root.cfg.model.ollama) root.setModel("ollama", id)
                if (!root.cfg.provider) root.patch({ provider: "ollama" })
                root.notify({ tone: "success", title: Ai.modelName(id, root.catalog) + " is ready", message: "" })
            } else if (err) root.notify({ tone: "error", title: err, message: "" })
            root.listLocal()
        }
    }
    Cmd {
        id: listCmd
        onLine: (l) => {
            let e
            try { e = JSON.parse(l) } catch (x) { return }
            if (e.type !== "models") return
            root.local = e.models || []
            const cur = root.cfg.model.ollama
            if (root.local.length && (!cur || !root.local.some(m => m.id === cur))) root.setModel("ollama", root.local[0].id)
        }
    }
    Cmd {
        id: delCmd
        onFinished: (code) => root.listLocal()
    }
    Cmd {
        id: modelsCmd
        property string pid: ""
        property string err: ""
        onStarted: err = ""
        onLine: (l) => {
            let e
            try { e = JSON.parse(l) } catch (x) { return }
            if (e.type === "models") {
                const c = Object.assign({}, root.cloudModels)
                c[pid] = e.models || []
                root.cloudModels = c
            } else if (e.type === "error") err = e.message
        }
        onFinished: (code) => {
            root.busy = ""
            if (code === 0 && root.cloudModels[pid]) root.showCloudModels(pid)
            else root.notify({ tone: "error", title: err || "Couldn't get the list of models", message: "" })
        }
    }

    // ---- keys ----------------------------------------------------------------------------------------
    Cmd {
        id: keyCmd
        property string verb: ""
        property string pid: ""
        property string err: ""
        onStarted: err = ""
        onLine: (l) => {
            let e
            try { e = JSON.parse(l) } catch (x) { return }
            if (e.type === "key") {
                const k = Object.assign({}, root.keys)
                k[e.provider] = e
                root.keys = k
            } else if (e.type === "models") {
                const c = Object.assign({}, root.cloudModels)
                c[e.provider] = e.models || []
                root.cloudModels = c
                if (!root.cfg.model[e.provider] && e["default"]) root.setModel(e.provider, e["default"])
            } else if (e.type === "error") err = e.message
        }
        onFinished: (code) => {
            if (verb === "set") {
                root.busy = ""
                const p = Ai.PROVIDERS[pid]
                if (code === 0) root.notify({ tone: "success", title: p.label + " is ready", message: "Press Ask on the taskbar to try it." })
                else root.notify({ tone: "error", title: err || "The key didn't work", message: "Nothing was saved." })
            }
        }
    }

    // ---- status ---------------------------------------------------------------------------------------
    Cmd {
        id: engineCmd
        onLine: (l) => {
            let e
            try { e = JSON.parse(l) } catch (x) { return }
            if (e.type !== "engine") return
            root.engine = e
            if (e.installed) root.listLocal()
            else root.local = []
        }
    }
    Cmd {
        id: latestCmd
        property string err: ""
        onStarted: err = ""
        onLine: (l) => {
            let e
            try { e = JSON.parse(l) } catch (x) { return }
            if (e.type === "latest") root.latest = e.version
            else if (e.type === "error") err = e.message
        }
        onFinished: (code) => {
            root.busy = ""
            if (code !== 0) root.notify({ tone: "error", title: err || "Couldn't check for updates", message: "" })
            else if (root.latest === root.engine.version) root.notify({ tone: "success", title: "The engine is up to date", message: "Version " + root.latest })
        }
    }
    FileView {
        path: Quickshell.env("QUASAR_AI_MODELS") || "/usr/share/quasar/ai/models.json"
        printErrors: false
        onLoaded: { try { root.catalog = JSON.parse(text()).models || [] } catch (e) { root.catalog = [] } }
    }
}
