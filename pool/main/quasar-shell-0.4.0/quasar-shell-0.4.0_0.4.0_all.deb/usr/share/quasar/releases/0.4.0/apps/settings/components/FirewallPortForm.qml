import QtQuick
import Quasar
import "firewall.js" as Fw

// Settings › Firewall › Advanced › "Allow a port or range". Goes inside a Dialog; the host reads
// `valid` / `spec()` for its Allow button. Pure view.
//   networks: Fw.homeOffers(status): connected networks that aren't home networks right now. A port answers
//             devices on home networks only, so each gets a switch: Allow makes it a home network in the same
//             step (as the connection prompt does). On when it's `suggested` (not when its router changed).
//   spec() -> { name, tcp, udp, home?: [uuid] }   (the ports text as typed; quasar-firewall checks and tidies it)
Column {
    id: root
    property int proto: 2                       // 0 TCP · 1 UDP · 2 both
    property var networks: []
    property var homeChoice: ({})               // uuid -> the person's switch, where they flipped it
    property bool touched: false                // show the ports hint as an error once something was typed
    property alias nameText: nameField.text
    property alias portsText: portsField.text
    signal submitted()

    readonly property string error: Fw.portsError(portsField.text)
    readonly property bool valid: nameField.text.trim().length > 0 && nameField.text.trim().length <= 40 && error === ""

    function reset() { nameField.text = ""; portsField.text = ""; proto = 2; touched = false; homeChoice = ({}) }
    function focusFirst() { nameField.focusInput() }
    function homeOn(o) { return o.uuid in homeChoice ? homeChoice[o.uuid] : !!o.suggested }
    function spec() {
        const p = portsField.text.trim()
        const out = { name: nameField.text.trim(), tcp: proto !== 1 ? p : "", udp: proto !== 0 ? p : "" }
        const home = networks.filter(o => root.homeOn(o)).map(o => o.uuid)
        if (home.length) out.home = home
        return out
    }

    width: parent ? parent.width : 380
    spacing: 10

    TextField {
        id: nameField
        width: parent.width
        glyph: Icons.pencil
        placeholder: "What it's for, e.g. Dev server"
        onAccepted: portsField.focusInput()
    }
    TextField {
        id: portsField
        width: parent.width
        glyph: Icons.server
        mono: true
        placeholder: "Port or range, e.g. 3000 or 8000-8010"
        error: root.touched && root.error !== ""
        onEdited: root.touched = true
        onAccepted: if (root.valid) root.submitted()
    }
    Segmented {
        width: parent.width
        model: ["TCP", "UDP", "Both"]
        currentIndex: root.proto
        accessibleName: "Kind of connection"
        onPicked: (i) => root.proto = i
    }
    Text {
        width: parent.width
        wrapMode: Text.Wrap
        text: root.touched && root.error !== "" ? root.error
            : "Web servers and most apps use TCP; games and streaming often use UDP. Not sure? Keep Both."
        font.family: Theme.fontUi; font.pointSize: Theme.pt(12)
        color: root.touched && root.error !== "" ? Theme.danger : Theme.textDim
    }

    // The networks this PC is on that aren't home networks: the port answers there only once they are.
    Repeater {
        model: root.networks
        delegate: Item {
            id: offer
            required property var modelData
            readonly property var words: Fw.homeOfferText(modelData)
            readonly property bool switchedOn: root.homeOn(modelData)
            width: root.width
            height: Math.max(sw.height, texts.implicitHeight) + 16

            Rectangle {
                anchors { left: parent.left; right: parent.right; top: parent.top; topMargin: 4 }
                height: 1
                color: Theme.white(0.06)
            }
            Column {
                id: texts
                anchors { left: parent.left; right: sw.left; rightMargin: 14; verticalCenter: parent.verticalCenter
                          verticalCenterOffset: 2 }
                spacing: 2
                Text {
                    width: parent.width
                    wrapMode: Text.Wrap
                    textFormat: Text.PlainText
                    text: offer.words.label
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(13); font.weight: Font.Medium
                    color: Theme.text
                }
                Text {
                    width: parent.width
                    wrapMode: Text.Wrap
                    textFormat: Text.PlainText
                    text: offer.words.sub
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(12)
                    color: Theme.textDim
                }
            }
            QSwitch {
                id: sw
                anchors { right: parent.right; verticalCenter: parent.verticalCenter; verticalCenterOffset: 2 }
                checked: offer.switchedOn
                accessibleName: offer.words.label
                onToggled: {
                    const c = Object.assign({}, root.homeChoice)
                    c[offer.modelData.uuid] = !offer.switchedOn
                    root.homeChoice = c
                }
            }
        }
    }
}
