import QtQuick

// Info chip (template Store detail: 24px, radius 7, white .06 fill, 11.5px #C9CFDC; the
// "Sandboxed" chip is mint on mint .1 with a 12px shield glyph).
Rectangle {
    id: root
    property string text: ""
    property string glyph: ""
    property color tone: Theme.text3
    property color fill: Theme.white(0.06)

    implicitHeight: 24
    implicitWidth: row.implicitWidth + 18
    radius: 7
    color: fill

    Row {
        id: row
        anchors.centerIn: parent
        spacing: 5
        QIcon {
            visible: root.glyph !== ""
            anchors.verticalCenter: parent.verticalCenter
            path: root.glyph; size: 12; strokeWidth: 2.2; color: root.tone
        }
        Text {
            anchors.verticalCenter: parent.verticalCenter
            text: root.text
            textFormat: Text.PlainText
            font.family: Theme.fontUi; font.pointSize: Theme.pt(11.5)
            color: root.tone
        }
    }
}
