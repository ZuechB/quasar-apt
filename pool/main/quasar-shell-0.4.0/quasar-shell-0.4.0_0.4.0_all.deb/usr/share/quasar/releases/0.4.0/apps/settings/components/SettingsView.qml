import QtQuick
import Quasar

// Settings window content (template data-win="settings"): 236px sidebar (search, account, 17
// sections) | content column (max 780px): Space Grotesk title, optional hero, special blocks
// (Wi-Fi list, accent/wallpaper pickers, performance cards) and groups of rows.
// Pure view: the host supplies `groups` (rows built from live system state) and handles signals.
Item {
    id: root
    // ---- data in --------------------------------------------------------------------------------
    property string section: "network"
    property string userName: "You"
    property string accountSub: "Local account"
    property var groups: []          // [{ label, rows: [{ key, label, sub, glyph, trailing, value, valueColor, checked, busy }] }]
    property var hero: null          // { glyph, title, sub, iconBg, iconFg, toggle: bool|undefined, checked, button }
    property var banner: null        // { tone, title, message, details }
    // Network
    property bool wifiOn: false
    property var networks: []        // array or keyed model of WifiList rows
    property bool scanning: false
    property string passwordFor: ""  // network whose inline password row is open
    // Bluetooth (BluetoothList; shown while the adapter is on)
    property bool btListVisible: false
    property var btDevices: []
    property var btNearby: []
    property bool btAdding: false
    property string btPairing: ""
    // Appearance
    property string accent: Theme.accent
    property string wallpaper: "deep"
    property string wallpaperPhoto: ""   // the user's photo (path), once one is chosen
    property string wallpaperFit: "fill"
    // Performance
    property int profile: 1
    property bool profileLocked: false
    // Network monitor (quasar-netguard: apps that used the internet today)
    property var monitorModel: []
    property int monitorCount: 0
    property real monitorTop: 1
    property string monitorPhase: "loading"
    property string monitorBusy: ""

    // Arrange displays (DisplayArrangement): the displays helper's outputs, which one's rows show,
    // the main display, and whether a tried change is waiting for Keep (no dragging meanwhile).
    property var displayOutputs: []
    property string selectedDisplay: ""
    property string displayMain: ""
    property bool displayBusy: false
    // Command Deck: the "Connect a phone" card ({ url, code, left, address, pcName }), or null.
    property var deckCard: null

    // ---- signals out ------------------------------------------------------------------------------
    signal navigate(string key)
    signal rowToggled(string key)
    signal rowActivated(string key)
    signal heroToggled()
    signal heroActivated()
    signal wifiPicked(string name)
    signal wifiConnect(string name, string password)
    signal wifiCancel()
    signal wifiDisconnect(string name)
    signal wifiForget(string name)
    signal wifiJoinOther()
    signal btConnect(string key)
    signal btDisconnect(string key)
    signal btForget(string key)
    signal btPair(string key)
    signal btAdd()
    signal btStop()
    signal accentPicked(string color)
    signal wallpaperPicked(string kind)
    signal wallpaperChoose()             // "Choose a photo…": the host opens PhotoChooser
    signal wallpaperFitPicked(string fit)
    signal profilePicked(int index)
    signal bannerAction()
    signal monitorBlock(string key)
    signal monitorAllow(string key)
    signal displayChosen(string name)
    signal displayMoved(string name, real x, real y)
    signal displayIdentify()

    readonly property var sections: [
        ["network", "Network & Internet", Icons.wifi], ["profiles", "Companies & Profiles", Icons.brief],
        ["bluetooth", "Bluetooth & Devices", Icons.bt], ["commanddeck", "Command Deck", Icons.phone], ["drivers", "Drivers & Hardware", Icons.cpu], ["display", "Display", Icons.monitor], ["desktop", "Desktop", Icons.layers], ["sound", "Sound", Icons.vol],
        ["appearance", "Appearance", Icons.palette], ["notifications", "Notifications", Icons.bell],
        ["privacy", "Privacy & Security", Icons.shield], ["ai", "Quasar AI", Icons.orbit], ["apps", "Apps", Icons.grid],
        ["performance", "Performance", Icons.bolt], ["storage", "Storage", Icons.drive], ["users", "Users & Accounts", Icons.user],
        ["input", "Keyboard & Input", Icons.keyboard], ["language", "Date & Language", Icons.globe],
        ["updates", "Updates", Icons.refresh], ["about", "About", Icons.info]
    ]
    // Pages that aren't in the sidebar: opened from a row on their parent page, with a way back.
    readonly property var subpages: ({ firewall: { title: "Firewall", parent: "network" },
                                       vpn: { title: "VPN", parent: "network" },
                                       hotspot: { title: "Mobile hotspot", parent: "network" },
                                       dns: { title: "Encrypted DNS", parent: "network" },
                                       arrange: { title: "Arrange displays", parent: "display" },
                                       history: { title: "Update history", parent: "updates" },
                                       snapshots: { title: "Snapshots", parent: "storage" },
                                       sshkeys: { title: "Your SSH keys", parent: "users" },
                                       remotedesktop: { title: "Remote desktop", parent: "users" },
                                       azure: { title: "Azure DevOps", parent: "profiles" } })
    readonly property var subpage: subpages[section] || null
    readonly property string navSection: subpage ? subpage.parent : section
    property string filter: ""
    function titleOf(key) { return (sections.find(s => s[0] === key) || sections[0])[1] }
    // Sidebar search: a section matches by its title, or by the title of one of its sub pages
    // ("firewall" finds Network & Internet).
    function matches(s, q) {
        return !q || s[1].toLowerCase().includes(q)
            || Object.keys(subpages).some(k => subpages[k].parent === s[0] && subpages[k].title.toLowerCase().includes(q))
    }
    readonly property string title: subpage ? subpage.title : titleOf(section)

    // ---- sidebar ------------------------------------------------------------------------------------
    Item {
        id: side
        width: 236
        height: parent.height
        Flickable {
            anchors.fill: parent
            contentHeight: navCol.implicitHeight + 24
            boundsBehavior: Flickable.StopAtBounds
            clip: true
            Column {
                id: navCol
                x: 10; y: 12
                width: side.width - 20
                spacing: 1
                SearchField {
                    width: parent.width
                    placeholder: "Find a setting"
                    onEdited: (t) => root.filter = t
                    onAccepted: {
                        const q = root.filter.trim().toLowerCase()
                        const sub = Object.keys(root.subpages).find(k => q && root.subpages[k].title.toLowerCase().includes(q))
                        if (sub && !root.sections.some(s => s[1].toLowerCase().includes(q))) { root.navigate(sub); return }
                        const hit = root.sections.find(s => root.matches(s, q))
                        if (hit) root.navigate(hit[0])
                    }
                }
                Item { width: 1; height: 8 }
                Row {
                    leftPadding: 10; topPadding: 0; bottomPadding: 12
                    spacing: 10
                    Avatar { anchors.verticalCenter: parent.verticalCenter; size: 38 }
                    Column {
                        anchors.verticalCenter: parent.verticalCenter
                        spacing: 1
                        Text { text: root.userName; font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5); font.weight: Font.DemiBold; color: Theme.text }
                        Text { text: root.accountSub; font.family: Theme.fontUi; font.pointSize: Theme.pt(11.5); color: Theme.textDim }
                    }
                }
                Repeater {
                    model: root.sections.filter(s => root.matches(s, root.filter.trim().toLowerCase()))
                    NavItem {
                        required property var modelData
                        width: navCol.width
                        label: modelData[1]
                        glyph: modelData[2]
                        selected: root.navSection === modelData[0]
                        accentIcon: true
                        idleText: Theme.text3
                        labelWeight: Font.Normal
                        onClicked: root.navigate(modelData[0])
                    }
                }
            }
        }
    }
    Rectangle { x: side.width; width: 1; height: parent.height; color: Theme.white(0.05) }

    // ---- content ---------------------------------------------------------------------------------------
    ScrollPane {
        id: scroll
        x: side.width + 1
        width: parent.width - x
        height: parent.height
        topPadding: 22; bottomPadding: 32

        Column {
            id: pageCol
            x: 28
            width: Math.min(780, scroll.width - 56)
            spacing: 0

            // A sub page: "‹ Network & Internet" back to its parent, above the title.
            Pressable {
                visible: !!root.subpage
                x: -8
                width: backRow.implicitWidth + 16
                height: visible ? 28 : 0
                kind: "hov"; radius: 8
                accessibleName: root.subpage ? "Back to " + root.titleOf(root.subpage.parent) : ""
                onClicked: if (root.subpage) root.navigate(root.subpage.parent)
                Row {
                    id: backRow
                    x: 8
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: 4
                    QIcon { anchors.verticalCenter: parent.verticalCenter; path: Icons.back; size: 14; strokeWidth: 2; color: Theme.textMuted }
                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        text: root.subpage ? root.titleOf(root.subpage.parent) : ""
                        font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
                        color: Theme.textMuted
                    }
                }
            }
            Item { visible: !!root.subpage; width: 1; height: 6 }

            Text {
                text: root.title
                font.family: Theme.fontDisplay; font.pixelSize: 26; font.weight: Font.Medium; font.letterSpacing: -0.5
                color: Theme.text
            }

            // Page body. Switching section swaps `groups` (and the section blocks below); the groups
            // play the row-in entrance again (onSectionChanged), including any that stay.
            Column {
            width: pageCol.width
            spacing: 22
            topPadding: 18

            Banner {
                visible: !!root.banner
                width: parent.width
                tone: root.banner ? root.banner.tone || "error" : "error"
                title: root.banner ? root.banner.title || "" : ""
                message: root.banner ? root.banner.message || "" : ""
                details: root.banner ? root.banner.details || "" : ""
                actionText: root.banner ? root.banner.actionText || "" : ""
                onActionClicked: root.bannerAction()
            }

            Appear {
                visible: !!root.hero
                width: parent.width
                height: heroCard.implicitHeight
                HeroCard {
                    id: heroCard
                    width: parent.width
                    glyph: root.hero ? root.hero.glyph || "" : ""
                    title: root.hero ? root.hero.title || "" : ""
                    sub: root.hero ? root.hero.sub || "" : ""
                    iconBg: root.hero && root.hero.iconBg ? root.hero.iconBg : Theme.white(0.07)
                    iconFg: root.hero && root.hero.iconFg ? root.hero.iconFg : Theme.text3
                    glow: root.hero && root.hero.glow ? root.hero.glow : Theme.accentTint
                    fill: root.hero && root.hero.fill ? root.hero.fill : Theme.white(0.035)
                    line: root.hero && root.hero.line ? root.hero.line : Theme.white(0.07)
                    Row {
                        spacing: 10
                        // A switch whose change is still running: dimmed, with a spinner (hero.busy).
                        Spinner {
                            anchors.verticalCenter: parent.verticalCenter
                            visible: !!root.hero && root.hero.toggle === true && !!root.hero.busy
                            size: 16
                        }
                        QSwitch {
                            anchors.verticalCenter: parent.verticalCenter
                            visible: !!root.hero && root.hero.toggle === true
                            enabled: !(root.hero && root.hero.busy)
                            checked: !!root.hero && !!root.hero.checked
                            accessibleName: root.hero ? root.hero.title : ""
                            onToggled: root.heroToggled()
                        }
                        Button {
                            anchors.verticalCenter: parent.verticalCenter
                            visible: !!root.hero && !!root.hero.button
                            text: root.hero && root.hero.button ? root.hero.button : ""
                            variant: root.hero && root.hero.buttonPrimary ? "primary" : "soft"; size: 36
                            onClicked: root.heroActivated()
                        }
                    }
                }
            }

            // Network: available Wi-Fi networks with inline password entry.
            Loader {
                active: root.section === "network" && root.wifiOn
                visible: active
                width: parent.width
                sourceComponent: WifiList {
                    width: pageCol.width
                    networks: root.networks
                    scanning: root.scanning
                    passwordFor: root.passwordFor
                    onPicked: (n) => root.wifiPicked(n)
                    onConnectClicked: (n, pw) => root.wifiConnect(n, pw)
                    onCancelled: root.wifiCancel()
                    onDisconnectClicked: (n) => root.wifiDisconnect(n)
                    onForgetClicked: (n) => root.wifiForget(n)
                    onJoinOtherClicked: root.wifiJoinOther()
                }
            }

            // Bluetooth: your devices, and nearby ones while adding.
            Loader {
                active: root.section === "bluetooth" && root.btListVisible
                visible: active
                width: parent.width
                sourceComponent: BluetoothList {
                    width: pageCol.width
                    devices: root.btDevices
                    nearby: root.btNearby
                    adding: root.btAdding
                    pairingKey: root.btPairing
                    onConnectClicked: (k) => root.btConnect(k)
                    onDisconnectClicked: (k) => root.btDisconnect(k)
                    onForgetClicked: (k) => root.btForget(k)
                    onPairClicked: (k) => root.btPair(k)
                    onAddClicked: root.btAdd()
                    onStopClicked: root.btStop()
                }
            }

            // Display: wallpaper cards, your own photo and Choose a photo… (the desktop's "Display
            // settings" opens this page).
            Loader {
                active: root.section === "display"
                visible: active
                width: parent.width
                sourceComponent: WallpaperPicker {
                    width: pageCol.width
                    accent: root.accent
                    wallpaper: root.wallpaper
                    photo: root.wallpaperPhoto
                    fit: root.wallpaperFit
                    onWallpaperPicked: (k) => root.wallpaperPicked(k)
                    onChoosePhoto: root.wallpaperChoose()
                    onFitPicked: (f) => root.wallpaperFitPicked(f)
                }
            }

            // Arrange displays: drag the displays into place, pick one for the rows below, Identify.
            Loader {
                active: root.section === "arrange"
                visible: active
                width: parent.width
                sourceComponent: DisplayArrangement {
                    width: pageCol.width
                    outputs: root.displayOutputs
                    selected: root.selectedDisplay
                    mainName: root.displayMain
                    locked: root.displayBusy
                    accent: root.accent
                    onChosen: (n) => root.displayChosen(n)
                    onMoved: (n, x, y) => root.displayMoved(n, x, y)
                    onIdentifyClicked: root.displayIdentify()
                }
            }

            // Command Deck: the code a phone scans (only while phones can connect).
            Loader {
                active: root.section === "commanddeck" && !!root.deckCard
                visible: active
                width: parent.width
                sourceComponent: DeckConnectCard {
                    width: pageCol.width
                    url: root.deckCard ? root.deckCard.url || "" : ""
                    code: root.deckCard ? root.deckCard.code || "" : ""
                    secondsLeft: root.deckCard ? root.deckCard.left || 0 : 0
                    address: root.deckCard ? root.deckCard.address || "" : ""
                    pcName: root.deckCard ? root.deckCard.pcName || "this PC" : "this PC"
                }
            }

            // Appearance: accent swatches.
            Loader {
                active: root.section === "appearance"
                visible: active
                width: parent.width
                sourceComponent: AppearancePickers {
                    width: pageCol.width
                    accent: root.accent
                    onAccentPicked: (c) => root.accentPicked(c)
                }
            }

            // Performance: Lite / Balanced / Max cards.
            Loader {
                active: root.section === "performance"
                visible: active
                width: parent.width
                sourceComponent: PerformanceCards {
                    width: pageCol.width
                    profile: root.profile
                    locked: root.profileLocked
                    onPicked: (i) => root.profilePicked(i)
                }
            }

            // Groups and rows follow `groups` by key (syncGroups below), so a live value (a
            // download's percent, the volume) updates its row in place. A Repeater on the array
            // itself rebuilt the whole page, entrance and all, on every change.
            Repeater {
                id: groupRepeater
                model: groupModel
                onItemAdded: (i, item) => root.fillGroup(item, i)
                Appear {
                    id: groupItem
                    required property int index
                    property var group: ({ label: "", rows: [] })      // set by fillGroup
                    readonly property ListModel rowModel: ListModel {}
                    order: index + 1
                    width: pageCol.width
                    height: grp.implicitHeight
                    SettingsGroup {
                        id: grp
                        width: parent.width
                        label: groupItem.group.label || ""
                        Repeater {
                            model: groupItem.rowModel
                            SettingsRow {
                                required property int index
                                readonly property var row: (groupItem.group.rows || [])[index] || ({})
                                label: row.label || ""
                                sub: row.sub || ""
                                glyph: row.glyph || ""
                                trailing: row.trailing || "none"
                                value: row.value !== undefined ? String(row.value) : ""
                                valueColor: row.valueColor || Theme.textMuted
                                checked: !!row.checked
                                busy: !!row.busy
                                onToggled: root.rowToggled(row.key || row.label)
                                onActivated: root.rowActivated(row.key || row.label)
                            }
                        }
                    }
                }
            }

            // Network: apps that used the internet today, after the groups (as in the template).
            Appear {
                visible: root.section === "network"
                order: root.groups.length + 1
                width: pageCol.width
                height: visible ? monitor.implicitHeight : 0
                NetworkMonitorList {
                    id: monitor
                    width: parent.width
                    model: root.monitorModel
                    rowCount: root.monitorCount
                    maxTotal: root.monitorTop
                    phase: root.monitorPhase
                    busyKey: root.monitorBusy
                    onBlockClicked: (k) => root.monitorBlock(k)
                    onAllowClicked: (k) => root.monitorAllow(k)
                }
            }
        }
    }
    }
    onSectionChanged: {
        scroll.scrollToTop()
        // A group whose label is on both pages stays alive, so replay the entrance on every group.
        for (let i = 0; i < groupRepeater.count; i++) { const g = groupRepeater.itemAt(i); if (g) g.replay() }
    }

    // ---- groups of rows, kept by key ----------------------------------------------------------------
    // One ListModel for the groups and one per group for its rows, each with a single role (itemKey).
    // Delegates read their data from `groups`; syncing only inserts, removes and moves, so a group or
    // row whose key stays keeps its delegate.
    ListModel { id: groupModel }
    onGroupsChanged: syncGroups()
    Component.onCompleted: syncGroups()

    // A row's key, else its label (a group's label); numbered when one repeats.
    function keysOf(items) {
        const seen = {}
        return items.map(x => {
            const k = String(x.key || x.label || "")
            seen[k] = (seen[k] || 0) + 1
            return seen[k] > 1 ? k + "\u001f" + seen[k] : k
        })
    }
    // Make `model` follow `keys` (unique) with the fewest changes.
    function syncKeys(model, keys) {
        const want = new Set(keys)
        for (let i = model.count - 1; i >= 0; i--) if (!want.has(model.get(i).itemKey)) model.remove(i)
        for (let i = 0; i < keys.length; i++) {
            if (i < model.count && model.get(i).itemKey === keys[i]) continue
            let j = i + 1
            while (j < model.count && model.get(j).itemKey !== keys[i]) j++
            if (j < model.count) model.move(j, i, 1)
            else model.insert(i, { itemKey: keys[i] })
        }
    }
    function fillGroup(item, i) {
        const g = (groups || [])[i]
        if (!item || !g) return
        syncKeys(item.rowModel, keysOf(g.rows || []))
        item.group = g
    }
    function syncGroups() {
        const gs = groups || []
        syncKeys(groupModel, keysOf(gs))
        for (let i = 0; i < gs.length; i++) fillGroup(groupRepeater.itemAt(i), i)
    }
}
