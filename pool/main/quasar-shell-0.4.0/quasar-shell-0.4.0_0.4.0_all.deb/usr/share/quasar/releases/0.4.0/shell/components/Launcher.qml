import QtQuick
import Quasar

// Launcher content (mockup role="dialog" aria-label="Launcher"): search field, pinned grid,
// assistant suggestions, recent files; with a query, grouped results (DO / APPS / STORE / SETTINGS / FILES).
// Pure view: the host supplies models and handles the signals. Keyboard: type, ↑/↓, Enter, Esc.
Panel {
    id: root
    radius: 26
    tint: Theme.panelBg
    borderColor: Theme.white(0.11)
    shadowOffsetY: 40
    shadowBlur: 90
    shadowSpread: -30
    shadowColor: Qt.rgba(0, 0, 0, 0.9)
    glowColor: Theme.accentGlow

    // ---- data in ------------------------------------------------------------------
    property string userName: "Brandon"
    property bool assistantAvailable: false
    property var pinned: []        // [{ key, name, glyph, icon, hue }]
    property var moreApps: []      // shown with "All apps"
    property var suggestions: []   // assistant tasks [{ label, sub, glyph }]
    property var recents: []       // [{ title, sub, glyph, hue, key }]
    property var groups: []        // [{ label, items: [{ title, sub, glyph, icon, hue, tag, key }] }]
    property bool allApps: false
    property alias query: input.text
    // A menu opened from here (the power menu, an app's menu) shows over the launcher, which stays open.
    property bool menuOpen: false
    property bool powerOpen: false        // that menu is the power menu: its button stays lit

    // ---- signals out ----------------------------------------------------------------
    signal queryEdited(string text)
    signal activated(var item)            // any app / result / recent
    signal askRequested(string text)
    signal allAppsToggled()
    signal settingsClicked()
    signal lockClicked()
    signal powerClicked()
    signal appContextRequested(var item, real x, real y)   // right click on an app; x/y in launcher coordinates
    signal menuDismissed()                // with menuOpen: a press anywhere here, Esc or typing closes that menu
    signal closeRequested()

    readonly property bool hasQuery: input.text.trim().length > 0
    property int selected: -1
    readonly property var flatResults: {
        const out = []
        for (const g of groups) for (const it of g.items) out.push(it)
        return out
    }
    function focusSearch() { input.forceActiveFocus() }
    onGroupsChanged: selected = (hasQuery && flatResults.length > 0 && !assistantAvailable) ? 0 : -1

    // ---- header: search field ---------------------------------------------------------
    Rectangle {
        id: field
        x: 18; y: 18
        width: root.width - 36; height: 54; radius: 18
        color: Theme.white(0.06)
        border.width: 1; border.color: Theme.accentLine
        OrbitMark {
            id: fieldMark
            anchors { left: parent.left; leftMargin: 16; verticalCenter: parent.verticalCenter }
            size: 22; spinning: root.visible
        }
        TextInput {
            id: input
            anchors { left: fieldMark.right; leftMargin: 12; right: badge.left; rightMargin: 10; verticalCenter: parent.verticalCenter }
            font.family: Theme.fontUi; font.pointSize: Theme.pt(15.5)
            color: Theme.text
            selectionColor: Theme.alpha(Theme.accent, 0.35)
            selectedTextColor: Theme.text
            cursorDelegate: Rectangle { width: 2; color: Theme.accent; visible: input.cursorVisible }
            clip: true
            focus: true
            Accessible.role: Accessible.EditableText
            Accessible.name: "Search or ask"
            onTextEdited: { if (root.menuOpen) root.menuDismissed(); root.queryEdited(text) }
            Keys.onEscapePressed: root.menuOpen ? root.menuDismissed() : root.closeRequested()
            Keys.onDownPressed: if (root.flatResults.length) root.selected = Math.min(root.flatResults.length - 1, root.selected + 1)
            Keys.onUpPressed: root.selected = Math.max(root.assistantAvailable ? -1 : 0, root.selected - 1)
            Keys.onReturnPressed: root._enter()
            Keys.onEnterPressed: root._enter()
            Text {
                anchors.fill: parent
                verticalAlignment: Text.AlignVCenter
                visible: input.text.length === 0
                text: root.assistantAvailable ? "Search apps, files, settings, or ask Quasar to do something"
                                              : "Search apps, files and settings"
                elide: Text.ElideRight
                font: input.font
                color: Theme.textFaint
            }
        }
        Badge { id: badge; anchors { right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter } }
    }
    function _enter() {
        const q = input.text.trim()
        if (!q) return
        if (selected >= 0 && selected < flatResults.length) root.activated(flatResults[selected])
        else if (assistantAvailable) root.askRequested(q)
        else if (flatResults.length) root.activated(flatResults[0])
    }

    // ---- body -----------------------------------------------------------------------------
    Flickable {
        id: flick
        x: 18; y: 80
        width: root.width - 36
        height: root.height - 80 - 58
        contentHeight: (root.hasQuery ? resultsCol.height : homeCol.height) + 20
        clip: true
        boundsBehavior: Flickable.StopAtBounds

        // Home (no query)
        Column {
            id: homeCol
            width: flick.width
            visible: !root.hasQuery
            topPadding: 6

            Item {
                width: parent.width; height: 48
                Text { x: 4; anchors.verticalCenter: parent.verticalCenter; text: "Pinned"; font.family: Theme.fontUi; font.pixelSize: 13; font.weight: Font.DemiBold; color: Theme.text }
                Pressable {
                    anchors { right: parent.right; rightMargin: 4; verticalCenter: parent.verticalCenter }
                    width: allText.implicitWidth + 20; height: 28; radius: 8; kind: "hov"
                    color: Theme.white(0.06)
                    accessibleName: root.allApps ? "Fewer apps" : "All apps"
                    onClicked: root.allAppsToggled()
                    Text { id: allText; anchors.centerIn: parent; text: root.allApps ? "Fewer" : "All apps"; font.family: Theme.fontUi; font.pixelSize: 12; color: Theme.text3 }
                }
            }

            Grid {
                id: pinGrid
                readonly property int cols: Math.max(1, Math.floor((width + 4) / 96))
                readonly property real cellW: (width - (cols - 1) * 4) / cols
                width: parent.width
                columns: cols
                columnSpacing: 4
                rowSpacing: 6
                Repeater {
                    model: root.allApps ? root.pinned.concat(root.moreApps) : root.pinned
                    delegate: Pressable {
                        required property int index
                        required property var modelData
                        width: pinGrid.cellW; height: 94; radius: 14; kind: "tile"
                        accessibleName: modelData.name
                        onClicked: root.activated(modelData)
                        onRightClicked: (mx, my) => { if (modelData.entry) { const p = mapToItem(root, mx, my); root.appContextRequested(modelData, p.x, p.y) } }
                        Column {
                            anchors.centerIn: parent
                            spacing: 8
                            AppTile { anchors.horizontalCenter: parent.horizontalCenter; size: 50; radius: 15; hue: modelData.hue || Theme.text3; glyph: modelData.glyph || ""; image: modelData.icon || ""; letter: modelData.letter || ""; glyphSize: 25 }
                            Text {
                                anchors.horizontalCenter: parent.horizontalCenter
                                width: pinGrid.cellW - 8
                                horizontalAlignment: Text.AlignHCenter
                                elide: Text.ElideRight
                                text: modelData.name
                                font.family: Theme.fontUi; font.pixelSize: 12; color: Theme.text2
                            }
                        }
                    }
                }
            }

            Column {
                width: parent.width
                visible: root.assistantAvailable && root.suggestions.length > 0
                Text { leftPadding: 4; topPadding: 16; bottomPadding: 8; text: "Quasar can do this for you"; font.family: Theme.fontUi; font.pixelSize: 13; font.weight: Font.DemiBold; color: Theme.text }
                Column {
                    width: parent.width
                    spacing: 4
                    Repeater {
                        model: root.suggestions
                        delegate: Pressable {
                            required property var modelData
                            width: parent.width; height: 52; radius: 13; kind: "hov"
                            color: Theme.white(0.03)
                            accessibleName: modelData.label
                            onClicked: root.askRequested(modelData.label)
                            Rectangle {
                                x: 10; anchors.verticalCenter: parent.verticalCenter
                                width: 34; height: 34; radius: 11; color: Theme.accentTint
                                QIcon { anchors.centerIn: parent; path: modelData.glyph; size: 17; color: Theme.accent }
                            }
                            Column {
                                x: 56; anchors.verticalCenter: parent.verticalCenter
                                spacing: 2
                                Text { text: modelData.label; font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5); font.weight: Font.Medium; color: Theme.text }
                                Text { text: modelData.sub; font.family: Theme.fontUi; font.pixelSize: 12; color: Theme.textDim }
                            }
                            QIcon { anchors { right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter } path: Icons.fwd; size: 16; strokeWidth: 2; color: Theme.textFaint }
                        }
                    }
                }
            }

            Column {
                width: parent.width
                visible: root.recents.length > 0
                Text { leftPadding: 4; topPadding: 16; bottomPadding: 8; text: "Recent"; font.family: Theme.fontUi; font.pixelSize: 13; font.weight: Font.DemiBold; color: Theme.text }
                Grid {
                    id: recentGrid
                    readonly property int cols: Math.max(1, Math.floor((width + 4) / 264))
                    width: parent.width
                    columns: cols
                    columnSpacing: 4; rowSpacing: 4
                    Repeater {
                        model: root.recents
                        delegate: Pressable {
                            required property var modelData
                            width: (recentGrid.width - (recentGrid.cols - 1) * 4) / recentGrid.cols
                            height: 48; radius: 12; kind: "hov"
                            accessibleName: modelData.title
                            onClicked: root.activated(modelData)
                            QIcon { x: 10; anchors.verticalCenter: parent.verticalCenter; path: modelData.glyph; size: 20; strokeWidth: 1.8; color: modelData.hue }
                            Column {
                                x: 41; anchors.verticalCenter: parent.verticalCenter
                                width: parent.width - 51
                                spacing: 1
                                Text { width: parent.width; elide: Text.ElideRight; text: modelData.title; font.family: Theme.fontUi; font.pixelSize: 13; font.weight: Font.Medium; color: Theme.text }
                                Text { width: parent.width; elide: Text.ElideRight; text: modelData.sub; font.family: Theme.fontUi; font.pointSize: Theme.pt(11.5); color: Theme.textDim }
                            }
                        }
                    }
                }
            }
        }

        // Results (query)
        Column {
            id: resultsCol
            width: flick.width
            visible: root.hasQuery
            topPadding: 4

            Pressable {
                visible: root.assistantAvailable
                width: parent.width; height: 58; radius: 14; kind: "hov"
                color: root.selected === -1 ? Theme.alpha(Theme.accent, 0.20) : Theme.accentTint
                borderColor: Theme.accentLine; hoverBorderColor: Theme.accentLine
                accessibleName: "Ask Quasar: " + input.text
                onClicked: root.askRequested(input.text.trim())
                Rectangle {
                    x: 12; anchors.verticalCenter: parent.verticalCenter
                    width: 36; height: 36; radius: 11; color: Theme.accent
                    QIcon { anchors.centerIn: parent; path: Icons.orbit; size: 18; strokeWidth: 2; color: Theme.accentInk }
                }
                Column {
                    x: 60; anchors.verticalCenter: parent.verticalCenter
                    width: parent.width - 60 - 70
                    spacing: 2
                    Text { width: parent.width; elide: Text.ElideRight; text: "Ask Quasar: “" + input.text.trim() + "”"; font.family: Theme.fontUi; font.pixelSize: 14; font.weight: Font.DemiBold; color: Theme.text }
                    Text { text: "Plans it, shows each step, runs it on this PC"; font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5); color: Theme.textMuted }
                }
                Rectangle {
                    anchors { right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter }
                    width: enterText.implicitWidth + 14; height: 22; radius: 6; color: "transparent"
                    border.width: 1; border.color: Theme.white(0.14)
                    Text { id: enterText; anchors.centerIn: parent; text: "Enter"; font.family: Theme.fontMono; font.pixelSize: 11; color: Theme.text3 }
                }
            }

            Repeater {
                model: root.groups
                delegate: Column {
                    id: grp
                    required property int index
                    required property var modelData
                    width: resultsCol.width
                    readonly property int base: {
                        let n = 0
                        for (let i = 0; i < index; i++) n += root.groups[i].items.length
                        return n
                    }
                    SectionLabel { leftPadding: 8; topPadding: 14; bottomPadding: 6; text: grp.modelData.label }
                    Repeater {
                        model: grp.modelData.items
                        delegate: Pressable {
                            required property int index
                            required property var modelData
                            readonly property bool isSel: root.selected === grp.base + index
                            width: grp.width; height: 52; radius: 12; kind: "hov"
                            color: isSel ? Theme.white(0.07) : "transparent"
                            accessibleName: modelData.title
                            onClicked: root.activated(modelData)
                            onRightClicked: (mx, my) => { if (modelData.entry) { const p = mapToItem(root, mx, my); root.appContextRequested(modelData, p.x, p.y) } }
                            Rectangle {
                                x: 10; anchors.verticalCenter: parent.verticalCenter
                                width: 34; height: 34; radius: 10
                                color: Theme.white(0.05); border.width: 1; border.color: Theme.white(0.07)
                                QIcon { anchors.centerIn: parent; visible: !modelData.icon && (!!modelData.glyph || !modelData.letter); path: modelData.glyph || Icons.grid; size: 17; color: modelData.hue || Theme.text3 }
                                Text { anchors.centerIn: parent; visible: !modelData.icon && !modelData.glyph && !!modelData.letter; text: modelData.letter || ""; font.family: Theme.fontUi; font.pixelSize: 15; font.weight: Font.DemiBold; color: modelData.hue || Theme.text3 }
                                Image { anchors.centerIn: parent; visible: !!modelData.icon; source: modelData.icon || ""; width: 22; height: 22; sourceSize: Qt.size(44, 44); asynchronous: true }
                            }
                            Column {
                                x: 56; anchors.verticalCenter: parent.verticalCenter
                                width: parent.width - 56 - 60
                                spacing: 2
                                Text { width: parent.width; elide: Text.ElideRight; text: modelData.title; font.family: Theme.fontUi; font.pixelSize: 14; font.weight: Font.Medium; color: Theme.text }
                                Text { width: parent.width; elide: Text.ElideRight; text: modelData.sub; font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5); color: Theme.textDim }
                            }
                            Text { anchors { right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter } text: modelData.tag || ""; font.family: Theme.fontUi; font.pixelSize: 12; color: Theme.textFaint }
                        }
                    }
                }
            }

            Text {
                visible: root.groups.length === 0
                width: parent.width
                leftPadding: 10; topPadding: 14
                wrapMode: Text.WordWrap
                text: root.assistantAvailable ? "Nothing on this PC matches. Press Enter and Quasar will work out the steps."
                                              : "Nothing on this PC matches."
                font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5); color: Theme.textMuted
            }
        }
    }

    // ---- footer: account + power row ---------------------------------------------------------
    Item {
        anchors { left: parent.left; right: parent.right; bottom: parent.bottom }
        height: 58
        Rectangle { anchors { left: parent.left; right: parent.right; top: parent.top } height: 1; color: Theme.white(0.07) }
        Avatar { x: 18; anchors.verticalCenter: parent.verticalCenter; size: 30 }
        Text { x: 58; anchors.verticalCenter: parent.verticalCenter; text: root.userName; font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5); font.weight: Font.Medium; color: Theme.text }
        Row {
            anchors { right: parent.right; rightMargin: 14; verticalCenter: parent.verticalCenter }
            spacing: 6
            Pressable { width: 40; height: 40; radius: 12; accessibleName: "Settings"; onClicked: root.settingsClicked()
                QIcon { anchors.centerIn: parent; path: Icons.gear; size: 18; color: Theme.text3 } }
            Pressable { width: 40; height: 40; radius: 12; accessibleName: "Lock"; onClicked: root.lockClicked()
                QIcon { anchors.centerIn: parent; path: Icons.lock; size: 18; color: Theme.text3 } }
            Pressable { id: powerButton; width: 40; height: 40; radius: 12; accessibleName: "Power"; onClicked: root.powerClicked()
                color: root.powerOpen ? Theme.white(0.07) : "transparent"
                QIcon { anchors.centerIn: parent; path: Icons.power; size: 18; color: Theme.danger } }
        }
    }

    // While a menu is open over the launcher, the first press anywhere on it closes the menu and still
    // does what it would have done (another app, the search field, Settings…). The power button only
    // closes its own menu, so it toggles. (MouseArea.enabled is its own flag: turning it off while
    // this press is handled is safe.)
    MouseArea {
        anchors.fill: parent
        z: 100
        enabled: root.menuOpen
        acceptedButtons: Qt.AllButtons
        onPressed: (mouse) => {
            const p = mapToItem(powerButton, mouse.x, mouse.y)
            mouse.accepted = root.powerOpen && powerButton.contains(p)
            root.menuDismissed()
        }
    }
}
