import QtQuick
import Qt.labs.folderlistmodel
import Quasar

// "Choose a photo" (Settings › Display): a folder's pictures as thumbnails, with places (Pictures,
// Desktop, Downloads, Home, and Drives while a removable drive is mounted) and the path above them.
// Click a folder to open it and a photo to pick it; double-click a photo, or "Set as wallpaper", to
// use it. Pure Qt (FolderListModel), so the preview can browse a real folder. Lists only what Qt can
// decode on Quasar (no HEIC/AVIF), and no hidden files.
Dialog {
    id: root
    property string home: "/home/you"
    property string drives: ""                 // /media/<user>; offered while something is mounted there
    property string folder: home + "/Pictures" // the folder shown (kept between openings)
    property string picked: ""                 // the photo picked (path)
    signal chosen(string path)

    title: "Choose a photo"
    cardWidth: 760
    onOpenChanged: if (open) picked = ""
    function go(path) { if (path && path !== folder) folder = path }

    readonly property var places: [
        { label: "Pictures", path: home + "/Pictures", glyph: Icons.image },
        { label: "Desktop", path: home + "/Desktop", glyph: Icons.monitor },
        { label: "Downloads", path: home + "/Downloads", glyph: Icons.download },
        { label: "Home", path: home, glyph: Icons.home }
    ].concat(hasDrives ? [{ label: "Drives", path: drives, glyph: Icons.drive }] : [])
    // The place the folder is in (the longest matching path), for the highlighted chip.
    readonly property string place: {
        let best = ""
        for (const p of places)
            if ((folder === p.path || folder.startsWith(p.path + "/")) && p.path.length > best.length) best = p.path
        return best
    }
    // Home › Pictures › Trips: the folder from its root (Home, Drives or the computer's /).
    readonly property var crumbs: {
        const f = folder
        let base = "", label = "Computer"
        if (f === home || f.startsWith(home + "/")) { base = home; label = "Home" }
        else if (drives && (f === drives || f.startsWith(drives + "/"))) { base = drives; label = "Drives" }
        const out = [{ label: label, path: base || "/" }]
        let p = base
        f.slice(base.length).split("/").filter(s => s !== "").forEach(s => { p += "/" + s; out.push({ label: s, path: p }) })
        return out.length > 4 ? [{ label: "…", path: out[out.length - 4].path }].concat(out.slice(-3)) : out
    }
    readonly property string parentFolder: {
        const i = folder.lastIndexOf("/")
        return i > 0 ? folder.slice(0, i) : (folder.length > 1 && folder.startsWith("/") ? "/" : "")
    }

    // Listings are names only, so they're kept from the start and the sheet opens on a ready grid; the
    // grid has no model while the sheet is closed, so no thumbnail is decoded then. The drives listing
    // waits on Home and looks at `drives` each time the sheet opens (a drive may be plugged in since).
    // A FolderListModel made with a missing folder lists the working directory instead, so a listing
    // only counts while it really is the folder asked for.
    FolderListModel {
        id: fileList
        folder: Theme.fileUrl(root.folder)
        nameFilters: ["*.jpg", "*.jpeg", "*.png", "*.webp", "*.bmp", "*.gif", "*.tif", "*.tiff"]
        caseSensitive: false
        showDirsFirst: true
        showDotAndDotDot: false
        showHidden: false
        sortField: FolderListModel.Name
        sortCaseSensitive: false
    }
    FolderListModel {
        id: driveList
        folder: Theme.fileUrl(root.visible && root.drives ? root.drives : root.home)
        showFiles: false
        showDotAndDotDot: false
    }
    function listing(m, path) {
        try { return !!path && decodeURIComponent(String(m.folder)) === decodeURIComponent(Theme.fileUrl(path)) }
        catch (e) { return false }
    }
    readonly property var files: listing(fileList, folder) ? fileList : null
    readonly property bool hasDrives: visible && listing(driveList, drives) && driveList.count > 0

    Column {
        width: parent.width
        spacing: 10

        // Places
        Flow {
            width: parent.width
            spacing: 6
            Repeater {
                model: root.places
                Button {
                    required property var modelData
                    text: modelData.label
                    glyph: modelData.glyph
                    size: 30
                    variant: root.place === modelData.path ? "soft" : "ghost"
                    fg: root.place === modelData.path ? Theme.text : Theme.text3
                    onClicked: root.go(modelData.path)
                }
            }
        }

        // Up + where we are
        Row {
            width: parent.width
            height: 30
            spacing: 4
            Button {
                glyph: Icons.up
                size: 30
                variant: "ghost"
                accessibleName: "Up one folder"
                enabled: root.parentFolder !== ""
                onClicked: root.go(root.parentFolder)
            }
            Repeater {
                model: root.crumbs
                Row {
                    id: crumb
                    required property var modelData
                    required property int index
                    readonly property bool last: index === root.crumbs.length - 1
                    height: 30
                    spacing: 4
                    QIcon {
                        visible: crumb.index > 0
                        anchors.verticalCenter: parent.verticalCenter
                        path: Icons.fwd; size: 12; strokeWidth: 2; color: Theme.textFaint
                    }
                    Pressable {
                        anchors.verticalCenter: parent.verticalCenter
                        width: Math.min(crumbText.implicitWidth, 200) + 12; height: 26
                        radius: 8
                        kind: "hov"
                        enabled: !crumb.last
                        cursorShape: crumb.last ? Qt.ArrowCursor : Qt.PointingHandCursor
                        accessibleName: crumb.modelData.label
                        onClicked: root.go(crumb.modelData.path)
                        Text {
                            id: crumbText
                            x: 6; width: Math.min(implicitWidth, 200)
                            anchors.verticalCenter: parent.verticalCenter
                            elide: Text.ElideMiddle
                            text: crumb.modelData.label
                            font.family: Theme.fontUi; font.pixelSize: 13
                            font.weight: crumb.last ? Font.DemiBold : Font.Normal
                            color: crumb.last ? Theme.text : Theme.textMuted
                        }
                    }
                }
            }
        }

        // Folders and pictures
        Item {
            width: parent.width
            height: Math.max(200, Math.min(400, root.height - 290))
            Rectangle { anchors.fill: parent; radius: 14; color: Theme.white(0.025); border.width: 1; border.color: Theme.white(0.06) }
            GridView {
                id: grid
                anchors.fill: parent
                anchors.margins: 6
                clip: true
                boundsBehavior: Flickable.StopAtBounds
                readonly property int cols: Math.max(3, Math.floor(width / 140))
                cellWidth: Math.floor(width / cols)
                cellHeight: Math.round(cellWidth * 0.68) + 34
                model: root.visible ? root.files : null
                Connections { target: root; function onFolderChanged() { grid.positionViewAtBeginning() } }
                delegate: Item {
                    id: cell
                    required property string fileName
                    required property string filePath
                    required property url fileUrl
                    required property bool fileIsDir
                    readonly property bool sel: root.picked === filePath
                    width: grid.cellWidth; height: grid.cellHeight
                    Pressable {
                        anchors.fill: parent
                        anchors.margins: 4
                        radius: 12
                        kind: "plain"
                        color: cell.sel ? Theme.accentTint : "transparent"
                        hoverColor: cell.sel ? Theme.accentTint : Theme.white(0.05)
                        borderWidth: 1.5
                        borderColor: cell.sel ? Theme.accent : "transparent"
                        hoverBorderColor: cell.sel ? Theme.accent : Theme.white(0.12)
                        accessibleName: cell.fileName
                        Accessible.role: cell.fileIsDir ? Accessible.Button : Accessible.RadioButton
                        Accessible.checked: cell.sel
                        onClicked: { if (cell.fileIsDir) root.go(cell.filePath); else root.picked = cell.filePath }
                        onDoubleClicked: if (!cell.fileIsDir) root.chosen(cell.filePath)
                        Rectangle {
                            x: 6; y: 6
                            // From the grid's cell, not this item's own (settling) size: a changed
                            // sourceSize restarts the decode.
                            width: grid.cellWidth - 20; height: grid.cellHeight - 42
                            radius: 8
                            color: cell.fileIsDir ? "transparent" : Theme.white(0.04)
                            clip: true
                            Image {
                                id: thumb
                                anchors.fill: parent
                                visible: !cell.fileIsDir
                                source: cell.fileIsDir || grid.cellWidth < 60 ? "" : cell.fileUrl
                                sourceSize: Qt.size(Math.max(1, grid.cellWidth - 20), Math.max(1, grid.cellHeight - 42))
                                fillMode: Image.PreserveAspectCrop
                                autoTransform: true
                                asynchronous: true
                            }
                            QIcon {
                                anchors.centerIn: parent
                                visible: cell.fileIsDir || thumb.status !== Image.Ready
                                path: cell.fileIsDir ? Icons.folder : Icons.image
                                size: cell.fileIsDir ? 40 : 22
                                strokeWidth: cell.fileIsDir ? 1.6 : 1.9
                                color: cell.fileIsDir ? "#7AB8FF" : Theme.textFaint
                            }
                        }
                        Text {
                            x: 8; y: parent.height - 6 - 18
                            width: parent.width - 16
                            horizontalAlignment: Text.AlignHCenter
                            elide: Text.ElideMiddle
                            text: cell.fileName
                            font.family: Theme.fontUi; font.pointSize: Theme.pt(12)
                            color: cell.sel ? Theme.text : Theme.text3
                        }
                    }
                }
            }
            Rectangle {        // scroll position
                visible: grid.visibleArea.heightRatio < 1
                x: parent.width - 6
                y: 6 + grid.visibleArea.yPosition * grid.height
                width: 3; radius: 1.5
                height: grid.visibleArea.heightRatio * grid.height
                color: Theme.white(0.2)
            }
            Column {
                anchors.centerIn: parent
                visible: !root.files || (root.files.count === 0 && root.files.status !== FolderListModel.Loading)
                spacing: 8
                QIcon { anchors.horizontalCenter: parent.horizontalCenter; path: Icons.image; size: 28; color: Theme.textFaint }
                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    text: "No photos here"
                    font.family: Theme.fontUi; font.pixelSize: 14; font.weight: Font.Medium
                    color: Theme.text3
                }
                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    text: "Try Pictures, Downloads or another folder"
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
                    color: Theme.textDim
                }
            }
        }
    }

    buttons: [
        Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: root.dismissed() },
        Button { text: "Set as wallpaper"; variant: "primary"; size: 38; enabled: root.picked !== ""; onClicked: root.chosen(root.picked) }
    ]
}
