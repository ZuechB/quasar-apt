import QtQuick
import Quickshell
import Quickshell.Io
import Quasar.Services

// What is installed right now: Flatpak apps and runtimes (system + user installations), the Debian
// packages the catalog knows about, and this account's developer tools (mise, read offline through
// /usr/libexec/quasar/quasar-dev status). Refreshed when the Store opens and after every job.
// Developer tools belong to an account: while a company is shown they are that company's.
Scope {
    id: root
    Connections {
        target: Companies
        function onActiveChanged() { if (root.catalog && root.catalog.apps.some(a => a.source === "mise")) devStatus.running = true }
    }
    property var catalog: null
    // app id -> { version, installation, name, origin, scopes: ["system", "user"] } (an app can be in
    // both installations; `installation` is the first one listed)
    property var flatpaks: ({})
    property var runtimes: []          // installed runtime refs, e.g. org.freedesktop.Platform/x86_64/24.08
    property var debs: ({})            // package -> version
    property var tools: ({})           // mise tool -> { versions: [newest first], active: "24.11.1", requested: "24" }
    signal refreshed()

    function refresh() {
        flatpakList.running = true
        runtimeList.running = true
        const pkgs = catalog ? catalog.debianPackages : []
        if (pkgs.length) {
            // A query already running may have an older package list (a .deb page just added its
            // package): ask again when it's done.
            if (dpkgList.running) { dpkgList.again = true }
            else {
                dpkgList.command = ["dpkg-query", "-W", "-f=${Package}\\t${db:Status-Abbrev}\\t${Version}\\n"].concat(pkgs)
                dpkgList.running = true
            }
        }
        if (catalog && catalog.apps.some(a => a.source === "mise")) devStatus.running = true
    }
    function isInstalled(app) {
        if (!app) return false
        if (app.source === "flathub") return !!flatpaks[app.id]
        if (app.source === "mise") return versionsOf(app.tool).length > 0
        const p = app.pkgs || []
        return p.length > 0 && p.every(x => !!debs[x])
    }
    function hasRuntime(ref) { return !!ref && runtimes.indexOf(ref) >= 0 }
    // Which installation an update or removal must use: the one the app is in. In both, the one this
    // account manages (administrators: the system one).
    function scopeOf(id) {
        const f = flatpaks[id]
        if (!f) return Platform.isAdmin ? "system" : "user"
        const s = f.scopes || [f.installation]
        if (s.indexOf("system") >= 0 && (Platform.isAdmin || s.indexOf("user") < 0)) return "system"
        return "user"
    }
    function versionsOf(tool) { const t = tools[tool]; return t ? t.versions : [] }
    function activeOf(tool) { const t = tools[tool]; return t ? t.active : "" }

    // Newest first: compare the numeric parts ("temurin-25.0.1+8" > "temurin-21.0.9+10", "3.13.9" > "3.9.1").
    function _newer(a, b) {
        const na = (a.match(/\d+/g) || []).map(Number), nb = (b.match(/\d+/g) || []).map(Number)
        for (let i = 0; i < Math.max(na.length, nb.length); i++) {
            const d = (nb[i] || 0) - (na[i] || 0)
            if (d !== 0) return d
        }
        return a < b ? -1 : a > b ? 1 : 0
    }

    Process {
        id: flatpakList
        command: ["flatpak", "list", "--app", "--columns=application,name,version,installation,origin"]
        stdout: StdioCollector {
            onStreamFinished: {
                const m = {}
                for (const line of text.split("\n")) {
                    const f = line.split("\t")
                    const id = (f[0] || "").trim()
                    if (!id) continue
                    const inst = (f[3] || "").trim()
                    if (m[id]) {
                        if (m[id].scopes.indexOf(inst) < 0) m[id].scopes.push(inst)
                        continue
                    }
                    m[id] = { name: (f[1] || "").trim(), version: (f[2] || "").trim(), installation: inst,
                              origin: (f[4] || "").trim(), scopes: [inst] }
                }
                root.flatpaks = m
                root.refreshed()
            }
        }
    }
    Process {
        id: runtimeList
        command: ["flatpak", "list", "--runtime", "--columns=ref"]
        stdout: StdioCollector { onStreamFinished: root.runtimes = text.split("\n").map(l => l.trim()).filter(l => l) }
    }
    Process {
        id: dpkgList
        property bool again: false
        stdout: StdioCollector {
            onStreamFinished: {
                const m = {}
                for (const line of text.split("\n")) {
                    const f = line.split("\t")
                    if (f[0] && (f[1] || "").startsWith("ii")) m[f[0]] = f[2] || ""
                }
                root.debs = m
                root.refreshed()
            }
        }
        onExited: if (again) { again = false; Qt.callLater(root.refresh) }
    }
    // `mise ls --json` (run from / so only the account's global default counts as "active"):
    // { "node": [{ "version": "24.11.1", "requested_version": "24", "installed": true, "active": true, … }] }
    Process {
        id: devStatus
        command: Companies.wrapExec(["/usr/libexec/quasar/quasar-dev", "status"])     // the shown company's tools
        stdout: StdioCollector {
            onStreamFinished: {
                const m = {}
                const line = text.split("\n").find(l => l.startsWith("STATUS "))
                try {
                    const o = line ? JSON.parse(line.slice(7)) : {}
                    for (const tool of Object.keys(o)) {
                        const recs = (Array.isArray(o[tool]) ? o[tool] : []).filter(r => r && r.installed && r.version)
                        const versions = []
                        for (const r of recs) if (versions.indexOf(String(r.version)) < 0) versions.push(String(r.version))
                        if (!versions.length) continue
                        const act = recs.find(r => r.active)
                        m[tool] = { versions: versions.sort(root._newer), active: act ? String(act.version) : "",
                                    requested: act && act.requested_version ? String(act.requested_version) : "" }
                    }
                } catch (e) {
                    console.warn("store: unreadable developer tools status:", e)
                }
                root.tools = m
                root.refreshed()
            }
        }
    }
}
