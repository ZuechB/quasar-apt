import QtQuick

// Wi-Fi strength (template: four 3.2px bars, heights 5/8.5/12/16, rounded 1px). Lit bars use
// `color` (accent when connected, #C9CFDC otherwise); unlit bars are white .14.
Item {
    id: root
    property int level: 0              // 0..4
    property color color: Theme.text3
    implicitWidth: 20
    implicitHeight: 16
    Accessible.role: Accessible.Indicator
    Accessible.name: "Signal " + level + " of 4"

    Repeater {
        model: [5, 8.5, 12, 16]
        Rectangle {
            required property int index
            required property real modelData
            x: index * 5.4
            y: root.implicitHeight - modelData
            width: 3.2; height: modelData; radius: 1
            color: index < root.level ? root.color : Theme.white(0.14)
        }
    }
}
