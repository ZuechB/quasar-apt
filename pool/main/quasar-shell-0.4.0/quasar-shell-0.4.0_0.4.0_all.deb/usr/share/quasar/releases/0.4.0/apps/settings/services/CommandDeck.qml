import QtQuick
import Quickshell
import Quasar
import Quasar.Services
import "../components/commanddeck.js" as Deck

// Settings › Command Deck: turn it on (one administrator password: quasar-commanddeck-admin), the code a
// phone scans, the phones, what they may do. deckd answers over its socket (role "settings"); the shell
// starts and stops deckd with Settings.commandDeck.enabled. Phones' keys never come here.
Scope {
    id: root
    property bool active: false                 // the Command Deck page is shown
    signal notify(var banner)
    signal pick(string title, var options, string current, var done, string message)

    readonly property var cfg: Deck.cfg(Settings.commandDeck)
    property var status: null
    property var pairing: ({ url: "", code: "", left: 0 })
    property string busy: ""
    property var client: null
    property int backoff: 0
    property double now: Date.now()
    readonly property bool connected: !!client && !client.dead && status !== null
    readonly property var st: ({ cfg: Settings.commandDeck, status: status, connected: connected, busy: busy, now: now })
    readonly property var ctx: ({ icons: Icons, theme: Theme })
    readonly property var hero: Deck.hero(st, ctx)
    readonly property var groups: Deck.groups(st, ctx)
    readonly property bool canPair: Deck.ready(st)
    readonly property int uid: {
        const m = /\/run\/user\/(\d+)/.exec(Quickshell.env("XDG_RUNTIME_DIR") || "")
        return m ? parseInt(m[1]) : -1
    }

    function patch(p) { Settings.commandDeck = Object.assign({}, Settings.commandDeck || {}, p) }

    // ---- deckd ---------------------------------------------------------------------------------------
    readonly property bool wanted: active && cfg.enabled
    onWantedChanged: { if (wanted) { backoff = 0; connectTimer.restart() } else drop() }
    Timer { id: connectTimer; interval: 300 + Math.min(root.backoff, 8) * 1000; onTriggered: root.connectNow() }
    Timer { interval: 30000; running: root.active; repeat: true; onTriggered: root.now = Date.now() }
    // deckd says when the code changes; the seconds until then count down here.
    Timer {
        interval: 1000; repeat: true
        running: root.active && root.canPair && (root.pairing.left || 0) > 0
        onTriggered: root.pairing = Object.assign({}, root.pairing, { left: Math.max(0, (root.pairing.left || 0) - 1) })
    }
    readonly property Component _clientComponent: Component { DeckClient { } }
    function drop() {
        connectTimer.stop()
        if (client) { client.destroy(); client = null }
        status = null
        pairing = { url: "", code: "", left: 0 }
    }
    function connectNow() {
        if (!wanted || (client && !client.dead)) return
        if (client) client.destroy()
        const c = _clientComponent.createObject(root)
        client = c
        c.event.connect(onEvent)
        c.lost.connect(() => { if (client === c) { status = null; if (wanted) { backoff++; connectTimer.restart() } } })
        c.request({ op: "hello", role: "settings" }, (r) => {
            if (client !== c) return
            if (!r.ok) { backoff++; if (wanted) connectTimer.restart(); return }
            backoff = 0
            status = r
            syncPairing()
        })
    }
    function onEvent(e) {
        if (e.event === "status") { status = e; syncPairing() }
        else if (e.event === "pairing") pairing = e
        else if (e.event === "paired") {
            notify({ tone: "success", title: (e.device && e.device.name ? e.device.name : "Your phone") + " is connected",
                     message: "Add it to the phone's home screen to open Command Deck like an app." })
        }
    }
    // The pairing secret exists only while this page shows the code.
    property bool pairingShown: false
    onCanPairChanged: syncPairing()
    function syncPairing() {
        const want = canPair && active
        if (!client || client.dead || want === pairingShown) return
        pairingShown = want
        client.request({ op: "pairing", show: want }, (r) => { if (r.ok && want) root.pairing = r })
        if (!want) pairing = { url: "", code: "", left: 0 }
    }
    onActiveChanged: { if (!active) pairingShown = false }

    // ---- turning it on: one administrator password (only the first time for this account) -------------
    Privileged {
        id: admin
        helper: "quasar-commanddeck-admin"
        property string why: ""
        onFinished: (code) => {
            const w = why
            why = ""
            root.busy = ""
            let res = null
            for (const l of admin.tail) { try { const o = JSON.parse(l); if (o && o.type) res = o } catch (e) {} }
            if (code === 0 && res && res.type === "result") {
                if (w === "enable" || w === "home") root.patch({ enabled: true })
                if (w === "unregister") root.patch({ enabled: false })
                if (root.client && !root.client.dead) root.client.request({ op: "status" }, (r) => { if (r.ok) root.status = r })
                return
            }
            if (admin.cancelledByUser) return
            root.notify({ tone: "error", title: res && res.message ? res.message : (admin.notAuthorized ? "An administrator has to allow this" : "Command Deck couldn't be turned on"),
                          message: res ? "" : "Details: " + admin.lastLine })
        }
    }
    Cmd {
        id: statusCmd
        onFinished: (code) => {
            let res = null
            for (const l of statusCmd.tail) { try { const o = JSON.parse(l); if (o && o.type === "result") res = o } catch (e) {} }
            if (res && (res.enabled || []).indexOf(root.uid) >= 0) { root.busy = ""; root.patch({ enabled: true }) }
            else { admin.why = "enable"; admin.runHelper(["enable"]) }
        }
    }
    function turnOn() {
        busy = "enable"
        statusCmd.run(["/usr/libexec/quasar/quasar-commanddeck-admin", "status"])
    }
    function heroActivated() {
        const h = hero
        if (!h || !h.button) return
        if (h.button === "Turn on") turnOn()
        else if (h.button === "Continue") { busy = "enable"; admin.why = "enable"; admin.runHelper(["enable"]) }
        else if (h.button === "This is my home network") markHome()
        else if (h.button === "Stop sharing" && client && !client.dead) client.request({ op: "stopScreen" }, null)
        else if (h.button === "Try again" && client && !client.dead) client.request({ op: "status" }, (r) => { if (r.ok) root.status = r })
    }
    function heroToggled() {
        if (cfg.enabled) { patch({ enabled: false }); drop() }
        else turnOn()
    }
    function markHome() {
        const net = (status && status.network) || {}
        if (!net.uuid) return
        busy = "home"
        admin.why = "home"
        admin.runHelper(["enable"], JSON.stringify({ home: net.uuid }) + "\n")
    }

    // ---- rows ---------------------------------------------------------------------------------------
    function toggle(key) {
        if (key === "cd:screen") patch({ screen: !cfg.screen })
        else if (key === "cd:files") patch({ files: !cfg.files })
    }
    function activate(key) {
        if (key === "cd:home") { if (status && status.network && !status.network.home) markHome(); return }
        if (key.startsWith("cd:rm:")) {
            const id = key.slice(6)
            const d = ((status && status.devices) || []).find(x => x.id === id)
            pick("Remove " + (d ? d.name : "this phone") + "?", [{ key: "remove", label: "Remove", sub: "It's disconnected now, and has to scan the code again to come back" }], "",
                 (k) => { if (k === "remove" && client) client.request({ op: "remove", device: id }, null) }, "")
            return
        }
        if (key === "cd:disconnect" && client) client.request({ op: "disconnect" }, null)
        else if (key === "cd:removeAll")
            pick("Remove all phones?", [{ key: "all", label: "Remove all", sub: "Every phone has to scan the code again. Their old keys stop working." }], "",
                 (k) => { if (k === "all" && client) client.request({ op: "removeAll" }, null) }, "")
        else if (key === "cd:unregister")
            pick("Take away Command Deck's access?", [{ key: "off", label: "Take away access", sub: "Turns it off and closes its way in through the firewall. Turning it on again asks an administrator." }], "",
                 (k) => { if (k === "off") { root.busy = "unregister"; admin.why = "unregister"; admin.runHelper(["disable"]) } }, "")
    }
}
