import QtQuick
import Quickshell
import Quickshell.Io
import Quasar
import Quasar.Services
import "../components/displays.js" as D
import "../components/displayLayout.js" as L

// Settings › Display and › Arrange displays, through /usr/libexec/quasar/displays, the only code that
// changes outputs (one wlr-output-management configuration per change).
//  * A change that could leave a display dark (resolution, refresh rate, scale, orientation, turning a
//    display on or off) is *tried*: the helper applies it, and its own watchdog puts the old layout back
//    after 15 s unless Keep is pressed, even when Settings closes or crashes in between.
//  * Moving a display (the arrangement card) applies at once: nothing goes dark.
//  * What's kept is saved in Settings.displays.profiles for the displays connected now (saved before
//    `keep`, so a display plugged in meanwhile can't bring the old layout back); the helper re-applies it
//    at login and when the same displays are plugged in again. "Make main" only saves: the shell moves
//    the desktop icons and notifications there by itself.
Scope {
    id: root
    property bool active: false
    readonly property string helper: Quickshell.env("QUASAR_DISPLAYS") || "/usr/libexec/quasar/displays"
    property var st: null                          // the helper's `state`
    property string selected: ""                   // Arrange displays: the display its rows are about
    readonly property var outputs: D.outputs(st)
    readonly property string mainName: D.mainName(st, (Settings.displays || {}).profiles)
    readonly property var main: D.find(st, mainName) || D.lit(st)[0] || null
    readonly property var sel: D.find(st, selected) || main || outputs[0] || null

    property bool pending: false                   // a tried change waits for Keep or Revert
    property real deadline: 0
    property int countdown: 0
    property var tried: null                       // the layout being tried (what Keep saves)
    signal notify(var banner)
    signal pick(string title, var options, string current, var done, string message)

    function refresh() { if (!query.running) query.running = true }
    onActiveChanged: if (active) refresh()
    Process {
        id: query
        command: [root.helper, "state"]
        stdout: StdioCollector { onStreamFinished: root.take(text) }
    }
    function take(text) {
        const lines = String(text || "").trim().split("\n")
        let s = null
        try { s = JSON.parse(lines[lines.length - 1]) } catch (e) { return }
        if (!s || !s.outputs) return
        root.st = s
        if (!root.selected || !D.find(s, root.selected)) root.selected = root.mainName || (s.outputs[0] ? s.outputs[0].name : "")
    }

    // ---- changes --------------------------------------------------------------------------------------
    // The whole layout with `patch` ({ enabled, mode, scale, transform }) applied to one display, and
    // its neighbours moved to keep touching it (displayLayout.js reflow).
    function target(name, patch) {
        const o = D.find(st, name)
        if (!o) return null
        const layout = D.layoutOf(st)
        if (patch.enabled === false) {
            layout[name] = { enabled: false }
        } else {
            let e = layout[name].enabled ? Object.assign({}, layout[name]) : null
            if (!e) {                                  // turned on: its preferred mode, right of the rest
                const pref = (o.modes || []).find(m => m.preferred) || (o.modes || [])[0]
                if (!pref) return null
                const at = L.placeNew(L.rects(outputs.map(x => Object.assign({}, x, layout[x.name]))))
                e = { enabled: true, mode: [pref.width, pref.height, pref.refresh], x: at.x, y: at.y,
                      scale: o.recommendedScale || 1, transform: "normal" }
            }
            if (patch.mode) e.mode = patch.mode
            if (patch.scale !== undefined) e.scale = patch.scale
            if (patch.transform) e.transform = patch.transform
            layout[name] = e
        }
        const after = L.reflow(L.rects(outputs), L.rects(outputs.map(x => Object.assign({}, x, layout[x.name]))))
        for (const r of after) { layout[r.name].x = r.x; layout[r.name].y = r.y }
        return layout
    }
    function change(name, patch) {
        if (tryCmd.running) return
        const layout = target(name, patch)
        if (!layout) return
        tried = layout
        tryCmd.run([root.helper, "try"], null, JSON.stringify({ outputs: layout }) + "\n")
    }
    Cmd {
        id: tryCmd
        onLine: (l) => {
            let o = null
            try { o = JSON.parse(l) } catch (e) { return }
            if (o.applied) {
                root.deadline = o.deadline
                root.countdown = Math.max(0, Math.ceil(o.deadline - Date.now() / 1000))
                root.pending = true
                tick.restart()
            } else if (o.error) {
                root.tried = null
                root.notify({ tone: "error", title: "The display didn't accept that", message: o.error })
            }
        }
        onFinished: (code) => root.refresh()
    }
    function keep() {
        if (!pending) return
        save(tried)
        pending = false
        tick.stop()
        tried = null
        keepCmd.run([root.helper, "keep"])
    }
    function revert() {
        if (!pending) return
        pending = false
        tick.stop()
        tried = null
        revertCmd.run([root.helper, "revert"])
    }
    Cmd { id: keepCmd; onFinished: (code) => root.refresh() }
    Cmd { id: revertCmd; onFinished: (code) => root.refresh() }
    Timer {
        id: tick
        interval: 1000
        repeat: true
        onTriggered: {
            root.countdown = Math.max(0, Math.ceil(root.deadline - Date.now() / 1000))
            if (root.countdown > 0) return
            stop()                                     // the helper's watchdog has put it back
            root.pending = false
            root.tried = null
            later.restart()
        }
    }
    Timer { id: later; interval: 900; onTriggered: root.refresh() }

    // Dropped on the arrangement card at layout position (x, y), already snapped.
    function moveTo(name, x, y) {
        if (applyCmd.running || pending) return
        const layout = D.layoutOf(st)
        if (!layout[name] || !layout[name].enabled) return
        layout[name].x = Math.round(x)
        layout[name].y = Math.round(y)
        const rs = L.normalize(L.rects(outputs.map(o => Object.assign({}, o, layout[o.name]))))
        for (const r of rs) { layout[r.name].x = r.x; layout[r.name].y = r.y }
        applyCmd.layout = layout
        applyCmd.run([root.helper, "apply"], null, JSON.stringify({ outputs: layout }) + "\n")
    }
    Cmd {
        id: applyCmd
        property var layout: null
        onLine: (l) => {
            let o = null
            try { o = JSON.parse(l) } catch (e) { return }
            if (o.applied) root.save(applyCmd.layout)
            else if (o.error) root.notify({ tone: "error", title: "Couldn't move the display", message: o.error })
        }
        onFinished: (code) => root.refresh()
    }

    function makeMain(name) { if (st) save(D.layoutOf(st), name) }
    function save(layout, mainName) {
        if (!st || !layout) return
        const d = Object.assign({}, Settings.displays || {})
        const profiles = Object.assign({}, d.profiles || {})
        profiles[st.key] = D.profile(st, layout, mainName || root.mainName, Math.floor(Date.now() / 1000))
        d.profiles = profiles
        Settings.displays = d
    }
    // vrr, hdr, taskbarAll: Settings.displays options.
    function setOption(key, value) {
        const d = Object.assign({}, Settings.displays || {})
        d[key] = value
        Settings.displays = d
    }

    // ---- HDR ------------------------------------------------------------------------------------------
    // The switch itself is Settings' labwc layer (LabwcLayer: <hdr>yes</hdr>); the app's toggle handler
    // rewrites it and then runs `displays reapply` through it. HDR works only while the session runs on
    // the Vulkan renderer (quasar-session picks it at sign-in when the layer asks for HDR), and
    // quasar-session leaves a marker when labwc couldn't start on Vulkan this time.
    readonly property string renderer: Quickshell.env("WLR_RENDERER") || ""
    property bool hdrFailed: false
    property bool hdrBusy: false                   // set by the toggle handler until the displays settle
    FileView {
        path: (Quickshell.env("XDG_RUNTIME_DIR") || "/tmp") + "/quasar-hdr-fallback"
        printErrors: false
        onLoaded: root.hdrFailed = true
        onLoadFailed: root.hdrFailed = false
    }
    // After `displays reapply`: the compositor sends the HDR state with the next frame, so the displays'
    // own state (hdrOn) is read once more a moment later.
    function hdrApplied() { refresh(); hdrSettle.restart() }
    Timer { id: hdrSettle; interval: 1200; onTriggered: { root.hdrBusy = false; root.refresh() } }

    // ---- pickers --------------------------------------------------------------------------------------
    function pickResolution(name) {
        const o = D.find(st, name)
        if (!o || !o.mode) return
        root.pick("Resolution", D.resolutions(o), o.mode[0] + "x" + o.mode[1], (k) => {
            const wh = k.split("x").map(Number)
            const m = D.fastest(o, wh[0], wh[1])
            if (m && (m[0] !== o.mode[0] || m[1] !== o.mode[1])) root.change(name, { mode: m })
        }, "")
    }
    function pickRefresh(name) {
        const o = D.find(st, name)
        if (!o || !o.mode) return
        root.pick("Refresh rate", D.refreshRates(o, o.mode[0], o.mode[1]), o.mode[2].toFixed(3), (k) => {
            if (Number(k).toFixed(3) !== o.mode[2].toFixed(3)) root.change(name, { mode: [o.mode[0], o.mode[1], Number(k)] })
        }, "")
    }
    function pickScale(name) {
        const o = D.find(st, name)
        if (!o || !o.mode) return
        root.pick("Scale", D.scales(o), String(o.scale), (k) => {
            if (Number(k) !== o.scale) root.change(name, { scale: Number(k) })
        }, "Makes text, apps and the taskbar bigger or smaller on this display.")
    }
    function pickOrientation(name) {
        const o = D.find(st, name)
        if (!o || !o.mode) return
        root.pick("Orientation", D.orientations(), o.transform || "normal", (k) => {
            if (k !== o.transform) root.change(name, { transform: k })
        }, "Turn the picture to match a display you've rotated on its stand.")
    }

    // Every display shows its number for a moment (the shell draws them).
    function identify() {
        const map = outputs.filter(o => o.enabled).map(o => o.name + "=" + o.number).join(",")
        Quickshell.execDetached(["qs", "--path", "/usr/share/quasar/shell", "ipc", "call", "displays", "identify", map])
    }
}
