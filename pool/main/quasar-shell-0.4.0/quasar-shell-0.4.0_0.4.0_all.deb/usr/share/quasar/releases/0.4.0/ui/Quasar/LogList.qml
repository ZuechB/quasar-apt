import QtQuick

// A live log (Services' consoles and the detail pane's LOGS box): one fixed-height line per entry, newest at
// the bottom. It follows new lines until you scroll up (paused: `newCount` counts what came in meanwhile;
// jumpToEnd() follows again).
//   Lines: { t: unix seconds, m: text, lvl: info|warn|err, src?: "systemd", unit?, user?, acct? }.
//   append(batch) adds a whole batch with one insert. Only the newest `cap` stay. While you're paused
//   nothing is trimmed, so the line you read never moves; it catches up when you follow again.
//   level (all | problems | errors) and query filter into a second model rebuilt from the buffer, so the
//   ListView never makes rows for hidden lines (Qt 6.8 has no QML filter model).
//   showUnit: the combined log's service column. Names come from unitNames[unit]; another account's
//   lines show their company ("Acme: docker.service").
// Pure: no Quickshell. Signals: lineClicked(line) (select it), lineMenu(line, x, y) (right-click, in this
// item's coordinates), unitClicked(line) (the service column).
//   LogList { id: log; anchors.fill: parent }   …   log.append(ev.lines)
Item {
    id: root
    property int cap: 5000
    property string level: "all"
    property string query: ""
    property bool showUnit: false
    property bool compact: false
    property var unitNames: ({})
    property int selectedN: -1
    property string emptyText: "No lines yet."
    property bool following: true
    property int newCount: 0
    readonly property int shownCount: view.count
    property int total: 0                 // lines kept (shown or filtered out)
    signal lineClicked(var line)
    signal lineMenu(var line, real x, real y)
    signal unitClicked(var line)

    property var _buf: []
    property int _seq: 0
    readonly property int rowH: compact ? 19 : 21
    readonly property real fontPt: Theme.pt(compact ? 11.5 : 12)

    // ---- data -------------------------------------------------------------------------------------
    function pad2(x) { return (x < 10 ? "0" : "") + x }
    function clock(ts) { const d = new Date(ts * 1000); return pad2(d.getHours()) + ":" + pad2(d.getMinutes()) + ":" + pad2(d.getSeconds()) }
    function norm(l) {
        _seq++
        const ts = typeof l.t === "number" ? l.t : Date.now() / 1000
        // t: unix seconds, or an already formatted "14:02:11" (previews, older shapes)
        return { n: _seq, ts: ts, t: typeof l.t === "string" && l.t ? l.t : clock(ts), m: String(l.m === undefined ? "" : l.m),
                 lvl: l.lvl === "err" || l.lvl === "warn" ? l.lvl : "info",
                 src: l.src === "systemd" ? "systemd" : "", unit: String(l.unit || ""), user: !!l.user, acct: String(l.acct || "") }
    }
    function matches(l) {
        if (level === "errors" && l.lvl !== "err") return false
        if (level === "problems" && l.lvl === "info") return false
        const q = query.trim().toLowerCase()
        return !q || l.m.toLowerCase().indexOf(q) >= 0 || l.unit.toLowerCase().indexOf(q) >= 0
            || String(unitNames[l.unit] || "").toLowerCase().indexOf(q) >= 0
    }
    readonly property bool filtering: level !== "all" || query.trim() !== ""

    function append(batch) {
        if (!batch || !batch.length) return
        const add = []
        for (const raw of batch) {
            const l = norm(raw)
            _buf.push(l)
            if (!filtering || matches(l)) add.push(l)
        }
        if (add.length) {
            shown.append(add)
            if (!following) newCount += add.length
        }
        trim()
        total = _buf.length
        if (following) Qt.callLater(view.toEnd)
    }
    function trim() {
        if (!following) return
        const extra = _buf.length - cap
        if (extra > 0) {
            const firstKept = _buf[extra].n
            _buf.splice(0, extra)
            let k = 0
            while (k < shown.count && shown.get(k).n < firstKept) k++
            if (k > 0) shown.remove(0, k)
            total = _buf.length
        }
    }
    function rebuild() {
        shown.clear()
        const out = filtering ? _buf.filter(matches) : _buf.slice()
        if (out.length) shown.append(out)
        newCount = 0
        if (following) Qt.callLater(view.toEnd)
    }
    function clear() { _buf = []; total = 0; shown.clear(); newCount = 0; selectedN = -1; following = true }
    function jumpToEnd() { following = true; newCount = 0; trim(); view.toEnd() }
    function lineOf(n) { for (let i = _buf.length - 1; i >= 0; i--) if (_buf[i].n === n) return _buf[i]; return null }
    function nameOf(l) { const nm = unitNames[l.unit] || l.unit.replace(/\.service$/, ""); return l.acct ? l.acct + ": " + nm : nm }
    // The lines on screen as plain text (Copy all): "14:02:11  [service]  text".
    function shownText() {
        const out = []
        const src = filtering ? _buf.filter(matches) : _buf
        for (const l of src) out.push(l.t + "  " + (showUnit ? "[" + nameOf(l) + "]  " : "") + l.m)
        return out.join("\n")
    }
    onLevelChanged: rebuild()
    onQueryChanged: rebuild()

    ListModel { id: shown }

    // ---- view -------------------------------------------------------------------------------------
    Text {
        anchors.centerIn: parent
        width: parent.width - 40
        visible: view.count === 0
        horizontalAlignment: Text.AlignHCenter
        wrapMode: Text.Wrap
        text: root.filtering && root.total ? "No lines match." : root.emptyText
        font.family: Theme.fontMono; font.pointSize: root.fontPt
        color: "#5B6275"
    }

    ListView {
        id: view
        anchors.fill: parent
        clip: true
        model: shown
        boundsBehavior: Flickable.StopAtBounds
        reuseItems: true
        cacheBuffer: root.rowH * 20
        function toEnd() { if (root.following) positionViewAtEnd() }
        // Scrolling up pauses; back at the bottom it follows again.
        onMovementEnded: {
            const end = atYEnd || contentHeight <= height
            if (end && !root.following) root.jumpToEnd()
            else if (!end) root.following = false
        }
        onHeightChanged: if (root.following) Qt.callLater(toEnd)

        delegate: Rectangle {
            id: row
            required property int index
            required property int n
            required property real ts
            required property string t
            required property string m
            required property string lvl
            required property string src
            required property string unit
            required property bool user
            required property string acct
            readonly property bool selected: root.selectedN === n
            width: view.width
            height: root.rowH
            color: selected ? Theme.white(0.08) : hov.hovered && !root.compact ? Theme.white(0.03) : "transparent"
            radius: 4

            HoverHandler { id: hov; enabled: !root.compact }
            Text {
                id: timeText
                x: 6
                anchors.verticalCenter: parent.verticalCenter
                text: row.t
                font.family: Theme.fontMono; font.pointSize: root.fontPt
                color: "#5B6275"
            }
            Item {
                id: unitCol
                visible: root.showUnit
                anchors { left: timeText.right; leftMargin: 10; top: parent.top; bottom: parent.bottom }
                width: root.showUnit ? Math.min(170, Math.max(110, view.width * 0.2)) : 0
                Rectangle {
                    id: dot
                    anchors.verticalCenter: parent.verticalCenter
                    width: 6; height: 6; radius: 3
                    color: Qt.hsla(root.hueOf(row.unit), 0.62, 0.68, 1)
                }
                Text {
                    anchors { left: dot.right; leftMargin: 6; right: parent.right; verticalCenter: parent.verticalCenter }
                    text: root.nameOf(row)
                    textFormat: Text.PlainText
                    elide: Text.ElideRight
                    font.family: Theme.fontMono; font.pointSize: root.fontPt
                    color: unitHit.containsMouse && !row.acct ? Theme.text : Theme.textDim
                    font.underline: unitHit.containsMouse && !row.acct
                }
                MouseArea {
                    id: unitHit
                    anchors.fill: parent
                    enabled: root.showUnit && !row.acct
                    hoverEnabled: true
                    cursorShape: enabled ? Qt.PointingHandCursor : Qt.ArrowCursor
                    onClicked: root.unitClicked(root.lineOf(row.n))
                }
            }
            Rectangle {
                id: tag
                visible: row.src === "systemd"
                anchors { left: root.showUnit ? unitCol.right : timeText.right; leftMargin: 10; verticalCenter: parent.verticalCenter }
                width: visible ? tagText.implicitWidth + 10 : 0
                height: 15; radius: 4
                color: Qt.rgba(185 / 255, 164 / 255, 1, 0.14)
                Text {
                    id: tagText
                    anchors.centerIn: parent
                    text: "systemd"
                    font.family: Theme.fontMono; font.pointSize: Theme.pt(9.5)
                    color: "#B9A4FF"
                }
            }
            Text {
                anchors { left: tag.visible ? tag.right : root.showUnit ? unitCol.right : timeText.right; leftMargin: tag.visible ? 7 : 10
                          right: parent.right; rightMargin: 8; verticalCenter: parent.verticalCenter }
                text: row.m
                textFormat: Text.PlainText
                elide: Text.ElideRight
                maximumLineCount: 1
                font.family: Theme.fontMono; font.pointSize: root.fontPt
                color: row.lvl === "err" ? Theme.danger : row.lvl === "warn" ? Theme.amber
                     : row.src === "systemd" ? "#CDBFFF" : Theme.text3
            }
            MouseArea {
                anchors.fill: parent
                anchors.leftMargin: root.showUnit ? unitCol.x + unitCol.width : 0
                enabled: !root.compact
                acceptedButtons: Qt.LeftButton | Qt.RightButton
                onClicked: (e) => {
                    const l = root.lineOf(row.n)
                    if (!l) return
                    root.selectedN = row.n
                    if (e.button === Qt.RightButton) {
                        const p = mapToItem(root, e.x, e.y)
                        root.lineMenu(l, p.x, p.y)
                    } else root.lineClicked(l)
                }
            }
        }
    }
    OverlayScrollBar { flick: view }

    // A stable colour per service for the combined log's column.
    function hueOf(unit) {
        let h = 0
        for (let i = 0; i < unit.length; i++) h = (h * 31 + unit.charCodeAt(i)) % 360
        return h / 360
    }
}
