import QtQuick
import Quasar
import "services.js" as S

// The whole Services window body (template data-win="svc" minus the title bar): the 208px filter
// sidebar, the list (search, summary, groups) and the 372px detail aside, plus the internet play guide
// (a page over the list and the aside) and the folder chooser. Pure: everything comes in through `m`
// (built by shell.qml or preview/ServicesPreview.qml) and goes out through act(name, a, b, c).
//   m.items [ITEM] (PROTOCOL.md), m.now (ms), m.filter, m.query, m.selectedKey, m.loaded, m.live, m.lan,
//   m.firewall, m.netguard, m.adding, m.editing, m.draft, m.inspecting, m.inspectError, m.saving,
//   m.formError, m.busy, m.error {key, message, details}, m.confirm {key, what: remove|update},
//   m.updating {key: true}, m.copy {key, running, percent, error}, m.logs [{n, t, m, lvl}], m.stats,
//   m.players, m.guide, m.dns {checking, result}, m.home, m.drives, m.company, m.hover (previews)
//   Every service on this PC (filter "pc", components/AllServices.qml): m.unitSelKey, m.unitsFull (the last full
//   `units` event, for a list made later), m.unitsError; changes arrive through unitsEvent(ev). m.logs then holds
//   the selected unit's lines. Consoles open through act("openConsole", key) ("*" = every service).
Item {
    id: root
    property var m: ({})
    signal act(string name, var a, var b, var c)
    function call(name, a, b, c) { root.act(name, a === undefined ? null : a, b === undefined ? null : b, c === undefined ? null : c) }

    readonly property var items: m.items || []
    readonly property real now: m.now || Date.now()
    readonly property var sel: S.selected(items, m.selectedKey || "")
    readonly property var byKey: {
        const o = {}
        for (const it of items) o[it.key] = it
        return o
    }
    readonly property real asideW: Math.min(372, Math.round(0.42 * (root.width - nav.width)))

    // Copy to the clipboard (addresses, router values).
    TextEdit { id: clip; visible: false; textFormat: TextEdit.PlainText }
    function copyText(s) { clip.text = s; clip.selectAll(); clip.copy() }

    // ---------------------------------------------------------------- sidebar: Add a service + filters
    Item {
        id: nav
        anchors { left: parent.left; top: parent.top; bottom: parent.bottom }
        width: 208
        Rectangle { anchors { right: parent.right; top: parent.top; bottom: parent.bottom } width: 1; color: Theme.white(0.05) }

        Column {
            x: 10; y: 12
            width: parent.width - 20
            spacing: 2

            Button {
                width: parent.width
                size: 40
                radius: 12
                variant: "primary"
                text: "Add a service"
                glyph: Icons.plus
                enabled: !root.m.live
                onClicked: root.call("openAdd")
            }
            Item { width: 1; height: 8 }

            Repeater {
                model: S.filters(root.items, root.m.filter || "all")
                delegate: Pressable {
                    id: f
                    required property var modelData
                    width: parent.width
                    height: 36
                    radius: 10
                    kind: "hov"
                    color: modelData.on ? Theme.white(0.08) : "transparent"
                    hoverColor: modelData.on ? Theme.white(0.08) : Theme.white(0.07)
                    accessibleName: modelData.label + ", " + modelData.count
                    Accessible.role: Accessible.PageTab
                    Accessible.selected: modelData.on
                    onClicked: root.call("filter", modelData.key)
                    QIcon {
                        id: fIcon
                        x: 10
                        anchors.verticalCenter: parent.verticalCenter
                        path: Icons[f.modelData.icon]
                        size: 16; strokeWidth: 1.9
                        color: f.modelData.on ? Theme.accent : f.modelData.warn ? "#FF8F8F" : Theme.textDim
                    }
                    Text {
                        anchors { left: fIcon.right; leftMargin: 10; right: pill.left; rightMargin: 8; verticalCenter: parent.verticalCenter }
                        text: f.modelData.label
                        elide: Text.ElideRight
                        font.family: Theme.fontUi; font.pixelSize: 13; font.weight: Font.Medium
                        color: f.modelData.on ? Theme.text : Theme.textMuted
                    }
                    Rectangle {
                        id: pill
                        anchors { right: parent.right; rightMargin: 8; verticalCenter: parent.verticalCenter }
                        height: 20; radius: 10
                        width: Math.max(20, countText.implicitWidth + 12)
                        color: f.modelData.warn ? "#FF8F8F" : Theme.white(0.08)
                        Text {
                            id: countText
                            anchors.centerIn: parent
                            text: f.modelData.count
                            font.family: Theme.fontUi; font.pixelSize: 11; font.weight: Font.DemiBold
                            color: f.modelData.warn ? Theme.accentInk : Theme.textMuted
                        }
                    }
                }
            }

            // Everything systemd runs on this PC, not only what Services manages (its own list and stream).
            Rectangle { width: parent.width; height: 1; color: Theme.white(0.05); visible: true }
            Item { width: 1; height: 4 }
            Pressable {
                id: everyEntry
                readonly property bool on: root.m.filter === "pc"
                width: parent.width
                height: 36
                radius: 10
                kind: "hov"
                color: on ? Theme.white(0.08) : "transparent"
                hoverColor: on ? Theme.white(0.08) : Theme.white(0.07)
                accessibleName: "Every service on this PC"
                Accessible.role: Accessible.PageTab
                Accessible.selected: on
                onClicked: root.call("filter", "pc")
                QIcon {
                    id: everyIcon
                    x: 10
                    anchors.verticalCenter: parent.verticalCenter
                    path: Icons.server
                    size: 16; strokeWidth: 1.9
                    color: everyEntry.on ? Theme.accent : Theme.textDim
                }
                Text {
                    anchors { left: everyIcon.right; leftMargin: 10; right: parent.right; rightMargin: 8; verticalCenter: parent.verticalCenter }
                    text: "Every service"
                    elide: Text.ElideRight
                    font.family: Theme.fontUi; font.pixelSize: 13; font.weight: Font.Medium
                    color: everyEntry.on ? Theme.text : Theme.textMuted
                }
            }
        }

        Text {
            anchors { left: parent.left; right: parent.right; bottom: parent.bottom; leftMargin: 14; rightMargin: 14; bottomMargin: 14 }
            text: "Each server runs as its own account, from its own folder. Quasar’s own services are marked System. Logs come from journald."
            wrapMode: Text.Wrap
            lineHeight: 1.15
            font.family: Theme.fontUi; font.pointSize: Theme.pt(11.5)
            color: Theme.textFaint
        }
    }

    // ---------------------------------------------------------------- every service on this PC (filter "pc")
    readonly property bool every: m.filter === "pc"
    Loader {
        id: everyLoader
        anchors { left: nav.right; right: aside.left; top: parent.top; bottom: parent.bottom }
        active: root.every
        visible: active
        sourceComponent: AllServices {
            items: root.items
            selectedKey: root.m.unitSelKey || ""
            error: root.m.unitsError || ""
            hover: root.m.hover || ""
            onSelect: (k) => root.call("selectUnit", k)
            onOpenConsole: (k) => root.call("openConsole", k)
            onOpenTerminal: (k) => root.call("openTerminal", k)
            onOpenEvery: root.call("openConsole", "*")
            onRetry: root.call("unitsRetry")
            Component.onCompleted: if (root.m.unitsFull) apply(root.m.unitsFull)
        }
    }
    // services-query units events from shell.qml (the full list, then changes).
    function unitsEvent(ev) { if (everyLoader.item) everyLoader.item.apply(ev) }
    readonly property var unitRow: {
        const v = everyLoader.item
        if (!v || !m.unitSelKey) return null
        v.rev                                // re-read on every change of the list
        return v.rowOf(m.unitSelKey)
    }

    // ---------------------------------------------------------------- the list
    Item {
        id: middle
        visible: !root.every
        anchors { left: nav.right; right: aside.left; top: parent.top; bottom: parent.bottom }

        Item {
            id: toolbar
            width: parent.width
            height: 58
            Rectangle { anchors.bottom: parent.bottom; width: parent.width; height: 1; color: Theme.white(0.05) }
            SearchField {
                id: search
                x: 14
                anchors.verticalCenter: parent.verticalCenter
                width: Math.max(160, Math.min(260, toolbar.width - 28 - summary.implicitWidth - 12))
                implicitHeight: 34
                placeholder: "Search services"
                text: root.m.query || ""
                onEdited: (t) => root.call("query", t)
            }
            Text {
                id: summary
                anchors { left: search.right; leftMargin: 12; right: parent.right; rightMargin: 14; verticalCenter: parent.verticalCenter }
                text: S.summary(root.items, root.now)
                textFormat: Text.PlainText
                elide: Text.ElideRight
                font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
                color: Theme.textMuted
            }
        }

        // Keyed: a header per group ("g:<kind>") and a row per service. A state update rebinds the rows
        // instead of making them again (no re-entrance, no flicker); only new keys animate in.
        ListModel { id: listModel }
        readonly property var groups: S.groups(root.items, root.m.filter || "all", root.m.query || "")
        readonly property var keys: {
            const out = []
            for (const g of groups) { out.push("g:" + g.key); for (const r of g.rows) out.push(r.key) }
            return out
        }
        readonly property var groupLabels: {
            const o = {}
            for (const g of groups) o["g:" + g.key] = g.label
            return o
        }
        function syncKeys(keys) {
            const want = new Set(keys)
            for (let i = listModel.count - 1; i >= 0; i--) if (!want.has(listModel.get(i).itemKey)) listModel.remove(i)
            for (let i = 0; i < keys.length; i++) {
                if (i < listModel.count && listModel.get(i).itemKey === keys[i]) continue
                let j = i + 1
                while (j < listModel.count && listModel.get(j).itemKey !== keys[i]) j++
                if (j < listModel.count) listModel.move(j, i, 1)
                else listModel.insert(i, { itemKey: keys[i] })
            }
        }
        onKeysChanged: syncKeys(keys)
        Component.onCompleted: syncKeys(keys)

        ScrollPane {
            id: list
            anchors { left: parent.left; right: parent.right; top: toolbar.bottom; bottom: parent.bottom }
            topPadding: 4
            bottomPadding: 16
            Column {
                x: 10
                width: list.width - 20
                Repeater {
                    model: listModel
                    delegate: Loader {
                        id: cell
                        required property string itemKey
                        required property int index
                        width: parent.width
                        readonly property bool header: itemKey.indexOf("g:") === 0
                        sourceComponent: header ? headerComp : rowComp
                        readonly property int order: Math.min(11, Math.max(0, index))
                    }
                }
            }
        }
        Component {
            id: headerComp
            Item {
                height: 35
                Text {
                    x: 8; y: 14
                    text: middle.groupLabels[parent.parent ? parent.parent.itemKey : ""] || ""
                    font.family: Theme.fontMono; font.pointSize: Theme.pt(10.5); font.letterSpacing: 1.05
                    color: Theme.textFaint
                }
            }
        }
        Component {
            id: rowComp
            Item {
                id: rowHost
                readonly property string key: parent ? parent.itemKey : ""
                height: 59
                ServiceRow {
                    width: rowHost.width
                    order: rowHost.parent ? rowHost.parent.order : 0
                    item: root.byKey[rowHost.key] || ({})
                    now: root.now
                    selected: !root.m.adding && !!root.sel && root.sel.key === rowHost.key
                    forceHover: root.m.hover === rowHost.key
                    onSelect: root.call("select", rowHost.key)
                    onToggle: root.call("toggle", rowHost.key)
                    onOpenConsole: root.call("openConsole", rowHost.key)
                }
            }
        }

        Text {
            visible: root.m.loaded !== false && middle.groups.length === 0
            anchors { horizontalCenter: list.horizontalCenter; top: toolbar.bottom; topMargin: 40 }
            text: root.items.length === 0 ? "Nothing runs in the background yet." : "No services match."
            font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
            color: Theme.textDim
        }
        Spinner {
            visible: root.m.loaded === false
            anchors { horizontalCenter: list.horizontalCenter; top: toolbar.bottom; topMargin: 44 }
            size: 18
        }
    }

    // ---------------------------------------------------------------- the detail aside
    Item {
        id: aside
        anchors { right: parent.right; top: parent.top; bottom: parent.bottom }
        width: root.asideW
        Rectangle { anchors { left: parent.left; top: parent.top; bottom: parent.bottom } width: 1; color: Theme.white(0.05) }

        ScrollPane {
            id: asidePane
            property string shownKey: ""
            anchors.fill: parent
            anchors.leftMargin: 1
            topPadding: 18
            bottomPadding: 22
            Item {
                x: 18
                width: asidePane.width - 36
                height: panel.item ? panel.item.implicitHeight : 0
                Loader {
                    id: panel
                    width: parent.width
                    sourceComponent: root.m.adding ? addComp : root.m.editing && root.sel && root.sel.server ? editComp
                                   : root.every ? (root.unitRow ? unitComp : unitEmptyComp)
                                   : root.sel ? detailComp : emptyComp
                    // A new panel (or another service) starts at its top.
                    onSourceComponentChanged: asidePane.contentY = 0
                }
                Connections {
                    target: root
                    function onSelChanged() { if (root.sel && root.sel.key !== asidePane.shownKey) { asidePane.shownKey = root.sel.key; asidePane.contentY = 0 } }
                }
            }
        }
    }

    Component {
        id: addComp
        AddService {
            mode: "add"
            m: root.m
            onAct: (name, a, b, c) => root.act(name, a, b, c)
            onBrowse: { chooser.mode = "add"; chooser.open = true }
        }
    }
    Component {
        id: editComp
        AddService {
            mode: "edit"
            m: root.m
            item: root.sel
            onAct: (name, a, b, c) => root.act(name, a, b, c)
            onBrowse: { chooser.mode = "edit"; chooser.open = true }
        }
    }
    Component {
        id: detailComp
        ServiceDetail {
            item: root.sel
            m: root.m
            now: root.now
            onAct: (name, a, b, c) => root.act(name, a, b, c)
            onCopy: (s) => root.copyText(s)
            onCopyFrom: (archive) => { chooser.mode = archive ? "copyArchive" : "copyFolder"; chooser.open = true }
        }
    }
    Component {
        id: unitComp
        UnitDetail {
            row: root.unitRow
            m: root.m
            onAct: (name, a, b, c) => root.act(name, a, b, c)
        }
    }
    Component {
        id: unitEmptyComp
        Item {
            implicitHeight: 140
            Text {
                y: 60
                width: parent.width
                horizontalAlignment: Text.AlignHCenter
                text: "Pick a service to see how it's doing and what it writes."
                wrapMode: Text.Wrap
                font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
                color: Theme.textDim
            }
        }
    }
    Component {
        id: emptyComp
        Item {
            implicitHeight: emptyCol.y + emptyCol.implicitHeight
            Column {
                id: emptyCol
                y: root.items.length === 0 ? 40 : 60
                width: parent.width
                spacing: 14
                AppTile {
                    visible: root.items.length === 0
                    anchors.horizontalCenter: parent.horizontalCenter
                    size: 50; radius: 15
                    glyph: Icons.gamepad
                    glyphSize: 24; glyphStroke: 1.8
                    hue: "#FF8FB1"
                }
                Text {
                    width: parent.width
                    horizontalAlignment: Text.AlignHCenter
                    text: root.items.length === 0 ? "Host a game server, or any program other people connect to." : "Pick a service to see its details."
                    wrapMode: Text.Wrap
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
                    color: root.items.length === 0 ? Theme.text2 : Theme.textDim
                }
                Text {
                    visible: root.items.length === 0
                    width: parent.width
                    horizontalAlignment: Text.AlignHCenter
                    text: "It runs in the background as its own account, from the folder you pick, and you decide who can join."
                    wrapMode: Text.Wrap
                    lineHeight: 1.15
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
                    color: Theme.textDim
                }
                Button {
                    visible: root.items.length === 0 && !root.m.live
                    anchors.horizontalCenter: parent.horizontalCenter
                    variant: "primary"; size: 38; glyph: Icons.plus; text: "Add a service"
                    onClicked: root.call("openAdd")
                }
            }
        }
    }

    // ---------------------------------------------------------------- internet play guide (a page)
    Loader {
        id: guideLoader
        anchors { left: nav.right; right: parent.right; top: parent.top; bottom: parent.bottom }
        active: !!root.m.guide && !!root.sel && !!root.sel.server
        visible: active
        sourceComponent: InternetGuide {
            item: root.sel
            m: root.m
            now: root.now
            onAct: (name, a, b, c) => root.act(name, a, b, c)
            onCopy: (s) => root.copyText(s)
        }
    }

    // ---------------------------------------------------------------- folder / archive chooser
    FileChooser {
        id: chooser
        property string mode: "add"           // add | edit | copyFolder | copyArchive
        folders: mode !== "copyArchive"
        nameFilters: mode === "copyArchive" ? ["*.zip", "*.7z", "*.tar", "*.tar.gz", "*.tgz", "*.tar.xz", "*.txz", "*.tar.zst", "*.rar"] : ["*"]
        kindText: mode === "copyArchive" ? "archives" : "files"
        title: mode === "copyFolder" ? "Copy the new build from a folder"
             : mode === "copyArchive" ? "Copy the new build from an archive"
             : "Choose the server’s folder"
        message: mode === "copyFolder" ? "Pick the folder Unity made, like Builds/Server/Linux. Everything in it is copied into the server’s folder."
               : mode === "copyArchive" ? "Pick the .zip of the new build. It’s unpacked into the server’s folder."
               : "Pick the folder with the server’s program, like the Linux build Unity made."
        home: root.m.home || ""
        drives: root.m.drives || ""
        // Home itself or a folder above it can't be a server's folder (it would run your whole home).
        allowFolder: (p) => mode === "copyFolder" ? p !== "/" : (p !== "/" && p !== chooser.home && !chooser.home.startsWith(p + "/"))
        onOpenChanged: {
            if (!open) return
            const d = root.m.draft
            const path = mode === "edit" && root.sel && root.sel.server ? root.sel.server.path : d && d.path ? d.path : ""
            folder = path && (mode === "add" || mode === "edit") ? (path.slice(0, path.lastIndexOf("/")) || "/") : (mode === "copyArchive" ? chooser.home + "/Downloads" : chooser.home)
        }
        onChosen: (p) => {
            chooser.open = false
            if (mode === "add" || mode === "edit") root.call("pick", p, mode)
            else if (root.sel) root.call("copyIn", root.sel.key, p, mode === "copyArchive")
        }
        onDismissed: chooser.open = false
    }
}
