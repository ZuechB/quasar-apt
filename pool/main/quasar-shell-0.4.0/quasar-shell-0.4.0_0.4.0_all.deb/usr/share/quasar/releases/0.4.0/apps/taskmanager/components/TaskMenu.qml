import QtQuick
import Quasar

// Task Manager's right-click menu: Quasar's ContextMenu inside the window, kept inside it. A click outside or
// Esc closes it (like Files' FileMenu, without flyouts).   items: ContextMenu items; show(x, y)
Item {
    id: root
    anchors.fill: parent
    property bool open: false
    property real menuX: 0
    property real menuY: 0
    property var items: []
    signal chosen(string key)
    signal dismissed()

    function show(x, y) { menuX = x; menuY = y; open = true; card.forceActiveFocus() }
    function close() { open = false }

    visible: open
    z: 900

    MouseArea {
        anchors.fill: parent
        acceptedButtons: Qt.AllButtons
        onPressed: root.dismissed()
        onWheel: (w) => root.dismissed()
    }
    MouseArea { x: card.x; y: card.y; width: card.width; height: card.height; acceptedButtons: Qt.AllButtons }
    ContextMenu {
        id: card
        x: Math.max(6, Math.min(root.menuX, root.width - width - 6))
        y: root.menuY + height > root.height - 6 ? Math.max(6, root.menuY - height) : root.menuY
        width: implicitWidth
        height: implicitHeight
        items: root.items
        focus: true
        onActivated: (key) => root.chosen(key)
        Keys.onEscapePressed: root.dismissed()
        Accessible.role: Accessible.PopupMenu
    }
}
