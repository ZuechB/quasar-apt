import QtQuick

// Quick-settings slider (brightness/volume): 44px pill, light fill grows from the left, icon in a
// "difference" colour (dark over the fill, white over the track). Drag, click, wheel, arrow keys.
Item {
    id: root
    property real value: 50          // 0..100
    property string icon: Icons.sun
    property string accessibleName: ""
    signal moved(real value)

    implicitHeight: 44
    activeFocusOnTab: true
    Accessible.role: Accessible.Slider
    Accessible.name: accessibleName
    Keys.onLeftPressed: root.moved(Math.max(0, root.value - 5))
    Keys.onRightPressed: root.moved(Math.min(100, root.value + 5))

    readonly property real _fillW: Math.round(width * Math.max(0, Math.min(100, value)) / 100)
    property bool _dragging: false

    Rectangle {
        anchors.fill: parent
        radius: 14
        color: Theme.white(0.07)
    }
    // Fill: rounded left end, straight right edge (container is overflow:hidden in the mockup).
    Item {
        id: fill
        width: root._fillW
        height: parent.height
        Behavior on width { enabled: !root._dragging; NumberAnimation { duration: Motion.dur(Motion.fade) } }
        Rectangle {
            width: Math.max(28, fill.width); height: parent.height; radius: 14
            color: Theme.fillLight
            visible: fill.width > 0
        }
        Rectangle {
            x: Math.max(0, fill.width - 14); width: Math.min(14, fill.width); height: parent.height
            color: Theme.fillLight
            visible: fill.width > 14 && fill.width < root.width - 14
        }
    }
    QIcon {
        x: 14
        anchors.verticalCenter: parent.verticalCenter
        path: root.icon
        size: 18
        strokeWidth: 2
        color: fill.width > 24 ? "#191510" : "#FFFFFF"
    }
    Rectangle {
        anchors.fill: parent; anchors.margins: -4; radius: 18
        color: "transparent"; border.width: 2; border.color: Theme.accent
        visible: root.activeFocus
    }
    MouseArea {
        anchors.fill: parent
        cursorShape: Qt.PointingHandCursor
        function set(mx) { root.moved(Math.round(Math.max(0, Math.min(1, mx / width)) * 100)) }
        onPressed: (e) => { root._dragging = true; set(e.x) }
        onPositionChanged: (e) => { if (pressed) set(e.x) }
        onReleased: root._dragging = false
        onCanceled: root._dragging = false
        onWheel: (w) => root.moved(Math.max(0, Math.min(100, root.value + (w.angleDelta.y > 0 ? 5 : -5))))
    }
}
