import QtQuick

// The visible app window (template <section data-win>): a rounded plate (14px) with a 1px hairline
// (white .15 focused / .07 not), a deep soft shadow and a 1px dark outline when focused, the title
// bar, the content and an invisible resize band. Maximized or fullscreen: square, edge to edge, no
// hairline, shadow or band.
//
// This item's own size is the visible frame. The shadow, the outline and the resize band are drawn
// outside it, so the host leaves `shadowMargins` around it (AppWindow: Qt custom margins, outside
// the window geometry the compositor sees). Pure view: the host turns the signals into
// startSystemMove()/startSystemResize(), minimize, maximize and close.
//
//   WindowFrame { x: 48; y: 26; width: 1020; height: 680; title: "Settings"; glyph: Icons.gear
//                 active: true; SettingsView { anchors.fill: parent } }
Item {
    id: root
    property bool active: true                   // focused window
    property bool maximized: false
    property bool fullscreen: false
    readonly property bool docked: maximized || fullscreen
    property bool resizable: true
    property bool rounded: true                  // false: the host can't make corners transparent
    property bool shadow: true                   // the host has room for it (GPU path); Lite hides it anyway
    property int band: 8                         // resize band outside the frame; 0 = none
    readonly property int bandRoom: 8            // the margin a host keeps for the band
    property color background: Theme.windowOpaque
    readonly property real radius: docked || !rounded ? 0 : Theme.windowRadius

    // Title bar
    property string title: ""
    property string glyph: ""
    property color glyphColor: Theme.text3
    property color titleTint: "transparent"
    property Item titleItem: null
    property int titleBarHeight: 46
    property alias titleBar: bar
    default property alias content: body.data

    signal moveRequested()
    signal minimizeClicked()
    signal maximizeClicked()
    signal closeClicked()
    signal resizeRequested(int edges)

    // The template's shadows (focused `0 40px 100px -28px rgba(0,0,0,.95)`, unfocused
    // `0 18px 50px -26px rgba(0,0,0,.85)`), tightened so they fade out within a margin the window
    // can afford: every frame of a GPU window repaints its whole surface, margin included.
    readonly property var shadowFocused: ({ y: 22, blur: 48, spread: -14, alpha: 0.85 })
    readonly property var shadowUnfocused: ({ y: 12, blur: 32, spread: -14, alpha: 0.7 })
    // Room the shadow and the resize band need around the frame. The surface cuts the shadow off
    // where it is under ~0.5% alpha (2.6 sigma, sigma = blur/2): one grey level on white, invisible.
    // (At 2.2 sigma the cut showed as a faint box on a white wallpaper.)
    readonly property var shadowMargins: {   // { left: 49, top: 27, right: 49, bottom: 71 }
        const m = { left: bandRoom, top: bandRoom, right: bandRoom, bottom: bandRoom }
        for (const s of [shadowFocused, shadowUnfocused]) {
            const reach = 1.3 * s.blur + s.spread
            m.left = Math.max(m.left, Math.ceil(reach))
            m.right = Math.max(m.right, Math.ceil(reach))
            m.top = Math.max(m.top, Math.ceil(reach - s.y))
            m.bottom = Math.max(m.bottom, Math.ceil(reach + s.y))
        }
        return m
    }

    Shadow {
        target: plate
        visible: root.shadow && !root.docked && Theme.profile > 0
        radius: root.radius
        readonly property var spec: root.active ? root.shadowFocused : root.shadowUnfocused
        offsetY: spec.y
        blur: spec.blur
        spread: spec.spread
        color: Qt.rgba(0, 0, 0, spec.alpha)
        Behavior on offsetY { NumberAnimation { duration: Motion.dur(300) } }
        Behavior on blur { NumberAnimation { duration: Motion.dur(300) } }
        Behavior on color { ColorAnimation { duration: Motion.dur(300) } }
    }

    // Template: `0 0 0 1px rgba(0,0,0,.5)` on the focused window, a crisp edge on light wallpapers.
    Rectangle {
        anchors.fill: plate
        anchors.margins: -1
        visible: !root.docked
        radius: root.radius + 1
        color: "transparent"
        border.width: 1
        border.color: Qt.rgba(0, 0, 0, 0.5)
        opacity: root.active ? 1 : 0
        Behavior on opacity { NumberAnimation { duration: Motion.dur(300) } }
    }

    Rectangle {
        id: plate
        anchors.fill: parent
        radius: root.radius
        color: root.background
    }

    WindowTitleBar {
        id: bar
        width: parent.width
        height: root.titleBarHeight
        cornerRadius: root.radius
        leadingItem: root.titleItem
        title: root.title
        glyph: root.glyph
        glyphColor: root.glyphColor
        tint: root.titleTint
        active: root.active
        maximized: root.maximized
        showMaximize: root.resizable
        onMoveRequested: root.moveRequested()
        onMinimizeClicked: root.minimizeClicked()
        onMaximizeClicked: root.maximizeClicked()
        onCloseClicked: root.closeClicked()
    }

    // Content. Clipped to the frame (a rectangle), so a menu's shadow can't spill into the
    // window's transparent margin. Full-bleed fills that reach the bottom corners round them
    // (Theme.windowCorner); nothing else here paints into them.
    Item {
        id: body
        anchors { top: bar.bottom; left: parent.left; right: parent.right; bottom: parent.bottom }
        clip: true
    }

    // Hairline, over the content like the template's border.
    Rectangle {
        anchors.fill: parent
        visible: !root.docked
        radius: root.radius
        color: "transparent"
        border.width: 1
        border.color: root.active ? Theme.white(0.15) : Theme.white(0.07)
        Behavior on border.color { ColorAnimation { duration: Motion.dur(300) } }
    }

    ResizeGrip {
        anchors { right: parent.right; bottom: parent.bottom }
        visible: root.resizable && !root.docked
        onResizeRequested: root.resizeRequested(Qt.RightEdge | Qt.BottomEdge)
    }

    ResizeEdges {
        anchors.fill: parent
        anchors.margins: -root.band
        band: root.band
        visible: root.resizable && !root.docked && root.band > 0
        onResizeRequested: (edges) => root.resizeRequested(edges)
    }
}
