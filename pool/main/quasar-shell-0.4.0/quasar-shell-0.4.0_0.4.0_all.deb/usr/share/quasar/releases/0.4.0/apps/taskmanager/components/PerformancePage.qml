import QtQuick
import Quasar
import "tm.js" as TM

// Task Manager › Performance: the devices on the left (each with a minute of history), the picked one's
// graph and figures on the right. Pure view: `info`/`tick` are sysmon's, `history` holds 60 samples per
// history key (TM.devices / TM.detail name them; apps/taskmanager/services/SysMon.qml keeps them).
Item {
    id: root
    property var info: null
    property var tick: null
    property var history: ({})
    property string selected: "cpu"
    signal picked(string key)

    readonly property var devices: TM.devices(info, tick)
    readonly property var current: TM.detail(devices.some(d => d.key === selected) ? selected : "cpu", info, tick)

    // ---- devices ---------------------------------------------------------------------------------------
    ListView {
        id: list
        x: 10; y: 10
        width: 250
        height: parent.height - 20
        clip: true
        spacing: 4
        boundsBehavior: Flickable.StopAtBounds
        model: root.devices
        delegate: Pressable {
            id: tile
            required property var modelData
            width: list.width
            implicitHeight: 64
            radius: 12
            kind: "hov"
            color: root.selected === modelData.key ? Theme.white(0.08) : "transparent"
            accessibleName: modelData.title + ", " + modelData.value
            onClicked: root.picked(modelData.key)
            Rectangle {
                x: 0; anchors.verticalCenter: parent.verticalCenter
                width: 3; height: 34; radius: 2
                visible: root.selected === tile.modelData.key
                color: tile.modelData.hue
            }
            Sparkline {
                id: spark
                x: 12; anchors.verticalCenter: parent.verticalCenter
                width: 64; height: 34
                values: root.history[tile.modelData.spark] || []
                floor: tile.modelData.kind === "net" ? 1024 : 100
                color: tile.modelData.hue
                lineWidth: 1.4
                Rectangle { anchors.fill: parent; color: "transparent"; border.width: 1; border.color: Theme.white(0.08); radius: 4 }
            }
            Column {
                anchors { left: spark.right; leftMargin: 12; right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter }
                spacing: 1
                Text { width: parent.width; text: tile.modelData.title; elide: Text.ElideRight; font.family: Theme.fontUi; font.pointSize: Theme.pt(13); font.weight: Font.Medium; color: Theme.text }
                Text { width: parent.width; text: tile.modelData.sub; visible: text !== ""; elide: Text.ElideRight; textFormat: Text.PlainText; font.family: Theme.fontUi; font.pointSize: Theme.pt(11); color: Theme.textFaint }
                Text { width: parent.width; text: tile.modelData.value; elide: Text.ElideRight; font.family: Theme.fontUi; font.pointSize: Theme.pt(11.5); font.features: { "tnum": 1 }; color: Theme.text3 }
            }
        }
    }
    Rectangle { x: list.x + list.width + 10; y: 0; width: 1; height: parent.height; color: Theme.white(0.06) }

    // ---- the picked device -----------------------------------------------------------------------------
    Item {
        id: detail
        readonly property var d: root.current
        x: list.x + list.width + 11
        width: parent.width - x
        height: parent.height
        visible: d !== null

        Text {
            id: title
            x: 24; y: 18
            text: detail.d ? detail.d.title : ""
            font.family: Theme.fontDisplay; font.pixelSize: 24; font.weight: Font.Medium
            color: Theme.text
        }
        Text {
            anchors { left: title.right; leftMargin: 14; right: parent.right; rightMargin: 24; baseline: title.baseline }
            horizontalAlignment: Text.AlignRight
            text: detail.d ? detail.d.sub : ""
            elide: Text.ElideRight
            textFormat: Text.PlainText
            font.family: Theme.fontUi; font.pointSize: Theme.pt(13)
            color: Theme.textDim
        }
        Row {
            id: legend
            x: 24; y: title.y + title.height + 10
            spacing: 16
            height: 16
            Text {
                visible: !(detail.d && detail.d.legend)
                text: detail.d && detail.d.graph.unit === "pct" ? "% over the last minute" : "Over the last minute"
                font.family: Theme.fontUi; font.pointSize: Theme.pt(11); color: Theme.textFaint
            }
            Repeater {
                model: detail.d && detail.d.legend ? detail.d.legend : []
                Row {
                    required property var modelData
                    spacing: 6
                    Rectangle { width: 10; height: 3; radius: 1.5; anchors.verticalCenter: parent.verticalCenter; color: parent.modelData[1] }
                    Text { text: parent.modelData[0]; font.family: Theme.fontUi; font.pointSize: Theme.pt(11); color: Theme.textDim }
                }
            }
        }
        LineGraph {
            id: graph
            x: 24; y: legend.y + legend.height + 8
            width: parent.width - 48
            height: Math.max(140, Math.min(260, parent.height * 0.42))
            max: detail.d ? detail.d.graph.max : 100
            floor: 1024
            series: detail.d ? detail.d.graph.series.map(s => ({ values: root.history[s.key] || [], color: s.color })) : []
        }
        // Memory: what it's used for, in one bar (in use, cached, free).
        Rectangle {
            id: bar
            visible: !!(detail.d && detail.d.bar)
            x: 24; y: graph.y + graph.height + 14
            width: graph.width; height: visible ? 10 : 0
            radius: 5
            color: Theme.white(0.06)
            Rectangle { width: parent.width * (detail.d && detail.d.bar ? detail.d.bar.used : 0); height: parent.height; radius: 5; color: "#B9A4FF" }
            Rectangle {
                x: parent.width * (detail.d && detail.d.bar ? detail.d.bar.used : 0)
                width: parent.width * (detail.d && detail.d.bar ? detail.d.bar.cached : 0); height: parent.height
                color: Theme.alpha("#B9A4FF", 0.35)
            }
        }
        Text {
            id: note
            visible: text !== ""
            x: 24; y: (bar.visible ? bar.y + bar.height : graph.y + graph.height) + 10
            width: graph.width
            wrapMode: Text.Wrap
            text: detail.d && detail.d.note ? detail.d.note : ""
            font.family: Theme.fontUi; font.pointSize: Theme.pt(11.5); color: Theme.textFaint
        }
        // The figures, in two columns.
        Grid {
            x: 24; y: (note.visible ? note.y + note.height : bar.visible ? bar.y + bar.height : graph.y + graph.height) + 18
            width: graph.width
            columns: width > 560 ? 3 : 2
            columnSpacing: 28
            rowSpacing: 14
            Repeater {
                model: detail.d ? detail.d.stats : []
                Column {
                    required property var modelData
                    width: Math.floor((graph.width - 28 * (parent.columns - 1)) / parent.columns)
                    spacing: 2
                    Text { text: parent.modelData[0]; font.family: Theme.fontUi; font.pointSize: Theme.pt(11.5); color: Theme.textDim }
                    Text {
                        width: parent.width
                        text: parent.modelData[1]
                        elide: Text.ElideRight
                        textFormat: Text.PlainText
                        font.family: Theme.fontDisplay; font.pixelSize: 17; font.features: { "tnum": 1 }
                        color: Theme.text
                    }
                }
            }
        }
    }
}
