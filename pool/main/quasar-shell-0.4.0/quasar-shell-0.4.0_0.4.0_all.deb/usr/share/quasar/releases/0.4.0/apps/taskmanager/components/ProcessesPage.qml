import QtQuick
import Quasar
import "tm.js" as TM

// Task Manager › Processes. Pure view: `rows` come from TM.rows() (apps, background programs, each company,
// the system; an expanded group lists its processes), `totals` from TM.totals().
// The list is a ListModel of slots that only grows or shrinks at its end, each delegate reading rows[index]:
// a new tick every second then repaints the numbers without recreating a single row (or jumping the list
// back to the top), and the selection is a key, so it stays on its app when the order changes.
// Keys: Up/Down pick, Right/Left (or Enter) open and close a group, Delete ends the picked task.
Item {
    id: root
    property var rows: []
    property var totals: ({})
    property real memTotal: 0               // bytes: how warm a Memory cell gets
    property string selected: ""            // a row key
    property var sort: ({ col: "cpu", desc: true })
    property bool busy: false               // an ending is under way
    signal picked(string key)
    signal toggled(string key)
    signal sortBy(string col)
    signal searched(string text)
    signal endRequested(string key)
    signal safeRequested()
    signal menuRequested(string key, real x, real y)

    readonly property var selRow: rows.find(r => r.key === selected) || null
    readonly property var plan: TM.endPlan(selRow)

    // Columns (right-aligned numbers) and how warm a cell gets at "full".
    readonly property var cols: [
        { key: "cpu", label: "CPU", w: 78, total: TM.pct(totals.cpu), text: (r) => TM.pct(r.cpu), heat: (r) => TM.heat(r.cpu, 40) },
        { key: "mem", label: "Memory", w: 94, total: TM.pct(totals.mem), text: (r) => r.mem === null || r.mem === undefined ? "—" : TM.bytes(r.mem),
          heat: (r) => TM.heat(r.mem, Math.max(1, root.memTotal * 0.2)) },
        { key: "disk", label: "Disk", w: 94, total: TM.pct(totals.disk), text: (r) => TM.rate(r.disk), heat: (r) => TM.heat(r.disk, 40e6) },
        { key: "net", label: "Network", w: 94, total: totals.net === null || totals.net === undefined ? "" : TM.bits(totals.net),
          text: (r) => r.type === "proc" ? "" : TM.bits(r.net), heat: (r) => TM.heat(r.net, 2e6) },
        { key: "gpu", label: "GPU", w: 70, total: TM.pct(totals.gpu), text: (r) => TM.pct(r.gpu), heat: (r) => TM.heat(r.gpu, 40) }
    ]
    readonly property real colsWidth: cols.reduce((s, c) => s + c.w, 0)

    function glyphOf(g) {
        return ({ desktop: Icons.home, window: Icons.layers, company: Icons.brief, system: Icons.server, user: Icons.users,
                  unit: Icons.gear, process: Icons.cube })[g] || g || ""      // else: an icon path already (an app's)
    }
    function move(d) {
        const keys = rows.filter(r => r.type !== "section").map(r => r.key)
        if (!keys.length) return
        const i = keys.indexOf(selected)
        picked(keys[Math.max(0, Math.min(keys.length - 1, i < 0 ? 0 : i + d))])
        const at = rows.findIndex(r => r.key === root.selected)
        if (at >= 0) list.positionViewAtIndex(at, ListView.Contain)
    }

    ListModel { id: slots }
    onRowsChanged: {
        while (slots.count < rows.length) slots.append({})
        while (slots.count > rows.length) slots.remove(slots.count - 1)
    }

    focus: true
    Keys.onUpPressed: move(-1)
    Keys.onDownPressed: move(1)
    Keys.onRightPressed: if (selRow && selRow.expandable && !selRow.expanded) toggled(selected)
    Keys.onLeftPressed: if (selRow && selRow.expanded) toggled(selected)
    Keys.onReturnPressed: if (selRow && selRow.expandable) toggled(selected)
    Keys.onDeletePressed: if (plan && !busy) endRequested(selected)

    // ---- top: search, and what the picked row can do -----------------------------------------------------
    Row {
        id: bar
        x: 16; y: 12
        width: parent.width - 32
        spacing: 8
        SearchField {
            id: search
            width: Math.min(280, bar.width - actions.width - 8)
            placeholder: "Search apps and processes"
            onEdited: (t) => root.searched(t)
            onEscapePressed: { text = ""; root.searched(""); root.forceActiveFocus() }
        }
        Item { width: bar.width - search.width - actions.width - 16; height: 1 }
        Row {
            id: actions
            spacing: 8
            Button {
                visible: !!root.plan && root.plan.how === "restart"
                text: "Restart with safe graphics"; variant: "outline"; size: 34
                onClicked: root.safeRequested()
            }
            Button {
                text: root.plan ? root.plan.verb : "End task"
                glyph: root.plan && root.plan.how === "restart" ? Icons.refresh : Icons.x
                variant: root.plan && root.plan.how !== "restart" ? "primary" : "soft"
                tone: Theme.danger
                size: 34
                enabled: !!root.plan && !root.busy
                busy: root.busy
                opacity: enabled || root.busy ? 1 : 0.45
                onClicked: root.endRequested(root.selected)
            }
        }
    }

    // ---- column headers (click to sort) ------------------------------------------------------------------
    Item {
        id: head
        x: 8; y: bar.y + bar.height + 12
        width: parent.width - 16
        height: 44
        Pressable {
            x: 0; width: parent.width - root.colsWidth; height: parent.height
            kind: "hov"; radius: 8; color: "transparent"
            accessibleName: "Sort by name"
            onClicked: root.sortBy("name")
            Text {
                x: 14; anchors.bottom: parent.bottom; anchors.bottomMargin: 7
                text: "Name" + (root.sort.col === "name" ? (root.sort.desc ? "  ↓" : "  ↑") : "")
                font.family: Theme.fontUi; font.pointSize: Theme.pt(12); color: Theme.text3
            }
        }
        Row {
            anchors.right: parent.right
            height: parent.height
            Repeater {
                model: root.cols
                Pressable {
                    id: hdr
                    required property var modelData
                    width: modelData.w; height: head.height
                    kind: "hov"; radius: 8; color: "transparent"
                    accessibleName: "Sort by " + modelData.label
                    onClicked: root.sortBy(modelData.key)
                    Column {
                        anchors { right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter }
                        Text {
                            anchors.right: parent.right
                            text: hdr.modelData.total || " "
                            font.family: Theme.fontDisplay; font.pixelSize: 15; font.weight: Font.Medium
                            color: Theme.text
                        }
                        Text {
                            anchors.right: parent.right
                            text: hdr.modelData.label + (root.sort.col === hdr.modelData.key ? (root.sort.desc ? " ↓" : " ↑") : "")
                            font.family: Theme.fontUi; font.pointSize: Theme.pt(11.5); color: Theme.text3
                        }
                    }
                }
            }
        }
        Rectangle { anchors.bottom: parent.bottom; width: parent.width; height: 1; color: Theme.white(0.06) }
    }

    // ---- the list ----------------------------------------------------------------------------------------
    ListView {
        id: list
        anchors { top: head.bottom; topMargin: 4; left: parent.left; leftMargin: 8; right: parent.right; rightMargin: 8; bottom: parent.bottom; bottomMargin: 6 }
        clip: true
        boundsBehavior: Flickable.StopAtBounds
        model: slots
        reuseItems: true
        delegate: Item {
            id: line
            required property int index
            readonly property var r: root.rows[index] || ({ type: "section", label: "" })
            readonly property bool isSection: r.type === "section"
            width: list.width
            height: isSection ? 34 : 38

            SectionLabel {
                visible: line.isSection
                x: 14; anchors.bottom: parent.bottom; anchors.bottomMargin: 8
                text: line.r.label
            }

            Pressable {
                id: cell
                visible: !line.isSection
                anchors.fill: parent
                radius: 8
                kind: "hov"
                color: root.selected === line.r.key ? Theme.white(0.08) : "transparent"
                accessibleName: line.r.label + ", CPU " + TM.pct(line.r.cpu)
                onClicked: { root.picked(line.r.key); root.forceActiveFocus() }
                onRightClicked: (x, y) => {
                    root.picked(line.r.key)
                    root.forceActiveFocus()
                    const p = cell.mapToItem(root, x, y)
                    root.menuRequested(line.r.key, p.x, p.y)
                }
                onDoubleClicked: if (line.r.expandable) root.toggled(line.r.key)

                // Chevron (a group with processes; its click area is above the row, see below), icon, name.
                Item {
                    id: chev
                    x: 4
                    width: 22; height: parent.height
                    visible: line.r.type === "group"
                    QIcon {
                        anchors.centerIn: parent
                        visible: !!line.r.expandable
                        path: Icons.chev
                        size: 14; strokeWidth: 2
                        color: Theme.textDim
                        rotation: line.r.expanded ? 0 : -90          // the glyph points down: closed = right
                        Behavior on rotation { NumberAnimation { duration: Motion.dur(140) } }
                    }
                }
                AppTile {
                    id: icon
                    x: line.r.type === "proc" ? 34 : 28
                    anchors.verticalCenter: parent.verticalCenter
                    size: line.r.type === "proc" ? 20 : 24
                    glyph: line.r.image ? "" : root.glyphOf(line.r.glyph)
                    image: line.r.image || ""
                    letter: (line.r.label || "?").charAt(0).toUpperCase()
                    hue: line.r.hue || Theme.text3
                    glyphSize: line.r.type === "proc" ? 11 : 13
                }
                Row {
                    anchors { left: icon.right; leftMargin: 10; right: nums.left; rightMargin: 8; verticalCenter: parent.verticalCenter }
                    spacing: 8
                    clip: true
                    Text {
                        id: name
                        width: Math.min(implicitWidth, parent.width)
                        text: line.r.label || ""
                        elide: Text.ElideRight
                        textFormat: Text.PlainText
                        font.family: Theme.fontUi; font.pointSize: Theme.pt(line.r.type === "proc" ? 12.5 : 13)
                        color: line.r.type === "proc" ? Theme.text2 : Theme.text
                    }
                    Text {
                        width: Math.max(0, parent.width - name.width - 8)
                        text: line.r.sub || ""
                        elide: Text.ElideRight
                        textFormat: Text.PlainText
                        font.family: Theme.fontUi; font.pointSize: Theme.pt(11.5)
                        color: Theme.textFaint
                        anchors.baseline: name.baseline
                    }
                }
                Row {
                    id: nums
                    anchors.right: parent.right
                    height: parent.height
                    Repeater {
                        model: root.cols
                        Rectangle {
                            required property var modelData
                            width: modelData.w; height: line.height
                            color: Theme.alpha(Theme.amber, line.isSection ? 0 : modelData.heat(line.r))
                            Text {
                                anchors { right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter }
                                text: line.isSection ? "" : parent.modelData.text(line.r)
                                font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
                                font.features: { "tnum": 1 }
                                color: Theme.text2
                            }
                        }
                    }
                }
            }
            // The chevron opens and closes the group (a Pressable's own mouse area sits above its content,
            // so this one is a sibling on top of the row).
            MouseArea {
                x: 0; width: 28; height: parent.height
                visible: !line.isSection && !!line.r.expandable
                cursorShape: Qt.PointingHandCursor
                onClicked: { root.picked(line.r.key); root.forceActiveFocus(); root.toggled(line.r.key) }
            }
        }
        Text {
            visible: root.rows.length === 0
            anchors.centerIn: parent
            text: "Nothing matches your search."
            font.family: Theme.fontUi; font.pointSize: Theme.pt(13)
            color: Theme.textDim
        }
    }
}
