import QtQuick
import Quasar

// Template Sites › Overview cards ("Address", "App"): a titled card of label/value rows (label 11px
// faint, value 12.5px, mono for paths and commands), plus an optional slot under the rows.
Rectangle {
    id: root
    property string title: ""
    property var facts: []             // [{ label, value, mono }]
    default property alias extra: slot.data

    implicitHeight: col.implicitHeight
    radius: 18
    color: Theme.white(0.035)
    border.width: 1; border.color: Theme.white(0.06)

    Column {
        id: col
        width: parent.width
        Text {
            leftPadding: 14; topPadding: 12; bottomPadding: 8
            text: root.title
            font.family: Theme.fontUi; font.pixelSize: 13; font.weight: Font.DemiBold
            color: Theme.text
        }
        Repeater {
            model: root.facts
            delegate: Item {
                required property var modelData
                width: col.width
                height: fc.implicitHeight + 16
                Rectangle { anchors { left: parent.left; right: parent.right; top: parent.top } height: 1; color: Theme.white(0.05) }
                Column {
                    id: fc
                    anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; leftMargin: 14; rightMargin: 14 }
                    spacing: 3
                    Text { text: modelData.label; font.family: Theme.fontUi; font.pixelSize: 11; color: Theme.textFaint }
                    TextEdit {
                        width: parent.width
                        readOnly: true
                        selectByMouse: true
                        text: modelData.value
                        textFormat: TextEdit.PlainText
                        wrapMode: modelData.mono ? TextEdit.WrapAnywhere : TextEdit.Wrap
                        font.family: modelData.mono ? Theme.fontMono : Theme.fontUi
                        font.pointSize: Theme.pt(12.5)
                        color: "#DDE2EC"
                        selectionColor: Theme.alpha(Theme.accent, 0.35)
                    }
                }
            }
        }
        Item {
            id: slot
            width: col.width
            height: childrenRect.height
        }
    }
}
