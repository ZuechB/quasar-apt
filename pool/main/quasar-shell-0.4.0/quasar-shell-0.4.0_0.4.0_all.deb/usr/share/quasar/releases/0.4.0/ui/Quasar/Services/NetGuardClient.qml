import QtQuick
import Quickshell
import Quickshell.Io

// One connection to quasar-netguard (/run/quasar/netguard.sock): the per-app half of the firewall.
// JSON lines, see /usr/lib/quasar/netguard/quasar_netguard/server.py. The service answers for the user
// who connects (the kernel says who that is), so a request never names a user.
//   request(obj, onReply(r))  e.g. { op: "usage" }, { op: "block", key: "app:org.foo" }, { op: "recent" }
//   event(obj)                after { op: "subscribe" }: { event: "prompt", key, label, app, kind, port,
//                             proto, from, network: { uuid, name, home, state } | null, allowed }
//   lost()                    the connection closed; every unanswered request got { ok: false }.
// A Socket that failed doesn't connect again: owners make a new NetGuardClient after `dead`.
// QUASAR_NETGUARD_SOCK points it elsewhere (tests: tools/fake-netguard.py).
Socket {
    id: root
    path: Quickshell.env("QUASAR_NETGUARD_SOCK") || "/run/quasar/netguard.sock"

    property int _seq: 0
    property var _pending: ({})
    property var _queue: []
    property bool dead: false
    signal event(var obj)
    signal lost()

    parser: SplitParser { onRead: (line) => root._received(line) }

    function request(obj, onReply) {
        const id = ++_seq
        _pending[id] = onReply || null
        const line = JSON.stringify(Object.assign({}, obj, { id: id })) + "\n"
        if (connected) { write(line); flush(); return id }
        _queue.push(line)
        if (_queue.length === 1) connected = true
        return id
    }

    function _failAll(why) {
        const pending = _pending
        _pending = {}
        _queue = []
        for (const id in pending) if (pending[id]) pending[id]({ ok: false, error: why })
    }
    onConnectionStateChanged: {
        if (connected) {
            for (const l of _queue) write(l)
            _queue = []
            flush()
        } else {
            dead = true
            _failAll("The network guard isn't running")
            lost()
        }
    }
    onError: (e) => { if (!connected) { dead = true; _failAll("The network guard isn't running") } }

    function _received(line) {
        let r
        try { r = JSON.parse(line) } catch (e) { return }
        if (r === null || typeof r !== "object") return
        if (r.id === undefined || r.id === null) { event(r); return }
        const cb = _pending[r.id]
        delete _pending[r.id]
        if (cb) cb(r)
    }
}
