import QtQuick
import Quickshell
import Quickshell.Io
import Quasar.Services

// The Quasar-managed labwc layer (~/.config/quasar/xdg/labwc/rc.xml, merged by `labwc -m`;
// ~/.config/labwc stays the user's own). Settings is its only writer and rewrites it whole from
// settings.json whenever one of its options changes, then labwc reloads its configuration (`labwc -r`,
// using LABWC_PID from the session):
//  * Keyboard & Input: pointer and keyboard options (Settings.input).
//  * Display: variable refresh rate (Settings.displays.vrr, default on). The default lives in the
//    lower layers: /etc/xdg's "fullscreen" (adaptive sync on a display while a full-screen window is
//    on it: games, video; the desktop keeps a steady rate, like Windows and KDE) and the software
//    path's "no" (xdg-software: no GPU, no VRR). So this layer only ever writes "no", when VRR is
//    turned off: writing "fullscreen" here would override the software path's "no".
//  * Display: HDR (Settings.displays.hdr, default off): <hdr>yes</hdr> while it's on. quasar-session
//    looks for exactly that text at sign-in to start labwc on the Vulkan renderer, and labwc reads it
//    only when it sets a display up, so a change in a running session is followed by `displays reapply`
//    (apply's `after`).
Scope {
    id: root
    property var input: ({})               // Settings.input: { naturalScroll, tap, speed (-1..1), flat, repeatRate, repeatDelay }
    property var displays: ({})            // Settings.displays: { vrr, hdr }
    readonly property string dir: (Quickshell.env("XDG_CONFIG_HOME") || (Quickshell.env("HOME") + "/.config")) + "/quasar/xdg/labwc"

    function xml(o, d) {
        const b = (v) => v ? "yes" : "no"
        const speed = Math.max(-1, Math.min(1, o.speed !== undefined ? o.speed : 0)).toFixed(2)
        const core = (d.vrr === false ? "    <adaptiveSync>no</adaptiveSync>\n" : "")
                   + (d.hdr === true ? "    <hdr>yes</hdr>\n" : "")
        return "<?xml version=\"1.0\"?>\n<!-- Written by Quasar Settings (Keyboard & Input, Display). Edit ~/.config/labwc/rc.xml for your own overrides. -->\n"
            + "<labwc_config>\n"
            + (core ? "  <core>\n" + core + "  </core>\n" : "")
            + "  <keyboard>\n    <repeatRate>" + (o.repeatRate || 40) + "</repeatRate>\n    <repeatDelay>" + (o.repeatDelay || 250) + "</repeatDelay>\n  </keyboard>\n"
            + "  <libinput>\n    <device category=\"default\">\n"
            + "      <naturalScroll>" + b(!!o.naturalScroll) + "</naturalScroll>\n"
            + "      <tap>" + b(o.tap !== false) + "</tap>\n"
            + "      <middleEmulation>no</middleEmulation>\n"
            + "      <pointerSpeed>" + speed + "</pointerSpeed>\n"
            + "      <accelProfile>" + (o.flat ? "flat" : "adaptive") + "</accelProfile>\n"
            + "    </device>\n  </libinput>\n</labwc_config>\n"
    }
    // Rewrites the layer and reloads labwc. after (optional): a command (array) run once labwc has
    // reloaded; done(code) is called when it ends.
    function apply(after, done) {
        const script = "mkdir -p \"$1\" && printf '%s' \"$2\" > \"$1/rc.xml.tmp\" && mv \"$1/rc.xml.tmp\" \"$1/rc.xml\" && labwc -r"
        const args = ["sh", root.dir, root.xml(root.input || {}, root.displays || {})]
        if (!after) {
            Quickshell.execDetached(["sh", "-c", script].concat(args))
            return
        }
        // labwc -r only signals labwc: give it a moment to reload before the displays are set up again.
        job.done = done || null
        job.run(["sh", "-c", script + " && sleep 0.3 && shift 2 && exec \"$@\""].concat(args, after))
    }
    Cmd {
        id: job
        property var done: null
        onFinished: (code) => { const d = job.done; job.done = null; if (d) d(code) }
    }
}
