import QtQuick

// Sidebar row (template Store/Settings <nav>): 36px, radius 10, 16px glyph, 13.5px label.
// Selected: white .08 fill and bright text (Settings also tints the glyph accent: accentIcon).
// badge: count pill in the accent colour (Store "Updates"). separator: a 1px divider row instead.
Pressable {
    id: root
    property string label: ""
    property string glyph: ""
    property bool selected: false
    property string badge: ""
    property bool accentIcon: false
    property color idleText: Theme.textMuted
    property int labelWeight: Font.Medium
    property bool separator: false

    kind: separator ? "plain" : "hov"
    enabled: !separator
    radius: 10
    implicitHeight: separator ? 17 : 36
    implicitWidth: 190
    color: selected ? Theme.white(0.08) : "transparent"
    hoverColor: selected ? Theme.white(0.08) : Theme.white(0.07)
    accessibleName: label
    Accessible.role: Accessible.PageTab
    Accessible.selected: selected

    Rectangle {
        visible: root.separator
        anchors.centerIn: parent
        width: parent.width - 12; height: 1
        color: Theme.white(0.06)
    }

    QIcon {
        id: icon
        visible: !root.separator && root.glyph !== ""
        x: 10
        anchors.verticalCenter: parent.verticalCenter
        path: root.glyph; size: 16; strokeWidth: 1.9
        color: root.accentIcon ? (root.selected ? Theme.accent : Theme.textDim)
                               : (root.selected ? Theme.text : root.idleText)
    }
    Text {
        visible: !root.separator
        anchors { left: icon.right; leftMargin: root.accentIcon ? 11 : 10; right: pill.visible ? pill.left : parent.right; rightMargin: 8; verticalCenter: parent.verticalCenter }
        text: root.label
        elide: Text.ElideRight
        font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5); font.weight: root.labelWeight
        color: root.selected ? Theme.text : root.idleText
    }
    Rectangle {
        id: pill
        visible: !root.separator && root.badge !== ""
        anchors { right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter }
        height: 20; radius: 10
        width: Math.max(20, badgeText.implicitWidth + 12)
        color: Theme.accent
        Text {
            id: badgeText
            anchors.centerIn: parent
            text: root.badge
            font.family: Theme.fontUi; font.pixelSize: 11; font.weight: Font.DemiBold
            color: Theme.accentInk
        }
    }
}
