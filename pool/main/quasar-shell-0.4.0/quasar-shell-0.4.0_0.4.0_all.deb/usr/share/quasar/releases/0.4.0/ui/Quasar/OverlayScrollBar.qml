import QtQuick

// ScrollPane's thin overlay scrollbar for any Flickable, including GridView/ListView pages whose header
// puts the start of the content at a negative originY (the Store's app lists). It appears while
// scrolling (or hovered) and fades out; no timers or animations run while idle.
//   GridView { id: grid; … OverlayScrollBar { flick: grid } }
Rectangle {
    id: bar
    required property Flickable flick
    readonly property real minY: flick.originY - flick.topMargin
    readonly property real maxY: flick.originY + flick.contentHeight + flick.bottomMargin - flick.height
    readonly property real span: flick.contentHeight + flick.topMargin + flick.bottomMargin

    parent: flick
    z: 10
    visible: maxY - minY > 1
    x: flick.width - width - 3
    y: 3 + (maxY > minY ? (flick.contentY - minY) / (maxY - minY) : 0) * (flick.height - 6 - height)
    width: barArea.containsMouse || barArea.pressed ? 6 : 4
    height: Math.max(28, flick.height / Math.max(1, span) * (flick.height - 6))
    radius: width / 2
    color: Theme.white(barArea.pressed ? 0.32 : 0.22)
    opacity: flick.moving || barArea.containsMouse || barArea.pressed || fade.running ? 1 : 0
    Behavior on opacity { NumberAnimation { duration: Motion.dur(220) } }
    Behavior on width { NumberAnimation { duration: Motion.dur(120) } }

    MouseArea {
        id: barArea
        anchors.fill: parent
        anchors.margins: -4
        hoverEnabled: true
        property real grabY: 0
        property real grabContentY: 0
        onPressed: (e) => { grabY = mapToItem(bar.flick, e.x, e.y).y; grabContentY = bar.flick.contentY }
        onPositionChanged: (e) => {
            if (!pressed) return
            const dy = mapToItem(bar.flick, e.x, e.y).y - grabY
            const range = bar.maxY - bar.minY
            bar.flick.contentY = Math.max(bar.minY, Math.min(bar.maxY, grabContentY + dy / Math.max(1, bar.flick.height - 6 - bar.height) * range))
        }
    }
    // Keep the bar visible for a moment after wheel scrolling (the wheel does not set `moving`).
    Timer { id: fade; interval: 700 }
    Connections {
        target: bar.flick
        function onContentYChanged() { fade.restart() }
    }
}
