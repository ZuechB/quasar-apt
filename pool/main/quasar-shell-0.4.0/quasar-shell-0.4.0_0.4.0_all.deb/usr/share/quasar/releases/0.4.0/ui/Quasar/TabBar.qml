import QtQuick

// Underlined tabs (template Sites › site sections): a 40px row with a hairline underneath; each tab
// is 13px/600 text with 14px side padding, and the current one gets a 2px accent bar (inset 10px).
//   TabBar { model: ["Overview", "Deployments"]; currentIndex: 0; onPicked: (i) => … }
Item {
    id: root
    property var model: []
    property int currentIndex: 0
    signal picked(int index)

    implicitHeight: 40
    implicitWidth: row.implicitWidth
    Accessible.role: Accessible.PageTabList

    Rectangle {
        anchors { left: parent.left; right: parent.right; bottom: parent.bottom }
        height: 1
        color: Theme.white(0.07)
    }

    Row {
        id: row
        height: parent.height
        spacing: 2
        Repeater {
            model: root.model
            delegate: Item {
                id: tab
                required property int index
                required property var modelData
                readonly property bool current: index === root.currentIndex
                width: label.implicitWidth + 28
                height: row.height
                Accessible.role: Accessible.PageTab
                Accessible.name: String(modelData)
                Accessible.focusable: true
                Accessible.onPressAction: root.picked(index)

                Text {
                    id: label
                    anchors.centerIn: parent
                    text: String(tab.modelData)
                    textFormat: Text.PlainText
                    font.family: Theme.fontUi; font.pixelSize: 13; font.weight: Font.DemiBold
                    color: tab.current ? Theme.text : (mouse.containsMouse ? Theme.text3 : Theme.textDim)
                    Behavior on color { ColorAnimation { duration: Motion.dur(Motion.hover) } }
                }
                Rectangle {
                    anchors { left: parent.left; right: parent.right; bottom: parent.bottom; leftMargin: 10; rightMargin: 10 }
                    height: 2; radius: 2
                    color: Theme.accent
                    opacity: tab.current ? 1 : 0
                    Behavior on opacity { NumberAnimation { duration: Motion.dur(250) } }
                }
                MouseArea {
                    id: mouse
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: root.picked(tab.index)
                }
            }
        }
    }
}
