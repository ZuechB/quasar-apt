import QtQuick
import "qrcodegen.js" as QR

// A QR code for `text`, drawn as an SVG (one path, crisp at any size, and the software backend renders
// it: no shader, no Canvas). Dark modules on a white tile with the standard 4-module quiet zone, so any
// phone camera reads it on a dark page. Empty or too-long text shows nothing.
Item {
    id: root
    property string text: ""
    property string ecl: "M"               // L M Q H
    property color dark: "#05060A"
    property color light: "#FFFFFF"
    property real radius: 14
    readonly property var symbol: text ? QR.encode(text, { ecl: ecl }) : null
    readonly property int modules: symbol ? symbol.size + 8 : 0

    implicitWidth: 220
    implicitHeight: 220

    Rectangle {
        anchors.fill: parent
        radius: root.radius
        color: root.light
        visible: !!root.symbol
    }
    Image {
        anchors.fill: parent
        anchors.margins: Math.max(0, root.radius * 0.3)
        visible: !!root.symbol
        smooth: false
        mipmap: false
        fillMode: Image.PreserveAspectFit
        cache: false
        sourceSize: Qt.size(Math.max(1, Math.round(width)), Math.max(1, Math.round(height)))
        source: {
            if (!root.symbol) return ""
            const n = root.modules
            const svg = "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 " + n + " " + n + "' shape-rendering='crispEdges'>"
                      + "<path fill='" + root.dark + "' d='" + QR.svgPath(root.symbol, 4) + "'/></svg>"
            return "data:image/svg+xml;utf8," + encodeURIComponent(svg)
        }
    }
}
