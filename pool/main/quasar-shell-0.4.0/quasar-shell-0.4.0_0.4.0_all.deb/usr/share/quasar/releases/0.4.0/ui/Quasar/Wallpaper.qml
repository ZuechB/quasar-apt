import QtQuick

// Procedural wallpaper (deep | aurora | graphite) rendered by one fragment shader, or the user's own
// photo (kind "photo": Theme.wallpaperPhoto, filled or fitted per Theme.wallpaperFit).
// Performance rules: time advances on a capped-FPS timer only while animated and visible;
// Lite / reduced motion / paused => a single static frame. Graphite and photos never animate.
// Qt's software scene graph (no GPU) cannot run shaders: there the wallpaper is a still image that
// tools/render-wallpapers.py renders from the same shader (wallpapers/<kind>-<accent>.jpg).
// A photo that can't be read (deleted, not a picture) falls back to Deep field.
Item {
    id: root
    property string kind: "deep"
    property bool animated: Theme.ambientMotion && kind !== "graphite"
    property bool paused: false                    // set when covered (fullscreen/maximized), idle or locked
    property int fps: Theme.profile >= 2 ? 60 : 30
    property bool lowDetail: false                 // procedural-glass backdrop mode
    property size screenSize: Qt.size(width, height)
    property point offset: Qt.point(0, 0)
    property real cornerRadius: 0                  // rounded mask (glass backdrop inside a panel)
    property real time: 2.0                        // pleasant static frame when not animated

    // The photo, unless it failed to load; reset when another photo is chosen.
    property bool photoBroken: false
    readonly property string photoPath: Theme.wallpaperPhoto
    onPhotoPathChanged: photoBroken = false
    readonly property bool isPhoto: kind === "photo" && photoPath !== "" && !photoBroken
    readonly property string shaderKind: kind === "photo" ? "deep" : kind

    readonly property bool useImage: Theme.softwareRender && !lowDetail

    // Pre-rendered stills exist for the preset accents; a custom accent uses the nearest preset.
    readonly property string accentKey: {
        const a = Theme.accent
        let best = Theme.accents[0].color, bestD = 1e9
        for (const p of Theme.accents) {
            const c = Qt.color(p.color)
            const d = (c.r - a.r) * (c.r - a.r) + (c.g - a.g) * (c.g - a.g) + (c.b - a.b) * (c.b - a.b)
            if (d < bestD) { bestD = d; best = p.color }
        }
        return best.slice(1).toLowerCase()
    }

    // A glass backdrop over a photo draws nothing: panels over a photo use their solid tint.
    Loader {
        anchors.fill: parent
        sourceComponent: root.isPhoto ? (root.lowDetail ? null : photo) : root.useImage ? still : shader
    }

    Component {
        id: shader
        ShaderEffect {
            property size itemSize: Qt.size(width, height)
            property size screenSize: root.screenSize
            property point offset: root.offset
            property color accent: Theme.accent
            property real time: root.time
            property real stars: Theme.profile > 0 ? 1 : 0
            property real detail: root.lowDetail ? 0 : 1
            property real cornerRadius: root.cornerRadius
            fragmentShader: Qt.resolvedUrl("shaders/" + root.shaderKind + ".frag.qsb")
        }
    }

    Component {
        id: still
        Image {
            source: Qt.resolvedUrl("wallpapers/" + root.shaderKind + "-" + root.accentKey + ".jpg")
            fillMode: Image.PreserveAspectCrop
            sourceSize: Qt.size(Math.max(1, width), Math.max(1, height))
            asynchronous: true
            retainWhileLoading: true              // keep the old still while a new accent decodes
            cache: false
        }
    }

    // Decoded once at screen size (JPEG decodes scaled down, so a 24 MP photo stays cheap), on
    // Theme.bg where "fit" leaves bars. autoTransform: phone photos are stored sideways + EXIF.
    Component {
        id: photo
        Image {
            source: Theme.wallpaperPhotoUrl
            fillMode: Theme.wallpaperFit === "fit" ? Image.PreserveAspectFit : Image.PreserveAspectCrop
            sourceSize: Qt.size(Math.max(1, width), Math.max(1, height))
            autoTransform: true
            asynchronous: true
            retainWhileLoading: true
            cache: false
            onStatusChanged: if (status === Image.Error) root.photoBroken = true
        }
    }

    Timer {
        interval: Math.round(1000 / root.fps)
        repeat: true
        running: root.animated && !root.paused && root.visible && !root.lowDetail && !root.useImage && !root.isPhoto
        onTriggered: root.time += interval / 1000
    }
}
