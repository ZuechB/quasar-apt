import QtQuick
import Quasar

// Quasar Assistant (template <aside aria-label="Quasar Assistant">): the right-side sheet that opens
// from the taskbar's Ask button and from "Ask Quasar" in the launcher. Pure view: the shell's
// services/Assistant.qml feeds it and runs everything.
//   header   orbit (8 s a turn, 1.6 s while working) · "Quasar" · where it runs (On-device / Claude …) · ×
//   body     empty state (or set-up card) · the conversation as blocks:
//            user bubble · answer text (Markdown) · step card (numbered rows with permission tags; Run plan /
//            Cancel while it waits, a progress row with Stop while it runs, Allow / Deny for one risky step)
//            · done card (Undo all / New task) · error card · note
//   footer   "Describe a task…" (send, or stop while working) and where requests go
Item {
    id: root
    property var blocks: null            // ListModel { kind: user|text|steps|done|error|note, text, ids, action, details }
    property bool detailsOpen: false     // error cards start with Details open (previews)
    property var steps: ({})             // id -> { state, title, detail, tag, risk, tool, summary, lines }
    property int rev: 0                  // bumped whenever `steps` changes
    property bool busy: false
    property var planIds: []             // staged steps waiting for Run plan
    property string askId: ""            // the step waiting for Allow / Deny
    property bool canUndo: false
    property bool ready: true            // a provider and model are set up
    property string destination: "On-device"
    property bool cloud: false
    property string company: ""          // who receives requests (cloud), for the footnote
    property var suggestions: []         // [{ label, glyph }]
    property string wallpaperKind: "deep"
    property size screenSize: Qt.size(0, 0)
    property point screenPos: Qt.point(0, 0)

    signal send(string text)
    signal runPlan()
    signal cancelPlan()
    signal stop()
    signal allow()
    signal deny()
    signal undo()
    signal newTask()
    signal retry()
    signal closeRequested()
    signal settingsRequested()
    signal linkClicked(string url)

    function focusInput() { input.forceActiveFocus() }
    function clearInput() { input.text = "" }
    function _submit() {
        const t = input.text.trim()
        if (!t || root.busy) return
        input.text = ""
        root.send(t)
    }

    readonly property bool empty: !blocks || blocks.count === 0

    Panel {
        id: panel
        anchors.fill: parent
        radius: 24
        tint: Theme.panelBgStrong
        borderColor: Theme.white(0.11)
        shadowOffsetY: 50
        shadowBlur: 120
        shadowSpread: -30
        shadowColor: Qt.rgba(0, 0, 0, 0.95)
        glowColor: Theme.alpha(Theme.accent, 0.28)
        wallpaperKind: root.wallpaperKind
        screenSize: root.screenSize
        screenPos: root.screenPos

        // ---------------------------------------------------------------- header
        Item {
            id: header
            width: parent.width
            height: 58
            OrbitMark {
                id: mark
                x: 18
                anchors.verticalCenter: parent.verticalCenter
                size: 24
                spinning: true
                spinDuration: root.busy ? 1600 : 8000
            }
            Text {
                anchors { left: mark.right; leftMargin: 10; verticalCenter: parent.verticalCenter }
                text: "Quasar"
                font.family: Theme.fontDisplay; font.pixelSize: 17; font.weight: Font.Medium
                color: Theme.text
            }
            Badge {
                anchors { right: closeBtn.left; rightMargin: 8; verticalCenter: parent.verticalCenter }
                text: root.destination
                tone: root.cloud ? Theme.amber : Theme.mint
            }
            Pressable {
                id: closeBtn
                anchors { right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter }
                width: 36; height: 36; radius: 10
                accessibleName: "Close assistant"
                onClicked: root.closeRequested()
                QIcon { anchors.centerIn: parent; path: Icons.x; size: 16; strokeWidth: 2; color: Theme.textMuted }
            }
            Rectangle { anchors.bottom: parent.bottom; width: parent.width; height: 1; color: Theme.white(0.07) }
        }

        // ---------------------------------------------------------------- body
        ScrollPane {
            id: scroll
            anchors { top: header.bottom; bottom: footer.top; left: parent.left; right: parent.right }
            topPadding: 18
            bottomPadding: 18
            property bool stick: true
            onMovementEnded: stick = contentY >= contentHeight - height - 24
            onContentHeightChanged: if (stick) contentY = Math.max(0, contentHeight - height)

            Column {
                id: col
                x: 18
                width: scroll.width - 36
                spacing: 14

                // Nothing asked yet: what to do (or how to set it up)
                Column {
                    width: parent.width
                    visible: root.empty
                    spacing: 16
                    topPadding: 24
                    Text {
                        width: parent.width
                        text: root.ready ? "What should we get done?" : "Set up Quasar AI"
                        wrapMode: Text.Wrap
                        font.family: Theme.fontDisplay; font.pixelSize: 26; font.weight: Font.Normal; font.letterSpacing: -0.5
                        lineHeight: 1.1
                        color: Theme.text
                    }
                    Text {
                        width: parent.width
                        text: root.ready
                              ? "Describe it in plain words. Quasar shows the plan and what it needs access to, and nothing runs until you press Run."
                              : "Choose where it runs: on this PC with Ollama (private and free), or Claude, ChatGPT or Ollama Cloud with your own API key."
                        wrapMode: Text.Wrap
                        lineHeight: 1.2
                        font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
                        color: Theme.textMuted
                    }
                    Button {
                        visible: !root.ready
                        text: "Open Settings"
                        variant: "primary"; size: 40
                        onClicked: root.settingsRequested()
                    }
                    Column {
                        visible: root.ready
                        width: parent.width
                        spacing: 6
                        Repeater {
                            model: root.suggestions
                            delegate: Appear {
                                required property var modelData
                                required property int index
                                order: index + 1
                                width: col.width
                                height: 46
                                Pressable {
                                    width: parent.width; height: 46; radius: 14
                                    color: Theme.white(0.03)
                                    borderColor: Theme.white(0.07)
                                    accessibleName: modelData.label
                                    onClicked: root.send(modelData.label)
                                    QIcon { x: 12; anchors.verticalCenter: parent.verticalCenter; path: modelData.glyph; size: 17; color: Theme.accent }
                                    Text {
                                        anchors { left: parent.left; leftMargin: 41; right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter }
                                        text: modelData.label
                                        elide: Text.ElideRight
                                        font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
                                        color: Theme.text
                                    }
                                }
                            }
                        }
                    }
                }

                // The conversation
                Repeater {
                    model: root.blocks
                    delegate: Loader {
                        id: blk
                        required property int index
                        required property string kind
                        required property string text
                        required property string ids
                        required property string action
                        required property string details
                        readonly property bool last: index === root.blocks.count - 1
                        width: col.width
                        sourceComponent: kind === "user" ? userBlock : kind === "text" ? textBlock : kind === "steps" ? stepsBlock
                                       : kind === "done" ? doneBlock : kind === "error" ? errorBlock : noteBlock
                    }
                }
            }
        }

        // ---------------------------------------------------------------- composer
        Item {
            id: footer
            anchors.bottom: parent.bottom
            width: parent.width
            height: 12 + 48 + 8 + note.implicitHeight + 14
            Rectangle { width: parent.width; height: 1; color: Theme.white(0.07) }
            Rectangle {
                id: field
                x: 14; y: 12
                width: parent.width - 28; height: 48; radius: 15
                color: Theme.white(0.06)
                border.width: 1
                border.color: input.activeFocus ? Theme.alpha(Theme.accent, 0.45) : Theme.white(0.10)
                Behavior on border.color { ColorAnimation { duration: Motion.dur(150) } }
                TextInput {
                    id: input
                    anchors { left: parent.left; leftMargin: 14; right: sendBtn.left; rightMargin: 10; verticalCenter: parent.verticalCenter }
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(14)
                    color: Theme.text
                    selectionColor: Theme.alpha(Theme.accent, 0.35)
                    selectedTextColor: Theme.text
                    cursorDelegate: Rectangle { width: 2; color: Theme.accent; visible: input.cursorVisible }
                    clip: true
                    Accessible.role: Accessible.EditableText
                    Accessible.name: "Describe a task"
                    Keys.onReturnPressed: root._submit()
                    Keys.onEnterPressed: root._submit()
                    Keys.onEscapePressed: root.closeRequested()
                    Text {
                        anchors.fill: parent
                        verticalAlignment: Text.AlignVCenter
                        visible: input.text.length === 0
                        text: root.busy ? "Working on it…" : "Describe a task…"
                        elide: Text.ElideRight
                        font: input.font
                        color: Theme.textFaint
                    }
                }
                Pressable {
                    id: sendBtn
                    anchors { right: parent.right; rightMargin: 6; verticalCenter: parent.verticalCenter }
                    width: 36; height: 36; radius: 11
                    kind: "chip"
                    color: root.busy ? Theme.white(0.10) : Theme.accent
                    hoverColor: root.busy ? Theme.white(0.16) : Qt.lighter(Theme.accent, 1.12)
                    opacity: root.busy || input.text.trim().length ? 1 : 0.55
                    accessibleName: root.busy ? "Stop" : "Send"
                    onClicked: root.busy ? root.stop() : root._submit()
                    QIcon {
                        anchors.centerIn: parent
                        visible: !root.busy
                        path: Icons.send; size: 16; strokeWidth: 2.2; color: Theme.accentInk
                    }
                    Rectangle { anchors.centerIn: parent; visible: root.busy; width: 11; height: 11; radius: 2.5; color: Theme.text }
                }
            }
            Text {
                id: note
                x: 16
                anchors.top: field.bottom; anchors.topMargin: 8
                width: parent.width - 32
                text: (root.cloud ? "Sent to " + root.company + "." : "Runs on this PC.") + " Asks before installing or deleting anything."
                elide: Text.ElideRight
                font.family: Theme.fontUi; font.pointSize: Theme.pt(11.5)
                color: Theme.textFaint
            }
        }
    }

    // ==================================================================== blocks
    Component {
        id: userBlock
        Item {
            id: ub
            readonly property var b: parent
            width: b ? b.width : 0
            height: bubble.height
            Appear {
                anchors.right: parent.right
                width: bubble.width; height: bubble.height
                Rectangle {
                    id: bubble
                    width: Math.min(ub.width * 0.85, msgSize.width + 28)
                    height: msg.height + 20
                    radius: 16
                    bottomRightRadius: 4
                    color: Theme.white(0.09)
                    TextMetrics { id: msgSize; text: ub.b ? ub.b.text : ""; font: msg.font }
                    Text {
                        id: msg
                        x: 14; y: 10
                        width: bubble.width - 28
                        text: b ? b.text : ""
                        textFormat: Text.PlainText
                        wrapMode: Text.Wrap
                        lineHeight: 1.15
                        font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
                        color: Theme.text
                    }
                }
            }
        }
    }

    Component {
        id: textBlock
        Text {
            readonly property var b: parent
            width: b ? b.width : 0
            text: b ? b.text : ""
            textFormat: Text.MarkdownText
            wrapMode: Text.Wrap
            lineHeight: 1.2
            font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
            color: Theme.text3
            linkColor: Theme.accent
            onLinkActivated: (url) => root.linkClicked(url)
            HoverHandler { enabled: parent.hoveredLink !== ""; cursorShape: Qt.PointingHandCursor }
        }
    }

    Component {
        id: noteBlock
        Text {
            readonly property var b: parent
            width: b ? b.width : 0
            horizontalAlignment: Text.AlignHCenter
            text: b ? b.text : ""
            wrapMode: Text.Wrap
            font.family: Theme.fontUi; font.pointSize: Theme.pt(12)
            color: Theme.textDim
        }
    }

    // The plain sentence and what to do; the helper's own words (the engine's state, the provider's
    // message) wait behind Details, as in the Store's Banner.
    Component {
        id: errorBlock
        Rectangle {
            id: eb
            readonly property var b: parent
            readonly property string details: b ? b.details : ""
            property bool expanded: root.detailsOpen
            width: b ? b.width : 0
            height: errCol.implicitHeight + 28
            radius: 16
            color: Theme.alpha(Theme.danger, 0.07)
            border.width: 1; border.color: Theme.alpha(Theme.danger, 0.25)
            QIcon { x: 14; y: 15; path: Icons.alert; size: 18; color: Theme.danger }
            Column {
                id: errCol
                x: 42; y: 14
                width: parent.width - 56
                spacing: 10
                Text {
                    width: parent.width
                    text: b ? b.text : ""
                    wrapMode: Text.Wrap
                    lineHeight: 1.15
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
                    color: Theme.text
                }
                Row {
                    spacing: 6
                    visible: actBtn.visible || detBtn.visible
                    Button {
                        id: actBtn
                        visible: !!b && b.last && (b.action === "settings" || b.action === "retry")
                        text: b && b.action === "settings" ? "Open Settings" : "Try again"
                        variant: "soft"; size: 32
                        onClicked: b.action === "settings" ? root.settingsRequested() : root.retry()
                    }
                    Button {
                        id: detBtn
                        visible: eb.details !== ""
                        text: eb.expanded ? "Hide details" : "Details"
                        glyph: eb.expanded ? Icons.up : Icons.chev
                        variant: "ghost"; size: 32
                        onClicked: eb.expanded = !eb.expanded
                    }
                    Button {
                        visible: eb.expanded && eb.details !== ""
                        text: "Copy"
                        variant: "ghost"; size: 32
                        onClicked: { copyBuf.text = eb.details; copyBuf.selectAll(); copyBuf.copy() }
                    }
                }
                Rectangle {
                    visible: eb.expanded && eb.details !== ""
                    width: parent.width
                    height: Math.min(160, log.implicitHeight + 16)
                    radius: 10
                    color: Qt.rgba(0, 0, 0, 0.35)
                    Flickable {
                        anchors.fill: parent
                        anchors.margins: 8
                        contentHeight: log.implicitHeight
                        clip: true
                        boundsBehavior: Flickable.StopAtBounds
                        TextEdit {
                            id: log
                            width: parent.width
                            readOnly: true
                            selectByMouse: true
                            wrapMode: TextEdit.WrapAnywhere
                            textFormat: TextEdit.PlainText
                            text: eb.details
                            font.family: Theme.fontMono; font.pointSize: Theme.pt(11)
                            color: Theme.textMuted
                        }
                    }
                }
            }
            TextEdit { id: copyBuf; visible: false; textFormat: TextEdit.PlainText }
        }
    }

    Component {
        id: doneBlock
        Column {
            readonly property var b: parent
            width: b ? b.width : 0
            Rectangle {
                width: parent.width
                height: doneCol.implicitHeight + 28
                radius: 16
                color: Theme.accentTint
                border.width: 1; border.color: Theme.accentLine
                scale: Theme.reduceMotion ? 1 : popIn
                property real popIn: 0.6
                Component.onCompleted: popIn = 1
                Behavior on popIn { NumberAnimation { duration: Motion.dur(Motion.pop); easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.spring } }
                Rectangle {
                    x: 14; y: 14
                    width: 28; height: 28; radius: 14
                    color: Theme.accent
                    QIcon { anchors.centerIn: parent; path: Icons.check; size: 15; strokeWidth: 2.8; color: Theme.accentInk }
                }
                Column {
                    id: doneCol
                    x: 54; y: 14
                    width: parent.width - 68
                    spacing: 10
                    Text {
                        width: parent.width
                        text: b ? b.text : ""
                        textFormat: Text.MarkdownText
                        wrapMode: Text.Wrap
                        lineHeight: 1.2
                        font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
                        color: Theme.text
                        onLinkActivated: (url) => root.linkClicked(url)
                    }
                    Row {
                        visible: !!b && b.last && !root.busy
                        spacing: 8
                        Button { visible: root.canUndo; text: "Undo all"; variant: "soft"; size: 30; onClicked: root.undo() }
                        Button { text: "New task"; variant: "ghost"; size: 30; onClicked: root.newTask() }
                    }
                }
            }
        }
    }

    Component {
        id: stepsBlock
        Column {
            id: sb
            readonly property var b: parent
            readonly property var list: b && b.ids ? b.ids.split(",") : []
            readonly property var states: { const r = root.rev; return list.map(id => (root.steps[id] || {}).state || "") }
            readonly property bool isPlan: root.planIds.length > 0 && list.indexOf(root.planIds[0]) >= 0
            readonly property bool asking: root.askId !== "" && list.indexOf(root.askId) >= 0
            readonly property int finished: states.filter(s => s === "done" || s === "failed" || s === "skipped" || s === "denied").length
            readonly property bool running: states.indexOf("running") >= 0 && list.length > 1
            width: b ? b.width : 0
            spacing: 10

            Appear {
                width: parent.width
                height: card.height
                Rectangle {
                    id: card
                    width: parent.width
                    height: rows.implicitHeight
                    radius: 18
                    color: Theme.white(0.035)
                    border.width: 1; border.color: Theme.white(0.07)
                    clip: true
                    Column {
                        id: rows
                        width: parent.width
                        Repeater {
                            model: sb.list
                            delegate: AssistantStep {
                                required property int index
                                required property var modelData
                                width: rows.width
                                number: index
                                st: { const r = root.rev; return root.steps[modelData] || {} }
                            }
                        }
                    }
                }
            }

            // Waiting for Run plan
            Row {
                visible: sb.isPlan && !sb.asking
                width: parent.width
                spacing: 8
                Pressable {
                    width: parent.width - cancelBtn.width - 8; height: 44; radius: 13
                    kind: "chip"
                    color: Theme.accent
                    hoverColor: Qt.lighter(Theme.accent, 1.12)
                    accessibleName: "Run plan"
                    onClicked: root.runPlan()
                    Row {
                        anchors.centerIn: parent
                        spacing: 8
                        QIcon { anchors.verticalCenter: parent.verticalCenter; path: Icons.play; size: 15; strokeWidth: 0; fill: Theme.accentInk; color: Theme.accentInk }
                        Text { anchors.verticalCenter: parent.verticalCenter; text: "Run plan"; font.family: Theme.fontUi; font.pointSize: Theme.pt(14); font.weight: Font.DemiBold; color: Theme.accentInk }
                    }
                }
                Button { id: cancelBtn; text: "Cancel"; variant: "outline"; size: 44; onClicked: root.cancelPlan() }
            }

            // Running: progress, step N of M, Stop
            Item {
                visible: sb.running
                width: parent.width
                height: 32
                Rectangle {
                    id: track
                    anchors { left: parent.left; right: count.left; rightMargin: 12; verticalCenter: parent.verticalCenter }
                    height: 4; radius: 2
                    color: Theme.white(0.08)
                    Rectangle {
                        height: parent.height; radius: 2
                        width: parent.width * (sb.list.length ? sb.finished / sb.list.length : 0)
                        color: Theme.accent
                        Behavior on width { NumberAnimation { duration: Motion.dur(600); easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.soft } }
                    }
                }
                Text {
                    id: count
                    anchors { right: stopBtn.left; rightMargin: 10; verticalCenter: parent.verticalCenter }
                    text: "Step " + Math.min(sb.list.length, sb.finished + 1) + " of " + sb.list.length
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(12); font.features: { "tnum": 1 }
                    color: Theme.textMuted
                }
                Button { id: stopBtn; anchors.right: parent.right; anchors.verticalCenter: parent.verticalCenter; text: "Stop"; variant: "outline"; size: 32; onClicked: root.stop() }
            }

            // One risky step (plan off): Allow / Deny
            Rectangle {
                id: askBar
                visible: sb.asking
                width: parent.width
                height: askRow.implicitHeight + 20
                radius: 14
                color: Theme.alpha(Theme.amber, 0.08)
                border.width: 1; border.color: Theme.alpha(Theme.amber, 0.30)
                readonly property var st: { const r = root.rev; return root.steps[root.askId] || {} }
                Row {
                    id: askRow
                    x: 14; y: 10
                    width: parent.width - 28
                    spacing: 10
                    QIcon { anchors.verticalCenter: parent.verticalCenter; path: Icons.alert; size: 17; color: Theme.amber }
                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        width: parent.width - 27 - allowBtn.width - denyBtn.width - 30
                        text: askBar.st.tool === "run_command" ? "Run this command?" : "Allow this step?"
                        wrapMode: Text.Wrap
                        font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
                        color: Theme.text
                    }
                    Button { id: allowBtn; anchors.verticalCenter: parent.verticalCenter; text: "Allow"; variant: "primary"; tone: Theme.amber; size: 30; onClicked: root.allow() }
                    Button { id: denyBtn; anchors.verticalCenter: parent.verticalCenter; text: "Deny"; variant: "outline"; size: 30; onClicked: root.deny() }
                }
            }
        }
    }
}
