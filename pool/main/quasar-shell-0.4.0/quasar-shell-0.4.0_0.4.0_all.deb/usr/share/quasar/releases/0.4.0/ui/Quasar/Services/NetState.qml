pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io

// VPN / Mobile hotspot / Encrypted DNS, live, for the shell (taskbar badge, Quick settings tiles, toasts)
// and Settings: /run/quasar/net-state.json, written in place by root (`quasar-net`: NetworkManager's
// dispatcher on every network change, and Encrypted DNS changes). Nothing is polled. The file is made at
// boot (tmpfiles quasar-net.conf): a FileView only watches a file that existed when it loaded.
//   QUASAR_NET_STATE=/path: another file (tests: tools/fake-net.py writes it).
Singleton {
    id: root
    readonly property string path: Quickshell.env("QUASAR_NET_STATE") || "/run/quasar/net-state.json"
    property var data: ({})

    readonly property var vpns: data.vpns || []                     // connected: [{ uuid, name, kind, device }]
    readonly property bool vpnOn: vpns.length > 0
    readonly property string vpnName: vpnOn ? vpns[0].name : ""
    readonly property var hotspot: data.hotspot || ({})              // { on, ssid, device, mode, stopped }
    readonly property bool hotspotOn: !!hotspot.on
    readonly property var dns: data.dns || ({})                      // { on, provider, name, reach }
    readonly property bool dnsOn: !!dns.on

    FileView {
        id: file
        path: root.path
        watchChanges: true
        printErrors: false
        onFileChanged: reload()
        onLoaded: { try { root.data = JSON.parse(text()) || {} } catch (e) { } }
    }
}
