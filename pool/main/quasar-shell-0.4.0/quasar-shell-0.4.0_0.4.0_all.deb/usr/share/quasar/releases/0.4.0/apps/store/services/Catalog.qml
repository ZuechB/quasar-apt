import QtQuick
import Quickshell
import Quickshell.Io

// The catalog shipped in the image: all of Flathub plus Quasar's picks, generated at build time by
// build/store/gen-catalog.py into /usr/share/quasar/store: catalog.json (one compact entry per app, in
// recommended order, plus categories, collections and runtime sizes), details/<n>.json (descriptions,
// licences, privacy labels… for about 32 apps each, read when a detail page opens) and icons/.
// Browsing never touches the network. QUASAR_STORE_DIR overrides the location (development).
// Entries are never copied or changed: views look up live state (state.js) by id.
Scope {
    id: root
    readonly property string dir: Quickshell.env("QUASAR_STORE_DIR") || "/usr/share/quasar/store"
    property var apps: []                 // entries, recommended order (picks, then the most installed)
    property var index: ({})              // id -> entry
    property var categories: []           // [{ id, label, glyph, chips: [{ id, label }] }]
    property var collections: ({})        // { picks, popular, trending, new }: ids
    property var runtimes: ({})           // runtime ref -> installed size
    property bool ready: false

    function byId(id) { return index[id] || null }
    function runtimeSize(a) { return a ? (a.runtimeSize || (a.runtime ? runtimes[a.runtime] || 0 : 0)) : 0 }
    readonly property var debianPackages: {
        const out = []
        for (const a of apps) if (a.source === "debian" || a.source === "debfile") for (const p of (a.pkgs || [])) if (out.indexOf(p) < 0) out.push(p)
        return out
    }
    // A package from a file (services/DebFiles.qml): added, or replaced when the same package's file is
    // opened again (a newer download). It never shows in search or the shelves (fromFile).
    function putLocal(e) {
        const m = Object.assign({}, index)
        m[e.id] = e
        index = m
        const i = apps.findIndex(a => a.id === e.id)
        apps = i < 0 ? apps.concat([e]) : apps.slice(0, i).concat([e], apps.slice(i + 1))
    }
    function dropLocal(id) {
        if (!index[id] || !index[id].fromFile) return
        const m = Object.assign({}, index)
        delete m[id]
        index = m
        apps = apps.filter(a => a.id !== id)
    }

    function _add(list) {
        if (!list.length) return
        const m = Object.assign({}, index)
        for (const e of list) m[e.id] = e
        index = m
        apps = apps.concat(list)
    }
    // Results of an explicit online Flathub search join the catalog (so they can be installed through
    // the same queue) but stay marked `online`: apps newer than this Store, with no details or label.
    function addOnline(list) {
        _add(list.filter(e => !index[e.id]).map(e => ({
            id: e.id, name: e.name || e.id, dev: e.dev || "Flathub", blurb: e.blurb || "", cat: "",
            glyph: "pkg", hue: "#C9CFDC", source: "flathub", online: true, verified: !!e.verified,
            proprietary: !!e.proprietary })))
    }
    // Installed Flatpak apps the catalog doesn't list (newer than this Quasar, end-of-life, or from an
    // online search in an earlier session) still show in Installed and can be opened, updated, removed.
    function addInstalled(flatpaks) {
        _add(Object.keys(flatpaks || {}).filter(id => !index[id]).map(id => ({
            id: id, name: (flatpaks[id] || {}).name || id.split(".").pop(), dev: "Flathub", blurb: "", cat: "",
            glyph: "pkg", hue: "#C9CFDC", source: "flathub", local: true })))
    }

    // ---- details: the shard of the app being looked at (the last two shards stay in memory) ------
    property string detailsFor: ""
    property var details: null
    property var _shards: ({})
    property var _order: []
    onDetailsForChanged: _loadDetails()
    function _loadDetails() {
        const a = index[detailsFor]
        if (!a || a.d === undefined) { details = null; return }
        const s = _shards[a.d]
        if (s) { details = s[detailsFor] || null; return }
        details = null
        shardFile.shard = a.d
        shardFile.path = dir + "/details/" + a.d + ".json"
    }
    FileView {
        id: shardFile
        property int shard: -1
        printErrors: false
        onLoaded: {
            try {
                const o = JSON.parse(text())
                const m = {}
                const keep = root._order.filter(k => k !== shardFile.shard).slice(-1)
                for (const k of keep) m[k] = root._shards[k]
                m[shardFile.shard] = o
                root._shards = m
                root._order = keep.concat([shardFile.shard])
            } catch (e) {
                console.warn("store: unreadable details", shardFile.path, e)
            }
            root._loadDetails()
        }
        onLoadFailed: (error) => { root.details = null }
    }

    FileView {
        path: root.dir + "/catalog.json"
        blockLoading: true
        printErrors: false
        onLoaded: {
            try {
                const o = JSON.parse(text())
                const list = (o.apps || []).filter(a => a && a.id)
                const m = {}
                for (const a of list) m[a.id] = a
                root.index = m
                root.apps = list
                root.categories = o.categories || []
                root.collections = o.collections || {}
                root.runtimes = o.runtimes || {}
            } catch (e) {
                console.warn("store: unreadable catalog:", e)
            }
            root.ready = true
            root._loadDetails()
        }
        onLoadFailed: (error) => { console.warn("store: no catalog at", root.dir); root.ready = true }
    }
}
