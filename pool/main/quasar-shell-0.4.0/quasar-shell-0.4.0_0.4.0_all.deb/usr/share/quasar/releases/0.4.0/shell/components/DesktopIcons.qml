import QtQuick
import Quasar

// Desktop icons (mockup aria-label="Desktop icons"): 96px tiles at the spots the shell's layout gives
// them (desktopLayout.js). Click selects, double-click opens, right-click asks for a menu. Press-drag
// on a tile starts a system drag of the selection: files to other apps, onto a folder or the Trash,
// or to a new spot. Selection boxes and drops on empty space are handled by the window behind.
Item {
    id: root
    // [{ key, name, glyph, hue, icon, letter, thumb, x, y, target }] (array or keyed ScriptModel).
    // `target`: folders and the Trash take drops.
    property var model: []
    property var selection: []
    property string dropKey: ""          // tile under a drag, highlighted
    property string renamingKey: ""      // label hidden while the rename field covers it
    property var draggingKeys: []        // dimmed while they are being dragged
    property string dragUris: ""         // text/uri-list of the selection, set by the shell
    property string dragKeys: ""         // JSON key list (application/x-quasar-desktop)
    property bool animateMoves: true
    property bool focused: true          // the desktop has the keyboard: full-strength selection

    signal clicked(string key, int modifiers)                 // the press's keyboard modifiers (Ctrl+click adds)
    signal activated(string key)
    signal contextRequested(string key, real x, real y)      // root coordinates
    signal dragRequested(string key, real hx, real hy)        // set selection + dragUris before it starts; hx/hy = grab point in the tile
    signal dragEnded(string key, int action)
    signal dropEntered(string key)
    signal dropExited(string key)
    signal dropped(string key, var drop, real x, real y)      // DragEvent, valid during the call only; x/y in root coordinates

    Repeater {
        model: root.model
        delegate: Item {
            id: cell
            required property int index
            required property var modelData
            readonly property string key: modelData.key
            readonly property bool sel: root.selection.indexOf(key) >= 0
            readonly property bool hot: root.dropKey === key
            x: modelData.x; y: modelData.y
            width: 96; height: 92
            opacity: root.draggingKeys.indexOf(key) >= 0 ? 0.4 : 1
            Behavior on x { enabled: root.animateMoves && !Theme.reduceMotion; NumberAnimation { duration: Motion.dur(420); easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.spring } }
            Behavior on y { enabled: root.animateMoves && !Theme.reduceMotion; NumberAnimation { duration: Motion.dur(420); easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.spring } }

            Pressable {
                id: icon
                // Selected: accent wash (fainter while another window has the keyboard); drop target: stronger.
                readonly property real wash: cell.hot ? 0.24 : root.focused ? 0.16 : 0.09
                anchors.fill: parent
                radius: 14; kind: "tile"
                color: cell.sel || cell.hot ? Theme.alpha(Theme.accent, wash) : "transparent"
                hoverColor: cell.sel || cell.hot ? Theme.alpha(Theme.accent, wash) : Theme.white(0.06)
                borderColor: cell.sel || cell.hot ? Theme.alpha(Theme.accent, cell.hot ? 0.6 : root.focused ? 0.40 : 0.22) : "transparent"
                accessibleName: cell.modelData.name
                cursorShape: Qt.ArrowCursor
                draggable: true
                onClicked: root.clicked(cell.key, icon.modifiers)
                onDoubleClicked: root.activated(cell.key)
                onRightClicked: (mx, my) => { const p = icon.mapToItem(root, mx, my); root.contextRequested(cell.key, p.x, p.y) }
                // The drag image (icon + name) is grabbed on press; it arrives a frame later, before
                // the pointer has moved past the drag threshold.
                onPressedChanged: if (pressed) face.grabToImage((r) => { grip.Drag.imageSource = r.url })
                // A system drag of the selection; the shell sets the selection and mime data first.
                onDragStarted: (px, py) => {
                    if (grip.Drag.active) return
                    grip.hot = icon.mapToItem(face, px, py)
                    root.dragRequested(cell.key, px, py)
                    grip.Drag.active = true
                }

                // pop-in: translateY(20px) scale(.6) -> none, spring .7s, staggered 80 + i*50 ms
                opacity: Theme.reduceMotion ? 1 : 0
                Component.onCompleted: if (!Theme.reduceMotion) pop.start()
                SequentialAnimation {
                    id: pop
                    PauseAnimation { duration: 80 + Math.min(cell.index, 12) * 50 }
                    ParallelAnimation {
                        NumberAnimation { target: icon; property: "opacity"; from: 0; to: 1; duration: 300 }
                        NumberAnimation { target: icon; property: "scale"; from: 0.6; to: 1; duration: 700; easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.spring }
                    }
                }

                Column {
                    id: face
                    anchors.centerIn: parent
                    spacing: 6
                    Item {
                        id: tile
                        width: 50; height: 50
                        anchors.horizontalCenter: parent.horizontalCenter
                        Shadow { target: app; visible: app.visible; radius: 15; offsetY: 10; blur: 22; spread: -12; color: Qt.rgba(0, 0, 0, 0.9) }
                        AppTile {
                            id: app
                            visible: !photo.visible
                            size: 50; radius: 15
                            hue: cell.modelData.hue || Theme.text3
                            glyph: cell.modelData.glyph || ""
                            image: cell.modelData.icon || ""
                            letter: cell.modelData.letter || ""
                            glyphSize: 25
                        }
                        // Picture files: a small print with a light frame (no masks, so software rendering works).
                        Rectangle {
                            id: photo
                            readonly property bool ready: thumbImg.status === Image.Ready
                            visible: !!cell.modelData.thumb && ready
                            anchors.centerIn: parent
                            width: thumbImg.paintedWidth + 6; height: thumbImg.paintedHeight + 6
                            radius: 3
                            color: Qt.rgba(0.93, 0.94, 0.97, 0.95)
                            Image {
                                id: thumbImg
                                anchors.centerIn: parent
                                width: 44; height: 44
                                source: cell.modelData.thumb || ""
                                sourceSize: Qt.size(96, 96)
                                fillMode: Image.PreserveAspectFit
                                asynchronous: true
                                smooth: true
                            }
                        }
                    }
                    Text {
                        anchors.horizontalCenter: parent.horizontalCenter
                        width: 88
                        horizontalAlignment: Text.AlignHCenter
                        wrapMode: Text.Wrap
                        maximumLineCount: 2
                        elide: Text.ElideRight
                        visible: root.renamingKey !== cell.key
                        text: cell.modelData.name
                        font.family: Theme.fontUi; font.pixelSize: 12
                        lineHeight: 1.25
                        color: Theme.text
                        style: Text.Raised
                        styleColor: Qt.rgba(0, 0, 0, 0.55)
                    }
                }
            }

            // Drag source, started by the Pressable (draggable) once a press moves past the drag distance.
            // Started by hand rather than bound to a drag-active flag: such a binding loops and can
            // cancel the system drag.
            Item {
                id: grip
                anchors.fill: parent
                property point hot: Qt.point(48, 30)  // press point in `face`, the drag image
                Drag.dragType: Drag.Automatic
                Drag.supportedActions: Qt.CopyAction | Qt.MoveAction | Qt.LinkAction
                Drag.proposedAction: Qt.MoveAction
                Drag.hotSpot.x: Math.max(0, Math.min(face.width, hot.x))
                Drag.hotSpot.y: Math.max(0, Math.min(face.height, hot.y))
                Drag.mimeData: ({ "text/uri-list": root.dragUris, "application/x-quasar-desktop": root.dragKeys })
                Drag.onDragFinished: (action) => {
                    root.dragEnded(cell.key, action)
                    icon.resetPress()                 // the release that ends a drop may never arrive
                }
            }

            // Folders and the Trash take drops (files from other apps, or other desktop icons).
            DropArea {
                anchors.fill: parent
                enabled: !!cell.modelData.target
                onEntered: (d) => root.dropEntered(cell.key)
                onExited: root.dropExited(cell.key)
                onDropped: (d) => { const p = mapToItem(root, d.x, d.y); root.dropped(cell.key, d, p.x, p.y) }
            }
        }
    }
}
