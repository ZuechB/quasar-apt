import QtQuick
import Quickshell
import Quickshell.Io
import Quasar
import Quasar.Services
import "../components/companies.js" as Co

// Settings > Companies & Profiles (company environments): add, rename and delete companies, start and
// stop them, and the per-company details (git identity, SSH key, dev tools, size). Root work goes
// through /usr/libexec/quasar/quasar-company-admin (pkexec); starting and stopping through the shell,
// which also gives a company its display and sound. Details are read inside each running company
// through its agent, and only while the page is shown.
Scope {
    id: root
    property bool active: false              // the Companies page is shown
    property string busy: ""                 // row key of the running action
    property var info: ({})                  // id -> { git, gitName, gitEmail, ssh, tools, size }
    property var azureCount: null            // (space) -> number of Azure Pipelines agents (services/AzureDevOps.qml)
    property var ask: null                   // confirmation: { id, title, message, button }
    property var form: null                  // dialog: { kind: "add" | "rename" | "git", id, name, email }
    signal notify(var banner)                // result banner for the page
    signal pick(string title, var options, string current, var done)   // a ChoiceSheet

    // Docker's setup step adds the Containers app's launcher entry: it marks Docker as installed.
    readonly property bool dockerInstalled: DesktopEntries.applications.values.length > 0 && !!DesktopEntries.byId("quasar-containers")
    readonly property var ctx: ({ state: (id) => Companies.stateOf(id), failed: Companies.failed, info: info,
                                  busy: busy, live: Platform.live, docker: dockerInstalled, azure: azureCount, icons: Icons, theme: Theme })
    readonly property var groups: Co.groups(Companies.list, ctx)
    readonly property var hero: Co.hero(Companies.list, ctx)

    onActiveChanged: if (active) refreshAll()
    Connections {
        target: Companies
        function onRunningChanged() { if (root.active) root.refreshAll() }
        function onRegistryChanged() { if (root.active) root.refreshAll() }
    }

    // ---- details --------------------------------------------------------------------------------
    readonly property var toolNames: ({ node: "Node.js", dotnet: ".NET", python: "Python", go: "Go", rust: "Rust",
                                        java: "Java", bun: "Bun", deno: "Deno" })
    function _setInfo(id, patch) {
        const all = Object.assign({}, info)
        all[id] = Object.assign({}, all[id] || {}, patch)
        info = all
    }
    function refreshAll() {
        const ids = Companies.companies.map(c => c.id)
        if (ids.length) { sizes.command = ["sh", "-c", "for d in \"$@\"; do printf '%s\\t' \"$d\"; du -sb \"/home/companies/$d\" 2>/dev/null | cut -f1; echo; done", "sh"].concat(ids); sizes.running = true }
        for (const id of ids) if (Companies.isRunning(id)) readInside(id)
    }
    Process {
        id: sizes
        stdout: SplitParser {
            onRead: (l) => {
                const m = /^([a-z][a-z0-9-]*)\t(\d+)/.exec(l)
                if (m) root._setInfo(m[1], { size: parseInt(m[2]) })
            }
        }
    }
    // Git identity, SSH key and dev tools, read inside the company (its own home).
    function readInside(id) {
        const script = "printf 'GITNAME=%s\\n' \"$(git config --global user.name 2>/dev/null)\";"
                     + "printf 'GITEMAIL=%s\\n' \"$(git config --global user.email 2>/dev/null)\";"
                     + "[ -f ~/.ssh/id_ed25519.pub ] && echo SSH=1;"
                     + "[ -x /usr/libexec/quasar/quasar-dev ] && /usr/libexec/quasar/quasar-dev status 2>/dev/null | grep '^STATUS '"
        const got = {}
        Companies.exec(id, ["sh", "-c", script], {
            onLine: (kind, l) => {
                if (kind !== "out") return
                if (l.startsWith("GITNAME=")) got.gitName = l.slice(8)
                else if (l.startsWith("GITEMAIL=")) got.gitEmail = l.slice(9)
                else if (l === "SSH=1") got.ssh = true
                else if (l.startsWith("STATUS ")) got.tools = root._tools(l.slice(7))
            },
            onExit: (code) => {
                got.git = got.gitName || got.gitEmail ? (got.gitName || "") + (got.gitEmail ? " <" + got.gitEmail + ">" : "") : ""
                root._setInfo(id, got)
            }
        })
    }
    function _tools(json) {
        try {
            const all = JSON.parse(json)
            const out = []
            for (const tool in all) {
                const vs = Array.isArray(all[tool]) ? all[tool] : []
                const v = vs.find(x => x.active) || vs[0]
                if (v) out.push((toolNames[tool] || tool) + " " + v.version)
            }
            return out.length ? out.join(", ") : ""
        } catch (e) { return "" }
    }

    // ---- actions ---------------------------------------------------------------------------------
    function _shell(args) { Quickshell.execDetached(["qs", "--path", "/usr/share/quasar/shell", "ipc", "call"].concat(args)) }
    function _prefs(id, patch) {
        const all = Object.assign({}, Settings.companies || {})
        all[id] = Object.assign({}, all[id] || {}, patch)
        Settings.companies = all
    }
    function heroActivated() { form = { kind: "add", name: "", color: Companies.nextColor() } }
    function activate(key) {
        if (key === "co:add") { heroActivated(); return }
        const k = Co.parseKey(key)
        if (!k || k.id === "personal") return
        const c = Companies.byId(k.id)
        if (!c) return
        const running = Companies.isRunning(c.id)
        if (k.what === "running") {
            busy = key
            _shell(["company", running ? "stop" : "start", c.id])
            busyClear.restart()
        } else if (k.what === "autostart") {
            _prefs(c.id, { autostart: !c.autostart })
        } else if (k.what === "home") {
            Quickshell.execDetached(["quasar-files", c.home])
        } else if (k.what === "tools") {
            // Dev tools install into the company that is shown: show it, then open the Store there.
            _shell(["company", "switchTo", c.id])
            Quickshell.execDetached(["quasar-store", "develop"])
        } else if (k.what === "docker") {
            // The company's own engine is managed in Containers while that company is shown.
            if (!dockerInstalled) { Quickshell.execDetached(["quasar-store", "app:docker"]); return }
            _shell(["company", "switchTo", c.id])
            Quickshell.execDetached(["quasar-containers"])
        } else if (k.what === "git") {
            if (!running) return
            const i = info[c.id] || {}
            form = { kind: "git", id: c.id, name: i.gitName || Platform.userName || "", email: i.gitEmail || "" }
        } else if (k.what === "ssh") {
            if (running) copySshKey(c)
        } else if (k.what === "terminal") {
            Quickshell.execDetached(["sh", "-c", "quasar-company terminal \"$1\" && qs --path /usr/share/quasar/shell ipc call company switchTo \"$1\"", "sh", c.id])
        } else if (k.what === "name") {
            form = { kind: "rename", id: c.id, name: c.name }
        } else if (k.what === "color") {
            pick("Colour", Co.COLOURS.map(x => ({ key: x[0], label: x[1] })), c.color, (v) => root._prefs(c.id, { color: v }))
        } else if (k.what === "wallpaper") {
            pick("Wallpaper", Co.WALLPAPERS.map(x => ({ key: x[0], label: x[1] })), c.wallpaper, (v) => root._prefs(c.id, { wallpaper: v }))
        } else if (k.what === "delete") {
            const sz = (info[c.id] || {}).size
            ask = { id: c.id, title: "Delete " + c.name + "?",
                    message: "Its account, its files" + (sz ? " (" + Co.size(sz) + ")" : "") + ", keys, sign-ins and everything it runs are "
                           + "removed from this PC. This can't be undone.", button: "Delete " + c.name }
        }
    }
    function toggle(key) { activate(key) }
    Timer { id: busyClear; interval: 2500; onTriggered: root.busy = "" }

    function copySshKey(c) {
        busy = "co:" + c.id + ":ssh"
        let key = ""
        const script = "[ -f ~/.ssh/id_ed25519 ] || ssh-keygen -q -t ed25519 -N '' -C \"$1\" -f ~/.ssh/id_ed25519 </dev/null >/dev/null; cat ~/.ssh/id_ed25519.pub"
        Companies.exec(c.id, ["sh", "-c", script, "sh", c.id + "@quasar"], {
            onLine: (kind, l) => { if (kind === "out" && l.startsWith("ssh-")) key = l },
            onExit: (code) => {
                root.busy = ""
                if (code === 0 && key) {
                    Quickshell.execDetached(["wl-copy", key])
                    root._setInfo(c.id, { ssh: true })
                    root.notify({ tone: "success", title: c.name + "'s public SSH key is copied",
                                  message: "Add it to GitHub, GitLab or your servers for " + c.name + ". The private key never leaves its account." })
                } else {
                    root.notify({ tone: "error", title: "Couldn't make an SSH key for " + c.name, message: "ssh-keygen exited with " + code + "." })
                }
            }
        })
    }

    // The dialogs (Settings' shell.qml) call these.
    function submitForm(name, email, color) {
        const f = form
        form = null
        if (!f) return
        if (f.kind === "add") create(name, color)
        else if (f.kind === "rename") rename(f.id, name)
        else if (f.kind === "git") setGit(f.id, name, email)
    }
    function setGit(id, name, email) {
        Companies.exec(id, ["sh", "-c", "git config --global user.name \"$1\" && git config --global user.email \"$2\"", "sh", name, email], {
            onExit: (code) => {
                if (code === 0) root.readInside(id)
                else root.notify({ tone: "error", title: "Couldn't save the git identity", message: "git exited with " + code + "." })
            }
        })
    }
    function confirm() {
        const a = ask
        ask = null
        if (!a) return
        busy = "co:" + a.id + ":delete"
        _shell(["company", "stop", a.id])
        _run(["delete", a.id], () => {
            const all = Object.assign({}, Settings.companies || {})
            delete all[a.id]
            Settings.companies = all
            root.notify({ tone: "success", title: "The company is deleted", message: "" })
        })
    }
    function create(name, color) {
        const n = String(name || "").trim()
        if (!n) return
        const id = Companies.slug(n)
        busy = "co:add"
        _run(["create", id, n], () => {
            root._prefs(id, { color: color || Companies.nextColor() })
            Companies.reloadRegistry()
            root._shell(["company", "refresh"])
            root.notify({ tone: "success", title: n + " is ready",
                          message: "Switch to it from the menu at the top right. It starts the first time you do." })
        })
    }
    function rename(id, name) {
        const n = String(name || "").trim()
        if (n) _run(["rename", id, n], () => { })
    }

    // One root job at a time, through pkexec. Cancelling the password prompt (126) says nothing.
    property var _done: null
    function _run(args, done) {
        _done = done
        admin.runHelper(args)
    }
    Privileged {
        id: admin
        helper: "quasar-company-admin"
        onFinished: (code) => {
            const done = root._done
            root._done = null
            root.busy = ""
            if (code === 0 && admin.details().split("\n").some(l => /^(CREATED|RENAMED|DELETED) /.test(l))) { if (done) done(); return }
            if (code === 126) return
            const err = admin.details().split("\n").filter(l => l.startsWith("ERROR ")).map(l => l.slice(6)).pop()
            root.notify({ tone: "error", title: code === 127 ? "Not allowed to change companies" : (err || "That didn't work"),
                          message: "", details: admin.details() })
        }
    }
}
