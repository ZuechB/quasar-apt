import QtQuick
import Quickshell
import Quickshell.Io
import Quasar

// The taskbar's Services tray (template: cycle icon, running count, a pulsing red dot on a failure):
// `services-query watch --summary`, driven by systemd's signals (nothing polled). The tray shows only
// once a server was added or something failed, so a fresh taskbar stays clean. A service that newly
// fails gets a toast that opens its console (`quasar-services log/<key>`: what it wrote, live, and why it
// stopped); a helper without `failedKeys` (an older one) opens Services instead. Without the helper (an
// older image) it retries quietly, at most every 5 minutes. QUASAR_SERVICES_QUERY=/path swaps the helper.
// failed: [{ name, key }] for the tray's menu (shell.qml openServicesMenu).
Item {
    id: root
    visible: false
    signal toast(var t)

    property int running: 0
    property int failed: 0
    property var failedNames: []
    property var failedList: []             // [{ name, key }] (key "" from an older helper)
    property int added: 0
    readonly property bool shown: added > 0 || failed > 0
    readonly property string label: "Background services: " + running + " running" + (failed ? ", " + failed + " failed" : "")

    readonly property string exe: Quickshell.env("QUASAR_SERVICES_QUERY") || "/usr/libexec/quasar/services-query"
    property bool heard: false              // a summary arrived (ever): later new failures toast
    property bool heardThisRun: false       // … since the helper last started
    property int quickExits: 0

    function onLine(l) {
        if (l.charAt(0) !== "{") return
        let o
        try { o = JSON.parse(l) } catch (e) { return }
        if (o.type !== "summary") return
        const before = failedNames
        const names = o.failedNames || []
        const keys = o.failedKeys || []
        running = o.running || 0
        failed = o.failed || 0
        added = o.added || 0
        // Only failures that happen while the shell watches (not the ones already there at sign-in).
        if (heard)
            for (let i = 0; i < names.length; i++) {
                const n = names[i], k = keys[i] || ""
                if (before.indexOf(n) >= 0) continue
                if (k) toast({ title: n + " stopped working", sub: "Click to see its log", glyph: Icons.alert, hue: "#FF8F8F",
                               app: "quasar-services", args: ["log/" + k] })
                else toast({ title: n + " stopped working", sub: "Open Services to see why", glyph: Icons.alert, hue: "#FF8F8F", app: "quasar-services" })
            }
        failedNames = names
        failedList = names.map((n, i) => ({ name: n, key: keys[i] || "" }))
        heard = true
        heardThisRun = true
    }

    Process {
        id: proc
        command: [root.exe, "watch", "--summary"]
        running: true
        onRunningChanged: if (running) root.heardThisRun = false
        stdout: SplitParser { onRead: (l) => root.onLine(l) }
        onExited: (code) => {
            // Keep the last numbers; start again later (sooner if it had been answering).
            root.quickExits = root.heardThisRun ? 0 : root.quickExits + 1
            retry.interval = Math.min(300000, 10000 * Math.pow(2, Math.min(5, root.quickExits)))
            retry.start()
        }
    }
    Timer { id: retry; onTriggered: proc.running = true }
}
