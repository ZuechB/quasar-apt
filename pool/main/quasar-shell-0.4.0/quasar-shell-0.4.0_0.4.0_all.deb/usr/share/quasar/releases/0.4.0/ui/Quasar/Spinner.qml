import QtQuick
import QtQuick.Shapes

// Busy indicator (template "Connecting": 16px, r=9 ring at white .15 + a quarter arc, .8s spin).
// Spins only while visible; no timers otherwise.
Item {
    id: root
    property real size: 16
    property color color: Theme.accent
    property bool running: visible

    implicitWidth: size
    implicitHeight: size
    // Clips when scrolled away (see Theme.softwareRender). On the root, so the arc turns inside the
    // layer and stays sharp.
    layer.enabled: Theme.softwareRender

    Shape {
        id: shape
        anchors.fill: parent
        readonly property real s: root.size / 24
        ShapePath {
            strokeColor: Theme.white(0.15)
            strokeWidth: 2.5 * shape.s
            fillColor: "transparent"
            PathAngleArc { centerX: root.size / 2; centerY: root.size / 2; radiusX: 9 * shape.s; radiusY: 9 * shape.s; startAngle: 0; sweepAngle: 360 }
        }
        ShapePath {
            strokeColor: root.color
            strokeWidth: 2.5 * shape.s
            fillColor: "transparent"
            capStyle: ShapePath.RoundCap
            PathAngleArc { centerX: root.size / 2; centerY: root.size / 2; radiusX: 9 * shape.s; radiusY: 9 * shape.s; startAngle: -90; sweepAngle: 90 }
        }
        RotationAnimator on rotation {
            from: 0; to: 360; duration: 800
            loops: Animation.Infinite
            running: root.running && root.visible && !Theme.reduceMotion
        }
    }
}
