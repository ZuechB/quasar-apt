import QtQuick
import Quasar

// A category page's filter chip (Games: Action, Puzzle…): the template's 24px chip, selectable.
Pressable {
    id: root
    property string text: ""
    property int count: -1
    property bool selected: false

    kind: "chip"
    radius: 7
    color: selected ? Theme.alpha(Theme.accent, 0.16) : Theme.white(0.06)
    borderColor: selected ? Theme.alpha(Theme.accent, 0.45) : "transparent"
    implicitHeight: 28
    implicitWidth: label.implicitWidth + 22
    accessibleName: text + (count >= 0 ? ", " + count + " apps" : "")
    Accessible.checkable: true
    Accessible.checked: selected

    Text {
        id: label
        anchors.centerIn: parent
        text: root.text + (root.count >= 0 ? "  " + root.count : "")
        textFormat: Text.PlainText
        font.family: Theme.fontUi; font.pointSize: Theme.pt(12); font.features: { "tnum": 1 }
        font.weight: root.selected ? Font.DemiBold : Font.Normal
        color: root.selected ? Theme.accent : Theme.text3
    }
}
