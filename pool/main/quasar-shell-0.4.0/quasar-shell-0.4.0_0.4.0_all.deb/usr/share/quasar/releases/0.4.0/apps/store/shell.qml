//@ pragma AppId quasar-store
// Quasar Store — native Qt Quick app run by Quickshell (launched by /usr/bin/quasar-store).
//   quasar-store [discover|<category>|collection:<picks|popular|trending|new>|installed|updates|
//                 app:<id>|appstream://<id>|search:<text>]     (categories come from the catalog)
import QtQuick
import Quickshell
import Quickshell.Io
import Quasar
import Quasar.Services
import "components"
import "components/state.js" as State
import "services"

ShellRoot {
    id: app

    // ---- look follows the shared settings + render path -------------------------------------
    Binding { target: Theme; property: "accent"; value: Settings.accent }
    Binding { target: Theme; property: "reduceMotion"; value: Settings.reduceMotion }
    Binding { target: Theme; property: "softwareRender"; value: Platform.softwareScene }
    Binding { target: Theme; property: "profile"; value: Platform.softwareRender ? 0 : (Settings.profile >= 0 ? Settings.profile : 1) }

    // ---- services -------------------------------------------------------------------------------
    Catalog {
        id: catalog
        detailsFor: app.detailId
        onReadyChanged: if (ready) { installed.refresh(); app._unpark() }
    }
    Installed {
        id: installed
        catalog: catalog
        onFlatpaksChanged: if (catalog.ready) catalog.addInstalled(flatpaks)
    }
    // .deb files the user opens (a page each) and packages installed from files (Installed).
    DebFiles {
        id: debFiles
        catalog: catalog
        onOpened: (id) => { app.query = ""; app.detailId = id; win.visible = true }
        onFailed: (title, message) => app.banner = { tone: "error", title: title, message: message }
        onEntriesChanged: installed.refresh()
    }
    Jobs {
        id: jobs
        catalog: catalog
        installed: installed
        onFailed: (id, err) => { app.banner = err; app.jobResult(id, false, err ? err.title : ""); if (id.startsWith("deb:")) debFiles.refresh() }
        onStatesChanged: app.publishJobs()
        onCancelled: (id, action, also) => {
            app.jobResult(id, false, "Cancelled", true)
            for (const o of also) app.jobResult(o, false, "Cancelled", true)
            // Say so only when the cancel took more out of the queue than the user pressed: entries that
            // needed it (Rust when Build tools is cancelled), or that were queued only for it.
            if (also.length) {
                const name = (x) => (catalog.byId(x) || { name: x }).name
                const list = (ids) => ids.map(name).join(" and ")
                const needs = also.filter(o => ((catalog.byId(o) || {}).requires || []).indexOf(id) >= 0)
                const forIt = also.filter(o => needs.indexOf(o) < 0)
                const parts = []
                if (needs.length) parts.push(list(needs) + (needs.length > 1 ? " need " : " needs ") + name(id) + ", so "
                                             + (needs.length > 1 ? "they were" : "it was") + " taken out of the queue too.")
                if (forIt.length) parts.push(list(forIt) + (forIt.length > 1 ? " were" : " was") + " only queued for "
                                             + (needs.length ? "them" : name(id)) + ", so " + (forIt.length > 1 ? "they were" : "it was") + " taken out too.")
                app.banner = { tone: "info", title: name(id) + " was cancelled", message: parts.join(" ") }
            }
        }
        onFinished: (id, action, job) => {
            app.jobResult(id, true, "")
            if (id.startsWith("deb:")) debFiles.refresh()
            const a = catalog.byId(id)
            if (a && action === "install") {
                const what = a.source === "mise" ? [a.name + (job && job.installedVersion ? " " + job.installedVersion : "") + " is ready",
                                                     "Open a terminal to use it. Projects can pick their own version."]
                           : a.setup === "docker" ? ["Docker is installed", "Open Containers from the Store or the launcher. You can use docker in a terminal right away."]
                           : a.library ? [a.name + " is installed", "Apps that need it can run now."]
                           : [a.name + " is installed", "Open it from the Store or the launcher."]
                Quickshell.execDetached(["notify-send", "-a", "Store", "-i", "system-software-install", what[0], what[1]])
            }
            if (action === "update") app.dropUpdate(id)
            // Removing the default version of a tool: the newest one left takes over.
            if (action === "remove" && job && job.thenDefault) jobs.enqueue(id, "default", { version: job.thenDefault, exact: true })
        }
    }

    // What is installed, for the views (they work out each card's state from it; see state.js).
    readonly property var inst: ({ flatpaks: installed.flatpaks, debs: installed.debs, tools: installed.tools })

    // ---- navigation state -----------------------------------------------------------------------
    property string page: "discover"
    property string query: ""
    property string detailId: ""
    property var banner: null
    property bool liveNoticeShown: false
    property string pendingInstall: ""
    property var pendingOpts: null
    property string pendingRemove: ""

    function navigateTo(arg) {
        const a = (arg || "").trim()
        // A .deb file (double-clicked, or opened by another app: a path or a file:// URI).
        if (/^(file:\/\/|\/)/.test(a) && /\.deb$/i.test(a)) { debFiles.open(FileKit.argPath(a, Platform.home)); return }
        detailId = ""
        if (a.startsWith("app:")) { detailId = a.slice(4); return }
        if (a.startsWith("appstream://")) { detailId = a.slice(12).replace(/\.desktop$/, "").replace(/\/$/, ""); return }
        if (a.startsWith("search:")) { query = a.slice(7); return }
        query = ""
        const cats = (catalog.categories.length ? catalog.categories.map(c => c.id) : ["create", "work", "learn", "develop", "games", "utilities"])
        if (["discover", "installed", "updates"].concat(cats).indexOf(a) >= 0 || /^collection:[a-z]+$/.test(a)) page = a
    }
    Component.onCompleted: navigateTo(Quickshell.env("QUASAR_APP_ARGS"))

    function getApp(id, opts) {
        banner = null
        const a = catalog.byId(id)
        if (a && a.needsDisk && Platform.live) {
            banner = { tone: "info", title: a.name + " needs Quasar installed on this PC",
                       message: "It can't run from the installer USB, which keeps everything in memory. Install Quasar first, then get " + a.name + " again.",
                       actionText: "Install Quasar" }
            return
        }
        if (Platform.live && !liveNoticeShown) { pendingInstall = id; pendingOpts = opts || null; return }
        jobs.enqueue(id, "install", opts)
    }
    function openApp(id) {
        const a = catalog.byId(id)
        if (!a) return
        // Command-line apps from Flathub have no window: they run in a Terminal tab.
        if (a.source === "flathub" && a.cli) {
            Quickshell.execDetached(Companies.wrapRun(["quasar-terminal", "-e", "flatpak", "run", a.id]))
            return
        }
        const did = State.desktopIdOf(a)
        const e = DesktopEntries.byId(did)
        // Through the shell, which opens it in the company that is shown (company environments).
        if (e) Quickshell.execDetached(["sh", "-c", "qs --path /usr/share/quasar/shell ipc call launch app \"$1\" >/dev/null 2>&1 || gtk-launch \"$1\"", "sh", e.id])
        else if (a.source === "flathub") Quickshell.execDetached(Companies.wrapRun(["flatpak", "run", a.id]))
        else if (did.startsWith("quasar-")) Quickshell.execDetached(["/usr/bin/" + did])
        else Quickshell.execDetached(["sh", "-c", "qs --path /usr/share/quasar/shell ipc call launch terminal >/dev/null 2>&1 || footclient || foot"])
    }
    // An app's website, in the default browser (fileop open: exit 3 = no browser yet).
    function openHomepage(url) {
        if (!/^https?:\/\/[^\s]+$/i.test(url || "")) return
        homepage.command = Companies.wrapRun(["/usr/libexec/quasar/fileop", "open", url])
        homepage.running = true
    }
    Process {
        id: homepage
        onExited: (code) => {
            if (code === 3) app.banner = { tone: "info", title: "There's no web browser on this PC yet",
                                           message: "Get one from the Store, then open the website again.",
                                           actionText: "Show browsers", action: "browsers" }
        }
    }

    // ---- developer tools (mise): versions of one tool -------------------------------------------
    // "24.11.1" -> "24" (track major), "3.15.0" -> "3.15" (track minor); same rule as quasar-dev.
    function lineOf(v, track) {
        const m = /^([A-Za-z]+-)?(\d+)(?:\.(\d+))?/.exec(v)
        if (!m) return v
        return (m[1] || "") + m[2] + (track === "minor" && m[3] !== undefined ? "." + m[3] : "")
    }
    function installTool(id, spec) {
        const a = catalog.byId(id)
        if (!a) return
        getApp(id, { spec: spec, makeDefault: !installed.isInstalled(a) })
    }
    function setToolDefault(id, version) {
        const a = catalog.byId(id)
        if (!a) return
        banner = null
        // Another installed version on the same line ("24.10.0" next to "24.11.1"): pin the exact one.
        const line = lineOf(version, a.track)
        const exact = installed.versionsOf(a.tool).some(v => v !== version && lineOf(v, a.track) === line)
        jobs.enqueue(id, "default", { version: version, exact: exact })
    }
    function removeToolVersion(id, version) {
        const a = catalog.byId(id)
        if (!a) return
        banner = null
        const rest = installed.versionsOf(a.tool).filter(v => v !== version)
        if (!rest.length) { jobs.enqueue(id, "remove"); return }   // the last one: remove the tool
        jobs.enqueue(id, "remove", { version: version, thenDefault: installed.activeOf(a.tool) === version ? rest[0] : "" })
    }
    // "Other version…": the tool's releases, asked from its own server when the user presses the button.
    property string versionsFor: ""
    function otherVersions(id) {
        const a = catalog.byId(id)
        if (!a || versionsFor) return
        versionsFor = id
        versionList.command = ["/usr/libexec/quasar/quasar-dev", "versions", a.tool].concat(a.versionPrefix ? [a.versionPrefix] : [])
        versionList.running = true
    }
    Process {
        id: versionList
        stdout: StdioCollector {
            onStreamFinished: {
                const id = app.versionsFor
                app.versionsFor = ""
                const a = catalog.byId(id)
                const line = text.split("\n").find(l => l.startsWith("VERSIONS "))
                let list = []
                try { list = line ? JSON.parse(line.slice(9)) : [] } catch (e) { list = [] }
                if (!a || !list.length) {
                    app.banner = { tone: "error", title: "Couldn't get the list of " + (a ? a.name : "") + " versions",
                                   message: "Quasar can't reach " + (a && a.from ? a.from.replace(/ \(.*$/, "") : "the download server") + ". Check that you're online and try again." }
                    return
                }
                const have = installed.versionsOf(a.tool)
                versionPicker.toolId = id
                versionPicker.title = "Install another version of " + a.name
                versionPicker.options = list.map(v => ({ key: v, label: v, sub: have.indexOf(v) >= 0 ? "Installed" : "" }))
                versionPicker.current = installed.activeOf(a.tool)
                versionPicker.open = true
            }
        }
    }

    // ---- online search (Flathub's search API; only after the user agrees to send it the words) ----
    // The Store already lists all of Flathub as of this Quasar's build; this finds what's newer.
    property bool onlineConsent: false
    property string pendingOnline: ""
    property var onlineIds: []
    property bool onlineSearching: false
    function searchOnline(t) {
        if (!t) return
        if (!onlineConsent) { pendingOnline = t; return }
        onlineSearching = true
        onlineSearch.query = t
        onlineSearch.running = true
    }
    Process {
        id: onlineSearch
        property string query: ""
        command: ["curl", "-fsS", "--max-time", "20", "--proto", "=https", "-A", "Quasar Store",
                  "-H", "Content-Type: application/json",
                  "--data-raw", JSON.stringify({ query: query, hits_per_page: 40, page: 1 }),
                  "https://flathub.org/api/v2/search?locale=en"]
        stdout: StdioCollector {
            onStreamFinished: {
                const out = []
                let ok = true
                try {
                    const o = JSON.parse(text)
                    for (const h of (o.hits || [])) {
                        const id = String(h.app_id || "")
                        if (!/^[A-Za-z0-9_-]+(\.[A-Za-z0-9_-]+)+$/.test(id)) continue
                        if (h.type && h.type !== "desktop-application" && h.type !== "console-application") continue
                        out.push({ id: id, name: String(h.name || id), blurb: String(h.summary || ""), dev: String(h.developer_name || ""),
                                   verified: !!h.verification_verified, proprietary: h.is_free_license === false })
                    }
                } catch (e) {
                    ok = false
                }
                app.onlineSearching = false
                if (!ok) {
                    app.banner = { tone: "error", title: "Couldn't search Flathub", message: "Quasar can't reach flathub.org. Check that you're online and try again." }
                    return
                }
                catalog.addOnline(out)
                // Apps already on this page aren't shown twice; catalog apps the local search missed are.
                const shown = storeView.listIds
                app.onlineIds = out.map(e => e.id).filter(id => !!catalog.byId(id) && shown.indexOf(id) < 0)
                if (!out.length) app.banner = { tone: "info", title: "Nothing on Flathub matches “" + onlineSearch.query + "”", message: "Check the spelling, or try a shorter name." }
            }
        }
    }

    // ---- updates (asks the network only when the user presses Check) ------------------------------
    // Flathub apps, this account's developer tools (mise) and, for administrators, the Store's system
    // entries (Debian packages and vendor feeds such as Docker's).
    property var flatpakUpdates: []
    property var devUpdates: []
    property var sysUpdates: []
    readonly property var updates: flatpakUpdates.concat(devUpdates, sysUpdates)
    property bool updatesChecked: false
    property int checksRunning: 0
    readonly property bool checkingUpdates: checksRunning > 0
    property string updatesError: ""
    function checkUpdates() {
        updatesError = ""
        checksRunning = 1
        updateCheck.running = true
        if (catalog.apps.some(a => a.source === "mise" && installed.isInstalled(a))) {
            checksRunning++
            devOutdated.running = true
        }
        if (Platform.isAdmin && catalog.apps.some(a => a.source === "debian" && installed.isInstalled(a))) {
            checksRunning++
            sysCheck.found = []
            sysCheck.runHelper(["upgradable"])
        }
    }
    function checkDone() {
        checksRunning = Math.max(0, checksRunning - 1)
        if (checksRunning === 0) updatesChecked = true
    }
    function dropUpdate(id) {
        flatpakUpdates = flatpakUpdates.filter(u => u.id !== id)
        devUpdates = devUpdates.filter(u => u.id !== id)
        sysUpdates = sysUpdates.filter(u => u.id !== id)
    }
    function row(id, ver) {
        const c = catalog.byId(id)
        return { id: id, name: c ? c.name : id, glyph: c ? c.glyph : "pkg", hue: c ? c.hue : Theme.text3,
                 icon: State.iconUrl(c, catalog.dir), ver: ver }
    }
    Process {
        id: updateCheck
        command: ["sh", "-c", "flatpak remote-ls --updates --app --columns=application,version 2>&1; echo \"EXIT $?\""]
        stdout: StdioCollector {
            onStreamFinished: {
                const lines = text.trim().split("\n")
                const exit = lines.length ? lines[lines.length - 1] : "EXIT 1"
                if (exit !== "EXIT 0") {
                    app.updatesError = "Couldn't reach Flathub. Check that you're online and try again."
                } else {
                    const out = []
                    for (const l of lines.slice(0, -1)) {
                        const f = l.split("\t")
                        const id = (f[0] || "").trim()
                        const cur = installed.flatpaks[id]
                        if (!id || !cur) continue
                        out.push(app.row(id, (cur.version || "?") + " → " + ((f[1] || "").trim() || "newer")))
                    }
                    app.flatpakUpdates = out
                }
                app.checkDone()
            }
        }
    }
    Process {
        id: devOutdated
        command: Companies.wrapExec(["/usr/libexec/quasar/quasar-dev", "outdated"])     // the shown company's tools
        stdout: StdioCollector {
            onStreamFinished: {
                const line = text.split("\n").find(l => l.startsWith("OUTDATED "))
                const out = []
                try {
                    const o = line ? JSON.parse(line.slice(9)) : {}
                    for (const tool of Object.keys(o)) {
                        const c = catalog.apps.find(a => a.source === "mise" && a.tool === tool)
                        const r = o[tool] || {}
                        if (c && r.latest && r.latest !== r.current) out.push(app.row(c.id, (r.current || "?") + " → " + r.latest))
                    }
                } catch (e) { console.warn("store: unreadable outdated list:", e) }
                app.devUpdates = out
                app.checkDone()
            }
        }
    }
    Privileged {
        id: sysCheck
        helper: "quasar-pkg"
        property var found: []           // [[package, installed, new]]
        onLine: (l) => { const f = l.split("\t"); if (f.length === 3) found.push(f) }
        onFinished: (code) => {
            const out = []
            if (code === 0) {
                for (const a of catalog.apps) {
                    if (a.source !== "debian" || !installed.isInstalled(a)) continue
                    const mine = found.filter(f => (a.pkgs || []).indexOf(f[0]) >= 0)
                    if (!mine.length) continue
                    const main = mine.find(f => f[0] === a.pkgs[0]) || mine[0]
                    out.push(app.row(a.id, mine.length > 1 ? main[1] + " → " + main[2] + "  ·  " + mine.length + " packages" : main[1] + " → " + main[2]))
                }
            } else if (code !== 126) {
                app.updatesError = "Couldn't check the system packages for updates. Check that you're online and try again."
            }
            app.sysUpdates = out
            app.checkDone()
        }
    }

    // ---- window -----------------------------------------------------------------------------------
    AppWindow {
        id: win
        appName: "store"
        title: "Store"
        glyph: Icons.bag
        glyphColor: Theme.accent
        busy: jobs.active

        StoreView {
            id: storeView
            anchors.fill: parent
            apps: catalog.apps
            index: catalog.index
            categories: catalog.categories
            collections: catalog.collections
            runtimes: catalog.runtimes
            storeDir: catalog.dir
            jobStates: jobs.states
            installed: app.inst
            live: Platform.live
            details: catalog.details
            page: app.page
            query: app.query
            detailId: app.detailId
            updates: app.updates
            updatesChecked: app.updatesChecked
            checkingUpdates: app.checkingUpdates
            updatesError: app.updatesError
            banner: app.banner
            softwareRender: Platform.softwareRender
            versionsLoading: app.versionsFor
            online: app.onlineIds
            onlineSearching: app.onlineSearching
            onNavigate: (p) => { app.query = ""; app.detailId = ""; app.page = p }
            onQueryEdited: (t) => { app.query = t; app.detailId = ""; app.onlineIds = [] }
            onOpenDetail: (id) => app.detailId = id
            onCloseDetail: app.detailId = ""
            onGetApp: (id) => app.getApp(id)
            onOpenApp: (id) => app.openApp(id)
            onRemoveApp: (id) => { purgeSwitch.checked = false; app.pendingRemove = id }
            onCancelApp: (id) => jobs.cancel(id)
            onCheckUpdates: app.checkUpdates()
            onUpdateApp: (id) => jobs.enqueue(id, "update")
            onUpdateAll: { for (const u of app.updates) jobs.enqueue(u.id, "update") }
            onBannerAction: {
                const b = app.banner
                app.banner = null
                if (b && b.action === "browsers") { app.detailId = ""; app.query = "web browser" }
                else Quickshell.execDetached(["sh", "-c", "gtk-launch quasar-installer || /usr/bin/quasar-installer"])
            }
            onSearchOnline: (t) => app.searchOnline(t)
            onOpenHomepage: (id, url) => app.openHomepage(url)
            onInstallTool: (id, spec) => app.installTool(id, spec)
            onSetToolDefault: (id, version) => app.setToolDefault(id, version)
            onRemoveToolVersion: (id, version) => app.removeToolVersion(id, version)
            onOtherVersions: (id) => app.otherVersions(id)
        }

        Dialog {
            open: app.pendingOnline !== ""
            title: "Search Flathub online?"
            message: "Quasar will send your search words to flathub.org to find apps that are newer than this Store. Apps found there weren't hand-picked by Quasar and have no privacy label yet, so check what they can reach before you install them."
            onDismissed: app.pendingOnline = ""
            buttons: [
                Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: app.pendingOnline = "" },
                Button { text: "Search Flathub"; variant: "primary"; size: 38; onClicked: { app.onlineConsent = true; const t = app.pendingOnline; app.pendingOnline = ""; app.searchOnline(t) } }
            ]
        }

        Dialog {
            open: app.pendingInstall !== ""
            title: "You're running from the installer USB"
            message: "Apps you get now are kept in memory and disappear when you restart. To keep them, install Quasar first."
            onDismissed: app.pendingInstall = ""
            buttons: [
                Button { text: "Install Quasar"; variant: "outline"; size: 38; onClicked: { app.pendingInstall = ""; Quickshell.execDetached(["sh", "-c", "gtk-launch quasar-installer || /usr/bin/quasar-installer"]) } },
                Button { text: "Get it anyway"; variant: "primary"; size: 38; onClicked: { app.liveNoticeShown = true; const id = app.pendingInstall; app.pendingInstall = ""; jobs.enqueue(id, "install", app.pendingOpts) } }
            ]
        }
        Dialog {
            id: removeDialog
            readonly property var target: catalog.byId(app.pendingRemove)
            readonly property bool docker: !!target && target.setup === "docker"
            open: app.pendingRemove !== ""
            title: target ? "Remove " + target.name + "?" : ""
            message: !target ? ""
                   : docker ? "Docker stops and is removed, and its package feed is turned off. Your containers, images and volumes stay unless you delete them too."
                   : target.source === "mise" ? "Every version of " + target.name + " is removed from your account. Projects that ask for a version will need it installed again."
                   : target.source === "debfile" ? target.name + " is removed for everyone on this PC, with the packages it brought along that nothing else needs"
                                                   + ((target.addedSources || []).length ? " and the update source it added." : ".")
                                                   + " Your settings in your home folder stay."
                   : "Its settings and files in your home folder stay, so it picks up where you left off if you get it again."
            onDismissed: app.pendingRemove = ""
            Row {
                visible: removeDialog.docker
                height: visible ? implicitHeight : 0
                spacing: 12
                QSwitch { id: purgeSwitch; anchors.verticalCenter: parent.verticalCenter; accessibleName: "Also delete containers, images and volumes"; onToggled: checked = !checked }
                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: "Also delete containers, images and volumes"
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
                    color: purgeSwitch.checked ? Theme.danger : Theme.text3
                }
            }
            buttons: [
                Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: app.pendingRemove = "" },
                Button {
                    text: removeDialog.docker && purgeSwitch.checked ? "Remove and delete" : "Remove"
                    variant: "primary"; tone: Theme.danger; size: 38
                    onClicked: { const id = app.pendingRemove; app.pendingRemove = ""; jobs.enqueue(id, "remove", { purgeData: removeDialog.docker && purgeSwitch.checked }) }
                }
            ]
        }
        ChoiceSheet {
            id: versionPicker
            property string toolId: ""
            onChosen: (k) => { open = false; app.installTool(toolId, k) }
            onDismissed: open = false
        }
    }

    // Job state for Quasar AI's install/remove steps (shell/services/Assistant.qml reads it; only the Store
    // writes it): { jobs: { id: { state, progress, phase, action, cancellable, cancelling } },
    //               results: { id: { ok, message, cancelled, at } } }.
    // Progress is written at most twice a second; results right away.
    property var jobResults: ({})
    function jobResult(id, ok, message, cancelled) {
        const r = Object.assign({}, jobResults)
        r[id] = { ok: ok, message: message || "", cancelled: !!cancelled, at: Date.now() }
        jobResults = r
        publishJobsNow()
    }
    function publishJobs() { if (!publishTimer.running) publishTimer.start() }
    function publishJobsNow() { publishTimer.stop(); jobsFile.setText(JSON.stringify({ jobs: jobs.states, results: jobResults })) }
    Timer { id: publishTimer; interval: 500; onTriggered: app.publishJobsNow() }
    FileView {
        id: jobsFile
        path: (Quickshell.env("XDG_RUNTIME_DIR") || "/tmp") + "/quasar-store-jobs.json"
        printErrors: false
    }

    // Install/remove calls that arrive before the catalog has loaded wait for it (the caller hears
    // "queued", and the outcome comes through the jobs file like any other).
    property var parked: []
    function _unpark() {
        const list = parked
        parked = []
        for (const p of list) {
            if (!catalog.byId(p.id)) { jobResult(p.id, false, "That app isn't in the Store"); continue }
            detailId = p.id
            if (p.verb === "install") {
                liveNoticeShown = true
                if (jobs.stateOf(p.id)) continue
                getApp(p.id)
                if (!jobs.stateOf(p.id)) jobResult(p.id, false, banner ? banner.title : "It couldn't be installed")
            } else if (!jobs.enqueue(p.id, "remove")) {
                jobResult(p.id, false, "It's busy")
            }
        }
    }

    IpcHandler {
        target: "app"
        function open(arg: string): void { app.navigateTo(arg); win.visible = true }
        // Programmatic install and removal (Quasar AI asks the user first; tests): no live-USB notice,
        // no confirmation dialog. Returns "queued", "busy" (already queued or running), "refused" or
        // "unknown". Before the catalog has loaded: "queued", and the call runs once it has.
        function install(id: string): string {
            // A package from a file is installed only from its page, where the user reads what it is.
            if (id.startsWith("deb:")) return "file"
            if (!catalog.ready) { app.parked = app.parked.concat([{ verb: "install", id: id }]); return "queued" }
            if (!catalog.byId(id)) return "unknown"
            app.liveNoticeShown = true; app.detailId = id
            if (jobs.stateOf(id)) return "busy"
            app.getApp(id)
            return jobs.stateOf(id) ? "queued" : "refused"
        }
        function remove(id: string): string {
            if (!catalog.ready) { app.parked = app.parked.concat([{ verb: "remove", id: id }]); return "queued" }
            if (!catalog.byId(id)) return "unknown"
            app.detailId = id
            return jobs.enqueue(id, "remove") ? "queued" : "busy"
        }
        // Same as the Cancel button. Returns "cancelling" (stopping a running install), "cancelled"
        // (taken out of the queue), "running" (it can't be stopped any more) or "idle" (nothing to cancel).
        function cancel(id: string): string {
            const s = jobs.stateOf(id)
            if (!s) return "idle"
            if (!s.cancellable) return s.cancelling ? "cancelling" : "running"
            const queued = s.state === "queued"
            jobs.cancel(id)
            return queued ? "cancelled" : "cancelling"
        }
        function ready(): bool { return catalog.ready }
        // Tests: what the list holds and how many cards were ever made (a job's progress must make none),
        // and a scripted scroll through the current list (frame timing).
        function stats(): string {
            return JSON.stringify({ apps: catalog.apps.length, page: app.page, query: app.query,
                                    list: storeView.listIds.length, cards: storeView.cardsCreated })
        }
        function scrollDemo(ms: int): void { storeView.scrollDemo(ms) }
    }
}
