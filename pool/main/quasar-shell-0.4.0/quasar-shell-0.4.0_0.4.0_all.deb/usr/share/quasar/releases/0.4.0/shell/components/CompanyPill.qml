import QtQuick
import Quasar

// Company switcher pill (template, top right of the desktop): the company's badge, its name and a
// chevron that turns while the menu is open. The amber dot means another company has something for
// you (notifications held while it was hidden, a window that opened there).
Pressable {
    id: root
    property string name: "Personal"
    property string initials: "P"
    property color hue: Theme.accent
    property bool alert: false
    property bool open: false

    kind: "chip"
    radius: 13
    color: "#B80A0C14"                         // rgba(10,12,20,.72)
    hoverColor: "#D60C0E18"
    borderColor: Theme.alpha(hue, 0.35)
    hoverBorderColor: Theme.alpha(hue, 0.55)
    accessibleName: "Company: " + name + ". Switch company"
    implicitWidth: row.implicitWidth + 7 + 10
    implicitHeight: 38

    Row {
        id: row
        x: 7
        anchors.verticalCenter: parent.verticalCenter
        spacing: 9
        Rectangle {
            width: 26; height: 26; radius: 8
            color: root.hue
            Behavior on color { ColorAnimation { duration: Motion.dur(500) } }
            Text {
                anchors.centerIn: parent
                text: root.initials
                textFormat: Text.PlainText
                color: Theme.accentInk
                font.family: Theme.fontUi; font.pointSize: Theme.pt(10.5); font.weight: Font.ExtraBold
            }
        }
        Text {
            anchors.verticalCenter: parent.verticalCenter
            width: Math.min(implicitWidth, 180)
            text: root.name
            textFormat: Text.PlainText
            elide: Text.ElideRight
            color: Theme.text
            font.family: Theme.fontUi; font.pixelSize: 13; font.weight: Font.DemiBold
        }
        QIcon {
            anchors.verticalCenter: parent.verticalCenter
            path: Icons.chev
            size: 14
            color: Theme.textMuted
            rotation: root.open ? 180 : 0
            Behavior on rotation {
                NumberAnimation { duration: Motion.dur(Motion.chip); easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.spring }
            }
        }
    }

    Rectangle {
        visible: root.alert
        x: -3; y: -3
        width: 10; height: 10; radius: 5
        color: Theme.amber
        border.width: 2
        border.color: "#0A0C14"
        // Pulses only while there is something to see, and never in Lite or with reduced motion.
        SequentialAnimation on opacity {
            running: root.alert && Theme.ambientMotion
            loops: Animation.Infinite
            alwaysRunToEnd: true
            NumberAnimation { to: 0.35; duration: 650; easing.type: Easing.InOutSine }
            NumberAnimation { to: 1; duration: 650; easing.type: Easing.InOutSine }
        }
    }
}
