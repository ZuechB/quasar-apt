import QtQuick

// Runs a Quasar root helper (/usr/libexec/quasar/<helper>) through pkexec. The shell's polkit agent
// shows the password sheet when the action needs one (on the live session it doesn't).
//   Privileged { id: pkg; helper: "quasar-pkg"; onLine: …; onFinished: (code) => … }
//   pkg.runHelper(["install", "gimp"])
// pkexec exit codes: 126 = the user cancelled the password prompt, 127 = not authorized / no agent.
Cmd {
    id: root
    property string helper: ""
    readonly property bool cancelledByUser: _last === 126
    readonly property bool notAuthorized: _last === 127
    property int _last: 0

    // input: optional stdin text (specs, secret values): never put those in args.
    function runHelper(args, input) {
        _last = 0
        run(["pkexec", "/usr/libexec/quasar/" + helper].concat(args || []), undefined, input)
    }
    onFinished: (code) => _last = code
}
