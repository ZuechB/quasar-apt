import QtQuick
import Quasar
import "Format.js" as Format

// Images page: download an image (docker pull) and the images on this PC — size, age, whether a
// container uses it — with Run and Remove.
Column {
    id: root
    property var images: []                // with inUse
    property var busy: ({})
    property bool pulling: false
    property string pullStatus: ""
    signal pull(string ref)
    signal imageAction(var image, string action)

    spacing: 0
    width: parent ? parent.width : 700

    readonly property real total: images.reduce((s, i) => s + (i.size || 0), 0)
    function go() {
        const ref = refField.text.trim()
        if (!/^[A-Za-z0-9][A-Za-z0-9._\/:@-]*$/.test(ref) || root.pulling) return
        root.pull(ref)
        refField.text = ""
    }

    Item {
        width: parent.width
        height: 34
        Text {
            anchors.verticalCenter: parent.verticalCenter
            text: "Images"
            font.family: Theme.fontDisplay; font.pixelSize: 18; font.weight: Font.Medium
            color: Theme.text
        }
        Text {
            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
            visible: root.images.length > 0
            text: root.images.length + (root.images.length === 1 ? " image" : " images") + "  ·  " + Format.bytes(root.total)
            font.family: Theme.fontUi; font.pixelSize: 12
            color: Theme.textDim
        }
    }
    Item { width: 1; height: 12 }
    Item {
        width: parent.width
        height: 38
        TextField {
            id: refField
            anchors { left: parent.left; right: pullBtn.left; rightMargin: 8 }
            placeholder: "Download an image, e.g. nginx:alpine or postgres:17"
            glyph: Icons.download
            onAccepted: root.go()
        }
        Button {
            id: pullBtn
            anchors.right: parent.right
            text: root.pulling ? "Downloading" : "Download"
            busy: root.pulling
            enabled: !root.pulling && refField.text.trim() !== ""
            variant: "primary"; size: 38
            onClicked: root.go()
        }
    }
    Text {
        visible: root.pulling
        width: parent.width
        topPadding: 8
        elide: Text.ElideRight
        text: root.pullStatus
        font.family: Theme.fontMono; font.pointSize: Theme.pt(11.5)
        color: Theme.textDim
    }
    Text {
        width: parent.width
        topPadding: 8
        wrapMode: Text.Wrap
        text: "Images come from Docker Hub unless the name says otherwise (ghcr.io/…, quay.io/…). Downloads start only when you press Download."
        font.family: Theme.fontUi; font.pixelSize: 12
        color: Theme.textFaint
    }
    Item { width: 1; height: 16 }

    Rectangle {
        visible: root.images.length > 0
        width: parent.width
        height: list.implicitHeight
        radius: 16
        color: Theme.white(0.035)
        border.width: 1; border.color: Theme.white(0.06)
        Column {
            id: list
            width: parent.width
            Repeater {
                model: root.images
                Item {
                    id: imgRow
                    required property int index
                    required property var modelData
                    readonly property bool working: !!root.busy["image:" + modelData.id] || !!root.busy["image:" + modelData.ref]
                    width: list.width
                    height: 60
                    Rectangle { visible: imgRow.index > 0; width: parent.width; height: 1; color: Theme.white(0.05) }
                    QIcon {
                        id: ic
                        x: 16
                        anchors.verticalCenter: parent.verticalCenter
                        path: Icons.cube; size: 18; strokeWidth: 1.9
                        color: imgRow.modelData.dangling ? Theme.textFaint : Theme.text3
                    }
                    Column {
                        anchors { left: ic.right; leftMargin: 14; right: acts.left; rightMargin: 12; verticalCenter: parent.verticalCenter }
                        spacing: 3
                        Row {
                            width: parent.width
                            spacing: 8
                            Text {
                                anchors.verticalCenter: parent.verticalCenter
                                width: Math.min(implicitWidth, parent.width - (useChip.visible ? useChip.width + 8 : 0))
                                elide: Text.ElideMiddle
                                text: imgRow.modelData.dangling ? "Unnamed image" : imgRow.modelData.ref
                                font.family: Theme.fontUi; font.pixelSize: 14; font.weight: Font.DemiBold
                                color: imgRow.modelData.dangling ? Theme.textMuted : Theme.text
                            }
                            Chip {
                                id: useChip
                                anchors.verticalCenter: parent.verticalCenter
                                visible: imgRow.modelData.inUse
                                text: "In use"
                                tone: Theme.mint; fill: Theme.alpha(Theme.mint, 0.1)
                            }
                        }
                        Text {
                            width: parent.width
                            elide: Text.ElideRight
                            text: [Format.bytes(imgRow.modelData.size), imgRow.modelData.created, "ID " + imgRow.modelData.id.slice(0, 12)].filter(x => x).join("  ·  ")
                            font.family: Theme.fontUi; font.pixelSize: 12
                            color: Theme.textDim
                        }
                    }
                    Row {
                        id: acts
                        anchors { right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter }
                        spacing: 2
                        Spinner { visible: imgRow.working; anchors.verticalCenter: parent.verticalCenter; size: 14 }
                        Button {
                            visible: !imgRow.working && !imgRow.modelData.dangling
                            anchors.verticalCenter: parent.verticalCenter
                            text: "Run"; glyph: Icons.play
                            variant: "soft"; size: 30
                            onClicked: root.imageAction(imgRow.modelData, "run")
                        }
                        Button {
                            visible: !imgRow.working
                            anchors.verticalCenter: parent.verticalCenter
                            glyph: Icons.trash
                            variant: "ghost"; size: 30
                            fg: Theme.textDim
                            accessibleName: "Remove " + imgRow.modelData.ref
                            onClicked: root.imageAction(imgRow.modelData, "remove")
                        }
                    }
                }
            }
        }
    }
    Text {
        visible: root.images.length === 0
        width: Math.min(560, parent.width)
        wrapMode: Text.Wrap
        lineHeight: 1.25
        text: "No images yet. Download one above: Docker Hub has official images for most databases, languages and servers."
        font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
        color: Theme.textDim
    }
}
