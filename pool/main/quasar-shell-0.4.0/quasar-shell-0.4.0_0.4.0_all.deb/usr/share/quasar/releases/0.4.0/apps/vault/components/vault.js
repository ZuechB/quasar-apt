// Vault (apps/vault): pure helpers for its lists. No Qt objects, so previews and tests share them.
.pragma library

// Logins matching a search (title, site, address or username), sorted by title.
function filterLogins(logins, query) {
    var q = String(query || "").trim().toLowerCase()
    return (logins || []).filter(function (l) {
        if (!q) return true
        return [l.title, l.site, l.url, l.username].some(function (v) { return String(v || "").toLowerCase().indexOf(q) >= 0 })
    }).sort(function (a, b) {
        var x = String(a.title || a.site || "").toLowerCase(), y = String(b.title || b.site || "").toLowerCase()
        return x < y ? -1 : x > y ? 1 : String(a.username || "").localeCompare(String(b.username || ""))
    })
}

function filterPasskeys(passkeys, query) {
    var q = String(query || "").trim().toLowerCase()
    return (passkeys || []).filter(function (p) {
        return !q || [p.rpId, p.username, p.displayName].some(function (v) { return String(v || "").toLowerCase().indexOf(q) >= 0 })
    }).sort(function (a, b) { return String(a.rpId).localeCompare(String(b.rpId)) || String(a.username).localeCompare(String(b.username)) })
}

// "github.com" -> "G"; the monogram for a site.
function letter(text) {
    var m = String(text || "").replace(/^www\./, "").match(/[A-Za-z0-9]/)
    return m ? m[0].toUpperCase() : "?"
}

// A rough strength: 0 weak · 1 fair · 2 strong (length and character kinds).
function strength(pw) {
    var p = String(pw || "")
    var kinds = [/[a-z]/, /[A-Z]/, /[0-9]/, /[^A-Za-z0-9]/].filter(function (r) { return r.test(p) }).length
    if (p.length >= 14 && kinds >= 3 || p.length >= 20) return 2
    if (p.length >= 10 && kinds >= 2) return 1
    return 0
}
function strengthLabel(pw) { return ["Weak", "Fair", "Strong"][strength(pw)] }

// "seconds since 1970" text -> "Today", "Yesterday", "3 days ago", "12 Mar 2026"
function when(stamp, now) {
    var t = parseInt(stamp, 10)
    if (!t) return ""
    var n = now || Date.now() / 1000
    var days = Math.floor((n - t) / 86400)
    if (days <= 0) return "Today"
    if (days === 1) return "Yesterday"
    if (days < 30) return days + " days ago"
    var d = new Date(t * 1000)
    var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    return d.getDate() + " " + months[d.getMonth()] + " " + d.getFullYear()
}

function browserState(b) {
    return b.state === "ready" ? "Connected to Vault" : b.state === "keepassxc" ? "Used by KeePassXC" : "Not set up"
}
