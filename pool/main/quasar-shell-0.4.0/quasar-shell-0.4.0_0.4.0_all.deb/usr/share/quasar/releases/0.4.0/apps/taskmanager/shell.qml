//@ pragma AppId quasar-taskmanager
// Quasar Task Manager: what's running and how hard the PC works. Ctrl+Alt+Delete or Ctrl+Shift+Escape opens
// it (labwc keybinds run /usr/bin/quasar-taskmanager), and so does the launcher.
//   quasar-taskmanager [processes|performance]
// Processes: your apps, background programs, each company and the system, with CPU, memory, disk, network and
// GPU; End task (an administrator's password for the system's), and "Quasar desktop" restarts the taskbar and
// desktop like restarting Explorer. Performance: CPU, memory, disks, network adapters and graphics cards.
// It's its own process, started by labwc, so it works when the desktop shell doesn't; its launcher picks safe
// graphics when the desktop failed (linux/session/bin/quasar-taskmanager).
import QtQuick
import Quickshell
import Quickshell.Io
import Quickshell.Wayland
import Quasar
import Quasar.Services
import "components"
import "services"

ShellRoot {
    id: app

    Binding { target: Theme; property: "accent"; value: Settings.accent }
    Binding { target: Theme; property: "reduceMotion"; value: Settings.reduceMotion }
    Binding { target: Theme; property: "softwareRender"; value: Platform.softwareScene }
    Binding { target: Theme; property: "profile"; value: Platform.softwareRender ? 0 : (Settings.profile >= 0 ? Settings.profile : 1) }

    property string page: "processes"
    property var banner: null
    function go(arg) {
        const a = (arg || "").trim()
        if (a === "processes" || a === "performance") page = a
    }
    Component.onCompleted: go(Quickshell.env("QUASAR_APP_ARGS"))

    SysMon { id: mon }
    Tasks {
        id: tasks
        onDone: (b) => { app.banner = b; if (b) bannerTimer.restart() }
    }
    Timer { id: bannerTimer; interval: 8000; onTriggered: app.banner = null }

    // Windows by desktop entry (Wayland windows carry no process id, so an app's windows are matched by its
    // id): an app with a window is listed under Apps, the rest under Background programs.
    readonly property var windows: {
        const m = {}
        for (const t of ToplevelManager.toplevels.values) {
            const e = t.appId ? DesktopEntries.heuristicLookup(t.appId) : null
            const id = e ? e.id : (t.appId || "")
            if (!id) continue
            ;(m[id] = m[id] || []).push(t.title || "")
        }
        return m
    }
    // An app's name and picture: Quasar's own get their glyphs (as in the launcher), others their icon.
    readonly property var known: ({
        "quasar-files": { glyph: Icons.folder, hue: "#7AB8FF" }, "quasar-settings": { glyph: Icons.gear, hue: "#C9CFDC" },
        "quasar-store": { glyph: Icons.bag, hue: "#7AE7FF" }, "quasar-sites": { glyph: Icons.web, hue: "#7AE7FF" },
        "quasar-services": { glyph: Icons.cycle, hue: "#8CF5B0" }, "quasar-containers": { glyph: Icons.layers, hue: "#7AB8FF" },
        "quasar-terminal": { glyph: Icons.terminal, hue: "#8CF5B0" }, "quasar-vault": { glyph: Icons.shield, hue: "#FFD66B" },
        "quasar-taskmanager": { glyph: Icons.activity, hue: "#8CF5B0" }, "quasar-installer": { glyph: Icons.download, hue: "#7AE7FF" }
    })
    function lookup(appId) {
        const e = DesktopEntries.heuristicLookup(appId)
        const k = known[appId] || (e ? known[e.id] : null)
        if (!e && !k) return null
        return { name: e ? e.name : "", image: e && e.icon && !k ? Quickshell.iconPath(e.icon, true) : "",
                 glyph: k ? k.glyph : "", hue: k ? k.hue : "" }
    }
    readonly property var companyNames: {
        const m = {}
        for (const c of Companies.companies) m[c.id] = c.name
        return m
    }
    // The Quasar desktop is down when its group stays missing for 3 ticks (a restart takes a moment).
    property int shellMissing: 0
    Connections {
        target: mon
        function onTickChanged() {
            const up = (mon.tick.groups || []).some(g => g.key === "unit:quasar-shell")
            app.shellMissing = up ? 0 : app.shellMissing + 1
        }
    }

    IpcHandler {
        target: "app"
        // A second Ctrl+Alt+Delete: show the window again, so labwc raises and focuses it (a keybind brings
        // no activation token).
        function open(arg: string): void {
            app.go(arg)
            if (win.visible) { win.visible = false; raiseLater.restart() }
            else win.visible = true
        }
    }
    Timer { id: raiseLater; interval: 30; onTriggered: win.visible = true }

    AppWindow {
        id: win
        appName: "taskmanager"
        title: "Task Manager"
        glyph: Icons.activity
        glyphColor: "#8CF5B0"
        defaultSize: Qt.size(980, 640)

        TaskManagerView {
            id: view
            anchors.fill: parent
            page: app.page
            info: mon.info
            tick: mon.tick
            history: mon.history
            windows: app.windows
            appLookup: app.lookup
            companyNames: app.companyNames
            desktopDown: app.shellMissing >= 3
            busy: tasks.busy
            banner: app.banner
            onPagePicked: (p) => app.page = p
            onExpand: (keys) => mon.expand(keys)
            onEndTask: (row, plan) => tasks.end(row, plan)
            onRestartDesktop: tasks.restartDesktop()
            onSafeGraphics: tasks.safeGraphics()
            onBannerDismissed: app.banner = null
            // A service's log, live, in Services' console window (it opens even if Services wasn't running).
            onOpenLog: (t) => Quickshell.execDetached(["quasar-services", t])
        }
    }
}
