import QtQuick
import Quasar
import "services.js" as S

// The detail aside for one service (template svd): header (tile, name, kind and profile chips),
// description, the status card (CPU and memory while it runs, the reason when it failed), the actions
// row with the on/off switch, then for servers the update flow and "Players can join", the facts card,
// folder buttons, live logs and removal. Pure view: act(name, key, …), copy(text), copyFrom(archive).
Column {
    id: root
    property var item: ({})
    property var m: ({})
    property real now: Date.now()
    signal act(string name, var a, var b, var c)
    signal copy(string text)
    signal copyFrom(bool archive)
    function call(name, b, c) { root.act(name, root.item.key, b === undefined ? null : b, c === undefined ? null : c) }

    readonly property string key: item ? item.key || "" : ""
    readonly property var server: item && item.server ? item.server : null
    readonly property var st: S.statusOf(item || {}, now)
    readonly property bool live: S.live(item || {})
    readonly property color statusColor: st.color === "accent" ? Theme.accent : st.color === "fail" ? "#FF8F8F"
                                       : st.color === "sched" ? Theme.text3 : Theme.textDim
    readonly property bool updating: !!(m.updating && m.updating[key])
    readonly property var copyJob: m.copy && m.copy.key === key ? m.copy : null
    readonly property bool busy: !!m.busy
    readonly property var error: m.error && m.error.key === key ? m.error : null
    readonly property string confirm: m.confirm && m.confirm.key === key ? m.confirm.what : ""
    readonly property var stats: server ? m.stats : null
    readonly property var linkNames: ({ sites: "Sites", settings: "Settings", containers: "Containers", store: "the Store" })
    readonly property string linkName: item && item.link ? linkNames[item.link.app] || item.link.app : ""

    spacing: 16

    // Template: the detail rises in (rowIn .4s) when it replaces the add form.
    opacity: 0
    transform: Translate { id: rise; y: 8 }
    Component.onCompleted: enter.start()
    ParallelAnimation {
        id: enter
        NumberAnimation { target: root; property: "opacity"; to: 1; duration: Motion.dur(400); easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.soft }
        NumberAnimation { target: rise; property: "y"; to: 0; duration: Motion.dur(400); easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.soft }
    }

    // ---- header -----------------------------------------------------------------------------------
    Row {
        width: root.width
        spacing: 12
        AppTile {
            anchors.verticalCenter: parent.verticalCenter
            size: 50; radius: 15
            base: Theme.tileBase
            sheen: 0.14; borderAlpha: 0.10
            glyph: Icons[root.item.icon] || Icons.cycle
            glyphSize: 24; glyphStroke: 1.8
            hue: root.item.hue || Theme.accent
        }
        Column {
            width: root.width - 62
            anchors.verticalCenter: parent.verticalCenter
            spacing: 5
            Text {
                width: parent.width
                text: root.item.name || ""
                textFormat: Text.PlainText
                wrapMode: Text.WrapAnywhere
                font.family: Theme.fontDisplay; font.pixelSize: 20; font.weight: Font.Medium
                color: Theme.text
            }
            Row {
                spacing: 6
                Rectangle {
                    height: 22; radius: 6
                    width: kindText.implicitWidth + 16
                    color: Theme.white(0.07)
                    Text {
                        id: kindText
                        anchors.centerIn: parent
                        text: S.kindLabel(root.item || {})
                        font.family: Theme.fontUi; font.pixelSize: 11
                        color: Theme.text3
                    }
                }
                Rectangle {
                    height: 22; radius: 6
                    width: profRow.implicitWidth + 16
                    color: root.item.system ? Theme.white(0.07) : Theme.alpha(Theme.accent, 0.12)
                    Row {
                        id: profRow
                        anchors.centerIn: parent
                        spacing: 5
                        Rectangle {
                            anchors.verticalCenter: parent.verticalCenter
                            width: 6; height: 6; radius: 3
                            color: root.item.system ? Theme.text3 : Theme.accent
                        }
                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            text: root.item.system ? "System" : "Personal"
                            font.family: Theme.fontUi; font.pixelSize: 11; font.weight: Font.DemiBold
                            color: root.item.system ? Theme.text3 : Theme.accent
                        }
                    }
                }
            }
        }
    }

    Text {
        width: root.width
        visible: text !== ""
        text: root.item.desc || ""
        textFormat: Text.PlainText
        wrapMode: Text.Wrap
        lineHeight: 1.2
        font.family: Theme.fontUi; font.pixelSize: 13
        color: Theme.textMuted
    }

    Banner {
        visible: !!root.error
        width: root.width
        tone: "error"
        title: root.error ? root.error.message || "" : ""
        details: root.error ? root.error.details || "" : ""
        actionText: root.error && root.error.code === "not-readable" ? "Make readable" : ""
        onActionClicked: root.call("makeReadable")
    }

    // ---- stopped for an update ------------------------------------------------------------------
    Rectangle {
        visible: root.updating && !!root.server
        width: root.width
        height: upCol.implicitHeight + 28
        radius: 14
        color: Theme.accentTint
        border.width: 1
        border.color: Theme.accentLine
        Column {
            id: upCol
            x: 14; y: 14
            width: parent.width - 28
            spacing: 10
            Row {
                spacing: 8
                QIcon { anchors.verticalCenter: parent.verticalCenter; path: Icons.refresh; size: 16; strokeWidth: 2; color: Theme.accent }
                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: "Stopped for an update"
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5); font.weight: Font.DemiBold
                    color: Theme.text
                }
            }
            Text {
                width: parent.width
                text: "Put the new build in " + (root.server ? root.server.path : "its folder") + ", then press Start. Copying it in here moves the old files to the Trash first."
                textFormat: Text.PlainText
                wrapMode: Text.Wrap
                lineHeight: 1.15
                font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
                color: Theme.text2
            }
            Text {
                text: "Copy the new build in"
                font.family: Theme.fontUi; font.pixelSize: 11
                color: Theme.textFaint
            }
            Flow {
                width: parent.width
                spacing: 6
                Button {
                    variant: "outline"; size: 34; glyph: Icons.folder; text: "From a folder…"; fg: Theme.text
                    enabled: !(root.copyJob && root.copyJob.running)
                    onClicked: root.copyFrom(false)
                }
                Button {
                    variant: "outline"; size: 34; glyph: Icons.pkg; text: "From a .zip…"; fg: Theme.text
                    enabled: !(root.copyJob && root.copyJob.running)
                    onClicked: root.copyFrom(true)
                }
            }
            Column {
                visible: !!root.copyJob && (root.copyJob.running || !!root.copyJob.error)
                width: parent.width
                spacing: 6
                Text {
                    width: parent.width
                    text: root.copyJob ? (root.copyJob.error ? root.copyJob.error
                                          : "Copying the new build…" + (root.copyJob.percent > 0 ? " " + root.copyJob.percent + "%" : "")) : ""
                    textFormat: Text.PlainText
                    wrapMode: Text.Wrap
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(12)
                    color: root.copyJob && root.copyJob.error ? Theme.danger : Theme.text3
                }
                Rectangle {
                    visible: !!root.copyJob && root.copyJob.running
                    width: parent.width; height: 5; radius: 3
                    color: Theme.white(0.08)
                    Rectangle {
                        height: parent.height; radius: 3
                        width: parent.width * Math.max(0.04, (root.copyJob ? root.copyJob.percent : 0) / 100)
                        color: Theme.accent
                        Behavior on width { NumberAnimation { duration: Motion.dur(300) } }
                    }
                }
            }
            Rectangle { width: parent.width; height: 1; color: Theme.alpha(Theme.accent, 0.2) }
            Flow {
                width: parent.width
                spacing: 6
                Button {
                    variant: "primary"; size: 34; glyph: Icons.play; text: "Start"
                    busy: root.busy && !(root.copyJob && root.copyJob.running)
                    enabled: !root.busy && !(root.copyJob && root.copyJob.running)
                    onClicked: root.call("start")
                }
                Button {
                    variant: "ghost"; size: 34; glyph: Icons.open; text: "Open folder"
                    onClicked: root.call("openFolder")
                }
            }
        }
    }

    // ---- status card ------------------------------------------------------------------------------
    Rectangle {
        width: root.width
        height: statusCol.implicitHeight + 28
        radius: 16
        color: Theme.alpha(root.statusColor, 0.08)
        border.width: 1
        border.color: Theme.alpha(root.statusColor, 0.25)
        Behavior on color { ColorAnimation { duration: Motion.dur(400) } }
        Behavior on border.color { ColorAnimation { duration: Motion.dur(400) } }
        Column {
            id: statusCol
            x: 14; y: 14
            width: parent.width - 28
            spacing: 10
            Item {
                width: parent.width
                height: 22
                Row {
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: 8
                    QIcon {
                        id: bigIcon
                        anchors.verticalCenter: parent.verticalCenter
                        path: Icons[root.st.icon] || ""
                        size: 16; strokeWidth: 2.4
                        color: root.statusColor
                        RotationAnimation on rotation {
                            running: root.st.spin && !Theme.reduceMotion
                            from: 0; to: 360; duration: 1000; loops: Animation.Infinite
                            onRunningChanged: if (!running) bigIcon.rotation = 0
                        }
                    }
                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        text: root.st.label
                        font.family: Theme.fontUi; font.pixelSize: 15; font.weight: Font.DemiBold
                        color: root.statusColor
                    }
                }
                Text {
                    anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                    text: root.st.meta
                    textFormat: Text.PlainText
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5); font.features: { "tnum": 1 }
                    color: Theme.text3
                }
            }
            Row {
                visible: root.live
                width: parent.width
                spacing: 10
                Repeater {
                    id: bars
                    // CPU only where Services samples it (servers); memory comes with every row.
                    model: (root.server ? [
                        { label: "CPU", value: root.stats && root.stats.cpu !== null && root.stats.cpu !== undefined ? Math.round(root.stats.cpu) + "%" : "—",
                          pct: S.cpuPct(root.stats ? root.stats.cpu : 0), bar: root.statusColor } ] : []).concat([
                        { label: "Memory", value: S.bytesText(root.stats && root.stats.memory ? root.stats.memory : root.item.memory) || "—",
                          pct: S.memPct(root.stats && root.stats.memory ? root.stats.memory : root.item.memory), bar: Theme.text } ])
                    delegate: Column {
                        required property var modelData
                        width: (statusCol.width - 10 * (bars.count - 1)) / Math.max(1, bars.count)
                        spacing: 5
                        Item {
                            width: parent.width
                            height: 15
                            Text { text: modelData.label; font.family: Theme.fontUi; font.pointSize: Theme.pt(11.5); color: Theme.textMuted }
                            Text {
                                anchors.right: parent.right
                                text: modelData.value
                                font.family: Theme.fontUi; font.pointSize: Theme.pt(11.5); font.features: { "tnum": 1 }
                                color: Theme.textMuted
                            }
                        }
                        Rectangle {
                            width: parent.width; height: 5; radius: 3
                            color: Theme.white(0.08)
                            clip: true
                            Rectangle {
                                height: parent.height; radius: 3
                                width: parent.width * modelData.pct / 100
                                color: modelData.bar
                                Behavior on width { NumberAnimation { duration: Motion.dur(800); easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.soft } }
                            }
                        }
                    }
                }
            }
            Rectangle {
                readonly property var ls: root.server ? root.server.lastStart : null
                visible: root.item.status === "failed" && !!ls && !ls.ok
                width: parent.width
                height: errText.implicitHeight + 16
                radius: 10
                color: Qt.rgba(0, 0, 0, 0.28)
                Text {
                    id: errText
                    x: 10; y: 8
                    width: parent.width - 20
                    text: parent.ls ? S.reasonText(parent.ls.code, parent.ls.message, root.server) : ""
                    textFormat: Text.PlainText
                    wrapMode: Text.Wrap
                    lineHeight: 1.15
                    font.family: Theme.fontMono; font.pointSize: Theme.pt(11.5)
                    color: "#FFB3B3"
                }
            }
        }
    }

    // ---- actions ------------------------------------------------------------------------------------
    // The buttons wrap beside the on/off switch (template: flex-wrap, the switch at the end).
    readonly property bool canStart: item.kind !== "schedule" && (item.status === "stopped" || item.status === "failed") && S.can(item, "start") && !updating
    readonly property bool canRestart: live && S.can(item, "restart")
    readonly property bool canStop: live && S.can(item, "stop")
    readonly property bool canUpdate: !!server && S.can(item, "update") && !updating && item.status !== "starting"
    readonly property bool canToggle: S.can(item, "toggle")
    Item {
        width: root.width
        height: Math.max(root.canStart || root.canRestart || root.canStop || root.canUpdate ? actions.height : 0, root.canToggle ? 34 : 0)
        visible: root.canStart || root.canRestart || root.canStop || root.canUpdate || root.canToggle
        Flow {
            id: actions
            width: parent.width - (root.canToggle ? onOff.width + 10 : 0)
            spacing: 6
            Button {
                visible: root.canStart
                variant: "primary"; size: 34; glyph: Icons.play; text: "Start"
                busy: root.busy; enabled: !root.busy
                onClicked: root.call("start")
            }
            Button {
                visible: root.canRestart
                variant: "outline"; size: 34; glyph: Icons.refresh; text: "Restart"; fg: Theme.text
                enabled: !root.busy
                onClicked: root.call("restart")
            }
            Button {
                visible: root.canStop
                variant: "outline"; size: 34; glyph: Icons.stop; text: "Stop"; fg: Theme.text
                enabled: !root.busy
                onClicked: root.call("stop")
            }
            Button {
                visible: root.canUpdate
                variant: "outline"; size: 34; glyph: Icons.download; text: "Update…"; fg: Theme.text
                enabled: !root.busy
                onClicked: root.call("askUpdate")
            }
        }
        Row {
            id: onOff
            visible: root.canToggle
            anchors { right: parent.right; top: parent.top; topMargin: 3 }
            spacing: 8
            Text {
                anchors.verticalCenter: parent.verticalCenter
                text: root.item.enabled ? "On" : "Off"
                font.family: Theme.fontUi; font.pixelSize: 12
                color: Theme.textMuted
            }
            QSwitch {
                anchors.verticalCenter: parent.verticalCenter
                checked: !!root.item.enabled
                enabled: !root.busy
                accessibleName: "Turn " + (root.item.name || "") + " on or off"
                onToggled: root.call("toggle")
            }
        }
    }

    // Update…: stop it first (the files can't be swapped under a running program).
    Rectangle {
        visible: root.confirm === "update"
        width: root.width
        height: confirmUp.implicitHeight + 28
        radius: 14
        color: Theme.accentTint
        border.width: 1
        border.color: Theme.accentLine
        scale: visible ? 1 : 0.6
        Behavior on scale { NumberAnimation { duration: Motion.dur(450); easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.spring } }
        Column {
            id: confirmUp
            x: 14; y: 14
            width: parent.width - 28
            spacing: 12
            Text {
                width: parent.width
                text: "Stop " + (root.item.name || "it") + " so you can replace its files?"
                      + (root.m.players && root.m.players.now > 0 ? " " + root.m.players.now + (root.m.players.now === 1 ? " player is" : " players are") + " on it now." : "")
                textFormat: Text.PlainText
                wrapMode: Text.Wrap
                lineHeight: 1.15
                font.family: Theme.fontUi; font.pixelSize: 13
                color: Theme.text
            }
            Row {
                spacing: 8
                Button { variant: "primary"; size: 34; text: "Stop for the update"; busy: root.busy; enabled: !root.busy; onClicked: root.call("update") }
                Button { variant: "outline"; size: 34; text: "Keep it running"; fg: Theme.text; onClicked: root.call("cancelConfirm") }
            }
        }
    }

    // ---- players can join (servers) ----------------------------------------------------------------
    ServerNetwork {
        visible: !!root.server
        width: root.width
        item: root.item
        m: root.m
        now: root.now
        onAct: (name, a, b, c) => root.act(name, a, b, c)
        onCopy: (s) => root.copy(s)
    }

    // ---- facts --------------------------------------------------------------------------------------
    Rectangle {
        width: root.width
        height: factsCol.implicitHeight
        radius: 14
        color: Theme.white(0.03)
        border.width: 1
        border.color: Theme.white(0.06)
        clip: true
        Column {
            id: factsCol
            width: parent.width
            Repeater {
                model: S.facts(root.item || {}, root.now)
                delegate: Item {
                    required property var modelData
                    required property int index
                    width: factsCol.width
                    height: factCol.implicitHeight + 20
                    Rectangle { visible: index > 0; width: parent.width; height: 1; color: Theme.white(0.05) }
                    Column {
                        id: factCol
                        x: 12; y: 10
                        width: parent.width - 24
                        spacing: 3
                        Text { text: modelData.label; font.family: Theme.fontUi; font.pixelSize: 11; color: Theme.textFaint }
                        TextEdit {
                            width: parent.width
                            readOnly: true
                            selectByMouse: true
                            textFormat: TextEdit.PlainText
                            wrapMode: TextEdit.WrapAnywhere
                            text: modelData.value
                            font.family: modelData.mono ? Theme.fontMono : Theme.fontUi
                            font.pointSize: Theme.pt(modelData.mono ? 12 : 12.5)
                            color: Theme.text2
                            selectionColor: Theme.alpha(Theme.accent, 0.35)
                            selectedTextColor: Theme.text
                        }
                    }
                }
            }
        }
    }

    Flow {
        width: root.width
        spacing: 6
        visible: !!root.server || !!root.item.link
        Button {
            visible: !!root.server && !root.updating
            variant: "soft"; size: 34; glyph: Icons.folder; text: "Open folder"
            onClicked: root.call("openFolder")
        }
        Button {
            visible: !!root.server && !!root.server.data
            variant: "soft"; size: 34; glyph: Icons.drive; text: "Open save folder"
            onClicked: root.call("openData")
        }
        Button {
            visible: !!root.server && S.can(root.item, "settings")
            variant: "soft"; size: 34; glyph: Icons.gear; text: "Settings…"
            enabled: !root.busy
            onClicked: root.call("openSettings")
        }
        Button {
            visible: !root.server && !!root.item.link
            variant: "soft"; size: 34; glyph: Icons.fwd; text: "Open in " + root.linkName
            onClicked: root.call("openLink")
        }
    }

    // ---- logs (journald, live): the newest lines here, everything in its console window ----------------
    LogPreview {
        width: root.width
        lines: root.m.logs || []
        onOpenConsole: root.call("openConsole")
        onOpenTerminal: root.call("openTerminal")
    }

    // ---- removal ------------------------------------------------------------------------------------
    Pressable {
        visible: S.can(root.item, "remove") && root.confirm !== "remove"
        width: rmRow.implicitWidth + 24
        height: 34
        kind: "chip"
        radius: 10
        borderColor: Qt.rgba(1, 143 / 255, 143 / 255, 0.35)
        accessibleName: "Remove from background"
        onClicked: root.call("askRemove")
        Row {
            id: rmRow
            anchors.centerIn: parent
            spacing: 8
            QIcon { anchors.verticalCenter: parent.verticalCenter; path: Icons.trash; size: 15; strokeWidth: 2; color: Theme.danger }
            Text { anchors.verticalCenter: parent.verticalCenter; text: "Remove from background"; font.family: Theme.fontUi; font.pixelSize: 13; color: Theme.danger }
        }
    }
    Rectangle {
        visible: root.confirm === "remove"
        width: root.width
        height: confirmRm.implicitHeight + 28
        radius: 14
        color: Qt.rgba(1, 143 / 255, 143 / 255, 0.08)
        border.width: 1
        border.color: Qt.rgba(1, 143 / 255, 143 / 255, 0.3)
        Accessible.role: Accessible.AlertMessage
        Accessible.name: "Confirm removal"
        scale: visible ? 1 : 0.6
        Behavior on scale { NumberAnimation { duration: Motion.dur(450); easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.spring } }
        Column {
            id: confirmRm
            x: 14; y: 14
            width: parent.width - 28
            spacing: 12
            Text {
                width: parent.width
                text: root.server
                      ? "Remove " + (root.item.name || "") + "? The service, its firewall openings and its saved data are deleted. Its folder stays where it is."
                      : "Remove " + (root.item.name || "") + "? The service and its settings are deleted. The app itself stays installed."
                textFormat: Text.PlainText
                wrapMode: Text.Wrap
                lineHeight: 1.15
                font.family: Theme.fontUi; font.pixelSize: 13
                color: Theme.text
            }
            Row {
                spacing: 8
                Pressable {
                    width: rmText.implicitWidth + 28; height: 34; radius: 10; kind: "chip"
                    color: "#FF8F8F"
                    accessibleName: "Remove"
                    enabled: !root.busy
                    onClicked: root.call("remove")
                    Text { id: rmText; anchors.centerIn: parent; text: "Remove"; font.family: Theme.fontUi; font.pixelSize: 13; font.weight: Font.DemiBold; color: Theme.accentInk }
                }
                Button { variant: "outline"; size: 34; text: "Keep it"; fg: Theme.text; onClicked: root.call("cancelConfirm") }
            }
        }
    }

    Text {
        visible: !!root.item.system
        width: root.width
        text: "Quasar needs this to work." + (root.linkName ? " Manage it in " + root.linkName + "." : "")
        wrapMode: Text.Wrap
        lineHeight: 1.15
        font.family: Theme.fontUi; font.pixelSize: 12
        color: Theme.textFaint
    }
}
