import QtQuick
import Quickshell
import Quickshell.Io
import Quasar

// The shell's word about system updates, from /run/quasar/update-state.json (written in place by root:
// quasar-update-state.service whenever packages or package lists change). Nothing is polled. One toast
// per change, opening Settings › Updates:
// - "Restart to finish installing updates": once updates are in but a new kernel or the desktop's own
//   libraries only start after a restart; shown again at each sign-in while it's true;
// - "Security updates are ready": only when automatic updates are off (otherwise they just install).
// And about snapshots, from /run/quasar/snapshot-state.json (quasar-snapshot), opening Settings › Snapshots:
// - "You're running a snapshot": this start runs one (GRUB's menu, or "Start it once"); changes vanish at
//   the next restart;
// - "Restart to finish restoring": a restore waits for the restart.
// "Restart to finish" never shows while something is still installing (the state's "running": dpkg's lock;
// "job": a driver install): a driver install switches the kernel first, and that newer kernel once made this
// toast ask for a restart in the middle of the NVIDIA install. quasar-update writes the state again when the
// install is over, and the toast comes then.
// A driver install that ends (/run/quasar/drivers-job.json, quasar-drivers' job, which runs even with
// Settings closed) gets its own toast, and so does an install that a restart cut off and that the next start
// finished or undid (/var/lib/quasar/boot-repair.json, quasar-boot-repair), once.
//   QUASAR_UPDATE_STATE=/path, QUASAR_SNAPSHOT_STATE=/path: other files (tests).
Item {
    id: root
    visible: false
    signal toast(var t)
    readonly property string path: Quickshell.env("QUASAR_UPDATE_STATE") || "/run/quasar/update-state.json"
    property string restartShown: ""
    property int securityShown: 0
    readonly property string snapshotPath: Quickshell.env("QUASAR_SNAPSHOT_STATE") || "/run/quasar/snapshot-state.json"
    property string snapshotShown: ""
    // The driver job seen last: its state and when it ended (a shell restart doesn't toast an old ending).
    property string jobState: ""
    property var jobEnded: undefined
    // The boot repair's report already shown (its "at"), kept in ~/.local/state/quasar/boot-repair-seen.
    readonly property string seenPath: (Quickshell.env("XDG_STATE_HOME") || (Quickshell.env("HOME") + "/.local/state")) + "/quasar/boot-repair-seen"
    property var repairSeen: undefined          // undefined until the file was read
    property var repairReport: null

    function checkJob(j) {
        if (!j) return
        const st = j.state || "idle"
        const first = jobEnded === undefined
        if (!first && st !== jobState && jobState === "running" && j.ended !== jobEnded) {
            if (st === "done")
                toast({ title: j.id === "nvidia" ? (j.action === "remove" ? "Switched to the open driver" : "NVIDIA's driver is installed")
                                                 : "Firmware is installed",
                        sub: j.reboot ? "Restart the PC to finish." : "",
                        glyph: Icons.monitor, hue: Theme.accent, settings: "drivers" })
            else if (st === "failed")
                toast({ title: "That didn't work", sub: (j.error || "The driver couldn't be set up.") + " Nothing else was changed.",
                        glyph: Icons.monitor, hue: Theme.amber, settings: "drivers" })
        }
        jobState = st
        jobEnded = j.ended === undefined ? null : j.ended
    }

    function checkRepair() {
        const r = repairReport
        if (!r || repairSeen === undefined || !r.at || r.at <= (repairSeen || 0)) return
        toast({ title: r.title || "Quasar finished an install that a restart cut off", sub: r.message || "",
                glyph: Icons.refresh, hue: r.driver === "failed" || r.dpkg === "failed" || r.driver === "gave-up" ? Theme.amber : Theme.accent,
                settings: r.driver && r.driver !== "none" ? "drivers" : "updates" })
        repairSeen = r.at
        Quickshell.execDetached(["sh", "-c", 'mkdir -p "${1%/*}" && echo "$2" > "$1"', "sh", seenPath, String(r.at)])
    }

    function checkSnapshots(st) {
        if (!st || !st.btrfs) return
        const key = st.booted ? "booted:" + st.booted.id : st.pending ? "pending:" + st.pending.old : ""
        if (key && key !== snapshotShown) {
            if (st.booted)
                toast({ title: "You're running a snapshot",
                        sub: "Anything you change now is gone at the next restart. Restore it in Settings to keep this system.",
                        glyph: Icons.restore, hue: Theme.accent, settings: "snapshots" })
            else
                toast({ title: "Restart to finish restoring",
                        sub: "The restored system starts next time. Until then, nothing new is installed.",
                        glyph: Icons.restore, hue: Theme.accent, settings: "snapshots" })
        }
        snapshotShown = key
    }

    function check(st) {
        if (!st || st.live) return
        const r = st.restart || {}
        const key = r.needed ? [r.kernel || "", r.flagged ? "flag" : "", (r.services || []).length, r.session ? "session" : ""].join("|") : ""
        // Still installing: say nothing yet (and remember nothing, so the toast comes once it's over).
        if (st.running || st.job)
            return
        if (key && key !== restartShown)
            toast({ title: "Restart to finish installing updates",
                    sub: (r.kernel ? "A new Linux kernel is ready." : "Some updated parts start after a restart.")
                         + (st.restartAt && st.restartAt !== "now" ? " Quasar restarts by itself at " + st.restartAt + "." : ""),
                    glyph: Icons.refresh, hue: Theme.accent, settings: "updates" })
        restartShown = key
        const sec = !st.auto && st.pending ? (st.pending.security || 0) : 0
        if (sec > 0 && sec !== securityShown)
            toast({ title: sec === 1 ? "A security update is ready" : sec + " security updates are ready",
                    sub: "Automatic updates are off. Install them in Settings › Updates.",
                    glyph: Icons.shield, hue: Theme.accent, settings: "updates" })
        securityShown = sec
    }
    FileView {
        path: root.path
        watchChanges: true
        printErrors: false
        onFileChanged: reload()
        onLoaded: { try { root.check(JSON.parse(text())) } catch (e) { } }
    }
    FileView {
        path: root.snapshotPath
        watchChanges: true
        printErrors: false
        onFileChanged: reload()
        onLoaded: { try { root.checkSnapshots(JSON.parse(text())) } catch (e) { } }
    }
    FileView {       // made at boot by tmpfiles (quasar-drivers.conf), so it's watched from the start
        path: Quickshell.env("QUASAR_DRIVERS_JOB") || "/run/quasar/drivers-job.json"
        watchChanges: true
        printErrors: false
        onFileChanged: reload()
        onLoaded: { try { root.checkJob(JSON.parse(text())) } catch (e) { } }
    }
    FileView {
        path: root.seenPath
        printErrors: false
        onLoaded: { root.repairSeen = parseInt(text()) || 0; root.checkRepair() }
        onLoadFailed: (error) => { root.repairSeen = 0; root.checkRepair() }
    }
    FileView {
        path: Quickshell.env("QUASAR_BOOT_REPAIR") || "/var/lib/quasar/boot-repair.json"
        printErrors: false
        onLoaded: { try { root.repairReport = JSON.parse(text()); root.checkRepair() } catch (e) { } }
    }
}
