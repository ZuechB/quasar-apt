//@ pragma Env QS_NO_RELOAD_POPUP=1
// Quasar Shell — Quickshell entry point. Runs on any wlroots compositor (Wayfire, labwc):
//   qs --path /usr/share/quasar/shell
// Visual components live in ./components (pure Qt Quick, previewable without Quickshell) and the
// Quasar design system module (ui/Quasar, installed into the Qt QML import path).
import QtQuick
import Quickshell
import Quickshell.Wayland
import Quickshell.Io
import Quickshell.Services.Polkit
import Quasar.Services
import Quasar
import "components"
import "services"
import "components/desktopLayout.js" as Layout

ShellRoot {
    id: shell

    // ---------------------------------------------------------------- environment
    readonly property bool softwareRender: Quickshell.env("QUASAR_SOFTWARE_RENDER") === "1"
    readonly property string compositor: Quickshell.env("QUASAR_COMPOSITOR") || "labwc"
    readonly property bool live: Quickshell.env("QUASAR_LIVE") === "1"
    readonly property string home: Quickshell.env("HOME") || "/root"
    readonly property string userName: Quickshell.env("QUASAR_USER_NAME") || Quickshell.env("USER") || "You"
    // ---------------------------------------------------------------- displays
    // Every display has the wallpaper and (Settings.displays.taskbarAll, default on) a taskbar. The main
    // display (services/Displays.qml: the saved choice, else the built-in, else the top-left one) has
    // the desktop icons, toasts and sign-in prompts; sw/sh are its size. Panels and menus open on
    // `panelScreen`, the display they were opened from, and size themselves by psw/psh.
    Displays { id: displays }
    readonly property var main: displays.main
    readonly property real sw: main ? main.width : 1440
    readonly property real sh: main ? main.height : 900
    readonly property var panelScreen: ui.screen && displays.has(ui.screen) ? ui.screen : main
    readonly property real psw: panelScreen ? panelScreen.width : sw
    readonly property real psh: panelScreen ? panelScreen.height : sh
    // The assistant sheet stays on the display it was opened on while its steps open apps.
    property var aiScreen: null
    readonly property var assistantScreen: aiScreen && displays.has(aiScreen) ? aiScreen : main
    // A keyboard shortcut or an IPC call opens a panel where you're working: the active window's display.
    function focusScreen() {
        const t = ToplevelManager.activeToplevel
        const n = t && t.screens && t.screens.length && t.screens[0] ? t.screens[0].name : ""
        return (n && displays.named(n)) || shell.main
    }
    function sameScreen(a, b) { return !!a && !!b && a.name === b.name }

    // ---------------------------------------------------------------- services
    Apps { id: apps; pins: Settings.pins; desktopActive: deskUi.focused; desk: companyDesk }
    // Company environments: one hidden account, network and desktop per company (services/CompanyDesk).
    CompanyDesk {
        id: companyDesk
        apps: apps
        onToast: (t) => shell.toast(t)
        onClosePanels: ui.close()
        onMenuRequested: ui.toggle("companies")
    }
    CompanyWindows { desk: companyDesk; ui: ui; screen: shell.main; onManageRequested: shell.openSettings("profiles") }
    // Keyed taskbar model: when a window's title or focus changes, the existing task delegates stay
    // (and their indicator/scale springs animate) instead of every taskbar item being rebuilt.
    ScriptModel { id: taskScript; values: apps.taskModel; objectProp: "key" }
    SystemControls { id: sys; nightLight: Settings.nightLight }
    // Restart / Shut down wait for installs a restart would break (services/RestartGuard.qml): the power
    // menu shows what's installing, and asking anyway opens restartWin's dialog.
    RestartGuard { id: restartGuard; sys: sys; onToast: (t) => shell.toast(t) }
    Connections {
        target: ui
        function onOpenChanged() { if (ui.open === "power") restartGuard.check() }
    }
    // The lock screen (services/ScreenLock.qml): sys.lock(), logind's lock-session, before sleep.
    ScreenLock { id: screenLock; controls: sys; displayName: shell.userName; mainScreen: shell.main }
    // Vault's questions (a passkey, a new site, a browser connecting): IPC "vault" from vaultd.
    VaultPrompts { screen: shell.main }
    MediaKeys { id: mediaKeys }     // play/pause/next/previous keys + Bluetooth headset buttons (IPC "media")
    // Command Deck: phones on the home network as a remote (deckd; Settings › Command Deck).
    CommandDeck {
        id: deck
        apps: apps; sys: sys; media: mediaKeys; lock: screenLock; desk: companyDesk; restartGuard: restartGuard
        onToast: (t) => shell.toast(t)
    }
    // Remote desktop (VNC): your other computers see and use this screen (vnc-run + wayvnc; Settings ›
    // Users & Accounts › Remote desktop). Viewers see the main display.
    RemoteDesktop {
        id: remoteDesktop
        lock: screenLock
        mainName: shell.main ? shell.main.name : ""
        onToast: (t) => shell.toast(t)
    }
    // Quasar AI: the assistant panel's state and its desktop tools (services/Assistant.qml). The model
    // runs in /usr/libexec/quasar/quasar-ai, started the first time the assistant is used.
    Assistant {
        id: assistant
        appSvc: apps
        sysSvc: sys
        onOpenSettings: (page) => shell.openSettings(page)
        onOpenTerminal: (dir) => shell.openTerminal(dir)
        onToast: (t) => shell.toast(t)
    }
    Connections {                         // switching company closes the assistant (template)
        target: Companies
        function onActiveChanged() { assistant.open = false }
    }
    LazyLoader { id: notifLoader; active: true; source: "services/Notifications.qml" }
    readonly property var notifs: notifLoader.item
    SystemClock { id: clock; precision: SystemClock.Minutes }
    // ~/Desktop as icons + the file work behind the desktop's menus and drops.
    DesktopFolder {
        id: desktop
        apps: apps
        live: shell.live
        area: Qt.size(shell.sw, shell.sh - Theme.taskbarHeight)
        areaKnown: shell.main !== null
        onMessage: (t) => shell.toast(t)
        onOpenFolderRequested: (p) => shell.openFiles(p)
        onProgramRequested: (p, how) => programs.open(p, how)
        onCreated: (key) => { deskUi.renameAfter = key; deskUi.selection = [key]; shell.renameIfShown() }
        onItemsChanged: shell.renameIfShown()
    }
    Connections {        // "Set as wallpaper" on a picture that can't be copied (gone, unreadable)
        target: Settings
        function onPhotoFailed(path) { shell.toast({ title: "Couldn't use that picture", sub: path.slice(path.lastIndexOf("/") + 1), glyph: Icons.image, hue: Theme.danger }) }
    }
    // Keyed: an icon whose name, spot or state changes keeps its delegate (no re-pop-in).
    ScriptModel { id: deskScript; values: desktop.viewItems; objectProp: "key" }

    // Software rendering (no GPU: Hyper-V, QEMU std VGA) always runs Lite — glass, shadows and
    // animated wallpapers would make every frame (and the software cursor) slow.
    Binding { target: Theme; property: "profile"; value: shell.softwareRender ? 0 : (Settings.profile >= 0 ? Settings.profile : 1) }
    // Qt's software scene graph (set by /usr/bin/quasar-shell when there is no GPU): no shaders,
    // so the wallpaper switches to its pre-rendered still.
    Binding { target: Theme; property: "softwareRender"; value: Quickshell.env("QT_QUICK_BACKEND") === "software" }
    Binding { target: Theme; property: "accent"; value: Companies.accent }      // the shown company's colour
    Binding { target: Theme; property: "wallpaperPhoto"; value: Settings.wallpaperPhoto }
    Binding { target: Theme; property: "wallpaperFit"; value: Settings.wallpaperFit }
    Binding { target: Theme; property: "glassEnabled"; value: Settings.glass }
    Binding { target: Theme; property: "reduceMotion"; value: Settings.reduceMotion }
    Binding { target: Theme; property: "compositorBlur"; value: shell.compositor === "wayfire" }
    Binding { target: shell.notifs; property: "dnd"; value: Settings.focus; when: shell.notifs !== null }

    // ---------------------------------------------------------------- start-up reveal
    // The boot splash (src/BootSplash) ends on Theme.bg, the wallpaper window's own color: the wallpaper
    // fades up from it, then the taskbar and the desktop icons rise in. Once per shell start; none with
    // reduced motion. On software rendering the wallpaper shows at once (a full-screen fade there is
    // ~50 full repaints); only the small parts move.
    property real introWall: 0
    property real introBar: 0
    property real introIcons: 0
    SequentialAnimation {
        id: intro
        PauseAnimation { duration: 120 }      // let the first Theme.bg frame land
        ParallelAnimation {
            NumberAnimation {
                target: shell; property: "introWall"; to: 1
                duration: Theme.softwareRender ? 1 : 900; easing.type: Easing.OutCubic
            }
            SequentialAnimation {
                PauseAnimation { duration: Theme.softwareRender ? 60 : 260 }
                NumberAnimation {
                    target: shell; property: "introBar"; to: 1; duration: Motion.panel
                    easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.spring
                }
            }
            SequentialAnimation {
                PauseAnimation { duration: Theme.softwareRender ? 140 : 380 }
                NumberAnimation { target: shell; property: "introIcons"; to: 1; duration: 450; easing.type: Easing.OutCubic }
            }
        }
    }
    Component.onCompleted: {
        sys.refresh()                     // once, not per taskbar (there's one on every display)
        if (Theme.reduceMotion) { introWall = 1; introBar = 1; introIcons = 1 }
        else intro.start()
    }

    // ---------------------------------------------------------------- UI state
    QtObject {
        id: ui
        property string open: ""         // "" | launcher | quick | calendar | context | power | windows | task
        property real ctxX: 0
        property real ctxY: 0
        property string taskKey: ""      // taskbar button whose window list ("windows") or menu ("task") is open
        property var menuItems: []
        property var menuWindows: []
        property string query: ""
        property bool allApps: false
        property var menuApp: null       // launcher app whose menu ("appmenu") is open
        property var screen: null        // the display the panel or menu opens on (shell.panelScreen)
        // The panel a menu was opened from, kept open beneath it: the launcher under its power menu and
        // an app's menu. A click on the panel closes just the menu (back()), a click elsewhere both.
        property string under: ""
        readonly property bool launcherShown: open === "launcher" || under === "launcher"
        // s: the display to open on (the taskbar or wallpaper clicked). Without one: where the open
        // panel is, else the active window's display. The same panel on the same display toggles off.
        function toggle(n, s) {
            if ((open === n || under === n) && (!s || shell.sameScreen(s, shell.panelScreen))) { close(); return }
            show(n, s)
        }
        // Moving to another display closes first: a layer surface never changes screen while it shows.
        function show(n, s) {
            const target = s || (open !== "" ? shell.panelScreen : shell.focusScreen())
            if (open !== "" && !shell.sameScreen(target, shell.panelScreen)) {
                close()
                Qt.callLater(() => ui.showOn(n, target))
                return
            }
            showOn(n, target)
        }
        // open before under, here and below: the panel beneath never unmaps in between (it would lose
        // the keyboard and its search text).
        function showOn(n, s) { screen = s; open = n; under = ""; if (n === "launcher") { query = ""; allApps = false } }
        // A menu over the open panel, on its display.
        function over(n) { if (under === "") under = open; open = n }
        function back() { if (under === "") { open = ""; return } open = under; under = "" }
        function close() { open = ""; under = "" }
    }

    // Desktop icon state (primary screen). Coordinates are screen pixels: the icon window sits at 0,0.
    QtObject {
        id: deskUi
        property var selection: []       // keys (file names; /home /trash /install for the fixed icons)
        property var band: null          // selection box { x, y, width, height } while dragging one
        property point bandFrom: Qt.point(0, 0)
        property bool pressing: false
        property string dropKey: ""      // folder / Trash under a drag
        property var dragging: []        // keys being dragged
        property string dragAnchor: ""   // the tile the drag started on
        property point dragHot: Qt.point(48, 46)
        property string renaming: ""     // key whose rename box is open
        property bool renameCancelled: false
        property string renameAfter: ""  // a just-created item: rename it as soon as it shows up
        property var menuKeys: []        // items an "item" menu acts on
        property point linkAt: Qt.point(-1, -1)  // where a new website shortcut goes
        // A desktop surface has the keyboard. labwc leaves the last window "activated" meanwhile, so the
        // taskbar uses this to treat a click on that window's button as "focus it", not "minimize".
        property bool wallActive: false
        property bool iconsActive: false
        readonly property bool focused: wallActive || iconsActive
    }

    // Toast stack (max 3), fed by the notification server and by shell actions.
    property var toasts: []
    property int toastSeq: 0
    function toast(t) { toastSeq++; toasts = toasts.concat([Object.assign({ id: toastSeq }, t)]).slice(-3) }
    function dropToast(id) { toasts = toasts.filter(t => t.id !== id) }
    Connections {
        target: shell.notifs
        ignoreUnknownSignals: true
        function onPopup(n) {
            shell.toast({
                title: n.summary || n.appName || "Notification",
                sub: n.body || "",
                glyph: Icons.bell,
                hue: Theme.accent,
                icon: n.image ? n.image : (n.appIcon ? Quickshell.iconPath(n.appIcon, true) : ""),
                notif: n
            })
        }
    }
    readonly property var history: {
        const n = shell.notifs
        if (!n || !n.trackedNotifications) return []
        return n.trackedNotifications.values.map(x => ({ id: x.id, title: x.summary || x.appName, sub: x.body || "", glyph: Icons.bell, hue: Theme.accent, notif: x }))
    }

    // ---------------------------------------------------------------- actions
    // Opens Settings, optionally at a section (network, display, appearance…): a running Settings
    // window is deep-linked over IPC by /usr/bin/quasar-settings itself.
    function openSettings(section) { if (!apps.launchId("quasar-settings", section ? [section] : [])) shell.toast({ title: "Settings", sub: "The Settings app is not installed", glyph: Icons.gear, hue: Theme.text3 }); ui.close() }
    function openFiles(path) { const p = companyDesk.filesPath(path); apps.launchId("quasar-files", p ? [p] : []); ui.close() }
    // dir: start the shell there (desktop "Open Terminal here", a folder's "Open in Terminal").
    function openTerminal(dir) {
        if (companyDesk.terminal(dir)) { ui.close(); return }      // a company is shown: its own terminal
        // Quasar's Terminal (a running one opens this as a new tab); foot when it isn't installed.
        const a = dir ? ["--working-directory=" + dir] : []
        if (!apps.launchId("quasar-terminal", dir ? ["--cwd", dir] : [])
            && !apps.launchId("org.codeberg.dnkl.footclient", a) && !apps.launchId("footclient", a))
            apps.launchId("org.codeberg.dnkl.foot", a)
        ui.close()
    }

    readonly property var settingsPages: [
        { key: "network", title: "Network & Internet", kw: "wifi wi-fi internet vpn ethernet dns", glyph: Icons.wifi },
        { key: "firewall", title: "Firewall", kw: "firewall incoming connections ports block allow home network", glyph: Icons.shield },
        { key: "vpn", title: "VPN", kw: "vpn wireguard openvpn tunnel work home server", glyph: Icons.lock },
        { key: "hotspot", title: "Mobile hotspot", kw: "hotspot tethering share internet phone access point", glyph: Icons.hotspot },
        { key: "dns", title: "Encrypted DNS", kw: "dns encrypted private secure dot quad9 cloudflare nextdns", glyph: Icons.globe },
        { key: "bluetooth", title: "Bluetooth & Devices", kw: "bluetooth devices pair", glyph: Icons.bt },
        { key: "display", title: "Display", kw: "display resolution scale refresh night wallpaper background vrr variable hdr", glyph: Icons.monitor },
        { key: "arrange", title: "Arrange displays", kw: "displays monitors screens multiple second external arrange identify main taskbar", glyph: Icons.monitor },
        { key: "desktop", title: "Desktop", kw: "desktop icons arrange grid snap free placement auto tidy", glyph: Icons.layers },
        { key: "sound", title: "Sound", kw: "sound audio volume speaker microphone", glyph: Icons.vol },
        { key: "appearance", title: "Appearance", kw: "accent theme color transparency animations", glyph: Icons.palette },
        { key: "privacy", title: "Privacy & Security", kw: "privacy camera microphone location", glyph: Icons.shield },
        { key: "performance", title: "Performance", kw: "performance raspberry pi lite speed max", glyph: Icons.bolt },
        { key: "apps", title: "Apps", kw: "apps default startup install", glyph: Icons.grid },
        { key: "about", title: "About", kw: "about system version", glyph: Icons.info }
    ]

    function groupsFor(q) {
        const query = q.trim().toLowerCase()
        if (!query) return []
        const words = query.split(/\s+/)
        const match = (hay) => words.every(w => hay.toLowerCase().includes(w))
        const doItems = [
            { title: sys.wifiOn ? "Turn off Wi-Fi" : "Turn on Wi-Fi", sub: "Network", glyph: Icons.wifi, hue: Theme.accent, tag: "Run", kw: "wifi wi-fi network internet wireless", action: () => sys.setWifi(!sys.wifiOn) },
            { title: Settings.focus ? "End Focus" : "Focus", sub: "Hold notifications", glyph: Icons.target, hue: "#B9A4FF", tag: "Run", kw: "focus do not disturb dnd quiet", action: () => Settings.focus = !Settings.focus },
            { title: Settings.nightLight ? "Night light off" : "Night light on", sub: "Warmer screen", glyph: Icons.moon, hue: "#FFD66B", tag: "Run", kw: "night light warm display blue", action: () => Settings.nightLight = !Settings.nightLight },
            { title: "Switch to Lite performance", sub: "No blur, still wallpaper", glyph: Icons.bolt, hue: Theme.mint, tag: "Run", kw: "lite performance raspberry pi fast low power", action: () => Settings.profile = 0 },
            { title: "Change wallpaper", sub: "Settings › Display", glyph: Icons.image, hue: "#FF9BD2", tag: "Open", kw: "wallpaper background", action: () => shell.openSettings("display") },
            { title: "Lock screen", sub: "Session", glyph: Icons.lock, hue: Theme.text3, tag: "Run", kw: "lock screen away", action: () => sys.lock() },
            { title: "New website", sub: "Host a .NET, Node or static project with HTTPS", glyph: Icons.web, hue: "#7AE7FF", tag: "Open", kw: "site website host hosting web app server dotnet asp.net kestrel node deploy domain https ssl certificate", action: () => { apps.launchId("quasar-sites", ["new"]); ui.close() } },
            { title: "Manage background services", sub: "Startup, scheduled and always-running apps", glyph: Icons.cycle, hue: "#8CF5B0", tag: "Run", kw: "services startup background daemon schedule cron systemd server game multiplayer host unity", action: () => { apps.launchId("quasar-services"); ui.close() } }
        ].concat(companyDesk.showSwitcher ? Companies.list.filter(c => c.id !== Companies.active).map(c => (
            { title: "Switch to " + c.name, sub: c.personal ? "Your own account" : "Its own desktop, network and sign-ins",
              glyph: Icons.brief, hue: c.color, tag: "Run", kw: "company switch workspace " + c.name + " " + c.id,
              action: () => companyDesk.switchTo(c.id) })) : [])
         .filter(d => match(d.title + " " + d.kw)).slice(0, 4)
        const appItems = apps.search(query, 5).map(a => Object.assign(a, { title: a.name, tag: "Open" }))
        const setItems = settingsPages.filter(p => match(p.title + " " + p.kw)).slice(0, 3)
            .map(p => ({ title: p.title, sub: "Settings", glyph: p.glyph, hue: Theme.text3, tag: "Open", action: () => shell.openSettings(p.key) }))
        return [["Do", doItems], ["Apps", appItems], ["Settings", setItems]]
            .filter(g => g[1].length).map(g => ({ label: g[0], items: g[1] }))
    }

    function activate(item) {
        if (!item) return
        if (item.entry) apps.launch(item.entry)
        else if (item.action) item.action()
        ui.close()
    }

    // ---------------------------------------------------------------- taskbar menus
    // "windows": the window list a click on an app with several windows opens (pick one, like Windows).
    // "task": the right-click menu (New window, Pin/Unpin, Close). Both are shown by menuWin, right
    // above the button; `x` is the button's centre (x on `screen`, the taskbar's display). Clicking the
    // same button again closes it.
    function openTaskMenu(kind, item, x, screen) {
        if (!item) return
        const s = screen || shell.panelScreen
        if (ui.open === kind && ui.taskKey === item.key && shell.sameScreen(s, shell.panelScreen)) { ui.close(); return }
        const wins = kind === "windows" ? item.windows.slice() : []
        const items = wins.map((t, i) => ({ key: "win:" + i, label: t.title || item.name,
                                            glyph: t.minimized ? Icons.minus : t.activated ? Icons.check : Icons.square }))
        if (kind === "windows") {
            if (item.entry) items.push({ sep: true }, { key: "new", label: "New window", glyph: Icons.plus })
        } else {
            if (item.entry) {
                items.push({ key: "new", label: item.running ? "New window" : "Open", glyph: Icons.plus })
                items.push(item.pinned ? { key: "unpin", label: "Unpin from taskbar", glyph: Icons.pin2 }
                                       : { key: "pin", label: "Pin to taskbar", glyph: Icons.pin2 })
            }
            if (item.running) {
                if (items.length) items.push({ sep: true })
                items.push({ key: "close", label: item.count > 1 ? "Close all windows" : "Close window", glyph: Icons.x })
            }
        }
        if (!items.length) return
        ui.taskKey = item.key
        ui.menuWindows = wins
        ui.menuItems = items
        ui.ctxX = x - 118                 // menuWin clamps it on screen and seats it above the taskbar
        ui.ctxY = s ? s.height : shell.sh
        ui.show(kind, s)
    }
    // The taskbar's phone icon (Command Deck): who is connected, and a way to stop them.
    function openDeckMenu(x, screen) {
        const s = screen || shell.panelScreen
        if (ui.open === "deck" && shell.sameScreen(s, shell.panelScreen)) { ui.close(); return }
        const items = deck.phones.map(p => ({ key: "phone:" + p.id, label: p.name + (p.screen ? " · sees the screen" : " · connected"),
                                              glyph: p.screen ? Icons.monitor : Icons.phone }))
        items.push({ sep: true })
        if (deck.live) items.push({ key: "stopScreen", label: "Stop sharing the screen", glyph: Icons.x })
        items.push({ key: "disconnect", label: "Disconnect phones", glyph: Icons.link })
        items.push({ key: "settings", label: "Command Deck settings", glyph: Icons.gear })
        ui.menuItems = items
        ui.ctxX = x - 118
        ui.ctxY = s ? s.height : shell.sh
        ui.show("deck", s)
    }
    function deckMenuActivated(key) {
        ui.close()
        if (key === "stopScreen") deck.stopScreen()
        else if (key === "disconnect") deck.disconnect()
        else if (key === "settings" || key.startsWith("phone:")) shell.openSettings("commanddeck")
    }
    // The taskbar's remote desktop icon: which computers use this screen, and a way to end it.
    function openVncMenu(x, screen) {
        const s = screen || shell.panelScreen
        if (ui.open === "vnc" && shell.sameScreen(s, shell.panelScreen)) { ui.close(); return }
        const items = remoteDesktop.viewers.map(v => ({ key: "viewer:" + v.id, glyph: Icons.monitor,
            label: (v.address || "A computer") + (v.username ? " · " + v.username : "") }))
        items.push({ sep: true })
        items.push({ key: "disconnect", label: remoteDesktop.count === 1 ? "Disconnect it" : "Disconnect them all", glyph: Icons.link })
        items.push({ key: "settings", label: "Remote desktop settings", glyph: Icons.gear })
        ui.menuItems = items
        ui.ctxX = x - 118
        ui.ctxY = s ? s.height : shell.sh
        ui.show("vnc", s)
    }
    // The taskbar's Services tray: what stopped working (each opens its log, live), the live log of every
    // service, and Services itself (services/BackgroundServices.qml; quasar-services log/<key>).
    function openServicesMenu(x, screen) {
        const s = screen || shell.panelScreen
        if (ui.open === "services" && shell.sameScreen(s, shell.panelScreen)) { ui.close(); return }
        const items = bgServices.failedList.map(f => ({ key: f.key ? "log:" + f.key : "open", glyph: Icons.alert,
                                                        label: f.name, hint: f.key ? "View log" : "" }))
        if (items.length) items.push({ sep: true })
        items.push({ key: "every", label: "Live log of every service", glyph: Icons.activity })
        items.push({ key: "open", label: "Open Services", glyph: Icons.cycle })
        ui.menuItems = items
        ui.ctxX = x - 118
        ui.ctxY = s ? s.height : shell.sh
        ui.show("services", s)
    }
    function servicesMenuActivated(key) {
        ui.close()
        if (key.startsWith("log:")) apps.launchId("quasar-services", ["log/" + key.slice(4)])
        else if (key === "every") apps.launchId("quasar-services", ["log"])
        else apps.launchId("quasar-services")
    }
    function vncMenuActivated(key) {
        ui.close()
        if (key === "disconnect") remoteDesktop.disconnectAll()
        else if (key.startsWith("viewer:")) remoteDesktop.disconnect(key.slice(7))
        else if (key === "settings") shell.openSettings("remotedesktop")
    }
    function taskMenuActivated(key) {
        const item = apps.taskModel.find(t => t.key === ui.taskKey)
        const wins = ui.menuWindows
        ui.close()
        if (key.startsWith("win:")) { apps.focusWindow(wins[parseInt(key.slice(4))]); return }
        if (!item) return
        if (key === "new") apps.newWindow(item)
        else if (key === "close") apps.closeAll(item)
        else if (key === "pin" && item.entry) Settings.pins = Settings.pins.concat([item.entry.id])
        // Unpin every pin id that resolves to this app (the default pins list several terminal ids).
        else if (key === "unpin" && item.entry)
            Settings.pins = Settings.pins.filter(p => { const e = apps.byId(p); return p !== item.entry.id && !(e && e.id === item.entry.id) })
    }
    // A window list or menu whose app went away (or gained/lost windows) is out of date: close it.
    Connections {
        target: apps
        function onTaskModelChanged() {
            if (ui.open !== "windows" && ui.open !== "task") return
            const it = apps.taskModel.find(t => t.key === ui.taskKey)
            if (!it || (ui.open === "windows" && it.count !== ui.menuWindows.length)) ui.close()
        }
    }

    // ---------------------------------------------------------------- desktop icons
    // Empty desktop space (the wallpaper, or a gap in the icon window): left press-drag draws a selection
    // box, a plain left click clears the selection, a right click opens the desktop menu.
    function deskPress(x, y, button) {
        ui.close()
        if (button !== Qt.LeftButton) return
        deskUi.pressing = true
        deskUi.bandFrom = Qt.point(x, y)
        deskUi.band = null
    }
    function deskMove(x, y) {
        if (!deskUi.pressing) return
        // Motion stays with the pressed surface, so it can run past its edges.
        x = Math.max(0, Math.min(shell.sw - 1, x))
        y = Math.max(0, Math.min(shell.sh - Theme.taskbarHeight - 1, y))
        const o = deskUi.bandFrom
        if (!deskUi.band && Math.abs(x - o.x) < 4 && Math.abs(y - o.y) < 4) return
        const r = { x: Math.min(o.x, x), y: Math.min(o.y, y), width: Math.abs(x - o.x), height: Math.abs(y - o.y) }
        deskUi.band = r
        deskUi.selection = Layout.hit(desktop.pos, r)
    }
    function deskRelease(x, y, button) {
        const banded = deskUi.band !== null
        deskUi.pressing = false
        deskUi.band = null
        if (banded) return
        deskUi.selection = []
        if (button === Qt.RightButton) {
            desktop.checkPaste()
            ui.ctxX = x; ui.ctxY = y
            ui.show("context", shell.main)
        }
    }
    // A right click on another display's wallpaper: the desktop menu there. What it makes (New,
    // Paste) goes on the main display's desktop, in the first free spot.
    function screenMenu(s, x, y) {
        deskUi.selection = []
        desktop.checkPaste()
        ui.ctxX = x; ui.ctxY = y
        ui.show("context", s)
    }
    function pruneSelection() {
        const keys = new Set(desktop.items.map(i => i.key))
        if (deskUi.selection.some(k => !keys.has(k))) deskUi.selection = deskUi.selection.filter(k => keys.has(k))
    }
    // A click on an icon: it alone; with Ctrl (or Shift) it joins the selection, or leaves it.
    function deskClick(key, mods) {
        if (!(mods & (Qt.ControlModifier | Qt.ShiftModifier))) { deskUi.selection = [key]; return }
        const i = deskUi.selection.indexOf(key)
        deskUi.selection = i >= 0 ? deskUi.selection.filter(k => k !== key) : deskUi.selection.concat([key])
    }
    // "New" is a flyout (ContextMenu `sub`): more kinds of new things go in that list.
    readonly property var desktopMenu: (assistant.enabled ? [{ key: "ask", label: "Ask Quasar", glyph: Icons.orbit }, { sep: true }] : []).concat([
        { key: "new", label: "New", glyph: Icons.plus, sub: [
            { key: "newfolder", label: "Folder", glyph: Icons.folder },
            { key: "newtext", label: "Text document", glyph: Icons.notes },
            { key: "newlink", label: "Website shortcut…", glyph: Icons.link }
        ] },
        { sep: true }
    ]).concat(desktop.canPaste ? [{ key: "paste", label: "Paste", glyph: Icons.paste }] : []).concat([
        { key: "terminal", label: "Open Terminal here", glyph: Icons.terminal },
        { sep: true },
        { key: "display", label: "Display settings", glyph: Icons.monitor },
        { key: "desktop", label: "Show desktop", glyph: Icons.grid }
    ])

    // Right click on an icon: it joins (or becomes) the selection and the menu acts on all of it.
    function deskContext(key, x, y) {
        if (deskUi.selection.indexOf(key) < 0) deskUi.selection = [key]
        const items = shell.itemMenu(deskUi.selection)
        if (!items.length) return
        deskUi.menuKeys = deskUi.selection.slice()
        ui.menuItems = items
        ui.ctxX = x; ui.ctxY = y
        ui.show("item", shell.main)
    }
    function itemMenu(keys) {
        const its = keys.map(k => desktop.find(k)).filter(i => !!i)
        if (!its.length) return []
        const one = its.length === 1 ? its[0] : null
        const out = [{ key: "open", label: its.length > 1 ? "Open " + its.length + " items"
                                         : one.kind === "program" ? "Run" : one.kind === "package" ? "Install" : "Open", glyph: Icons.open }]
        if (one && one.kind === "program") {
            if (one.script && apps.byId("quasar-texteditor")) out.push({ key: "edit", label: "Edit", glyph: Icons.pencil })
            out.push({ key: "runterm", label: "Run in Terminal", glyph: Icons.terminal })
            if (/\.appimage$/i.test(one.name)) out.push({ key: "toapps", label: "Add to Apps", glyph: Icons.grid })
        }
        if (one && (one.kind === "dir" || one.kind === "home")) out.push({ key: "terminal", label: "Open in Terminal", glyph: Icons.terminal })
        if (one && one.kind === "image" && !/\.ico$/i.test(one.path)) out.push({ key: "setwall", label: "Set as wallpaper", glyph: Icons.image })
        if (one && one.kind === "trash")
            return out.concat(desktop.trashFull ? [{ sep: true }, { key: "empty", label: "Empty Trash", glyph: Icons.trash }] : [])
        const files = its.filter(i => !desktop.isFixed(i))
        if (!files.length) return out
        out.push({ sep: true }, { key: "cut", label: "Cut", glyph: Icons.scissors }, { key: "copy", label: "Copy", glyph: Icons.copy })
        if (one) out.push({ key: "rename", label: "Rename", glyph: Icons.pencil })
        out.push({ sep: true })
        if (files.every(i => i.kind === "archive")) out.push({ key: "extract", label: "Extract here", glyph: Icons.pkg })
        out.push({ key: "compress", label: "Compress to .zip", glyph: Icons.layers })
        out.push({ sep: true }, { key: "trash", label: files.length > 1 ? "Move " + files.length + " items to Trash" : "Move to Trash", glyph: Icons.trash })
        return out
    }
    // Opens up to 12 selected icons. A program runs only when it's the only one selected and a .deb
    // opens only the first, so Ctrl+A, Enter can't queue a dozen questions.
    function openItems(keys) {
        const its = keys.slice(0, 12).map(k => desktop.find(k)).filter(i => !!i)
        const progs = its.filter(i => i.kind === "program")
        let pkg = false
        for (const it of its) {
            if (it.kind === "program" && its.length > 1) continue
            if (it.kind === "package") { if (pkg) continue; pkg = true }
            desktop.open(it)
        }
        if (progs.length && its.length > 1)
            shell.toast({ title: "Open programs one at a time", sub: progs.length === 1 ? progs[0].name : progs.length + " programs weren't opened",
                          glyph: Icons.cube, hue: "#7AE7FF" })
    }
    function itemMenuActivated(key) {
        const keys = deskUi.menuKeys
        ui.close()
        if (key === "open") shell.openItems(keys)
        else if (key === "edit") { const it = desktop.find(keys[0]); if (it) apps.launchId("quasar-texteditor", [it.path]) }
        else if (key === "runterm") { const it = desktop.find(keys[0]); if (it) programs.open(it.path, "terminal") }
        else if (key === "toapps") { const it = desktop.find(keys[0]); if (it) programs.open(it.path, "apps") }
        else if (key === "terminal") { const it = desktop.find(keys[0]); if (it) shell.openTerminal(it.path) }
        else if (key === "setwall") { const it = desktop.find(keys[0]); if (it) Settings.useWallpaperPhoto(it.path) }
        else if (key === "cut" || key === "copy") desktop.clip(keys, key === "cut")
        else if (key === "rename") shell.startRename(keys[0])
        else if (key === "extract") desktop.extract(keys)
        else if (key === "compress") desktop.compress(keys)
        else if (key === "trash") { desktop.trash(keys); deskUi.selection = [] }
        else if (key === "empty") {            // permanent: ask once more, in place
            const n = desktop.trashCount
            ui.menuItems = [{ key: "emptyok", label: "Delete " + n + (n === 1 ? " item" : " items") + " forever", glyph: Icons.trash },
                            { key: "cancel", label: "Cancel", glyph: Icons.x }]
            ui.show("item")
        }
        else if (key === "emptyok") desktop.emptyTrash()
    }
    function deskKey(e) {
        const sel = deskUi.selection
        const ctrl = (e.modifiers & Qt.ControlModifier) !== 0
        if (e.key === Qt.Key_Delete) { desktop.trash(sel); deskUi.selection = [] }
        else if (e.key === Qt.Key_F2 && sel.length === 1) shell.startRename(sel[0])
        else if ((e.key === Qt.Key_Return || e.key === Qt.Key_Enter) && sel.length) shell.openItems(sel)
        else if (ctrl && e.key === Qt.Key_A) deskUi.selection = desktop.items.map(i => i.key)
        else if (ctrl && (e.key === Qt.Key_C || e.key === Qt.Key_X)) desktop.clip(sel, e.key === Qt.Key_X)
        else if (ctrl && e.key === Qt.Key_V) desktop.paste(-1, -1)
        else if (e.key === Qt.Key_Escape) deskUi.selection = []
        else return
        e.accepted = true
    }

    // Dragging icons: the whole selection goes (files to other apps; folders, the Trash or a new spot).
    function deskDragStart(key, hx, hy) {
        ui.close()
        if (deskUi.selection.indexOf(key) < 0) deskUi.selection = [key]
        deskUi.dragAnchor = key
        deskUi.dragHot = Qt.point(hx, hy)
        deskUi.dragging = deskUi.selection.slice()
    }
    // CRLF-separated, no trailing CRLF: Qt splits a string uri-list on CRLF only. Home, Trash and
    // Install are never offered: a Home icon dropped on another drive would move the home folder.
    readonly property string deskDragUris: deskUi.dragging.map(k => desktop.find(k))
        .filter(i => i && i.url && i.url.startsWith("file:") && !desktop.isFixed(i)).map(i => i.url).join("\r\n")
    // A link's page title: Firefox offers "url\ntitle" as UTF-8 _NETSCAPE_URL on Wayland; Firefox and
    // Chromium also put it in UTF-16 under text/x-moz-url.
    function mozTitle(drop) {
        let s = ""
        if (drop.formats.indexOf("_NETSCAPE_URL") >= 0) s = drop.getDataAsString("_NETSCAPE_URL")
        else if (drop.formats.indexOf("text/x-moz-url") >= 0) {
            const b = new Uint8Array(drop.getDataAsArrayBuffer("text/x-moz-url"))
            for (let i = 0; i + 1 < b.length; i += 2) s += String.fromCharCode(b[i] | (b[i + 1] << 8))
        }
        const lines = s.replace(/\0/g, "").split("\n")
        return lines.length > 1 ? lines[1].trim() : ""
    }
    function localPath(u) {
        const m = /^file:\/\/(?:localhost)?(\/[^?#]*)$/.exec(u)
        if (!m) return ""
        try { return decodeURIComponent(m[1]) } catch (e) { return "" }
    }
    // A drop on the desktop at screen (x, y), or on the icon `key` (a folder, Home or the Trash).
    function deskDrop(key, drop, x, y) {
        deskUi.dropKey = ""
        const target = key ? desktop.find(key) : null
        let own = []
        if (drop.formats.indexOf("application/x-quasar-desktop") >= 0) {
            try { own = JSON.parse(drop.getDataAsString("application/x-quasar-desktop") || "[]") } catch (e) { own = [] }
        }
        if (own.length) {
            // Onto one of the dragged icons itself (a short nudge, or a group over its own member): a new
            // spot, as on empty space. Refusing it left free placement unable to nudge folders, Home or
            // the Trash, and a refused drop could leave the drag half-finished.
            const into = target && own.indexOf(key) < 0 ? target : null
            if (into && into.kind === "trash") { desktop.trash(own); deskUi.selection = [] }
            else if (into) desktop.transfer("move", desktop.pathsOf(own), into.path)
            else desktop.moveIcons(own, deskUi.dragAnchor || own[0], x - deskUi.dragHot.x, y - deskUi.dragHot.y)
            drop.accept(Qt.MoveAction)
            return
        }
        const urls = Array.from(drop.urls || [], u => String(u))
        if (!urls.length && drop.hasText && /^(https?|ftp):\/\/\S+$/i.test(drop.text.trim())) urls.push(drop.text.trim())
        const files = urls.map(shell.localPath).filter(p => p !== "")
        const webs = urls.filter(u => /^(https?|ftp):\/\//i.test(u))
        const dest = target && target.kind !== "trash" ? target.path : ""
        if (files.length) {
            // From Quasar's Files (its own type marks it): a move on the same drive, a copy onto another
            // ("drop"), as between Files windows. Other apps: a copy, unless they propose a move.
            const fromFiles = drop.formats.indexOf("application/x-quasar-files") >= 0
            const mode = fromFiles ? "drop" : drop.proposedAction === Qt.MoveAction ? "move" : "copy"
            if (target && target.kind === "trash") desktop.trashPaths(files)
            else desktop.transfer(mode, files, dest, x - 48, y - 46)
            drop.accept(mode !== "copy" || (target && target.kind === "trash") ? Qt.MoveAction : Qt.CopyAction)
        } else if (webs.length) {
            const title = shell.mozTitle(drop)
            webs.slice(0, 8).forEach((u, i) => desktop.newLink(i === 0 ? title : "", u, x - 48, y - 46 + i * 96, dest))
            drop.accept(Qt.CopyAction)
        } else {
            drop.accepted = false
        }
    }

    // Rename in place: a small Overlay window over the icon's label takes the keyboard (renameWin).
    function startRename(key) {
        const it = desktop.find(key)
        if (!it || desktop.isFixed(it) || !desktop.pos[key]) return
        deskUi.selection = [key]
        deskUi.renaming = key
        deskUi.renameCancelled = false
        renameBox.error = false
        renameBox.begin(it.name, it.kind === "dir" || desktop.isShortcut(it))
        ui.show("rename", shell.main)
    }
    function renameIfShown() {
        shell.pruneSelection()
        const k = deskUi.renameAfter
        if (k && desktop.find(k) && desktop.pos[k]) { deskUi.renameAfter = ""; shell.startRename(k) }
    }
    // Enter or a click elsewhere keeps the new name; Esc keeps the old one.
    function finishRename() {
        const key = deskUi.renaming
        if (!key) return
        deskUi.renaming = ""
        const it = desktop.find(key)
        const name = renameBox.text.trim()
        if (deskUi.renameCancelled || !it || !name || name === it.name) return
        desktop.rename(key, name, (code, err, made) => {
            if (code === 0) { deskUi.selection = [made]; return }
            shell.toast({ title: code === 2 ? "That name is already taken" : (err || "Couldn't rename it"), sub: name, glyph: Icons.pencil, hue: "#FFB86B" })
            if (code === 2 || code === 4) {          // let them pick another name
                deskUi.renaming = key
                deskUi.renameCancelled = false
                renameBox.error = true
                ui.show("rename", shell.main)
            }
        })
    }
    Connections {
        target: ui
        function onOpenChanged() { if (ui.open !== "rename" && deskUi.renaming) shell.finishRename() }
    }
    function openShortcutDialog(x, y) { deskUi.linkAt = Qt.point(x, y); ui.show("shortcut", shell.main) }

    // Start menu app → right click: Open, Pin/Unpin, Add to desktop.
    function openAppMenu(item, x, y) {
        const e = item && item.entry
        if (!e) return
        const pinned = Settings.pins.some(p => { const x = apps.byId(p); return p === e.id || (x && x.id === e.id) })
        ui.menuApp = item
        ui.menuItems = [
            { key: "open", label: "Open", glyph: Icons.open },
            { sep: true },
            pinned ? { key: "unpin", label: "Unpin from taskbar", glyph: Icons.pin2 } : { key: "pin", label: "Pin to taskbar", glyph: Icons.pin2 },
            { key: "todesk", label: "Add to desktop", glyph: Icons.layers }
        ].concat(/^quasar-appimage-/.test(e.id) ? [{ sep: true }, { key: "unapp", label: "Remove from Apps", glyph: Icons.trash }] : [])
        ui.ctxX = x; ui.ctxY = y
        ui.over("appmenu")              // the launcher stays open beneath
    }
    function appMenuActivated(key) {
        const item = ui.menuApp
        ui.close()
        const e = item && item.entry
        if (!e) return
        if (key === "open") apps.launch(e)
        else if (key === "pin") Settings.pins = Settings.pins.concat([e.id])
        else if (key === "unpin") Settings.pins = Settings.pins.filter(p => { const x = apps.byId(p); return p !== e.id && !(x && x.id === e.id) })
        else if (key === "todesk") desktop.addLauncher(e.id, item.name)
        else if (key === "unapp") {
            // An AppImage added to Apps: its launcher entry and icon go, the file goes to the Trash.
            Settings.pins = Settings.pins.filter(p => p !== e.id)
            programs.removeFromApps(e.id, item.name || e.name)
        }
    }

    // ---------------------------------------------------------------- wallpaper + desktop (every screen)
    // Two surfaces per screen: the wallpaper (Background layer, opaque) and, on the main display, the
    // desktop icons (Bottom layer, sized to the icons' bounding box). Kept apart so that hovering an
    // icon repaints around that icon instead of re-rendering the wallpaper: on software rendering
    // (Hyper-V, QEMU) a full-screen repaint per hover frame is what made the cursor lag.
    // Both take the keyboard when clicked (OnDemand): Delete, F2, Enter, Ctrl+A/C/X/V, Esc.
    // Every display also gets the dismiss layer (a click anywhere closes an open panel) and Identify.
    Variants {
        model: Quickshell.screens
        Scope {
            id: desk
            required property var modelData
            readonly property bool isMain: modelData === shell.main
            readonly property bool hasBar: (Settings.displays || {}).taskbarAll !== false || isMain

            PanelWindow {
                screen: desk.modelData
                anchors { top: true; bottom: true; left: true; right: true }
                exclusionMode: ExclusionMode.Ignore
                color: Theme.bg
                surfaceFormat { opaque: true }
                WlrLayershell.layer: WlrLayer.Background
                WlrLayershell.namespace: "quasar-wallpaper"
                WlrLayershell.keyboardFocus: desk.isMain ? WlrKeyboardFocus.OnDemand : WlrKeyboardFocus.None

                // The main display's first frame: the desktop is really up (services/ShellReady.qml).
                Item {
                    visible: false
                    readonly property var win: desk.isMain ? Window.window : null
                    onWinChanged: if (win) shellReady.window = win
                }
                Wallpaper {
                    anchors.fill: parent
                    kind: Companies.wallpaper
                    // Each display pauses on its own: a full-screen or maximized window covers it, or
                    // the launcher is open on it.
                    paused: apps.coveredOn(desk.modelData) || (ui.launcherShown && shell.sameScreen(shell.panelScreen, desk.modelData))
                    opacity: shell.introWall
                }
                // Selection box, drawn under the icons. On software rendering only its four edges: a
                // filled box marks its whole area dirty on every move, repainting the wallpaper under it.
                Item {
                    id: band
                    visible: desk.isMain && deskUi.band !== null
                    x: deskUi.band ? deskUi.band.x : 0
                    y: deskUi.band ? deskUi.band.y : 0
                    width: deskUi.band ? deskUi.band.width : 0
                    height: deskUi.band ? deskUi.band.height : 0
                    readonly property color line: Theme.alpha(Theme.accent, 0.6)
                    Rectangle {
                        visible: !Theme.softwareRender
                        anchors.fill: parent
                        radius: 4
                        color: Theme.alpha(Theme.accent, 0.12)
                        border.width: 1
                        border.color: band.line
                    }
                    Rectangle { visible: Theme.softwareRender; width: parent.width; height: 1; color: band.line }
                    Rectangle { visible: Theme.softwareRender; y: parent.height - 1; width: parent.width; height: 1; color: band.line }
                    Rectangle { visible: Theme.softwareRender; width: 1; height: parent.height; color: band.line }
                    Rectangle { visible: Theme.softwareRender; x: parent.width - 1; width: 1; height: parent.height; color: band.line }
                }
                MouseArea {
                    anchors.fill: parent
                    acceptedButtons: Qt.LeftButton | Qt.RightButton
                    focus: desk.isMain
                    readonly property bool windowActive: Window.active
                    onWindowActiveChanged: if (desk.isMain) deskUi.wallActive = windowActive
                    Keys.onPressed: (e) => shell.deskKey(e)
                    onPressed: (e) => { if (desk.isMain) shell.deskPress(e.x, e.y, e.button); else ui.close() }
                    onPositionChanged: (e) => { if (desk.isMain) shell.deskMove(e.x, e.y) }
                    // Another display has no icons: its right click opens the desktop menu there.
                    onReleased: (e) => {
                        if (desk.isMain) shell.deskRelease(e.x, e.y, e.button)
                        else if (e.button === Qt.RightButton) shell.screenMenu(desk.modelData, e.x, e.y)
                    }
                }
                DropArea {
                    anchors.fill: parent
                    enabled: desk.isMain
                    onDropped: (d) => shell.deskDrop("", d, d.x, d.y)
                }
            }

            // At 0,0 so its coordinates are screen coordinates (the layout's spots include the margins).
            PanelWindow {
                id: iconWin
                visible: desk.isMain
                screen: desk.modelData
                anchors { top: true; left: true }
                implicitWidth: Math.max(1, desktop.placed.width + 8)       // + room for the hover lift/scale
                implicitHeight: Math.max(1, desktop.placed.height + 8)
                exclusionMode: ExclusionMode.Ignore
                color: "transparent"
                WlrLayershell.layer: WlrLayer.Bottom
                WlrLayershell.namespace: "quasar-desktop-icons"
                WlrLayershell.keyboardFocus: WlrKeyboardFocus.OnDemand

                // Gaps between icons behave like the wallpaper (selection box, desktop menu, drops).
                MouseArea {
                    anchors.fill: parent
                    acceptedButtons: Qt.LeftButton | Qt.RightButton
                    focus: true
                    readonly property bool windowActive: Window.active
                    onWindowActiveChanged: deskUi.iconsActive = windowActive
                    Keys.onPressed: (e) => shell.deskKey(e)
                    onPressed: (e) => shell.deskPress(e.x, e.y, e.button)
                    onPositionChanged: (e) => shell.deskMove(e.x, e.y)
                    onReleased: (e) => shell.deskRelease(e.x, e.y, e.button)
                }
                DropArea {
                    anchors.fill: parent
                    onDropped: (d) => shell.deskDrop("", d, d.x, d.y)
                }
                DesktopIcons {
                    anchors.fill: parent
                    opacity: shell.introIcons
                    transform: Translate { y: (1 - shell.introIcons) * 8 }
                    model: deskScript
                    selection: deskUi.selection
                    dropKey: deskUi.dropKey
                    renamingKey: deskUi.renaming
                    draggingKeys: deskUi.dragging
                    dragUris: shell.deskDragUris
                    dragKeys: JSON.stringify(deskUi.dragging)
                    focused: deskUi.focused
                    onClicked: (k, mods) => { shell.deskClick(k, mods); ui.close() }
                    onActivated: (k) => { ui.close(); desktop.open(desktop.find(k)) }
                    onContextRequested: (k, x, y) => shell.deskContext(k, x, y)
                    onDragRequested: (k, hx, hy) => shell.deskDragStart(k, hx, hy)
                    onDragEnded: (k, action) => { deskUi.dragging = []; deskUi.dropKey = "" }
                    onDropEntered: (k) => { if (deskUi.dragging.indexOf(k) < 0) deskUi.dropKey = k }   // not over itself
                    onDropExited: (k) => { if (deskUi.dropKey === k) deskUi.dropKey = "" }
                    onDropped: (k, d, x, y) => shell.deskDrop(k, d, x, y)
                }
            }

            // Dismiss layer while a panel is open: a click on any display closes it. This display's
            // taskbar strip stays clickable (a click there moves the panel to this display's taskbar).
            PanelWindow {
                screen: desk.modelData
                visible: ui.open !== ""
                anchors { top: true; bottom: true; left: true; right: true }
                exclusionMode: ExclusionMode.Ignore
                color: "transparent"
                WlrLayershell.layer: WlrLayer.Top
                WlrLayershell.namespace: "quasar-scrim"
                WlrLayershell.keyboardFocus: WlrKeyboardFocus.None
                mask: Region { item: scrimArea }
                Item {
                    id: scrimArea
                    anchors { fill: parent; bottomMargin: desk.hasBar ? Theme.taskbarHeight : 0 }
                    MouseArea { anchors.fill: parent; acceptedButtons: Qt.AllButtons; onPressed: ui.close() }
                }
            }

            // Identify (Settings › Arrange displays): this display's number, centred, for a moment. Takes
            // no input; stays up until the badge has faded out.
            PanelWindow {
                id: idWin
                readonly property int number: displays.identifying ? (displays.identifying[desk.modelData.name] || 0) : 0
                onNumberChanged: if (number > 0) {
                    const o = displays.output(desk.modelData)
                    badge.number = number
                    badge.label = o ? o.label : desk.modelData.name
                }
                screen: desk.modelData
                visible: number > 0 || badge.enter > 0.01
                implicitWidth: badge.implicitWidth + 120
                implicitHeight: badge.implicitHeight + 120
                exclusionMode: ExclusionMode.Ignore
                color: "transparent"
                WlrLayershell.layer: WlrLayer.Overlay
                WlrLayershell.namespace: "quasar-identify"
                WlrLayershell.keyboardFocus: WlrKeyboardFocus.None
                mask: Region { }
                IdentifyBadge {
                    id: badge
                    anchors.centerIn: parent
                    width: implicitWidth; height: implicitHeight
                    shown: idWin.number > 0
                    screenSize: Qt.size(desk.modelData.width, desk.modelData.height)
                    screenPos: Qt.point((desk.modelData.width - width) / 2, (desk.modelData.height - height) / 2)
                    wallpaperKind: Companies.wallpaper
                }
            }
        }
    }

    // ---------------------------------------------------------------- rename + new website shortcut
    PanelWindow {
        id: renameWin
        readonly property var spot: deskUi.renaming ? (desktop.pos[deskUi.renaming] || null) : null
        screen: shell.main
        visible: ui.open === "rename" && spot !== null
        anchors { top: true; left: true }
        margins { left: spot ? Math.max(0, spot.x + 48 - renameBox.width / 2) : 0; top: spot ? spot.y + 60 : 0 }
        implicitWidth: renameBox.width
        implicitHeight: renameBox.height
        exclusionMode: ExclusionMode.Ignore
        color: "transparent"
        WlrLayershell.layer: WlrLayer.Overlay
        WlrLayershell.namespace: "quasar-rename"
        WlrLayershell.keyboardFocus: WlrKeyboardFocus.Exclusive
        onVisibleChanged: if (visible) renameBox.focusInput()

        RenameField {
            id: renameBox
            width: 124; height: implicitHeight
            onAccepted: ui.close()
            onCancelled: { deskUi.renameCancelled = true; ui.close() }
        }
    }
    PanelWindow {
        id: shortcutWin
        screen: shell.main
        visible: ui.open === "shortcut"          // no anchors: the compositor centres it
        implicitWidth: shortcutBox.implicitWidth
        implicitHeight: shortcutBox.implicitHeight
        exclusionMode: ExclusionMode.Ignore
        color: "transparent"
        WlrLayershell.layer: WlrLayer.Overlay
        WlrLayershell.namespace: "quasar-shortcut"
        WlrLayershell.keyboardFocus: WlrKeyboardFocus.Exclusive
        onVisibleChanged: if (visible) shortcutBox.begin()

        ShortcutDialog {
            id: shortcutBox
            anchors.fill: parent
            onAccepted: (url, name) => { desktop.newLink(name, url, deskUi.linkAt.x - 48, deskUi.linkAt.y - 46); ui.close() }
            onCancelled: ui.close()
        }
    }

    // ---------------------------------------------------------------- restart while something installs
    // Restart / Shut down asked for while a driver, updates or a restore is installing (RestartGuard):
    // wait for it (the default), go ahead anyway (an administrator's password), or cancel.
    PanelWindow {
        id: restartWin
        screen: shell.main
        visible: restartGuard.asking !== null
        anchors { top: true; bottom: true; left: true; right: true }
        exclusionMode: ExclusionMode.Ignore
        color: "transparent"
        WlrLayershell.layer: WlrLayer.Overlay
        WlrLayershell.namespace: "quasar-restart-guard"
        WlrLayershell.keyboardFocus: WlrKeyboardFocus.Exclusive

        Dialog {
            id: restartAsk
            readonly property var a: restartGuard.asking
            readonly property bool off: !!a && a.action === "poweroff"
            open: a !== null
            cardWidth: 470
            title: "Wait for the install to finish?"
            message: a ? a.reasons.join(", ") + ". " + (off ? "Shutting down" : "Restarting")
                         + " now can leave the PC without a working desktop." : ""
            onDismissed: restartGuard.cancel()
            buttons: [
                Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: restartGuard.cancel() },
                Button { text: restartAsk.off ? "Shut down anyway" : "Restart anyway"; variant: "primary"; tone: Theme.danger; size: 38
                         onClicked: restartGuard.anyway(restartAsk.a.action) },
                Button { text: restartAsk.off ? "Shut down when it's done" : "Restart when it's done"; variant: "primary"; size: 38
                         onClicked: restartGuard.whenDone(restartAsk.a.action) }
            ]
        }
    }

    // ---------------------------------------------------------------- polkit agent
    // The shell answers polkit's password requests (Store's system packages, Settings, pkexec in a
    // terminal), so system changes never fail with "no authentication agent".
    PolkitAgent {
        id: polkit
        onIsRegisteredChanged: console.info("polkit agent registered:", isRegistered)
    }
    PanelWindow {
        id: authWin
        screen: shell.main
        visible: polkit.isActive && polkit.flow !== null
        anchors { top: true; bottom: true; left: true; right: true }
        exclusionMode: ExclusionMode.Ignore
        color: "transparent"
        WlrLayershell.layer: WlrLayer.Overlay
        WlrLayershell.namespace: "quasar-auth"
        WlrLayershell.keyboardFocus: WlrKeyboardFocus.Exclusive
        onVisibleChanged: if (visible) { auth.clear(); auth.focusInput() }

        AuthDialog {
            id: auth
            anchors.fill: parent
            readonly property var flow: polkit.flow
            // The account polkit actually asks for: yours, or an administrator's when you're a
            // standard account (polkit's admin identities). Several administrators: tap to switch.
            readonly property var people: flow && flow.identities ? Array.from(flow.identities).filter(i => i && !i.isGroup) : []
            function nameOf(i) {
                const n = String((i && (i.displayName || i.string)) || "")
                return n.replace(/^unix-user:/, "")
            }
            message: flow ? flow.message : ""
            identity: flow && flow.selectedIdentity && !flow.selectedIdentity.isGroup ? nameOf(flow.selectedIdentity)
                    : flow ? "An administrator" : shell.userName
            canSwitch: people.length > 1
            onSwitchIdentity: {
                if (!flow || people.length < 2) return
                const i = people.indexOf(flow.selectedIdentity)
                flow.selectedIdentity = people[(i + 1) % people.length]
                auth.clear()
            }
            prompt: flow && flow.inputPrompt ? flow.inputPrompt : "Password"
            echo: flow ? flow.responseVisible : false
            feedback: flow ? flow.supplementaryMessage : ""
            feedbackIsError: flow ? flow.supplementaryIsError : false
            busy: flow ? (!flow.isResponseRequired && !flow.isCompleted) : false
            onSubmitted: (r) => { if (flow) { flow.submit(r); auth.clear() } }
            onCancelled: if (flow) flow.cancelAuthenticationRequest()
        }
    }

    // ---------------------------------------------------------------- Bluetooth pairing agent
    // The shell answers BlueZ's pairing questions (Settings' "Add a device", a phone pairing with this
    // PC). Typing a PIN/passkey takes the keyboard; every other question is answered with the pointer, so
    // a stray key press never approves a pairing and a phone's request never steals the keyboard.
    BluetoothAgent { id: btAgent }
    component PairWindow: PanelWindow {
        property alias dialog: pairDialog
        readonly property var req: btAgent.request
        screen: shell.main
        anchors { top: true; bottom: true; left: true; right: true }
        exclusionMode: ExclusionMode.Ignore
        color: "transparent"
        WlrLayershell.layer: WlrLayer.Overlay
        WlrLayershell.namespace: "quasar-bluetooth-pair"
        PairDialog {
            id: pairDialog
            anchors.fill: parent
            readonly property var req: btAgent.request
            mode: req ? req.mode : "confirm"
            deviceName: req && req.device ? (req.device.name || req.device.address || "Bluetooth device") : ""
            deviceGlyph: req && req.kind ? req.kind.glyph : "bt"
            code: req ? (req.passkey || req.pin || "") : ""
            entered: req && req.entered ? req.entered : 0
            serviceName: req ? BtDevices.service(req.uuid) : ""
            onAccepted: (value) => btAgent.answer(true, value)
            onDeclined: btAgent.answer(false, "")
        }
    }
    PairWindow {
        id: pairEntryWin
        visible: !!req && (req.mode === "pin" || req.mode === "passkey")
        WlrLayershell.keyboardFocus: WlrKeyboardFocus.Exclusive
        onVisibleChanged: if (visible) { dialog.clear(); Qt.callLater(dialog.focusInput) }
        onReqChanged: if (visible) { dialog.clear(); Qt.callLater(dialog.focusInput) }
    }
    PairWindow {
        visible: !!req && !pairEntryWin.visible
        WlrLayershell.keyboardFocus: WlrKeyboardFocus.None
    }

    // ---------------------------------------------------------------- taskbar (every display)
    // One per display, each listing every app (Settings › Arrange displays › "Taskbar on every display"
    // off: the main display only). Its launcher, Quick Settings, calendar and menus open above it.
    Variants {
        model: (Settings.displays || {}).taskbarAll === false ? (shell.main ? [shell.main] : []) : Quickshell.screens
        PanelWindow {
            id: barWin
            required property var modelData
            readonly property bool here: shell.sameScreen(shell.panelScreen, modelData)   // its panels are open
            screen: modelData
            anchors { left: true; right: true; bottom: true }
            implicitHeight: taskbar.implicitHeight
            exclusiveZone: Theme.taskbarHeight
            color: "transparent"
            WlrLayershell.layer: WlrLayer.Top
            WlrLayershell.namespace: "quasar-taskbar"
            WlrLayershell.keyboardFocus: WlrKeyboardFocus.None
            mask: Region { item: taskbar.bar }

            Taskbar {
                id: taskbar
                anchors.fill: parent
                opacity: Math.min(1, shell.introBar)
                transform: Translate { y: (1 - shell.introBar) * 20 }       // the spring overshoots: settles from above
                tasks: taskScript
                showWorkspaces: false
                launcherOpen: ui.launcherShown && barWin.here
                quickOpen: ui.open === "quick" && barWin.here
                calendarOpen: ui.open === "calendar" && barWin.here
                assistantAvailable: assistant.enabled
                assistantOpen: assistant.open && shell.sameScreen(shell.assistantScreen, barWin.modelData)
                onAssistantClicked: { ui.close(); shell.toggleAssistant(barWin.modelData) }
                timeText: Qt.formatDateTime(clock.date, Settings.clock24 ? "HH:mm" : "h:mm AP")
                dateText: Qt.formatDateTime(clock.date, "ddd, MMM d")
                wifiConnected: sys.wifiOn && sys.wifiSsid !== ""
                wiredConnected: sys.wiredConnected
                vpnOn: NetState.vpnOn
                hotspotOn: NetState.hotspotOn
                deckOn: deck.connected
                deckLive: deck.live
                deckOpen: ui.open === "deck" && barWin.here
                onDeckClicked: (x) => shell.openDeckMenu(x, barWin.modelData)
                vncViewers: remoteDesktop.count
                vncOpen: ui.open === "vnc" && barWin.here
                onVncClicked: (x) => shell.openVncMenu(x, barWin.modelData)
                servicesShown: bgServices.shown
                servicesRunning: bgServices.running
                servicesFailed: bgServices.failed
                servicesLabel: bgServices.label
                servicesOpen: ui.open === "services" && barWin.here
                // Something failed: the menu (each failure's log); otherwise straight to Services, as before.
                onServicesClicked: (x) => {
                    if (bgServices.failed > 0) shell.openServicesMenu(x, barWin.modelData)
                    else { ui.close(); apps.launchId("quasar-services") }
                }
                onServicesRightClicked: (x) => shell.openServicesMenu(x, barWin.modelData)
                onLauncherClicked: ui.toggle("launcher", barWin.modelData)
                menuKey: (ui.open === "windows" || ui.open === "task") && barWin.here ? ui.taskKey : ""
                onTaskClicked: (i, x) => {
                    const it = apps.taskModel[i]
                    if (apps.taskClick(it)) ui.close()
                    else shell.openTaskMenu("windows", it, x, barWin.modelData)      // several windows: pick one
                }
                onTaskRightClicked: (i, x) => shell.openTaskMenu("task", apps.taskModel[i], x, barWin.modelData)
                onTaskMiddleClicked: (i) => { apps.newWindow(apps.taskModel[i]); ui.close() }
                onQuickClicked: { sys.refresh(); ui.toggle("quick", barWin.modelData) }
                onCalendarClicked: ui.toggle("calendar", barWin.modelData)
                onShowDesktopClicked: { apps.showDesktop(); ui.close() }
            }
        }
    }
    // Ask on a taskbar: the assistant opens on that display; open on another display, it moves here.
    function toggleAssistant(s) {
        if (assistant.open && !shell.sameScreen(shell.assistantScreen, s)) {
            assistant.open = false
            Qt.callLater(() => { shell.aiScreen = s; assistant.toggle() })
            return
        }
        shell.aiScreen = s
        assistant.toggle()
    }

    // ---------------------------------------------------------------- launcher
    PanelWindow {
        id: launchWin
        readonly property int sm: Theme.profile > 0 ? 40 : 0
        readonly property real lw: Math.min(660, shell.psw - 20)
        readonly property real lh: Math.min(660, shell.psh - 80)
        screen: shell.panelScreen
        visible: ui.launcherShown
        anchors { left: true; bottom: true }
        margins { left: 0; bottom: Theme.panelBottom - sm }
        implicitWidth: 10 + lw + sm
        implicitHeight: lh + 2 * sm
        exclusionMode: ExclusionMode.Ignore
        color: "transparent"
        WlrLayershell.layer: WlrLayer.Overlay
        WlrLayershell.namespace: "quasar-launcher"
        WlrLayershell.keyboardFocus: WlrKeyboardFocus.Exclusive
        mask: Region { item: launcher }

        Launcher {
            id: launcher
            x: 10; y: launchWin.sm
            width: launchWin.lw; height: launchWin.lh
            screenSize: Qt.size(shell.psw, shell.psh)
            screenPos: Qt.point(10, shell.psh - Theme.panelBottom - height)
            wallpaperKind: Companies.wallpaper
            userName: shell.userName
            assistantAvailable: assistant.ready
            suggestions: assistant.suggestions
            onAskRequested: (q) => { shell.aiScreen = shell.panelScreen; ui.close(); assistant.show(q) }
            allApps: ui.allApps
            pinned: apps.entries.length ? Settings.pins.map(id => apps.byId(id)).filter(e => !!e).map(e => apps.decorate(e)) : []
            moreApps: apps.listed.filter(e => Settings.pins.indexOf(e.id) < 0)
                          .sort((a, b) => a.name.localeCompare(b.name)).map(e => apps.decorate(e))
            groups: shell.groupsFor(ui.query)
            onQueryEdited: (t) => ui.query = t
            onActivated: (item) => shell.activate(item)
            onAllAppsToggled: ui.allApps = !ui.allApps
            onSettingsClicked: shell.openSettings()
            onLockClicked: { ui.close(); sys.lock() }
            // The power menu opens over the launcher, which stays open beneath it; its right edge lines up
            // with the power button's (14 px in from the launcher's).
            onPowerClicked: { ui.ctxX = 10 + launchWin.lw - 14 - 236; ui.ctxY = shell.psh - Theme.panelBottom - 58 - 190; ui.over("power") }
            onAppContextRequested: (item, x, y) => shell.openAppMenu(item, launcher.screenPos.x + x, launcher.screenPos.y + y)
            menuOpen: ui.under === "launcher"
            powerOpen: menuOpen && ui.open === "power"
            onMenuDismissed: ui.back()
            onCloseRequested: ui.close()
        }
        onVisibleChanged: if (visible) { launcher.query = ""; launcher.focusSearch() }
    }

    // ---------------------------------------------------------------- Quasar AI assistant
    // A right-side sheet (template): opens from Ask, the launcher and the desktop menu, and stays open
    // while the steps it runs open apps. It takes the keyboard when it opens; once a request is sent it
    // gives it back (OnDemand: click the composer to type again), so apps it opens can be used.
    PanelWindow {
        id: aiWin
        readonly property int sm: Theme.profile > 0 ? 40 : 0
        readonly property real pw: Math.min(420, asw - 20)
        readonly property real asw: shell.assistantScreen ? shell.assistantScreen.width : shell.sw
        readonly property real ash: shell.assistantScreen ? shell.assistantScreen.height : shell.sh
        property bool grab: false
        property real enter: 1
        screen: shell.assistantScreen
        visible: assistant.open
        anchors { top: true; right: true; bottom: true }
        margins { top: 0; right: 0; bottom: Theme.panelBottom - sm }
        implicitWidth: sm + pw + 10
        exclusionMode: ExclusionMode.Ignore
        color: "transparent"
        WlrLayershell.layer: WlrLayer.Overlay
        WlrLayershell.namespace: "quasar-assistant"
        WlrLayershell.keyboardFocus: grab ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.OnDemand
        mask: Region { item: aiPanel }
        onVisibleChanged: {
            if (!visible) { grab = false; return }
            enter = 0
            enterAnim.restart()
            Qt.callLater(() => { aiWin.grab = !assistant.busy; if (aiWin.grab) aiPanel.focusInput() })
        }
        NumberAnimation { id: enterAnim; target: aiWin; property: "enter"; to: 1; duration: Motion.dur(Motion.windowOpen); easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.spring }

        AssistantPanel {
            id: aiPanel
            x: aiWin.sm
            y: 10
            width: aiWin.pw
            height: aiWin.height - 10 - aiWin.sm
            opacity: Math.min(1, aiWin.enter * 1.5)
            transform: Translate { x: (1 - aiWin.enter) * 60 }
            screenSize: Qt.size(aiWin.asw, aiWin.ash)
            screenPos: Qt.point(aiWin.asw - 10 - width, 10)
            wallpaperKind: Companies.wallpaper
            blocks: assistant.blocks
            steps: assistant.steps
            rev: assistant.rev
            busy: assistant.busy
            planIds: assistant.planIds
            askId: assistant.askId
            canUndo: assistant.canUndo
            ready: assistant.ready
            destination: assistant.destination
            cloud: assistant.cloud
            company: assistant.company
            suggestions: assistant.suggestions
            onSend: (t) => { aiWin.grab = false; assistant.ask(t) }
            onRunPlan: assistant.runPlan()
            onCancelPlan: assistant.cancelPlan()
            onStop: assistant.stop()
            onAllow: assistant.allow()
            onDeny: assistant.deny()
            onUndo: assistant.undo()
            onNewTask: { assistant.newTask(); aiWin.grab = true; aiPanel.focusInput() }
            onRetry: assistant.retry()
            onCloseRequested: assistant.open = false
            onSettingsRequested: shell.openSettings("ai")
            onLinkClicked: (url) => { if (/^https?:\/\//i.test(url)) Quickshell.execDetached(["/usr/libexec/quasar/fileop", "open", url]) }
        }
    }

    // ---------------------------------------------------------------- quick settings
    PanelWindow {
        id: quickWin
        readonly property int sm: Theme.profile > 0 ? 40 : 0
        readonly property real pw: Math.min(372, shell.psw - 20)
        screen: shell.panelScreen
        visible: ui.open === "quick"
        anchors { right: true; bottom: true }
        margins { right: 0; bottom: Theme.panelBottom - sm }
        implicitWidth: sm + pw + 10
        implicitHeight: quick.implicitHeight + 2 * sm
        exclusionMode: ExclusionMode.Ignore
        color: "transparent"
        WlrLayershell.layer: WlrLayer.Overlay
        WlrLayershell.namespace: "quasar-quick-settings"
        WlrLayershell.keyboardFocus: WlrKeyboardFocus.None
        mask: Region { item: quick }

        QuickSettings {
            id: quick
            x: quickWin.sm; y: quickWin.sm
            width: quickWin.pw; height: implicitHeight
            screenSize: Qt.size(shell.psw, shell.psh)
            screenPos: Qt.point(shell.psw - 10 - width, shell.psh - Theme.panelBottom - height)
            wallpaperKind: Companies.wallpaper
            profile: Theme.profile
            profileLocked: shell.softwareRender
            brightnessAvailable: sys.brightnessAvailable
            brightness: sys.brightness
            volume: sys.volume
            volumeMuted: sys.muted
            volumeAvailable: sys.audioAvailable
            // Wi-Fi/Bluetooth tiles: the chevron (or right-click) opens their Settings page; with no adapter
            // or a hardware switch off, a click goes there too (it explains why) instead of doing nothing.
            toggles: [
                { key: "wifi",  label: "Wi-Fi", glyph: Icons.wifi, on: sys.wifiOn, details: true,
                  sub: !sys.wifiAvailable ? "Not available" : sys.wifiHardBlocked ? "Switched off" : sys.wifiOn ? (sys.wifiSsid || "Not connected") : "Off" },
                { key: "bt",    label: "Bluetooth", glyph: Icons.bt, on: sys.btOn, details: true,
                  sub: !sys.btAvailable ? "Not available" : sys.btHardBlocked ? "Switched off"
                     : sys.btOn ? (sys.btDevices ? sys.btDevices + (sys.btDevices === 1 ? " device" : " devices") : "On") : "Off" },
                netQuick.vpnTile, netQuick.hotspotTile,          // services/NetQuick.qml (hidden until they apply)
                { key: "focus", label: "Focus",       sub: Settings.focus ? "Notifications held" : "Off", glyph: Icons.target, on: Settings.focus },
                { key: "night", label: "Night light", sub: Settings.nightLight ? "On" : "Off", glyph: Icons.moon, on: Settings.nightLight },
                { key: "air",   label: "Airplane",    sub: sys.airplane ? "Radios off" : "Off", glyph: Icons.plane, on: sys.airplane }
            ]
            onToggled: (key) => {
                if (key === "wifi") { if (!sys.wifiAvailable || sys.wifiHardBlocked) shell.openSettings("network"); else sys.setWifi(!sys.wifiOn) }
                else if (key === "bt") { if (!sys.btAvailable || sys.btHardBlocked) shell.openSettings("bluetooth"); else sys.setBluetooth(!sys.btOn) }
                else if (key === "focus") Settings.focus = !Settings.focus
                else if (key === "night") Settings.nightLight = !Settings.nightLight
                else if (key === "air") sys.setAirplane(!sys.airplane)
                else if (key === "vpn" || key === "hotspot") netQuick.toggle(key)
            }
            onBrightnessMoved: (v) => sys.setBrightness(v)
            onVolumeMoved: (v) => sys.setVolume(v)
            // The visual profile (Lite/Balanced/Max) no longer switches the CPU power profile.
            onProfilePicked: (i) => Settings.profile = i
            onSettingsClicked: shell.openSettings()
            onDetailsRequested: (key) => shell.openSettings(key === "bt" ? "bluetooth" : key === "vpn" || key === "hotspot" ? key : "network")
        }
    }

    // ---------------------------------------------------------------- calendar + notifications
    PanelWindow {
        id: calWin
        readonly property int sm: Theme.profile > 0 ? 40 : 0
        readonly property real pw: Math.min(360, shell.psw - 20)
        screen: shell.panelScreen
        visible: ui.open === "calendar"
        anchors { right: true; bottom: true }
        margins { right: 0; bottom: Theme.panelBottom - sm }
        implicitWidth: sm + pw + 10
        implicitHeight: cal.implicitHeight + 2 * sm
        exclusionMode: ExclusionMode.Ignore
        color: "transparent"
        WlrLayershell.layer: WlrLayer.Overlay
        WlrLayershell.namespace: "quasar-calendar"
        WlrLayershell.keyboardFocus: WlrKeyboardFocus.None
        mask: Region { item: cal }

        CalendarPanel {
            id: cal
            x: calWin.sm; y: calWin.sm
            width: calWin.pw; height: implicitHeight
            screenSize: Qt.size(shell.psw, shell.psh)
            screenPos: Qt.point(shell.psw - 10 - width, shell.psh - Theme.panelBottom - height)
            wallpaperKind: Companies.wallpaper
            now: clock.date
            calm: Settings.focus
            notifications: shell.history
            onDismissed: (id) => { const h = shell.history.find(x => x.id === id); if (h && h.notif) h.notif.dismiss() }
            onClearAll: shell.history.forEach(h => h.notif && h.notif.dismiss())
        }
    }

    // ---------------------------------------------------------------- context / power menu
    PanelWindow {
        id: menuWin
        readonly property bool isPower: ui.open === "power"
        readonly property bool isTask: ui.open === "windows" || ui.open === "task"
        readonly property bool isList: isTask || ui.open === "item" || ui.open === "appmenu" || ui.open === "deck"
                                       || ui.open === "vnc" || ui.open === "services"   // items in ui.menuItems
        readonly property int sm: Theme.profile > 0 ? 24 : 0
        readonly property real mx: Math.max(0, Math.min(ui.ctxX, shell.psw - 246))
        readonly property real my: Math.max(0, Math.min(ui.ctxY, shell.psh - Theme.taskbarHeight - menu.implicitHeight - 10))
        // Flyout (New ›): beside the menu, its first item level with the item that opened it; on the
        // left when there's no room on the right. A menu that has one always spans that room, so
        // pointing at it doesn't resize the surface.
        readonly property int subW: 212
        readonly property bool hasSub: menu.items.some(i => !!i && !!i.sub)
        readonly property real subX: mx + 240 + subW <= shell.psw ? mx + 240 : Math.max(0, mx - 4 - subW)
        readonly property real subY: Math.max(0, Math.min(my + menu.openSubY - 6, shell.psh - Theme.taskbarHeight - flyout.implicitHeight - 10))
        readonly property real boxL: hasSub ? Math.min(mx, subX) : mx
        readonly property real boxR: hasSub ? Math.max(mx + 236, subX + subW) : mx + 236
        readonly property real boxB: Math.max(my + menu.implicitHeight, flyout.visible ? subY + flyout.implicitHeight : 0)
        readonly property point at: Qt.point(ui.ctxX, ui.ctxY)
        onAtChanged: menu.openSub = ""
        onVisibleChanged: { menu.openSub = ""; menu.holdSub = false }
        screen: shell.panelScreen
        visible: ui.open === "context" || ui.open === "power" || isList
        anchors { left: true; top: true }
        margins { left: Math.max(0, boxL - sm); top: Math.max(0, my - sm) }
        implicitWidth: boxR + sm - margins.left
        implicitHeight: boxB + sm - margins.top
        exclusionMode: ExclusionMode.Ignore
        color: "transparent"
        WlrLayershell.layer: WlrLayer.Overlay
        WlrLayershell.namespace: "quasar-menu"
        WlrLayershell.keyboardFocus: WlrKeyboardFocus.None
        mask: Region { item: menu; Region { item: flyout.visible ? flyout : null } }

        function activate(key) {
            if (menuWin.isTask) { shell.taskMenuActivated(key); return }
            if (ui.open === "item") { shell.itemMenuActivated(key); return }
            if (ui.open === "appmenu") { shell.appMenuActivated(key); return }
            if (ui.open === "deck") { shell.deckMenuActivated(key); return }
            if (ui.open === "vnc") { shell.vncMenuActivated(key); return }
            if (ui.open === "services") { shell.servicesMenuActivated(key); return }
            // New items land where the desktop was right-clicked (tile centred on the point). From another
            // display's wallpaper (no icons there): the first free spot on the main display's desktop.
            const onMain = shell.sameScreen(shell.panelScreen, shell.main)
            const nx = onMain ? ui.ctxX - 48 : -1, ny = onMain ? ui.ctxY - 46 : -1
            const here = shell.panelScreen
            ui.close()
            if (key === "lock") sys.lock()
            else if (key === "logout") sys.logout()
            else if (key === "reboot") restartGuard.request("reboot")
            else if (key === "poweroff") restartGuard.request("poweroff")
            else if (key === "cancelwait") restartGuard.cancelWaiting()
            else if (key === "newfolder") desktop.newFolder(nx, ny)
            else if (key === "newtext") desktop.newTextFile(nx, ny)
            else if (key === "newlink") shell.openShortcutDialog(onMain ? nx + 48 : -1, onMain ? ny + 46 : -1)
            else if (key === "paste") desktop.paste(nx, ny)
            else if (key === "terminal") shell.openTerminal(desktop.dir)
            else if (key === "display") shell.openSettings("display")
            else if (key === "desktop") apps.showDesktop()
            else if (key === "ask") { shell.aiScreen = here; assistant.show("") }
        }

        ContextMenu {
            id: menu
            x: menuWin.mx - menuWin.margins.left
            y: menuWin.my - menuWin.margins.top
            width: 236; height: implicitHeight
            screenSize: Qt.size(shell.psw, shell.psh)
            screenPos: Qt.point(menuWin.mx, menuWin.my)
            wallpaperKind: Companies.wallpaper
            items: menuWin.isList ? ui.menuItems : menuWin.isPower ? [
                { key: "lock", label: "Lock", glyph: Icons.lock },
                // Signing out ends Remote desktop until someone signs in here (automatic sign-in runs once per start)
                { key: "logout", label: "Sign out", glyph: Icons.user, hint: remoteDesktop.listening ? "Ends remote desktop" : "" },
                { sep: true },
                // What's installing right now (services/RestartGuard.qml): restarting would break it.
                { key: "reboot", label: "Restart", glyph: Icons.refresh, hint: restartGuard.hint },
                { key: "poweroff", label: "Shut down", glyph: Icons.power, hint: restartGuard.hint }
            ].concat(restartGuard.waiting === "" ? [] : [
                { key: "cancelwait", label: restartGuard.waiting === "poweroff" ? "Don't shut down later" : "Don't restart later",
                  glyph: Icons.x }
            ]) : shell.desktopMenu
            onActivated: (key) => menuWin.activate(key)
        }
        ContextMenu {
            id: flyout
            visible: menu.openSub !== ""
            x: menuWin.subX - menuWin.margins.left
            y: menuWin.subY - menuWin.margins.top
            width: menuWin.subW; height: implicitHeight
            screenSize: Qt.size(shell.psw, shell.psh)
            screenPos: Qt.point(menuWin.subX, menuWin.subY)
            wallpaperKind: Companies.wallpaper
            items: menu.openSubItems
            onActivated: (key) => menuWin.activate(key)
            HoverHandler { onHoveredChanged: menu.holdSub = hovered }
        }
    }

    // ---------------------------------------------------------------- toasts
    PanelWindow {
        id: toastWin
        readonly property int sm: Theme.profile > 0 ? 28 : 0
        screen: shell.main
        visible: shell.toasts.length > 0
        anchors { right: true; bottom: true }
        margins { right: 0; bottom: Math.max(0, 68 - sm) }
        implicitWidth: sm + 320 + 12
        implicitHeight: toastCol.height + 2 * sm
        exclusionMode: ExclusionMode.Ignore
        color: "transparent"
        WlrLayershell.layer: WlrLayer.Overlay
        WlrLayershell.namespace: "quasar-toasts"
        WlrLayershell.keyboardFocus: WlrKeyboardFocus.None
        mask: Region { item: toastCol }

        Column {
            id: toastCol
            x: toastWin.sm; y: toastWin.sm
            width: 320
            spacing: 8
            Repeater {
                model: shell.toasts
                delegate: Item {
                    id: tItem
                    required property var modelData
                    width: 320; height: toast.implicitHeight
                    Toast {
                        id: toast
                        width: 320; height: implicitHeight
                        screenSize: Qt.size(shell.sw, shell.sh)
                        screenPos: Qt.point(shell.sw - 12 - 320, shell.sh - 68 - toastCol.height + tItem.y)
                        wallpaperKind: Companies.wallpaper
                        title: tItem.modelData.title
                        sub: tItem.modelData.sub
                        glyph: tItem.modelData.glyph || Icons.bell
                        hue: tItem.modelData.hue || Theme.accent
                        image: tItem.modelData.icon || ""
                        onDismissed: { if (tItem.modelData.notif) tItem.modelData.notif.dismiss(); shell.dropToast(tItem.modelData.id) }
                        onClicked: {
                            if (tItem.modelData.company) companyDesk.switchTo(tItem.modelData.company)
                            if (tItem.modelData.settings) shell.openSettings(tItem.modelData.settings)
                            if (tItem.modelData.open) apps.launchId("quasar-files", [tItem.modelData.open])
                            if (tItem.modelData.runTerminal) programs.runInTerminal(tItem.modelData.runTerminal)
                            if (tItem.modelData.app) apps.launchId(tItem.modelData.app, tItem.modelData.args || [])
                            shell.dropToast(tItem.modelData.id)
                        }
                    }
                    Timer { interval: 4200; running: true; onTriggered: shell.dropToast(tItem.modelData.id) }
                }
            }
        }
    }

    // ---------------------------------------------------------------- programs from files
    // A double-clicked .sh, .py, .exe (.NET) or .AppImage: asked about first (RunPrompt), then run by
    // /usr/libexec/quasar/program. Pointer only, like the pairing questions: a stray Enter runs nothing.
    Programs { id: programs; apps: apps; locked: screenLock.locked; onToast: (t) => shell.toast(t) }
    PanelWindow {
        screen: shell.main
        visible: !!programs.current
        anchors { top: true; bottom: true; left: true; right: true }
        exclusionMode: ExclusionMode.Ignore
        color: "transparent"
        WlrLayershell.layer: WlrLayer.Overlay
        WlrLayershell.namespace: "quasar-run-prompt"
        WlrLayershell.keyboardFocus: WlrKeyboardFocus.None
        RunPrompt {
            anchors.fill: parent
            info: programs.current
            textEditor: programs.textEditor
            bottlesInstalled: programs.bottlesInstalled
            runsIn: programs.runsIn
            busy: programs.gettingRuntime
            progress: programs.runtimeProgress
            status: programs.runtimeStatus
            onChosen: (a) => programs.choose(a)
            onCancelled: programs.choose("cancel")
        }
    }

    // ---------------------------------------------------------------- "wants to receive connections"
    // The firewall refused a connection an app of yours was waiting for (quasar-netguard): ask, above
    // the toasts. Pointer only: the card never takes the keyboard, so a stray Enter allows nothing.
    NetGuard { id: netGuard; onNotify: (t) => shell.toast(Object.assign({ hue: Theme.accent }, t)) }
    // VPN and Mobile hotspot tiles, and toasts when the hotspot or Encrypted DNS stops on its own.
    NetQuick {
        id: netQuick
        wifiAvailable: sys.wifiAvailable
        onToast: (t) => shell.toast(t)
        onOpenSettings: (page) => shell.openSettings(page)
    }
    // "Restart to finish installing updates" and, with automatic updates off, "Security updates are ready"
    // (services/UpdateNotice.qml, from quasar-update's state file).
    UpdateNotice { onToast: (t) => shell.toast(t) }
    // "The desktop is up" for shell-rescue's guard and the boot check, and the safe-graphics toast.
    ShellReady { id: shellReady; onToast: (t) => shell.toast(t) }
    // The Services tray's numbers and "<name> stopped working" (services/BackgroundServices.qml, from
    // services-query watch --summary: systemd's signals, nothing polled).
    BackgroundServices { id: bgServices; onToast: (t) => shell.toast(t) }
    PanelWindow {
        id: promptWin
        readonly property var p: netGuard.current
        screen: shell.main
        visible: !!p
        anchors { right: true; bottom: true }
        margins { right: 12; bottom: 68 + (toastWin.visible ? toastCol.height + 8 : 0) }
        implicitWidth: prompt.implicitWidth
        implicitHeight: prompt.implicitHeight
        exclusionMode: ExclusionMode.Ignore
        color: "transparent"
        WlrLayershell.layer: WlrLayer.Overlay
        WlrLayershell.namespace: "quasar-connection-prompt"
        WlrLayershell.keyboardFocus: WlrKeyboardFocus.None
        ConnectionPrompt {
            id: prompt
            readonly property var p: promptWin.p
            appName: netGuard.appName(p)
            icon: netGuard.appIcon(p)
            kind: p ? p.kind : "app"
            port: p ? p.port : 0
            hasNetwork: !!(p && p.network)
            networkName: p && p.network ? p.network.name : ""
            home: !!(p && p.network && p.network.home)
            busy: netGuard.busy
            onAllowClicked: netGuard.allow()
            onNotNowClicked: netGuard.notNow()
        }
    }

    // ---------------------------------------------------------------- IPC (compositor keybinds)
    //   qs --path /usr/share/quasar/shell ipc call launcher toggle
    IpcHandler {
        target: "commanddeck"
        function state(): string { return JSON.stringify({ enabled: deck.enabled, phones: deck.phones, live: deck.live, watched: deck.watched }) }
        function stopScreen(): void { deck.stopScreen() }
        function disconnect(): void { deck.disconnect() }
    }
    IpcHandler {
        target: "remotedesktop"
        function state(): string {
            return JSON.stringify({ enabled: remoteDesktop.enabled, status: remoteDesktop.status, viewers: remoteDesktop.viewers,
                                    main: remoteDesktop.mainName, locked: screenLock.locked })
        }
        function disconnect(): void { remoteDesktop.disconnectAll() }
    }
    IpcHandler {
        target: "launcher"
        function toggle(): void { ui.toggle("launcher") }
        function open(): void { ui.show("launcher") }
        function close(): void { ui.close() }
    }
    IpcHandler {
        target: "shell"
        function quickSettings(): void { sys.refresh(); ui.toggle("quick") }
        function calendar(): void { ui.toggle("calendar") }
        function closeAll(): void { ui.close() }
        function lock(): void { sys.lock() }
        // Settings' Restart buttons (Platform.power): through RestartGuard, like the power menu.
        function power(action: string): void { if (action === "reboot" || action === "poweroff") restartGuard.request(action) }
        function setProfile(p: int): void { Settings.profile = p }
        function wallpaper(kind: string): void { Settings.wallpaper = kind }
        function wallpaperPhoto(path: string): void { Settings.useWallpaperPhoto(path) }
        function accent(c: string): void { Settings.accent = c }
    }
    // Launch in the shown company (labwc keybinds, the Store's Open): Personal or a company decides.
    //   qs --path /usr/share/quasar/shell ipc call launch terminal
    IpcHandler {
        target: "launch"
        function terminal(): void { shell.openTerminal("") }
        // A terminal in a folder (Files' "Open in Terminal": a shown company gets its own).
        function terminalIn(dir: string): void { shell.openTerminal(dir) }
        function files(): void { shell.openFiles("") }
        function app(id: string): void {
            if (!apps.launchId(id)) shell.toast({ title: "That app isn't installed", sub: id, glyph: Icons.grid, hue: Theme.text3 })
        }
    }
    // Quasar AI: Settings' "Try it", keybinds and the nested-session tests.
    //   qs --path /usr/share/quasar/shell ipc call assistant ask "turn on night light"
    IpcHandler {
        target: "assistant"
        function toggle(): void { if (!assistant.open) shell.aiScreen = shell.focusScreen(); assistant.toggle() }
        function ask(text: string): void { if (!assistant.open) shell.aiScreen = shell.focusScreen(); assistant.show(text) }
        function run(): void { assistant.runPlan() }
        function cancel(): void { assistant.cancelPlan() }
        function allow(): void { assistant.allow() }
        function deny(): void { assistant.deny() }
        function stop(): void { assistant.stop() }
        function undo(): void { assistant.undo() }
        function newTask(): void { assistant.newTask() }
        function state(): string {
            const b = []
            for (let i = 0; i < assistant.blocks.count; i++) { const x = assistant.blocks.get(i); b.push({ kind: x.kind, text: x.text, ids: x.ids, action: x.action, details: x.details }) }
            return JSON.stringify({ open: assistant.open, busy: assistant.busy, ready: assistant.ready, provider: assistant.provider,
                                    plan: assistant.planIds, ask: assistant.askId, canUndo: assistant.canUndo, blocks: b, steps: assistant.steps })
        }
    }
    // The connection prompt (tests): state, and a sample prompt when QUASAR_NETGUARD_DEMO=1.
    //   qs --path /usr/share/quasar/shell ipc call netguard state
    IpcHandler {
        target: "netguard"
        function state(): string {
            return JSON.stringify({ enabled: netGuard.enabled, connected: !!netGuard.client && !netGuard.client.dead,
                                    current: netGuard.current, queued: netGuard.queue.length, busy: netGuard.busy })
        }
        function allow(): void { netGuard.allow() }
        function notNow(): void { netGuard.notNow() }
        function demo(json: string): void {
            if (Quickshell.env("QUASAR_NETGUARD_DEMO") !== "1") return
            try { netGuard.received(Object.assign({ event: "prompt" }, JSON.parse(json))) } catch (e) { }
        }
    }
    // Programs from files. open = a double-click (Files uses it); external = another app (program
    // open-external: always asks); exited = the launcher's watcher; answer only with QUASAR_PROGRAMS_TEST=1.
    //   qs --path /usr/share/quasar/shell ipc call programs open /home/u/Downloads/install.sh
    IpcHandler {
        target: "programs"
        function open(path: string): void { programs.open(path, "") }
        function terminal(path: string): void { programs.open(path, "terminal") }
        function toApps(path: string): void { programs.open(path, "apps") }
        function external(path: string): void { programs.external(path) }
        function exited(report: string): void { programs.exited(report) }
        function state(): string { return programs.stateJson() }
        function answer(choice: string): void { if (Quickshell.env("QUASAR_PROGRAMS_TEST") === "1") programs.choose(choice) }
    }
    //   qs --path /usr/share/quasar/shell ipc call desktop newFolder   (used by the nested-session tests)
    IpcHandler {
        target: "desktop"
        function newFolder(): void { desktop.newFolder(-1, -1) }
        function newTextFile(): void { desktop.newTextFile(-1, -1) }
        function newShortcut(): void { shell.openShortcutDialog(shell.sw / 2, shell.sh / 2) }
        function selectAll(): void { deskUi.selection = desktop.items.map(i => i.key) }
        function select(key: string): void { deskUi.selection = key ? [key] : [] }
        function rename(key: string): void { shell.startRename(key) }
        function menu(key: string): void { const p = desktop.pos[key]; if (p) shell.deskContext(key, p.x + 60, p.y + 50) }
        function arrange(mode: string): void { Settings.desktopArrange = mode }
        function tidy(): void { desktop.tidy() }
        function state(): string {
            return JSON.stringify({ selection: deskUi.selection, renaming: deskUi.renaming, open: ui.open, under: ui.under, focused: deskUi.focused,
                                    dragging: deskUi.dragging, items: desktop.items.length,
                                    screen: shell.panelScreen ? shell.panelScreen.name : "", main: shell.main ? shell.main.name : "",
                                    assistantScreen: shell.assistantScreen ? shell.assistantScreen.name : "" })
        }
    }
}
