import QtQuick

// Bottom-right resize handle (template: 18x18, nwse-resize cursor). The host window starts a
// compositor-driven resize (startSystemResize) on press.
Item {
    id: root
    signal resizeRequested()
    width: 18
    height: 18
    MouseArea {
        anchors.fill: parent
        cursorShape: Qt.SizeFDiagCursor
        onPressed: root.resizeRequested()
    }
}
