import QtQuick
import Quickshell
import Quasar
import Quasar.Services

// fileop (/usr/libexec/quasar/fileop: copy, move, trash, rename, archives, clipboard, open…) for every
// Files window, one short-lived process per job. Jobs belong to the app, not to a window, so closing
// a window never stops a copy halfway; the app quits once the last job is done (shell.qml).
// Slow jobs are listed in `jobs` with their byte progress ({"progress", "total"} lines); copies, moves,
// trash, restore and searches can be cancelled (SIGTERM: fileop stops after the current chunk and
// removes the half-copied item). QUASAR_FILEOP points at another helper (tests).
Scope {
    id: root
    readonly property string helper: Quickshell.env("QUASAR_FILEOP") || "/usr/libexec/quasar/fileop"
    // [{ id, label, done, total, cancellable }], oldest first. Shown once a job has taken a moment.
    property var jobs: []
    readonly property int busy: jobs.length
    readonly property var shownJobs: shown ? jobs : []
    property bool shown: false
    signal jobDone()                           // a slow job finished (free space and listings may differ)

    readonly property var cancellable: ["copy", "move", "drop", "paste", "trash", "restore", "search", "props"]
    property int _seq: 0
    property var _cmds: ({})                   // job id -> its Cmd

    Timer { id: showSoon; interval: 400; onTriggered: root.shown = root.busy > 0 }

    Component { id: cmd; Cmd { tailLines: 50 } }

    function _update(id, fields) {
        jobs = jobs.map(j => j.id === id ? Object.assign({}, j, fields) : j)
    }

    // args: fileop's arguments. onLine(obj): each JSON line. onDone(code, lastError, lines): code 130
    // when it was cancelled. slow: a label for the status bar while it runs (also marks it as a job
    // the app waits for before it quits). Returns an id for cancel() (any run, slow or not).
    function run(args, onLine, onDone, slow) {
        const c = cmd.createObject(root)
        let err = ""
        const lines = []
        const id = ++_seq
        _cmds[id] = c
        c.line.connect((l) => {
            let o = null
            try { o = JSON.parse(l) } catch (e) { return }
            if (o.progress !== undefined) {
                if (slow) root._update(id, { done: o.progress, total: o.total || 0 })
                return
            }
            lines.push(o)
            if (o.error) err = o.error
            if (onLine) { try { onLine(o) } catch (e) { console.warn("fileop line handler:", e) } }
        })
        c.finished.connect((code) => {
            delete root._cmds[id]
            if (slow) {
                root.jobs = root.jobs.filter(j => j.id !== id)
                if (root.jobs.length === 0) { root.shown = false; showSoon.stop() }
            }
            if (onDone) { try { onDone(code, err, lines) } catch (e) { console.warn("fileop done handler:", e) } }
            if (slow) root.jobDone()
            c.destroy()
        })
        if (slow) {
            jobs = jobs.concat([{ id: id, label: slow, done: 0, total: 0, cancellable: cancellable.indexOf(args[0]) >= 0 }])
            if (!showSoon.running && !shown) showSoon.start()
        }
        c.run([helper].concat(args))
        return id
    }
    function cancel(id) {
        const c = _cmds[id]
        if (c) c.terminate()
    }
}
