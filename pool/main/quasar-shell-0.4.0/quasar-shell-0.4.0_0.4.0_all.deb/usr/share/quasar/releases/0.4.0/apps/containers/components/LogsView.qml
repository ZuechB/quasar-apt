import QtQuick
import Quasar

// The logs of one container (docker logs -f): monospace, selectable, and it follows new output while
// scrolled to the bottom — scrolling up pauses that, scrolling back down resumes it. Copy puts all the
// lines shown on the clipboard.
Item {
    id: root
    property string name: ""
    property string text: ""
    signal back()

    property bool follow: true
    property bool _auto: false            // contentY is being moved by following, not by the user

    Item {
        id: head
        width: parent.width
        height: 58
        Button {
            id: backBtn
            x: 14
            anchors.verticalCenter: parent.verticalCenter
            text: "Back"; glyph: Icons.back
            variant: "ghost"; size: 32
            onClicked: root.back()
        }
        Text {
            anchors { left: backBtn.right; leftMargin: 10; right: tools.left; rightMargin: 12; verticalCenter: parent.verticalCenter }
            elide: Text.ElideRight
            text: "Logs  ·  " + root.name
            font.family: Theme.fontDisplay; font.pixelSize: 17; font.weight: Font.Medium
            color: Theme.text
        }
        Row {
            id: tools
            anchors { right: parent.right; rightMargin: 18; verticalCenter: parent.verticalCenter }
            spacing: 8
            StatusPill {
                anchors.verticalCenter: parent.verticalCenter
                text: root.follow ? "Following" : "Paused"
                tone: root.follow ? Theme.mint : Theme.textDim
            }
            Button {
                anchors.verticalCenter: parent.verticalCenter
                text: "Copy"
                variant: "soft"; size: 30
                onClicked: { log.selectAll(); log.copy(); log.deselect() }
            }
        }
    }
    Rectangle { y: head.height; width: parent.width; height: 1; color: Theme.white(0.05) }

    ScrollPane {
        id: pane
        y: head.height + 1
        width: parent.width
        height: parent.height - y
        topPadding: 14; bottomPadding: 14

        TextEdit {
            id: log
            x: 18
            width: pane.width - 36
            readOnly: true
            selectByMouse: true
            textFormat: TextEdit.PlainText
            wrapMode: TextEdit.WrapAnywhere
            text: root.text !== "" ? root.text : "No output yet."
            font.family: Theme.fontMono; font.pointSize: Theme.pt(12)
            color: root.text !== "" ? Theme.text2 : Theme.textDim
            selectionColor: Theme.alpha(Theme.accent, 0.35)
            selectedTextColor: Theme.text
        }
    }
    Connections {
        target: pane
        function onContentYChanged() {
            if (!root._auto) root.follow = pane.contentY >= pane.contentHeight - pane.height - 4
        }
        function onContentHeightChanged() {
            if (!root.follow) return
            root._auto = true
            pane.contentY = Math.max(0, pane.contentHeight - pane.height)
            root._auto = false
        }
    }
    onVisibleChanged: if (visible) follow = true
}
