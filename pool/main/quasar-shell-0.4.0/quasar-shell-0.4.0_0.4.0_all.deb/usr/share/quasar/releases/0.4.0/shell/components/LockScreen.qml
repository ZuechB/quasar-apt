import QtQuick
import Quasar

// The lock screen (services/ScreenLock.qml shows it on every screen; the card only on the main one):
// your wallpaper dimmed, the time and date, your card with the password field, and Sign out (the way
// to let someone else use the PC: their account needs a session of its own). Pure view.
Item {
    id: root
    property string name: ""                 // display name
    property string seed: ""                 // username (avatar hue)
    property string wallpaper: "deep"
    property bool main: true
    property bool busy: false
    property string message: ""
    property bool messageIsError: false
    property string prompt: "Password"
    property bool echo: false
    property var now: new Date()
    property bool ticking: true
    property bool confirmingSignOut: false
    signal submitted(string password)
    signal signOut()

    function focusInput() { card.focusInput() }
    function clear() { card.clear() }
    function setText(t) { card.setText(t) }         // previews

    Timer { running: root.ticking && root.visible; repeat: true; interval: 5000; onTriggered: root.now = new Date() }

    Wallpaper {
        anchors.fill: parent
        kind: root.wallpaper
        animated: false
    }
    Rectangle { anchors.fill: parent; color: Qt.rgba(0.02, 0.024, 0.04, 0.55) }

    Column {
        id: clock
        anchors.horizontalCenter: parent.horizontalCenter
        y: Math.round(parent.height * (root.main ? 0.12 : 0.36))
        spacing: 4
        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: Qt.formatTime(root.now, "h:mm")
            font.family: Theme.fontDisplay; font.pixelSize: root.main ? 76 : 96; font.weight: Font.Light
            color: Theme.text
        }
        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: Qt.formatDate(root.now, "dddd, MMMM d")
            font.family: Theme.fontUi; font.pointSize: Theme.pt(16)
            color: Theme.text3
        }
    }

    SignInCard {
        id: card
        visible: root.main
        width: 340
        anchors.horizontalCenter: parent.horizontalCenter
        y: Math.round(Math.max(clock.y + clock.height + 40, parent.height * 0.5 - 150))
        name: root.name
        seed: root.seed
        sub: "Locked"
        placeholder: root.prompt
        echo: root.echo
        busy: root.busy
        message: root.confirmingSignOut ? "Signing out closes your apps. Anything unsaved in them is lost." : root.message
        messageIsError: !root.confirmingSignOut && root.messageIsError
        actionText: root.confirmingSignOut ? "Sign out and close my apps" : "Sign out"
        onSubmitted: (pw) => { root.confirmingSignOut = false; root.submitted(pw) }
        onEscapePressed: { root.confirmingSignOut = false; card.clear() }
        onActionClicked: {
            if (root.confirmingSignOut) root.signOut()
            else root.confirmingSignOut = true
        }
    }
}
