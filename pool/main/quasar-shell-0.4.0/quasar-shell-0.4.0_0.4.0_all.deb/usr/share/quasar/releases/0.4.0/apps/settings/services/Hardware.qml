import QtQuick
import Quickshell
import Quickshell.Io
import Quasar
import Quasar.Services
import "../components/drivers.js" as Drivers

// Settings > Drivers & Hardware. Reads what hw-detect found at boot (/run/quasar/hardware.json: graphics
// cards and their drivers, Wi-Fi/Bluetooth/sound devices, firmware, driver suggestions) and runs the
// installs the user picks through the quasar-drivers root helper. Detection is local; only an install
// the user starts downloads anything.
Item {
    id: hw
    visible: false

    property var report: null
    property bool scanning: false
    property string fallback: ""          // set when the session fell back to software rendering (the reason)
    // "Safe graphics": ~/.config/quasar/renderer says "software" (quasar-session reads it at sign-in).
    readonly property string rendererPath: (Quickshell.env("XDG_CONFIG_HOME") || (Quickshell.env("HOME") + "/.config")) + "/quasar/renderer"
    property bool safeGraphics: false
    property string job: ""               // offer id being installed
    property string jobTitle: ""
    property int progress: 0
    property string phase: ""
    property string error: ""
    property bool rebootNeeded: false
    property bool restartPending: false   // ask the user to restart (Dialog in shell.qml)
    property var ask: null                // { key, title, message, button }: confirmation before an install
    signal notify(var banner)             // progress / result banner for the page

    readonly property var ctx: ({ live: Platform.live, softwareRender: Platform.softwareRender, fallback: fallback,
                                  safe: safeGraphics, job: job, scanning: scanning, icons: Icons, theme: Theme })
    readonly property var groups: Drivers.groups(report, ctx)
    readonly property var hero: Drivers.hero(report, ctx)

    function parse(t) { try { report = JSON.parse(t) } catch (e) { } }
    function refresh() { scanning = true; detect.running = true }

    function activate(key) {
        if (key === "hw:rescan") { refresh(); return }
        const o = Drivers.offerFor(report, key)
        if (!o || job !== "" || Platform.live)
            return
        if (o.id === "nvidia" && o.action === "install")
            ask = { key: key, button: "Install", title: "Install NVIDIA's driver?",
                    message: (o.switchesKernel ? "NVIDIA's driver runs on Debian's standard kernel (Linux 6.12), so Quasar also "
                                                 + "switches this PC to that kernel. This card doesn't need the newer one. " : "")
                           + "Quasar downloads about 400 MB from Debian and sets it up, which takes a few minutes. "
                           + "Restart when it's done. If it can't be set up on this PC, nothing changes." }
        else if (o.id === "nvidia")
            ask = { key: key, button: "Switch", title: "Switch back to the open driver?",
                    message: "Removes NVIDIA's driver. The open driver (nouveau) takes over after a restart."
                           + (o.switchesKernel ? " Quasar also returns this PC to the newer kernel it came with (a download)." : "") }
        else
            run(o)
    }
    function heroActivated() { const o = Drivers.recommended(report); if (o) activate("hw:" + o.id) }

    // Safe graphics on or off from the next sign-in (the "hw:safe" switch). Off removes the file, so the
    // automatic choice (the graphics card when it has a 3D driver) comes back.
    function toggleSafe() {
        const on = !safeGraphics
        if (on)
            Quickshell.execDetached(["sh", "-c", 'mkdir -p "${1%/*}" && printf "software\\n" > "$1"', "sh", rendererPath])
        else
            Quickshell.execDetached(["rm", "-f", rendererPath])
        safeGraphics = on
        notify({ tone: "info", title: on ? "Safe graphics starts the next time you sign in" : "The graphics card is used again the next time you sign in",
                 message: on ? "Everything draws in software: slower, but it works when the graphics driver doesn't." : "",
                 actionText: "Sign out", action: "session:signout" })
    }
    function confirm() { const k = ask ? ask.key : ""; ask = null; const o = Drivers.offerFor(report, k); if (o) run(o) }

    function run(o) {
        job = o.id; progress = 0; phase = "Starting"; error = ""; rebootNeeded = false
        jobTitle = o.id === "nvidia" ? (o.action === "remove" ? "Switching to the open driver" : "Installing NVIDIA's driver")
                                     : "Installing firmware"
        notify({ tone: "info", title: jobTitle, message: "Starting…" })
        installer.runHelper(o.id === "nvidia" ? ["nvidia", o.action] : ["firmware"].concat(o.packages || []))
    }

    // (not `id: helper`: the object's own `helper` property would shadow it inside its handlers)
    Privileged {
        id: installer
        helper: "quasar-drivers"
        onLine: (l) => {
            if (l.startsWith("PROGRESS ")) hw.progress = parseInt(l.slice(9)) || hw.progress
            else if (l.startsWith("PHASE ")) hw.phase = l.slice(6)
            else if (l.startsWith("ERROR ")) hw.error = l.slice(6)
            else if (l === "REBOOT") hw.rebootNeeded = true
            if (hw.job !== "") hw.notify({ tone: "info", title: hw.jobTitle, message: hw.phase + "  ·  " + hw.progress + "%" })
        }
        onFinished: (code) => {
            const title = hw.jobTitle
            hw.job = ""
            if (code === 0) {
                hw.notify({ tone: "success", title: title.replace(/^Installing/, "Installed").replace(/^Switching/, "Switched"),
                            message: hw.rebootNeeded ? "Restart the PC to finish." : "", actionText: hw.rebootNeeded ? "Restart now" : "",
                            restart: hw.rebootNeeded })
                if (hw.rebootNeeded) hw.restartPending = true
            } else if (installer.cancelledByUser) {
                hw.notify(null)
            } else {
                hw.notify({ tone: "error", title: hw.error || "That didn't work", message: "Nothing else was changed.",
                            details: installer.details() })
            }
            hw.refresh()
        }
    }

    // A driver install runs as its own system job (quasar-drivers-job.service): it goes on when Settings
    // closes, and Settings opened later follows it here, from the job's file (written in place). An install
    // this window started is followed through its own output instead.
    property bool attached: false
    function follow(j) {
        if (!j || installer.running) return
        if (j.state === "running") {
            attached = true
            job = j.id || "job"
            jobTitle = j.title || "Installing a driver"
            progress = typeof j.progress === "number" ? j.progress : progress
            phase = j.phase || phase
            notify({ tone: "info", title: jobTitle, message: (phase ? phase + "  ·  " : "") + progress + "%" })
        } else if (attached && (j.state === "done" || j.state === "failed")) {
            attached = false
            const title = jobTitle
            job = ""
            if (j.state === "done") {
                rebootNeeded = !!j.reboot
                notify({ tone: "success", title: title.replace(/^Installing/, "Installed").replace(/^Switching/, "Switched"),
                         message: j.reboot ? "Restart the PC to finish." : "", actionText: j.reboot ? "Restart now" : "",
                         restart: !!j.reboot })
                if (j.reboot) restartPending = true
            } else {
                notify({ tone: "error", title: j.error || "That didn't work", message: "Nothing else was changed." })
            }
            refresh()
        }
    }
    FileView {
        path: Quickshell.env("QUASAR_DRIVERS_JOB") || "/run/quasar/drivers-job.json"
        watchChanges: true
        printErrors: false
        onFileChanged: reload()
        onLoaded: { try { hw.follow(JSON.parse(text())) } catch (e) { } }
    }

    FileView {
        path: "/run/quasar/hardware.json"
        watchChanges: true
        printErrors: false
        onFileChanged: reload()
        onLoaded: hw.parse(text())
        onLoadFailed: (error) => hw.refresh()          // the boot-time scan hasn't run: scan now
    }
    FileView {
        // Written by quasar-session (labwc couldn't start on the graphics card) or shell-rescue (the desktop
        // kept stopping), possibly while Settings is open.
        path: (Quickshell.env("XDG_RUNTIME_DIR") || "/tmp") + "/quasar-render-fallback"
        watchChanges: true
        printErrors: false
        onFileChanged: reload()
        onLoaded: hw.fallback = text().trim()
        onLoadFailed: (error) => hw.fallback = ""
    }
    FileView {
        path: hw.rendererPath
        printErrors: false
        onLoaded: hw.safeGraphics = text().trim() === "software"
        onLoadFailed: (error) => hw.safeGraphics = false
    }
    Process {
        id: detect
        command: ["/usr/libexec/quasar/hw-detect"]
        stdout: StdioCollector { onStreamFinished: { hw.parse(text); hw.scanning = false } }
        onExited: (code, status) => hw.scanning = false
    }
}
