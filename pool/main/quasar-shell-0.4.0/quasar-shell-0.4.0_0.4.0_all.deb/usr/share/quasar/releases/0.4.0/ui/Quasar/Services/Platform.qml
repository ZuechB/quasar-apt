pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io

// What kind of machine/session this is (set by quasar-session, see linux/session/bin).
Singleton {
    id: root
    readonly property string home: Quickshell.env("HOME") || "/root"
    readonly property string userName: Quickshell.env("QUASAR_USER_NAME") || Quickshell.env("USER") || "You"
    readonly property string renderMode: Quickshell.env("QUASAR_RENDER") || "gpu"        // gpu | software
    readonly property bool softwareRender: renderMode === "software"
    // Qt's software scene graph (no shaders): quasar-shell / quasar-app set it on the software path.
    readonly property bool softwareScene: Quickshell.env("QT_QUICK_BACKEND") === "software"
    readonly property bool live: Quickshell.env("QUASAR_LIVE") === "1"
    readonly property string compositor: Quickshell.env("QUASAR_COMPOSITOR") || "labwc"
    // Members of "sudo" administer this PC (Flatpak system installs need no prompt for them).
    property bool isAdmin: false

    // Restart ("reboot") or shut down ("poweroff") the way the desktop's power menu does: the shell first
    // checks for installs a restart would break and asks (shell/services/RestartGuard.qml). Without a shell
    // that knows how (none running, or one from an older version), straight to systemd.
    function power(action) {
        const a = action === "poweroff" ? "poweroff" : "reboot"
        Quickshell.execDetached(["sh", "-c", 'qs --path /usr/share/quasar/shell ipc call shell power "$1" >/dev/null 2>&1 || systemctl "$1"', "sh", a])
    }

    Process {
        command: ["id", "-Gn"]
        running: true
        stdout: StdioCollector { onStreamFinished: root.isAdmin = (" " + text.trim() + " ").indexOf(" sudo ") >= 0 }
    }
}
