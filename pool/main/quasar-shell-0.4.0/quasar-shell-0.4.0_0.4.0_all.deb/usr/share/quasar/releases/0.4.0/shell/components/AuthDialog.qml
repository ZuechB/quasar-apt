import QtQuick
import Quasar

// Password sheet for system changes (the shell is the polkit authentication agent): dims the
// screen, centred card with the reason, the account, a password field and Cancel / Allow.
// Pure view: the host connects it to Quickshell's PolkitAgent flow.
Item {
    id: root
    property string message: ""            // why (from the polkit action), e.g. "Enter your password to install…"
    property string identity: ""            // account that authenticates
    property string prompt: "Password"
    property bool echo: false               // show what is typed (non-secret prompts)
    property string feedback: ""            // e.g. "Sorry, try again."
    property bool feedbackIsError: false
    property bool busy: false
    property bool canSwitch: false          // several accounts may answer (administrators): tap to switch
    signal submitted(string response)
    signal switchIdentity()
    signal cancelled()

    function focusInput() { field.focusInput() }
    function clear() { field.text = "" }

    Rectangle {
        anchors.fill: parent
        color: Qt.rgba(0, 0, 0, 0.5)
        MouseArea { anchors.fill: parent }       // modal: clicks outside do nothing
    }

    Rectangle {
        id: card
        anchors.centerIn: parent
        width: Math.min(420, parent.width - 40)
        height: col.implicitHeight + 48
        radius: 22
        color: Theme.solid
        border.width: 1
        border.color: Theme.white(0.11)
        Accessible.role: Accessible.Dialog
        Accessible.name: "Authentication required"

        Column {
            id: col
            x: 24; y: 24
            width: parent.width - 48
            spacing: 14

            Rectangle {
                width: 46; height: 46; radius: 15
                color: Theme.alpha(Theme.accent, 0.14)
                QIcon { anchors.centerIn: parent; path: Icons.lock; size: 22; strokeWidth: 1.9; color: Theme.accent }
            }
            Text {
                width: parent.width
                text: "Allow this change?"
                font.family: Theme.fontDisplay; font.pixelSize: 20; font.weight: Font.Medium
                color: Theme.text
            }
            Text {
                width: parent.width
                text: root.message
                wrapMode: Text.Wrap
                textFormat: Text.PlainText
                font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
                color: Theme.text3
            }
            Pressable {
                visible: root.identity !== ""
                kind: root.canSwitch ? "hov" : "plain"
                radius: 10
                implicitWidth: idRow.implicitWidth + 12
                implicitHeight: 34
                x: -6
                accessibleName: root.canSwitch ? "Use another administrator's account" : root.identity
                onClicked: if (root.canSwitch) root.switchIdentity()
                Row {
                    id: idRow
                    x: 6
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: 10
                    UserAvatar { anchors.verticalCenter: parent.verticalCenter; size: 26; name: root.identity }
                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        text: root.identity
                        textFormat: Text.PlainText
                        font.family: Theme.fontUi; font.pixelSize: 13; font.weight: Font.Medium
                        color: Theme.text
                    }
                    QIcon {
                        visible: root.canSwitch
                        anchors.verticalCenter: parent.verticalCenter
                        path: Icons.chev; size: 12; strokeWidth: 2
                        color: Theme.textDim
                    }
                }
            }
            TextField {
                id: field
                width: parent.width
                glyph: Icons.lock
                placeholder: root.prompt.replace(/:\s*$/, "")
                password: !root.echo
                error: root.feedbackIsError
                enabled: !root.busy
                onAccepted: if (text !== "") root.submitted(text)
                onEscapePressed: root.cancelled()
            }
            Text {
                width: parent.width
                visible: root.feedback !== ""
                text: root.feedback
                wrapMode: Text.Wrap
                textFormat: Text.PlainText
                font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
                color: root.feedbackIsError ? Theme.danger : Theme.textDim
            }
            Row {
                anchors.right: parent.right
                spacing: 8
                Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: root.cancelled() }
                Button {
                    text: "Allow"; variant: "primary"; size: 38
                    busy: root.busy
                    enabled: field.text !== "" && !root.busy
                    onClicked: root.submitted(field.text)
                }
            }
        }
    }
}
