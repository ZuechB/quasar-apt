import QtQuick
import Quasar

// Template Sites empty state: centred glyph, "No sites yet", one line, "New site".
Item {
    id: root
    signal openNew()

    Column {
        anchors.centerIn: parent
        width: Math.min(parent.width, 420)
        spacing: 10
        QIcon { anchors.horizontalCenter: parent.horizontalCenter; path: Icons.web; size: 40; strokeWidth: 1.6; color: Theme.textDim }
        Item { width: 1; height: 4 }
        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: "No sites yet"
            font.family: Theme.fontDisplay; font.pixelSize: 22; font.weight: Font.Medium
            color: Theme.text
        }
        Text {
            width: parent.width
            horizontalAlignment: Text.AlignHCenter
            text: "Host a .NET, Node or static project with its own HTTPS address."
            wrapMode: Text.WordWrap
            font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
            color: Theme.textMuted
        }
        Item { width: 1; height: 6 }
        Button {
            anchors.horizontalCenter: parent.horizontalCenter
            variant: "primary"; size: 38
            text: "New site"; glyph: Icons.plus
            onClicked: root.openNew()
        }
    }
}
