import QtQuick
import Quasar

// Settings › Arrange displays › Identify: the display's number (as Settings numbers it) and its name,
// big and centred on that display for a moment. Pops in with the spring curve (the template's `pop`),
// fades out when `shown` drops; the host keeps its window up while `enter` > 0. Pure view: the shell
// hosts one per screen.
Panel {
    id: root
    radius: 28
    tint: Theme.menuBg
    borderColor: Theme.white(0.12)
    shadowOffsetY: 26
    shadowBlur: 60
    shadowSpread: -18

    property int number: 0
    property string label: ""
    property bool shown: true

    implicitWidth: Math.max(176, nameText.implicitWidth + 48)
    implicitHeight: 176

    property real enter: 0
    onShownChanged: shown ? popIn.restart() : popOut.restart()
    Component.onCompleted: if (shown) popIn.restart()
    NumberAnimation {
        id: popIn
        target: root; property: "enter"; to: 1
        duration: Motion.dur(Motion.pop)
        easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.spring
    }
    NumberAnimation { id: popOut; target: root; property: "enter"; to: 0; duration: Motion.dur(220); easing.type: Easing.InCubic }
    opacity: Math.min(1, enter * 1.6)
    scale: 0.6 + 0.4 * enter

    Text {
        anchors { horizontalCenter: parent.horizontalCenter; top: parent.top; topMargin: 18 }
        text: root.number > 0 ? String(root.number) : ""
        font.family: Theme.fontDisplay
        font.pixelSize: 96
        font.weight: Font.Medium
        color: Theme.text
    }
    Text {
        id: nameText
        anchors { horizontalCenter: parent.horizontalCenter; bottom: parent.bottom; bottomMargin: 18 }
        text: root.label
        font.family: Theme.fontUi
        font.pointSize: Theme.pt(13)
        color: Theme.textMuted
    }
}
