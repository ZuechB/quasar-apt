// Settings > Companies & Profiles > Azure DevOps (one space: Personal or a company): its build agent and
// deploy agent. Pure, so the Settings app (services/AzureDevOps.qml) and the design preview share it.
//   agents: /var/lib/quasar-azp/agents.json { account: { space, owner, role, name, url, pool, environment,
//           project, lan, keep, version } }
//   ctx: { space ("personal" | company id), spaceName, uid, states: { account: "active" | "activating" | … },
//          busy: row key, icons, theme }
//   sites: sites-query state's sites [{ id, name, kind, deployers: [account] }] (your own)
// Keys: "azp:add:build|deploy", "azp:rm:<role>", "azp:lan:<role>", "azp:keep:<role>", "azp:site:<id>".
.pragma library

function accountFor(space, uid, role) {
    var key = space === "personal" ? "u" + uid : space
    return (role === "build" ? "quasar-ci-" : "quasar-dp-") + key
}

function agentFor(agents, ctx, role) {
    return (agents || {})[accountFor(ctx.space, ctx.uid, role)] || null
}

function count(agents, space, uid) {
    return ["build", "deploy"].filter(function (r) { return !!(agents || {})[accountFor(space, uid, r)] }).length
}

function stateWords(s) {
    return s === "active" ? "Online, waiting for jobs" : s === "activating" ? "Starting…"
         : s === "failed" ? "Stopped after an error (see its log)" : s ? "Offline" : "…"
}

function where(a) {
    return a.url.replace(/^https:\/\//, "") + "  ·  " + (a.role === "build" ? "pool " + a.pool : a.project + " › " + a.environment)
}

function agentRows(a, role, ctx) {
    var icons = ctx.icons, t = ctx.theme, acct = accountFor(ctx.space, ctx.uid, role)
    var title = role === "build" ? "Build agent" : "Deploy agent"
    if (!a) return [{ key: "azp:add:" + role, label: role === "build" ? "Add a build agent…" : "Add a deploy agent…",
                      glyph: role === "build" ? icons.code : icons.server, trailing: "chevron", busy: ctx.busy === "azp:add:" + role,
                      sub: role === "build" ? "Runs this space's pipeline jobs on this PC: builds, tests, scheduled work"
                                            : "Receives deployments for an environment (with its approvals), e.g. into Sites" }]
    var st = (ctx.states || {})[acct] || ""
    return [
        { key: "azp:info:" + role, label: title + ": " + a.name, glyph: role === "build" ? icons.code : icons.server,
          trailing: "value", value: st === "active" ? "Online" : st === "failed" ? "Error" : "Offline",
          valueColor: st === "active" ? t.mint : st === "failed" ? t.danger : "", sub: where(a) + "  ·  " + stateWords(st) },
        { key: "azp:lan:" + role, label: "Can reach your home network", glyph: icons.wifi, trailing: "toggle", checked: !!a.lan,
          busy: ctx.busy === "azp:lan:" + role,
          sub: a.lan ? "Jobs can reach devices at home (never this PC's own services)" : "Off: jobs reach the internet only" },
        { key: "azp:keep:" + role, label: "Keep tools and caches between jobs", glyph: icons.layers, trailing: "toggle",
          checked: !!a.keep, busy: ctx.busy === "azp:keep:" + role,
          sub: a.keep ? "Faster builds, but one job can leave files for the next" : "Off: every job starts from a clean slate" },
        { key: "azp:rm:" + role, label: "Remove the " + title.toLowerCase(), glyph: icons.trash, trailing: "button", value: "Remove…",
          busy: ctx.busy === "azp:rm:" + role, sub: "Stops it and deletes its account and files from this PC" }
    ]
}

// The spaces whose deploy agents a site allows, from its deployers (accounts quasar-dp-<space>).
function spacesOf(deployers, uid) {
    return (deployers || []).map(function (a) {
        var k = a.replace(/^quasar-dp-/, "")
        return k === "u" + uid ? "personal" : /^u\d+$/.test(k) ? null : k
    }).filter(function (s) { return s })
}

function siteRows(sites, ctx) {
    var icons = ctx.icons, me = accountFor(ctx.space, ctx.uid, "deploy")
    var list = sites || []
    if (!list.length) return [{ key: "azp:nosites", label: "No sites yet", glyph: icons.globe, trailing: "value", value: "",
                                sub: "Make one in the Sites app; then allow this agent to deploy it here" }]
    return list.map(function (s) {
        var on = (s.deployers || []).indexOf(me) >= 0
        return { key: "azp:site:" + s.id, label: "May deploy " + (s.name || s.id), glyph: icons.globe, trailing: "toggle",
                 checked: on, busy: ctx.busy === "azp:site:" + s.id,
                 sub: on ? "Its pipeline's deployment jobs can hand Sites new versions of " + (s.name || s.id)
                         : "Off: this agent can't change " + (s.name || s.id) }
    })
}

function groups(agents, ctx) {
    var icons = ctx.icons
    var b = agentFor(agents, ctx, "build"), d = agentFor(agents, ctx, "deploy")
    var deployRows = agentRows(d, "deploy", ctx)
    return [
        { label: "Build agent", rows: agentRows(b, "build", ctx) },
        { label: "Deploy agent", rows: deployRows }].concat(d ? [{ label: "Sites the deploy agent may change", rows: siteRows(ctx.sites, ctx) }] : [], [
        { label: "Keep pipelines safe", rows: [
            { key: "azp:tip:prs", label: "Pull requests on Microsoft-hosted agents", glyph: icons.shield, trailing: "value", value: "",
              sub: "Jobs here share the agent's account: run only your own trusted pipelines on this PC" },
            { key: "azp:tip:pool", label: "Grant the pool and environment to named pipelines", glyph: icons.lock, trailing: "value", value: "",
              sub: "In Azure DevOps, turn off \"Grant access permission to all pipelines\"" },
            { key: "azp:tip:env", label: "Approvals and branch control on the environment", glyph: icons.check || icons.shield, trailing: "value", value: "",
              sub: "Only reviewed code from your main branch reaches the deploy agent" },
            { key: "azp:tip:update", label: "Agent updates come with Quasar", glyph: icons.refresh, trailing: "value", value: "",
              sub: "Turn off \"Allow agents in this pool to automatically update\" in the pool's settings" }] }
    ])
}

function hero(agents, ctx) {
    var n = count(agents, ctx.space, ctx.uid)
    return { glyph: ctx.icons.server, iconFg: n ? ctx.theme.accentInk : ctx.theme.text3, iconBg: n ? ctx.theme.accent : ctx.theme.white(0.07),
             title: n ? ctx.spaceName + " runs " + (n === 1 ? "1 agent" : n + " agents") + " here" : "Azure DevOps for " + ctx.spaceName,
             sub: "Each agent is its own locked account: jobs never see " + ctx.spaceName + "'s keys or files, and reach the "
                  + "internet only. Nothing listens for connections: agents call Azure DevOps." }
}
