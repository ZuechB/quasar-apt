//@ pragma AppId quasar-terminal
// Quasar Terminal — shells in tabs, one process for all windows (launched by /usr/bin/quasar-terminal).
//   quasar-terminal [--window] [--cwd DIR] [-e COMMAND [ARGS…]]
// A running Terminal opens each request as a new tab in its most recent window (--window: a new
// window). The engine is the native Quasar.Native Terminal item; the launcher falls back to foot
// when it isn't installed. Settings: "terminal" in ~/.config/quasar/settings.json.
import QtQuick
import Quickshell
import Quickshell.Io
import Quasar
import Quasar.Services
import "services"

ShellRoot {
    id: app

    Binding { target: Theme; property: "accent"; value: Settings.accent }
    Binding { target: Theme; property: "reduceMotion"; value: Settings.reduceMotion }
    Binding { target: Theme; property: "softwareRender"; value: Platform.softwareScene }
    Binding { target: Theme; property: "profile"; value: Platform.softwareRender ? 0 : (Settings.profile >= 0 ? Settings.profile : 1) }

    // ---- settings -----------------------------------------------------------------------------------
    readonly property var defaults: ({ fontSize: 12.5, lineHeight: 1.6, cursorStyle: 0, cursorBlink: false,
                                       scrollback: 10000, ignoreCase: true, confirmClose: true, confirmPaste: true })
    readonly property var cfg: Object.assign({}, defaults, Settings.terminal || {})
    function setting(key, value) {
        const t = Object.assign({}, Settings.terminal || {})
        t[key] = value
        Settings.terminal = t
    }

    // The engine is created per tab from this component (TerminalPane), so the window code stays
    // previewable without the native plugin.
    readonly property Component engine: Qt.createComponent(Qt.resolvedUrl("components/NativeTerminal.qml"))
    // No usable engine (plugin missing, or built for another Qt): every request goes to foot instead
    // of a window that can't run a shell — however the app was started (quasar-app, an old link…).
    readonly property bool engineOk: engine.status === Component.Ready
    function openInFoot(r) {
        const home = Quickshell.env("HOME") || ""
        const dir = (r.cwd || "").replace(/^~(?=\/|$)/, home)
        let cmd = ["foot"]
        if (dir !== "") cmd.push("--working-directory=" + dir)
        if (r.program !== "") cmd = cmd.concat([r.program], r.args)
        Quickshell.execDetached(cmd)
    }

    // ---- windows ------------------------------------------------------------------------------------
    ListModel { id: windows }
    property int nextId: 1
    property var requests: ({})
    property QtObject lastWindow: null

    function openWindow(req) {
        const id = nextId++
        requests[id] = req || {}
        windows.append({ wid: id })
    }
    function closeWindow(id) {
        for (let i = 0; i < windows.count; ++i)
            if (windows.get(i).wid === id) { windows.remove(i); break }
        delete requests[id]
        if (windows.count === 0) Qt.quit()
    }

    Instantiator {
        model: windows
        delegate: TerminalWindow {
            required property int wid
            windowId: wid
            request: app.requests[wid] || ({})
            cfg: app.cfg
            engine: app.engine
            onFocusedChanged: if (focused) app.lastWindow = this
            onCloseWindow: (id) => app.closeWindow(id)
            onNewWindow: (req) => app.openWindow(req)
            onSettingChanged: (key, value) => app.setting(key, value)
            Component.onCompleted: app.lastWindow = this
        }
    }

    // ---- requests: the launcher's arguments, joined by \x1f so they survive the IPC string ----------
    function parse(s) {
        const parts = s.indexOf("\x1f") >= 0 ? s.split("\x1f") : (s.trim() !== "" ? s.trim().split(/\s+/) : [])
        const r = { window: false, cwd: "", program: "", args: [] }
        for (let i = 0; i < parts.length; ++i) {
            const a = parts[i]
            if (a === "--window" || a === "--new-window") r.window = true
            else if (a === "--cwd" || a === "--working-directory" || a === "-D") r.cwd = parts[++i] || ""
            else if (a.startsWith("--cwd=")) r.cwd = a.slice(6)
            else if (a.startsWith("--working-directory=")) r.cwd = a.slice(20)
            else if (a === "-e" || a === "-x" || a === "--") {
                r.program = parts[i + 1] || ""
                r.args = parts.slice(i + 2)
                break
            }
        }
        // `-e "cmd with args"` as one word (some launchers do that): run it through sh.
        if (r.program.indexOf(" ") >= 0 && r.args.length === 0) {
            r.args = ["-c", r.program]
            r.program = "/bin/sh"
        }
        return r
    }
    function handle(s) {
        const r = parse(s || "")
        if (!engineOk) {
            console.warn("Quasar.Native unavailable, using foot:", engine.errorString())
            openInFoot(r)
            if (windows.count === 0) quitSoon.start()
            return
        }
        const w = app.lastWindow
        if (r.window || !w) {
            openWindow(r)
        } else {
            w.addTab(r)
            w.visible = true
            if (w.minimized) w.minimized = false
        }
    }

    // Qt.quit() while the config is still loading is ignored; quit once it has.
    Timer { id: quitSoon; interval: 300; onTriggered: Qt.quit() }

    IpcHandler {
        target: "app"
        function open(arg: string): void { app.handle(arg) }
    }

    Component.onCompleted: handle(Quickshell.env("QUASAR_APP_ARGS") || "")
}
