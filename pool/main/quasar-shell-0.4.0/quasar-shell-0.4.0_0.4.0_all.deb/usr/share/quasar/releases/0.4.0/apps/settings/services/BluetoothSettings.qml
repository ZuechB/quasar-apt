import QtQuick
import Quickshell
import Quickshell.Io
import Quickshell.Bluetooth
import Quasar

// Settings › Bluetooth: BlueZ through Quickshell.Bluetooth (live; nothing polled).
// Gives the pure BluetoothList keyed ScriptModels, so a battery level or a connection changes a row in
// place instead of rebuilding the page. Pairing goes through the shell's agent (PairDialog asks the
// questions; BlueZ keeps no pairing keys without an agent), so pair() first checks it's running.
Scope {
    id: root
    property bool active: false             // the Bluetooth page is visible
    signal notify(var banner)

    readonly property var adapter: Bluetooth.defaultAdapter
    readonly property bool present: adapter !== null
    readonly property bool powered: !!adapter && adapter.enabled
    readonly property bool blocked: !!adapter && adapter.state === BluetoothAdapterState.Blocked
    property bool hardBlocked: false        // the rfkill block is a hardware switch / key
    property bool wantOn: false             // turn on once the rfkill block is gone

    property bool adding: false             // "Add a device" is open: discovering, and visible to phones
    property string pairingPath: ""         // device being paired from here
    property string busyPath: ""            // device connecting/disconnecting from here
    property bool agentReady: false

    readonly property var pairingDevice: find(pairingPath)
    function find(path) { return path ? Bluetooth.devices.values.find(d => d && d.dbusPath === path) || null : null }

    function row(d) {
        const k = BtDevices.kind(d.icon)
        const b = d.batteryAvailable ? (d.battery > 1 ? d.battery : d.battery * 100) : -1
        return { key: d.dbusPath, name: d.name || d.deviceName || d.address, kind: k.label, glyph: k.glyph,
                 connected: d.connected, paired: d.paired, battery: Math.round(b),
                 busy: d.pairing || d.dbusPath === busyPath || d.dbusPath === pairingPath
                       || d.state === BluetoothDeviceState.Connecting || d.state === BluetoothDeviceState.Disconnecting }
    }
    readonly property var devices: Bluetooth.devices.values.filter(d => d && (!adapter || d.adapter === adapter))
    ScriptModel {
        id: pairedRows
        objectProp: "key"
        values: root.devices.filter(d => d.paired).map(d => root.row(d))
    }
    // Devices found while adding. Nameless ones (BlueZ shows their address, "AA-BB-…") are mostly beacons.
    function named(d) { const n = d.name || d.deviceName; return !!n && !/^([0-9A-F]{2}[-:]){5}[0-9A-F]{2}$/i.test(n) }
    ScriptModel {
        id: nearbyRows
        objectProp: "key"
        values: root.adding ? root.devices.filter(d => !d.paired && root.named(d)).map(d => root.row(d)) : []
    }
    readonly property var pairedModel: pairedRows
    readonly property var nearbyModel: nearbyRows

    function setPowered(on) {
        if (!adapter) return
        if (on && blocked) {
            wantOn = true
            Quickshell.execDetached(["/usr/sbin/rfkill", "unblock", "bluetooth"])
            stillBlocked.restart()
        } else {
            wantOn = false
            if (!on) stopAdding()
            adapter.enabled = on
        }
    }
    function startAdding() {
        if (!powered) return
        adding = true
        adapter.discoverable = true
        adapter.discovering = true
        addTimeout.restart()
        agentCheck.running = true
    }
    function stopAdding() {
        adding = false
        addTimeout.stop()
        if (adapter) {
            if (adapter.discovering) adapter.discovering = false
            if (adapter.discoverable) adapter.discoverable = false
        }
    }
    function pair(path) {
        const d = find(path)
        if (!d || pairingPath !== "") return
        if (!agentReady) {
            agentCheck.running = true
            notify({ tone: "warning", title: "Bluetooth is getting ready", message: "Try again in a moment." })
            return
        }
        pairingPath = path
        pairWatchdog.restart()
        d.pair()
    }
    function cancelPairing() {
        const d = pairingDevice
        if (d) d.cancelPair()
        pairingPath = ""
        pairWatchdog.stop()
    }
    function connectDevice(path) { const d = find(path); if (d) { busyPath = path; busyTimeout.restart(); d.connect() } }
    function disconnectDevice(path) { const d = find(path); if (d) { busyPath = path; busyTimeout.restart(); d.disconnect() } }
    function forget(path) { const d = find(path); if (d) d.forget() }

    onActiveChanged: if (!active) stopAdding()
    onBlockedChanged: {
        if (blocked) hardCheck.running = true
        else { hardBlocked = false; if (wantOn && adapter) { wantOn = false; adapter.enabled = true } }
    }
    Component.onCompleted: if (blocked) hardCheck.running = true

    // Pairing finishes with `paired`; it failed when `pairing` ends without it (BlueZ or the person said no).
    function pairDone(ok) {
        const d = pairingDevice
        const name = d ? (d.name || d.address) : "the device"
        pairingPath = ""
        pairWatchdog.stop()
        if (ok && d) {
            d.trusted = true            // reconnects on its own from now on (and its services don't ask)
            d.connect()
            notify({ tone: "success", title: "Paired with " + name, message: "" })
        } else {
            notify({ tone: "error", title: "Couldn't pair with " + name,
                     message: "Make sure it's in pairing mode and close to this PC, then try again." })
        }
    }
    Connections {
        target: root.pairingDevice
        ignoreUnknownSignals: true
        function onPairedChanged() { if (root.pairingDevice && root.pairingDevice.paired) root.pairDone(true) }
        function onPairingChanged() { if (root.pairingDevice && !root.pairingDevice.pairing) settle.restart() }
    }
    Timer { id: settle; interval: 1500; onTriggered: if (root.pairingDevice && !root.pairingDevice.paired && !root.pairingDevice.pairing) root.pairDone(false) }
    Timer { id: pairWatchdog; interval: 60000; onTriggered: { root.cancelPairing(); root.pairDone(false) } }
    Timer { id: busyTimeout; interval: 20000; onTriggered: root.busyPath = "" }
    Connections {
        target: root.find(root.busyPath)
        ignoreUnknownSignals: true
        function onStateChanged() {
            const d = root.find(root.busyPath)
            if (d && (d.state === BluetoothDeviceState.Connected || d.state === BluetoothDeviceState.Disconnected)) root.busyPath = ""
        }
    }
    Timer { id: addTimeout; interval: 120000; onTriggered: root.stopAdding() }
    Timer { id: stillBlocked; interval: 1500; onTriggered: if (root.blocked) hardCheck.running = true }

    // The shell's pairing agent (shell/services/BluetoothAgent.qml) answers BlueZ's questions.
    Process {
        id: agentCheck
        command: ["qs", "--path", "/usr/share/quasar/shell", "ipc", "call", "bluetooth", "agentReady"]
        stdout: StdioCollector { onStreamFinished: root.agentReady = text.trim() === "true" }
    }
    // Hardware switch or key? (rfkill: "blocked" in the HARD column)
    Process {
        id: hardCheck
        command: ["/usr/sbin/rfkill", "-n", "-o", "HARD", "list", "bluetooth"]
        stdout: StdioCollector { onStreamFinished: root.hardBlocked = /\bblocked\b/.test(text) }
    }
}
