import QtQuick
import Quickshell
import Quickshell.Io
import Quasar

// Picture thumbnails, kept so a folder of photos isn't decoded again every time it's shown
// ($XDG_CACHE_HOME/quasar/thumbnails, shared by every Files window). A thumbnail is the tile's own
// small image (decoded at 112 px), saved once it has loaded; its name is a hash of the picture's
// path, size and modification time, so a changed picture gets a new one. Which ones exist is read
// once when Files starts (no folder watch, no failed loads); new ones are added as they're saved.
// Thumbnails unused for 90 days are deleted then too. Local only, like everything else.
Scope {
    id: root
    property string home: Quickshell.env("HOME") || "/root"
    readonly property string dir: (Quickshell.env("XDG_CACHE_HOME") || home + "/.cache") + "/quasar/thumbnails"
    property var known: ({})                   // file name -> true
    property bool ready: false
    property var _names: []

    Process {
        command: ["sh", "-c", 'mkdir -p "$1" && find "$1" -maxdepth 1 -type f -atime +90 -delete; ls -1 "$1"', "sh", root.dir]
        running: true
        stdout: SplitParser { onRead: (n) => root._names.push(n) }
        onExited: {
            const k = {}
            root._names.forEach(n => k[n] = true)
            root._names = []
            root.known = k
            root.ready = true
        }
    }
    // The cache file for a FileKit row (photos as JPEG, the rest as PNG, which keeps transparency).
    function key(row) {
        return Qt.md5(row.path + "\n" + row.size + "\n" + row.mtime) + (/\.jpe?g$/i.test(row.name) ? ".jpg" : ".png")
    }
    function has(name) { return ready && known[name] === true }
    function saved(name) { known[name] = true }
}
