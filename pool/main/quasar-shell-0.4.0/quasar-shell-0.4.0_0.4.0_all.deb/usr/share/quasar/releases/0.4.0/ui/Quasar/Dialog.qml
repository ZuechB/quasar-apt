import QtQuick

// In-window modal (confirmations, consent sheets): a dimming scrim over the window and a centred
// card that springs in (template panelIn: rise 24px + scale .94 -> 1, .55s spring). Clicking the
// scrim or pressing Esc emits `dismissed` unless `modal` is set. Place it as the last child of
// the window content so it covers everything.
Item {
    id: root
    property bool open: false
    property bool modal: false
    property string title: ""
    property string message: ""
    property real cardWidth: 440
    default property alias body: bodySlot.data
    property alias buttons: buttonRow.data
    signal dismissed()

    anchors.fill: parent
    visible: open || card.opacity > 0
    z: 1000

    Rectangle {
        anchors.fill: parent
        color: Qt.rgba(0, 0, 0, 0.45)
        // It covers the window's content down to its rounded bottom corners (translucent, so
        // per-corner radii are safe on the software scene graph).
        bottomLeftRadius: Theme.windowCorner(Window.visibility)
        bottomRightRadius: Theme.windowCorner(Window.visibility)
        opacity: root.open ? 1 : 0
        Behavior on opacity { NumberAnimation { duration: Motion.dur(200) } }
        MouseArea {
            anchors.fill: parent
            onClicked: if (!root.modal) root.dismissed()
        }
    }

    Rectangle {
        id: card
        anchors.centerIn: parent
        width: Math.min(root.cardWidth, root.width - 40)
        height: col.implicitHeight + 44
        radius: 20
        color: Theme.solid
        border.width: 1
        border.color: Theme.white(0.1)
        opacity: root.open ? 1 : 0
        scale: root.open ? 1 : 0.94
        transform: Translate { y: root.open ? 0 : 24; Behavior on y { NumberAnimation { duration: Motion.dur(Motion.panel); easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.spring } } }
        Behavior on opacity { NumberAnimation { duration: Motion.dur(220) } }
        Behavior on scale { NumberAnimation { duration: Motion.dur(Motion.panel); easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.spring } }
        Accessible.role: Accessible.Dialog
        Accessible.name: root.title
        focus: root.open
        Keys.onEscapePressed: if (!root.modal) root.dismissed()
        MouseArea { anchors.fill: parent }          // swallow clicks on the card

        Column {
            id: col
            x: 22; y: 22
            width: parent.width - 44
            spacing: 14
            Text {
                width: parent.width
                visible: root.title !== ""
                text: root.title
                textFormat: Text.PlainText
                wrapMode: Text.Wrap
                font.family: Theme.fontDisplay; font.pixelSize: 20; font.weight: Font.Medium
                color: Theme.text
            }
            Text {
                width: parent.width
                visible: root.message !== ""
                text: root.message
                textFormat: Text.PlainText
                wrapMode: Text.Wrap
                lineHeight: 1.15
                font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
                color: Theme.text3
            }
            Item {
                id: bodySlot
                width: parent.width
                height: childrenRect.height
                visible: children.length > 0
            }
            Row {
                id: buttonRow
                anchors.right: parent.right
                spacing: 8
            }
        }
    }
}
