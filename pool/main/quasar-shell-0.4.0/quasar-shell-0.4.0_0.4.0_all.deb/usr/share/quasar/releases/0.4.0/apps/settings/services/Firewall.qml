import QtQuick
import Quickshell
import Quickshell.Io
import Quasar
import Quasar.Services
import "../components/firewall.js" as Fw

// Settings > Network & Internet > Firewall ("Block unknown incoming connections"). Reads the state with
// `quasar-firewall status` (any user) and changes it through `pkexec quasar-firewall …`: on/off, which
// connected network is a home network, the apps and ports allowed on home networks, and whether home
// networks get an answer to ping. A switch never flips ahead of the change: the state is read back
// after every one. /run/quasar/firewall-net.json changes whenever a network comes or goes (written in
// place by root), so the page follows along.
//   QUASAR_FIREWALL=/path: a stand-in for the helper (tools/fake-firewall.py), used for status too
//   QUASAR_FIREWALL_NET=/path: the network file to watch instead
Scope {
    id: root
    property bool active: false              // the Network page or the Firewall page is shown
    property var st: null                    // quasar-firewall status
    property string busy: ""                 // row key of the change in progress
    property var recent: []                  // [{ time, from, port, proto, app, network }] — fed by quasar-netguard
    property var ask: null                   // confirmation: { key, title, message, button, danger }
    property bool portFormOpen: false        // "Allow a port or range" dialog
    property bool recentOpen: false          // "Recently blocked" dialog
    property string vpnFor: ""               // the home network whose "Router VPN" dialog is open ("" = closed)
    readonly property var vpnHome: vpnFor ? Fw.homeFor(st, vpnFor) : null
    signal notify(var banner)                // result banner for the page
    signal pick(string title, var options, string current, var done, string message)   // a ChoiceSheet

    readonly property string exe: Quickshell.env("QUASAR_FIREWALL") || ""
    readonly property string netFile: Quickshell.env("QUASAR_FIREWALL_NET") || "/run/quasar/firewall-net.json"
    function helperCmd(args) { return (exe ? [exe] : ["pkexec", "/usr/libexec/quasar/quasar-firewall"]).concat(args) }

    readonly property var ctx: ({ busy: busy, ask: Settings.firewallAsk !== false, recent: recent, live: Platform.live,
                                  icons: Icons, theme: Theme })
    readonly property var networkRows: Fw.networkRows(st, ctx)
    readonly property var groups: Fw.groups(st, ctx)
    readonly property var hero: Fw.hero(st, ctx)

    onActiveChanged: if (active) refresh()

    // ---- reading ---------------------------------------------------------------------------------
    property bool _again: false
    function refresh() {
        if (statusProc.running) { _again = true; return }
        statusProc.running = true
    }
    Process {
        id: statusProc
        command: [root.exe || "/usr/libexec/quasar/quasar-firewall", "status"]
        stdout: StdioCollector {
            onStreamFinished: {
                try { root.st = JSON.parse(text) } catch (e) { }
            }
        }
        onExited: (code, status) => { if (root._again) { root._again = false; running = true } }
    }
    FileView {
        path: root.netFile
        watchChanges: true
        printErrors: false
        onFileChanged: { reload(); if (root.active) root.refresh() }
    }

    // ---- changing ----------------------------------------------------------------------------------
    function toggle(key) { activate(key) }
    function activate(key) {
        // Your own choice and the read-only list never wait for a running change.
        if (key === "fw:ask") { Settings.firewallAsk = !(Settings.firewallAsk !== false); return }
        if (key === "fw:recent") { recentOpen = true; return }
        // A server open to the internet is Services' to change: open it there.
        if (key.startsWith("fw:wan:")) { Quickshell.execDetached(["quasar-services", "svc/" + key.slice(7).replace(/^svc:/, "")]); return }
        if (busy !== "" || !st)
            return
        if (key === "fw") {
            if (isOn()) ask = Fw.confirmOff()
            else run("fw", ["on"])
        } else if (key.startsWith("fw:home:")) {
            const c = Fw.connectionFor(st, key.slice(8))
            if (c) run(key, ["home", c.state === "home" ? "off" : "on", c.uuid])
        } else if (key.startsWith("fw:repin:")) {
            run(key, ["home", "on", key.slice(9)])
        } else if (key.startsWith("fw:forget:")) {
            const h = Fw.homeFor(st, key.slice(10))
            if (h) ask = Fw.confirmForget(h)
        } else if (key.startsWith("fw:rm:")) {
            const e = Fw.entryFor(st, key.slice(6))
            if (e && !e.by) run(key, ["unallow", e.id], undefined, () => root.notify({ tone: "success", title: e.name + " is no longer allowed",
                                                                                        message: "Devices on your home networks can't connect to it any more." }))
        } else if (key === "fw:allowApp") {
            pick("Allow an app", appChoices(), "", (id) => root.allowApp(id), Fw.allowAppMessage(st))
        } else if (key === "fw:port") {
            portFormOpen = true
        } else if (key.startsWith("fw:vpn:")) {
            vpnFor = key.slice(7)
        } else if (key === "fw:ping") {
            run(key, ["option", "ping", st.ping === false ? "on" : "off"])
        }
    }
    function isOn() { return Fw.isOn(st) }

    // The dialogs (Settings' shell.qml) call these.
    function confirm() {
        const a = ask
        ask = null
        if (!a) return
        if (a.key === "fw:off") run("fw", ["off"])
        else if (a.key.startsWith("fw:forget:")) run(a.key, ["home", "off", a.key.slice(10)])
    }
    // spec: FirewallPortForm's, with `home` = the networks it makes home in the same step (one password).
    function submitPort(spec) {
        portFormOpen = false
        const before = st
        run("fw:port", ["allow"], JSON.stringify(spec) + "\n", () => root.notify(Fw.allowedNotice(before, spec.name, spec.home)))
    }
    // Remote desktop's "From outside your home" opens the Router VPN dialog of the home network you're on.
    function openVpn(uuid) {
        if (!uuid) return
        refresh()
        vpnFor = uuid
    }
    function submitVpn(ranges) {
        const uuid = vpnFor, h = vpnHome
        vpnFor = ""
        if (!uuid) return
        run("fw:vpn:" + uuid, ["home", "vpn", uuid], JSON.stringify({ vpn: ranges }) + "\n", () => root.notify(ranges.length
            ? { tone: "success", title: "Devices on " + (h ? h.name : "this network") + "'s router VPN count as home devices",
                message: "Connect to the VPN, then reach this PC as if you were home." }
            : { tone: "success", title: "The router VPN is no longer trusted", message: "Only devices on the network itself count as home." }))
    }

    // Installed apps for "Allow an app" (Quasar's own apps never wait for connections).
    function appChoices() {
        const seen = {}, out = []
        for (const e of DesktopEntries.applications.values) {
            if (!e || !e.id || e.id.startsWith("quasar-") || seen[e.id]) continue
            seen[e.id] = true
            out.push({ key: e.id, label: e.name || e.id, sub: e.genericName || "" })
        }
        return out.sort((a, b) => a.label.localeCompare(b.label))
    }
    // Like the connection prompt, allowing an app makes the networks you're on home networks (the sheet says so
    // first): what's allowed answers nothing on a public one. Never one whose router changed.
    function allowApp(id) {
        const e = DesktopEntries.byId(id)
        const name = (e && e.name) || id
        const spec = { app: id, name: name }
        const home = Fw.homeOffers(st).filter(o => o.suggested).map(o => o.uuid)
        if (home.length) spec.home = home
        const before = st
        run("fw:allowApp", ["allow"], JSON.stringify(spec) + "\n", () => root.notify(Fw.allowedNotice(before, name, home)))
    }

    // One change at a time, through pkexec. Closing the password sheet (126) says nothing.
    property var _done: null
    function run(key, args, input, done) {
        busy = key
        _done = done || null
        job.run(helperCmd(args), undefined, input)
    }
    Cmd {
        id: job
        onFinished: (code) => {
            const done = root._done
            root._done = null
            root.busy = ""
            if (code === 0) {
                if (done) done()
            } else if (code !== 126) {
                const err = job.details().split("\n").filter(l => l.startsWith("ERROR ")).map(l => l.slice(6)).pop()
                root.notify(code === 127
                    ? { tone: "error", title: "Your account isn't allowed to change the firewall", message: "Ask an administrator." }
                    : { tone: "error", title: err || "That didn't work", message: err ? "" : "Nothing was changed.", details: job.details() })
            }
            root.refresh()
        }
    }
}
