import QtQuick
import Quickshell
import Quasar.Services
import "../components/tm.js" as TM

// Ending tasks, the way TM.endPlan says:
//   restart / safe   the Quasar desktop: /usr/libexec/quasar/shell-rescue restart | safe (apps stay open)
//   signout          the desktop session: loginctl terminate-session
//   unit / pid       yours: sysmon end --unit … (SIGTERM, then SIGKILL after 5 s) | --pid P --start T
//   company          inside a company you own: quasar-company exec ID -- sysmon end … (its agent checks you)
//   admin            the system's or another account's: pkexec quasar-proc-admin, one JSON line on stdin
//                    (org.quasar.proc.admin: an administrator's password every time)
// done(banner) after each (null: nothing to say; the row just goes away).
//   QUASAR_SYSMON, QUASAR_SHELL_RESCUE: other helpers (tests).
Item {
    id: root
    visible: false
    signal done(var banner)
    property bool busy: false
    property string name: ""
    readonly property string sysmon: Quickshell.env("QUASAR_SYSMON") || "/usr/libexec/quasar/sysmon"
    readonly property string rescue: Quickshell.env("QUASAR_SHELL_RESCUE") || "/usr/libexec/quasar/shell-rescue"

    function units(g) { return [].concat(...(g.units || []).map(u => ["--unit", u])) }

    function end(row, plan) {
        if (busy || !row || !plan) return
        const g = row.group || {}, p = row.proc
        name = row.label
        if (plan.how === "restart") { restartDesktop(); return }
        if (plan.how === "signout") {
            Quickshell.execDetached(["loginctl", "terminate-session", Quickshell.env("XDG_SESSION_ID") || "self"])
            return
        }
        busy = true
        if (plan.how === "unit") job.run([sysmon, "end"].concat(units(g)))
        else if (plan.how === "pid") job.run([sysmon, "end", "--pid", String(p.pid), "--start", String(p.start)])
        else if (plan.how === "company")
            job.run(["quasar-company", "exec", g.company, "--", sysmon, "end"]
                    .concat(p ? ["--pid", String(p.pid), "--start", String(p.start)] : units(g)))
        else if (plan.how === "admin")
            admin.runHelper([], JSON.stringify(p ? { op: "end", pid: p.pid, start: p.start, signal: "TERM" }
                                                 : { op: "stop", unit: (g.units || [])[0] || "" }))
        else busy = false
    }
    function restartDesktop() {
        Quickshell.execDetached([rescue, "restart"])
        done({ tone: "success", title: "The desktop is starting again", message: "Your apps stay open." })
    }
    function safeGraphics() {
        Quickshell.execDetached([rescue, "safe"])
        done({ tone: "info", title: "The desktop restarts on safe graphics",
               message: "It draws in software until you sign out. Settings › Drivers & Hardware can keep it that way." })
    }

    Cmd {
        id: job
        onFinished: (code) => { root.busy = false; root.done(TM.endResult(root.name, code, lastLine)) }
    }
    Privileged {
        id: admin
        helper: "quasar-proc-admin"
        onFinished: (code) => { root.busy = false; root.done(TM.endResult(root.name, code, lastLine)) }
    }
}
