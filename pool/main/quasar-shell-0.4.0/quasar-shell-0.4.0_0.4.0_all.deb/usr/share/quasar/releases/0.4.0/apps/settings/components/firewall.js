// Settings > Network & Internet > Firewall: rows built from `quasar-firewall status`
// (linux/system/libexec/quasar-firewall). Pure, so the Settings app (services/Firewall.qml) and the
// design preview share it.
//   st:  { available, enabled, active, ping, homeNetworks: [{ uuid, name, router, vpn: ["192.168.3.0/24"] }],
//          allowed: [{ id, name, app | tcp, udp, by, internet: { tcp, udp } }],   (internet: Services' servers)
//          connections: [{ uuid, name, type: "wifi" | "ethernet", device, home,
//                          state: "home" | "public" | "routerChanged" | "checking" }] }   (null while loading)
//   ctx: { busy: row key of the change in progress, ask: Settings.firewallAsk,
//          recent: [{ time, from, port, proto, app, network }], icons, theme }
// Everyone should understand every line: say what a choice does, in plain words. The everyday flow is
// the prompt ("LocalSend wants to receive connections"); this page is for looking things over and
// undoing them, with the expert controls in the last group.
.pragma library

function plural(n, one, many) { return n + " " + (n === 1 ? one : many) }

function isOn(st) { return !!st && !!st.active }

function connections(st) { return (st && st.connections) || [] }

// "TCP 3000, 8000-8010  ·  UDP 53317"
function portsText(e) {
    var parts = []
    if (e.tcp) parts.push("TCP " + e.tcp)
    if (e.udp) parts.push("UDP " + e.udp)
    return parts.join("  ·  ")
}

function byName(by) {
    return ({ sites: "Sites", commanddeck: "Command Deck", services: "Services", ssh: "Remote sign-in",
              vnc: "Remote desktop" })[by]
        || (String(by).charAt(0).toUpperCase() + String(by).slice(1))
}

// "3000, 8000-8010" -> [[3000, 3000], [8000, 8010]]
function ranges(spec) {
    return String(spec || "").split(",").map(function (x) { return x.trim() }).filter(function (x) { return x })
        .map(function (x) { var m = /^(\d+)(?:\s*-\s*(\d+))?$/.exec(x); return m ? [+m[1], m[2] ? +m[2] : +m[1]] : null })
        .filter(function (r) { return r })
}

// The ports of `spec` that aren't in `minus`, in the same "a, b-c" form.
function portsMinus(spec, minus) {
    var out = [], cut = ranges(minus)
    ranges(spec).forEach(function (r) {
        var pieces = [r]
        cut.forEach(function (c) {
            var next = []
            pieces.forEach(function (p) {
                if (c[1] < p[0] || c[0] > p[1]) { next.push(p); return }
                if (c[0] > p[0]) next.push([p[0], c[0] - 1])
                if (c[1] < p[1]) next.push([c[1] + 1, p[1]])
            })
            pieces = next
        })
        out = out.concat(pieces)
    })
    return out.map(function (p) { return p[0] === p[1] ? String(p[0]) : p[0] + "-" + p[1] }).join(", ")
}

function isInternet(e) { return !!e && !!e.internet && !!(e.internet.tcp || e.internet.udp) }

// A server Services opened to the internet (its group says so): "UDP 7770  ·  Home networks only: UDP 47770"
function internetText(e) {
    var home = { tcp: portsMinus(e.tcp, e.internet.tcp), udp: portsMinus(e.udp, e.internet.udp) }
    var homeText = portsText(home)
    return portsText(e.internet) + (homeText ? "  ·  Home networks only: " + homeText : "")
}

// What's allowed, in a few words: "2 apps and 1 port allowed", "… · 1 server open to the internet".
function allowedText(st) {
    var all = (st && st.allowed) || []
    var wan = all.filter(isInternet).length
    var a = all.filter(function (e) { return !isInternet(e) })
    var apps = a.filter(function (e) { return !!e.app }).length, ports = a.length - apps
    var text = !apps && !ports ? (wan ? "" : "Nothing allowed yet")
        : apps && ports ? plural(apps, "app", "apps") + " and " + plural(ports, "port", "ports") + " allowed"
        : (apps ? plural(apps, "app", "apps") : plural(ports, "port", "ports")) + " allowed"
    var open = wan ? plural(wan, "server", "servers") + " open to the internet" : ""
    return [text, open].filter(function (x) { return x }).join("  ·  ")
}

// "Studio", "Studio and Wired connection 1", "A, B and C"
function names(list) {
    return list.length < 2 ? (list[0] || "") : list.slice(0, -1).join(", ") + " and " + list[list.length - 1]
}

// Connected networks that aren't home networks right now. What's allowed answers devices on home networks
// only, so Allow (a port, an app) can make them home in the same step, as the connection prompt does.
// `suggested`: what Allow does unless the person says otherwise. A public network, or a saved home network
// whose router didn't answer just now, becomes home; one whose router changed stays a deliberate choice
// ("Wired connection 1" matches any cable, and an open café network can share a saved name).
//   -> [{ uuid, name, why: "public" | "checking" | "routerChanged", suggested }]
function homeOffers(st) {
    return connections(st).filter(function (c) { return !!c.uuid && c.state !== "home" }).map(function (c) {
        var why = c.state === "routerChanged" || c.state === "checking" ? c.state : "public"
        return { uuid: c.uuid, name: c.name || "This network", why: why, suggested: why !== "routerChanged" }
    })
}

// "Allow a port or range": the words beside one network's switch.
function homeOfferText(o) {
    if (o.why === "routerChanged")
        return { label: "Keep " + o.name + " as a home network",
                 sub: "Its router changed, so Quasar treats it as public. Turn this on only if you're at home." }
    if (o.why === "checking")
        return { label: "Keep " + o.name + " as a home network",
                 sub: "Quasar couldn't check its router just now, so it counts as public until then." }
    return { label: "Make " + o.name + " a home network",
             sub: "It's public now, so nothing on it can reach this port." }
}

// "Allow an app": the sheet's words. It makes the offered networks home without asking again (the prompt's way).
function allowAppMessage(st) {
    var text = "Your phone and other devices on home networks can connect to the app you pick. Public networks stay closed."
    var made = homeOffers(st).filter(function (o) { return o.suggested }).map(function (o) { return o.name })
    if (!made.length) return text
    return text + " " + names(made) + (made.length === 1 ? " isn't a home network right now: allowing an app makes it one."
                                                         : " aren't home networks right now: allowing an app makes them home networks.")
}

// The banner after allowing something. homes: the networks that Allow just made home.
function allowedNotice(st, name, homes) {
    var made = {}
    ;(homes || []).forEach(function (u) { made[u] = true })
    var left = homeOffers(st).filter(function (o) { return !made[o.uuid] })
    if (left.length) {
        var o = left[0]
        return { tone: "info", title: name + " is allowed on home networks",
                 message: o.why === "routerChanged"
                     ? o.name + "'s router changed, so Quasar treats it as public and devices on it can't connect yet. "
                       + "If you're at home, choose It's still home."
                     : o.name + " isn't one of your home networks, so devices on it can't connect yet. Make it a home network if it's yours." }
    }
    var here = connections(st).map(function (c) { return c.name })
    return { tone: "success", title: name + " is allowed",
             message: here.length ? "Devices on " + names(here) + " can connect to it now."
                                  : "Devices on your home networks can connect to it." }
}

function connectionText(c) {
    if (!c) return ""
    if (c.state === "home") return c.name + " is a home network"
    if (c.state === "routerChanged") return c.name + "'s router changed"
    if (c.state === "checking") return "Checking " + c.name
    return c.name + " is public"
}

// Network & Internet › More connections: the design's Firewall switch, and the way into its page.
function networkRows(st, ctx) {
    var icons = ctx.icons
    if (!st)
        return [{ key: "fw", label: "Firewall", sub: "Checking…", glyph: icons.shield, trailing: "value", value: "" }]
    if (!st.available)
        return [{ key: "fw", label: "Firewall", sub: "Not part of this copy of Quasar", glyph: icons.shield, trailing: "value", value: "" }]
    var failed = st.enabled && !st.active
    return [
        { key: "fw", label: "Firewall", glyph: icons.shield, trailing: "toggle", checked: isOn(st), busy: ctx.busy === "fw",
          sub: isOn(st) ? "Block unknown incoming connections"
             : failed ? "It didn't start, so nothing is blocked. Turn it on to try again."
             : "Off: apps that listen can be reached by anyone on this network" },
        { key: "fw:open", label: "Firewall settings", glyph: icons.sliders, trailing: "chevron", value: "",
          sub: [allowedText(st), connectionText(connections(st)[0])].filter(function (x) { return x }).join("  ·  ") }
    ]
}

function hero(st, ctx) {
    var icons = ctx.icons, t = ctx.theme, busy = ctx.busy === "fw"
    if (!st)
        return { glyph: icons.shield, title: "Firewall", sub: "Checking…" }
    if (!st.available)
        return { glyph: icons.shield, title: "The firewall isn't available",
                 sub: "This copy of Quasar doesn't include it. Update Quasar to get it." }
    if (isOn(st))
        return { glyph: icons.shield, title: "Firewall is on", toggle: true, checked: true, busy: busy,
                 iconBg: t.accent, iconFg: t.accentInk,
                 sub: "Other devices can't connect to this PC unless you allow them. Your apps reach the internet as usual." }
    if (st.enabled)
        return { glyph: icons.shield, title: "The firewall didn't start", toggle: true, checked: false, busy: busy, iconFg: t.amber,
                 sub: "Its rules didn't load, so nothing is blocked right now. Turn it on to try again." }
    return { glyph: icons.shield, title: "Firewall is off", toggle: true, checked: false, busy: busy, iconFg: t.amber,
             sub: "Any app that waits for connections can be reached by everyone on the networks you join, public Wi-Fi included." }
}

// "This network": is the connected network one of your home networks?
function homeRow(c, ctx) {
    var icons = ctx.icons, glyph = c.type === "wifi" ? icons.wifi : icons.ethernet
    var key = "fw:home:" + c.uuid
    if (c.state === "routerChanged")
        return { key: "fw:repin:" + c.uuid, label: "Home network", glyph: glyph, trailing: "button", value: "It's still home",
                 busy: ctx.busy === "fw:repin:" + c.uuid,
                 sub: c.name + " has a different router now, so Quasar treats it as public. Is it still your home network?" }
    if (c.state === "checking")
        return { key: key, label: "Home network", glyph: glyph, trailing: "value", value: "Checking…",
                 sub: c.name + "  ·  Quasar is checking its router" }
    var home = c.state === "home"
    return { key: key, label: "Home network", glyph: glyph, trailing: "toggle", checked: home, busy: ctx.busy === key,
             sub: home ? c.name + "  ·  Your other devices here can reach the apps you allow"
                       : c.name + "  ·  Public: nothing on this network can connect to this PC. Turn on if it's your home." }
}

// Servers Services opened to the internet: shown on their own, managed there (an administrator's password).
function internetRows(st, ctx) {
    var icons = ctx.icons, t = ctx.theme
    return ((st && st.allowed) || []).filter(isInternet).map(function (e) {
        return { key: "fw:wan:" + e.id, label: e.name, glyph: icons.globe, sub: internetText(e),
                 trailing: "value", value: "Managed by " + byName(e.by || "services"), valueColor: t.textMuted }
    })
}

// While the firewall is on, what's allowed answers nothing on a connected network that isn't home: say so
// above the list, with the way to fix it (the same keys as This network's rows).
function notAnsweringRows(st, ctx) {
    if (!isOn(st))
        return []
    return homeOffers(st).map(function (o) {
        var k = (o.why === "public" ? "fw:home:" : "fw:repin:") + o.uuid
        return { key: k, label: "Not answering on " + o.name, glyph: ctx.icons.alert, busy: ctx.busy === k, trailing: "button",
                 value: o.why === "public" ? "Make it home" : o.why === "routerChanged" ? "It's still home" : "Check again",
                 sub: o.why === "public" ? o.name + " is public, so devices on it can't reach what you allowed. Make it a home network if it's yours."
                    : o.why === "routerChanged" ? o.name + "'s router changed, so Quasar treats it as public. Is it still your home network?"
                    : "Quasar couldn't check " + o.name + "'s router, so it counts as public for now." }
    })
}

function allowedRows(st, ctx) {
    var icons = ctx.icons, t = ctx.theme
    var rows = ((st && st.allowed) || []).filter(function (e) { return !isInternet(e) }).map(function (e) {
        var k = "fw:rm:" + e.id
        var r = { key: k, label: e.name, glyph: e.app ? icons.grid : icons.server, busy: ctx.busy === k,
                  sub: e.app ? "Any port it opens" : portsText(e) }
        if (e.by) { r.trailing = "value"; r.value = "Managed by " + byName(e.by); r.valueColor = t.textMuted }
        else { r.trailing = "button"; r.value = "Remove" }
        return r
    })
    if (!rows.length)
        rows.push({ label: "No apps allowed yet", glyph: icons.info, trailing: "none",
                    sub: "Quasar asks you when an app needs connections from your other devices, like a phone sending files" })
    else
        rows = notAnsweringRows(st, ctx).concat(rows)
    rows.push({ key: "fw:allowApp", label: "Allow an app", glyph: icons.plus, trailing: "button", value: "Choose…",
                busy: ctx.busy === "fw:allowApp",
                sub: "For apps like LocalSend or Steam, so your phone or another PC at home can connect to them" })
    return rows
}

function advancedRows(st, ctx) {
    var icons = ctx.icons, rows = []
    rows.push({ key: "fw:port", label: "Allow a port or range", glyph: icons.server, trailing: "button", value: "Add…",
                busy: ctx.busy === "fw:port",
                sub: "For a server or game that isn't in the app list. Only devices on home networks can reach it." })
    rows.push({ key: "fw:ask", label: "Ask when an app is blocked", glyph: icons.bell, trailing: "toggle", checked: !!ctx.ask,
                sub: "Shows a prompt when an app on this PC waits for a connection the firewall stopped" })
    rows.push({ key: "fw:ping", label: "Answer ping on home networks", glyph: icons.activity, trailing: "toggle",
                checked: !st || st.ping !== false, busy: ctx.busy === "fw:ping",
                sub: "Lets devices at home check that this PC is there. Public networks never get an answer." })
    var n = (ctx.recent || []).length
    rows.push({ key: "fw:recent", label: "Recently blocked", glyph: icons.clock, trailing: "chevron", value: n ? String(n) : "",
                sub: "Connections the firewall stopped since this PC started" })
    // Saved home networks (also the ones not connected now): forget one to make it public again.
    var homes = (st && st.homeNetworks) || []
    var now = {}
    connections(st).forEach(function (c) { now[c.uuid] = c.state })
    homes.forEach(function (h) {
        var k = "fw:forget:" + h.uuid
        rows.push({ key: k, label: h.name, glyph: icons.home, trailing: "button", value: "Forget", busy: ctx.busy === k,
                    sub: now[h.uuid] === "home" ? "Saved home network  ·  Connected now"
                       : now[h.uuid] === "routerChanged" ? "Saved home network  ·  Its router changed" : "Saved home network" })
        rows.push(vpnRow(h, ctx))
    })
    if (!homes.length)
        rows.push({ label: "Saved home networks", glyph: icons.home, trailing: "none",
                    sub: "None yet. Turn on Home network above while you're connected to yours." })
    rows.push({ label: "Containers", glyph: icons.layers, trailing: "none",
                sub: "Docker's published ports follow these rules too: only the ports you allow answer, and only at home." })
    return rows
}

// The Firewall page (Settings section "firewall").
function groups(st, ctx) {
    if (!st || !st.available)
        return []
    var cs = connections(st)
    var here = cs.length ? cs.map(function (c) { return homeRow(c, ctx) })
        : [{ label: "Not connected", glyph: ctx.icons.wifi, trailing: "none",
             sub: "Connect to Wi-Fi or a cable to choose whether it's your home network" }]
    var wan = internetRows(st, ctx)
    return [{ label: "This network", rows: here }]
        .concat(wan.length ? [{ label: "Open to the internet", rows: wan }] : [])
        .concat([{ label: "Allowed on home networks", rows: allowedRows(st, ctx) },
                 { label: "Advanced", rows: advancedRows(st, ctx) }])
}

// A home router's VPN (WireGuard, UniFi Teleport…): its devices reach this PC from outside as home devices.
function vpnRow(h, ctx) {
    var k = "fw:vpn:" + h.uuid, vpn = h.vpn || []
    return { key: k, label: h.name + ": router VPN", glyph: ctx.icons.lock, trailing: "button",
             value: vpn.length ? "Change…" : "Add…", busy: ctx.busy === k,
             sub: vpn.length ? vpn.join(", ") + "  ·  Devices on this VPN count as home devices"
                             : "Reach this PC from outside your home through this router's VPN" }
}

// The Router VPN dialog's field: "192.168.3.0/24, fd00:3::/64" -> ["192.168.3.0/24", "fd00:3::/64"].
function vpnParse(text) {
    return String(text || "").split(/[\s,;]+/).map(function (x) { return x.trim() }).filter(function (x) { return x })
}
// "" when quasar-firewall will take it (it checks again, and refuses ranges already used on this PC).
function vpnError(text) {
    var items = vpnParse(text)
    if (items.length > 4) return "That's too many ranges: up to 4"
    for (var i = 0; i < items.length; i++) {
        var s = items[i], m = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})\/(\d{1,2})$/.exec(s)
        if (m) {
            var o = [+m[1], +m[2], +m[3], +m[4]], len = +m[5]
            if (o.some(function (n) { return n > 255 })) return "“" + s + "” isn't an address range like 192.168.3.0/24"
            var priv = o[0] === 10 || (o[0] === 172 && o[1] >= 16 && o[1] <= 31) || (o[0] === 192 && o[1] === 168)
                    || (o[0] === 100 && o[1] >= 64 && o[1] <= 127)
            if (!priv) return s + " isn't a private range. A router VPN hands out private addresses, like 192.168.3.0/24"
            if (len < 16) return s + " is too wide. A router VPN's range is usually a /24, like 192.168.3.0/24"
            if (len > 30) return s + " is too small. A router VPN's range is usually a /24, like 192.168.3.0/24"
            continue
        }
        var v6 = /^(f[cd][0-9a-f]{0,2}:[0-9a-f:]*)\/(\d{1,3})$/i.exec(s)
        if (v6 && +v6[2] >= 48 && +v6[2] <= 64) continue
        return "“" + s + "” isn't an address range like 192.168.3.0/24"
    }
    return ""
}
function vpnMessage(h) {
    return "Connect your laptop or phone to " + (h ? h.name : "this network") + "'s router VPN first, then reach this PC "
         + "as if you were home. Type the VPN's address range: in UniFi Network it's under Settings › VPN › VPN Server "
         + "(WireGuard or Teleport), for example 192.168.3.0/24. Devices on it count as home devices for everything "
         + "allowed on home networks: Remote desktop, Remote sign-in, Command Deck, and the apps and ports you allowed."
}

// "fw:home:<uuid>" -> the connection, "fw:forget:<uuid>" -> the home network, "fw:rm:<id>" -> the entry.
function connectionFor(st, uuid) { return connections(st).filter(function (c) { return c.uuid === uuid })[0] || null }
function homeFor(st, uuid) { return ((st && st.homeNetworks) || []).filter(function (h) { return h.uuid === uuid })[0] || null }
function entryFor(st, id) { return ((st && st.allowed) || []).filter(function (e) { return e.id === id })[0] || null }

// Confirmations (Settings' shell.qml shows them; the preview too).
function confirmOff() {
    return { key: "fw:off", title: "Turn off the firewall?", button: "Turn off", danger: true,
             message: "Apps on this PC that wait for connections can then be reached by anyone on the networks you join, "
                    + "public Wi-Fi included. Your home networks and allowed apps are kept for when you turn it back on." }
}
function confirmForget(h) {
    return { key: "fw:forget:" + h.uuid, title: "Forget " + h.name + " as a home network?", button: "Forget", danger: false,
             message: "It becomes a public network: the apps and ports you allowed stop answering devices on it. "
                    + "You can make it a home network again any time you're connected to it." }
}

// The "Allow a port or range" field: "" when it's fine, else what to fix, in plain words.
function portsError(text) {
    var s = String(text || "").trim()
    if (!s) return "Type a port, like 3000, or a range, like 8000-8010"
    var items = s.split(/[,;]/).map(function (x) { return x.trim() }).filter(function (x) { return x })
    if (items.length > 32) return "That's too many at once: up to 32"
    for (var i = 0; i < items.length; i++) {
        var m = /^(\d{1,5})(?:\s*-\s*(\d{1,5}))?$/.exec(items[i])
        if (!m) return "“" + items[i] + "” isn't a port number or a range like 8000-8010"
        var lo = +m[1], hi = m[2] ? +m[2] : lo
        if (lo < 1 || hi > 65535 || lo > hi) return "Ports go from 1 to 65535, and a range starts with the lower number"
    }
    return ""
}
