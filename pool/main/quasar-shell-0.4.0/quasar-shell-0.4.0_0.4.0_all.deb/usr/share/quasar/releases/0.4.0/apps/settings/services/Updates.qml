import QtQuick
import Quickshell
import Quickshell.Io
import Quasar
import Quasar.Services
import "../components/updates.js" as Up

// Settings > Updates: system updates through /usr/libexec/quasar/quasar-update.
// - Reading: /run/quasar/update-state.json (written in place by root whenever packages or package lists
//   change, so the page follows automatic updates and the Store) and `quasar-update status` (any user).
// - Check now / Install now: `pkexec quasar-update check|install`; an active administrator isn't asked for
//   a password (52-quasar-update.rules). Progress comes as PROGRESS/PHASE lines.
// - The choices (automatic updates, restart time, automatic app updates): `pkexec quasar-update-admin`,
//   which asks.
//   QUASAR_UPDATE=/path: a stand-in for both helpers (UI tests).
//   QUASAR_UPDATE_STATE=/path: the state file to watch instead.
Scope {
    id: root
    property bool active: false              // the Updates page is shown
    property bool historyActive: false       // the Update history page is shown
    property var st: null
    property var history: []
    property string busy: ""                 // "check" | "install" | "auto" | "restart" | "apps"
    property int progress: -1
    property string phase: ""
    property var ask: null                   // confirmation: { key, title, message, button }
    property real now: Date.now() / 1000
    signal notify(var banner)
    signal pick(string title, var options, string current, var done, string message)

    readonly property string exe: Quickshell.env("QUASAR_UPDATE") || ""
    readonly property string stateFile: Quickshell.env("QUASAR_UPDATE_STATE") || "/run/quasar/update-state.json"
    function helperCmd(args, admin) {
        return exe ? [exe].concat(args)
                   : ["pkexec", admin ? "/usr/libexec/quasar/quasar-update-admin" : "/usr/libexec/quasar/quasar-update"].concat(args)
    }

    readonly property var ctx: ({ busy: busy, progress: progress, phase: phase, now: now, icons: Icons, theme: Theme })
    readonly property var hero: Up.hero(st, ctx)
    readonly property var groups: Up.groups(st, ctx)
    readonly property var historyGroups: Up.historyGroups(history, ctx)

    onActiveChanged: if (active) { now = Date.now() / 1000; refresh() }
    onHistoryActiveChanged: if (historyActive) historyProc.running = true
    Timer { interval: 60000; running: root.active; repeat: true; onTriggered: root.now = Date.now() / 1000 }

    // ---- reading -----------------------------------------------------------------------------------
    property bool _again: false
    function refresh() {
        if (statusProc.running) { _again = true; return }
        statusProc.running = true
    }
    Process {
        id: statusProc
        command: [root.exe || "/usr/libexec/quasar/quasar-update", "status"]
        stdout: StdioCollector { onStreamFinished: { try { root.st = JSON.parse(text) } catch (e) { } } }
        onExited: (code, status) => { if (root._again) { root._again = false; running = true } }
    }
    Process {
        id: historyProc
        command: [root.exe || "/usr/libexec/quasar/quasar-update", "history", "60"]
        stdout: StdioCollector { onStreamFinished: { try { root.history = JSON.parse(text) || [] } catch (e) { } } }
    }
    FileView {
        path: root.stateFile
        watchChanges: true
        printErrors: false
        onFileChanged: reload()
        onLoaded: { if (root.active && root.busy === "") root.refresh() }
    }

    // ---- changing ----------------------------------------------------------------------------------
    function heroActivated() {
        const s = Up.state(st, ctx)
        if (s.kind === "pending") run("install", ["install"], false)
        else if (s.kind === "restart")
            ask = { key: "restart", title: "Restart now?", button: "Restart",
                    message: "Save your work first: open apps close. Updates finish while the PC starts again." }
        else if (s.button === "Check now") run("check", ["check"], false)
    }
    function toggle(key) { activate(key) }
    function activate(key) {
        if (busy !== "" || !st || st.live) {
            if (key === "up:history" || key === "up:ai") open(key)
            return
        }
        if (key === "up:auto") {
            if (st.auto) ask = { key: "autoOff", title: "Turn off automatic updates?", button: "Turn off", danger: true,
                                 message: "Security fixes then wait until you install them here. A PC that runs on its own, like a server, should keep this on." }
            else run("auto", ["auto", "on"], true)
        } else if (key === "up:restart") {
            pick("Restart automatically", Up.restartChoices(), st.restartAt || "never", (k) => root.run("restart", ["restart", k], true),
                 "When an update needs a restart (a new Linux kernel, the desktop's own libraries), Quasar restarts at this time, even if someone is signed in. Unsaved work is lost, so choose a time nobody uses the PC.")
        } else if (key === "up:apps") {
            run("apps", ["apps", st.apps ? "off" : "on"], true)
        } else {
            open(key)
        }
    }
    function open(key) {
        if (key === "up:history") root.openHistory()
        else if (key === "up:ai") root.openAi()
    }
    signal openHistory()
    signal openAi()

    function confirm() {
        const a = ask
        ask = null
        if (!a) return
        if (a.key === "restart") Platform.power("reboot")
        else if (a.key === "autoOff") run("auto", ["auto", "off"], true)
    }

    // One change at a time. Closing the password sheet (126) says nothing.
    function run(key, args, admin) {
        busy = key
        progress = -1
        phase = ""
        job.run(helperCmd(args, admin))
    }
    Cmd {
        id: job
        onLine: (l) => {
            if (l.startsWith("PROGRESS ")) root.progress = parseInt(l.slice(9)) || 0
            else if (l.startsWith("PHASE ")) root.phase = l.slice(6)
        }
        onFinished: (code) => {
            const key = root.busy
            root.busy = ""
            root.progress = -1
            const phase = root.phase
            root.phase = ""
            if (code === 0) {
                if (key === "install")
                    root.notify(phase.startsWith("Restart") ? { tone: "info", title: "Updates installed", message: "Restart the PC to finish." }
                                                            : { tone: "success", title: phase || "Updates installed", message: "" })
                else if (key === "check" && phase === "Up to date")
                    root.notify({ tone: "success", title: "Quasar is up to date", message: "" })
            } else if (code !== 126) {
                const err = job.details().split("\n").filter(l => l.startsWith("ERROR ")).map(l => l.slice(6)).pop()
                root.notify(code === 127
                    ? { tone: "error", title: "Your account can't install updates", message: "Ask an administrator." }
                    : { tone: code === 4 ? "info" : "error", title: err || "That didn't work", message: err ? "" : "Nothing was changed.",
                        details: job.details() })
            }
            root.refresh()
        }
    }
}
