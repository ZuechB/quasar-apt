import QtQuick

// Template buttons (CSS class "chip": hover lifts 1px and brightens, press springs to .95).
//   variant "primary": accent fill, dark ink (Get, Update all, Connect)
//           "light":   #EEF1F7 fill, dark ink (Open)
//           "soft":    white .08 fill (card "Get" pill uses fg = the app accent; Rename)
//           "outline": hairline border, no fill (Cancel, Disconnect, Details)
//           "ghost":   no fill, "hov" hover (Back)
// size: 30 | 34 | 38 | 42 (template heights); pill: fully rounded (card buttons).
Pressable {
    id: root
    property string text: ""
    property string variant: "soft"
    property string glyph: ""
    property int size: 34
    property bool pill: false
    property bool busy: false
    property color tone: Theme.accent
    property color fg: variant === "primary" || variant === "light" ? Theme.accentInk
                     : variant === "soft" ? Theme.text : Theme.text3
    property int fontWeight: variant === "outline" || variant === "ghost" ? Font.Normal : Font.DemiBold

    readonly property real fontPx: size <= 30 ? 12.5 : size <= 34 ? 13 : size <= 38 ? 13.5 : 14
    readonly property real padX: size <= 34 ? 14 : size <= 38 ? 16 : 26

    kind: variant === "ghost" ? "hov" : "chip"
    radius: pill ? size / 2 : (size <= 30 ? 9 : size <= 38 ? 10 : 13)
    color: variant === "primary" ? tone
         : variant === "light" ? Theme.text
         : variant === "soft" ? Theme.white(0.08) : "transparent"
    borderColor: variant === "outline" ? Theme.white(0.12) : "transparent"
    hoverBorderColor: variant === "outline" ? Theme.white(0.2) : borderColor
    accessibleName: text
    implicitHeight: size
    implicitWidth: Math.round(row.implicitWidth + 2 * (variant === "ghost" ? 10 : padX))
    opacity: enabled ? 1 : 0.5

    // The spinner and the glyph are Shapes (and layers on software rendering): made only when shown, so
    // a page of plain buttons (the Store's cards) holds none.
    Row {
        id: row
        anchors.centerIn: parent
        spacing: 6
        Loader {
            anchors.verticalCenter: parent.verticalCenter
            active: root.busy
            visible: active
            sourceComponent: Spinner { size: 14; color: root.fg }
        }
        Loader {
            anchors.verticalCenter: parent.verticalCenter
            active: root.glyph !== "" && !root.busy
            visible: active
            sourceComponent: QIcon { path: root.glyph; size: Math.round(root.fontPx + 3); strokeWidth: 2; color: root.fg }
        }
        Text {
            anchors.verticalCenter: parent.verticalCenter
            visible: text !== ""
            text: root.text
            textFormat: Text.PlainText
            font.family: Theme.fontUi; font.pointSize: Theme.pt(root.fontPx); font.weight: root.fontWeight
            color: root.fg
        }
    }
}
