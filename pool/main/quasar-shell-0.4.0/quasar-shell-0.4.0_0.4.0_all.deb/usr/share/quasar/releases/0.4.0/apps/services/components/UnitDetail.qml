import QtQuick
import Quasar
import "services.js" as S

// The aside for a row of "Every service on this PC" (S.everyRow): what it is, how it's doing and why it
// stopped, its newest log lines (live), Open console and Open in Terminal. Starting, stopping and turning
// services on or off stay with the tools that own them; Quasar's own open their page in Services. Pure.
Column {
    id: root
    property var row: null
    property var m: ({})
    signal act(string name, var a, var b, var c)
    spacing: 16

    readonly property var st: row ? S.unitStatus(row) : null
    readonly property string why: row ? S.whyStopped(row) : ""
    readonly property color tone: !st ? Theme.textDim : st.color === "fail" ? "#FF8F8F" : st.color === "accent" ? Theme.accent : Theme.textDim

    Row {
        spacing: 12
        width: root.width
        AppTile {
            size: 50; radius: 15
            glyph: root.row && root.row.user ? Icons.user : Icons.server
            glyphSize: 22; glyphStroke: 1.8
            hue: root.row && root.row.status === "failed" ? "#FF8F8F" : "#7AB8FF"
        }
        Column {
            width: root.width - 62
            anchors.verticalCenter: parent.verticalCenter
            spacing: 3
            Text {
                width: parent.width
                text: root.row ? root.row.name : ""
                textFormat: Text.PlainText
                elide: Text.ElideRight
                font.family: Theme.fontUi; font.pixelSize: 16; font.weight: Font.DemiBold
                color: Theme.text
            }
            Text {
                width: parent.width
                text: root.row ? root.row.unit : ""
                textFormat: Text.PlainText
                elide: Text.ElideMiddle
                font.family: Theme.fontMono; font.pointSize: Theme.pt(11)
                color: Theme.textFaint
            }
        }
    }

    // status and, when it isn't running, why
    Column {
        width: root.width
        spacing: 6
        Row {
            spacing: 8
            Rectangle { anchors.verticalCenter: parent.verticalCenter; width: 8; height: 8; radius: 4; color: root.tone }
            Text {
                anchors.verticalCenter: parent.verticalCenter
                text: root.st ? root.st.label : ""
                font.family: Theme.fontUi; font.pixelSize: 13; font.weight: Font.DemiBold
                color: root.tone
            }
        }
        Text {
            visible: root.why !== ""
            width: root.width
            text: root.why
            textFormat: Text.PlainText
            wrapMode: Text.Wrap
            font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
            color: root.row && root.row.status === "failed" ? "#FF9B9B" : Theme.amber
        }
    }

    // facts
    Rectangle {
        width: root.width
        height: facts.implicitHeight
        radius: 12
        color: Theme.white(0.03)
        border.width: 1
        border.color: Theme.white(0.05)
        Column {
            id: facts
            width: parent.width
            Repeater {
                model: root.row ? [
                    ["Runs for", root.row.user ? "Your account" : "This PC (system service)"],
                    ["Starts with the PC", root.row.enabled === true ? "Yes" : root.row.enabled === false ? "No" : "When something needs it"],
                    ["systemd state", (root.row.status || "") + (root.row.sub ? " (" + root.row.sub + ")" : "")]
                ] : []
                delegate: Item {
                    required property var modelData
                    required property int index
                    width: facts.width
                    height: 38
                    Rectangle { visible: index > 0; width: parent.width; height: 1; color: Theme.white(0.05) }
                    Text {
                        x: 14; anchors.verticalCenter: parent.verticalCenter
                        text: modelData[0]
                        font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
                        color: Theme.textDim
                    }
                    Text {
                        anchors { right: parent.right; rightMargin: 14; verticalCenter: parent.verticalCenter }
                        width: parent.width * 0.55
                        horizontalAlignment: Text.AlignRight
                        text: modelData[1]
                        textFormat: Text.PlainText
                        elide: Text.ElideRight
                        font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
                        color: Theme.text2
                    }
                }
            }
        }
    }

    Button {
        visible: !!root.row && root.row.quasar
        variant: "soft"; size: 34; glyph: Icons.fwd; text: "Its page in Services"
        onClicked: root.act("showMain", root.row.console, null, null)
    }

    LogPreview {
        width: root.width
        lines: root.m.logs || []
        onOpenConsole: root.act("openConsole", root.row ? root.row.console : "", null, null)
        onOpenTerminal: root.act("openTerminal", root.row ? root.row.console : "", null, null)
    }
}
