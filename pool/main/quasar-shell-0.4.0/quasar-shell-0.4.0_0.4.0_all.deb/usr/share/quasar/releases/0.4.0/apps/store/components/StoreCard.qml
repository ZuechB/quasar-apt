import QtQuick
import Quasar
import "state.js" as State

// One app card bound to the Store's live data by id: the catalog entry is looked up, never copied, so a
// job's progress re-evaluates only the cards on screen. `view` is the StoreView (catalog index, job
// states, installed apps, store folder, and the signals the clicks go to).
AppCard {
    id: card
    property string appId: ""
    property var view: null
    readonly property var app: view ? view.index[appId] || null : null
    readonly property var job: view ? view.jobStates[appId] || null : null

    name: app ? app.name : ""
    blurb: app ? app.blurb : ""
    source: State.sourceLine(app)
    highlight: !!(app && app.pick)
    glyph: app && app.pick && !app.icon ? Icons.get(app.glyph) : ""
    icon: view ? State.iconUrl(app, view.storeDir) : ""
    letter: State.letterOf(app)
    hue: app && app.hue ? app.hue : Theme.accent
    state_: job ? job.state : (view && State.isInstalled(app, view.installed) ? "open" : "get")
    progress: job ? job.progress : 0
    cancellable: job ? !!job.cancellable : false
    cancelling: job ? !!job.cancelling : false
    // A runtime (library: true, e.g. .NET) has nothing of its own to open: "Installed" shows its page.
    openText: app && app.library ? "Installed" : State.isCli(app) ? "Terminal" : "Open"
    onClicked: view.openDetail(appId)
    onGetClicked: view.getApp(appId)
    onOpenClicked: app && app.library ? view.openDetail(appId) : view.openApp(appId)
    onCancelClicked: view.cancelApp(appId)
}
