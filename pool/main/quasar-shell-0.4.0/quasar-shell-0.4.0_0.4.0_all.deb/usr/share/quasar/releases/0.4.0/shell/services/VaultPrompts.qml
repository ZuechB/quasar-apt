import QtQuick
import Quickshell
import Quickshell.Io
import Quickshell.Wayland
import Quasar
import "../components"

// Vault's questions to you (/usr/libexec/quasar/vaultd daemon asks over IPC: `vault ask BASE64-JSON`,
// `vault cancel ID` when it stopped waiting). One sheet at a time; more questions wait their turn.
// Your answer goes back through `vaultd answer` (stdin: {id, ok, password, choice}); vaultd checks the
// password with PAM and says ok / wrong / gone (it stopped waiting).
//   QUASAR_VAULTD=/path   another vaultd (tests)
Scope {
    id: root
    property var screen: null
    readonly property string vaultd: Quickshell.env("QUASAR_VAULTD") || "/usr/libexec/quasar/vaultd"
    property var queue: []                   // [{ id, kind, browser, site, username, count, accounts }]
    readonly property var current: queue.length ? queue[0] : null
    property bool busy: false
    property string message: ""
    property bool messageIsError: false
    property string choice: ""

    function push(ask) {
        if (!ask || !ask.id) return
        queue = queue.concat([ask])
        if (queue.length === 1) start()
    }
    function start() {
        message = ""; messageIsError = false; busy = false
        const a = current
        choice = a && a.accounts && a.accounts.length ? a.accounts[0].key : ""
        focusTimer.restart()
    }
    function next() {
        queue = queue.slice(1)
        if (queue.length) start()
    }
    function drop(id) {
        const wasCurrent = current && current.id === id
        queue = queue.filter(a => a.id !== id)
        if (wasCurrent) { answerProc.running = false; if (queue.length) start() }
    }

    property string _pending: ""             // the answer being sent (the id it's for)
    function answer(ok, password, pick) {
        const a = current
        if (!a || busy) return
        busy = ok
        _pending = a.id
        answerProc.payload = JSON.stringify({ id: a.id, ok: ok, password: ok ? password : "", choice: pick || "" }) + "\n"
        answerProc.running = true
        if (!ok) { busy = false; next() }
    }
    Process {
        id: answerProc
        property string payload: ""
        command: [root.vaultd, "answer"]
        stdinEnabled: true
        onStarted: { write(payload); payload = ""; stdinEnabled = false }
        stdout: StdioCollector {
            onStreamFinished: {
                let result = "gone"
                try { result = JSON.parse(text).result || "gone" } catch (e) { }
                if (!root.current || root.current.id !== root._pending) return
                if (result === "wrong") {
                    root.busy = false
                    root.message = "That password isn't right"; root.messageIsError = true
                    for (const v of [view]) v.clear()
                    root.focusTimer.restart()
                } else if (root.busy) {
                    root.busy = false
                    root.next()
                }
            }
        }
        onExited: stdinEnabled = true
    }
    property alias focusTimer: focusTimer
    Timer { id: focusTimer; interval: 60; onTriggered: if (root.current) view.focusInput() }

    IpcHandler {
        target: "vault"
        function ask(data: string): void {
            try { root.push(JSON.parse(Qt.atob(data))) } catch (e) { console.warn("vault: bad question", e) }
        }
        function cancel(id: string): void { root.drop(id) }
        function state(): string { return JSON.stringify({ open: root.current !== null, queued: root.queue.length }) }
    }

    PanelWindow {
        id: win
        screen: root.screen
        visible: root.current !== null
        anchors { top: true; bottom: true; left: true; right: true }
        exclusionMode: ExclusionMode.Ignore
        color: "transparent"
        WlrLayershell.layer: WlrLayer.Overlay
        WlrLayershell.namespace: "quasar-vault"
        WlrLayershell.keyboardFocus: WlrKeyboardFocus.Exclusive
        onVisibleChanged: if (visible) { view.clear(); focusTimer.restart() }
        VaultPrompt {
            id: view
            anchors.fill: parent
            readonly property var a: root.current || ({})
            kind: a.kind || "unlock"
            browser: a.browser || ""
            site: a.site || ""
            username: a.username || ""
            count: a.count || 0
            accounts: a.accounts || []
            choice: root.choice
            busy: root.busy
            message: root.message
            messageIsError: root.messageIsError
            onPicked: (key) => root.choice = key
            onSubmitted: (pw, pick) => root.answer(true, pw, pick)
            onCancelled: root.answer(false, "", "")
        }
    }
}
