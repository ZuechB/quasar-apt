import QtQuick

// Glass panel surface (launcher, quick settings, calendar, menus, toasts, taskbar).
//  * Wayfire (compositorBlur): translucent tint; the compositor blurs what is behind the surface.
//  * labwc / no compositor blur: "procedural glass" — a low-detail copy of the wallpaper shader is
//    drawn behind the tint at this panel's screen position (looks frosted over the desktop).
//  * Lite or transparency off: solid #10121B (the mockup's `.solid .glass` rule).
Item {
    id: root
    property real radius: 24
    property color tint: Theme.panelBg
    property color borderColor: Theme.white(0.10)
    property real borderWidth: 1

    // Shadow (CSS box-shadow). Disabled in Lite.
    property bool shadowEnabled: Theme.profile > 0
    property real shadowOffsetY: 30
    property real shadowBlur: 70
    property real shadowSpread: -20
    property color shadowColor: Qt.rgba(0, 0, 0, 0.85)
    property color glowColor: "transparent"     // e.g. Theme.accentGlow for the launcher

    // Procedural glass inputs (set by the shell window that hosts the panel).
    property string wallpaperKind: "deep"
    property size screenSize: Qt.size(0, 0)
    property point screenPos: Qt.point(0, 0)
    readonly property bool proceduralGlass: Theme.glassEnabled && Theme.profile > 0 && !Theme.compositorBlur
                                            && screenSize.width > 0

    default property alias content: body.data
    property alias body: body

    Shadow {
        target: frame
        visible: root.shadowEnabled
        radius: root.radius
        offsetY: root.shadowOffsetY
        blur: root.shadowBlur
        spread: root.shadowSpread
        color: root.shadowColor
    }
    Shadow {
        target: frame
        visible: root.shadowEnabled && root.glowColor.a > 0
        radius: root.radius
        offsetY: 0
        blur: 90
        spread: -40
        color: root.glowColor
    }

    Item {
        id: frame
        anchors.fill: parent

        // Procedural glass backdrop; the shader masks itself to the rounded shape (no offscreen pass).
        Wallpaper {
            anchors.fill: parent
            visible: root.proceduralGlass
            kind: root.wallpaperKind
            lowDetail: true
            cornerRadius: root.radius
            screenSize: root.screenSize
            offset: root.screenPos
        }

        Rectangle {
            anchors.fill: parent
            radius: root.radius
            color: root.proceduralGlass ? Qt.rgba(root.tint.r, root.tint.g, root.tint.b, Math.min(1, root.tint.a + 0.04))
                                        : (Theme.glass ? root.tint : Theme.solid)
            border.width: root.borderWidth
            border.color: root.borderColor
            antialiasing: true
        }

        Item {
            id: body
            anchors.fill: parent
        }
    }
}
