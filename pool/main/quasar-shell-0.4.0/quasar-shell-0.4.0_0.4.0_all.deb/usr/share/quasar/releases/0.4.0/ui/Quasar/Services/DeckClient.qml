import QtQuick
import Quickshell
import Quickshell.Io

// One connection to Command Deck's server, deckd ($XDG_RUNTIME_DIR/quasar/commanddeck.sock), used by the
// shell (role "shell": state pushes, running the phones' requests) and by Settings (role "settings":
// pairing, phones, status). JSON lines; see linux/session/commanddeck/PROTOCOL.md §2. deckd only answers
// this account (it checks the socket's peer).
//   request(obj, onReply(r))   e.g. { op: "status" }, { op: "pairing", show: true }
//   event(obj)                 { event: "watch" | "call" | "phones" | "toast" | "status" | "pairing" | … }
//   lost()                     the connection closed; every unanswered request got { ok: false }.
// A Socket that failed doesn't connect again: owners make a new DeckClient after `dead` (with a backoff).
// QUASAR_DECK_SOCK points it elsewhere (tests).
Socket {
    id: root
    path: Quickshell.env("QUASAR_DECK_SOCK") || ((Quickshell.env("XDG_RUNTIME_DIR") || "/run/user/1000") + "/quasar/commanddeck.sock")

    property int _seq: 0
    property var _pending: ({})
    property var _queue: []
    property bool dead: false
    signal event(var obj)
    signal lost()

    parser: SplitParser { onRead: (line) => root._received(line) }

    function request(obj, onReply) {
        const id = ++_seq
        _pending[id] = onReply || null
        const line = JSON.stringify(Object.assign({}, obj, { id: id })) + "\n"
        if (connected) { write(line); flush(); return id }
        _queue.push(line)
        if (_queue.length === 1) connected = true
        return id
    }
    // A message that needs no answer (state pushes, replies to deckd's calls).
    function send(obj) { return request(obj, null) }

    function _failAll(why) {
        const pending = _pending
        _pending = {}
        _queue = []
        for (const id in pending) if (pending[id]) pending[id]({ ok: false, error: why })
    }
    onConnectionStateChanged: {
        if (connected) {
            for (const l of _queue) write(l)
            _queue = []
            flush()
        } else {
            dead = true
            _failAll("Command Deck isn't running")
            lost()
        }
    }
    onError: (e) => { if (!connected) { dead = true; _failAll("Command Deck isn't running") } }

    function _received(line) {
        let r
        try { r = JSON.parse(line) } catch (e) { return }
        if (r === null || typeof r !== "object") return
        if (r.id === undefined || r.id === null) { event(r); return }
        const cb = _pending[r.id]
        delete _pending[r.id]
        if (cb) cb(r)
    }
}
