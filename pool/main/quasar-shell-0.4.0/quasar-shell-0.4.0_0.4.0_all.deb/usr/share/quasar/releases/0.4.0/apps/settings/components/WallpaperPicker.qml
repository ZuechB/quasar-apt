import QtQuick
import Quasar

// Wallpaper cards (template, Settings › Display): cards (min 170px) with a 92px preview and a name,
// accent ring when chosen. After the three presets come the user's own photo (once one is chosen)
// and "Choose a photo…" (the host opens PhotoChooser). While the photo is the wallpaper, Fill / Fit
// sits under the cards. The desktop's right-click "Display settings" opens this page.
Column {
    id: root
    property string accent: Theme.accent
    property string wallpaper: "deep"
    property string photo: ""              // path of the user's photo; "" until one is chosen
    property string fit: "fill"            // fill | fit
    signal wallpaperPicked(string kind)
    signal choosePhoto()
    signal fitPicked(string fit)
    spacing: 0

    readonly property var cards: [["deep", "Deep field"], ["aurora", "Aurora"], ["graphite", "Graphite"]]
        .concat(photo ? [["photo", photo.slice(photo.lastIndexOf("/") + 1)]] : [], [["choose", "Choose a photo…"]])

    SectionLabel { leftPadding: 4; bottomPadding: 10; text: "Wallpaper" }
    Grid {
        id: grid
        width: parent.width
        readonly property int cols: Math.max(1, Math.floor((width + 10) / (170 + 10)))
        columns: cols
        spacing: 10
        Repeater {
            model: root.cards
            Pressable {
                id: card
                required property var modelData
                readonly property string key: modelData[0]
                readonly property bool on: root.wallpaper === key
                width: (grid.width - (grid.cols - 1) * 10) / grid.cols
                height: 8 + 92 + 8 + 22
                radius: 16
                kind: "card"
                color: Theme.white(0.03)
                borderWidth: 1.5
                borderColor: on ? Theme.accent : Theme.white(0.08)
                hoverBorderColor: on ? Theme.accent : Theme.white(0.16)
                accessibleName: key === "choose" ? "Choose a photo" : modelData[1]
                Accessible.role: key === "choose" ? Accessible.Button : Accessible.RadioButton
                Accessible.checked: on
                onClicked: key === "choose" ? root.choosePhoto() : root.wallpaperPicked(key)
                Rectangle {
                    x: 8; y: 8
                    width: parent.width - 16; height: 92; radius: 10
                    color: card.key === "choose" ? Theme.white(0.04) : Theme.bg
                    clip: true
                    Loader {
                        anchors.fill: parent
                        sourceComponent: card.key === "choose" ? chooseArt : card.key === "photo" ? photoArt : presetArt
                    }
                    Component {
                        id: presetArt
                        Item {
                            Image {
                                id: still
                                anchors.fill: parent
                                source: Theme.wallpaperStill(card.key, root.accent, true)
                                fillMode: Image.PreserveAspectCrop
                                asynchronous: true
                                visible: status === Image.Ready
                            }
                            Wallpaper {
                                anchors.fill: parent
                                visible: !Theme.softwareRender && still.status !== Image.Ready
                                kind: card.key
                                animated: false
                            }
                        }
                    }
                    Component {
                        id: photoArt
                        Item {
                            Image {
                                id: pic
                                anchors.fill: parent
                                source: Theme.fileUrl(root.photo)
                                sourceSize: Qt.size(Math.max(1, Math.round(width)), Math.max(1, Math.round(height)))
                                fillMode: Image.PreserveAspectCrop
                                autoTransform: true
                                asynchronous: true
                            }
                            QIcon {
                                anchors.centerIn: parent
                                visible: pic.status === Image.Error
                                path: Icons.image; size: 24; color: Theme.textFaint
                            }
                        }
                    }
                    Component {
                        id: chooseArt
                        Item {
                            Rectangle {
                                anchors.centerIn: parent
                                width: 40; height: 40; radius: 20
                                color: card.hovered ? Theme.accentTint : Theme.white(0.06)
                                QIcon {
                                    anchors.centerIn: parent
                                    path: Icons.plus; size: 18; strokeWidth: 2.2
                                    color: card.hovered ? Theme.accent : Theme.text3
                                }
                            }
                        }
                    }
                }
                Text {
                    x: 12; y: 8 + 92 + 7
                    width: parent.width - 24
                    elide: Text.ElideMiddle
                    text: card.modelData[1]
                    font.family: Theme.fontUi; font.pixelSize: 13; font.weight: Font.Medium
                    color: card.key === "choose" ? Theme.text3 : Theme.text
                }
            }
        }
    }

    // Fill / Fit for the photo.
    Item {
        width: parent.width
        visible: root.wallpaper === "photo" && root.photo !== ""
        height: visible ? 16 + 42 : 0
        Column {
            x: 4; y: 16
            height: 42
            width: parent.width - fitSeg.width - 20
            spacing: 2
            Item { width: 1; height: (42 - fitTitle.height - fitSub.height - 2) / 2 }
            Text {
                id: fitTitle
                text: "Photo fit"
                font.family: Theme.fontUi; font.pixelSize: 14; font.weight: Font.Medium
                color: Theme.text
            }
            Text {
                id: fitSub
                width: parent.width
                elide: Text.ElideRight
                text: root.fit === "fit" ? "Shows the whole photo, with dark bars where it doesn't reach"
                                         : "Covers the screen; the edges may be cut off"
                font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
                color: Theme.textDim
            }
        }
        Segmented {
            id: fitSeg
            anchors.right: parent.right
            y: 16
            width: 200; height: 42
            model: ["Fill", "Fit"]
            currentIndex: root.fit === "fit" ? 1 : 0
            accessibleName: "Photo fit"
            onPicked: (i) => root.fitPicked(i === 1 ? "fit" : "fill")
        }
    }
}
