import QtQuick
import Quasar
import "state.js" as State

// Store detail page (template sIsDetail): Back; 96px tile, Space Grotesk 30px name, developer,
// chips (source, Sandboxed/System package/Your account, pick or not, compatibility); Get -> Queued /
// Installing N% (+ Cancel while it can still stop) -> Open (+ Remove); about + description (Show more),
// facts (version, updated, licence, website), size; developer tools: versions (DevToolPanel); PRIVACY
// LABEL cards (green = can't reach it) and what weakens the sandbox. Every string from the catalog is
// shown as plain text (it comes from Flathub's app authors).
Column {
    id: root
    property var app: null             // catalog entry + state/progress/action + details (state.js merged())
    property bool softwareRender: false
    property bool versionsLoading: false
    signal backClicked()
    signal getClicked()
    signal openClicked()
    signal removeClicked()
    signal cancelClicked()
    signal homepageClicked()
    signal installSpec(string spec)                 // developer tools: install this version line
    signal defaultClicked(string version)
    signal removeVersionClicked(string version)
    signal otherVersionsClicked()

    spacing: 22
    width: parent ? parent.width : 700
    readonly property string st: app ? app.state : "get"
    readonly property bool sandboxed: app ? app.source === "flathub" : false
    readonly property bool isTool: app ? app.source === "mise" : false
    readonly property bool blocked: !!(app && app.blocked)
    // A .deb the user opened (services/DebFiles.qml): not a Store app, checked by apt's dry run.
    readonly property bool fromFile: !!(app && app.source === "debfile")
    readonly property string fileProblem: !fromFile || st === "open" ? ""
        : app.older ? "This file has an older version (" + app.version + ") than the one installed (" + app.installedVersion + "), so it can't be installed."
        : app.essential ? "It's part of the system itself, so it can't be installed from a file."
        : app.plan && (app.plan.removes || []).length ? "Installing it would remove " + app.plan.removes.slice(0, 4).join(", ") + ", so Quasar won't install it."
        : ""
    readonly property bool proprietary: !!(app && (app.proprietary || /LicenseRef-proprietary/.test(app.license || "")))
    property bool expanded: false
    onAppChanged: if (!app || app.id !== _shownId) { expanded = false; _shownId = app ? app.id : "" }
    property string _shownId: ""

    function mb(bytes) {
        if (!bytes) return ""
        return bytes >= 1e9 ? (bytes / 1e9).toFixed(1) + " GB" : Math.max(1, Math.round(bytes / 1e6)) + " MB"
    }
    function permColor(v) {
        if (v === "No" || v === "None") return Theme.mint
        if (v === "Ask") return Theme.text3
        return Theme.amber
    }
    readonly property bool cancelling: !!(app && app.cancelling)
    function busyText() {
        if (st === "queued") return "Queued"
        if (cancelling) return "Cancelling"
        const pct = " " + Math.round((app ? app.progress : 0) * 100) + "%"
        const a = app ? app.action : ""
        return a === "remove" ? "Removing" : a === "update" ? "Updating" + pct : a === "default" ? "Switching" : "Installing" + pct
    }
    function cancelName() {
        const a = app ? app.action : ""
        if (st === "queued") return "Take " + (app ? app.name : "") + " out of the queue"
        return (a === "update" ? "Stop updating " : "Stop installing ") + (app ? app.name : "")
    }
    function aboutText() {
        if (!app) return ""
        if (fromFile) {
            let t = (app.blurb ? app.blurb.replace(/[.!?]?\s*$/, ".") + " " : "")
                    + "This package comes from a file, not from the Store, so Quasar can't check who made it or what it does. "
                    + "Installing it runs its own setup as administrator, and it isn't sandboxed: install it only if you trust where it came from."
            if (st === "open") return t
            if (fileProblem) return t + " " + fileProblem
            const p = app.plan || {}
            if (app.installedVersion && !app.same) t += " It replaces version " + app.installedVersion + " with " + app.version + "."
            if ((p.missing || []).length || (p.installs || []).length > 1)
                t += " It also needs " + ((p.installs || []).length > 1 ? ((p.installs.length - 1) + " more " + ((p.installs.length - 1) === 1 ? "package" : "packages")) : "more packages")
                     + " from Debian, downloaded when you install it."
            else if (p.ok) t += " Everything it needs is already on this PC."
            return t
        }
        if (app.online) return app.blurb + " Found on Flathub: it's newer than this Store, so Quasar has no details or privacy label for it yet. It still runs sandboxed."
        if (app.local) return "Installed on this PC, but not in this Store's list (it may be newer than this Quasar, or no longer on Flathub). You can open, update or remove it here."
        if (sandboxed) return app.blurb
        if (isTool) return app.blurb + " Installed for your account only. Builds come from " + (app.from || "the project's own server")
                           + " and run unsandboxed, like any developer tool."
                           + ((app.requires || []).indexOf("build-tools") >= 0
                              ? " It needs Build tools (a C compiler and git): the Store gets them first if they're missing, which asks for your password once."
                              : " No password is needed.")
        let t = app.blurb + " Installed from " + (app.sourceLabel ? app.sourceLabel + ", which Quasar turns on only while it's installed," : "Debian")
                + " as a system package: it is not sandboxed."
        if (app.setup === "docker")
            t += " Your account can use Docker without a password, which also gives it full control of this PC."
        if (blocked) t += " It can't run from the installer USB: install Quasar first."
        return t
    }
    // Who chose it, for Flathub apps: Quasar's picks are hand-picked; everything else is all of Flathub.
    function originText() {
        if (!app || !sandboxed || app.online || app.local) return ""
        return app.pick ? "Hand-picked by Quasar. It runs in Flatpak's sandbox; the label below is what it can reach."
                        : "Not hand-picked by Quasar. It runs in Flatpak's sandbox with the permissions below."
    }
    readonly property var weakText: ({
        spawn: "Can run commands outside its sandbox",
        files: "Can change all your files",
        x11: "Uses X11, an older display system with weaker isolation",
        devices: "Can use all devices (cameras, USB)",
        bus: "Can talk to any service on your desktop"
    })
    function facts() {
        if (!app) return ""
        const out = []
        if (app.version) out.push("Version " + app.version)
        if (app.updated) out.push("Updated " + Qt.formatDate(new Date(app.updated * 1000), "MMMM yyyy"))
        if (proprietary) out.push("Proprietary")
        else if (app.license) out.push(app.license.length > 48 ? app.license.slice(0, 46) + "…" : app.license)
        return out.join("  ·  ")
    }

    Button {
        text: "Back"; glyph: Icons.back
        variant: "ghost"; size: 32
        onClicked: root.backClicked()
    }

    Item {
        width: parent.width
        height: Math.max(96, info.implicitHeight)
        AppTile {
            id: tile
            size: 96; radius: 28
            hue: root.app && root.app.hue ? root.app.hue : Theme.accent
            glyph: root.app && !root.app.icon && root.app.pick ? Icons.get(root.app.glyph) : ""
            letter: State.letterOf(root.app)
            image: root.app ? root.app.iconUrl || "" : ""
            glyphSize: 46; glyphStroke: 1.6
            glow: 1.4
        }
        Column {
            id: info
            anchors { left: tile.right; leftMargin: 20; right: action.left; rightMargin: 20; verticalCenter: parent.verticalCenter }
            spacing: 6
            Text {
                width: parent.width
                text: root.app ? root.app.name : ""
                textFormat: Text.PlainText
                elide: Text.ElideRight
                font.family: Theme.fontDisplay; font.pixelSize: 30; font.weight: Font.Medium; font.letterSpacing: -0.6
                color: Theme.text
            }
            Row {
                spacing: 6
                width: parent.width
                Text {
                    id: devText
                    width: Math.min(implicitWidth, parent.width - (verifiedMark.visible ? verifiedMark.width + 6 : 0))
                    text: root.app ? root.app.dev || "" : ""
                    textFormat: Text.PlainText
                    elide: Text.ElideRight
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
                    color: Theme.textMuted
                }
                Row {
                    id: verifiedMark
                    visible: !!(root.app && root.app.verified)
                    anchors.verticalCenter: devText.verticalCenter
                    spacing: 4
                    QIcon { anchors.verticalCenter: parent.verticalCenter; path: Icons.check; size: 13; strokeWidth: 2.4; color: Theme.accent }
                    Text { text: "Verified"; font.family: Theme.fontUi; font.pixelSize: 12; color: Theme.accent }
                }
            }
            Flow {
                width: parent.width
                spacing: 6
                topPadding: 4
                Chip {
                    visible: !!(root.app && root.app.pick)
                    text: "Quasar pick"
                    glyph: Icons.star
                    tone: Theme.accent
                    fill: Theme.alpha(Theme.accent, 0.1)
                }
                Chip {
                    text: !root.app ? "" : root.fromFile ? "From a file" : root.sandboxed ? "Flathub" : root.isTool ? "mise" : (root.app.sourceLabel || "Debian")
                    glyph: root.fromFile ? Icons.alert : ""
                    tone: root.fromFile ? Theme.amber : Theme.text3
                    fill: root.fromFile ? Theme.alpha(Theme.amber, 0.1) : Theme.white(0.06)
                }
                Chip {
                    visible: !!(root.fromFile && root.app.origin)
                    text: root.fromFile ? "Downloaded from " + root.app.origin : ""
                }
                Chip {
                    text: root.sandboxed ? "Sandboxed" : root.isTool ? "Your account" : "System package"
                    glyph: root.sandboxed ? Icons.shield : root.isTool ? Icons.user : Icons.pkg
                    tone: root.sandboxed ? Theme.mint : root.isTool ? Theme.accent : Theme.amber
                    fill: Theme.alpha(root.sandboxed ? Theme.mint : root.isTool ? Theme.accent : Theme.amber, 0.1)
                }
                Chip {
                    visible: root.proprietary
                    text: "Proprietary"
                }
                Chip {
                    readonly property bool gpuWarn: !!(root.app && root.app.gpuRecommended && root.softwareRender)
                    visible: !root.fromFile
                    text: root.blocked ? "Needs Quasar installed" : gpuWarn ? "Works best with a GPU" : "Compatible with this PC"
                    tone: root.blocked || gpuWarn ? Theme.amber : Theme.text3
                }
            }
        }
        Row {
            id: action
            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
            spacing: 8
            Button {
                visible: root.st === "get" || root.st === "failed"
                text: root.fileProblem ? "Can't install" : root.blocked ? "Install Quasar first" : root.st === "failed" ? "Try again" : root.fromFile ? "Install" : "Get"
                variant: root.blocked || root.fileProblem ? "outline" : "primary"; size: 42
                enabled: !root.fileProblem
                onClicked: {
                    if (root.isTool && !root.blocked) root.installSpec(toolPanel.item ? toolPanel.item.selectedSpec : "")
                    else root.getClicked()
                }
            }
            Rectangle {
                visible: root.st === "busy" || root.st === "queued"
                height: 42; radius: 13
                width: busyRow.implicitWidth + 32
                color: Theme.white(0.07)
                Row {
                    id: busyRow
                    anchors.centerIn: parent
                    spacing: 10
                    ProgressRing { anchors.verticalCenter: parent.verticalCenter; size: 22; value: root.app ? root.app.progress : 0; visible: root.st === "busy" && !root.cancelling }
                    Spinner { anchors.verticalCenter: parent.verticalCenter; size: 18; color: Theme.text3; visible: root.cancelling }
                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        text: root.busyText()
                        font.family: Theme.fontUi; font.pixelSize: 13; font.features: { "tnum": 1 }
                        color: root.cancelling ? Theme.text3 : Theme.text
                    }
                }
            }
            // Queued: always. Running: Flathub installs and updates (Debian packages and developer
            // tools run to the end once started, so there's nothing to offer).
            Button {
                visible: (root.st === "busy" || root.st === "queued") && !!(root.app && root.app.cancellable)
                text: "Cancel"
                variant: "outline"; size: 42
                accessibleName: root.cancelName()
                onClicked: root.cancelClicked()
            }
            Button {
                visible: root.st === "open"
                text: "Remove"
                variant: "outline"; size: 42
                onClicked: root.removeClicked()
            }
            Button {
                visible: root.st === "open" && !(root.app && root.app.library)     // a runtime: nothing to open
                text: root.app && root.app.cli ? "Terminal" : "Open"
                glyph: root.app && root.app.cli ? Icons.terminal : ""
                variant: "light"; size: 42
                onClicked: root.openClicked()
            }
        }
    }

    Column {
        width: parent.width
        spacing: 10
        Text {
            width: Math.min(640, parent.width)
            text: root.aboutText()
            textFormat: Text.PlainText
            wrapMode: Text.Wrap
            lineHeight: 1.25
            font.family: Theme.fontUi; font.pointSize: Theme.pt(14.5)
            color: Theme.text3
        }
        Text {
            id: desc
            visible: text !== ""
            width: Math.min(640, parent.width)
            text: root.app ? root.app.desc || "" : ""
            textFormat: Text.PlainText
            wrapMode: Text.Wrap
            maximumLineCount: root.expanded ? 400 : 6
            elide: Text.ElideRight
            lineHeight: 1.25
            font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
            color: Theme.textMuted
        }
        Button {
            visible: desc.visible && (desc.truncated || root.expanded)
            text: root.expanded ? "Show less" : "Show more"
            glyph: root.expanded ? Icons.up : Icons.chev
            variant: "ghost"; size: 30
            onClicked: root.expanded = !root.expanded
        }
        Text {
            visible: text !== ""
            width: Math.min(640, parent.width)
            text: root.originText()
            wrapMode: Text.Wrap
            font.family: Theme.fontUi; font.pixelSize: 13
            color: root.app && root.app.pick ? Theme.text3 : Theme.amber
        }
        Text {
            visible: !!(root.app && root.app.mature)
            text: "For mature audiences: it has intense content (such as violence or adult themes)."
            font.family: Theme.fontUi; font.pixelSize: 13
            color: Theme.amber
        }
        Row {
            spacing: 14
            Text {
                anchors.verticalCenter: parent.verticalCenter
                visible: text !== ""
                text: root.facts()
                textFormat: Text.PlainText
                font.family: Theme.fontUi; font.pixelSize: 12
                color: Theme.textDim
            }
            Button {
                anchors.verticalCenter: parent.verticalCenter
                visible: !!(root.app && root.app.home)
                text: "Website"
                glyph: Icons.globe
                variant: "ghost"; size: 30
                accessibleName: "Open the website of " + (root.app ? root.app.name : "")
                onClicked: root.homepageClicked()
            }
        }
        Text {
            visible: !!(root.app && root.app.size && root.app.size.installed)
            text: !root.app || !root.app.size ? ""
                  : root.fromFile ? "File " + root.mb(root.app.size.download) + "  ·  " + root.mb(root.app.size.installed) + " on disk"
                  : !root.app.size.download ? "About " + root.mb(root.app.size.installed) + " on disk"
                  : "Download " + root.mb(root.app.size.download) + "  ·  " + root.mb(root.app.size.installed) + " on disk"
                    + (root.app.runtimeSize ? "  ·  + " + root.mb(root.app.runtimeSize) + " shared runtime" : "")
            font.family: Theme.fontUi; font.pixelSize: 12
            color: Theme.textDim
        }
    }

    // Developer tools: version lines, installed versions, the default.
    Loader {
        id: toolPanel
        active: root.isTool
        visible: active
        width: parent.width
        sourceComponent: DevToolPanel {
            width: root.width
            app: root.app
            loadingVersions: root.versionsLoading
            onInstallClicked: (spec) => root.installSpec(spec)
            onDefaultClicked: (v) => root.defaultClicked(v)
            onRemoveClicked: (v) => root.removeVersionClicked(v)
            onOtherClicked: root.otherVersionsClicked()
        }
    }

    Column {
        visible: !!root.app && !root.app.online && !root.app.local && (!!root.app.perms || (root.sandboxed && !!root.app.detailsLoaded))
        width: parent.width
        spacing: 10
        Item {
            width: parent.width; height: privTitle.implicitHeight
            SectionLabel { id: privTitle; text: "Privacy label" }
            Text {
                anchors { right: parent.right; baseline: privTitle.baseline }
                text: root.isTool ? "What this tool can reach on your PC" : "What this app can reach on your PC"
                font.family: Theme.fontUi; font.pixelSize: 12
                color: Theme.textDim
            }
        }
        // Flathub didn't tell us (an unreadable or missing manifest): say so rather than guess.
        Text {
            visible: !!root.app && !root.app.perms
            width: Math.min(640, parent.width)
            wrapMode: Text.Wrap
            text: "Not checked: Quasar couldn't read what this app can reach. It still runs in Flatpak's sandbox; Flatseal (in the Store) shows its permissions once it's installed."
            font.family: Theme.fontUi; font.pixelSize: 13
            color: Theme.text3
        }
        Grid {
            id: perms
            visible: !!(root.app && root.app.perms)
            width: parent.width
            readonly property int cols: Math.max(1, Math.floor((width + 8) / (150 + 8)))
            columns: cols
            spacing: 8
            Repeater {
                model: root.app && root.app.perms ? [
                    { label: "Network", val: root.app.perms.net, glyph: Icons.globe },
                    { label: "Files", val: root.app.perms.files, glyph: Icons.folder },
                    { label: "Camera", val: root.app.perms.cam, glyph: Icons.camera },
                    { label: "Microphone", val: root.app.perms.mic, glyph: Icons.mic },
                    { label: "Location", val: root.app.perms.loc, glyph: Icons.pin }
                ] : []
                Rectangle {
                    required property var modelData
                    width: (perms.width - (perms.cols - 1) * 8) / perms.cols
                    height: 86
                    radius: 14
                    color: Theme.white(0.04)
                    border.width: 1; border.color: Theme.white(0.06)
                    Column {
                        x: 12; y: 12
                        width: parent.width - 24
                        spacing: 8
                        QIcon { path: modelData.glyph; size: 18; strokeWidth: 1.9; color: root.permColor(modelData.val) }
                        Text { text: modelData.label; font.family: Theme.fontUi; font.pixelSize: 12; color: Theme.textDim }
                        Text { width: parent.width; elide: Text.ElideRight; text: modelData.val; textFormat: Text.PlainText; font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5); font.weight: Font.DemiBold; color: root.permColor(modelData.val) }
                    }
                }
            }
        }
        // What weakens the sandbox (read from its manifest).
        Repeater {
            model: root.app && root.app.weak ? root.app.weak.filter(w => !!root.weakText[w]) : []
            Row {
                required property var modelData
                spacing: 8
                QIcon { anchors.verticalCenter: parent.verticalCenter; path: Icons.alert; size: 15; strokeWidth: 2; color: Theme.amber }
                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: root.weakText[modelData]
                    font.family: Theme.fontUi; font.pixelSize: 13
                    color: Theme.text3
                }
            }
        }
    }
}
