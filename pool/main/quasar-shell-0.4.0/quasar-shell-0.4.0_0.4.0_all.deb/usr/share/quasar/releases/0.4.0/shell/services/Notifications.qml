import QtQuick
import Quickshell
import Quickshell.Services.Notifications

// org.freedesktop.Notifications server. Popups go to the toast stack unless Focus (DND) is on;
// everything stays in history (calendar panel) until dismissed.
NotificationServer {
    id: server
    keepOnReload: false
    bodySupported: true
    actionsSupported: true
    imageSupported: true

    property bool dnd: false
    signal popup(var notification)

    onNotification: (n) => {
        n.tracked = true
        if (!dnd || n.urgency === NotificationUrgency.Critical) server.popup(n)
    }
}
