import QtQuick
import Quickshell
import Quasar
import Quasar.Services
import "../components"
import "../components/services.js" as S

// One console window (Open console, a row's double-click, quasar-services log/<key>, the tray, Task Manager):
// an AppWindow around LogConsole with its own stream. Its lines never pass through the app's model.
//   services-query journal KEY -n 1000 -f   (servers, Quasar's own, any unit; "*" = every service)
//   sites-query logs ID -f                  (a site: its request lines matter)
// The stream runs with stdinEnabled: when the window goes, its stdin closes and the helper (and the
// journalctl it runs) ends. shell.qml keeps the windows in a ListModel, one per key.
AppWindow {
    id: win
    required property string ckey
    property var item: null                  // the service's row, kept current by shell.qml
    property var cmd: []
    property var unitNames: ({})
    property bool busy: false
    property real now: Date.now()
    signal closeWindow(string key)
    signal act(string name, string key)
    signal openTerminal(string key)
    signal openUnit(var line)

    appName: "services"
    stateName: "console-window"
    title: S.consoleTitle(ckey, item) + " — Log"
    glyph: Icons.terminal
    glyphColor: "#8CF5B0"
    defaultSize: Qt.size(920, 580)
    quitOnClose: false
    onCloseRequested: win.closeWindow(win.ckey)

    property string notice: ""
    property bool live: false
    property string ended: ""

    Stream {
        id: stream
        active: true
        stdinEnabled: true
        cmd: win.cmd
        onEvent: (ev) => {
            if (ev.type === "lines" || ev.type === "log") consoleView.append(S.linesOf(ev))
            else if (ev.type === "live") win.live = true
            else if (ev.type === "notice") win.notice = ev.message || ""
            else if (ev.type === "error") win.ended = ev.message || "Its log couldn't be read."
        }
        onEnded: (code) => {
            win.live = true
            if (code !== 0 && win.ended === "") win.ended = "Reading its log stopped (code " + code + ")."
        }
    }

    // Copy to the clipboard.
    TextEdit { id: clip; visible: false; textFormat: TextEdit.PlainText }
    function copyText(s) { clip.text = s; clip.selectAll(); clip.copy(); clip.text = "" }

    LogConsole {
        id: consoleView
        anchors.fill: parent
        title: win.title
        item: win.item
        combined: win.ckey === "*"
        notice: win.notice
        live: win.live
        ended: win.ended
        busy: win.busy
        unitNames: win.unitNames
        now: win.now
        onAct: (name) => win.act(name, win.item ? win.item.key : win.ckey)
        onOpenTerminal: win.openTerminal(win.ckey)
        onOpenUnit: (line) => win.openUnit(line)
        onCopyText: (s) => win.copyText(s)
        onRetry: { win.ended = ""; win.notice = ""; win.live = false; consoleView.clear(); stream.restart() }
    }

    // Tests: what this window shows (shell.qml's IPC `app consoles`).
    function stateInfo() {
        return { key: ckey, title: title, live: live, notice: notice, ended: ended, lines: consoleView.lineCount,
                 shown: consoleView.shownCount, following: consoleView.following, cmd: cmd }
    }
}
