import QtQuick
import Quickshell
import Quasar
import Quasar.Services

// VPN and Mobile hotspot in Quick settings, and the shell's word when the network side changes on its own.
//   Tiles: VPN (once one has been used: Settings.network.vpn) connects/disconnects that VPN; Hotspot (with
//   a Wi-Fi adapter) starts/stops it, and the first time opens Settings › Mobile hotspot, where its name
//   and password are. Both go through /usr/libexec/quasar/nm-ctl as the user.
//   Toasts: a hotspot that stopped because its adapter's Wi-Fi went away, and Encrypted DNS that stopped
//   getting through on a new network (a sign-in page, a blocked port). State comes from NetState (the
//   root-written /run/quasar/net-state.json); nothing is polled.
//   QUASAR_NM_CTL=/path: a stand-in for nm-ctl (tools/fake-net.py).
Item {
    id: root
    visible: false
    property bool wifiAvailable: false
    property string busy: ""                    // "vpn" | "hotspot" while a tile's change runs
    signal toast(var t)
    signal openSettings(string page)

    readonly property string exe: Quickshell.env("QUASAR_NM_CTL") || "/usr/libexec/quasar/nm-ctl"
    readonly property var lastVpn: (Settings.network || {}).vpn || null

    readonly property var vpnTile: ({
        key: "vpn", label: "VPN", glyph: Icons.lock, details: true, available: !!lastVpn || NetState.vpnOn,
        on: NetState.vpnOn || busy === "vpn",
        sub: busy === "vpn" ? (NetState.vpnOn ? "Disconnecting…" : "Connecting…")
           : NetState.vpnOn ? NetState.vpnName : "Off"
    })
    readonly property var hotspotTile: ({
        key: "hotspot", label: "Hotspot", glyph: Icons.hotspot, details: true, available: wifiAvailable || NetState.hotspotOn,
        on: NetState.hotspotOn || busy === "hotspot",
        sub: busy === "hotspot" ? (NetState.hotspotOn ? "Stopping…" : "Starting…")
           : NetState.hotspotOn ? (NetState.hotspot.ssid || "On") : "Off"
    })

    function toggle(key) {
        if (busy !== "") return
        if (key === "vpn") {
            if (NetState.vpnOn) run("vpn", ["vpn-down", NetState.vpns[0].uuid])
            else if (lastVpn) run("vpn", ["vpn-up", lastVpn.uuid])
            else openSettings("vpn")
        } else if (key === "hotspot") {
            if (NetState.hotspotOn) run("hotspot", ["hotspot-stop"])
            else if (!(Settings.network || {}).hotspot) openSettings("hotspot")   // name and password first
            else run("hotspot", ["hotspot-start"], "{}\n")
        }
    }

    // In plain words, short: the details are a click away (each toast opens the right page).
    readonly property var words: ({
        "needs-secrets": ["Sign in to connect", "vpn"], "password": ["The VPN's password wasn't accepted", "vpn"],
        "unreachable": ["The VPN server didn't answer", "vpn"], "no-network": ["This PC isn't connected to a network", "vpn"],
        "timeout": ["That took too long", ""], "not-found": ["That VPN isn't there any more", "vpn"],
        "same-adapter": ["This PC can't share the Wi-Fi it's connected to", "hotspot"],
        "wifi-off": ["Wi-Fi is off", "hotspot"], "offline": ["This PC isn't online", "hotspot"],
        "no-ap": ["This PC's Wi-Fi can't host a hotspot", "hotspot"], "channel": ["Your Wi-Fi's channel can't host a hotspot", "hotspot"],
        "ap-refused": ["The Wi-Fi adapter wouldn't start the hotspot", "hotspot"],
        "not-allowed": ["Your account isn't allowed to do that", ""]
    })

    property string _key: ""
    property var _result: null
    function run(key, args, input) {
        busy = key
        _key = key
        _result = null
        job.run([exe].concat(args), undefined, input)
    }
    Cmd {
        id: job
        onLine: (l) => { try { const o = JSON.parse(l); if (o.result !== undefined) root._result = o } catch (e) { } }
        onFinished: (code) => {
            const r = root._result || {}, key = root._key
            root.busy = ""
            job.tail = []
            if (code === 0 || r.reason === "cancelled") return
            const w = root.words[r.reason] || ["That didn't work", ""]
            const page = w[1] || (key === "vpn" ? "vpn" : "hotspot")
            root.toast({ title: w[0], sub: key === "vpn" ? (root.lastVpn ? root.lastVpn.name : "VPN") : "Mobile hotspot",
                         glyph: key === "vpn" ? Icons.lock : Icons.hotspot, hue: Theme.amber, settings: page })
            if (r.reason === "needs-secrets" || r.reason === "password" || r.reason === "same-adapter") root.openSettings(page)
        }
    }

    // ---- changes nobody here asked for ---------------------------------------------------------------
    property string _stopped: ""
    property string _reach: ""
    Connections {
        target: NetState
        function onHotspotChanged() {
            const s = NetState.hotspot.stopped || ""
            if (s === "uplink-lost" && root._stopped !== s)
                root.toast({ title: "Mobile hotspot stopped", sub: "The Wi-Fi it was sharing went away.",
                             glyph: Icons.hotspot, hue: Theme.amber, settings: "hotspot" })
            root._stopped = s
        }
        function onDnsChanged() {
            const r = NetState.dnsOn ? (NetState.dns.reach || "") : ""
            const bad = ["blocked", "tls", "clock"].indexOf(r) >= 0
            if (bad && ["blocked", "tls", "clock"].indexOf(root._reach) < 0)
                root.toast({ title: r === "clock" ? "This PC's clock is wrong" : "Encrypted DNS is blocked here",
                             sub: r === "clock" ? "Encrypted DNS can't check certificates. Set the clock in Date & Language."
                                : "This network blocks it, or wants you to sign in on a web page first. Turn it off in Settings until you're signed in.",
                             glyph: Icons.globe, hue: Theme.amber, settings: "dns" })
            if (r !== "checking") root._reach = r
        }
    }
    Component.onCompleted: { _stopped = NetState.hotspot.stopped || ""; _reach = NetState.dns.reach || "" }
}
