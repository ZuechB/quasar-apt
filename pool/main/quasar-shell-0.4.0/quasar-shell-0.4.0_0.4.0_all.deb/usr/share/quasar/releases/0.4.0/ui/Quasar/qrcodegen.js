.pragma library
// QR codes (ISO/IEC 18004 Model 2), byte mode, versions 1-40: enough for URLs. Written for Quasar after
// Project Nayuki's qrcodegen (MIT); verified module-for-module against segno by tools/test-qrcode.py.
//   QR.encode(text, { ecl: "L"|"M"|"Q"|"H", boost: true, mask: -1, minVersion: 1, maxVersion: 40 })
//     -> { size, version, ecl, mask, modules: [[bool]] }  (modules[y][x], true = dark)
//   QR.svgPath(qr, border) -> SVG path data, one unit per module (QrCode.qml draws it as an Image).

var ECLS = { L: { ord: 0, bits: 1 }, M: { ord: 1, bits: 0 }, Q: { ord: 2, bits: 3 }, H: { ord: 3, bits: 2 } }
var ECC_CODEWORDS_PER_BLOCK = [
    [-1, 7, 10, 15, 20, 26, 18, 20, 24, 30, 18, 20, 24, 26, 30, 22, 24, 28, 30, 28, 28, 28, 28, 30, 30, 26, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],
    [-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28, 28, 26, 26, 26, 26, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28],
    [-1, 13, 22, 18, 26, 18, 24, 18, 22, 20, 24, 28, 26, 24, 20, 30, 24, 28, 28, 26, 30, 28, 30, 30, 30, 30, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],
    [-1, 17, 28, 22, 16, 22, 28, 26, 26, 24, 28, 24, 28, 22, 24, 24, 30, 28, 28, 26, 28, 30, 24, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30]]
var NUM_ERROR_CORRECTION_BLOCKS = [
    [-1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4, 4, 4, 4, 4, 6, 6, 6, 6, 7, 8, 8, 9, 9, 10, 12, 12, 12, 13, 14, 15, 16, 17, 18, 19, 19, 20, 21, 22, 24, 25],
    [-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10, 10, 11, 13, 14, 16, 17, 17, 18, 20, 21, 23, 25, 26, 28, 29, 31, 33, 35, 37, 38, 40, 43, 45, 47, 49],
    [-1, 1, 1, 2, 2, 4, 4, 6, 6, 8, 8, 8, 10, 12, 16, 12, 17, 16, 18, 21, 20, 23, 23, 25, 27, 29, 34, 34, 35, 38, 40, 43, 45, 48, 51, 53, 56, 59, 62, 65, 68],
    [-1, 1, 1, 2, 4, 4, 4, 5, 6, 8, 8, 11, 11, 16, 16, 18, 16, 19, 21, 25, 25, 25, 34, 30, 32, 35, 37, 40, 42, 45, 48, 51, 54, 57, 60, 63, 66, 70, 74, 77, 81]]

function utf8(text) {
    var out = [], s = String(text)
    for (var i = 0; i < s.length; i++) {
        var c = s.charCodeAt(i)
        if (c >= 0xD800 && c < 0xDC00 && i + 1 < s.length) {
            var d = s.charCodeAt(i + 1)
            if (d >= 0xDC00 && d < 0xE000) { c = 0x10000 + ((c - 0xD800) << 10) + (d - 0xDC00); i++ }
        }
        if (c < 0x80) out.push(c)
        else if (c < 0x800) out.push(0xC0 | c >> 6, 0x80 | c & 63)
        else if (c < 0x10000) out.push(0xE0 | c >> 12, 0x80 | c >> 6 & 63, 0x80 | c & 63)
        else out.push(0xF0 | c >> 18, 0x80 | c >> 12 & 63, 0x80 | c >> 6 & 63, 0x80 | c & 63)
    }
    return out
}

function numRawDataModules(ver) {
    var result = (16 * ver + 128) * ver + 64
    if (ver >= 2) {
        var numAlign = Math.floor(ver / 7) + 2
        result -= (25 * numAlign - 10) * numAlign - 55
        if (ver >= 7) result -= 36
    }
    return result
}

function numDataCodewords(ver, e) {
    return Math.floor(numRawDataModules(ver) / 8) - ECC_CODEWORDS_PER_BLOCK[e.ord][ver] * NUM_ERROR_CORRECTION_BLOCKS[e.ord][ver]
}

// ---- Reed-Solomon over GF(2^8), polynomial 0x11D -----------------------------------------------------
function rsMultiply(x, y) {
    var z = 0
    for (var i = 7; i >= 0; i--) {
        z = (z << 1) ^ ((z >>> 7) * 0x11D)
        z ^= ((y >>> i) & 1) * x
    }
    return z & 0xFF
}

function rsDivisor(degree) {
    var result = []
    for (var i = 0; i < degree - 1; i++) result.push(0)
    result.push(1)
    var root = 1
    for (var j = 0; j < degree; j++) {
        for (var k = 0; k < result.length; k++) {
            result[k] = rsMultiply(result[k], root)
            if (k + 1 < result.length) result[k] ^= result[k + 1]
        }
        root = rsMultiply(root, 0x02)
    }
    return result
}

function rsRemainder(data, divisor) {
    var result = divisor.map(function () { return 0 })
    for (var i = 0; i < data.length; i++) {
        var factor = data[i] ^ result.shift()
        result.push(0)
        for (var j = 0; j < divisor.length; j++) result[j] ^= rsMultiply(divisor[j], factor)
    }
    return result
}

function addEccAndInterleave(data, ver, e) {
    var numBlocks = NUM_ERROR_CORRECTION_BLOCKS[e.ord][ver]
    var blockEccLen = ECC_CODEWORDS_PER_BLOCK[e.ord][ver]
    var rawCodewords = Math.floor(numRawDataModules(ver) / 8)
    var numShortBlocks = numBlocks - rawCodewords % numBlocks
    var shortBlockLen = Math.floor(rawCodewords / numBlocks)
    var blocks = []
    var divisor = rsDivisor(blockEccLen)
    for (var i = 0, k = 0; i < numBlocks; i++) {
        var dat = data.slice(k, k + shortBlockLen - blockEccLen + (i < numShortBlocks ? 0 : 1))
        k += dat.length
        var ecc = rsRemainder(dat, divisor)
        if (i < numShortBlocks) dat.push(0)
        blocks.push(dat.concat(ecc))
    }
    var result = []
    for (var n = 0; n < blocks[0].length; n++) {
        for (var b = 0; b < blocks.length; b++) {
            if (n != shortBlockLen - blockEccLen || b >= numShortBlocks) result.push(blocks[b][n])
        }
    }
    return result
}

// ---- the symbol --------------------------------------------------------------------------------------
function Symbol(ver, e, codewords, mask) {
    this.version = ver
    this.size = ver * 4 + 17
    this.ecl = e
    this.modules = []
    this.isFunction = []
    for (var y = 0; y < this.size; y++) {
        var row = [], frow = []
        for (var x = 0; x < this.size; x++) { row.push(false); frow.push(false) }
        this.modules.push(row)
        this.isFunction.push(frow)
    }
    this.drawFunctionPatterns()
    this.drawCodewords(codewords)
    if (mask == -1) {
        var best = 1e9
        for (var m = 0; m < 8; m++) {
            this.applyMask(m)
            this.drawFormatBits(m)
            var p = this.penalty()
            if (p < best) { mask = m; best = p }
            this.applyMask(m)
        }
    }
    this.mask = mask
    this.applyMask(mask)
    this.drawFormatBits(mask)
}

Symbol.prototype.set = function (x, y, dark) {
    this.modules[y][x] = dark
    this.isFunction[y][x] = true
}

Symbol.prototype.alignmentPositions = function () {
    if (this.version == 1) return []
    var numAlign = Math.floor(this.version / 7) + 2
    var step = this.version == 32 ? 26 : Math.ceil((this.version * 4 + 4) / (numAlign * 2 - 2)) * 2
    var result = [6]
    for (var pos = this.size - 7; result.length < numAlign; pos -= step) result.splice(1, 0, pos)
    return result
}

Symbol.prototype.drawFunctionPatterns = function () {
    var i
    for (i = 0; i < this.size; i++) {
        this.set(6, i, i % 2 == 0)
        this.set(i, 6, i % 2 == 0)
    }
    this.drawFinder(3, 3)
    this.drawFinder(this.size - 4, 3)
    this.drawFinder(3, this.size - 4)
    var pos = this.alignmentPositions()
    var n = pos.length
    for (i = 0; i < n; i++) {
        for (var j = 0; j < n; j++) {
            if (!(i == 0 && j == 0 || i == 0 && j == n - 1 || i == n - 1 && j == 0)) this.drawAlignment(pos[i], pos[j])
        }
    }
    this.drawFormatBits(0)
    this.drawVersion()
}

Symbol.prototype.drawFinder = function (x, y) {
    for (var dy = -4; dy <= 4; dy++) {
        for (var dx = -4; dx <= 4; dx++) {
            var dist = Math.max(Math.abs(dx), Math.abs(dy))
            var xx = x + dx, yy = y + dy
            if (0 <= xx && xx < this.size && 0 <= yy && yy < this.size) this.set(xx, yy, dist != 2 && dist != 4)
        }
    }
}

Symbol.prototype.drawAlignment = function (x, y) {
    for (var dy = -2; dy <= 2; dy++)
        for (var dx = -2; dx <= 2; dx++) this.set(x + dx, y + dy, Math.max(Math.abs(dx), Math.abs(dy)) != 1)
}

function bit(x, i) { return ((x >>> i) & 1) != 0 }

Symbol.prototype.drawFormatBits = function (mask) {
    var data = this.ecl.bits << 3 | mask
    var rem = data
    for (var i = 0; i < 10; i++) rem = (rem << 1) ^ ((rem >>> 9) * 0x537)
    var bits = (data << 10 | rem) ^ 0x5412
    for (i = 0; i <= 5; i++) this.set(8, i, bit(bits, i))
    this.set(8, 7, bit(bits, 6))
    this.set(8, 8, bit(bits, 7))
    this.set(7, 8, bit(bits, 8))
    for (i = 9; i < 15; i++) this.set(14 - i, 8, bit(bits, i))
    for (i = 0; i < 8; i++) this.set(this.size - 1 - i, 8, bit(bits, i))
    for (i = 8; i < 15; i++) this.set(8, this.size - 15 + i, bit(bits, i))
    this.set(8, this.size - 8, true)
}

Symbol.prototype.drawVersion = function () {
    if (this.version < 7) return
    var rem = this.version
    for (var i = 0; i < 12; i++) rem = (rem << 1) ^ ((rem >>> 11) * 0x1F25)
    var bits = this.version << 12 | rem
    for (i = 0; i < 18; i++) {
        var b = bit(bits, i)
        var a = this.size - 11 + i % 3, c = Math.floor(i / 3)
        this.set(a, c, b)
        this.set(c, a, b)
    }
}

Symbol.prototype.drawCodewords = function (data) {
    var i = 0
    for (var right = this.size - 1; right >= 1; right -= 2) {
        if (right == 6) right = 5
        for (var vert = 0; vert < this.size; vert++) {
            for (var j = 0; j < 2; j++) {
                var x = right - j
                var upward = ((right + 1) & 2) == 0
                var y = upward ? this.size - 1 - vert : vert
                if (!this.isFunction[y][x] && i < data.length * 8) {
                    this.modules[y][x] = bit(data[i >>> 3], 7 - (i & 7))
                    i++
                }
            }
        }
    }
}

Symbol.prototype.applyMask = function (mask) {
    for (var y = 0; y < this.size; y++) {
        for (var x = 0; x < this.size; x++) {
            var inv
            switch (mask) {
            case 0: inv = (x + y) % 2 == 0; break
            case 1: inv = y % 2 == 0; break
            case 2: inv = x % 3 == 0; break
            case 3: inv = (x + y) % 3 == 0; break
            case 4: inv = (Math.floor(x / 3) + Math.floor(y / 2)) % 2 == 0; break
            case 5: inv = x * y % 2 + x * y % 3 == 0; break
            case 6: inv = (x * y % 2 + x * y % 3) % 2 == 0; break
            default: inv = ((x + y) % 2 + x * y % 3) % 2 == 0
            }
            if (!this.isFunction[y][x] && inv) this.modules[y][x] = !this.modules[y][x]
        }
    }
}

// The standard penalty (runs, 2x2 blocks, finder-like patterns, dark/light balance).
Symbol.prototype.penalty = function () {
    var s = this.size, m = this.modules, result = 0, x, y
    var line = function (get) {
        var p = 0, run = 0, color = null, seq = []
        for (var i = 0; i < s; i++) {
            var c = get(i)
            if (c === color) {
                run++
                if (run == 5) p += 3
                else if (run > 5) p += 1
            } else {
                if (color !== null) seq.push(run)
                color = c
                run = 1
            }
        }
        return p
    }
    for (y = 0; y < s; y++) result += line(function (i) { return m[y][i] })
    for (x = 0; x < s; x++) result += line(function (i) { return m[i][x] })
    for (y = 0; y < s - 1; y++)
        for (x = 0; x < s - 1; x++) {
            var c = m[y][x]
            if (c === m[y][x + 1] && c === m[y + 1][x] && c === m[y + 1][x + 1]) result += 3
        }
    // 1:1:3:1:1 with four light modules on one side (rows and columns).
    var pat = [true, false, true, true, true, false, true]
    var finderLike = function (get) {
        var p = 0
        for (var i = 0; i + 7 <= s; i++) {
            var ok = true
            for (var k = 0; k < 7 && ok; k++) if (get(i + k) !== pat[k]) ok = false
            if (!ok) continue
            var before = true, after = true
            for (k = 1; k <= 4; k++) {
                if (i - k >= 0 && get(i - k)) before = false
                if (i + 6 + k < s && get(i + 6 + k)) after = false
            }
            if (before || after) p += 40
        }
        return p
    }
    for (y = 0; y < s; y++) result += finderLike(function (i) { return m[y][i] })
    for (x = 0; x < s; x++) result += finderLike(function (i) { return m[i][x] })
    var dark = 0
    for (y = 0; y < s; y++) for (x = 0; x < s; x++) if (m[y][x]) dark++
    var total = s * s
    var k2 = Math.ceil(Math.abs(dark * 20 - total * 10) / total) - 1
    return result + Math.max(0, k2) * 10
}

// ---- public ----------------------------------------------------------------------------------------------
function encode(text, opts) {
    opts = opts || {}
    var data = utf8(text)
    var e = ECLS[opts.ecl || "M"] || ECLS.M
    var minV = opts.minVersion || 1, maxV = opts.maxVersion || 40
    var ver, used
    for (ver = minV; ; ver++) {
        used = 4 + (ver < 10 ? 8 : 16) + data.length * 8
        if (used <= numDataCodewords(ver, e) * 8) break
        if (ver >= maxV) return null                    // too long
    }
    if (opts.boost !== false) {
        var order = ["L", "M", "Q", "H"]
        for (var oi = e.ord + 1; oi < 4; oi++) if (used <= numDataCodewords(ver, ECLS[order[oi]]) * 8) e = ECLS[order[oi]]
    }
    var bits = []
    var push = function (val, len) { for (var i = len - 1; i >= 0; i--) bits.push((val >>> i) & 1) }
    push(4, 4)
    push(data.length, ver < 10 ? 8 : 16)
    for (var i = 0; i < data.length; i++) push(data[i], 8)
    var capacity = numDataCodewords(ver, e) * 8
    push(0, Math.min(4, capacity - bits.length))
    push(0, (8 - bits.length % 8) % 8)
    for (var pad = 0xEC; bits.length < capacity; pad ^= 0xEC ^ 0x11) push(pad, 8)
    var codewords = []
    for (i = 0; i < bits.length; i += 8) {
        var b = 0
        for (var j = 0; j < 8; j++) b = (b << 1) | bits[i + j]
        codewords.push(b)
    }
    var mask = opts.mask === undefined ? -1 : opts.mask
    var sym = new Symbol(ver, e, addEccAndInterleave(codewords, ver, e), mask)
    var name = ["L", "M", "Q", "H"][e.ord]
    return { size: sym.size, version: ver, ecl: name, mask: sym.mask, modules: sym.modules }
}

function svgPath(qr, border) {
    var b = border === undefined ? 4 : border
    var parts = []
    for (var y = 0; y < qr.size; y++) {
        for (var x = 0; x < qr.size; x++) {
            if (!qr.modules[y][x]) continue
            var run = 1
            while (x + run < qr.size && qr.modules[y][x + run]) run++
            parts.push("M" + (x + b) + "," + (y + b) + "h" + run + "v1h-" + run + "z")
            x += run - 1
        }
    }
    return parts.join("")
}
