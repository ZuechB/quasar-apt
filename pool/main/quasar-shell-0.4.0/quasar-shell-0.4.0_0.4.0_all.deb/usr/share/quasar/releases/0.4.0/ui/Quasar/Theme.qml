pragma Singleton
import QtQuick

// Quasar design tokens. Source of truth: templates/Quasar OS – Quasar desktop.html (a bundled page:
// the design markup and its CSS are the JSON string on line 680). Keep values in sync with it.
QtObject {
    id: theme

    // ---- Profile / effects -------------------------------------------------
    // 0 = Lite (solid panels, static wallpaper, no stars), 1 = Balanced, 2 = Max.
    property int profile: 1
    // Qt's software scene graph is in use (QT_QUICK_BACKEND=software, set for Quasar processes on
    // machines without a GPU). It repaints only what changed, but cannot run shaders: the wallpaper
    // becomes a pre-rendered image and shadows/glass stay off (they are Lite-only anyway).
    // It also paints a Shape that lies wholly outside a clip (scrolled out of a ScrollPane or
    // ListView) with no clip at all, over whatever is there, such as the title bar (Qt 6.8). So every
    // Shape that can scroll is a layer on this path (`layer.enabled: Theme.softwareRender`): a layer
    // is a plain image, which clips, and scrolling then moves pixels instead of re-drawing paths.
    property bool softwareRender: false
    // Mockup "Transparency" toggle. Glass needs compositor blur (Wayfire); Lite or labwc => solid.
    property bool glassEnabled: true
    property bool compositorBlur: false        // set by the shell when the compositor blurs behind us
    readonly property bool glass: glassEnabled && profile > 0 && compositorBlur
    // Mockup "Animations" toggle (+ system reduced motion).
    property bool reduceMotion: false
    readonly property bool ambientMotion: !reduceMotion && profile > 0

    // ---- Accent --------------------------------------------------------------
    readonly property var accents: [
        { name: "Ice",    color: "#7AE7FF" },
        { name: "Violet", color: "#B9A4FF" },
        { name: "Amber",  color: "#FFB86B" },
        { name: "Mint",   color: "#8CF5B0" },
        { name: "Rose",   color: "#FF8FB1" }
    ]
    property color accent: "#7AE7FF"
    // Pre-rendered wallpaper still (or its Settings thumbnail) for a kind + preset accent. Resolved
    // here, inside the module: Quickshell blocks app-relative URLs that climb out of an app's folder.
    function wallpaperStill(kind, accentHex, thumb) {
        return Qt.resolvedUrl("wallpapers/" + (thumb ? "thumbs/" : "") + kind + "-" + String(accentHex).replace("#", "").toLowerCase() + ".jpg")
    }
    // The user's own wallpaper photo (wallpaper kind "photo"): Settings.wallpaperPhoto, bound by each
    // process like `accent`. A file path; "fill" crops it to cover the screen, "fit" shows all of it.
    property string wallpaperPhoto: ""
    property string wallpaperFit: "fill"
    readonly property url wallpaperPhotoUrl: fileUrl(wallpaperPhoto)
    // A local path as a file:// URL ("#", "?" and spaces in file names would otherwise break it).
    // A Windows drive ("D:/…") is kept as is, for the design previews.
    function fileUrl(path) {
        if (!path) return ""
        const p = String(path)
        const drive = /^[A-Za-z]:\//.test(p) ? "/" + p.slice(0, 2) : ""
        return "file://" + drive + p.slice(drive ? 2 : 0).split("/").map(encodeURIComponent).join("/")
    }
    readonly property color accentTint: alpha(accent, 0.14)
    readonly property color accentGlow: alpha(accent, 0.40)
    readonly property color accentLine: alpha(accent, 0.45)

    // ---- Surfaces --------------------------------------------------------------
    readonly property color bg: "#05060A"
    readonly property color solid: "#10121B"          // `.solid .glass` fallback
    readonly property color windowBg: "#E60B0D15"     // rgba(11,13,21,.90)
    // App window fill (AppWindow.background): the template's rgba(11,13,21,.92) over its dark
    // desktop, opaque. The window itself is translucent only in its rounded corners and its
    // shadow/resize margin; WindowShape tells the compositor the rest is opaque, so it still skips
    // everything behind the window (cheap to move on software rendering).
    readonly property color windowOpaque: "#0B0D15"
    // App window corners (template: border-radius 14px). Maximized and fullscreen windows are
    // square and edge to edge. Full-bleed fills that reach a window's bottom corners (a Dialog's
    // scrim) round them with windowCorner(Window.visibility).
    readonly property int windowRadius: 14
    function windowCorner(visibility) {
        return visibility === Window.Maximized || visibility === Window.FullScreen ? 0 : windowRadius
    }
    readonly property color panelBg: glass ? "#D60C0E17" : solid      // rgba(12,14,23,.84)
    readonly property color panelBgStrong: glass ? "#DB0C0E17" : solid // rgba(12,14,23,.86)
    readonly property color menuBg: glass ? "#E60E101A" : solid       // rgba(14,16,26,.90)
    readonly property color taskbarBg: glass ? "#BD090B12" : solid    // rgba(9,11,18,.74)
    readonly property color tooltipBg: "#F0090B12"                    // rgba(9,11,18,.94)
    readonly property color tileBase: "#121522"
    readonly property color taskTileBase: "#131623"

    // ---- Text ----------------------------------------------------------------
    readonly property color text: "#EEF1F7"
    readonly property color text2: "#DDE2EC"
    readonly property color text3: "#C9CFDC"
    readonly property color textMuted: "#A4ABBD"
    readonly property color textDim: "#8E96A8"
    readonly property color textFaint: "#7D8598"
    readonly property color danger: "#FF9B9B"
    readonly property color mint: "#8CF5B0"
    readonly property color amber: "#FFB86B"
    readonly property color accentInk: "#05060A"
    readonly property color fillLight: "#E6EAF2"

    // ---- Hairlines / fills (white at alpha) ------------------------------------
    function white(a) { return Qt.rgba(1, 1, 1, a) }
    function alpha(c, a) { return Qt.rgba(c.r, c.g, c.b, a) }

    // ---- App hues (mockup reg()) -----------------------------------------------
    readonly property var hues: ({
        files: "#7AB8FF", browser: "#7AE7FF", mail: "#FFB86B", terminal: "#8CF5B0",
        store: "#7AE7FF", settings: "#C9CFDC", code: "#B9A4FF", photos: "#FF9BD2",
        music: "#FF8FB1", calendar: "#FF9B9B", notes: "#FFD66B", chat: "#7AB8FF",
        monitor: "#8CF5B0", canvas: "#7AE7FF", video: "#FFB86B", camera: "#C9CFDC",
        calc: "#C9CFDC", vault: "#FFD66B", sites: "#7AE7FF"
    })

    // ---- Typography --------------------------------------------------------------
    // CSS px -> font.pointSize (Qt logical DPI is 96). font.pixelSize is integer-only in Qt 6, and the
    // mockup uses half-pixel sizes (10.5, 12.5, 13.5 …), so text sizes go through pt().
    function pt(px) { return px * 0.75 }
    // Fonts are vendored (OFL) so nothing is fetched at runtime.
    readonly property FontLoader _inter: FontLoader { source: Qt.resolvedUrl("fonts/Inter-Variable.ttf") }
    readonly property FontLoader _mono: FontLoader { source: Qt.resolvedUrl("fonts/JetBrainsMono-Variable.ttf") }
    readonly property FontLoader _display: FontLoader { source: Qt.resolvedUrl("fonts/SpaceGrotesk-Variable.ttf") }
    readonly property string fontUi: _inter.status === FontLoader.Ready ? _inter.name : "Inter"
    readonly property string fontMono: _mono.status === FontLoader.Ready ? _mono.name : "JetBrains Mono"
    readonly property string fontDisplay: _display.status === FontLoader.Ready ? _display.name : "Space Grotesk"

    // ---- Layout constants --------------------------------------------------------
    readonly property int taskbarHeight: 56
    readonly property int panelGap: 10       // panels sit 10px from screen edges, 66px from bottom
    readonly property int panelBottom: 66
}
