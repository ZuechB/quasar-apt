import QtQuick
import Quasar
import "services.js" as S

// The aside's form (template "Add a service", springs in with panelIn). mode "add": pick the server's
// folder (Browse… or a typed path), see what Quasar found (a Unity server, a .NET app, a program), then
// name, program, arguments, how it runs and who can join on which port; "Add service" asks for the
// administrator password once. mode "edit": the same fields for a server that exists ("Save").
// Everything is in m.draft (shell.qml keeps it); edits go out as act("draft", field, value),
// act("port", index, field, value), act("addPort"), act("removePort", index).
Column {
    id: root
    property string mode: "add"
    property var m: ({})
    property var item: null
    signal act(string name, var a, var b, var c)
    signal browse()
    function call(name, a, b, c) { root.act(name, a === undefined ? null : a, b === undefined ? null : b, c === undefined ? null : c) }

    readonly property var d: m.draft || null
    readonly property bool editing: mode === "edit"
    readonly property bool blocked: !!d && (d.problems || []).length > 0
    readonly property string problem: d ? S.draftProblem(d) : ""
    readonly property bool saving: !!m.saving
    readonly property var kindGlyph: ({ unity: Icons.gamepad, dotnet: Icons.code, program: Icons.terminal, script: Icons.terminal })
    property bool showAllFlags: !!m.showAllFlags                // the previews open it
    readonly property var chips: d ? S.flagChips(d, showAllFlags) : ({ shown: [], more: 0 })
    readonly property var warnings: d ? S.argsWarnings(d) : []

    // A chip's flag goes into the arguments. One that still needs its value leaves the cursor after it.
    function addFlag(f) {
        root.call("addFlag", f.flag)
        Qt.callLater(() => {
            if (!argsField.text.endsWith(" ")) return
            argsField.focusInput()
            argsField.inputItem.cursorPosition = argsField.inputItem.text.length
        })
    }

    // The template's 24px chip, clickable (like the Store's FilterChip): "+ -maxplayers".
    component FlagChip: Pressable {
        id: chip
        property string text: ""
        property string glyph: Icons.plus
        property bool mono: true
        kind: "chip"
        radius: 7
        color: Theme.white(0.06)
        implicitHeight: 26
        implicitWidth: chipRow.implicitWidth + 18
        Row {
            id: chipRow
            anchors.centerIn: parent
            spacing: 5
            QIcon {
                visible: chip.glyph !== ""
                anchors.verticalCenter: parent.verticalCenter
                path: chip.glyph; size: 11; strokeWidth: 2.2; color: Theme.text3
            }
            Text {
                anchors.verticalCenter: parent.verticalCenter
                text: chip.text
                textFormat: Text.PlainText
                font.family: chip.mono ? Theme.fontMono : Theme.fontUi; font.pointSize: Theme.pt(chip.mono ? 11 : 11.5)
                color: Theme.text3
            }
        }
    }

    spacing: 16

    // Template panelIn: rises 24px and scales from .94 with the spring.
    opacity: 0
    scale: 0.94
    transform: Translate { id: rise; y: 24 }
    Component.onCompleted: enter.start()
    ParallelAnimation {
        id: enter
        NumberAnimation { target: root; property: "opacity"; to: 1; duration: Motion.dur(300) }
        NumberAnimation { target: root; property: "scale"; to: 1; duration: Motion.dur(450); easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.spring }
        NumberAnimation { target: rise; property: "y"; to: 0; duration: Motion.dur(450); easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.spring }
    }

    component Label: Text {
        font.family: Theme.fontMono; font.pointSize: Theme.pt(10.5); font.letterSpacing: 1.05
        color: Theme.textFaint
    }
    component Hint: Text {
        wrapMode: Text.Wrap
        lineHeight: 1.15
        font.family: Theme.fontUi; font.pixelSize: 12
        color: Theme.textDim
    }

    // ---- header -----------------------------------------------------------------------------------
    Item {
        width: root.width
        height: 32
        Text {
            anchors.verticalCenter: parent.verticalCenter
            width: parent.width - 40
            text: root.editing ? "Settings" : "Add a service"
            elide: Text.ElideRight
            font.family: Theme.fontDisplay; font.pixelSize: 20; font.weight: Font.Medium
            color: Theme.text
        }
        Pressable {
            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
            width: 32; height: 32; radius: 9; kind: "hov"
            accessibleName: "Close"
            onClicked: root.call("closeForm")
            QIcon { anchors.centerIn: parent; path: Icons.x; size: 14; strokeWidth: 2; color: Theme.textMuted }
        }
    }

    // ---- the folder --------------------------------------------------------------------------------
    Column {
        width: root.width
        spacing: 8
        Label { text: "SERVER FOLDER" }
        Row {
            width: parent.width
            spacing: 6
            TextField {
                id: pathField
                width: parent.width - browseBtn.width - parent.spacing
                mono: true
                text: root.d ? root.d.path || "" : ""
                placeholder: "~/Servers/My Game Server"
                enabled: !root.saving
                Accessible.name: "Server folder"
                onTextChanged: if (!inputItem.activeFocus) inputItem.cursorPosition = 0
                onAccepted: { pathTimer.stop(); root.call("pathEdited", pathField.text, root.mode) }
                onEdited: (t) => pathTimer.restart()
            }
            Button {
                id: browseBtn
                variant: "soft"; size: 38; text: "Browse…"
                enabled: !root.saving
                onClicked: root.browse()
            }
        }
        Timer { id: pathTimer; interval: 900; onTriggered: root.call("pathEdited", pathField.text, root.mode) }
        Row {
            visible: !!root.m.inspecting
            spacing: 8
            Spinner { anchors.verticalCenter: parent.verticalCenter; size: 14 }
            Hint { anchors.verticalCenter: parent.verticalCenter; text: "Looking at the folder…" }
        }
        Hint {
            visible: !!root.m.inspectError && !root.m.inspecting
            width: parent.width
            text: root.m.inspectError || ""
            color: Theme.danger
        }
        Hint {
            visible: !root.d && !root.m.inspecting && !root.m.inspectError && !root.editing
            width: parent.width
            text: "The folder with the server’s program, like the Linux build Unity made. It runs from there, and stays yours."
        }
    }

    // ---- what Quasar found -------------------------------------------------------------------------
    Rectangle {
        visible: !!root.d && !root.editing
        width: root.width
        height: found.implicitHeight + 24
        radius: 13
        color: Theme.white(0.03)
        border.width: 1
        border.color: root.blocked ? Qt.rgba(1, 143 / 255, 143 / 255, 0.35) : Theme.white(0.07)
        Column {
            id: found
            x: 12; y: 12
            width: parent.width - 24
            spacing: 10
            Row {
                width: parent.width
                spacing: 12
                AppTile {
                    size: 38; radius: 12
                    base: Theme.taskTileBase
                    sheen: 0.13; borderAlpha: 0.08
                    glyph: root.d ? root.kindGlyph[root.d.kind] || Icons.cube : Icons.cube
                    glyphSize: 19; glyphStroke: 1.9
                    hue: root.blocked ? "#FF8F8F" : "#FF8FB1"
                }
                Column {
                    width: parent.width - 50
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: 3
                    Text {
                        width: parent.width
                        text: root.d ? (root.d.label || "A program") : ""
                        textFormat: Text.PlainText
                        elide: Text.ElideRight
                        font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5); font.weight: Font.DemiBold
                        color: Theme.text
                    }
                    Text {
                        width: parent.width
                        text: root.d ? root.d.name || "" : ""
                        textFormat: Text.PlainText
                        elide: Text.ElideRight
                        font.family: Theme.fontUi; font.pixelSize: 12
                        color: Theme.textDim
                    }
                }
            }
            Flow {
                visible: !!root.d && ((root.d.facts || []).length > 0 || root.d.manifest)
                width: parent.width
                spacing: 6
                Repeater {
                    model: root.d ? root.d.facts || [] : []
                    delegate: Chip { required property var modelData; text: modelData }
                }
                Chip {
                    visible: !!root.d && root.d.manifest
                    text: "quasar-service.json"
                    glyph: Icons.check
                    tone: Theme.mint
                    fill: Theme.alpha(Theme.mint, 0.1)
                }
            }
            Repeater {
                model: root.d ? root.d.problems || [] : []
                delegate: Row {
                    required property var modelData
                    width: found.width
                    spacing: 8
                    QIcon { path: Icons.alert; size: 14; strokeWidth: 2.2; color: Theme.danger }
                    Text {
                        width: parent.width - 22
                        text: modelData.message || ""
                        textFormat: Text.PlainText
                        wrapMode: Text.Wrap
                        lineHeight: 1.15
                        font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
                        color: Theme.danger
                    }
                }
            }
            Repeater {
                model: root.d ? root.d.notes || [] : []
                delegate: Hint { required property var modelData; width: found.width; text: modelData }
            }
        }
    }

    // ---- the fields --------------------------------------------------------------------------------
    Column {
        visible: !!root.d && !root.blocked
        width: root.width
        spacing: 16

        Column {
            width: parent.width
            spacing: 8
            Label { text: "NAME" }
            TextField {
                onTextChanged: if (!inputItem.activeFocus) inputItem.cursorPosition = 0
                width: parent.width
                text: root.d ? root.d.name || "" : ""
                placeholder: "My Game Server"
                enabled: !root.saving
                Accessible.name: "Name"
                onEdited: (t) => root.call("draft", "name", t)
            }
        }
        Column {
            width: parent.width
            spacing: 8
            Label { text: "PROGRAM" }
            TextField {
                width: parent.width
                mono: true
                text: root.d ? root.d.exec || "" : ""
                placeholder: "Game Server.x86_64"
                enabled: !root.saving
                Accessible.name: "Program"
                onTextChanged: if (!inputItem.activeFocus) inputItem.cursorPosition = 0
                onEdited: (t) => root.call("draft", "exec", t)
            }
        }
        Column {
            width: parent.width
            spacing: 8
            Label { text: "ARGUMENTS" }
            TextField {
                id: argsField
                width: parent.width
                mono: true
                text: root.d ? root.d.argsText || "" : ""
                placeholder: "-port 7770 -maxplayers 10"
                enabled: !root.saving
                Accessible.name: "Arguments"
                onTextChanged: if (!inputItem.activeFocus) inputItem.cursorPosition = 0
                onEdited: (t) => root.call("draft", "argsText", t)
            }
            Hint {
                width: parent.width
                text: root.d && root.d.kind === "unity" ? "Your game’s own options. Quasar adds ‑batchmode ‑nographics itself."
                                                        : "Add your game’s own options, like ‑port 7770 or ‑maxplayers 10."
            }
            // What would stop the server, with the fix when there is one. Not blocking.
            Repeater {
                model: root.warnings
                delegate: Column {
                    required property var modelData
                    width: root.width
                    spacing: 6
                    Row {
                        width: parent.width
                        spacing: 8
                        QIcon { path: Icons.alert; size: 14; strokeWidth: 2.2; color: Theme.amber }
                        Text {
                            width: parent.width - 22
                            text: modelData.text
                            textFormat: Text.PlainText
                            wrapMode: Text.Wrap
                            lineHeight: 1.15
                            font.family: Theme.fontUi; font.pixelSize: 12
                            color: Theme.amber
                        }
                    }
                    Button {
                        visible: !!modelData.fix
                        x: 22
                        variant: "ghost"; size: 28; glyph: Icons.plus
                        text: modelData.fix ? "List " + modelData.fix.proto.toUpperCase() + " " + modelData.fix.port : ""
                        enabled: !root.saving
                        onClicked: root.call("listPort", modelData.fix.proto, modelData.fix.port)
                    }
                }
            }
            // What the game's own scripts read (inspect's flags): one click adds one.
            Column {
                visible: root.chips.shown.length > 0 || root.showAllFlags
                width: parent.width
                spacing: 6
                topPadding: 2
                Hint { width: parent.width; text: "Options " + (root.d && root.d.name ? root.d.name : "it") + " reads" }
                Flow {
                    width: parent.width
                    spacing: 6
                    Repeater {
                        model: root.chips.shown
                        delegate: FlagChip {
                            required property var modelData
                            text: modelData.flag
                            accessibleName: "Add " + modelData.flag
                            enabled: !root.saving
                            onClicked: root.addFlag(modelData)
                        }
                    }
                    FlagChip {
                        visible: root.chips.more > 0 || root.showAllFlags
                        glyph: ""
                        mono: false
                        text: root.showAllFlags ? "Fewer" : root.chips.more + " more"
                        accessibleName: root.showAllFlags ? "Show fewer options" : "Show " + root.chips.more + " more options"
                        onClicked: root.showAllFlags = !root.showAllFlags
                    }
                }
            }
        }

        // How it runs: servers are always running (the template's other two kinds are for your own apps).
        Column {
            width: parent.width
            spacing: 8
            Label { text: "HOW IT RUNS" }
            Rectangle {
                width: parent.width
                height: 58
                radius: 13
                color: Theme.alpha(Theme.accent, 0.08)
                border.width: 1.5
                border.color: Theme.alpha(Theme.accent, 0.45)
                Accessible.role: Accessible.RadioButton
                Accessible.name: "Always running"
                Accessible.checked: true
                QIcon { id: alwaysIcon; x: 12; anchors.verticalCenter: parent.verticalCenter; path: Icons.cycle; size: 18; strokeWidth: 1.9; color: Theme.accent }
                Column {
                    anchors { left: alwaysIcon.right; leftMargin: 12; right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter }
                    spacing: 2
                    Text { text: "Always running"; font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5); font.weight: Font.DemiBold; color: Theme.text }
                    Text {
                        width: parent.width
                        text: "Kept alive in the background"
                        elide: Text.ElideRight
                        font.family: Theme.fontUi; font.pixelSize: 12
                        color: Theme.textDim
                    }
                }
            }
            Rectangle {
                width: parent.width
                height: 56
                radius: 12
                color: Theme.white(0.035)
                Column {
                    anchors { left: parent.left; leftMargin: 12; right: restartSw.left; rightMargin: 12; verticalCenter: parent.verticalCenter }
                    spacing: 2
                    Text { text: "Restart if it crashes"; font.family: Theme.fontUi; font.pixelSize: 13; font.weight: Font.Medium; color: Theme.text }
                    Text {
                        width: parent.width
                        text: "Up to 5 times a minute, then marks it failed"
                        elide: Text.ElideRight
                        font.family: Theme.fontUi; font.pixelSize: 12
                        color: Theme.textDim
                    }
                }
                QSwitch {
                    id: restartSw
                    anchors { right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter }
                    checked: !!root.d && root.d.restart !== false
                    accessibleName: "Restart if it crashes"
                    enabled: !root.saving
                    onToggled: root.call("draft", "restart", !(root.d && root.d.restart !== false))
                }
            }
        }

        // Who can join, port by port.
        Column {
            width: parent.width
            spacing: 8
            Label { text: "WHO CAN JOIN" }
            Repeater {
                model: root.d ? root.d.ports || [] : []
                delegate: Rectangle {
                    id: portCard
                    required property var modelData
                    required property int index
                    readonly property string err: root.d ? S.portProblem(root.d.ports || [], index) : ""
                    width: root.width
                    height: portCol.implicitHeight + 20
                    radius: 12
                    color: Theme.white(0.035)
                    border.width: 1
                    border.color: err ? Qt.rgba(1, 143 / 255, 143 / 255, 0.35) : "transparent"
                    Column {
                        id: portCol
                        x: 10; y: 10
                        width: parent.width - 20
                        spacing: 8
                        Row {
                            width: parent.width
                            spacing: 6
                            Segmented {
                                id: protoSeg
                                width: 96; height: 34
                                model: ["UDP", "TCP"]
                                currentIndex: portCard.modelData.proto === "tcp" ? 1 : 0
                                accessibleName: "Protocol"
                                onPicked: (i) => root.call("port", portCard.index, "proto", i === 1 ? "tcp" : "udp")
                            }
                            TextField {
                                onTextChanged: if (!inputItem.activeFocus) inputItem.cursorPosition = 0
                                width: 74; height: 34
                                mono: true
                                text: String(portCard.modelData.port === undefined || portCard.modelData.port === null ? "" : portCard.modelData.port)
                                placeholder: "7770"
                                error: portCard.err !== ""
                                enabled: !root.saving
                                Accessible.name: "Port"
                                onEdited: (t) => root.call("port", portCard.index, "port", t.trim())
                            }
                            TextField {
                                onTextChanged: if (!inputItem.activeFocus) inputItem.cursorPosition = 0
                                width: parent.width - protoSeg.width - 74 - rmPort.width - 3 * parent.spacing
                                height: 34
                                text: portCard.modelData.label || ""
                                placeholder: "What it’s for"
                                enabled: !root.saving
                                Accessible.name: "Label"
                                onEdited: (t) => root.call("port", portCard.index, "label", t)
                            }
                            Pressable {
                                id: rmPort
                                width: 30; height: 34; radius: 8; kind: "hov"
                                accessibleName: "Remove this port"
                                onClicked: root.call("removePort", portCard.index)
                                QIcon { anchors.centerIn: parent; path: Icons.x; size: 13; strokeWidth: 2.2; color: Theme.textMuted }
                            }
                        }
                        Segmented {
                            width: parent.width; height: 34
                            model: ["This PC", "Home network", "Internet"]
                            currentIndex: portCard.modelData.reach === "internet" ? 2 : portCard.modelData.reach === "home" ? 1 : 0
                            accessibleName: "Who can reach " + S.portText(portCard.modelData)
                            onPicked: (i) => root.call("port", portCard.index, "reach", ["this-pc", "home", "internet"][i])
                        }
                        Hint {
                            visible: portCard.err !== ""
                            width: parent.width
                            text: portCard.err
                            color: Theme.danger
                        }
                    }
                }
            }
            Button {
                variant: "ghost"; size: 30; glyph: Icons.plus; text: "Add a port"
                enabled: !root.saving && (!root.d || (root.d.ports || []).length < 16)
                onClicked: root.call("addPort")
            }
        }

        // The internet: said plainly, plus the name players use (for the guide).
        Rectangle {
            visible: !!root.d && S.hasInternet(root.d.ports)
            width: parent.width
            height: netCol.implicitHeight + 24
            radius: 12
            color: Theme.alpha(Theme.amber, 0.08)
            border.width: 1
            border.color: Theme.alpha(Theme.amber, 0.3)
            Column {
                id: netCol
                x: 12; y: 12
                width: parent.width - 24
                spacing: 10
                Row {
                    width: parent.width
                    spacing: 8
                    QIcon { path: Icons.globe; size: 15; strokeWidth: 2; color: Theme.amber }
                    Text {
                        width: parent.width - 23
                        text: "Anyone on the internet can send packets to " + (root.d ? S.internetPorts(root.d.ports).map(S.portText).join(" and ") : "")
                              + " on this PC, and players can see your home’s internet address. Nothing else opens."
                        textFormat: Text.PlainText
                        wrapMode: Text.Wrap
                        lineHeight: 1.15
                        font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
                        color: Theme.text2
                    }
                }
                Hint { width: parent.width; text: "Name players use (optional)" }
                TextField {
                    onTextChanged: if (!inputItem.activeFocus) inputItem.cursorPosition = 0
                    width: parent.width; height: 34
                    mono: true
                    text: root.d ? root.d.publicName || "" : ""
                    placeholder: "game.example.com"
                    enabled: !root.saving
                    Accessible.name: "Name players use"
                    onEdited: (t) => root.call("draft", "publicName", t.trim())
                }
                Hint { width: parent.width; text: "It points at (your router’s dynamic DNS name)" }
                TextField {
                    onTextChanged: if (!inputItem.activeFocus) inputItem.cursorPosition = 0
                    width: parent.width; height: 34
                    mono: true
                    text: root.d ? root.d.publicVia || "" : ""
                    placeholder: "home.example.com"
                    enabled: !root.saving
                    Accessible.name: "Dynamic DNS name"
                    onEdited: (t) => root.call("draft", "publicVia", t.trim())
                }
            }
        }

        Hint {
            visible: !!root.m.company
            width: parent.width
            text: "Servers run on this PC’s own network, not inside " + (root.m.company ? root.m.company.name : "a company") + "."
        }

        // Settings only: a memory limit.
        Column {
            visible: root.editing
            width: parent.width
            spacing: 8
            Label { text: "MEMORY LIMIT" }
            Segmented {
                width: parent.width; height: 34
                model: ["None", "1 GB", "2 GB", "4 GB", "8 GB"]
                readonly property var values: [null, "1G", "2G", "4G", "8G"]
                currentIndex: Math.max(0, values.indexOf(root.d ? root.d.memoryMax || null : null))
                accessibleName: "Memory limit"
                onPicked: (i) => root.call("draft", "memoryMax", values[i])
            }
        }

        Rectangle {
            visible: !root.editing
            width: parent.width
            height: previewText.implicitHeight + 24
            radius: 12
            color: Theme.accentTint
            border.width: 1
            border.color: Theme.accentLine
            Text {
                id: previewText
                x: 14; y: 12
                width: parent.width - 28
                text: root.d ? S.previewText(root.d) : ""
                textFormat: Text.PlainText
                wrapMode: Text.Wrap
                lineHeight: 1.2
                font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
                color: Theme.text2
            }
        }
    }

    Hint {
        visible: !!root.d && !root.blocked && root.problem !== ""
        width: root.width
        text: root.problem
        color: Theme.danger
    }

    Banner {
        visible: !!root.m.formError
        width: root.width
        tone: "error"
        title: root.m.formError ? root.m.formError.message || "" : ""
        details: root.m.formError ? root.m.formError.details || "" : ""
    }

    Row {
        spacing: 8
        Button {
            visible: !root.blocked
            variant: "primary"; size: 40
            text: root.editing ? "Save" : "Add service"
            busy: root.saving
            enabled: !!root.d && root.problem === "" && !root.saving && !root.m.inspecting
            onClicked: root.call(root.editing ? "save" : "add")
        }
        Button {
            variant: "outline"; size: 40; text: "Cancel"; fg: Theme.text
            enabled: !root.saving
            onClicked: root.call("closeForm")
        }
    }
}
