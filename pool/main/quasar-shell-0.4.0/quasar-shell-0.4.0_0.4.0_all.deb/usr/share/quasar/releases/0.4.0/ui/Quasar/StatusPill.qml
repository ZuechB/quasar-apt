import QtQuick

// Small status pill (template Terminal title bar / Sessions cards): 22px, fully rounded, colour at
// .12 behind a 6px dot and 11px/600 label. The dot pulses (opacity .55 <-> 1) only while `pulse`
// is set and the pill is visible, and never in Lite or with reduced motion.
Rectangle {
    id: root
    property string text: ""
    property color tone: Theme.accent
    property bool pulse: false
    property string glyph: ""

    implicitHeight: 22
    implicitWidth: row.implicitWidth + 16
    radius: height / 2
    color: Theme.alpha(tone, 0.12)
    Accessible.role: Accessible.StaticText
    Accessible.name: text

    Row {
        id: row
        anchors.centerIn: parent
        spacing: 6
        Rectangle {
            id: dot
            visible: root.glyph === ""
            anchors.verticalCenter: parent.verticalCenter
            width: 6; height: 6; radius: 3
            color: root.tone
            SequentialAnimation on opacity {
                running: root.pulse && root.visible && Theme.ambientMotion
                loops: Animation.Infinite
                alwaysRunToEnd: true
                NumberAnimation { from: 1; to: 0.55; duration: 1000; easing.type: Easing.InOutSine }
                NumberAnimation { from: 0.55; to: 1; duration: 1000; easing.type: Easing.InOutSine }
            }
        }
        QIcon {
            visible: root.glyph !== ""
            anchors.verticalCenter: parent.verticalCenter
            path: root.glyph; size: 12; strokeWidth: 2.2; color: root.tone
        }
        Text {
            anchors.verticalCenter: parent.verticalCenter
            text: root.text
            textFormat: Text.PlainText
            font.family: Theme.fontUi; font.pixelSize: 11; font.weight: Font.DemiBold
            color: root.tone
        }
    }
}
