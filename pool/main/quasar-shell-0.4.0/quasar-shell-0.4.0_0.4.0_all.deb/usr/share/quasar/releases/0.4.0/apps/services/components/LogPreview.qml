import QtQuick
import Quasar

// The detail pane's LOGS box (template: "LOGS · journald, live", #06070B, 200px): the newest lines of the
// selected service, live, with Open console (its own window) and Open in Terminal. Pure.
//   lines: m.logs, [{ n, t, m, lvl, src?, unit? }] (the newest 200, n rising; [] when another service is shown)
Column {
    id: root
    property var lines: []
    signal openConsole()
    signal openTerminal()
    spacing: 8

    property int _lastN: -1
    function sync() {
        const l = lines || []
        if (!l.length) { list.clear(); _lastN = -1; return }
        if (l[l.length - 1].n < _lastN) { list.clear(); _lastN = -1 }      // started over
        const add = []
        for (const x of l) if (x.n > _lastN) add.push(x)
        if (add.length) { list.append(add); _lastN = add[add.length - 1].n }
    }
    onLinesChanged: sync()
    Component.onCompleted: sync()

    Item {
        width: root.width
        height: 28
        Text {
            x: 2
            anchors.verticalCenter: parent.verticalCenter
            text: "LOGS"
            font.family: Theme.fontMono; font.pointSize: Theme.pt(10.5); font.letterSpacing: 1.05
            color: Theme.textFaint
        }
        Row {
            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
            spacing: 4
            Button {
                variant: "ghost"; size: 28; glyph: Icons.terminal; text: "Terminal"
                accessibleName: "Open its log in Terminal"
                onClicked: root.openTerminal()
            }
            Button {
                variant: "soft"; size: 28; glyph: Icons.open; text: "Open console"
                onClicked: root.openConsole()
            }
        }
    }
    Rectangle {
        width: root.width
        height: 200
        radius: 12
        color: "#06070B"
        border.width: 1
        border.color: Theme.white(0.06)
        LogList {
            id: list
            anchors.fill: parent
            anchors.margins: 8
            compact: true
            cap: 400
            emptyText: "No log lines yet."
        }
    }
}
