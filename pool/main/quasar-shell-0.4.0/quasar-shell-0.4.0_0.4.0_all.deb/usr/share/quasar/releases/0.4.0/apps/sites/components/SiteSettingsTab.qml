import QtQuick
import Quasar

// Template Sites › Settings: switches, then "Remove site" with the inline confirmation.
Column {
    id: root
    property var site: null
    property bool confirming: false
    property bool busy: false
    signal setOption(string key, bool on)
    signal askRemove()
    signal cancelRemove()
    signal remove()

    spacing: 12
    readonly property var opts: site ? site.options || {} : {}
    readonly property bool app: !!site && site.kind !== "static"

    SettingsGroup {
        width: parent.width
        SettingsRow {
            width: parent.width
            label: "Start when Quasar starts"
            sub: root.app ? "Runs as site-" + (root.site ? root.site.id : "") + " with its own account" : "Served by the proxy whenever Sites is on"
            trailing: root.app ? "toggle" : "value"
            value: root.app ? "" : "Always"
            checked: root.opts.boot !== false
            onToggled: root.setOption("boot", !checked)
        }
        SettingsRow {
            visible: root.app
            width: parent.width
            label: "Restart if it crashes"
            sub: "Up to 5 times a minute, then marks it crashed"
            trailing: "toggle"
            checked: root.opts.crashRestart !== false
            onToggled: root.setOption("crashRestart", !checked)
        }
        SettingsRow {
            visible: root.app
            width: parent.width
            label: "Stop the old version first"
            sub: "For apps that run migrations or background jobs at startup. Visitors see a short pause."
            trailing: "toggle"
            checked: root.opts.stopFirst === true
            onToggled: root.setOption("stopFirst", !checked)
        }
        SettingsRow {
            width: parent.width
            label: "Deploy on push to main"
            sub: "Checks the Git remote every minute"
            trailing: "soon"
        }
        SettingsRow {
            width: parent.width
            label: "Watch files and reload"
            sub: "For development. Rebuilds when you save."
            trailing: "soon"
        }
    }

    Button {
        visible: !root.confirming
        variant: "outline"; size: 36
        glyph: Icons.trash; text: "Remove site"
        fg: Theme.danger
        enabled: !root.busy
        onClicked: root.askRemove()
    }
    Rectangle {
        visible: root.confirming
        width: parent.width
        height: confirmCol.implicitHeight + 28
        radius: 16
        color: Theme.alpha(Theme.danger, 0.08)
        border.width: 1; border.color: Theme.alpha(Theme.danger, 0.3)
        Accessible.role: Accessible.AlertMessage
        Column {
            id: confirmCol
            anchors { left: parent.left; right: parent.right; top: parent.top; margins: 14 }
            spacing: 12
            Text {
                width: parent.width
                wrapMode: Text.WordWrap
                text: "Remove " + (root.site ? root.site.name : "") + "? Its service, address, certificate and saved data are deleted. Your project folder stays as it is."
                font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
                color: Theme.text
            }
            Row {
                spacing: 8
                Button { variant: "primary"; tone: Theme.danger; size: 34; text: "Remove"; busy: root.busy; enabled: !root.busy; onClicked: root.remove() }
                Button { variant: "outline"; size: 34; text: "Keep it"; onClicked: root.cancelRemove() }
            }
        }
    }
}
