import QtQuick
import Quasar

// Store detail, developer tools (mise): the version line to install (the catalog's channels: LTS,
// Latest, 3.13 …), the versions installed for this account with the default one marked, Make default
// and Remove per version, and "Other version…" (any release; the Store then asks the tool's own
// server for the list). Pure view.
Column {
    id: root
    property var app: null                 // catalog entry + versions (newest first) + activeVersion + state
    property bool loadingVersions: false
    property int channelIndex: 0
    signal installClicked(string spec)
    signal defaultClicked(string version)
    signal removeClicked(string version)
    signal otherClicked()

    readonly property var channels: app && app.channels ? app.channels : []
    readonly property string selectedSpec: channels.length ? channels[Math.min(channelIndex, channels.length - 1)].spec : ""
    readonly property var versions: app && app.versions ? app.versions : []
    readonly property string active: app ? app.activeVersion || "" : ""
    readonly property bool busy: !!app && (app.state === "busy" || app.state === "queued")

    spacing: 10
    width: parent ? parent.width : 640

    Item {
        width: parent.width; height: verTitle.implicitHeight
        SectionLabel { id: verTitle; text: "Versions" }
        Text {
            anchors { right: parent.right; baseline: verTitle.baseline }
            text: "Installed for your account"
            font.family: Theme.fontUi; font.pixelSize: 12
            color: Theme.textDim
        }
    }

    // Installed versions (newest first).
    Rectangle {
        visible: root.versions.length > 0
        width: parent.width
        height: rows.implicitHeight
        radius: 16
        color: Theme.white(0.035)
        border.width: 1; border.color: Theme.white(0.06)
        Column {
            id: rows
            width: parent.width
            Repeater {
                model: root.versions
                Item {
                    id: verRow
                    required property int index
                    required property var modelData
                    readonly property bool isDefault: modelData === root.active
                    width: rows.width
                    height: 52
                    Rectangle { visible: index > 0; width: parent.width; height: 1; color: Theme.white(0.05) }
                    Row {
                        x: 16; anchors.verticalCenter: parent.verticalCenter
                        spacing: 10
                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            text: (root.app ? root.app.name + " " : "") + modelData
                            font.family: Theme.fontUi; font.pixelSize: 14; font.weight: Font.DemiBold; font.features: { "tnum": 1 }
                            color: Theme.text
                        }
                        Chip {
                            anchors.verticalCenter: parent.verticalCenter
                            visible: verRow.isDefault
                            text: "Default"; glyph: Icons.check
                            tone: Theme.accent; fill: Theme.alpha(Theme.accent, 0.12)
                        }
                    }
                    Row {
                        anchors { right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter }
                        spacing: 6
                        Button {
                            visible: !verRow.isDefault
                            enabled: !root.busy
                            text: "Make default"
                            variant: "soft"; size: 30
                            onClicked: root.defaultClicked(modelData)
                        }
                        Button {
                            enabled: !root.busy
                            text: "Remove"
                            variant: "outline"; size: 30
                            accessibleName: "Remove " + modelData
                            onClicked: root.removeClicked(modelData)
                        }
                    }
                }
            }
        }
    }

    // Which version line to install (first one = what Get installs), plus any other release.
    Item {
        width: parent.width
        height: 34
        Text {
            id: pickLabel
            anchors.verticalCenter: parent.verticalCenter
            text: root.versions.length ? "Add a version" : "Version to install"
            font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
            color: Theme.text3
        }
        Row {
            anchors { left: pickLabel.right; leftMargin: 14; verticalCenter: parent.verticalCenter }
            spacing: 8
            Segmented {
                visible: root.channels.length > 1
                anchors.verticalCenter: parent.verticalCenter
                width: Math.min(330, 96 * root.channels.length)
                model: root.channels.map(c => c.label)
                currentIndex: root.channelIndex
                accessibleName: "Version to install"
                onPicked: (i) => root.channelIndex = i
            }
            Chip {
                visible: root.channels.length === 1
                anchors.verticalCenter: parent.verticalCenter
                text: root.channels.length === 1 ? root.channels[0].label : ""
            }
            Button {
                visible: root.versions.length > 0
                enabled: !root.busy
                anchors.verticalCenter: parent.verticalCenter
                text: "Install"; glyph: Icons.download
                variant: "soft"; size: 30
                onClicked: root.installClicked(root.selectedSpec)
            }
            Button {
                enabled: !root.busy && !root.loadingVersions
                busy: root.loadingVersions
                anchors.verticalCenter: parent.verticalCenter
                text: "Other version…"
                variant: "ghost"; size: 30
                onClicked: root.otherClicked()
            }
        }
    }

    Text {
        width: Math.min(640, parent.width)
        wrapMode: Text.Wrap
        lineHeight: 1.2
        text: "The default is used everywhere. A project can ask for its own version with a version file (.nvmrc, .python-version, global.json, mise.toml …)."
              + (root.app && root.app.from ? " Downloads come from " + root.app.from + " and only start when you press a button here." : "")
        font.family: Theme.fontUi; font.pixelSize: 12
        color: Theme.textDim
    }
}
