import QtQuick
import Quickshell
import Quickshell.Io
import Quasar.Services

// VPN profiles and the hotspot as NetworkManager has them right now (`nm-ctl list`, as the user), for
// the Network, VPN and Mobile hotspot pages. Read when one of them opens, after every change made here,
// and whenever the root-written state file changes (a VPN connects or drops, the hotspot starts or
// stops: NetState). Nothing is polled.
//   QUASAR_NM_CTL=/path: a stand-in for nm-ctl (tools/fake-net.py), for every nm-ctl call in Settings.
Scope {
    id: root
    property bool active: false
    property var st: null                  // { vpns: […], hotspot: {…} }
    readonly property string exe: Quickshell.env("QUASAR_NM_CTL") || "/usr/libexec/quasar/nm-ctl"

    onActiveChanged: if (active) refresh()
    Connections {
        target: NetState
        function onDataChanged() { if (root.active) root.refresh() }
    }

    property bool _again: false
    function refresh() {
        if (proc.running) { _again = true; return }
        proc.running = true
    }
    Process {
        id: proc
        command: [root.exe, "list"]
        stdout: StdioCollector {
            onStreamFinished: {
                const lines = text.trim().split("\n")
                try {
                    const o = JSON.parse(lines[lines.length - 1])
                    if (o.result === "ok") root.st = o
                } catch (e) { }
            }
        }
        onExited: (code, status) => { if (root._again) { root._again = false; running = true } }
    }
}
