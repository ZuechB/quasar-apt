import QtQuick

// Inline message (errors from installs, settings that failed to apply): one plain sentence, an
// optional action, and a "Details" disclosure with the technical log (monospace, scrollable,
// copyable) — the raw output is never the headline.
Rectangle {
    id: root
    property string tone: "error"              // error | warning | info | success
    property string title: ""
    property string message: ""
    property string details: ""
    property string actionText: ""
    property bool expanded: false
    signal actionClicked()
    signal dismissed()

    readonly property color toneColor: tone === "error" ? Theme.danger : tone === "warning" ? Theme.amber
                                     : tone === "success" ? Theme.mint : Theme.accent
    readonly property string toneGlyph: tone === "success" ? Icons.check : tone === "info" ? Icons.info : Icons.alert

    implicitHeight: col.implicitHeight + 28
    width: parent ? parent.width : 520
    radius: 14
    color: Theme.alpha(toneColor, 0.07)
    border.width: 1
    border.color: Theme.alpha(toneColor, 0.28)
    Accessible.role: Accessible.AlertMessage
    Accessible.name: title + ". " + message

    QIcon {
        id: icon
        x: 14; y: 15
        path: root.toneGlyph; size: 18; strokeWidth: 2
        color: root.toneColor
    }
    Column {
        id: col
        anchors { left: icon.right; leftMargin: 12; right: parent.right; rightMargin: 14; top: parent.top; topMargin: 14 }
        spacing: 6
        Text {
            width: parent.width
            visible: root.title !== ""
            text: root.title
            textFormat: Text.PlainText
            wrapMode: Text.Wrap
            font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5); font.weight: Font.DemiBold
            color: Theme.text
        }
        Text {
            width: parent.width
            visible: root.message !== ""
            text: root.message
            textFormat: Text.PlainText
            wrapMode: Text.Wrap
            font.family: Theme.fontUi; font.pixelSize: 13
            color: Theme.text3
        }
        Row {
            spacing: 8
            visible: root.actionText !== "" || root.details !== ""
            Button {
                visible: root.actionText !== ""
                text: root.actionText
                variant: "soft"; size: 30
                onClicked: root.actionClicked()
            }
            Button {
                visible: root.details !== ""
                text: root.expanded ? "Hide details" : "Details"
                glyph: root.expanded ? Icons.up : Icons.chev
                variant: "ghost"; size: 30
                onClicked: root.expanded = !root.expanded
            }
            Button {
                visible: root.details !== "" && root.expanded
                text: "Copy details"
                variant: "ghost"; size: 30
                onClicked: { clip.text = root.details; clip.selectAll(); clip.copy() }
            }
        }
        Rectangle {
            visible: root.expanded && root.details !== ""
            width: parent.width
            height: Math.min(180, log.implicitHeight + 16)
            radius: 10
            color: Qt.rgba(0, 0, 0, 0.35)
            Flickable {
                anchors.fill: parent
                anchors.margins: 8
                contentHeight: log.implicitHeight
                clip: true
                boundsBehavior: Flickable.StopAtBounds
                TextEdit {
                    id: log
                    width: parent.width
                    readOnly: true
                    selectByMouse: true
                    wrapMode: TextEdit.WrapAnywhere
                    textFormat: TextEdit.PlainText
                    text: root.details
                    font.family: Theme.fontMono; font.pointSize: Theme.pt(11)
                    color: Theme.textMuted
                }
            }
        }
    }
    TextEdit { id: clip; visible: false; textFormat: TextEdit.PlainText }
}
