import QtQuick
import QtQuick.Shapes

// Default local-account emblem from the mockup (28-unit viewBox): dark disc, accent diamond, amber core.
Item {
    id: root
    property real size: 30
    implicitWidth: size
    implicitHeight: size
    layer.enabled: Theme.softwareRender         // clips when scrolled away (see Theme.softwareRender)

    Item {
        width: 28; height: 28
        scale: root.size / 28
        transformOrigin: Item.TopLeft
        Rectangle {
            x: 1; y: 1; width: 26; height: 26; radius: 13
            color: "#141826"
            border.width: 1
            border.color: Theme.white(0.14)
        }
        Shape {
            anchors.fill: parent
            preferredRendererType: Shape.CurveRenderer
            ShapePath {
                strokeColor: Theme.accent
                strokeWidth: 1.4
                fillColor: "transparent"
                joinStyle: ShapePath.MiterJoin
                PathSvg { path: "M14 4 L22 14 L14 24 L6 14 Z" }
            }
        }
        Rectangle { x: 14 - 3.4; y: 14 - 3.4; width: 6.8; height: 6.8; radius: 3.4; color: Theme.amber }
    }
}
