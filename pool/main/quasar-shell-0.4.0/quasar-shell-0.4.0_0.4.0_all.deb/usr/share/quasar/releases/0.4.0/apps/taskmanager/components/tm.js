// Task Manager: pure helpers (no Quickshell), shared by the app (apps/taskmanager/shell.qml), its views and
// the preview. Data comes from /usr/libexec/quasar/sysmon watch (protocol in linux/system/sysmon/quasar_sysmon):
//   info  { cpu {model, cores, threads, maxMHz}, memory {total}, gpus [...], disks [...], nets [...] }
//   tick  { cpu {...}, mem {...}, disks [...], nets [...], gpus [...], groups [...], procs { key: [...] } }
// Groups use netguard's keys: app:<desktop id>, unit:<user unit>, sys:<system service>, company:<id>, user:<name>.
.pragma library

// ---- numbers -------------------------------------------------------------------------------------------
function bytes(b) {
    const v = Number(b) || 0
    if (v < 1024) return Math.round(v) + " B"
    const units = ["KB", "MB", "GB", "TB"]
    let x = v / 1024, i = 0
    while (x >= 1024 && i < units.length - 1) { x /= 1024; i++ }
    return (x >= 100 || i === 0 ? Math.round(x) : x.toFixed(1)) + " " + units[i]
}

// Disk speeds: bytes per second.
function rate(bps) {
    if (bps === null || bps === undefined) return "—"
    const v = Number(bps) || 0
    return v < 1024 ? "0 KB/s" : bytes(v) + "/s"
}

// Network speeds: bits per second (how network speeds are sold and shown).
function bits(bps) {
    if (bps === null || bps === undefined) return "—"
    const b = (Number(bps) || 0) * 8
    if (b < 1000) return "0 Kbps"
    if (b < 1e6) return Math.round(b / 1e3) + " Kbps"
    if (b < 1e9) return (b / 1e6).toFixed(b < 1e7 ? 1 : 0) + " Mbps"
    return (b / 1e9).toFixed(1) + " Gbps"
}

function pct(p) {
    if (p === null || p === undefined || isNaN(p)) return "—"
    const v = Math.max(0, Number(p))
    return (v > 0 && v < 10 ? v.toFixed(1) : Math.round(v)) + "%"
}

function ghz(mhz) { return mhz ? (mhz / 1000).toFixed(2) + " GHz" : "—" }

function uptime(s) {
    const t = Math.max(0, Math.floor(Number(s) || 0))
    const d = Math.floor(t / 86400), h = Math.floor(t % 86400 / 3600), m = Math.floor(t % 3600 / 60)
    if (d > 0) return d + (d === 1 ? " day " : " days ") + h + " h"
    if (h > 0) return h + " h " + m + " min"
    return m + " min"
}

function temp(c) { return c === null || c === undefined ? "—" : Math.round(c) + " °C" }

// A cell's tint: busier is warmer (like the Windows Task Manager's yellow cells), 0 .. 0.26 alpha.
function heat(value, full) {
    const v = Number(value) || 0
    return v <= 0 ? 0 : Math.min(0.26, 0.05 + 0.21 * Math.min(1, v / full))
}

// ---- what a group is -----------------------------------------------------------------------------------
// Ending these can make the PC stop working until a restart (asked first, admin or not).
const CRITICAL = {
    "sys:systemd-logind": "Signs everyone out and can stop the PC from working until you restart it.",
    "sys:dbus": "Desktop services stop working until you restart the PC.",
    "sys:dbus-broker": "Desktop services stop working until you restart the PC.",
    "sys:systemd-journald": "System logs stop until you restart the PC.",
    "sys:systemd-udevd": "New devices aren't noticed until you restart the PC.",
    "sys:polkit": "Password prompts stop working until you restart the PC.",
    "sys:greetd": "Ends every desktop session and the sign-in screen.",
    "sys:display-manager": "Ends every desktop session and the sign-in screen.",
    "sys:NetworkManager": "Wi-Fi and the network go away until you restart the PC.",
    "sys:systemd-resolved": "Websites stop resolving until you restart the PC.",
    "sys:init": "This is the system itself."
}
const SESSION_WARN = "This is the desktop session itself (labwc): ending it closes all your apps and signs you out."

function isDesktop(g) { return g && g.key === "unit:quasar-shell" }

// Which list a group goes in: apps with a window (and the desktop itself, like Windows Explorer), other
// things of yours, each company, and the system.
function section(g, ctx) {
    if (g.kind === "company") return "company:" + (g.company || g.key.slice(8))
    if (g.kind === "system" || g.kind === "user") return "system"
    if (isDesktop(g)) return "apps"
    if (g.appId && ctx.windows && ctx.windows[g.appId]) return "apps"
    return "background"
}

function sectionLabel(s, ctx) {
    if (s === "apps") return "Apps"
    if (s === "background") return "Background programs"
    if (s === "system") return "System and other accounts"
    const id = s.slice(8)
    return ((ctx.companyNames || {})[id] || id) + " (company)"
}

// The name and picture for a group: the desktop entry's (ctx.app), else what sysmon calls it.
function look(g, ctx) {
    if (isDesktop(g)) return { name: "Quasar desktop", glyph: "desktop" }
    const a = g.appId && ctx.app ? ctx.app(g.appId) : null
    if (a && a.name) return { name: a.name, image: a.image || "", glyph: a.glyph || "", hue: a.hue || "" }
    if (g.kind === "session") return { name: "Desktop session (labwc)", glyph: "window" }
    if (g.kind === "company") return { name: (ctx.companyNames || {})[g.company] || g.label || g.key, glyph: "company" }
    if (g.kind === "system") return { name: g.label || g.key.replace(/^sys:/, ""), glyph: "system" }
    if (g.kind === "user") return { name: g.label || g.user || g.key, glyph: "user" }
    return { name: g.label || g.key.replace(/^(app|unit):/, ""), glyph: g.kind === "app" ? "" : "unit" }
}

const SORTS = { name: 1, cpu: 1, mem: 1, disk: 1, net: 1, gpu: 1 }

function compare(a, b, sort) {
    const col = SORTS[sort.col] ? sort.col : "cpu"
    let d
    if (col === "name") d = a.label.localeCompare(b.label, undefined, { sensitivity: "base", numeric: true })
    else d = (Number(a[col]) || 0) - (Number(b[col]) || 0)
    if (d === 0) d = a.label.localeCompare(b.label)
    return sort.desc ? -d : d
}

function matches(text, q) { return !q || String(text || "").toLowerCase().indexOf(q) >= 0 }

// The Processes list as flat rows: section headers, groups and, under an expanded group, its processes.
//   ctx: { windows: {appId: [titles]}, app(appId) -> {name, image, glyph, hue} | null, companyNames: {id: name},
//          expanded: {key: true}, query, sort: {col, desc} }
// Row: { key, type: "section"|"group"|"proc", label, sub, section, cpu, mem, disk, net, gpu, image, glyph, hue,
//        expandable, expanded, group (the sysmon group, for groups and their processes), proc (for processes) }
function rows(tick, ctx) {
    const groups = (tick && tick.groups) || []
    const procs = (tick && tick.procs) || {}
    const q = (ctx.query || "").trim().toLowerCase()
    const sort = ctx.sort || { col: "cpu", desc: true }
    const bySection = {}
    for (const g of groups) {
        const lk = look(g, ctx)
        const wins = (g.appId && ctx.windows && ctx.windows[g.appId]) || []
        const kids = procs[g.key] || []
        const hit = matches(lk.name, q) || matches(g.appId, q) || matches(g.key, q)
                    || kids.some(p => matches(p.name, q) || matches(p.cmd, q))
        if (!hit) continue
        const s = section(g, ctx)
        const row = {
            key: g.key, type: "group", label: lk.name, section: s,
            sub: wins.length > 1 ? wins.length + " windows" : wins.length === 1 ? wins[0] : (g.pids > 1 ? g.pids + " processes" : ""),
            cpu: g.cpu, mem: g.mem, disk: g.disk, net: g.net, gpu: g.gpu,
            image: lk.image || "", glyph: lk.glyph || "", hue: lk.hue || "",
            expandable: (g.pids || 0) > 0, expanded: !!(ctx.expanded && ctx.expanded[g.key]), group: g, proc: null
        }
        ;(bySection[s] = bySection[s] || []).push(row)
    }
    const order = ["apps", "background"]
    for (const s of Object.keys(bySection).filter(s => s.indexOf("company:") === 0).sort()) order.push(s)
    order.push("system")
    const out = []
    for (const s of order) {
        const list = bySection[s]
        if (!list || !list.length) continue
        list.sort((a, b) => compare(a, b, sort))
        out.push({ key: "section:" + s, type: "section", label: sectionLabel(s, ctx) + " (" + list.length + ")", section: s })
        for (const r of list) {
            out.push(r)
            if (!r.expanded) continue
            const kids = (procs[r.key] || []).slice().sort((a, b) => compare(
                { label: a.name || "", cpu: a.cpu, mem: a.mem, disk: a.disk, net: 0, gpu: a.gpu },
                { label: b.name || "", cpu: b.cpu, mem: b.mem, disk: b.disk, net: 0, gpu: b.gpu }, sort))
            for (const p of kids)
                out.push({ key: r.key + "/" + p.pid, type: "proc", label: p.name || String(p.pid), section: s,
                           sub: (p.user && r.group.kind !== "app" && r.group.kind !== "unit" ? p.user + "  ·  " : "") + "PID " + p.pid,
                           cpu: p.cpu, mem: p.mem, disk: p.disk, net: null, gpu: p.gpu, glyph: "process",
                           expandable: false, expanded: false, group: r.group, proc: p })
        }
    }
    return out
}

// The column headers' totals (like Windows: "CPU 12%").
function totals(tick) {
    if (!tick) return { cpu: null, mem: null, disk: null, net: null, gpu: null }
    const m = tick.mem || {}
    const disks = tick.disks || [], nets = tick.nets || [], gpus = tick.gpus || []
    return {
        cpu: tick.cpu ? tick.cpu.total : null,
        mem: m.total ? m.used / m.total * 100 : null,
        disk: disks.length ? Math.max.apply(null, disks.map(d => d.busy || 0)) : null,
        net: nets.length ? nets.reduce((s, n) => s + (n.rxBps || 0) + (n.txBps || 0), 0) : null,
        gpu: gpus.some(g => g.busy !== null && g.busy !== undefined) ? Math.max.apply(null, gpus.map(g => g.busy || 0)) : null
    }
}

// ---- the Performance page --------------------------------------------------------------------------------
// One hue per kind of device (the tiles' sparklines and the big graph).
const HUES = { cpu: "#7AB8FF", mem: "#B9A4FF", disk: "#8CF5B0", net: "#FFB86B", netTx: "#FF9BD2", gpu: "#7AE7FF" }

function byKey(list, key) { return (list || []).find(x => x.key === key) || {} }

// The device list: [{ key, kind, title, sub, value, hue, spark (a history key) }].
// History keys (apps/taskmanager/services/SysMon.qml keeps 60 samples of each): cpu, mem, disk:K (active
// time %), diskr:K / diskw:K (bytes/s), netrx:K / nettx:K (bytes/s), gpu:K (busy %), gpumem:K (VRAM %).
function devices(info, tick) {
    if (!info || !tick) return []
    const out = []
    const c = tick.cpu || {}, m = tick.mem || {}
    out.push({ key: "cpu", kind: "cpu", title: "Processor", sub: (info.cpu || {}).model || "",
               value: pct(c.total) + (c.mhz ? "  " + ghz(c.mhz) : ""), hue: HUES.cpu, spark: "cpu" })
    out.push({ key: "mem", kind: "mem", title: "Memory", sub: "",
               value: m.total ? bytes(m.used) + " of " + bytes(m.total) + " (" + pct(m.used / m.total * 100) + ")" : "—",
               hue: HUES.mem, spark: "mem" })
    ;(info.disks || []).forEach((d, i) => {
        const t = byKey(tick.disks, d.key)
        out.push({ key: "disk:" + d.key, kind: "disk", title: "Disk " + i + (d.removable ? " (removable)" : ""),
                   sub: d.name || d.key, value: pct(t.busy), hue: HUES.disk, spark: "disk:" + d.key })
    })
    ;(info.nets || []).forEach(n => {
        const t = byKey(tick.nets, n.key)
        out.push({ key: "net:" + n.key, kind: "net",
                   title: n.kind === "wifi" ? "Wi-Fi" : n.kind === "ethernet" ? "Ethernet" : n.kind === "vpn" ? "VPN" : (n.name || n.key),
                   sub: t.ssid || n.name || n.key, value: t.up === false ? "Not connected" : "↓ " + bits(t.rxBps) + "  ↑ " + bits(t.txBps),
                   hue: HUES.net, spark: "netrx:" + n.key })
    })
    ;(info.gpus || []).forEach((g, i) => {
        const t = byKey(tick.gpus, g.key)
        out.push({ key: "gpu:" + g.key, kind: "gpu", title: "Graphics " + i, sub: g.name || g.key,
                   value: t.busy === null || t.busy === undefined ? (g.driver ? g.driver : "—") : pct(t.busy) + (t.tempC ? "  " + temp(t.tempC) : ""),
                   hue: HUES.gpu, spark: "gpu:" + g.key })
    })
    return out
}

// The selected device's big graph and figures:
// { title, sub, graph: { series: [{ key (history), color }], max (0 = auto), unit: "pct"|"bytes" }, stats: [[label, value]…], note }
function detail(key, info, tick) {
    if (!info || !tick) return null
    if (key === "cpu") {
        const c = tick.cpu || {}, ci = info.cpu || {}
        return { title: "Processor", sub: ci.model || "", graph: { series: [{ key: "cpu", color: HUES.cpu }], max: 100, unit: "pct" },
                 stats: [["Utilization", pct(c.total)], ["Speed", ghz(c.mhz)], ["Processes", String(c.procs || "—")],
                         ["Threads", String(c.threads || "—")], ["Up time", uptime(c.uptime)], ["Cores", String(ci.cores || "—")],
                         ["Logical processors", String(ci.threads || "—")], ["Top speed", ghz(ci.maxMHz)], ["Temperature", temp(c.tempC)]] }
    }
    if (key === "mem") {
        const m = tick.mem || {}
        const z = m.zram
        const stats = [["In use", bytes(m.used)], ["Available", bytes(m.available)], ["Cached", bytes(m.cached)], ["Total", bytes(m.total)]]
        if (m.swapTotal) stats.push(["Swap in use", bytes(m.swapUsed) + " of " + bytes(m.swapTotal)])
        if (z && z.orig) stats.push(["Compressed", bytes(z.orig) + " in " + bytes(z.compr)])
        return { title: "Memory", sub: bytes(m.total), graph: { series: [{ key: "mem", color: HUES.mem }], max: 100, unit: "pct" },
                 stats: stats, bar: m.total ? { used: m.used / m.total, cached: Math.min(1 - m.used / m.total, (m.cached || 0) / m.total) } : null }
    }
    const [kind, k] = [key.slice(0, key.indexOf(":")), key.slice(key.indexOf(":") + 1)]
    if (kind === "disk") {
        const d = byKey(info.disks, k), t = byKey(tick.disks, k)
        return { title: "Disk", sub: d.name || k, graph: { series: [{ key: "disk:" + k, color: HUES.disk }], max: 100, unit: "pct" },
                 stats: [["Active time", pct(t.busy)], ["Read speed", rate(t.readBps)], ["Write speed", rate(t.writeBps)],
                         ["Capacity", bytes(d.size)], ["Used", t.used === null || t.used === undefined ? "—" : bytes(t.used)],
                         ["Free", t.free === null || t.free === undefined ? "—" : bytes(t.free)], ["Removable", d.removable ? "Yes" : "No"]] }
    }
    if (kind === "net") {
        const n = byKey(info.nets, k), t = byKey(tick.nets, k)
        return { title: n.kind === "wifi" ? "Wi-Fi" : n.kind === "ethernet" ? "Ethernet" : n.kind === "vpn" ? "VPN" : "Network",
                 sub: n.name || k, graph: { series: [{ key: "netrx:" + k, color: HUES.net }, { key: "nettx:" + k, color: HUES.netTx }], max: 0, unit: "bytes" },
                 stats: [["Receive", bits(t.rxBps)], ["Send", bits(t.txBps)], ["Network", t.ssid || (t.up === false ? "Not connected" : "—")],
                         ["IPv4 address", t.ipv4 || "—"], ["Adapter", n.key]],
                 legend: [["Receive", HUES.net], ["Send", HUES.netTx]] }
    }
    if (kind === "gpu") {
        const g = byKey(info.gpus, k), t = byKey(tick.gpus, k)
        const vt = t.vramTotal || g.vramTotal
        return { title: "Graphics", sub: g.name || k, graph: { series: [{ key: "gpu:" + k, color: HUES.gpu }], max: 100, unit: "pct" },
                 stats: [["Utilization", pct(t.busy)], ["Dedicated memory", t.vramUsed !== null && t.vramUsed !== undefined && vt ? bytes(t.vramUsed) + " of " + bytes(vt) : (vt ? bytes(vt) : "—")],
                         ["Temperature", temp(t.tempC)], ["Driver", g.driver || "—"]],
                 note: t.busy === null || t.busy === undefined ? "This graphics driver doesn't report how busy it is." : "" }
    }
    return null
}

// ---- ending a task ---------------------------------------------------------------------------------------
// How a row ends, and what to say first:
//   restart   the Quasar desktop: restart it (apps stay open)
//   signout   the desktop session (labwc): sign out
//   unit      your app or program: its units, SIGTERM then SIGKILL (sysmon end --unit)
//   pid       one of your processes (sysmon end --pid --start)
//   company   inside a company (quasar-company exec ID -- sysmon end …): no password, the agent checks you
//   admin     the system's or another account's (pkexec quasar-proc-admin): a password every time
// { how, warn: "" | why it's risky, confirm: bool, verb: "End task" | "Restart" | "Sign out" }
function endPlan(row) {
    if (!row || (row.type !== "group" && row.type !== "proc")) return null
    const g = row.group || {}
    const proc = row.type === "proc" ? row.proc : null
    // Nothing to end: kernel threads, the system itself (PID 1), your own service manager (it runs
    // everything else of yours).
    if (!proc && (g.key === "sys:kernel" || g.key === "sys:init" || g.key === "unit:user-manager")) return null
    if (proc && (g.key === "sys:kernel" || proc.pid === 1)) return null
    if (isDesktop(g) && !proc) return { how: "restart", warn: "", confirm: false, verb: "Restart" }
    if (g.kind === "session") return { how: "signout", warn: SESSION_WARN, confirm: true, verb: "Sign out" }
    if (g.kind === "company")
        return { how: "company", warn: proc ? "" : "Closes every app in this company.", confirm: !proc, verb: "End task" }
    if (g.kind === "system" || g.kind === "user") {
        // Another account (the sign-in screen, someone else signed in) or a service without a unit: one
        // process at a time (open the group). A system service stops as a whole (systemctl stop).
        if (!proc && (g.kind === "user" || !(g.units || []).length)) return null
        const warn = CRITICAL[g.key] || (proc && proc.pid === 1 ? CRITICAL["sys:init"] : "")
        return { how: "admin", warn: warn, confirm: warn !== "", verb: "End task" }
    }
    if (isDesktop(g) && proc) return { how: "restart", warn: "", confirm: false, verb: "Restart" }
    return { how: proc ? "pid" : "unit", warn: "", confirm: false, verb: "End task" }
}

// ---- its log ----------------------------------------------------------------------------------------------
// What "Open log" asks Services for (quasar-services <arg>: a console window, live), or "" when there's nothing
// to read. Services' own servers and sites go by their keys (netguard's sys:svc:<id> / sys:site:<id>); other
// system services and your own background services by their units. Apps (a scope keeps none of their output),
// the session, companies and other accounts have no log to open here.
function logTarget(row) {
    if (!row || (row.type !== "group" && row.type !== "proc")) return ""
    const g = row.group || {}
    const key = String(g.key || "")
    let m = /^sys:svc:([a-z][a-z0-9-]{0,24}[a-z0-9])$/.exec(key)
    if (m) return "log/svc:" + m[1]
    m = /^sys:site:([a-z][a-z0-9-]{0,24}[a-z0-9])$/.exec(key)
    if (m) return "log/site:" + m[1]
    const units = (g.units || []).filter(u => /^[A-Za-z0-9:_.\\@-]+\.service$/.test(u))
    if (!units.length) return ""
    if (g.kind === "system") return "log/service:" + units.join(",")
    if (g.kind === "unit") return "log/userservice:" + units.join(",")
    return ""
}

// The words after an ending: { tone, title, message } for the banner, from the helper's result line
// ({"type":"result","ok":true} / {"type":"error","code","message"}) or pkexec's exit code.
function endResult(name, code, line) {
    if (code === 0) return null
    if (code === 126) return null                          // the password prompt was cancelled: nothing to say
    if (code === 127) return { tone: "error", title: "Quasar couldn't ask for your password", message: "Ending it needs an administrator." }
    let r = null
    try { r = JSON.parse(line || "") } catch (e) { }
    const c = r && r.code
    if (code === 3 || c === "gone") return { tone: "info", title: name + " had already stopped", message: "" }
    if (c === "changed") return { tone: "info", title: name + " had already stopped", message: "Another program took its number since; nothing was ended." }
    if (code === 4 || c === "refused") return { tone: "error", title: "Quasar won't end " + name, message: (r && r.message) || "" }
    return { tone: "error", title: name + " didn't end", message: (r && r.message) || "" }
}
