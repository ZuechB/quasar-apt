import QtQuick
import Quickshell.Io

// A long-running helper stream (services-query watch, units -f, journal KEY -f, stats ID -f): one parsed JSON
// object per line. Runs while `active` is true; a different `cmd` restarts it. Bindings hand it a new array
// on every state push, so only a command with other words counts as different (it used to restart on each
// push: a failing service's log came again and again). A stream that ended stays ended until its command or
// `active` changes, or restart(). Managed imperatively (no binding on `running`, which restarting breaks).
// Set stdinEnabled on streams that should end when the app goes away: the helpers stop at stdin's end.
Process {
    id: stream
    property var cmd: []
    property bool active: false
    property string _key: ""
    signal event(var ev)
    signal ended(int code)

    function _want() { return active && cmd && cmd.length > 0 ? JSON.stringify(cmd) : "" }
    function _sync() {
        const want = _want()
        if (want === _key) return
        _key = want
        if (running) running = false
        if (want !== "") {
            command = cmd
            Qt.callLater(() => { if (stream._key === want && !stream.running) stream.running = true })
        }
    }
    function restart() { _key = ""; _sync() }
    onActiveChanged: _sync()
    onCmdChanged: _sync()
    Component.onCompleted: _sync()

    stdout: SplitParser {
        onRead: (l) => {
            if (l.charAt(0) !== "{") return
            try { stream.event(JSON.parse(l)) } catch (e) { }
        }
    }
    onExited: (code) => stream.ended(code)
}
