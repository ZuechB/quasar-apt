// System snapshots in words and rows (`import Quasar` → SnapKit), from `quasar-snapshot status` /
// /run/quasar/snapshot-state.json: Settings › Storage › Safety and the Snapshots page
// (apps/settings/services/Snapshots.qml), and the installer's Repair (`quasar-snapshot repair-list`).
// Pure JavaScript, so the previews and tools/test-server-js.py use it too.
//   st:  { btrfs, live, auto, bootOnce, free, total,
//          booted: { id, created, … } | null          (this start runs a snapshot)
//          pending: { id, old, at } | null             (a restore waits for the restart)
//          snapshots: [{ id, created, reason: "update"|"manual", description, trigger: { by, verb, what },
//                        version, kernel }] | null      (null: not readable without root yet)
//          old: [{ name, created, from, goodBoots }] }  (the systems kept after a restore)
//   ctx: { busy: "" | "create" | "auto" | "restore" | "delete" | "cancel" | "once", phase, now (seconds),
//          icons, theme }
.pragma library

var MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
var GOOD_BOOTS = 3

function plural(n, one, many) { return n + " " + (n === 1 ? one : (many || one + "s")) }
function pad(n) { return (n < 10 ? "0" : "") + n }

// "Today, 21:15" · "Yesterday, 09:02" · "23 Nov, 21:15" · "23 Nov 2025, 21:15"
function when(t, now) {
    if (!t) return ""
    var d = new Date(t * 1000), n = new Date((now || t) * 1000)
    var time = pad(d.getHours()) + ":" + pad(d.getMinutes())
    var day = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime()
    var today = new Date(n.getFullYear(), n.getMonth(), n.getDate()).getTime()
    if (day === today) return "Today, " + time
    if (today - day === 86400000) return "Yesterday, " + time
    return d.getDate() + " " + MONTHS[d.getMonth()] + (d.getFullYear() !== n.getFullYear() ? " " + d.getFullYear() : "") + ", " + time
}

function size(b) {
    if (!b) return ""
    return b >= 1e12 ? (b / 1e12).toFixed(1) + " TB" : b >= 1e9 ? Math.round(b / 1e9) + " GB" : Math.round(b / 1e6) + " MB"
}

// What a snapshot was taken before (the boot menu has the same words: quasar-snapshot words()).
function words(s) {
    if (!s) return ""
    if (s.reason === "manual") return s.description || "Made by you"
    var t = s.trigger || {}
    if (t.by === "automatic") return "Before automatic updates"
    if (t.by === "updates") return "Before installing updates"
    if (t.by === "store" && t.what) return (t.verb === "remove" ? "Before removing " : "Before installing ") + t.what
    if (t.by === "debfile") return "Before installing a package file"
    if (t.by === "drivers") return "Before a driver change"
    if (t.by === "apt") return "Before a change made in a terminal"
    return "Before a software change"
}

function detail(s, now) {
    var bits = [when(s.created, now)]
    if (s.version) bits.push("Quasar " + s.version)
    if (s.kernel) bits.push("Linux " + s.kernel.replace(/\+deb\d+/, "").replace(/-amd64$/, ""))
    return bits.join("  ·  ")
}

function find(st, id) {
    return ((st && st.snapshots) || []).filter(function (s) { return s.id === id })[0] || null
}

// The page's state, decided once: { kind, title, sub, button, primary }.
function state(st, ctx) {
    var now = ctx.now || 0
    if (!st) return { kind: "loading", title: "Reading the snapshots…", sub: "", button: "", primary: false }
    if (st.live) return { kind: "live", title: "The live USB has no snapshots",
                          sub: "Installed PCs take one before every update. To repair an installed PC that won't start, use Repair in the installer.",
                          button: "", primary: false }
    if (!st.btrfs) return { kind: "unavailable", title: "Snapshots need a reinstall",
                            sub: "This PC was installed before Quasar used btrfs. Reinstall Quasar to roll back after a bad update.",
                            button: "", primary: false }
    if (ctx.busy === "restore" || ctx.busy === "cancel")
        return { kind: "working", title: ctx.busy === "restore" ? "Restoring…" : "Cancelling the restore…",
                 sub: ctx.phase || "This takes a moment.", button: "", primary: false }
    if (st.pending) {
        var from = typeof st.pending.id === "number" ? find(st, st.pending.id) : null
        return { kind: "pending", title: "Restart to finish restoring",
                 sub: "The system " + (from ? "from " + when(from.created, now).replace(/^[A-Z]/, function (c) { return c.toLowerCase() })
                                            : "from before the last restore") + " starts next time. Until then, nothing new is installed.",
                 button: "Restart now", primary: true }
    }
    if (st.booted) {
        var b = find(st, st.booted.id) || st.booted
        return { kind: "booted", title: "This is the snapshot from " + (when(b.created, now) || "earlier").replace(/^[A-Z]/, function (c) { return c.toLowerCase() }),
                 sub: "Anything you change now is gone at the next restart. Keep this system with Restore, or restart into today's.",
                 button: "Restore this snapshot", primary: true }
    }
    if (ctx.busy === "create") return { kind: "working", title: "Making a snapshot…", sub: "", button: "", primary: false }
    var n = (st.snapshots || []).length
    return { kind: "ready", title: st.snapshots === null ? "Snapshots" : n ? plural(n, "snapshot") : "No snapshots yet",
             sub: st.auto ? "Quasar takes one before every update, so a bad one can be undone"
                          : "Automatic snapshots are off: only the ones you make",
             button: "Make a snapshot", primary: false }
}

function hero(st, ctx) {
    var s = state(st, ctx), t = ctx.theme
    var hot = s.kind === "pending" || s.kind === "booted"
    return { glyph: ctx.icons.restore, title: s.title, sub: s.sub, button: s.button, buttonPrimary: s.primary,
             iconBg: hot ? t.accent : s.kind === "ready" ? t.white(0.1) : t.white(0.07),
             iconFg: hot ? t.accentInk : t.text3 }
}

// Storage › Safety.
function storageRows(st, ctx) {
    var icons = ctx.icons
    if (!st) return [{ key: "snap:open", label: "Snapshots", glyph: icons.restore, trailing: "chevron", value: "…", sub: "" }]
    if (st.live) return [{ key: "snap:open", label: "Snapshots", glyph: icons.restore, trailing: "value", value: "Off",
                           sub: "Not on the live USB" }]
    if (!st.btrfs) return [{ key: "snap:open", label: "Snapshots", glyph: icons.restore, trailing: "value", value: "Not available",
                             sub: "Needs Quasar reinstalled: this PC was installed before snapshots" }]
    var n = st.snapshots ? st.snapshots.length : -1
    return [
        { key: "snap:auto", label: "Automatic snapshots", glyph: icons.shield, trailing: "toggle", checked: !!st.auto,
          busy: ctx.busy === "auto",
          sub: st.auto ? "Before every update, so a bad one can be undone" : "Off: updates install without a way back" },
        { key: "snap:open", label: "Snapshots", glyph: icons.restore, trailing: "chevron",
          value: st.pending ? "Restart to finish" : st.booted ? "Running one" : n < 0 ? "" : n ? String(n) : "None yet",
          sub: "Restore the system as it was, or start an older one once" }
    ]
}

function groups(st, ctx) {
    if (!st || st.live || !st.btrfs) return []
    var now = ctx.now || 0, icons = ctx.icons, out = []
    var bootedId = st.booted ? st.booted.id : -1
    if (st.pending)
        out.push({ label: "Waiting for the restart", rows: [
            { key: "snap:cancel", label: "Cancel the restore", glyph: icons.x, trailing: "button", value: "Cancel restore",
              busy: ctx.busy === "cancel", sub: "Keep the system as it is now" }] })
    var snaps = (st.snapshots || []).slice().reverse()
    out.push({ label: "Snapshots", rows: snaps.length ? snaps.map(function (s) {
        return { key: "snap:s:" + s.id, label: words(s), glyph: s.reason === "manual" ? icons.pin : icons.layers,
                 trailing: "chevron", value: s.id === bootedId ? "Running" : "", sub: detail(s, now) }
    }) : [{ label: st.snapshots === null ? "Open this page again in a moment" : "None yet", glyph: icons.layers, trailing: "value", value: "",
            sub: st.auto ? "The first one comes with the next update, or make one now" : "Make one before you try something risky" }] })
    var old = (st.old || []).filter(function (o) { return !st.pending || o.name !== st.pending.old })
    if (old.length)
        out.push({ label: "Before a restore", rows: old.slice().reverse().map(function (o) {
            var left = Math.max(1, GOOD_BOOTS - (o.goodBoots || 0))
            return { key: "snap:o:" + o.name, label: "The system as it was before a restore", glyph: icons.restore,
                     trailing: "chevron", value: "",
                     sub: when(o.created, now) + "  ·  Deleted after " + plural(left, "more start") }
        }) })
    out.push({ label: "About snapshots", rows: [
        { label: "What a restore brings back", glyph: icons.restore, trailing: "value", value: "",
          sub: "Programs, Debian packages and system settings, as they were then" },
        { label: "What stays as it is", glyph: icons.shield, trailing: "value", value: "",
          sub: "Your files, accounts and passwords, Wi-Fi, sites, Docker, Flatpak apps, Azure agents and logs" },
        { label: "Space", glyph: icons.drive, trailing: "value", value: st.free ? size(st.free) + " free" : "",
          sub: "Snapshots share what didn't change. Quasar keeps 10 automatic ones and 5 of yours" }] })
    return out
}

// The choices for one snapshot (a ChoiceSheet).
function actions(st, key) {
    if (key.indexOf("snap:o:") === 0)
        return [{ key: "restore", label: "Go back to it", sub: "Undo the restore: the next start runs this system again" },
                { key: "delete", label: "Delete it now", sub: "Frees its space; the restore can't be undone after that" }]
    var s = find(st, parseInt(key.slice(7)))
    var out = []
    if (st && st.booted && s && st.booted.id === s.id)
        out.push({ key: "restore", label: "Restore it", sub: "Keep this system: the next start runs it for good" })
    else
        out.push({ key: "restore", label: "Restore", sub: "The next start runs the system as it was then" })
    if (st && st.bootOnce && s && s.kernel && !st.booted)
        out.push({ key: "once", label: "Start it once", sub: "Look around without changing anything; the start after that is today's system" })
    if (!(st && st.booted))
        out.push({ key: "delete", label: "Delete", sub: "" })
    return out
}

// The restore question.
function restoreAsk(st, target, now) {
    var old = typeof target === "string"
    var s = old ? null : find(st, target)
    var o = old ? (st.old || []).filter(function (x) { return x.name === target })[0] : null
    var at = when(s ? s.created : o ? o.created : 0, now)
    return { key: "restore", target: target, button: "Restore", danger: false,
             title: old ? "Go back to the system from before the restore?" : "Restore the system from " + at.replace(/^[A-Z]/, function (c) { return c.toLowerCase() }) + "?",
             message: "Quasar restarts into the system as it was " + (old ? "before the restore" : "then") +
                      ". Updates and programs installed since then are undone; the next update brings the updates back." +
                      "\n\nYour files, accounts and passwords, Wi-Fi, sites, Docker, Flatpak apps, Azure agents and logs stay as they are now. " +
                      "Today's system is kept, so this can be undone." }
}
