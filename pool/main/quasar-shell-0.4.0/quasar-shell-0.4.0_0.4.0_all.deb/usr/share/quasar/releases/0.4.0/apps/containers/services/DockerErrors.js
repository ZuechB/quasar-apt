.pragma library

// Turn a failed docker command into one plain sentence + the raw output for "Details".
//   describe(log, exitCode, what) -> { tone, title, message, details, actionText, action }
//   what: what the user asked for, e.g. "Stopping web-1", "Downloading nginx:alpine".
function describe(log, code, what) {
    const text = log || ""
    const L = text.toLowerCase()
    let title = (what || "Docker") + " didn't work"
    let message
    let actionText = ""
    let action = ""

    if (/permission denied.*docker\.sock|got permission denied while trying to connect/.test(L)) {
        title = "Your account can't use Docker yet"
        message = "If you just installed Docker, log out and back in. Otherwise give your account access (an administrator's password is needed)."
        actionText = "Give access"; action = "access"
    } else if (/cannot connect to the docker daemon|is the docker daemon running|docker\.sock: connect: no such file/.test(L)) {
        title = "Docker isn't running"
        message = "Start Docker and try again."
        actionText = "Start Docker"; action = "start"
    } else if (/port is already allocated|address already in use|bind: address already in use/.test(L)) {
        message = "That port on this PC is already in use. Pick another one, or stop whatever is using it."
    } else if (/pull access denied|repository does not exist|manifest unknown|manifest for .* not found|not found: manifest/.test(L)) {
        message = "Docker couldn't find that image. Check the name and tag. Private images need `docker login` in a terminal first."
    } else if (/unauthorized|authentication required|denied: requested access/.test(L)) {
        message = "The registry wants you to sign in. Run `docker login` in a terminal, then try again."
    } else if (/toomanyrequests|rate limit/.test(L)) {
        message = "The registry is limiting downloads from your network. Try again later, or sign in with `docker login` for a higher limit."
    } else if (/x509|certificate.*(expired|not yet valid)|is not yet valid/.test(L)) {
        message = "Your PC's clock looks wrong, so secure downloads are refused. Set the time in Settings › Date & Language, then try again."
    } else if (/no space left|enospc/.test(L)) {
        message = "There isn't enough free space. Clean up unused images and build cache, or free some disk space."
    } else if (/could not resolve|temporary failure in name resolution|no such host|network is unreachable|i\/o timeout|tls handshake timeout|connection refused/.test(L)) {
        message = "Docker can't reach the registry. Check that you're online and try again."
    } else if (/(image is being used|image is referenced|unable to remove repository reference).*container|conflict: unable to delete/.test(L)) {
        message = "A container still uses that image. Remove the container first."
    } else if (/volume is in use/.test(L)) {
        message = "A container still uses that volume. Remove the container first."
    } else if (/container name .* is already in use|conflict. the container name/.test(L)) {
        message = "A container with that name already exists. Pick another name, or remove the old container."
    } else if (/invalid reference format/.test(L)) {
        message = "That isn't a valid image name. It looks like name, name:tag or registry/name:tag."
    } else if (/no such container|no such image|no such volume/.test(L)) {
        message = "It's already gone."
    } else {
        message = "Docker stopped with an error (code " + code + "). The details below show what it reported."
    }
    return { tone: "error", title: title, message: message, details: text, actionText: actionText, action: action }
}
