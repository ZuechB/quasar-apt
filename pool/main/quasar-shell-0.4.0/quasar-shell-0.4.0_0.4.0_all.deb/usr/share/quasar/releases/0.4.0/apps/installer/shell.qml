//@ pragma AppId quasar-installer
// Install Quasar — native Qt Quick app run by Quickshell (launched by /usr/bin/quasar-installer,
// e.g. from the live desktop's "Install Quasar" icon). A fixed, dialog-sized window that labwc
// centres; the disk work is done by the headless C# backend (services/Backend.qml).
import QtQuick
import Quickshell
import Quickshell.Io
import Quasar
import Quasar.Services
import "components"
import "services"

ShellRoot {
    id: app

    // ---- look follows the shared settings + render path -------------------------------------
    Binding { target: Theme; property: "accent"; value: Settings.accent }
    Binding { target: Theme; property: "reduceMotion"; value: Settings.reduceMotion }
    Binding { target: Theme; property: "softwareRender"; value: Platform.softwareScene }
    Binding { target: Theme; property: "profile"; value: Platform.softwareRender ? 0 : (Settings.profile >= 0 ? Settings.profile : 1) }

    // ---- services -------------------------------------------------------------------------------
    Backend {
        id: backend
        onFinished: {
            view.page = "done"
            Quickshell.execDetached(["notify-send", "-a", "Install Quasar", "-i", "system-software-install",
                                     "Quasar is installed", "Restart to start using it."])
        }
        onFailed: (message) => {
            view.errorMessage = message
            view.errorDetails = backend.details()
            view.page = "failed"
        }
        onRepaired: view.page = "repaired"
        onRepairFailed: (message) => {
            view.errorMessage = message
            view.errorDetails = backend.repairDetails()
            view.page = "repairFailed"
        }
    }

    property string timezone: ""
    property var zones: []
    Process {
        command: ["timedatectl", "show", "-p", "Timezone", "--value"]
        running: true
        stdout: StdioCollector { onStreamFinished: app.timezone = text.trim() }
    }
    Process {
        command: ["timedatectl", "list-timezones"]
        running: true
        stdout: StdioCollector { onStreamFinished: app.zones = text.trim().split("\n").filter(z => z).map(z => ({ key: z, label: z.replace(/_/g, " ") })) }
    }

    Component.onCompleted: if (Platform.live) backend.listDisks()

    // ---- window ---------------------------------------------------------------------------------
    AppWindow {
        id: win
        appName: "installer"
        title: "Install Quasar"
        glyph: Icons.download
        glyphColor: Theme.accent
        defaultSize: Qt.size(760, 560)
        resizable: false
        closeBlocked: view.page === "installing" || view.page === "repairing"
        onCloseRequested: if (closeBlocked) stillInstalling.open = true

        InstallerView {
            id: view
            anchors.fill: parent
            page: Platform.live ? "welcome" : "installed"
            zones: app.zones
            systemTimezone: app.timezone
            disks: backend.disks
            disksLoading: backend.listing
            disksError: backend.listError
            progress: backend.percent / 100
            stepName: backend.step
            stepMessage: backend.message
            onCancelled: Qt.quit()
            onQuitRequested: Qt.quit()
            onRefreshDisks: backend.listDisks()
            repairDisks: backend.repairDisks
            repairLoading: backend.repairLoading
            repairPhase: backend.repairPhase
            onRepairOpened: backend.scanRepair()
            onRepairRequested: (device, target) => backend.restoreSnapshot(device, target)
            onInstallRequested: backend.install(view.config())
            onRestartRequested: backend.reboot()
            onPageChanged: {
                if (page !== "installing" && page !== "repairing") stillInstalling.open = false     // the work ended: drop the notice
                if (page === "disk" && !backend.listing && backend.disks.length === 0) backend.listDisks()
            }
        }

        Dialog {
            id: stillInstalling
            title: "Quasar is still installing"
            message: "Stopping now would leave the disk half-written. You can keep using Quasar while it finishes."
            onDismissed: open = false
            buttons: [ Button { text: "OK"; variant: "primary"; size: 38; onClicked: stillInstalling.open = false } ]
        }
    }

    IpcHandler {
        target: "app"
        function open(arg: string): void { win.visible = true }
    }
}
