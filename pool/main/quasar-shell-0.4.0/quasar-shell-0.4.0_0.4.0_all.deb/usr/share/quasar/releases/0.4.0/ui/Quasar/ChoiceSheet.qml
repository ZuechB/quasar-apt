import QtQuick

// Pick one option (resolution, scale, output device, time zone…): a Dialog with a list of rows;
// the current one is ticked. Long lists get a search field and scroll.
Dialog {
    id: root
    property var options: []            // [{ key, label, sub }]
    property string current: ""
    property bool searchable: options.length > 12
    signal chosen(string key)
    property string _q: ""
    readonly property var shown: _q ? options.filter(o => (o.label + " " + (o.sub || "")).toLowerCase().includes(_q.toLowerCase())) : options
    onOpenChanged: if (open) { _q = ""; search.clear() }

    cardWidth: 420
    Column {
        width: parent.width
        spacing: 10
        SearchField {
            id: search
            visible: root.searchable
            width: parent.width
            placeholder: "Search"
            onEdited: (t) => root._q = t
        }
        ListView {
            width: parent.width
            height: Math.min(contentHeight, 320)
            clip: true
            boundsBehavior: Flickable.StopAtBounds
            model: root.shown
            delegate: Pressable {
                required property var modelData
                width: ListView.view.width
                height: 44
                radius: 10
                kind: "hov"
                color: modelData.key === root.current ? Theme.white(0.06) : "transparent"
                accessibleName: modelData.label
                onClicked: root.chosen(modelData.key)
                Column {
                    x: 12
                    anchors.verticalCenter: parent.verticalCenter
                    Text { text: modelData.label; font.family: Theme.fontUi; font.pixelSize: 14; color: Theme.text }
                    Text { visible: !!modelData.sub; text: modelData.sub || ""; font.family: Theme.fontUi; font.pixelSize: 12; color: Theme.textDim }
                }
                QIcon {
                    visible: modelData.key === root.current
                    anchors { right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter }
                    path: Icons.check; size: 16; strokeWidth: 2.2; color: Theme.accent
                }
            }
        }
    }
    buttons: [ Button { text: "Close"; variant: "outline"; size: 34; onClicked: root.dismissed() } ]
}
