import QtQuick
import QtQuick.Shapes

// Stroke glyph from Icons (24×24 viewBox), scaled like an inline SVG: stroke width scales with size.
// Rendered with the GPU curve renderer, so it stays crisp at any size and costs no textures.
// On software rendering it's a layer (see Theme.softwareRender): a bare Shape scrolled out of view
// would paint over the window's title bar.
Item {
    id: root
    property string path: ""          // SVG path data (Icons.<name>)
    property real size: 16
    property color color: Theme.text
    property real strokeWidth: 1.9
    property color fill: "transparent"
    property int capStyle: ShapePath.RoundCap
    property int joinStyle: ShapePath.RoundJoin

    implicitWidth: size
    implicitHeight: size
    layer.enabled: Theme.softwareRender

    Shape {
        width: 24
        height: 24
        scale: root.size / 24
        transformOrigin: Item.TopLeft
        preferredRendererType: Shape.CurveRenderer
        asynchronous: false
        ShapePath {
            strokeColor: root.color
            strokeWidth: root.strokeWidth
            fillColor: root.fill
            capStyle: root.capStyle
            joinStyle: root.joinStyle
            PathSvg { path: root.path }
        }
    }
}
