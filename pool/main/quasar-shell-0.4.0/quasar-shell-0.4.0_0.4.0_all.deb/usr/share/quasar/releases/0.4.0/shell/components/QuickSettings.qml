import QtQuick
import Quasar

// Quick settings (mockup aria-label="Quick settings"): 2-column toggle grid, brightness/volume fill
// sliders, Lite/Balanced/Max performance switch, footer note + settings button.
Panel {
    id: root
    radius: 24
    tint: Theme.panelBgStrong
    shadowOffsetY: 30
    shadowBlur: 80
    shadowSpread: -24

    // toggles: [{ key, label, sub, glyph, on, available, details }]  details: a chevron (and right-click)
    // asks for the toggle's page (detailsRequested)
    property var toggles: []
    property bool brightnessAvailable: true
    property real brightness: 72
    property real volume: 48
    property bool volumeMuted: false
    property bool volumeAvailable: true    // false: no sound output device (e.g. Hyper-V)
    property int profile: 1
    property bool profileLocked: false     // no GPU: Lite only (Balanced/Max need acceleration)
    readonly property var profileNotes: ["Lite: tuned for Raspberry Pi", "Balanced: adaptive frame rate", "Max: highest frame rate"]

    signal toggled(string key)
    signal detailsRequested(string key)
    signal brightnessMoved(real value)
    signal volumeMoved(real value)
    signal profilePicked(int index)
    signal settingsClicked()

    implicitWidth: 372
    implicitHeight: col.implicitHeight + 28

    Column {
        id: col
        x: 14; y: 14
        width: root.width - 28
        spacing: 12

        Grid {
            id: grid
            width: parent.width
            columns: 2
            columnSpacing: 8; rowSpacing: 8
            Repeater {
                model: root.toggles.filter(t => t.available !== false)
                delegate: Pressable {
                    required property var modelData
                    width: (grid.width - 8) / 2; height: 62; radius: 18; kind: "chip"
                    color: modelData.on ? Theme.accentTint : Theme.white(0.045)
                    borderColor: modelData.on ? Theme.alpha(Theme.accent, 0.35) : Theme.white(0.06)
                    hoverBorderColor: borderColor
                    accessibleName: modelData.label + ", " + (modelData.on ? "on" : "off")
                    onClicked: root.toggled(modelData.key)
                    onRightClicked: if (modelData.details) root.detailsRequested(modelData.key)
                    Rectangle {
                        x: 12; anchors.verticalCenter: parent.verticalCenter
                        width: 36; height: 36; radius: 12
                        color: modelData.on ? Theme.accent : Theme.white(0.07)
                        Behavior on color { ColorAnimation { duration: Motion.dur(300) } }
                        QIcon { anchors.centerIn: parent; path: modelData.glyph; size: 18; color: modelData.on ? Theme.accentInk : Theme.text3 }
                    }
                    Column {
                        x: 58; anchors.verticalCenter: parent.verticalCenter
                        width: parent.width - 66 - (modelData.details ? 20 : 0)
                        spacing: 2
                        Text { width: parent.width; elide: Text.ElideRight; text: modelData.label; font.family: Theme.fontUi; font.pixelSize: 13; font.weight: Font.DemiBold; color: Theme.text }
                        Text { width: parent.width; elide: Text.ElideRight; text: modelData.sub; font.family: Theme.fontUi; font.pointSize: Theme.pt(11.5); color: Theme.textMuted }
                    }
                    MouseArea {     // the tile's own page (Settings › Network / Bluetooth)
                        visible: !!modelData.details
                        anchors { right: parent.right; top: parent.top; bottom: parent.bottom }
                        width: 32
                        cursorShape: Qt.PointingHandCursor
                        hoverEnabled: true
                        onClicked: root.detailsRequested(modelData.key)
                        QIcon { anchors.centerIn: parent; path: Icons.fwd; size: 14; strokeWidth: 2; color: parent.containsMouse ? Theme.text : Theme.textMuted }
                    }
                }
            }
        }

        FillSlider {
            width: parent.width
            visible: root.brightnessAvailable
            icon: Icons.sun
            value: root.brightness
            accessibleName: "Brightness"
            onMoved: (v) => root.brightnessMoved(v)
        }
        FillSlider {
            width: parent.width
            icon: Icons.vol
            value: !root.volumeAvailable || root.volumeMuted ? 0 : root.volume
            enabled: root.volumeAvailable
            opacity: root.volumeAvailable ? 1 : 0.5
            accessibleName: root.volumeAvailable ? "Volume" : "Volume, no output device"
            onMoved: (v) => root.volumeMoved(v)
        }
        Text {
            visible: !root.volumeAvailable
            leftPadding: 4
            topPadding: -4
            text: "No sound output device"
            font.family: Theme.fontUi; font.pixelSize: 12; color: Theme.textDim
        }

        Column {
            width: parent.width
            spacing: 8
            SectionLabel { leftPadding: 4; topPadding: 2; text: "Performance" }
            Segmented {
                width: parent.width
                currentIndex: root.profile
                accessibleName: "Performance profile"
                enabled: !root.profileLocked
                opacity: root.profileLocked ? 0.5 : 1
                onPicked: (i) => root.profilePicked(i)
            }
        }

        Item {
            width: parent.width; height: 44
            Rectangle { width: parent.width; height: 1; color: Theme.white(0.06) }
            Text {
                x: 0; anchors.verticalCenter: parent.verticalCenter; anchors.verticalCenterOffset: 3
                text: root.profileLocked ? "Lite: this PC has no graphics acceleration"
                                         : root.profileNotes[Math.max(0, Math.min(2, root.profile))]
                font.family: Theme.fontUi; font.pixelSize: 12; color: Theme.textDim
            }
            Pressable {
                anchors { right: parent.right; verticalCenter: parent.verticalCenter; verticalCenterOffset: 3 }
                width: 38; height: 38; radius: 12
                accessibleName: "All settings"
                onClicked: root.settingsClicked()
                QIcon { anchors.centerIn: parent; path: Icons.gear; size: 17; color: Theme.text3 }
            }
        }
    }
}
