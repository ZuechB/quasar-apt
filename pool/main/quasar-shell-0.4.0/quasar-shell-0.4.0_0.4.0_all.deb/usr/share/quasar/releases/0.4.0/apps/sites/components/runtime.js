.pragma library

// Labels, statuses and formatting shared by the Sites views (pure: no Theme access here, colours are
// returned as tone names the views map to Theme tokens).

// End of support of the runtimes Sites builds. Shown as a warning banner on the site.
var EOL = {
    dotnet: { 6: "2024-11-12", 7: "2024-05-14", 8: "2026-11-10", 9: "2026-05-12", 10: "2028-11-14" },
    node: { 16: "2023-09-11", 18: "2025-04-30", 20: "2026-04-30", 22: "2027-04-30", 24: "2028-04-30" }
}
var NEXT = { dotnet: 10, node: 24 }
var MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September",
              "October", "November", "December"]

function major(framework) {
    var m = String(framework || "").match(/(\d+)/)
    return m ? parseInt(m[1], 10) : 0
}

function rtLabel(s) {
    if (!s) return ""
    var v = major(s.framework)
    if (s.kind === "dotnet") return ".NET " + (v || "") + " · " + (s.label || "ASP.NET Core")
    if (s.kind === "node") {
        var node = "Node " + (v || "LTS")
        return s.label && s.label.indexOf("Node") !== 0 ? s.label + " · " + node : node
    }
    if (s.kind === "static") return s.label && s.label !== "Static site" ? s.label + " · static files" : "Static site"
    return s.label && s.label !== "Custom" ? s.label : "Custom command"
}

function eolWarning(s, nowMs) {
    if (!s || (s.kind !== "dotnet" && s.kind !== "node" && !(s.kind === "static" && s.tool))) return ""
    var tool = s.kind === "static" ? (s.tool && s.tool.name) : s.kind
    var v = major(s.framework)
    var end = EOL[tool] && EOL[tool][v]
    if (!end || Date.parse(end) > nowMs) return ""
    var d = new Date(end + "T00:00:00Z")
    var name = tool === "dotnet" ? ".NET " + v : "Node " + v
    var next = tool === "dotnet" ? ".NET " + NEXT.dotnet : "Node " + NEXT.node
    return name + " reached end of support in " + MONTHS[d.getUTCMonth()] + " " + d.getUTCFullYear() +
           ". Move it to " + next + " to keep getting security fixes."
}

// state from sites-query: new | live | starting | crashed | stopped (+ deploying, lastFailed)
function status(s) {
    if (!s) return { label: "", tone: "dim", live: false }
    if (s.deploying) return { label: s.state === "new" ? "Deploying" : "Deploying", tone: "accent", live: true }
    if (s.state === "live") return s.lastFailed ? { label: "Live, last deploy failed", tone: "amber", live: true }
                                                : { label: "Live", tone: "mint", live: true }
    if (s.state === "starting") return { label: "Starting", tone: "accent", live: false }
    if (s.state === "crashed") return { label: "Crashed", tone: "danger", live: false }
    if (s.state === "new") return { label: s.lastFailed ? "First deploy failed" : "Not deployed yet",
                                     tone: s.lastFailed ? "danger" : "dim", live: false }
    return { label: "Stopped", tone: "dim", live: false }
}

function pad2(n) { return (n < 10 ? "0" : "") + n }

function clock(t) {
    if (!t) return ""
    var d = new Date(t * 1000)
    return pad2(d.getHours()) + ":" + pad2(d.getMinutes()) + ":" + pad2(d.getSeconds())
}

// "48s", "12m", "2h 14m", "3d 4h" (the mockup's fmtDur)
function dur(ms) {
    var s = Math.max(0, Math.floor(ms / 1000))
    if (s < 60) return s + "s"
    var m = Math.floor(s / 60)
    if (m < 60) return m + "m"
    var h = Math.floor(m / 60)
    if (h < 24) return h + "h " + (m % 60) + "m"
    var d = Math.floor(h / 24)
    return d + "d " + (h % 24) + "h"
}

function mem(bytes) {
    if (bytes === null || bytes === undefined) return ""
    var mb = bytes / 1048576
    return mb >= 1024 ? (mb / 1024).toFixed(1) + " GB" : Math.max(1, Math.round(mb)) + " MB"
}

function logTone(m) {
    if (/ 5\d\d in /.test(m)) return "danger"
    if (/ 4\d\d in /.test(m)) return "amber"
    return ""
}

function shortHome(path, home) {
    if (home && path && path.indexOf(home + "/") === 0) return "~" + path.slice(home.length)
    return path || ""
}

function kindGlyph(kind) {
    return kind === "node" ? "terminal" : kind === "static" ? "web" : kind === "custom" ? "cube" : "code"
}

// What a project needs installed before it can be built, given sites-query tools.
function missingTool(draft, tools) {
    if (!draft || !draft.tool || !tools) return null
    var name = draft.tool.name, spec = String(draft.tool.spec || "")
    var have = tools[name] || []
    if (name === "node") {
        if (!have.length) return { name: name, spec: spec || "lts", label: "Node.js " + (spec && spec !== "lts" ? spec : "LTS"), size: "about 190 MB", from: "nodejs.org" }
        if (spec && spec !== "lts" && !have.some(function (v) { return String(v).split(".")[0] === spec }))
            return { name: name, spec: spec, label: "Node.js " + spec, size: "about 190 MB", from: "nodejs.org" }
        return null
    }
    if (name === "dotnet") {
        if (!have.some(function (v) { return !spec || String(v).split(".")[0] === spec }))
            return { name: name, spec: spec, label: "the .NET " + spec + " SDK", size: "about 750 MB", from: "Microsoft" }
    }
    return null
}
