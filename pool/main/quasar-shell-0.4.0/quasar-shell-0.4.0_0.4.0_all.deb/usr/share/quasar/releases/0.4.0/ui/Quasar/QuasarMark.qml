import QtQuick
import QtQuick.Shapes

// The Quasar mark (the OS logo): the "deep" wallpaper's quasar in miniature. A white-hot core in an accent
// glow, a tilted orbit (near side bright, far side dim) with a comet of light riding it, and the jet along
// the orbit's axis, passing in front of the orbit's far side and behind its near side. Drawn on a 24-unit
// grid and scaled to `size`. Shapes only (no shaders), so software rendering draws it too.
//   hovered: the glow rises, the jet reaches out and the comet slides forward
//   active:  it ignites (the launcher is open): the glow blooms, the jet fires to full length, a ripple
//            runs out along the orbit and the comet makes a lap. Turning it off settles without a bounce.
// Static uses leave both off and get the resting mark.
Item {
    id: root
    property real size: 24
    property color accent: Theme.accent
    property bool hovered: false
    property bool active: false

    implicitWidth: size
    implicitHeight: size

    // ---- geometry: 24-unit grid, in the tilted frame ---------------------------------------------
    readonly property real tilt: -20          // the mockup logo's angle
    readonly property real rx: 10.2
    readonly property real ry: 3.8
    readonly property real ringW: 1.7
    readonly property real coreR: 2.0
    readonly property real cometW: 2.4        // at the head; the tail tapers to nothing
    readonly property real cometSweep: 130    // degrees of orbit from tail to head

    // ---- motion ----------------------------------------------------------------------------------
    property real hover: hovered ? 1 : 0
    Behavior on hover { NumberAnimation { duration: Motion.dur(Motion.chip); easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.spring } }
    property real ignite: 0                   // 0..1 (the opening spring overshoots a little)
    property real lap: 0                      // degrees the comet has travelled; each ignition adds a lap
    property real ripple: 0                   // 0..1 while the ignition ripple runs out
    // Springs overshoot past both ends; colors need 0..1 (a negative alpha is an invalid color)
    readonly property real heat: Math.max(0, Math.min(1, ignite))
    readonly property real lit: Math.max(0, Math.min(1, Math.max(hover, ignite)))

    // the comet's tail, in degrees clockwise from the orbit's right end (0..180 is the near half)
    readonly property real cometAt: 18 + 30 * hover * (1 - heat) + lap
    readonly property real cometMid: (cometAt + cometSweep / 2) * Math.PI / 180
    readonly property color ringColor: Qt.tint(Theme.text, Theme.alpha(accent, 0.30 * heat))

    NumberAnimation { id: igniteAnim; target: root; property: "ignite"; easing.type: Easing.BezierSpline }
    NumberAnimation {
        id: lapAnim
        target: root; property: "lap"
        duration: Motion.dur(1100); easing.type: Easing.OutCubic
        onFinished: root.lap = root.lap % 360
    }
    NumberAnimation { id: rippleAnim; target: root; property: "ripple"; from: 0; to: 1; duration: 700; easing.type: Easing.OutCubic }

    onActiveChanged: {
        igniteAnim.stop()
        igniteAnim.to = active ? 1 : 0
        igniteAnim.duration = Motion.dur(active ? Motion.launcher : 380)
        igniteAnim.easing.bezierCurve = active ? Motion.spring : Motion.soft
        igniteAnim.start()
        if (!active || Theme.reduceMotion) return
        lapAnim.stop()
        lapAnim.to = (Math.floor(lap / 360) + 1) * 360     // mid-lap: finish this lap rather than restart
        lapAnim.start()
        rippleAnim.restart()
    }

    // ---- comet outline: along the orbit from tail to head, widening toward a round head ----------
    function orbitPoint(t) { return Qt.point(12 + rx * Math.cos(t), 12 + ry * Math.sin(t)) }
    function orbitNormal(t) {
        const nx = Math.cos(t) / rx, ny = Math.sin(t) / ry, l = Math.hypot(nx, ny)
        return Qt.point(nx / l, ny / l)
    }
    readonly property real _tail: cometAt * Math.PI / 180
    readonly property real _head: (cometAt + cometSweep) * Math.PI / 180
    readonly property point cometTail: orbitPoint(_tail)
    readonly property point cometHead: orbitPoint(_head)
    readonly property var cometPath: {
        const n = 20, outer = [], inner = []
        for (let i = 0; i <= n; i++) {
            const f = i / n, t = _tail + (_head - _tail) * f
            const p = orbitPoint(t), q = orbitNormal(t), w = cometW / 2 * Math.pow(f, 0.75)
            outer.push(Qt.point(p.x + q.x * w, p.y + q.y * w))
            inner.push(Qt.point(p.x - q.x * w, p.y - q.y * w))
        }
        const q = orbitNormal(_head), r = cometW / 2
        let tx = -rx * Math.sin(_head), ty = ry * Math.cos(_head)
        const tl = Math.hypot(tx, ty); tx /= tl; ty /= tl
        const cap = []
        for (let k = 1; k < 8; k++) {
            const a = Math.PI * k / 8
            cap.push(Qt.point(cometHead.x + r * (q.x * Math.cos(a) + tx * Math.sin(a)),
                              cometHead.y + r * (q.y * Math.cos(a) + ty * Math.sin(a))))
        }
        return outer.concat(cap, inner.reverse(), [outer[0]])
    }

    Item {
        width: 24; height: 24
        scale: root.size / 24
        transformOrigin: Item.TopLeft

        Item {
            anchors.fill: parent
            rotation: root.tilt            // about the center (the scale above is about the top-left)

            // orbit: one band, dim at the far side and bright at the near side
            Shape {
                anchors.fill: parent
                z: 0
                preferredRendererType: Shape.CurveRenderer
                ShapePath {
                    strokeColor: "transparent"
                    fillRule: ShapePath.OddEvenFill
                    fillGradient: LinearGradient {
                        x1: 12; y1: 12 - root.ry; x2: 12; y2: 12 + root.ry
                        GradientStop { position: 0.0; color: Theme.alpha(root.ringColor, 0.34) }
                        GradientStop { position: 0.55; color: Theme.alpha(root.ringColor, 0.80) }
                        GradientStop { position: 1.0; color: Theme.alpha(root.ringColor, 1.0) }
                    }
                    PathAngleArc { centerX: 12; centerY: 12; radiusX: root.rx + root.ringW / 2; radiusY: root.ry + root.ringW / 2; startAngle: 0; sweepAngle: 360 }
                    PathAngleArc { centerX: 12; centerY: 12; radiusX: root.rx - root.ringW / 2; radiusY: root.ry - root.ringW / 2; startAngle: 0; sweepAngle: 360 }
                }
            }

            // ripple: on ignition a ring runs out along the orbit plane and fades
            Shape {
                anchors.fill: parent
                z: 1
                visible: rippleAnim.running
                scale: 0.2 + 1.15 * root.ripple
                opacity: 0.85 * (1 - root.ripple)
                preferredRendererType: Shape.CurveRenderer
                ShapePath {
                    strokeColor: root.accent
                    strokeWidth: 1.2
                    fillColor: "transparent"
                    PathAngleArc { centerX: 12; centerY: 12; radiusX: root.rx; radiusY: root.ry; startAngle: 0; sweepAngle: 360 }
                }
            }

            // glow around the core
            Shape {
                anchors.fill: parent
                z: 2
                scale: 0.92 + 0.18 * root.hover + 0.42 * root.ignite
                opacity: 0.9 + 0.1 * root.lit
                preferredRendererType: Shape.CurveRenderer
                ShapePath {
                    strokeColor: "transparent"
                    fillGradient: RadialGradient {
                        centerX: 12; centerY: 12; centerRadius: 8
                        focalX: 12; focalY: 12
                        GradientStop { position: 0.0; color: Theme.alpha(root.accent, 0.85) }
                        GradientStop { position: 0.22; color: Theme.alpha(root.accent, 0.48) }
                        GradientStop { position: 0.55; color: Theme.alpha(root.accent, 0.14) }
                        GradientStop { position: 1.0; color: Theme.alpha(root.accent, 0.0) }
                    }
                    PathAngleArc { centerX: 12; centerY: 12; radiusX: 8; radiusY: 8; startAngle: 0; sweepAngle: 360 }
                }
            }

            // jet: a tapered beam along the axis, white at the core and fading out at the tips
            Item {
                anchors.fill: parent
                z: 3
                opacity: 0.8 + 0.2 * root.lit
                transform: Scale { origin.x: 12; origin.y: 12; yScale: 0.7 + 0.15 * root.hover * (1 - root.heat) + 0.36 * root.ignite }
                Shape {
                    anchors.fill: parent
                    preferredRendererType: Shape.CurveRenderer
                    ShapePath {
                        strokeColor: "transparent"
                        fillGradient: LinearGradient {
                            x1: 12; y1: 0; x2: 12; y2: 24
                            GradientStop { position: 0.0; color: Theme.alpha(root.accent, 0.0) }
                            GradientStop { position: 0.2; color: Theme.alpha(root.accent, 0.45) }
                            GradientStop { position: 0.42; color: Theme.alpha(root.accent, 0.95) }
                            GradientStop { position: 0.5; color: "#FFFFFF" }
                            GradientStop { position: 0.58; color: Theme.alpha(root.accent, 0.95) }
                            GradientStop { position: 0.8; color: Theme.alpha(root.accent, 0.45) }
                            GradientStop { position: 1.0; color: Theme.alpha(root.accent, 0.0) }
                        }
                        startX: 12; startY: 0
                        PathLine { x: 12.8; y: 12 }
                        PathLine { x: 12; y: 24 }
                        PathLine { x: 11.2; y: 12 }
                        PathLine { x: 12; y: 0 }
                    }
                }
            }

            // core
            Shape {
                anchors.fill: parent
                z: 4
                scale: 1 + 0.1 * root.hover + 0.14 * root.ignite
                preferredRendererType: Shape.CurveRenderer
                ShapePath {
                    strokeColor: "transparent"
                    fillColor: "#FFFFFF"
                    PathAngleArc { centerX: 12; centerY: 12; radiusX: root.coreR; radiusY: root.coreR; startAngle: 0; sweepAngle: 360 }
                }
            }

            // the near side of the orbit again, over the jet where it crosses
            Shape {
                anchors.fill: parent
                z: 5
                preferredRendererType: Shape.CurveRenderer
                ShapePath {
                    strokeColor: root.ringColor
                    strokeWidth: root.ringW
                    fillColor: "transparent"
                    capStyle: ShapePath.FlatCap
                    PathAngleArc { centerX: 12; centerY: 12; radiusX: root.rx; radiusY: root.ry; startAngle: 74; sweepAngle: 32 }
                }
            }

            // comet: fades in from its tail to a pale head with a soft glow (the boot splash's light
            // dashes); dimmer, and behind the jet, on the far side
            Shape {
                anchors.fill: parent
                z: Math.sin(root.cometMid) > 0 ? 6 : 1
                opacity: 0.55 + 0.45 * (0.5 + 0.5 * Math.sin(root.cometMid))
                preferredRendererType: Shape.CurveRenderer
                ShapePath {
                    strokeColor: "transparent"
                    fillGradient: LinearGradient {
                        x1: root.cometTail.x; y1: root.cometTail.y; x2: root.cometHead.x; y2: root.cometHead.y
                        GradientStop { position: 0.0; color: Theme.alpha(root.accent, 0.0) }
                        GradientStop { position: 0.45; color: Theme.alpha(root.accent, 0.75) }
                        GradientStop { position: 0.8; color: root.accent }
                        GradientStop { position: 1.0; color: Qt.tint(root.accent, Theme.white(0.6)) }
                    }
                    PathPolyline { path: root.cometPath }
                }
                ShapePath {
                    strokeColor: "transparent"
                    fillGradient: RadialGradient {
                        centerX: root.cometHead.x; centerY: root.cometHead.y; centerRadius: 2.6
                        focalX: root.cometHead.x; focalY: root.cometHead.y
                        GradientStop { position: 0.0; color: Theme.alpha(Qt.tint(root.accent, Theme.white(0.7)), 0.9) }
                        GradientStop { position: 0.35; color: Theme.alpha(root.accent, 0.35) }
                        GradientStop { position: 1.0; color: Theme.alpha(root.accent, 0.0) }
                    }
                    PathAngleArc { centerX: root.cometHead.x; centerY: root.cometHead.y; radiusX: 2.6; radiusY: 2.6; startAngle: 0; sweepAngle: 360 }
                }
            }
        }
    }
}
