import QtQuick
import QtQuick.Shapes

// The assistant mark: an accent orbit, a faint orbit turned 60° and a white core (launcher search field,
// Ask, installer). The OS logo is QuasarMark. Drawn on a 24-unit grid and scaled about its center, so
// `spinning` turns it in place.
Item {
    id: root
    property real size: 22
    property color accent: Theme.accent
    property real strokeWidth: 1.6
    property bool spinning: false
    property int spinDuration: 6000

    implicitWidth: size
    implicitHeight: size
    layer.enabled: Theme.softwareRender         // clips when scrolled away (see Theme.softwareRender)

    Item {
        id: glyph
        width: 24; height: 24
        anchors.centerIn: parent
        scale: root.size / 24

        Shape {
            anchors.fill: parent
            preferredRendererType: Shape.CurveRenderer
            ShapePath {
                strokeColor: root.accent
                strokeWidth: root.strokeWidth
                fillColor: "transparent"
                PathAngleArc { centerX: 12; centerY: 12; radiusX: 10; radiusY: 4; startAngle: 0; sweepAngle: 360 }
            }
        }
        Shape {
            anchors.fill: parent
            rotation: 60
            preferredRendererType: Shape.CurveRenderer
            ShapePath {
                strokeColor: Qt.rgba(0.933, 0.945, 0.969, 0.35)
                strokeWidth: root.strokeWidth * 0.75
                fillColor: "transparent"
                PathAngleArc { centerX: 12; centerY: 12; radiusX: 10; radiusY: 4; startAngle: 0; sweepAngle: 360 }
            }
        }
        // core
        Rectangle {
            x: 12 - 2.3; y: 12 - 2.3; width: 4.6; height: 4.6; radius: 2.3
            color: "#FFFFFF"
        }

        RotationAnimator on rotation {
            running: root.spinning && Theme.ambientMotion
            from: glyph.rotation; to: glyph.rotation + 360
            duration: root.spinDuration
            loops: Animation.Infinite
        }
    }
}
