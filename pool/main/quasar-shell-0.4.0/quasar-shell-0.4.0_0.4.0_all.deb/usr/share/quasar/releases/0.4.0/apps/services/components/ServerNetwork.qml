import QtQuick
import Quasar
import "services.js" as S

// "Players can join" in a server's detail: each port with who can reach it and whether something has
// it open, the addresses to share (LAN and internet), the packets that came from outside the home
// network (netguard, while the detail shows), players when the server's log says, and the way into the
// internet play guide. Pure view.
Column {
    id: root
    property var item: ({})
    property var m: ({})
    property real now: Date.now()
    signal act(string name, var a, var b, var c)
    signal copy(string text)

    readonly property var server: item && item.server ? item.server : null
    readonly property var ports: server ? server.ports || [] : []
    readonly property bool running: !!item && item.status === "running"
    readonly property var stats: m.stats || null
    readonly property var addr: S.addresses(server, m.lan)
    readonly property bool internet: S.hasInternet(ports)
    readonly property var wan: stats && stats.wan ? stats.wan : null
    function listening(p) {
        const live = stats && stats.ports ? stats.ports.find(x => x.proto === p.proto && x.port === p.port) : null
        return live ? !!live.listening : !!p.listening
    }

    spacing: 8

    Text {
        text: "PLAYERS CAN JOIN"
        font.family: Theme.fontMono; font.pointSize: Theme.pt(10.5); font.letterSpacing: 1.05
        color: Theme.textFaint
    }

    Rectangle {
        width: root.width
        height: col.implicitHeight
        radius: 14
        color: Theme.white(0.03)
        border.width: 1
        border.color: Theme.white(0.06)

        Column {
            id: col
            width: parent.width

            Text {
                visible: root.ports.length === 0
                width: parent.width
                padding: 12
                text: "No ports: nothing outside this PC can reach it. Add one in Settings."
                wrapMode: Text.Wrap
                font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
                color: Theme.textMuted
            }

            Repeater {
                model: root.ports
                delegate: Item {
                    id: pr
                    required property var modelData
                    required property int index
                    width: col.width
                    height: 52
                    readonly property bool open: root.listening(modelData)
                    Rectangle { visible: pr.index > 0; width: parent.width; height: 1; color: Theme.white(0.05) }
                    QIcon {
                        id: reachIcon
                        x: 12
                        anchors.verticalCenter: parent.verticalCenter
                        path: pr.modelData.reach === "internet" ? Icons.globe : pr.modelData.reach === "home" ? Icons.home : Icons.monitor
                        size: 16; strokeWidth: 1.9
                        color: pr.modelData.reach === "internet" ? Theme.accent : Theme.text3
                    }
                    Column {
                        anchors { left: reachIcon.right; leftMargin: 10; right: stateRow.left; rightMargin: 8; verticalCenter: parent.verticalCenter }
                        spacing: 2
                        Text {
                            width: parent.width
                            text: S.portText(pr.modelData) + (pr.modelData.label ? "  ·  " + pr.modelData.label : "")
                            textFormat: Text.PlainText
                            elide: Text.ElideRight
                            font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5); font.weight: Font.Medium
                            color: Theme.text2
                        }
                        Text {
                            width: parent.width
                            text: pr.modelData.reach === "internet" ? "Anyone on the internet" : pr.modelData.reach === "home" ? "Devices on your home network" : "Only this PC"
                            elide: Text.ElideRight
                            font.family: Theme.fontUi; font.pointSize: Theme.pt(11.5)
                            color: Theme.textFaint
                        }
                    }
                    Row {
                        id: stateRow
                        visible: root.running
                        anchors { right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter }
                        spacing: 5
                        QIcon {
                            anchors.verticalCenter: parent.verticalCenter
                            path: pr.open ? Icons.check : Icons.clock
                            size: 12; strokeWidth: 2.5
                            color: pr.open ? Theme.mint : Theme.textDim
                        }
                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            text: pr.open ? "Listening" : "Not open yet"
                            font.family: Theme.fontUi; font.pointSize: Theme.pt(11.5); font.weight: Font.DemiBold
                            color: pr.open ? Theme.mint : Theme.textDim
                        }
                    }
                }
            }

            // Where players connect.
            Repeater {
                model: [
                    root.addr.lan ? { label: "On your Wi-Fi", value: root.addr.lan } : null,
                    root.addr.internet ? { label: "From the internet", value: root.addr.internet } : null
                ].filter(x => !!x)
                delegate: Item {
                    id: ar
                    required property var modelData
                    width: col.width
                    height: 50
                    Rectangle { width: parent.width; height: 1; color: Theme.white(0.05) }
                    Column {
                        anchors { left: parent.left; leftMargin: 12; right: copyBtn.left; rightMargin: 8; verticalCenter: parent.verticalCenter }
                        spacing: 3
                        Text { text: ar.modelData.label; font.family: Theme.fontUi; font.pixelSize: 11; color: Theme.textFaint }
                        Text {
                            width: parent.width
                            text: ar.modelData.value
                            textFormat: Text.PlainText
                            elide: Text.ElideMiddle
                            font.family: Theme.fontMono; font.pointSize: Theme.pt(12.5)
                            color: Theme.text2
                        }
                    }
                    Pressable {
                        id: copyBtn
                        anchors { right: parent.right; rightMargin: 8; verticalCenter: parent.verticalCenter }
                        width: 30; height: 30; radius: 8; kind: "hov"
                        accessibleName: "Copy " + ar.modelData.value
                        onClicked: root.copy(ar.modelData.value)
                        QIcon { anchors.centerIn: parent; path: Icons.copy; size: 14; strokeWidth: 2; color: Theme.textMuted }
                    }
                }
            }

            // Packets from outside the home network (the firewall's counter for this server).
            Item {
                visible: root.internet
                width: col.width
                height: 50
                Rectangle { width: parent.width; height: 1; color: Theme.white(0.05) }
                Column {
                    anchors { left: parent.left; leftMargin: 12; right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter }
                    spacing: 3
                    Text { text: "From outside your home"; font.family: Theme.fontUi; font.pixelSize: 11; color: Theme.textFaint }
                    Text {
                        width: parent.width
                        text: !root.m.netguard ? "Shows once the firewall is on"
                            : !root.running && !root.wan ? "Counts while the server runs"
                            : !root.wan ? "Counting…"
                            : root.wan.packets === 0 ? "No packets yet"
                            : S.grouped(root.wan.packets) + (root.wan.packets === 1 ? " packet" : " packets")
                              + (root.stats.wanAt ? "  ·  latest " + S.ago(root.stats.wanAt, root.now) : "")
                        elide: Text.ElideRight
                        font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5); font.features: { "tnum": 1 }
                        color: root.wan && root.wan.packets > 0 ? Theme.text2 : Theme.textMuted
                    }
                }
            }

            // Players, when the server's log tells (a `players` pattern).
            Item {
                visible: !!root.m.players && root.running
                width: col.width
                height: 50
                Rectangle { width: parent.width; height: 1; color: Theme.white(0.05) }
                Column {
                    anchors { left: parent.left; leftMargin: 12; right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter }
                    spacing: 3
                    Text { text: "Playing now"; font.family: Theme.fontUi; font.pixelSize: 11; color: Theme.textFaint }
                    Text {
                        text: root.m.players ? root.m.players.now + (root.m.players.max ? " of " + root.m.players.max : "") : ""
                        font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5); font.weight: Font.Medium; font.features: { "tnum": 1 }
                        color: Theme.text2
                    }
                }
            }
        }
    }

    Text {
        visible: !!root.m.firewall && root.m.firewall.on === false
        width: root.width
        text: "The firewall is off, so every port on this PC is open to your home network. Turn it on in Settings › Network & Internet."
        wrapMode: Text.Wrap
        font.family: Theme.fontUi; font.pointSize: Theme.pt(12)
        color: Theme.amber
    }

    Button {
        visible: root.internet
        variant: "soft"
        size: 34
        glyph: Icons.globe
        text: "Set up internet play…"
        onClicked: root.act("openGuide", root.item.key, null, null)
    }
}
