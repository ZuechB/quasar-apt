import QtQuick
import Quasar
import "tm.js" as TM

// Task Manager's window content (apps/taskmanager/shell.qml wires it to sysmon and the end-task helpers).
// Pure view; it keeps only what's on screen (page, picked row, search, sort, open groups) and asks before an
// ending that can hurt (TM.endPlan's confirm), then emits endTask.
//   page: "processes" | "performance"
//   info, tick: sysmon's lines; history: { key: [60 samples] } (TM.devices / TM.detail)
//   windows: { appId: [window titles] }; appLookup(appId) -> { name, image, glyph, hue } | null; companyNames
//   desktopDown: the Quasar desktop (quasar-shell.service) isn't running: a card offers to restart it
Item {
    id: root
    property string page: "processes"
    property var info: null
    property var tick: null
    property var history: ({})
    property var windows: ({})
    property var appLookup: null
    property var companyNames: ({})
    property bool desktopDown: false
    property bool busy: false
    property var banner: null               // { tone, title, message }
    signal pagePicked(string page)
    signal expand(var keys)
    signal endTask(var row, var plan)
    signal restartDesktop()
    signal safeGraphics()
    signal bannerDismissed()
    signal openLog(string target)          // quasar-services' argument: the row's log, live, in its own window

    property string selected: ""
    property string perfKey: "cpu"
    property string query: ""
    property var sort: ({ col: "cpu", desc: true })
    property var expanded: ({})
    property var ask: null                  // { row, plan }: the confirmation

    readonly property var rows: TM.rows(tick, { windows: windows, app: appLookup, companyNames: companyNames, expanded: expanded,
                                                query: query, sort: sort })
    readonly property var totals: TM.totals(tick)

    function toggle(key) {
        const e = Object.assign({}, expanded)
        if (e[key]) delete e[key]
        else e[key] = true
        expanded = e
        expand(Object.keys(e))
    }
    function sortBy(col) {
        sort = { col: col, desc: sort.col === col ? !sort.desc : col !== "name" }
    }
    function requestEnd(key) {
        const row = rows.find(r => r.key === key)
        const plan = TM.endPlan(row)
        if (!plan || busy) return
        if (plan.confirm) ask = { row: row, plan: plan }
        else endTask(row, plan)
    }

    // ---- navigation ------------------------------------------------------------------------------------
    Column {
        id: nav
        x: 12; y: 12
        width: 196
        spacing: 2
        NavItem { width: parent.width; label: "Processes"; glyph: Icons.list; selected: root.page === "processes"; onClicked: root.pagePicked("processes") }
        NavItem { width: parent.width; label: "Performance"; glyph: Icons.chart; selected: root.page === "performance"; onClicked: root.pagePicked("performance") }
    }
    // A live summary under the navigation.
    Column {
        anchors { left: nav.left; right: nav.right; bottom: parent.bottom; bottomMargin: 16 }
        spacing: 8
        Repeater {
            model: [
                { label: "CPU", value: TM.pct(root.totals.cpu) },
                { label: "Memory", value: TM.pct(root.totals.mem) },
                { label: "Disk", value: TM.pct(root.totals.disk) },
                { label: "GPU", value: TM.pct(root.totals.gpu) }
            ]
            Item {
                required property var modelData
                width: parent.width; height: 18
                visible: modelData.value !== "—"
                Text { x: 12; text: parent.modelData.label; font.family: Theme.fontUi; font.pointSize: Theme.pt(12); color: Theme.textDim }
                Text { anchors.right: parent.right; anchors.rightMargin: 12; text: parent.modelData.value; font.family: Theme.fontUi; font.pointSize: Theme.pt(12); font.features: { "tnum": 1 }; color: Theme.text3 }
            }
        }
    }
    Rectangle { x: 220; y: 0; width: 1; height: parent.height; color: Theme.white(0.06) }

    // ---- content -----------------------------------------------------------------------------------------
    Item {
        id: content
        x: 221
        width: parent.width - x
        height: parent.height

        Column {
            id: notices
            x: 16; y: 12
            width: parent.width - 32
            spacing: 10
            // The Quasar desktop stopped (a crash systemd gave up on, or it was ended): bring it back here.
            Rectangle {
                visible: root.desktopDown
                width: parent.width
                height: visible ? downCol.implicitHeight + 28 : 0
                radius: 14
                color: Theme.alpha(Theme.amber, 0.08)
                border.width: 1
                border.color: Theme.alpha(Theme.amber, 0.3)
                Column {
                    id: downCol
                    x: 16; y: 14
                    width: parent.width - 32
                    spacing: 10
                    Text { text: "The desktop isn't running"; font.family: Theme.fontUi; font.pointSize: Theme.pt(14); font.weight: Font.DemiBold; color: Theme.text }
                    Text {
                        width: parent.width
                        wrapMode: Text.Wrap
                        text: "The taskbar, desktop and notifications stopped. Restart them: your apps stay open. If it keeps stopping, safe graphics draws it without the graphics card."
                        font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5); color: Theme.text3
                    }
                    Row {
                        spacing: 8
                        Button { text: "Restart the desktop"; glyph: Icons.refresh; variant: "primary"; size: 34; onClicked: root.restartDesktop() }
                        Button { text: "Use safe graphics"; variant: "outline"; size: 34; onClicked: root.safeGraphics() }
                    }
                }
            }
            Banner {
                visible: root.banner !== null
                width: parent.width
                tone: root.banner ? root.banner.tone : "info"
                title: root.banner ? root.banner.title : ""
                message: root.banner ? root.banner.message || "" : ""
                onDismissed: root.bannerDismissed()
            }
        }

        ProcessesPage {
            id: procs
            visible: root.page === "processes"
            focus: visible
            anchors { top: notices.bottom; topMargin: notices.height > 0 ? 4 : 0; left: parent.left; right: parent.right; bottom: parent.bottom }
            rows: root.rows
            totals: root.totals
            memTotal: root.info && root.info.memory ? root.info.memory.total : 0
            selected: root.selected
            sort: root.sort
            busy: root.busy
            onPicked: (k) => root.selected = k
            onToggled: (k) => root.toggle(k)
            onSortBy: (c) => root.sortBy(c)
            onSearched: (t) => root.query = t
            onEndRequested: (k) => root.requestEnd(k)
            onSafeRequested: root.safeGraphics()
            onMenuRequested: (k, x, y) => {
                const row = root.rows.find(r => r.key === k)
                const plan = TM.endPlan(row)
                const items = []
                if (plan) items.push({ key: "end", label: plan.verb, glyph: plan.how === "restart" ? Icons.refresh : Icons.x })
                if (plan && plan.how === "restart") items.push({ key: "safe", label: "Restart with safe graphics", glyph: Icons.monitor })
                if (TM.logTarget(row)) items.push({ key: "log", label: "Open log", glyph: Icons.terminal })
                if (row && row.expandable) items.push({ key: "expand", label: row.expanded ? "Hide its processes" : "Show its processes", glyph: Icons.list })
                if (!items.length) return
                const p = procs.mapToItem(root, x, y)
                menu.target = k
                menu.items = items
                menu.show(p.x, p.y)
            }
        }
        PerformancePage {
            visible: root.page === "performance"
            anchors { top: notices.bottom; left: parent.left; right: parent.right; bottom: parent.bottom }
            info: root.info
            tick: root.tick
            history: root.history
            selected: root.perfKey
            onPicked: (k) => root.perfKey = k
        }
        Text {
            visible: root.tick === null
            anchors.centerIn: parent
            text: "Reading this PC's numbers…"
            font.family: Theme.fontUi; font.pointSize: Theme.pt(13)
            color: Theme.textDim
        }
    }

    TaskMenu {
        id: menu
        property string target: ""
        onChosen: (key) => {
            close()
            if (key === "end") root.requestEnd(target)
            else if (key === "safe") root.safeGraphics()
            else if (key === "expand") root.toggle(target)
            else if (key === "log") {
                const t = TM.logTarget(root.rows.find(r => r.key === target))
                if (t) root.openLog(t)
            }
        }
        onDismissed: close()
    }

    Dialog {
        open: root.ask !== null
        title: root.ask ? root.ask.plan.verb + ": " + root.ask.row.label + "?" : ""
        message: root.ask ? root.ask.plan.warn : ""
        onDismissed: root.ask = null
        buttons: [
            Button { text: "Cancel"; variant: "outline"; size: 38; onClicked: root.ask = null },
            Button {
                text: root.ask ? root.ask.plan.verb : ""
                variant: "primary"; tone: Theme.danger; size: 38
                onClicked: { const a = root.ask; root.ask = null; root.endTask(a.row, a.plan) }
            }
        ]
    }
}
