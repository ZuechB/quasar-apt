import QtQuick
import Quasar

// Files' sidebar (template): PLACES (Home, Desktop, Documents, Downloads, Pictures, Music, Videos,
// Projects when it exists, Trash) and DEVICES (This PC with how full it is, then any mounted drive).
// The place the shown folder is in is highlighted. Every place takes drops: files dragged onto it
// go into it, and onto Trash go to the Trash.
Item {
    id: root
    property var places: []              // [{ label, path, glyph }]
    property var devices: []             // drives [{ label, path ("" until mounted), device, mounted, ejectable, busy }]
    property string current: ""          // the folder shown
    property string trashPath: ""        // the Trash place's path (Trash/files)
    property real rootFree: -1           // bytes free / in all on "/" (-1: not known yet)
    property real rootTotal: -1
    signal picked(string path)
    signal dropped(string path, var drop)    // DragEvent, valid during the call only
    signal mountRequested(string device)
    signal ejectRequested(string device)

    implicitWidth: 190

    // The place the folder is in: the longest place path it starts with.
    readonly property string here: {
        let best = ""
        const all = places.concat(devices)
        for (let i = 0; i < all.length; i++) {
            const p = all[i].path
            if ((current === p || current.startsWith(p + "/")) && p.length > best.length) best = p
        }
        return best || (current.startsWith("/") ? "/" : "")
    }
    property string dropOn: ""               // the place under a drag

    Rectangle { anchors.right: parent.right; width: 1; height: parent.height; color: Theme.white(0.05) }

    Flickable {
        id: flick
        anchors { fill: parent; rightMargin: 1 }
        contentHeight: col.implicitHeight + 20
        clip: true
        boundsBehavior: Flickable.StopAtBounds
        interactive: contentHeight > height

        Column {
            id: col
            x: 8; y: 10
            width: parent.width - 16
            spacing: 1

            SectionLabel { text: "Places"; leftPadding: 10; topPadding: 6; bottomPadding: 6 }
            Repeater {
                model: root.places
                delegate: Place {
                    required property var modelData
                    width: col.width
                    label: modelData.label
                    glyph: modelData.glyph
                    path: modelData.path
                }
            }

            SectionLabel { text: "Devices"; leftPadding: 10; topPadding: 14; bottomPadding: 6 }
            // This PC: the whole system (/), with how full its drive is.
            Pressable {
                id: pc
                width: col.width
                height: pcCol.implicitHeight + 14
                radius: 9
                color: root.here === "/" ? Theme.white(0.08) : "transparent"
                accessibleName: "This PC"
                onClicked: root.picked("/")
                Column {
                    id: pcCol
                    x: 10; y: 7
                    width: parent.width - 20
                    spacing: 6
                    Row {
                        spacing: 10
                        QIcon { path: Icons.drive; size: 15; strokeWidth: 1.9; color: root.here === "/" ? Theme.accent : Theme.textMuted; anchors.verticalCenter: parent.verticalCenter }
                        Text {
                            text: "This PC"
                            font.family: Theme.fontUi; font.pixelSize: 13
                            color: root.here === "/" ? Theme.text : Theme.text3
                        }
                    }
                    Rectangle {
                        visible: root.rootTotal > 0
                        width: parent.width; height: 4; radius: 2
                        color: Theme.white(0.08)
                        Rectangle {
                            width: Math.max(4, parent.width * Math.min(1, 1 - root.rootFree / Math.max(1, root.rootTotal)))
                            height: parent.height; radius: 2
                            color: Theme.accent
                        }
                    }
                    Text {
                        visible: root.rootTotal > 0
                        text: FileKit.formatSize(root.rootFree) + " free of " + FileKit.formatSize(root.rootTotal)
                        font.family: Theme.fontUi; font.pointSize: Theme.pt(11)
                        color: Theme.textDim
                    }
                }
            }
            // USB sticks and cards: one that isn't open yet opens (mounts) when clicked; an open one
            // has an eject button (then it's safe to unplug).
            Repeater {
                model: root.devices
                delegate: Place {
                    id: dev
                    required property var modelData
                    width: col.width
                    label: modelData.label
                    glyph: Icons.drive
                    path: modelData.path
                    opacity: modelData.mounted || modelData.busy ? 1 : 0.7
                    interactiveContent: true             // the eject button takes its own clicks
                    onClicked: if (!modelData.mounted && modelData.device && !modelData.busy) root.mountRequested(modelData.device)
                    Spinner {
                        visible: dev.modelData.busy !== ""
                        size: 14
                        anchors { right: parent.right; rightMargin: 9; verticalCenter: parent.verticalCenter }
                    }
                    Pressable {
                        visible: dev.modelData.mounted && dev.modelData.ejectable && dev.modelData.busy === ""
                        width: 24; height: 24; radius: 7
                        anchors { right: parent.right; rightMargin: 4; verticalCenter: parent.verticalCenter }
                        accessibleName: "Eject " + dev.modelData.label
                        onClicked: root.ejectRequested(dev.modelData.device)
                        QIcon { anchors.centerIn: parent; path: Icons.eject; size: 13; strokeWidth: 1.9; color: Theme.textMuted }
                    }
                }
            }
        }
    }

    // A place row: highlighted when the folder is in it, an accent wash while files are dragged over it.
    component Place: NavItem {
        id: place
        property string path: ""
        readonly property bool hot: root.dropOn === path && path !== ""
        height: 32
        radius: 9
        accentIcon: true
        selected: root.here === path
        color: hot ? Theme.alpha(Theme.accent, 0.2) : selected ? Theme.white(0.08) : "transparent"
        hoverColor: hot ? Theme.alpha(Theme.accent, 0.2) : selected ? Theme.white(0.08) : Theme.white(0.07)
        borderColor: hot ? Theme.alpha(Theme.accent, 0.55) : "transparent"
        onClicked: root.picked(path)
        DropArea {
            anchors.fill: parent
            enabled: place.path !== ""               // a drive that isn't open yet takes no drops
            onEntered: root.dropOn = place.path
            onExited: if (root.dropOn === place.path) root.dropOn = ""
            onDropped: (d) => { root.dropOn = ""; root.dropped(place.path, d) }
        }
    }
}
