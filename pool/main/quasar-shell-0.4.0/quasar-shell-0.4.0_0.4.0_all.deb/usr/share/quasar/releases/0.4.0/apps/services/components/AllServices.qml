import QtQuick
import Quasar
import "services.js" as S

// "Every service on this PC" (services-query units -f): every system service and your own, failures first,
// then what runs, then the rest. Quasar's own show under their Services names (S.everyRow).
// A ListView over a keyed model patched from the stream's deltas: rows that changed move, others stay put, and
// your scroll position stays where it was. Search filters into a second model. Pure: apply(ev) takes the
// stream's events; out go select(key), openConsole(consoleKey), openEvery().
//   items: the app's own rows (names for Quasar's units)   selectedKey: the selected row
Item {
    id: root
    property var items: []
    property string selectedKey: ""
    property string error: ""
    property bool loaded: false
    property string hover: ""                // previews: a row key drawn hovered
    signal select(string key)
    signal openConsole(string key)
    signal openTerminal(string key)
    signal openEvery()
    signal retry()

    property var byKey: ({})
    property var order: []                   // sort keys, parallel to the model
    property string countsText: ""
    property string query: ""

    // ---- data ---------------------------------------------------------------------------------------
    function roleOf(r) {
        const st = S.unitStatus(r)
        return { rkey: r.key, sec: S.unitSection(r), name: String(r.name || r.unit), unitName: r.unit, user: !!r.user,
                 label: st.label, tone: st.color, quasar: !!r.quasar }
    }
    function find(sk) {
        let lo = 0, hi = order.length
        while (lo < hi) { const mid = (lo + hi) >> 1; if (order[mid] < sk) lo = mid + 1; else hi = mid }
        return lo
    }
    function removeKey(k) {
        const old = byKey[k]
        if (!old) return
        const sk = S.unitSortKey(old), i = find(sk)
        if (i < order.length && order[i] === sk) { order.splice(i, 1); all.remove(i) }
        delete byKey[k]
    }
    function upsert(r) {
        const old = byKey[r.key]
        const sk = S.unitSortKey(r)
        if (old) {
            const osk = S.unitSortKey(old)
            if (osk === sk) {
                const i = find(sk)
                if (i < order.length && order[i] === sk) { all.set(i, roleOf(r)); byKey[r.key] = r; return }
            }
            removeKey(r.key)
        }
        const j = find(sk)
        order.splice(j, 0, sk)
        all.insert(j, roleOf(r))
        byKey[r.key] = r
    }
    // A services-query units event: the full list, or what changed.
    function apply(ev) {
        if (!ev || ev.type !== "units") return
        if (ev.full) {
            const rows = []
            const keep = {}
            for (const u of ev.rows || []) { const r = S.everyRow(u, items); if (r) { rows.push(r); keep[r.key] = r } }
            rows.sort((a, b) => S.unitSortKey(a) < S.unitSortKey(b) ? -1 : 1)
            byKey = keep
            order = rows.map(S.unitSortKey)
            all.clear()
            all.append(rows.map(roleOf))
        } else {
            for (const k of ev.gone || []) removeKey(k)
            for (const u of ev.rows || []) {
                const r = S.everyRow(u, items)
                if (r) upsert(r)
                else removeKey(u.key)
            }
        }
        loaded = true
        error = ""
        refresh()
        rev++
    }
    property int rev: 0                      // bumps on every change (the aside re-reads its row)
    function refresh() {
        const rows = Object.keys(byKey).map(k => byKey[k])
        countsText = S.unitCounts(rows)
        if (query.trim() !== "") {
            found.clear()
            const hits = rows.filter(r => S.unitMatches(r, query)).sort((a, b) => S.unitSortKey(a) < S.unitSortKey(b) ? -1 : 1)
            if (hits.length) found.append(hits.map(roleOf))
        }
    }
    function rowOf(key) { return byKey[key] || null }
    onQueryChanged: refresh()

    ListModel { id: all }
    ListModel { id: found }

    // ---- toolbar ----------------------------------------------------------------------------------------
    Item {
        id: toolbar
        width: parent.width
        height: 58
        Rectangle { anchors.bottom: parent.bottom; width: parent.width; height: 1; color: Theme.white(0.05) }
        SearchField {
            id: search
            x: 14
            anchors.verticalCenter: parent.verticalCenter
            width: Math.max(150, Math.min(240, toolbar.width - everyBtn.width - 48 - counts.implicitWidth))
            implicitHeight: 34
            placeholder: "Search services"
            onEdited: (t) => root.query = t
            onEscapePressed: { text = ""; root.query = "" }
        }
        Text {
            id: counts
            anchors { left: search.right; leftMargin: 12; right: everyBtn.left; rightMargin: 10; verticalCenter: parent.verticalCenter }
            text: root.countsText
            textFormat: Text.PlainText
            elide: Text.ElideRight
            font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
            color: Theme.textMuted
        }
        Button {
            id: everyBtn
            anchors { right: parent.right; rightMargin: 14; verticalCenter: parent.verticalCenter }
            variant: "soft"; size: 34; glyph: Icons.activity; text: "Live log of all"
            accessibleName: "Live log of every service"
            onClicked: root.openEvery()
        }
    }

    // ---- the list ---------------------------------------------------------------------------------------
    ListView {
        id: list
        anchors { left: parent.left; right: parent.right; top: toolbar.bottom; bottom: parent.bottom; leftMargin: 10; rightMargin: 10 }
        topMargin: 4
        bottomMargin: 16
        clip: true
        model: root.query.trim() !== "" ? found : all
        reuseItems: true
        boundsBehavior: Flickable.StopAtBounds
        section.property: "sec"
        section.delegate: Item {
            required property string section
            width: list.width
            height: 35
            Text {
                x: 8; y: 14
                text: section
                font.family: Theme.fontMono; font.pointSize: Theme.pt(10.5); font.letterSpacing: 1.05
                color: section === "FAILED" ? "#FF8F8F" : Theme.textFaint
            }
        }
        delegate: Pressable {
            id: row
            required property string rkey
            required property string name
            required property string unitName
            required property bool user
            required property string label
            required property string tone
            required property bool quasar
            width: list.width
            height: 44
            kind: "hov"
            radius: 11
            interactiveContent: true
            readonly property bool selected: root.selectedKey === rkey
            color: selected || root.hover === rkey ? Theme.white(0.07) : "transparent"
            hoverColor: Theme.white(0.07)
            borderColor: selected ? Theme.alpha(Theme.accent, 0.35) : "transparent"
            hoverBorderColor: borderColor
            accessibleName: name + ", " + label
            onClicked: root.select(rkey)
            onDoubleClicked: { const r = root.rowOf(rkey); if (r) root.openConsole(r.console) }

            readonly property color toneColor: tone === "fail" ? "#FF8F8F" : tone === "accent" ? Theme.accent : Theme.textDim
            Rectangle {
                id: dot
                x: 12
                anchors.verticalCenter: parent.verticalCenter
                width: 8; height: 8; radius: 4
                color: row.toneColor
                opacity: row.tone === "dim" ? 0.6 : 1
            }
            Column {
                anchors { left: dot.right; leftMargin: 12; right: statusText.left; rightMargin: 12; verticalCenter: parent.verticalCenter }
                spacing: 1
                Row {
                    spacing: 7
                    width: parent.width
                    Text {
                        id: nameText
                        width: Math.min(implicitWidth, parent.width - (yours.visible ? yours.width + 7 : 0))
                        text: row.name
                        textFormat: Text.PlainText
                        elide: Text.ElideRight
                        font.family: Theme.fontUi; font.pixelSize: 13; font.weight: Font.Medium
                        color: Theme.text
                    }
                    Rectangle {
                        id: yours
                        visible: row.user || row.quasar
                        anchors.verticalCenter: nameText.verticalCenter
                        width: yoursText.implicitWidth + 10; height: 16; radius: 5
                        color: Theme.white(0.07)
                        Text {
                            id: yoursText
                            anchors.centerIn: parent
                            text: row.quasar ? "Services" : "yours"
                            font.family: Theme.fontUi; font.pointSize: Theme.pt(10)
                            color: Theme.textMuted
                        }
                    }
                }
                Text {
                    width: parent.width
                    text: row.unitName
                    textFormat: Text.PlainText
                    elide: Text.ElideMiddle
                    font.family: Theme.fontMono; font.pointSize: Theme.pt(10.5)
                    color: Theme.textFaint
                }
            }
            Text {
                id: statusText
                anchors { right: consoleBtn.left; rightMargin: 8; verticalCenter: parent.verticalCenter }
                text: row.label
                font.family: Theme.fontUi; font.pixelSize: 12; font.weight: Font.DemiBold
                color: row.toneColor
            }
            Button {
                id: consoleBtn
                anchors { right: parent.right; rightMargin: 6; verticalCenter: parent.verticalCenter }
                variant: "ghost"; size: 30; glyph: Icons.terminal; text: ""
                accessibleName: "Open " + row.name + "'s log"
                opacity: row.hovered || row.selected || root.hover === row.rkey ? 1 : 0
                onClicked: { const r = root.rowOf(row.rkey); if (r) root.openConsole(r.console) }
            }
        }
        OverlayScrollBar { flick: list }
    }

    // ---- states -----------------------------------------------------------------------------------------
    Spinner {
        visible: !root.loaded && root.error === ""
        anchors { horizontalCenter: list.horizontalCenter; top: toolbar.bottom; topMargin: 44 }
        size: 18
    }
    Column {
        visible: root.error !== ""
        anchors { horizontalCenter: list.horizontalCenter; top: toolbar.bottom; topMargin: 40 }
        width: Math.min(420, list.width - 40)
        spacing: 12
        Text {
            width: parent.width
            horizontalAlignment: Text.AlignHCenter
            text: "Services couldn't list this PC's services."
            font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
            color: Theme.text2
        }
        Text {
            width: parent.width
            horizontalAlignment: Text.AlignHCenter
            text: root.error
            textFormat: Text.PlainText
            wrapMode: Text.Wrap
            font.family: Theme.fontUi; font.pointSize: Theme.pt(12)
            color: Theme.textDim
        }
        Button {
            anchors.horizontalCenter: parent.horizontalCenter
            variant: "soft"; size: 34; glyph: Icons.refresh; text: "Try again"
            onClicked: root.retry()
        }
    }
    Text {
        visible: root.loaded && root.error === "" && list.count === 0
        anchors { horizontalCenter: list.horizontalCenter; top: toolbar.bottom; topMargin: 40 }
        text: root.query.trim() !== "" ? "No services match." : "No services found."
        font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
        color: Theme.textDim
    }
}
