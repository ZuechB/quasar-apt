import QtQuick

// Group of rows (template Settings "setGroups"): caps label (JetBrains Mono 10.5, .1em, #7D8598,
// padding 0 4 8) over a radius-16 box (white .035 fill, white .06 hairline). Rows go inside and
// draw their own top divider when they are not the first row (see SettingsRow).
Column {
    id: root
    property string label: ""
    default property alias rows: box.data
    spacing: 0
    width: parent ? parent.width : implicitWidth

    SectionLabel {
        visible: root.label !== ""
        text: root.label
        leftPadding: 4
        bottomPadding: 8
    }
    Rectangle {
        width: parent.width
        height: box.implicitHeight
        radius: 16
        color: Theme.white(0.035)
        border.width: 1
        border.color: Theme.white(0.06)
        Column {
            id: box
            width: parent.width
        }
    }
}
