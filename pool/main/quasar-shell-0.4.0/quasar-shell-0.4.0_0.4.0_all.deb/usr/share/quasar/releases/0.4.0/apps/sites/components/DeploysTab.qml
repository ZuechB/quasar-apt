import QtQuick
import Quasar
import "runtime.js" as RT

// Template Sites › Deployments: newest first; a check for the live one (LIVE badge), a clock for
// older ones you can roll back to, a red alert with the build error for failed ones.
Rectangle {
    id: root
    property var site: null
    property var deploys: []
    property var releases: []
    property real now: Date.now()
    property bool busy: false
    signal rollback(string release)

    implicitHeight: deploys.length ? list.implicitHeight : 64
    radius: 18
    color: Theme.white(0.035)
    border.width: 1; border.color: Theme.white(0.06)

    Text {
        visible: root.deploys.length === 0
        anchors.centerIn: parent
        text: "No deployments yet."
        font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
        color: Theme.textFaint
    }

    Column {
        id: list
        width: parent.width
        Repeater {
            model: root.deploys
            delegate: Item {
                id: row
                required property var modelData
                required property int index
                readonly property bool current: !!root.site && modelData.ok && modelData.release === root.site.release
                readonly property bool kept: modelData.ok && root.releases.indexOf(modelData.release) >= 0
                readonly property color tone: !modelData.ok ? Theme.danger : current ? Theme.mint : Theme.textDim
                width: list.width
                height: body.implicitHeight + 24
                Rectangle { visible: row.index > 0; anchors { left: parent.left; right: parent.right; top: parent.top } height: 1; color: Theme.white(0.05) }
                QIcon {
                    id: ic
                    x: 16; y: 14
                    path: !row.modelData.ok ? Icons.alert : row.current ? Icons.check : Icons.clock
                    size: 16; strokeWidth: 2.2
                    color: row.tone
                }
                Column {
                    id: body
                    anchors { left: ic.right; leftMargin: 12; right: rb.left; rightMargin: 12; top: parent.top; topMargin: 12 }
                    spacing: 4
                    Row {
                        spacing: 8
                        Text {
                            text: row.modelData.hash || "–"
                            font.family: Theme.fontMono; font.pointSize: Theme.pt(12.5)
                            color: Theme.text3
                        }
                        Text {
                            text: row.modelData.msg || ""
                            textFormat: Text.PlainText
                            elide: Text.ElideRight
                            width: Math.min(implicitWidth, body.width - 140)
                            font.family: Theme.fontUi; font.pixelSize: 13; font.weight: Font.Medium
                            color: Theme.text
                        }
                        Rectangle {
                            visible: row.current
                            anchors.verticalCenter: parent.verticalCenter
                            width: liveTxt.implicitWidth + 12; height: 18; radius: 6
                            color: Theme.alpha(Theme.mint, 0.14)
                            Text { id: liveTxt; anchors.centerIn: parent; text: "LIVE"; font.family: Theme.fontMono; font.pixelSize: 10; font.weight: Font.DemiBold; color: Theme.mint }
                        }
                    }
                    Text {
                        text: (row.modelData.ok ? "Deployed " : "Failed ") + RT.dur(root.now - row.modelData.at * 1000) + " ago, took " + (row.modelData.dur || "–")
                        font.family: Theme.fontUi; font.pixelSize: 12
                        color: Theme.textDim
                    }
                    Rectangle {
                        visible: !!row.modelData.err
                        width: body.width
                        height: errTxt.implicitHeight + 16
                        radius: 10
                        color: "#06070B"
                        border.width: 1; border.color: Theme.alpha(Theme.danger, 0.25)
                        TextEdit {
                            id: errTxt
                            anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; margins: 10 }
                            readOnly: true; selectByMouse: true
                            text: row.modelData.err || ""
                            textFormat: TextEdit.PlainText
                            wrapMode: TextEdit.WrapAnywhere
                            font.family: Theme.fontMono; font.pointSize: Theme.pt(11.5)
                            color: "#FFB3B3"
                        }
                    }
                }
                Button {
                    id: rb
                    anchors { right: parent.right; rightMargin: 14; top: parent.top; topMargin: 10 }
                    visible: row.kept && !row.current
                    variant: "outline"; size: 30
                    text: "Roll back to this"
                    enabled: !root.busy
                    onClicked: root.rollback(row.modelData.release)
                }
            }
        }
    }
}
