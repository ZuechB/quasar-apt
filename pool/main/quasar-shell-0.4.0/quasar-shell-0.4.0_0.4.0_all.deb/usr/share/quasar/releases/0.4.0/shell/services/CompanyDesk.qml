import QtQuick
import Quickshell
import Quickshell.Io
import Quickshell.Wayland
import Quickshell.WindowManager
import Quasar
import Quasar.Services
import "attribution.js" as Attr

// Company environments in the shell. Each company is a hidden account with its own network and its own
// labwc desktop (see ui/Quasar/Services/Companies.qml and /usr/libexec/quasar/quasar-company-admin).
// This keeps the shown company in step with labwc's active desktop, starts and stops companies, runs
// the apps launched while a company is shown inside that company, works out which company owns each
// window (the taskbar shows only the shown company's), and writes the labwc layer with the companies'
// desktops and window rules. Companies need labwc (its sandbox window rules place their windows).
Scope {
    id: root
    property var apps: null                  // shell/services/Apps.qml (desktop entries for windows)
    signal toast(var t)
    signal closePanels()
    signal menuRequested()

    // Quasar apps that run as the owner. "follow" ones are shown on every desktop (labwc omnipresent
    // rule); the others open on the desktop that is shown.
    readonly property var followApps: ["quasar-settings", "quasar-store", "quasar-installer", "quasar-services", "quasar-taskmanager"]
    readonly property var ownerApps: ["quasar-files", "quasar-texteditor", "quasar-photos", "quasar-containers"]

    readonly property bool supported: (Quickshell.env("QUASAR_COMPOSITOR") || "labwc") === "labwc"
    readonly property bool showSwitcher: supported && Companies.companies.length > 0
    readonly property string active: Companies.active
    property var switching: null             // { to, phase: "out" | "in", cold, failed, since }
    property int revision: 0                 // bumps whenever window ownership changes
    property var appsOf: ({})                // company id -> desktop ids it can launch (agent "apps")

    readonly property string configHome: Quickshell.env("XDG_CONFIG_HOME") || (Companies.home + "/.config")
    readonly property string layerDir: configHome + "/quasar/companies-xdg/labwc"

    // ------------------------------------------------------------------ desktops (labwc ext-workspace)
    readonly property var windowsets: WindowManager.windowsets
    readonly property var activeSet: windowsets.find(w => w.active) || null
    function desktopOf(id) {
        const named = windowsets.find(w => w.name === id)
        if (named) return named
        return id === "personal" && windowsets.length ? windowsets[0] : null   // before our layer applies
    }
    function companyOfDesktop(w) {
        if (!w) return ""
        if (w.name === "personal" || windowsets.indexOf(w) === 0) return "personal"
        return Companies.byId(w.name) ? w.name : ""
    }
    onActiveSetChanged: _followDesktop()
    // A desktop change the shell didn't make (Super+N, or a hidden company's window got the focus):
    // follow it without the overlay, and start that company if it isn't running.
    function _followDesktop() {
        const id = companyOfDesktop(activeSet)
        if (!id || id === Companies.active || (switching && switching.to === id)) return
        Companies.active = id
        _clearAlerts(id)
        Companies.publish()
        if (!Companies.isRunning(id) && root._probed[id] !== "pending") start(id)
    }

    // ------------------------------------------------------------------ switching
    function go(n) { const c = Companies.list[n - 1]; if (c) switchTo(c.id) }
    function switchTo(id) {
        const c = Companies.byId(id)
        if (!c || !supported) return
        closePanels()
        if (id === Companies.active && !switching) return
        const cold = !Companies.isRunning(id)
        // Lite and reduced motion: a running company is just there; a cold start still shows progress.
        if (!cold && (Theme.reduceMotion || Theme.profile === 0)) { switching = null; _arrive(id); return }
        switching = { to: id, phase: "out", cold: cold, failed: "", since: Date.now() }
        if (cold) start(id)
        outTimer.restart()
    }
    Timer { id: outTimer; interval: 420; onTriggered: root._tryArrive() }
    // Polls only while a cold-started company comes up (at most 25 s).
    Timer { id: waitTimer; interval: 120; onTriggered: root._tryArrive() }
    Timer { id: endTimer; interval: 760; onTriggered: root.switching = null }
    Timer { id: failTimer; interval: 2600; onTriggered: { root.switching = null } }
    function _tryArrive() {
        const s = switching
        if (!s || s.phase !== "out") return
        if (s.failed) { failTimer.restart(); return }
        if (!Companies.isRunning(s.to) || !desktopOf(s.to)) {
            if (Date.now() - s.since > 25000) { switching = Object.assign({}, s, { failed: "It's taking too long to start" }); failTimer.restart() }
            else waitTimer.restart()
            return
        }
        _arrive(s.to)
        switching = Object.assign({}, s, { phase: "in" })
        endTimer.restart()
    }
    function _arrive(id) {
        Companies.active = id
        _clearAlerts(id)
        Companies.publish()
        const w = desktopOf(id)
        if (w && w.canActivate) w.activate()
    }
    function _clearAlerts(id) {
        if (!Companies.alerts[id]) return
        const a = Object.assign({}, Companies.alerts)
        delete a[id]
        Companies.alerts = a
    }

    // ------------------------------------------------------------------ start / stop
    Component { id: cmdComponent; Cmd { } }
    function _cmd(argv, done) {
        const p = cmdComponent.createObject(root)
        p.finished.connect((code) => { const out = p.tail.slice(); p.destroy(); if (done) done(code, out) })
        p.run(argv)
    }
    function _errorIn(out, fallback) {
        const e = out.find(l => l.startsWith("ERROR "))
        return e ? e.slice(6) : fallback
    }
    function start(id) {
        if (id === "personal" || Companies.isRunning(id) || Companies.starting.indexOf(id) >= 0) return
        Companies.starting = Companies.starting.concat([id])
        const f = Object.assign({}, Companies.failed)
        delete f[id]
        Companies.failed = f
        Companies.publish()
        _cmd(["pkexec", "/usr/libexec/quasar/quasar-company-ctl", "start", id], (code, out) => {
            if (code !== 0 || out.indexOf("READY") < 0) {
                _startFailed(id, code === 126 ? "Cancelled" : _errorIn(out, "It didn't start"))
                return
            }
            _attach(id)
        })
    }
    // A running company: give it this desktop (its Wayland socket) and sound, then talk to its agent.
    function _attach(id) {
        _cmd(["systemctl", "--user", "start", "quasar-companies-pulse.service", "quasar-company-display@" + id + ".service"], (code) => {
            if (code !== 0) console.warn("company", id, ": display or sound unit didn't start")
            _connect(id)
        })
    }
    property var _wired: ({})
    property var _subscribed: ({})
    function _connect(id) {
        const a = Companies.agent(id)
        if (_subscribed[id] && _wired[id] === a) { _running(id); return }   // already attached on this connection
        _subscribed[id] = true
        if (_wired[id] !== a) {                            // a new connection object: listen to it
            _wired[id] = a
            a.event.connect((e) => root._agentEvent(id, e))
            a.lost.connect(() => { if (root._wired[id] === a) root._lost(id) })
        }
        a.request({ op: "subscribe" }, { onReply: (r) => {
            console.info("company", id, "agent:", r.ok ? "connected" : "not answering (" + r.error + ")")
            if (!r.ok) { root._subscribed[id] = false; _startFailed(id, r.error || "Its agent isn't answering"); return }
            const env = {}
            for (const k of ["QUASAR_RENDER", "QUASAR_SOFTWARE_RENDER", "LIBGL_ALWAYS_SOFTWARE", "GSK_RENDERER", "XCURSOR_THEME", "XCURSOR_SIZE"]) {
                const v = Quickshell.env(k)
                if (v) env[k] = v
            }
            a.request({ op: "display", state: "ready", env: env }, { onReply: (d) => {
                if (!d.ok) console.warn("company", id, "display:", d.error)
                root._running(id)
            } })
            a.request({ op: "apps" }, { onReply: (l) => {
                if (!l.ok || !Array.isArray(l.apps)) return
                const m = Object.assign({}, root.appsOf)
                m[id] = l.apps
                root.appsOf = m
            } })
        } })
    }
    function _running(id) {
        Companies.starting = Companies.starting.filter(x => x !== id)
        if (Companies.running.indexOf(id) < 0) Companies.running = Companies.running.concat([id])
        Companies.publish()
        if (switching && switching.to === id) _tryArrive()
    }
    function _startFailed(id, why) {
        Companies.starting = Companies.starting.filter(x => x !== id)
        const f = Object.assign({}, Companies.failed)
        f[id] = why
        Companies.failed = f
        Companies.publish()
        if (switching && switching.to === id) {
            switching = Object.assign({}, switching, { failed: why })
            failTimer.restart()
        } else {
            const c = Companies.byId(id)
            toast({ title: "Couldn't start " + (c ? c.name : id), sub: why, glyph: Icons.brief, hue: Theme.amber })
        }
    }
    function _lost(id) {
        _subscribed[id] = false
        if (Companies.running.indexOf(id) < 0) return
        Companies.running = Companies.running.filter(x => x !== id)
        Companies.publish()
        if (Companies.active === id) switchTo("personal")
    }
    function stop(id) {
        if (id === "personal" || !Companies.byId(id)) return
        if (Companies.active === id) switchTo("personal")
        _cmd(["systemctl", "--user", "stop", "quasar-company-display@" + id + ".service"], () => {
            _cmd(["pkexec", "/usr/libexec/quasar/quasar-company-ctl", "stop", id], (code, out) => {
                if (code !== 0) {
                    const c = Companies.byId(id)
                    toast({ title: "Couldn't stop " + (c ? c.name : id), sub: _errorIn(out, ""), glyph: Icons.brief, hue: Theme.amber })
                }
            })
        })
    }

    // Company notifications arrive through its agent: shown now for the company on screen (or when
    // critical), otherwise counted and shown as the switcher's alert dot.
    // The desktop entry a command line starts ("footclient …", "flatpak run org.x.App …"), as the
    // shell's window matching (Apps.entryFor) sees it.
    function _entryIdForArgv(argv) {
        if (!Array.isArray(argv) || !argv.length) return ""
        let id = String(argv[0]).split("/").pop()
        if (id === "flatpak") { const i = argv.indexOf("run"); if (i >= 0) id = argv.slice(i + 1).find(a => !String(a).startsWith("-")) || id }
        const e = apps ? apps.entryFor(id) : null
        return e ? e.id : id
    }
    function _agentEvent(id, e) {
        if (e && e.event === "spawned") {                 // anything the company's agent started
            const eid = _entryIdForArgv(e.argv)
            if (eid) Attr.noteLaunch(ownership, id, eid, Date.now())
            return
        }
        if (!e || e.event !== "notify") return
        const c = Companies.byId(id)
        if (id === Companies.active || e.urgency === 2) {
            toast({ title: String(e.summary || e.app || "Notification"), sub: String(e.body || ""), glyph: Icons.bell,
                    hue: c ? c.color : Theme.accent, company: id })
        } else {
            const a = Object.assign({}, Companies.alerts)
            a[id] = (a[id] || 0) + 1
            Companies.alerts = a
            Companies.publish()
        }
    }

    // ------------------------------------------------------------------ launching
    // Apps.launch asks first; true = it now runs inside the shown company (the shell doesn't start it).
    function route(e, args) {
        const id = Companies.active
        if (!supported || id === "personal" || !e) return false
        if (followApps.indexOf(e.id) >= 0 || ownerApps.indexOf(e.id) >= 0) return false
        // AppImages added to Apps live in your home, which a company can't read: they run as you.
        if (/^quasar-appimage-/.test(e.id)) return false
        let argv = e.command.slice()
        if (args && args.length) argv = argv.concat(args)
        if (e.runInTerminal) argv = ["footclient", "-E", "--"].concat(argv)
        Attr.noteLaunch(ownership, id, e.id, Date.now())
        const c = Companies.current
        Companies.run(id, argv, e.workingDirectory || c.home, (r) => {
            if (!r.ok) toast({ title: "Couldn't open " + e.name + " in " + c.name, sub: String(r.error || ""), glyph: Icons.brief, hue: Theme.amber })
        })
        return true
    }
    // A terminal inside the shown company; false in Personal. A folder in Personal's home becomes the
    // company's home (the company can't enter Personal's files).
    function terminal(dir) {
        const id = Companies.active
        if (!supported || id === "personal") return false
        const c = Companies.current
        const own = Companies.home
        const cwd = !dir || dir === own || dir.startsWith(own + "/") ? c.home : dir
        Companies.agent(id).request({ op: "terminal", cwd: cwd }, { onReply: (r) => {
            if (!r.ok) toast({ title: "Couldn't open a terminal in " + c.name, sub: String(r.error || ""), glyph: Icons.terminal, hue: Theme.amber })
        } })
        return true
    }
    // Files: Personal's home becomes the shown company's.
    function filesPath(path) {
        if (Companies.active === "personal") return path
        return !path || path === Companies.home ? Companies.current.home : path
    }
    // Launcher: in a company only what that company can launch (Personal's own user entries aren't there).
    readonly property var allowedApps: {
        const id = Companies.active
        if (id === "personal" || !appsOf[id]) return null
        return new Set(appsOf[id].concat(followApps, ownerApps))
    }

    // ------------------------------------------------------------------ window ownership
    property var ownership: Attr.create()
    readonly property var tops: ToplevelManager.toplevels.values
    readonly property var focusedTop: ToplevelManager.activeToplevel
    readonly property double startedAt: Date.now()
    property var _births: []
    property double _activationDue: 0
    onTopsChanged: _sync()
    // Only a change of the focused window triggers rule 2: after a desktop switch labwc may leave the
    // previous desktop's window "activated", and that must not move it.
    onFocusedTopChanged: { _activationDue = Date.now() + Attr.ACTIVATION_DELAY; checkTimer.start() }
    function _sync() {
        const now = Date.now()
        const r = Attr.sync(ownership, tops, {
            active: Companies.active, now: now, initial: now - startedAt < 2500,
            entryIdOf: (t) => { const e = root.apps ? root.apps.entryFor(t.appId) : null; return e ? e.id : (t.appId || "") },
            isFollow: (id) => root.followApps.indexOf(id) >= 0
        })
        if (r.born.length) {
            _births = _births.concat(r.born.map(t => ({ t: t, due: now + Attr.BIRTH_DELAY })))
            checkTimer.start()
        }
        if (r.changed) revision++
    }
    // Runs only while a decision is pending (an activation to confirm or a new window to place).
    Timer { id: checkTimer; interval: 50; repeat: true; onTriggered: root._check() }
    function _check() {
        const now = Date.now()
        let changed = false
        if (_activationDue && now >= _activationDue) {
            _activationDue = 0
            const t = ToplevelManager.activeToplevel
            if (t && t.activated && tops.indexOf(t) >= 0) changed = Attr.activated(ownership, Attr.mainOf(t), Companies.active) || changed
        }
        if (_births.length) {
            const due = _births.filter(b => now >= b.due)
            if (due.length) {
                _births = _births.filter(b => now < b.due)
                const ctx = { active: Companies.active, running: ["personal"].concat(Companies.running) }
                for (const b of due) if (tops.indexOf(b.t) >= 0) changed = Attr.birthTimeout(ownership, b.t, ctx) || changed
            }
        }
        if (changed) revision++
        if (!_activationDue && !_births.length) checkTimer.stop()
    }
    function isShown(t) { return !supported || Attr.isShown(ownership, t, Companies.active) }
    readonly property var unplaced: { revision; tops; return Attr.unplaced(ownership) }
    function showUnplaced() {
        const t = unplaced[0]
        if (!t) return
        if (t.minimized) t.minimized = false
        t.activate()                         // labwc switches to its desktop; rule 2 then places it
    }

    // ------------------------------------------------------------------ labwc layer
    // Desktops are positional in labwc (a reload renames them by index and removes from the end), so
    // slots are append-only: a deleted company leaves a placeholder until it's the last one.
    FileView { id: layerFile; path: root.layerDir + "/rc.xml"; blockLoading: true; printErrors: false }
    property string _written: ""
    function _slots() {
        const ids = Companies.registry.map(c => c.id)
        let old = []
        const m = (root._written || layerFile.text() || "").match(/<name>[^<]*<\/name>/g) || []
        old = m.map(x => x.slice(6, -7))
        let s = old.length && old[0] === "personal" ? old.slice() : ["personal"]
        s = s.map((n, i) => i === 0 || ids.indexOf(n) >= 0 ? n : "-")
        for (const id of ids) {
            if (s.indexOf(id) >= 0) continue
            const hole = s.indexOf("-")
            if (hole > 0) s[hole] = id; else s.push(id)
        }
        while (s.length > 1 && s[s.length - 1] === "-") s.pop()
        return s
    }
    function layerXml() {
        const s = _slots()
        let x = "<?xml version=\"1.0\"?>\n<!-- Written by the Quasar shell (company environments): one desktop per company and the\n"
              + "     rules that put each company's windows on its desktop. Don't edit; it is rewritten. -->\n<labwc_config>\n"
              + "  <desktops number=\"" + s.length + "\">\n    <popupTime>0</popupTime>\n    <names>\n"
        for (const n of s) x += "      <name>" + n + "</name>\n"
        x += "    </names>\n  </desktops>\n  <windowRules>\n"
        for (const c of Companies.registry)
            x += "    <windowRule sandboxEngine=\"org.quasar.company\" sandboxAppId=\"" + c.id + "\">\n"
               + "      <action name=\"SendToDesktop\" to=\"" + c.id + "\" follow=\"no\" />\n    </windowRule>\n"
        for (const a of followApps)
            x += "    <windowRule identifier=\"" + a + "\">\n      <action name=\"ToggleOmnipresent\" />\n    </windowRule>\n"
        return x + "  </windowRules>\n</labwc_config>\n"
    }
    function writeLayer() {
        if (!supported || !Companies.registryLoaded) return
        const xml = layerXml()
        if (xml === (_written || layerFile.text())) return
        _written = xml
        Quickshell.execDetached(["sh", "-c", "mkdir -p \"$1\" && printf '%s' \"$2\" > \"$1/rc.xml.tmp\" && mv \"$1/rc.xml.tmp\" \"$1/rc.xml\" && labwc -r",
                                 "sh", layerDir, xml])
    }
    // The registry loads after the shell starts and changes when Settings adds or deletes a company.
    Connections {
        target: Companies
        function onRegistryChanged() { root._registryReady() }
        function onRegistryLoadedChanged() { root._registryReady() }
    }
    function _registryReady() {
        if (!Companies.registryLoaded) return
        writeLayer()
        _followDesktop()
        _probe()
    }
    // Each company once: already running (the shell restarted) -> attach; else start it if it starts
    // with the session.
    property var _probed: ({})
    function _probe() {
        for (const c of Companies.companies) {
            if (_probed[c.id]) continue
            _probed[c.id] = "pending"
            Companies.agent(c.id).request({ op: "ping" }, { onReply: (r) => {
                root._probed[c.id] = "done"
                console.info("company", c.id, r.ok ? "is running" : "is stopped")
                if (r.ok) root._attach(c.id)
                else if (c.autostart) root.start(c.id)
            } })
        }
    }

    // ------------------------------------------------------------------ startup
    Component.onCompleted: {
        Companies.writer = true
        Quickshell.execDetached(["mkdir", "-p", Companies.runtimeDir])
        Companies.active = "personal"
        Companies.publish()
        _registryReady()
    }

    // ------------------------------------------------------------------ IPC (keybinds, apps, tests)
    //   qs --path /usr/share/quasar/shell ipc call company go 2
    IpcHandler {
        target: "company"
        function go(n: int): void { root.go(n) }
        function switchTo(id: string): void { root.switchTo(id) }
        function start(id: string): void { root.start(id) }
        function stop(id: string): void { root.stop(id) }
        function menu(): void { root.menuRequested() }
        function refresh(): void { Companies.reloadRegistry() }
        // A company started outside the shell (quasar-company-ctl in a terminal, tests): attach to it.
        function attach(id: string): void { if (Companies.byId(id)) root._attach(id) }
        function state(): string {
            return JSON.stringify({ active: Companies.active, running: Companies.running, starting: Companies.starting,
                                    failed: Companies.failed, desktops: root.windowsets.map(w => w.name),
                                    switching: root.switching, unplaced: root.unplaced.length,
                                    owners: root.tops.map(t => [t.appId, Attr.ownerOf(root.ownership, t)]) })
        }
    }
}
