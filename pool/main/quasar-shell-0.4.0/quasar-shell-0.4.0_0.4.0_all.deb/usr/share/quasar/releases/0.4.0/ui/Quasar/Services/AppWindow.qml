import QtQuick
import QtQuick.Window
import Quickshell
import Quickshell.Io
import Quasar

// A Quasar app window: the template's rounded frame (WindowFrame: 14px corners, hairline, shadow,
// title bar, content, resize band), drawn entirely by the app. labwc adds no decorations to
// quasar-* windows (linux/session/labwc/rc.xml). Moving, resizing, snapping and maximizing are
// still done by the compositor (startSystemMove/Resize), so windows follow the pointer 1:1. Size
// and maximized state are remembered.
//
// The surface is the frame plus a fixed margin for the shadow and the resize band (8px on the
// software path, shadow-sized on GPUs). Quasar.Native.Window's WindowShape tells the compositor
// the margin isn't part of the window (Qt custom margins: placement, snapping, maximize and size
// hints use the frame alone) and which part is opaque. Invariant: window size = frame + margins,
// always (a maximized window's transparent margin hangs off the screen, outside the input mask).
// Without the plugin the window is an opaque square, as it was before.
//
//   AppWindow { appName: "settings"; title: "Settings"; glyph: Icons.gear; SettingsView { anchors.fill: parent } }
FloatingWindow {
    id: win
    property string appName: "app"
    property string glyph: ""
    property color glyphColor: Theme.text3
    property color titleTint: "transparent"
    property size defaultSize: Qt.size(1020, 680)   // the frame
    property color background: Theme.windowOpaque   // the frame's fill (never set `color`)
    property bool busy: false                    // e.g. installing: closing hides instead of quitting
    property bool quitOnClose: true
    // false: a fixed, dialog-sized window (installer): defaultSize always, no grip, no maximize.
    property bool resizable: true
    // true: closing is refused (the window stays up) — the app reacts to closeRequested(), e.g. by
    // explaining why. Used while a step that must not be interrupted is running.
    property bool closeBlocked: false
    // Replaces the title text in the bar (the Terminal's tabs); the window title still names the window.
    property Item titleItem: null
    property int titleBarHeight: 46              // Terminal: 44 (template)
    property alias titleBar: frame.titleBar
    default property alias content: frame.content
    readonly property bool focused: frame.Window.active
    readonly property bool docked: maximized || fullscreen
    signal closeRequested()

    // ---- shape -----------------------------------------------------------------------------------
    // Decided while the window is being created: the surface format (translucent or not) is fixed then.
    readonly property Component _shapeComponent: Qt.createComponent(Qt.resolvedUrl("NativeWindowShape.qml"))
    readonly property var _wantMargins: Platform.softwareScene
        ? { left: frame.bandRoom, top: frame.bandRoom, right: frame.bandRoom, bottom: frame.bandRoom }
        : frame.shadowMargins
    readonly property QtObject _shape: _shapeComponent.status === Component.Ready
        ? _shapeComponent.createObject(win.contentItem, {
            marginLeft: _wantMargins.left, marginTop: _wantMargins.top,
            marginRight: _wantMargins.right, marginBottom: _wantMargins.bottom })
        : null
    readonly property bool shaped: !!_shape && _shape.supported
    readonly property var _m: shaped ? _wantMargins : { left: 0, top: 0, right: 0, bottom: 0 }
    Component.onCompleted: if (!shaped) console.warn("AppWindow: Quasar.Native.Window unavailable, square window:",
                                                     _shapeComponent.errorString() || "not supported here")
    Binding { target: win._shape; property: "radius"; value: frame.radius; when: win.shaped }
    // Opaque once the entrance has settled (a fading frame isn't opaque) and while the fill is.
    Binding { target: win._shape; property: "opaque"; value: win._settled && win.background.a >= 1; when: win.shaped }

    color: shaped ? "transparent" : background

    implicitWidth: (resizable && _saved.w > 0 ? _saved.w : defaultSize.width) + _m.left + _m.right
    implicitHeight: (resizable && _saved.h > 0 ? _saved.h : defaultSize.height) + _m.top + _m.bottom
    minimumSize: resizable ? Qt.size(560 + _m.left + _m.right, 380 + _m.top + _m.bottom)
                           : Qt.size(defaultSize.width + _m.left + _m.right, defaultSize.height + _m.top + _m.bottom)
    Binding { target: win; property: "maximumSize"; value: win.minimumSize; when: !win.resizable }

    function requestClose() {
        win.closeRequested()
        if (win.closeBlocked) { win.visible = true; return }
        if (win.busy) { win.visible = false; return }
        if (win.quitOnClose) Qt.quit()
    }
    onClosed: requestClose()                     // compositor close (keybind, taskbar menu)

    // ---- window chrome ------------------------------------------------------------------------
    Item {
        id: entrance
        x: win._m.left
        y: win._m.top
        width: win.width - win._m.left - win._m.right
        height: win.height - win._m.top - win._m.bottom
        // First-frame entrance (labwc has no window animations): the window settles in with a short
        // spring. Skipped in Lite, where every frame is a full software repaint.
        opacity: _entered || Theme.profile === 0 || Theme.reduceMotion ? 1 : 0
        scale: _entered || Theme.profile === 0 || Theme.reduceMotion ? 1 : 0.97
        Behavior on opacity { NumberAnimation { duration: Motion.dur(260) } }
        Behavior on scale { NumberAnimation { duration: Motion.dur(Motion.chip); easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.spring } }

        WindowFrame {
            id: frame
            anchors.fill: parent
            rounded: win.shaped
            shadow: win.shaped && !Platform.softwareScene
            band: win.shaped ? 8 : 0
            background: win.background
            active: win.focused
            maximized: win.maximized
            fullscreen: win.fullscreen
            resizable: win.resizable
            title: win.title
            glyph: win.glyph
            glyphColor: win.glyphColor
            titleTint: win.titleTint
            titleItem: win.titleItem
            titleBarHeight: win.titleBarHeight
            onMoveRequested: win.startSystemMove()
            onMinimizeClicked: win.minimized = true
            onMaximizeClicked: if (win.resizable) win.maximized = !win.maximized
            onCloseClicked: win.requestClose()
            onResizeRequested: (edges) => win.startSystemResize(edges)
        }
        // No plugin: no margin to resize from, and labwc adds no resize area. A 3px strip inside the
        // edges (scrollbars keep 3px clear of them).
        ResizeEdges {
            anchors.fill: parent
            band: 3
            visible: !win.shaped && win.resizable && !win.docked
            onResizeRequested: (edges) => win.startSystemResize(edges)
        }
    }
    property bool _entered: false
    property bool _settled: false
    // From the first time it shows: a window made hidden (Services opened for a console) still gets its
    // entrance, and its first configure isn't taken for a resize (it wrote its size file before).
    Timer { interval: 16; running: win.visible && !win._entered; onTriggered: { win._entered = true; settleTimer.start() } }
    Timer { id: settleTimer; interval: 300; onTriggered: win._settled = true }

    // Input: the frame plus its resize band. The rest of the margin (the shadow; all of it while
    // maximized) lets clicks through to what's below. A direct child of the window, since a Region
    // follows only its own item's geometry.
    Item {
        id: hitArea
        readonly property int b: win.shaped && win.resizable && !win.docked ? frame.band : 0
        x: win._m.left - b
        y: win._m.top - b
        width: Math.max(1, win.width - win._m.left - win._m.right + 2 * b)
        height: Math.max(1, win.height - win._m.top - win._m.bottom + 2 * b)
    }
    mask: Region { item: hitArea }

    // ---- remembered size (the frame's) ----------------------------------------------------------
    // One file per kind of window in the app's state folder: a second kind (the Services consoles) sets its
    // own name, or it would open at the main window's size and save over it.
    property string stateName: "window"
    property var _saved: ({ w: 0, h: 0 })
    FileView {
        id: stateFile
        path: Quickshell.statePath(win.stateName + ".json")
        blockLoading: true
        printErrors: false
        onLoaded: {
            try {
                const o = JSON.parse(text())
                win._saved = { w: o.w || 0, h: o.h || 0 }
                if (o.maximized && win.resizable) win.maximized = true
            } catch (e) { }
        }
    }
    Timer {
        id: saveTimer
        interval: 600
        onTriggered: {
            const w = Math.round(win.width - win._m.left - win._m.right)
            const h = Math.round(win.height - win._m.top - win._m.bottom)
            if (win.maximized || w < 100) { stateFile.setText(JSON.stringify({ w: win._saved.w, h: win._saved.h, maximized: win.maximized })); return }
            win._saved = { w: w, h: h }
            stateFile.setText(JSON.stringify({ w: w, h: h, maximized: false }))
        }
    }
    onWidthChanged: if (_entered && resizable) saveTimer.restart()
    onHeightChanged: if (_entered && resizable) saveTimer.restart()
    onMaximizedChanged: if (_entered && resizable) saveTimer.restart()
}
