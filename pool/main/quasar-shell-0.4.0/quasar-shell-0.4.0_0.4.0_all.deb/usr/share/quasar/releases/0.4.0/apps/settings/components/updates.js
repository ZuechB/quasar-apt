// Settings > Updates: hero, rows and the Update history page, from `quasar-update status` /
// /run/quasar/update-state.json and `quasar-update history`. Pure, so the Settings app
// (services/Updates.qml) and the design preview share it.
//   st:  { live, auto, restartAt, checked, listsMissing, running, error,
//          pending: { total, security, kernel, removals, items: [{ name, from, to, security, origin }] },
//          restart: { needed, kernel, services, sites, session, flagged }, lastAuto: { time, ok, text },
//          lastInstall, apps }
//   ctx: { busy: "" | "check" | "install" | "auto" | "restart" | "apps", progress: -1..100, phase,
//          now (seconds), icons, theme }
.pragma library

var RESTART_TIMES = ["02:00", "03:00", "04:00", "05:00"]

function plural(n, one, many) { return n + " " + (n === 1 ? one : (many || one + "s")) }

function ago(t, now) {
    if (!t) return ""
    var s = Math.max(0, now - t)
    if (s < 90) return "just now"
    if (s < 3600) return plural(Math.round(s / 60), "minute") + " ago"
    if (s < 86400) return plural(Math.round(s / 3600), "hour") + " ago"
    if (s < 2 * 86400) return "yesterday"
    return plural(Math.floor(s / 86400), "day") + " ago"
}

function restartLabel(at) { return !at ? "Never" : at === "now" ? "Right away" : "At " + at }

// Why a restart is needed, in plain words.
function restartReason(r) {
    if (!r) return ""
    if (r.kernel) return "A new Linux kernel (" + r.kernel.replace(/-amd64$/, "") + ") starts after a restart."
    var other = (r.services || []).filter(function (u) { return (r.sites || []).indexOf(u) < 0 })
    if (r.session) return "Parts of your desktop still run the old version until you restart."
    if ((r.sites || []).length) return plural(r.sites.length, "website") + " still run" + (r.sites.length === 1 ? "s" : "") + " the old system libraries."
    if (other.length) return plural(other.length, "service") + " still run the old version."
    return "Some updates finish when the PC restarts."
}

// What's waiting, under a title that already says how many: "2 security fixes, including a new Linux kernel".
function pendingLine(p) {
    if (!p || !p.total) return ""
    var sec = !p.security ? "Bug fixes" : p.security === p.total ? (p.total === 1 ? "A security fix" : "All security fixes")
            : plural(p.security, "security fix", "security fixes")
    return sec + (p.kernel ? ", including a new Linux kernel" : "")
}
function when(stamp) { return (stamp || "").replace(/\s+/g, " ").replace(/:\d\d$/, "") }

// The page's state, decided once: { kind, title, sub, button, primary }.
function state(st, ctx) {
    var now = ctx.now || 0
    if (!st) return { kind: "loading", title: "Checking the update status…", sub: "", button: "", primary: false }
    if (st.live) return { kind: "live", title: "The live USB doesn't update",
                          sub: "Install Quasar on a disk: it then keeps itself up to date.", button: "", primary: false }
    if (ctx.busy === "install") return { kind: "installing", title: "Installing updates" + (ctx.progress >= 0 ? "  ·  " + ctx.progress + "%" : "…"),
                                         sub: ctx.phase || "Keep the PC on until this finishes.", button: "", primary: false }
    if (ctx.busy === "check") return { kind: "checking", title: "Checking for updates…", sub: ctx.phase || "", button: "", primary: false }
    if (st.running) return { kind: "running", title: "Updates are being installed",
                             sub: "Automatic updates or the Store are working; this page follows along.", button: "", primary: false }
    var p = st.pending || {}
    if (p.total) return { kind: "pending", title: p.total === 1 ? "1 update is ready" : p.total + " updates are ready",
                          sub: pendingLine(p) + (st.auto ? "  ·  They install by themselves within a day" : ""),
                          button: "Install now", primary: true }
    if (st.restart && st.restart.needed) return { kind: "restart", title: "Restart to finish installing updates",
                                                  sub: restartReason(st.restart) + (st.restartAt && st.restartAt !== "now" ? "  ·  Restarts by itself " + restartLabel(st.restartAt).toLowerCase() : ""),
                                                  button: "Restart", primary: true }
    if (st.listsMissing) return { kind: "unchecked", title: "Not checked yet",
                                  sub: st.auto ? "This PC checks by itself once it's online." : "Check to see what's available.",
                                  button: "Check now", primary: false }
    if (st.error) return { kind: "error", title: "Couldn't read the updates", sub: st.error, button: "Check now", primary: false }
    return { kind: "uptodate", title: "Quasar is up to date", sub: st.checked ? "Checked " + ago(st.checked, now) : "",
             button: "Check now", primary: false }
}

function hero(st, ctx) {
    var s = state(st, ctx)
    var t = ctx.theme
    var hot = s.kind === "pending" || s.kind === "restart"
    return { glyph: ctx.icons.refresh, title: s.title, sub: s.sub, button: s.button, buttonPrimary: s.primary,
             iconBg: hot ? t.accent : s.kind === "uptodate" ? t.mint : t.white(0.07),
             iconFg: hot || s.kind === "uptodate" ? t.accentInk : t.text3 }
}

function groups(st, ctx) {
    var icons = ctx.icons, live = !!(st && st.live)
    var auto = !!(st && st.auto), apps = !!(st && st.apps)
    var last = st && st.lastAuto
    var autoSub = live ? "Installed PCs check every day"
                : !auto ? "Off: updates install only when you choose"
                : last && last.time ? "Every day  ·  last run " + ago(last.time, ctx.now || 0) + (last.ok ? "" : ": " + last.text)
                : "Every day: Debian's security fixes and Quasar's updates"
    var system = [
        { key: "up:auto", label: "Install security updates automatically", glyph: icons.shield, trailing: live ? "value" : "toggle",
          checked: auto, busy: ctx.busy === "auto", value: live ? "Off" : "", sub: autoSub },
        { key: "up:restart", label: "Restart automatically when needed", glyph: icons.clock, trailing: live ? "value" : "chevron",
          value: restartLabel(st && st.restartAt), busy: ctx.busy === "restart",
          sub: "For a PC that runs on its own: finishes updates at night, even when someone is signed in" },
        { key: "up:history", label: "Update history", glyph: icons.list, trailing: "chevron", value: "",
          sub: st && st.lastInstall ? "Last: " + when(st.lastInstall.start) : "What was installed, and when" }
    ]
    var appsRows = [
        { key: "appUpdates", label: "App updates", glyph: icons.bag, trailing: "chevron", value: "Check",
          sub: "Flathub apps and developer tools, from the Store" },
        { key: "up:apps", label: "Update apps automatically", glyph: icons.refresh, trailing: live ? "value" : "toggle",
          checked: apps, busy: ctx.busy === "apps", value: live ? "Off" : "",
          sub: "Every day, apps and their runtimes, when plugged in" }
    ]
    var other = [
        { key: "up:ai", label: "AI engine", glyph: icons.orbit, trailing: "chevron", value: "",
          sub: "Updated from Settings › Quasar AI when you choose" },
        { key: "up:sources", label: "Where updates come from", glyph: icons.server, trailing: "value", value: "",
          sub: "Debian 13 and Quasar's signed repository, checked against their keys" }
    ]
    return [{ label: "System", rows: system }, { label: "Apps", rows: appsRows }, { label: "Other software", rows: other }]
}

function restartChoices() {
    return [{ key: "never", label: "Never", sub: "Quasar asks you to restart" }].concat(RESTART_TIMES.map(function (t) {
        return { key: t, label: "At " + t, sub: t === "04:00" ? "Recommended for a server" : "" }
    }))
}

// Update history page: one row per install, newest first.
function historyGroups(hist, ctx) {
    var icons = ctx.icons
    if (!hist || !hist.length) return [{ label: "History", rows: [
        { key: "uph:none", label: "Nothing installed yet", sub: "Updates show here once they install", trailing: "value", value: "" }] }]
    var rows = hist.map(function (e, i) {
        var names = (e.upgraded || []).concat(e.installed || [])
        var what = e.error ? "Didn't finish: " + e.error
                 : names.slice(0, 4).join(", ") + (names.length > 4 ? " and " + (names.length - 4) + " more" : "")
                   + ((e.removed || []).length ? (names.length ? "  ·  " : "") + "removed " + plural(e.removed.length, "old package") : "")
        return { key: "uph:" + i, label: e.error ? (e.auto ? "Automatic update didn't finish" : "Update didn't finish")
                                                 : (e.auto ? "Automatic: " : "") + plural(e.count, "package"),
                 glyph: e.error ? icons.alert : e.auto ? icons.refresh : icons.user,
                 trailing: "value", value: when(e.start),
                 valueColor: e.error ? ctx.theme.danger : "", sub: what }
    })
    return [{ label: "Installed", rows: rows }]
}

// The shell's toast after updates finished but need a restart (once per kernel/flag change).
function restartKey(st) {
    var r = st && st.restart
    if (!r || !r.needed) return ""
    return [r.kernel || "", r.flagged ? "flag" : "", (r.services || []).length ? "svc" : "", r.session ? "session" : ""].join("|")
}
