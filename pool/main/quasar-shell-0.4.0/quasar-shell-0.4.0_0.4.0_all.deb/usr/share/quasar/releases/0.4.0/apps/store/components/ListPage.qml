import QtQuick
import Quasar

// A scrolling page of app cards for any number of apps (a category of all of Flathub, search results,
// Installed). A ListView of rows over a list of ids: only the rows on screen (plus about one screen
// above and below) exist, rows scrolled away are recycled (in Qt 6.8 only ListView reuses delegates;
// GridView ignores reuseItems), a recycled row only re-points its cards at other ids, and a job's
// progress never rebuilds anything. The header and footer (title, chips, empty text, online search)
// scroll with the cards.
ListView {
    id: list
    property var ids: []
    property var view: null            // the StoreView (lookups and click signals)
    property int created: 0            // rows made so far (test IPC: `stats`)

    readonly property real contentW: width - leftMargin - rightMargin
    readonly property int cols: Math.max(1, Math.floor(contentW / 260))
    readonly property real cellW: Math.floor(contentW / cols)

    // The very top, header and top margin included (positionViewAtBeginning() leaves the margin out).
    function toTop() { forceLayout(); contentY = originY - topMargin }
    // A header that grows (the sort control wrapping onto its own row) moves the origin up: a list that
    // was at the top stays there.
    property real _lastOrigin: 0
    onOriginYChanged: {
        if (contentY <= _lastOrigin - topMargin + 1) contentY = originY - topMargin
        _lastOrigin = originY
    }

    leftMargin: 22
    rightMargin: 12                    // + the 10 px gap after each card = 22
    topMargin: 20
    bottomMargin: 28
    model: Math.ceil(ids.length / cols)
    clip: true
    pixelAligned: true
    boundsBehavior: Flickable.StopAtBounds
    flickDeceleration: 3000
    maximumFlickVelocity: 5000
    reuseItems: true
    cacheBuffer: Math.max(0, height)
    currentIndex: -1
    highlightFollowsCurrentItem: false
    keyNavigationEnabled: false

    delegate: Item {
        id: row
        required property int index
        width: list.contentW
        height: 84
        Repeater {
            model: list.cols
            StoreCard {
                required property int index
                readonly property int at: row.index * list.cols + index
                visible: at < list.ids.length
                appId: visible ? list.ids[at] : ""
                view: list.view
                x: index * list.cellW
                width: list.cellW - 10
                height: 74
            }
        }
        Component.onCompleted: list.created++
    }

    OverlayScrollBar { flick: list }
}
