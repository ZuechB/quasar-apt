import QtQuick
import Qt.labs.folderlistmodel
import Quickshell
import Quasar

// One folder's items, watched live by Qt's FolderListModel, as FileKit rows (any order: sorting and
// the search are the view's). A FolderListModel made with an empty or missing folder lists the
// working directory instead, so rows only count while the model really shows `path`.
Scope {
    id: root
    property string path: ""
    property bool showHidden: false
    property var rows: []
    readonly property bool listing: {
        if (!path) return false
        try { return decodeURIComponent(String(model.folder)) === decodeURIComponent(Theme.fileUrl(path)) }
        catch (e) { return false }
    }
    readonly property bool loading: !!path && listing && model.status !== FolderListModel.Ready

    onPathChanged: rows = []

    FolderListModel {
        id: model
        folder: root.path ? Theme.fileUrl(root.path) : ""
        showHidden: root.showHidden
        showDotAndDotDot: false
        showDirsFirst: false
        showOnlyReadable: false
        sortField: FolderListModel.Unsorted          // FileKit sorts (natural order, folders first)
        onCountChanged: Qt.callLater(root.rebuild)
        onStatusChanged: Qt.callLater(root.rebuild)
        onFolderChanged: Qt.callLater(root.rebuild)
    }
    Connections {
        target: model
        function onDataChanged() { Qt.callLater(root.rebuild) }
        function onModelReset() { Qt.callLater(root.rebuild) }
        function onRowsMoved() { Qt.callLater(root.rebuild) }
    }

    function rebuild() {
        if (!listing) { if (rows.length) rows = []; return }
        const n = model.count
        const out = new Array(n)
        for (let i = 0; i < n; i++) {
            const dir = model.get(i, "fileIsDir")
            const m = model.get(i, "fileModified")
            out[i] = FileKit.row(model.get(i, "fileName"), model.get(i, "filePath"), dir,
                                 dir ? 0 : model.get(i, "fileSize"), m ? m.getTime() : 0)
        }
        rows = out
    }
}
