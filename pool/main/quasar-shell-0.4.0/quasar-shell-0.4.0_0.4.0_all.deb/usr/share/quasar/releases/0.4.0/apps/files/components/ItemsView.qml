import QtQuick
import Quasar
import "selection.js" as Sel

// The items of one folder as tiles (grid) or rows (list), and everything the mouse and keyboard do
// to them. ONE MouseArea over the view finds the item under the pointer from geometry
// (selection.js), so delegates stay cheap with thousands of files and the ListView can never take a
// press away from a drag (a Flickable steals mouse drags from items inside it).
//   click = only it · Ctrl+click = toggle · Shift+click = range · Ctrl+Shift+click = add a range
//   press on empty space + drag = selection box (Ctrl/Shift: adds; scrolls near the edges)
//   press on an item + drag = a system drag of the whole selection: text/uri-list for every app,
//   plus application/x-quasar-files (JSON paths) so Quasar's desktop and Files know it's theirs.
// In the list a drag that starts beside a name, not on it, draws a box (as in Windows).
// Drops land on the folder under the pointer, else in this folder: dropRequested(dest, drop).
// The model is a ListModel of empty slots that only grows or shrinks at its end, and each delegate
// reads rows[index]: an integer model would reset the view (back to the top) whenever a file
// appears or goes, e.g. during a copy.
FocusScope {
    id: root
    property var rows: []                  // FileKit.row()s, in display order
    property var paths: []                 // their paths
    property string mode: "grid"           // grid | list
    property string kind: "folder"         // folder | trash (a list, nothing dragged out) | search (a list of results)
    readonly property bool trash: kind === "trash"
    property bool thumbs: true
    property var thumbCache: null          // services/Thumbs.qml
    property bool clock24: false
    property bool windowActive: true
    property string sortKey: "name"
    property bool sortReversed: false
    property var selection: Sel.empty()
    property string renamingPath: ""
    property bool renameError: false

    signal activated(int index)
    signal contextRequested(int index, real x, real y)      // index -1: empty space; x/y in this item
    signal dropRequested(string dest, var drop)             // dest "": this folder; DragEvent valid during the call
    signal command(string name)                             // open properties trash delete rename copy cut paste up back forward menu
    signal renameAccepted(string path, string text)
    signal renameCancelled()
    signal sortRequested(string key)

    readonly property bool grid: mode === "grid" && kind === "folder"
    property bool showFocused: false       // previews: draw the selection as if the view had the keyboard
    readonly property bool lit: windowActive && (activeFocus || showFocused)

    // ---- geometry (template: grid auto-fill minmax(104px, 1fr), gap 6, padding 14) -----------------
    readonly property real padX: 14
    readonly property real gap: 6
    readonly property int cols: grid ? Math.max(1, Math.floor((width - 2 * padX + gap) / (104 + gap))) : 1
    readonly property real cellW: grid ? (width - 2 * padX + gap) / cols : width
    readonly property real tileW: cellW - gap
    readonly property real tileH: 114
    readonly property real rowH: grid ? tileH + gap : 34
    readonly property var geo: ({ cols: cols, cellW: cellW, rowH: rowH, padX: padX - gap / 2, tileW: tileW, tileH: tileH })
    readonly property real headerH: grid ? 0 : 30
    readonly property real sizeW: kind === "folder" ? 96 : 0
    readonly property real dateW: 168
    readonly property real originW: kind !== "folder" ? Math.max(120, Math.floor((width - 46 - dateW) * 0.42)) : 0
    readonly property int pageRows: Math.max(1, Math.floor(list.height / rowH))

    function indexAt(p) {
        if (grid) return Sel.gridAt(geo, p.x, p.y, rows.length)
        return p.x >= 6 && p.x < width - 6 ? Sel.listAt(rowH, p.y, rows.length) : -1
    }
    // An item's box in content coordinates.
    function rectOf(i) {
        if (grid) return Sel.gridRect(geo, i)
        return { x: 6, y: i * rowH, width: width - 12, height: rowH }
    }
    // In the list only the glyph and the name pick an item up; beside them is room for a box.
    TextMetrics { id: metrics; font.family: Theme.fontUi; font.pixelSize: 13 }
    function onName(i, p) {
        if (grid) return true
        metrics.text = rows[i].name
        const col = width - 46 - sizeW - dateW - originW - 16
        return p.x <= 46 + Math.min(col, metrics.advanceWidth) + 8
    }
    function reveal(path) {
        const i = paths.indexOf(path)
        if (i < 0) return
        list.positionViewAtIndex(grid ? Math.floor(i / cols) : i, ListView.Contain)
    }
    function toTop() { list.positionViewAtBeginning(); list.contentY = list.originY - list.topMargin }

    // ---- slots: the model only changes at its end -----------------------------------------------
    ListModel { id: slots }
    readonly property int slotCount: grid ? Math.ceil(rows.length / cols) : rows.length
    onSlotCountChanged: Qt.callLater(syncSlots)
    function syncSlots() {
        const n = slotCount
        if (n > slots.count) {
            const add = []
            for (let i = slots.count; i < n; i++) add.push({ s: 0 })
            slots.append(add)
        } else if (n < slots.count) {
            slots.remove(n, slots.count - n)
        }
    }
    Component.onCompleted: syncSlots()

    // ---- the list header (list mode) ---------------------------------------------------------------
    Item {
        id: header
        visible: !root.grid
        width: parent.width
        height: root.headerH
        Rectangle { anchors.bottom: parent.bottom; width: parent.width; height: 1; color: Theme.white(0.05) }
        component HeaderCell: Item {
            id: cell
            property string label: ""
            property string key: ""
            property bool alignRight: false
            readonly property bool active: key !== "" && root.sortKey === key
            height: parent.height
            Row {
                anchors { verticalCenter: parent.verticalCenter; right: cell.alignRight ? parent.right : undefined; left: cell.alignRight ? undefined : parent.left }
                spacing: 4
                Text {
                    text: cell.label
                    font.family: Theme.fontUi; font.pixelSize: 11; font.weight: Font.DemiBold
                    font.letterSpacing: 0.4
                    color: cell.active ? Theme.text3 : Theme.textFaint
                }
                QIcon {
                    visible: cell.active
                    anchors.verticalCenter: parent.verticalCenter
                    path: root.sortReversed ? Icons.up : Icons.down
                    size: 11; strokeWidth: 2.2; color: Theme.textDim
                }
            }
            MouseArea {
                anchors.fill: parent
                enabled: cell.key !== ""
                cursorShape: enabled ? Qt.PointingHandCursor : Qt.ArrowCursor
                onClicked: root.sortRequested(cell.key)
            }
        }
        HeaderCell {
            x: 46; width: parent.width - 46 - root.sizeW - root.dateW - root.originW - 16
            label: "Name"; key: "name"
        }
        HeaderCell {
            visible: root.kind !== "folder"
            x: parent.width - root.dateW - root.originW - 16; width: root.originW
            label: root.trash ? "From" : "Folder"
        }
        HeaderCell {
            visible: root.kind === "folder"
            x: parent.width - root.dateW - root.sizeW - 16; width: root.sizeW - 8
            label: "Size"; key: "size"; alignRight: true
        }
        HeaderCell {
            x: parent.width - root.dateW - 8; width: root.dateW - 10
            label: root.trash ? "Deleted" : "Modified"; key: "modified"; alignRight: true
        }
    }

    // ---- the items ---------------------------------------------------------------------------------
    ListView {
        id: list
        anchors { fill: parent; topMargin: root.headerH }
        topMargin: root.grid ? 14 : 4
        bottomMargin: 24
        model: slots
        clip: true
        pixelAligned: true
        boundsBehavior: Flickable.StopAtBounds
        flickDeceleration: 3000
        maximumFlickVelocity: 5000
        reuseItems: true
        cacheBuffer: Math.max(0, height)
        currentIndex: -1
        highlightFollowsCurrentItem: false
        keyNavigationEnabled: false
        delegate: root.grid ? gridRow : listRow
    }
    Component {
        id: gridRow
        Item {
            id: rowItem
            required property int index
            width: list.width
            height: root.rowH
            Repeater {
                model: root.cols
                FileTile {
                    required property int index
                    readonly property int at: rowItem.index * root.cols + index
                    readonly property string path: item ? item.path : ""
                    visible: item !== null
                    item: at < root.rows.length ? root.rows[at] : null
                    x: root.padX + index * root.cellW
                    width: root.tileW; height: root.tileH
                    thumbs: root.thumbs
                    cache: root.thumbCache
                    focusedView: root.lit
                    selected: root.selection.sel[path] === true
                    cursor: root.lit && root.selection.focus === path && !selected
                    hovered: root.hoverIndex === at && !press.active
                    pressed: press.index === at && press.down && !press.moved
                    dropTarget: root.dropIndex === at
                    dimmed: root.dragging[path] === true
                    renaming: root.renamingPath === path && path !== ""
                }
            }
        }
    }
    Component {
        id: listRow
        FileRow {
            required property int index
            readonly property string path: item ? item.path : ""
            width: list.width
            height: root.rowH
            item: index < root.rows.length ? root.rows[index] : null
            kind: root.kind
            clock24: root.clock24
            sizeW: root.sizeW; dateW: root.dateW; originW: root.originW
            focusedView: root.lit
            selected: root.selection.sel[path] === true
            cursor: root.lit && root.selection.focus === path && !selected
            hovered: root.hoverIndex === index
            dropTarget: root.dropIndex === index
            dimmed: root.dragging[path] === true
            renaming: root.renamingPath === path && path !== ""
        }
    }

    // The selection box, in content coordinates so it scrolls with the items.
    Rectangle {
        parent: list.contentItem
        z: 10
        visible: root.band !== null
        x: root.band ? root.band.x : 0
        y: root.band ? root.band.y : 0
        width: root.band ? root.band.width : 0
        height: root.band ? root.band.height : 0
        radius: 4
        color: Theme.alpha(Theme.accent, 0.12)
        border.width: 1
        border.color: Theme.alpha(Theme.accent, 0.6)
    }

    // Inline rename over the item's name (Enter keeps it, Esc cancels, a click elsewhere keeps it).
    RenameField {
        id: renameBox
        parent: list.contentItem
        z: 20
        readonly property int at: root.renamingPath ? root.paths.indexOf(root.renamingPath) : -1
        readonly property var r: at >= 0 ? root.rectOf(at) : null
        visible: r !== null
        error: root.renameError
        horizontalAlignment: root.grid ? TextInput.AlignHCenter : TextInput.AlignLeft
        fontSize: root.grid ? 12 : 13
        x: !r ? 0 : root.grid ? r.x - 8 : 40
        y: !r ? 0 : root.grid ? r.y + 70 : r.y + (root.rowH - height) / 2
        width: !r ? 0 : root.grid ? r.width + 16 : Math.max(160, root.width - 46 - root.sizeW - root.dateW - root.originW - 10)
        onAccepted: (t) => root.renameAccepted(root.renamingPath, t)
        onCancelled: root.renameCancelled()
    }
    function beginRename(path) {
        const i = paths.indexOf(path)
        if (i < 0) return
        renameError = false
        renamingPath = path
        reveal(path)
        Qt.callLater(() => { if (root.renamingPath === path) renameBox.begin(root.rows[i].name, root.rows[i].isDir) })
    }
    function focusRename() { renameBox.focusInput() }
    onRenamingPathChanged: if (renamingPath === "") renameBox.release()
    function commitRename() { if (renamingPath && renameBox.visible) renameAccepted(renamingPath, renameBox.text) }

    // ---- pointer -----------------------------------------------------------------------------------
    property int hoverIndex: -1
    property int dropIndex: -1
    property var dragging: ({})            // paths being dragged out (dimmed)
    property bool dragOver: false
    property point lastPos: Qt.point(0, 0) // pointer in the items area (press or drag over)
    property var band: null                // the selection box { x, y, width, height } (content coordinates)

    QtObject {
        id: press
        property bool down: false
        property int index: -1
        property point at: Qt.point(0, 0)      // content coordinates
        property point view: Qt.point(0, 0)    // where it was pressed, in the items area
        property int mods: 0
        property bool onItem: false
        property bool moved: false
        property var base: null                // the selection the box adds to
        readonly property bool active: down && moved
    }

    function toContent(x, y) { return area.mapToItem(list.contentItem, x, y) }
    function updateBand() {
        const cur = toContent(lastPos.x, lastPos.y)
        const ch = Math.max(list.contentHeight, list.height)
        const c = Qt.point(Math.max(0, Math.min(width, cur.x)), Math.max(-list.topMargin, Math.min(ch, cur.y)))
        root.band = Sel.box(press.at, c)
        const hits = grid ? Sel.gridHits(geo, root.band, rows.length) : Sel.listHits(rowH, root.band, rows.length)
        selection = Sel.band(press.base, paths, hits, press.mods)
    }

    // The drag image: the pressed item's glyph and name, and how many are going.
    Item {
        id: ghost
        x: -4000
        width: 120; height: 104
        property var item: null
        property int count: 1
        Rectangle {
            x: 34; y: 6; width: 52; height: 52; radius: 14
            color: Theme.alpha(Theme.accent, 0.16)
            border.width: 1; border.color: Theme.alpha(Theme.accent, 0.4)
            QIcon {
                anchors.centerIn: parent
                // No software-render layer here: grabToImage of an off-window item leaves a layer blank,
                // and the drag image never scrolls (the reason QIcon has one).
                layer.enabled: false
                path: ghost.item ? Icons.get(ghost.item.glyph) : ""
                size: 30; strokeWidth: 1.6
                color: ghost.item && ghost.item.hue ? ghost.item.hue : Theme.text3
                fill: ghost.item && ghost.item.fill ? ghost.item.fill : "transparent"
            }
        }
        Rectangle {
            visible: ghost.count > 1
            x: 74; y: 0
            height: 20; radius: 10
            width: Math.max(20, countText.implicitWidth + 12)
            color: Theme.accent
            Text {
                id: countText
                anchors.centerIn: parent
                text: ghost.count
                font.family: Theme.fontUi; font.pixelSize: 11; font.weight: Font.DemiBold
                color: Theme.accentInk
            }
        }
        Rectangle {
            x: (parent.width - width) / 2; y: 66
            width: Math.min(116, nameText.implicitWidth + 14); height: 22; radius: 7
            color: Theme.solid
            Text {
                id: nameText
                anchors.centerIn: parent
                width: Math.min(implicitWidth, 104)
                elide: Text.ElideMiddle
                text: ghost.item ? (ghost.count > 1 ? ghost.count + " items" : ghost.item.name) : ""
                textFormat: Text.PlainText
                font.family: Theme.fontUi; font.pixelSize: 11
                color: Theme.text
            }
        }
    }
    function prepareGhost(i) {
        ghost.item = rows[i]
        ghost.count = Sel.has(selection, paths[i]) ? Math.max(1, Sel.count(selection)) : 1
        ghost.grabToImage((r) => { proxy.Drag.imageSource = r.url })
    }

    // The system drag. Started by hand once (never bound: a bound Drag.active loops and can cancel
    // the drag), then the press is reset, because the release that ends a drop may never arrive.
    Item {
        id: proxy
        Drag.dragType: Drag.Automatic
        Drag.supportedActions: Qt.CopyAction | Qt.MoveAction | Qt.LinkAction
        Drag.proposedAction: Qt.MoveAction
        Drag.hotSpot.x: 60
        Drag.hotSpot.y: 32
        Drag.onDragFinished: (action) => {
            root.dragging = ({})
            root.dropIndex = -1
            area.reset()
        }
    }
    function startDrag() {
        const i = press.index
        const p = paths[i]
        if (!Sel.has(selection, p))
            selection = (press.mods & Qt.ControlModifier) ? Sel.click(selection, paths, i, Qt.ControlModifier) : Sel.only(p)
        const out = Sel.list(selection, paths)
        if (!out.length) return
        const map = {}
        out.forEach(x => map[x] = true)
        dragging = map
        proxy.Drag.mimeData = { "text/uri-list": FileKit.uriList(out), "application/x-quasar-files": JSON.stringify(out) }
        proxy.Drag.active = true
    }

    MouseArea {
        id: area
        anchors { fill: list }
        acceptedButtons: Qt.LeftButton | Qt.RightButton | Qt.BackButton | Qt.ForwardButton
        hoverEnabled: true
        preventStealing: true
        function reset() {
            press.down = false; press.moved = false; root.band = null; press.index = -1
            area.enabled = false; area.enabled = true
        }
        onExited: root.hoverIndex = -1
        onPressed: (e) => {
            const p = root.toContent(e.x, e.y)
            // The rename field lies under this area: a press inside it goes to the text.
            if (root.renamingPath && renameBox.visible && renameBox.contains(renameBox.mapFromItem(list.contentItem, p.x, p.y))) {
                e.accepted = false
                return
            }
            root.forceActiveFocus()
            if (e.button === Qt.BackButton || e.button === Qt.ForwardButton) {   // a mouse's side buttons
                root.command(e.button === Qt.BackButton ? "back" : "forward")
                return
            }
            if (root.renamingPath) root.commitRename()
            const i = root.indexAt(p)
            if (e.button === Qt.RightButton) {
                if (i >= 0 && !Sel.has(root.selection, root.paths[i])) root.selection = Sel.only(root.paths[i])
                else if (i < 0) root.selection = Sel.empty()
                const q = area.mapToItem(root, e.x, e.y)
                root.contextRequested(i, q.x, q.y)
                return
            }
            press.down = true
            press.index = i
            press.at = p
            press.view = Qt.point(e.x, e.y)
            press.mods = e.modifiers
            press.moved = false
            root.band = null
            press.onItem = i >= 0 && root.onName(i, p)
            const plain = !(e.modifiers & (Qt.ControlModifier | Qt.ShiftModifier))
            // A plain press selects at once (unless the item is already selected: it may be dragged
            // with the others); Ctrl / Shift apply on release, so Ctrl+drag can carry the selection.
            if (i >= 0 && plain && press.onItem && !Sel.has(root.selection, root.paths[i])) root.selection = Sel.only(root.paths[i])
            if (press.onItem && !root.trash) root.prepareGhost(i)
            root.lastPos = press.view
        }
        onPositionChanged: (e) => {
            root.lastPos = Qt.point(e.x, e.y)
            if (!press.down) {
                const i = root.indexAt(root.toContent(e.x, e.y))
                root.hoverIndex = i
                return
            }
            if (!press.moved) {
                const d = Application.styleHints.startDragDistance
                if (Math.abs(e.x - press.view.x) <= d && Math.abs(e.y - press.view.y) <= d) return
                press.moved = true
                root.hoverIndex = -1
                if (press.onItem && !root.trash && press.index >= 0) { root.startDrag(); return }
                press.base = (press.mods & (Qt.ControlModifier | Qt.ShiftModifier)) ? root.selection : Sel.empty()
            }
            if (press.base !== null && press.moved) root.updateBand()
        }
        onReleased: (e) => {
            if (!press.down) return
            const i = press.index
            if (!press.moved) {
                if (i >= 0) root.selection = Sel.click(root.selection, root.paths, i, press.mods)
                else if (!(press.mods & (Qt.ControlModifier | Qt.ShiftModifier))) root.selection = Sel.empty()
            }
            press.down = false
            press.moved = false
            root.band = null
            press.base = null
        }
        onCanceled: { press.down = false; press.moved = false; root.band = null; press.base = null }
        onDoubleClicked: (e) => {
            if (e.button !== Qt.LeftButton) return
            const i = root.indexAt(root.toContent(e.x, e.y))
            if (i >= 0) root.activated(i)
        }
    }

    // Scroll while a box or a drag is held near the top or bottom edge.
    Timer {
        interval: 16
        repeat: true
        running: ((root.band !== null && press.down && press.base !== null) || root.dragOver)
                 && (root.lastPos.y < 28 || root.lastPos.y > list.height - 28)
        onTriggered: {
            const edge = root.lastPos.y < 28 ? -(28 - root.lastPos.y) : root.lastPos.y - (list.height - 28)
            const step = Math.max(-22, Math.min(22, edge * 0.8))
            const top = list.originY - list.topMargin
            const bottom = Math.max(top, list.originY + list.contentHeight + list.bottomMargin - list.height)
            list.contentY = Math.max(top, Math.min(bottom, list.contentY + step))
            if (root.band !== null && press.base !== null) root.updateBand()
        }
    }

    // ---- drops -----------------------------------------------------------------------------------
    function updateDrop(d) {
        lastPos = Qt.point(d.x, d.y)
        const i = indexAt(toContent(d.x, d.y))
        dropIndex = i >= 0 && !trash && rows[i].isDir && dragging[rows[i].path] !== true ? i : -1
    }
    DropArea {
        anchors.fill: list
        onEntered: (d) => { root.dragOver = true; root.updateDrop(d) }
        onPositionChanged: (d) => root.updateDrop(d)
        onExited: { root.dragOver = false; root.dropIndex = -1 }
        onDropped: (d) => {
            const i = root.dropIndex
            root.dragOver = false
            root.dropIndex = -1
            root.dropRequested(i >= 0 ? root.paths[i] : "", d)
        }
    }

    OverlayScrollBar { flick: list; z: 30 }

    // ---- keys --------------------------------------------------------------------------------------
    property string typed: ""
    Timer { id: typedReset; interval: 900; onTriggered: root.typed = "" }
    readonly property var keyNames: ({ [Qt.Key_Left]: "left", [Qt.Key_Right]: "right", [Qt.Key_Up]: "up", [Qt.Key_Down]: "down",
                                       [Qt.Key_Home]: "home", [Qt.Key_End]: "end", [Qt.Key_PageUp]: "pageup", [Qt.Key_PageDown]: "pagedown" })
    Keys.onPressed: (e) => {
        if (root.renamingPath) return
        const ctrl = (e.modifiers & Qt.ControlModifier) !== 0
        const alt = (e.modifiers & Qt.AltModifier) !== 0
        const k = keyNames[e.key]
        if (k && !alt) {
            const s = Sel.key(root.selection, root.paths, k, e.modifiers, root.cols, root.pageRows)
            if (s) { root.selection = s; root.reveal(s.focus) }
            e.accepted = true
            return
        }
        if (ctrl && e.key === Qt.Key_A) { root.selection = Sel.all(root.selection, root.paths); e.accepted = true; return }
        if (ctrl && e.key === Qt.Key_Space) { root.selection = Sel.toggleFocus(root.selection); e.accepted = true; return }
        if (e.key === Qt.Key_Escape && Sel.count(root.selection) > 0) { root.selection = Sel.empty(); e.accepted = true; return }
        const cmd = (e.key === Qt.Key_Return || e.key === Qt.Key_Enter) ? (alt ? "properties" : "open")
                  : e.key === Qt.Key_Delete ? ((e.modifiers & Qt.ShiftModifier) ? "delete" : "trash")
                  : e.key === Qt.Key_F2 ? "rename"
                  : ctrl && e.key === Qt.Key_C ? "copy"
                  : ctrl && e.key === Qt.Key_X ? "cut"
                  : ctrl && e.key === Qt.Key_V ? "paste"
                  : e.key === Qt.Key_Backspace && !ctrl ? "up"
                  : e.key === Qt.Key_Menu || (e.key === Qt.Key_F10 && (e.modifiers & Qt.ShiftModifier)) ? "menu" : ""
        if (cmd) { root.command(cmd); e.accepted = true; return }
        // Type to jump to a name.
        if (!ctrl && !alt && e.text.length === 1 && e.text > " ") {
            root.typed += e.text
            typedReset.restart()
            const i = Sel.typeAhead(root.typed, root.rows.map(r => r.name), root.paths.indexOf(root.selection.focus))
            if (i >= 0) { root.selection = Sel.only(root.paths[i]); root.reveal(root.paths[i]) }
            e.accepted = true
        }
    }
    // Where a keyboard menu (Menu key) opens: below the cursor item, in this item's coordinates.
    function focusPoint() {
        const i = paths.indexOf(selection.focus)
        if (i < 0) return Qt.point(40, headerH + 20)
        const r = rectOf(i)
        return list.contentItem.mapToItem(root, r.x + Math.min(40, r.width / 2), r.y + r.height / 2)
    }
}
