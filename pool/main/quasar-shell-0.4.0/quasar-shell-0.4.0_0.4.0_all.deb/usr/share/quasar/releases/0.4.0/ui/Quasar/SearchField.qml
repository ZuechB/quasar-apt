import QtQuick

// Template search field (Store / Settings sidebars): 36px, radius 10, white .05 fill, white .08
// hairline (accent when focused), 15px search glyph, 13px text, #7D8598 placeholder.
// Esc clears the text first, then emits escapePressed.
Rectangle {
    id: root
    property alias text: input.text
    property string placeholder: "Search"
    property string glyph: Icons.search
    signal edited(string text)
    signal accepted()
    signal escapePressed()
    function focusInput() { input.forceActiveFocus() }
    function clear() { input.text = ""; root.edited("") }

    implicitHeight: 36
    implicitWidth: 200
    radius: 10
    color: Theme.white(0.05)
    border.width: 1
    border.color: input.activeFocus ? Theme.accentLine : Theme.white(0.08)
    Behavior on border.color { ColorAnimation { duration: Motion.dur(Motion.hover) } }

    MouseArea {
        anchors.fill: parent
        cursorShape: Qt.IBeamCursor
        onPressed: input.forceActiveFocus()
    }
    QIcon {
        id: icon
        x: 10
        anchors.verticalCenter: parent.verticalCenter
        path: root.glyph; size: 15; strokeWidth: 2
        color: Theme.textDim
    }
    TextInput {
        id: input
        anchors { left: icon.right; leftMargin: 8; right: clearBtn.visible ? clearBtn.left : parent.right; rightMargin: 8; verticalCenter: parent.verticalCenter }
        font.family: Theme.fontUi; font.pixelSize: 13
        color: Theme.text
        selectionColor: Theme.alpha(Theme.accent, 0.35)
        selectedTextColor: Theme.text
        selectByMouse: true
        clip: true
        Accessible.role: Accessible.EditableText
        Accessible.name: root.placeholder
        onTextEdited: root.edited(text)
        onAccepted: root.accepted()
        Keys.onEscapePressed: { if (text !== "") root.clear(); else root.escapePressed() }
        Text {
            anchors.fill: parent
            verticalAlignment: Text.AlignVCenter
            visible: input.text === "" && input.preeditText === ""
            text: root.placeholder
            elide: Text.ElideRight
            font: input.font
            color: Theme.textFaint
        }
    }
    Pressable {
        id: clearBtn
        visible: input.text !== ""
        anchors { right: parent.right; rightMargin: 4; verticalCenter: parent.verticalCenter }
        width: 26; height: 26; radius: 8; kind: "hov"
        accessibleName: "Clear search"
        onClicked: { root.clear(); input.forceActiveFocus() }
        QIcon { anchors.centerIn: parent; path: Icons.x; size: 12; strokeWidth: 2.2; color: Theme.textDim }
    }
}
