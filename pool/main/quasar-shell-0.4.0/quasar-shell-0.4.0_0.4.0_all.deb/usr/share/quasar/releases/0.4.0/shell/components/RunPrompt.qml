import QtQuick
import Quasar

// "Run “install.sh”?" — asked before a double-clicked program runs (services/Programs.qml). Dims the
// screen, centred card, AuthDialog's style. Pointer only, like PairDialog: Enter and Space never run
// anything, and the run buttons only answer 700 ms after the card appears, so the second press of a
// double-click (or a click meant for something else) can't land on Run.
// The name is shown as inspected (invisible direction marks removed by the helper) and shortened in
// the middle, so its real extension always shows. What it is comes from the file itself, not its name.
// Pure view: `info` is `program inspect`'s JSON; the host handles the choices.
//   actions: run | apps (Add to Apps) | edit | store (find the interpreter) | runtime (get .NET N) |
//            bottles (Windows programs)
Item {
    id: root
    property var info: null
    property bool textEditor: true
    property bool bottlesInstalled: false
    property string runsIn: ""                 // "Personal" or a company's name, when worth saying
    property bool busy: false                  // getting a runtime
    property real progress: -1                 // 0..1 while getting it
    property string status: ""
    signal chosen(string action)
    signal cancelled()

    readonly property var i: info || ({})
    readonly property var d: i.detail || ({})
    readonly property var acts: i.actions || []
    readonly property bool runnable: !!i.canRun
    property int armDelay: 700                 // previews show the armed card with 0
    property bool armed: false
    onInfoChanged: { armed = armDelay <= 0; if (armDelay > 0) armTimer.restart() }
    Timer { id: armTimer; interval: Math.max(1, root.armDelay); onTriggered: root.armed = true }

    function has(a) { return acts.indexOf(a) >= 0 }
    function shortName(n) {
        n = n || ""
        return n.length <= 46 ? n : n.slice(0, 28) + "…" + n.slice(-16)
    }
    function archName(a) { return a === "x86_64" ? "Intel and AMD" : a === "aarch64" || a === "arm" ? "ARM" : a === "i386" ? "32-bit" : a }
    readonly property string q: "“" + shortName(i.name) + "”"
    readonly property string net: (d.aspnet ? "ASP.NET Core " : ".NET ") + (d.major || "")

    readonly property string title: {
        switch (i.reason || "") {
        case "": case "copy-first": return "Run " + q + "?"
        case "runtime-missing": return q + " needs " + net
        case "windows-program":
            return d.what === "msi" ? q + " is a Windows installer"
                 : d.what === "bat" || d.what === "cmd" ? q + " is a Windows batch file" : q + " is a Windows program"
        case "windows-only-dotnet": case "cpp-cli": case "x86-only": return q + " only works on Windows"
        case "netfx": return q + " is made for .NET Framework"
        case "missing-interpreter": return q + " needs " + d.missing
        case "wrong-arch": return q + " is for a different kind of PC"
        case "broken": return q + " looks damaged"
        default: return q + " isn't a program Quasar can run"
        }
    }
    readonly property string subtitle: [i.type, i.size !== undefined ? FileKit.formatSize(i.size) : "",
                                        i.origin ? "from " + i.origin : ""].filter(s => !!s).join(" · ")
    readonly property var lines: {
        const out = []
        const bottles = bottlesInstalled ? "Bottles can try to run it." : "Bottles, from the Store, runs many of them."
        switch (i.reason || "") {
        case "": case "copy-first":
            // A company's own files run inside that company: no warning needed for whose they are.
            if (i.owner === "other" && !i.company) out.push("It belongs to another account, or sits in a folder other accounts can change.")
            if (i.reason === "copy-first") out.push("It can't run from this drive. Add to Apps copies it to this PC first.")
            else if (has("apps")) out.push("Add to Apps moves it to your Applications folder and puts it in the launcher.")
            if (d.crlf) out.push("It was saved on Windows (Windows line endings), so it may not run.")
            if (d.rollForward) out.push("Made for .NET " + d.major + ". It runs on .NET " + String(d.runtime || "").split(".")[0] + ", which most apps are fine with.")
            if (i.terminal) out.push("It runs in a Terminal tab.")
            out.push("Programs can see and change anything your account can. Run it only if you trust where it came from.")
            break
        case "runtime-missing":
            out.push(has("runtime") ? net + " isn't on this PC yet. Quasar can get it from Microsoft (about " + (d.aspnet ? 50 : 40) + " MB)."
                                    : net + " isn't available for this version of Quasar yet.")
            break
        case "windows-program": out.push("Quasar runs apps made with .NET, but not other Windows programs. " + bottles); break
        case "windows-only-dotnet": out.push("It's built with Windows Forms or WPF, which only exist on Windows. " + bottles); break
        case "netfx": out.push(".NET Framework only exists on Windows. Quasar runs apps made with .NET 10 and later. " + bottles); break
        case "cpp-cli": out.push("Part of it is Windows machine code. " + bottles); break
        case "x86-only": out.push("It only runs as 32-bit Windows code. " + bottles); break
        case "missing-interpreter": out.push(d.missing + " isn't installed on this PC. The Store may have it."); break
        case "wrong-arch": out.push("It's made for " + archName(d.arch) + " PCs."); break
        case "broken": out.push("Quasar couldn't read it" + (d.why ? " (" + d.why + ")" : "") + "."); break
        default: out.push("Its name says it's a program, but it isn't one.")
        }
        return out
    }
    readonly property string glyph: i.kind === "script" ? Icons.code : runnable ? Icons.cube
                                  : i.reason === "runtime-missing" ? Icons.download : Icons.alert
    readonly property color hue: runnable ? (i.kind === "script" ? "#B9A4FF" : "#7AE7FF")
                               : i.reason === "runtime-missing" ? Theme.accent : Theme.amber

    Rectangle {
        anchors.fill: parent
        color: Qt.rgba(0, 0, 0, 0.5)
        MouseArea { anchors.fill: parent }         // modal: clicks outside do nothing
    }

    Rectangle {
        id: card
        anchors.centerIn: parent
        width: Math.min(460, parent.width - 40)
        height: col.implicitHeight + 48
        radius: 22
        color: Theme.solid
        border.width: 1
        border.color: Theme.white(0.11)
        Accessible.role: Accessible.Dialog
        Accessible.name: root.title

        Column {
            id: col
            x: 24; y: 24
            width: parent.width - 48
            spacing: 14

            Row {
                width: parent.width
                spacing: 14
                Rectangle {
                    width: 46; height: 46; radius: 14
                    color: Theme.alpha(root.hue, 0.14)
                    QIcon { anchors.centerIn: parent; path: root.glyph; size: 22; strokeWidth: 1.9; color: root.hue }
                }
                Column {
                    width: parent.width - 60
                    spacing: 4
                    Text {
                        width: parent.width
                        wrapMode: Text.Wrap
                        textFormat: Text.PlainText
                        text: root.title
                        font.family: Theme.fontUi; font.pointSize: Theme.pt(15); font.weight: Font.DemiBold
                        color: Theme.text
                    }
                    Text {
                        width: parent.width
                        visible: text !== ""
                        wrapMode: Text.Wrap
                        textFormat: Text.PlainText
                        text: root.subtitle
                        font.family: Theme.fontUi; font.pointSize: Theme.pt(12)
                        color: Theme.text3
                    }
                }
            }

            Repeater {
                model: root.lines
                Text {
                    required property string modelData
                    width: col.width
                    wrapMode: Text.Wrap
                    textFormat: Text.PlainText
                    text: modelData
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5)
                    color: Theme.text2
                }
            }

            Text {
                width: parent.width
                visible: root.runnable && root.runsIn !== ""
                textFormat: Text.PlainText
                text: "Runs in " + root.runsIn
                font.family: Theme.fontUi; font.pointSize: Theme.pt(11.5)
                color: Theme.textDim
            }

            // Getting a runtime: progress where the buttons were.
            Column {
                width: parent.width
                spacing: 6
                visible: root.busy
                Rectangle {
                    width: parent.width; height: 4; radius: 2
                    color: Theme.white(0.1)
                    Rectangle {
                        height: parent.height; radius: 2
                        width: root.progress >= 0 ? parent.width * Math.max(0.03, Math.min(1, root.progress)) : parent.width * 0.3
                        color: Theme.accent
                        Behavior on width { enabled: !Theme.reduceMotion; NumberAnimation { duration: 200 } }
                    }
                }
                Text {
                    width: parent.width
                    textFormat: Text.PlainText
                    text: root.status
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(11.5)
                    color: Theme.text3
                }
            }

            Row {
                anchors.right: parent.right
                spacing: 8
                Button {
                    visible: root.has("edit") && root.textEditor
                    text: "Open in Text Editor"; variant: "outline"; size: 34
                    onClicked: root.chosen("edit")
                }
                Button {
                    text: root.runnable || root.has("runtime") || root.has("store") ? "Cancel" : "Close"
                    variant: "outline"; size: 34
                    onClicked: root.cancelled()
                }
                Button {
                    visible: root.runnable && root.has("apps") && root.has("run")
                    text: "Run once"; variant: "soft"; size: 34
                    enabled: root.armed
                    onClicked: root.chosen("run")
                }
                Button {
                    visible: root.runnable && root.has("apps")
                    text: "Add to Apps"; variant: "primary"; size: 34
                    enabled: root.armed
                    onClicked: root.chosen("apps")
                }
                Button {
                    visible: root.runnable && root.has("run") && !root.has("apps")
                    text: "Run"; variant: "primary"; size: 34
                    enabled: root.armed
                    onClicked: root.chosen("run")
                }
                Button {
                    visible: root.has("runtime")
                    text: "Get " + root.net; variant: "primary"; size: 34
                    busy: root.busy
                    enabled: root.armed && !root.busy
                    onClicked: root.chosen("runtime")
                }
                Button {
                    visible: root.has("store")
                    text: "Find in Store"; variant: "primary"; size: 34
                    onClicked: root.chosen("store")
                }
                Button {
                    visible: root.has("bottles")
                    text: root.bottlesInstalled ? "Open with Bottles" : "Get Bottles"; variant: "primary"; size: 34
                    enabled: root.armed
                    onClicked: root.chosen("bottles")
                }
            }
        }
    }
}
