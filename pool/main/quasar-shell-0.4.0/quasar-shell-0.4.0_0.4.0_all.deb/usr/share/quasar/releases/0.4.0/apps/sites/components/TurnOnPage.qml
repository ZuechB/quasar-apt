import QtQuick
import Quasar

// Shown while Sites is off: what turning it on does, then the steps while it happens. Turning it on
// asks for the administrator password (quasar-sites-admin activate).
Item {
    id: root
    property bool liveUsb: false
    property bool caddyInstalled: true
    property bool working: false
    property var steps: ["Create Quasar’s certificate authority", "Trust it on this PC", "Start the web server"]
    property int current: -1
    property bool failed: false
    property string error: ""
    property string errorDetails: ""
    signal turnOn()

    implicitHeight: col.implicitHeight

    Column {
        id: col
        width: Math.min(parent.width, 640)
        spacing: 18

        Rectangle {
            width: 64; height: 64; radius: 20
            color: "#121522"
            border.width: 1; border.color: Theme.white(0.1)
            gradient: Gradient {
                GradientStop { position: 0; color: Theme.white(0.12) }
                GradientStop { position: 0.6; color: "#121522" }
            }
            QIcon { anchors.centerIn: parent; path: Icons.web; size: 30; strokeWidth: 1.8; color: Theme.accent }
        }
        Column {
            width: parent.width
            spacing: 8
            Text {
                text: "Host websites from this PC"
                font.family: Theme.fontDisplay; font.pixelSize: 26; font.weight: Font.Medium; font.letterSpacing: -0.4
                color: Theme.text
            }
            Text {
                width: parent.width
                text: "Run your own sites with automatic HTTPS. Quasar builds them, keeps them running and gives each one an address this PC trusts. Share one with your home network or the internet when you’re ready."
                wrapMode: Text.WordWrap
                font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5); lineHeight: 1.15
                color: Theme.textMuted
            }
        }

        Rectangle {
            visible: !root.working
            width: parent.width
            height: facts.implicitHeight
            radius: 18
            color: Theme.white(0.035)
            border.width: 1; border.color: Theme.white(0.06)
            Column {
                id: facts
                width: parent.width
                Repeater {
                    model: [
                        { g: Icons.server, t: "A web server starts on this PC", s: "Caddy answers on ports 80 and 443, for this PC only until you share a site." },
                        { g: Icons.shield, t: "Quasar’s own certificate authority", s: "Made on this PC and trusted by its browsers, so https://name.localhost just works. It can only vouch for local names." },
                        { g: Icons.lock, t: "Each site in its own sandbox", s: "Sites run under their own system account and can’t read your files. Secrets are stored encrypted." },
                        { g: Icons.globe, t: "Share when you’re ready", s: "Quasar walks you through your home network, your own domain and the router." }
                    ]
                    delegate: Item {
                        required property var modelData
                        required property int index
                        width: facts.width
                        height: Math.max(58, txt.implicitHeight + 22)
                        Rectangle { visible: index > 0; anchors { left: parent.left; right: parent.right; top: parent.top } height: 1; color: Theme.white(0.05) }
                        Rectangle {
                            id: tile
                            x: 16; anchors.verticalCenter: parent.verticalCenter
                            width: 32; height: 32; radius: 10
                            color: Theme.white(0.05)
                            QIcon { anchors.centerIn: parent; path: modelData.g; size: 16; color: Theme.text3 }
                        }
                        Column {
                            id: txt
                            anchors { left: tile.right; leftMargin: 14; right: parent.right; rightMargin: 16; verticalCenter: parent.verticalCenter }
                            spacing: 2
                            Text { text: modelData.t; font.family: Theme.fontUi; font.pixelSize: 14; font.weight: Font.Medium; color: Theme.text }
                            Text { width: parent.width; text: modelData.s; wrapMode: Text.WordWrap; font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5); color: Theme.textDim }
                        }
                    }
                }
            }
        }

        StepList {
            visible: root.working || root.failed
            width: parent.width
            steps: root.steps
            current: root.current
            failed: root.failed
        }

        Banner {
            visible: root.liveUsb
            width: parent.width
            tone: "info"
            title: "Install Quasar to host websites"
            message: "The live USB forgets everything when it restarts, including your sites and their certificates. Install Quasar on this PC, then turn on Sites."
        }
        Banner {
            visible: !root.caddyInstalled && !root.liveUsb
            width: parent.width
            tone: "error"
            title: "The web server is missing"
            message: "Caddy isn’t installed on this PC, so Sites can’t start."
        }
        Banner {
            visible: root.error !== ""
            width: parent.width
            tone: "error"
            title: "Sites didn’t turn on"
            message: root.error
            details: root.errorDetails
        }

        Row {
            spacing: 12
            Button {
                size: 42
                variant: "primary"
                text: root.failed ? "Try again" : "Turn on Sites"
                busy: root.working
                enabled: !root.working && !root.liveUsb && root.caddyInstalled
                onClicked: root.turnOn()
            }
            Text {
                anchors.verticalCenter: parent.verticalCenter
                text: "Needs your password. You can turn it off any time."
                font.family: Theme.fontUi; font.pixelSize: 12
                color: Theme.textFaint
            }
        }
    }
}
