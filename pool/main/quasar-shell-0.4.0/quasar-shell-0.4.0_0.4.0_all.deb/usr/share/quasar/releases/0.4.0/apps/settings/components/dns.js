// Settings > Network & Internet > Encrypted DNS: rows built from `quasar-net dns status`
// (linux/system/net/quasar_net/qnet.py) and the live reach in /run/quasar/net-state.json. Pure.
//   st:  { available, enabled, provider, name, nextdnsId?, host?, addresses?, reach }   (null while loading)
//   ctx: { busy: "dns" while it switches, reach: NetState.dns.reach, icons, theme }
// Plain words: DNS is how the PC "looks up" websites; encrypted lookups can't be read or changed on the way.
.pragma library

var PROVIDERS = [
    { key: "quad9", label: "Quad9", sub: "Blocks known harmful sites. A Swiss non-profit." },
    { key: "cloudflare", label: "Cloudflare", sub: "Fast. Blocks nothing." },
    { key: "mullvad", label: "Mullvad", sub: "Keeps no logs. Blocks nothing." },
    { key: "nextdns", label: "NextDNS", sub: "Your own rules. Asks for your configuration ID." },
    { key: "custom", label: "Another server", sub: "A DNS-over-TLS server you choose." }
]

function providerName(st) {
    if (!st) return "Quad9"
    if (st.provider === "custom") return st.host || st.name || "your server"
    var p = PROVIDERS.find(function (x) { return x.key === st.provider })
    return p ? p.label : "Quad9"
}

function isOn(st) { return !!st && !!st.enabled }

// Reach of an "on" Encrypted DNS right now: the live value from the state file wins over status's.
function reach(st, ctx) { return ctx.reach !== undefined && ctx.reach !== null && ctx.reach !== "" ? ctx.reach : ((st && st.reach) || "") }
function struggling(st, ctx) { return isOn(st) && ["blocked", "tls", "clock", "offline"].indexOf(reach(st, ctx)) >= 0 }

function networkRow(st, ctx) {
    var t = ctx.theme
    var row = { key: "dns:open", label: "Encrypted DNS", glyph: ctx.icons.globe, trailing: "chevron", sub: "DNS over TLS", value: "" }
    if (!st) return row
    if (!st.available) { row.value = "Not available"; return row }
    if (ctx.busy === "dns") { row.value = "Checking…"; return row }
    if (isOn(st)) {
        row.sub = providerName(st) + "  ·  DNS over TLS"
        if (struggling(st, ctx)) { row.value = "Not getting through"; row.valueColor = t.amber }
        else { row.value = "On"; row.valueColor = t.mint }
    } else {
        row.value = "Off"
    }
    return row
}

function hero(st, ctx) {
    var icons = ctx.icons, t = ctx.theme
    if (!st)
        return { glyph: icons.globe, title: "Encrypted DNS", sub: "Checking…" }
    if (!st.available)
        return { glyph: icons.globe, title: "Encrypted DNS isn't available", sub: "This copy of Quasar can't encrypt lookups. Update Quasar." }
    var name = providerName(st)
    if (ctx.busy === "dns")
        return { glyph: icons.globe, title: "Checking that " + name + " answers…", toggle: true, checked: true, busy: true,
                 sub: "Your lookups switch over once it does." }
    if (struggling(st, ctx)) {
        var r = reach(st, ctx)
        return { glyph: icons.globe, title: "Lookups aren't getting through", toggle: true, checked: true, busy: false, iconFg: t.amber,
                 sub: r === "clock" ? "This PC's clock is wrong, so " + name + "'s certificate can't be checked. Set it in Date & Language."
                    : r === "offline" ? "This PC isn't online right now."
                    : "This network blocks encrypted lookups, or wants you to sign in on a web page first. Turn this off to use the network's own DNS, then on again once you're signed in." }
    }
    if (isOn(st))
        return { glyph: icons.globe, title: "Encrypted DNS is on", toggle: true, checked: true, busy: false,
                 iconBg: t.accent, iconFg: t.accentInk,
                 sub: "The websites and apps you look up go encrypted to " + name + ". The network you're on can't read or change them." }
    return { glyph: icons.globe, title: "Encrypted DNS is off", toggle: true, checked: false, busy: false,
             sub: "The network you're on can see every website and app you look up. Turn this on to send those lookups encrypted to " + name + " instead." }
}

function groups(st, ctx) {
    if (!st || !st.available) return []
    var icons = ctx.icons
    var p = PROVIDERS.find(function (x) { return x.key === st.provider }) || PROVIDERS[0]
    var out = [{ label: "Provider", rows: [
        { key: "dns:provider", label: "Looks up through", glyph: icons.server, trailing: "chevron", value: providerName(st),
          sub: st.provider === "nextdns" && st.nextdnsId ? "Configuration " + st.nextdnsId : p.sub }] },
        { label: "Good to know", rows: [
        { key: "dns:info:portal", label: "Wi-Fi with a sign-in page", glyph: icons.info, trailing: "none",
          sub: "Hotels and cafés often want you to sign in on a web page first. Turn Encrypted DNS off until you're signed in." },
        { key: "dns:info:local", label: "Names only your router knows", glyph: icons.home, trailing: "none",
          sub: "Like a printer's name ending in .lan: they may stop working. Names ending in .local keep working." },
        { key: "dns:info:vpn", label: "VPNs", glyph: icons.lock, trailing: "none",
          sub: "A VPN still answers for its own network's names." }] }]
    if (isOn(st))
        out.push({ label: "Advanced", rows: [
            { key: "dns:check", label: "Check the connection", glyph: icons.refresh, trailing: "button", value: "Check again",
              busy: ctx.busy === "dns:check", sub: "Whether " + providerName(st) + " can be reached from this network" }] })
    return out
}

// quasar-net dns reasons (reasons.py DNS) in plain words; name = the provider.
function reasonText(code, name) {
    name = name || "the server"
    var R = {
        "offline": ["This PC isn't online", "Connect to a network, then turn Encrypted DNS on."],
        "blocked": ["This network blocks encrypted DNS", "Nothing was changed. Some hotel, school and office networks block it: try again on another network."],
        "tls": ["Couldn't confirm it's really " + name, "Nothing was changed. This network may be intercepting the connection."],
        "clock": ["This PC's clock is wrong", "Encrypted DNS checks certificates, which needs the right date. Set it in Date & Language, then try again."],
        "lookup": ["Lookups didn't come back encrypted", "Encrypted DNS was left off. Try again in a moment."],
        "bad-id": ["That isn't a NextDNS configuration ID", "It's the 6 letters and digits on your NextDNS Setup page."],
        "bad-host": ["That isn't a server name", "Type the DNS-over-TLS name, like dns.example.com."],
        "no-addresses": ["Quasar couldn't find that server", "Check the name, or type its IP address too."],
        "no-resolved": ["This copy of Quasar can't encrypt lookups", "Update Quasar."],
        "not-allowed": ["Your account isn't allowed to change this", "Ask an administrator."],
        "cancelled": ["", ""],
        "other": ["That didn't work", ""]
    }
    var r = R[code] || R.other
    return { title: r[0], message: r[1] }
}
