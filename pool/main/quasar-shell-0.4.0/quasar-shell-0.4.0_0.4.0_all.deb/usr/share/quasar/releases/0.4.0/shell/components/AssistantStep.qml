import QtQuick
import Quasar

// One step of the assistant's plan (template plan row, AssistantPanel): a 26px ring (number → spinner →
// check; × failed, – skipped/denied, ! waiting for Allow), the title, a grey detail (a command is shown
// in full, in mono), the result or error, a command's live output, and the permission tag.
//   st: { state: staged|asking|running|done|failed|skipped|denied, title, detail, tag, tool, summary, lines }
Rectangle {
    id: row
    property int number: 0               // position in the card (0-based)
    property var st: ({})
    readonly property string s: st.state || ""
    readonly property bool done: s === "done"
    readonly property bool run: s === "running"
    readonly property bool bad: s === "failed"
    readonly property bool off: s === "skipped" || s === "denied"
    readonly property bool asking: s === "asking"
    readonly property bool isCommand: st.tool === "run_command"

    width: parent ? parent.width : 0
    height: Math.max(52, info.implicitHeight + 24)
    color: run ? Theme.alpha(Theme.accent, 0.07) : asking ? Theme.alpha(Theme.amber, 0.06) : "transparent"
    Behavior on color { ColorAnimation { duration: Motion.dur(300) } }
    Accessible.role: Accessible.StaticText
    Accessible.name: (st.title || "") + (done ? ", done" : run ? ", running" : bad ? ", failed" : off ? ", skipped" : asking ? ", waiting for you" : "")

    Rectangle { visible: row.number > 0; width: parent.width; height: 1; color: Theme.white(0.05) }
    Rectangle {
        x: 14; y: 13
        width: 26; height: 26; radius: 13
        border.width: 1.5
        border.color: row.bad ? Theme.danger : row.asking ? Theme.amber : (row.done || row.run) ? Theme.accent : Theme.white(0.18)
        color: row.done ? Theme.accent : row.bad ? Theme.alpha(Theme.danger, 0.15) : "transparent"
        Behavior on color { ColorAnimation { duration: Motion.dur(Motion.pop) } }
        Text {
            anchors.centerIn: parent
            visible: !row.done && !row.run && !row.bad && !row.off && !row.asking
            text: row.number + 1
            font.family: Theme.fontUi; font.pixelSize: 11; font.weight: Font.DemiBold
            color: Theme.textMuted
        }
        Spinner { anchors.centerIn: parent; visible: row.run; size: 14; color: Theme.accent }
        QIcon {
            anchors.centerIn: parent
            visible: row.done || row.bad || row.off || row.asking
            path: row.done ? Icons.check : row.bad ? Icons.x : row.asking ? Icons.alert : Icons.minus
            size: 14; strokeWidth: row.done ? 3 : 2.2
            color: row.done ? Theme.accentInk : row.bad ? Theme.danger : row.asking ? Theme.amber : Theme.textFaint
        }
    }
    Column {
        id: info
        x: 52; y: 12
        width: row.width - 52 - 14              // only the title line makes room for the tag
        spacing: 3
        Text {
            width: parent.width - (tag.visible ? tag.width + 10 : 0)
            text: row.st.title || ""
            wrapMode: Text.Wrap
            font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5); font.weight: Font.DemiBold
            font.strikeout: row.s === "denied"
            color: row.off ? Theme.textDim : (row.done || row.run || row.bad || row.asking) ? Theme.text : Theme.text3
        }
        Text {
            width: parent.width
            visible: text !== ""
            text: row.st.detail || ""
            textFormat: Text.PlainText
            wrapMode: row.isCommand ? Text.WrapAnywhere : Text.Wrap
            maximumLineCount: row.isCommand ? 8 : 3
            elide: Text.ElideRight
            font.family: row.isCommand ? Theme.fontMono : Theme.fontUi
            font.pointSize: Theme.pt(row.isCommand ? 11.5 : 12)
            color: row.isCommand ? Theme.text2 : Theme.textDim
        }
        Text {
            width: parent.width
            visible: text !== ""
            text: row.st.summary || ""
            textFormat: Text.PlainText
            wrapMode: Text.Wrap
            maximumLineCount: 3
            elide: Text.ElideRight
            font.family: Theme.fontUi; font.pointSize: Theme.pt(12)
            color: row.bad ? Theme.danger : Theme.textMuted
        }
        Rectangle {
            visible: (row.st.lines || []).length > 0
            width: parent.width
            height: out.implicitHeight + 14
            radius: 8
            color: "#06070B"
            Text {
                id: out
                x: 8; y: 7
                width: parent.width - 16
                text: (row.st.lines || []).slice(-6).join("\n")
                textFormat: Text.PlainText
                wrapMode: Text.WrapAnywhere
                lineHeight: 1.2
                font.family: Theme.fontMono; font.pointSize: Theme.pt(11)
                color: Theme.textMuted
            }
        }
    }
    Rectangle {
        id: tag
        anchors { right: parent.right; rightMargin: 14 }
        y: 12
        visible: tagText.text !== ""
        width: tagText.implicitWidth + 16; height: 22; radius: 6
        color: Theme.white(0.06)
        Text {
            id: tagText
            anchors.centerIn: parent
            text: row.st.tag || ""
            font.family: Theme.fontMono; font.pointSize: Theme.pt(10)
            color: Theme.textMuted
        }
    }
}
