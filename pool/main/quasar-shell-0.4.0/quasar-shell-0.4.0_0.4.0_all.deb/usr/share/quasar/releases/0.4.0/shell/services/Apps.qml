import QtQuick
import Quickshell
import Quickshell.Wayland
import Quasar

// Installed applications (freedesktop desktop entries) + taskbar model (pins + running toplevels).
// Apps launch into their own systemd scope (app-quasar-<id>-<n>.scope) so per-app accounting
// (network monitor, resource use) can attribute them later.
QtObject {
    id: apps
    property var pins: []
    property bool useScopes: Quickshell.env("QUASAR_NO_SCOPES") !== "1"
    // The desktop has the keyboard: labwc still reports the last window as activated, but to the
    // user it isn't focused, so its taskbar button should focus it rather than minimize it.
    property bool desktopActive: false
    // Company environments (CompanyDesk): apps launched while a company is shown run inside it, and
    // the taskbar lists only that company's windows (plus the Quasar apps that follow you).
    property var desk: null

    readonly property var entries: DesktopEntries.applications.values
    readonly property var toplevels: ToplevelManager.toplevels.values
    readonly property var shown: {
        if (!desk) return toplevels
        const dependOn = [desk.revision, desk.active]
        return toplevels.filter(t => desk.isShown(t))
    }

    // Quasar's own Terminal (apps/terminal) replaces foot wherever it's installed; foot stays as
    // the fallback engine and for windows that already use it.
    readonly property var footIds: ["foot", "footclient", "foot-server",
                                    "org.codeberg.dnkl.foot", "org.codeberg.dnkl.footclient", "org.codeberg.dnkl.foot-server"]
    readonly property bool ownTerminal: entries.length > 0 && !!byId("quasar-terminal")

    // What the launcher lists (All apps, search). foot ships three entries: the server is a session
    // service, and plain foot would be a second "Terminal" next to footclient (the pinned one) —
    // and with Quasar's Terminal installed none of them is listed. byId/heuristicLookup still see
    // every entry, so a running foot window keeps its icon.
    readonly property var listed: {
        const ids = entries.map(e => e.id)
        const hasClient = ids.includes("footclient") || ids.includes("org.codeberg.dnkl.footclient")
        const hide = ownTerminal ? footIds
                   : ["foot-server", "org.codeberg.dnkl.foot-server"].concat(hasClient ? ["foot", "org.codeberg.dnkl.foot"] : [])
        const allow = desk ? desk.allowedApps : null       // in a company: what that company can run
        return entries.filter(e => !hide.includes(e.id) && (!allow || allow.has(e.id)))
    }

    // First-party / well-known apps get Quasar glyphs; everything else shows its theme icon in a tile.
    readonly property var known: ({
        "quasar-files":                 { glyph: Icons.folder,   hue: "#7AB8FF" },
        "quasar-settings":              { glyph: Icons.gear,     hue: "#C9CFDC" },
        "quasar-store":                 { glyph: Icons.bag,      hue: "#7AE7FF" },
        "quasar-texteditor":            { glyph: Icons.notes,    hue: "#FFD66B" },
        "quasar-photos":                { glyph: Icons.image,    hue: "#FF9BD2" },
        "quasar-installer":             { glyph: Icons.download, hue: "#7AE7FF" },
        "quasar-sites":                 { glyph: Icons.web,      hue: "#7AE7FF" },
        "quasar-services":              { glyph: Icons.cycle,    hue: "#8CF5B0" },
        "quasar-containers":            { glyph: Icons.layers,   hue: "#7AB8FF" },
        "quasar-terminal":              { glyph: Icons.terminal, hue: "#8CF5B0" },
        "quasar-taskmanager":           { glyph: Icons.activity, hue: "#8CF5B0" },
        "org.codeberg.dnkl.foot":       { glyph: Icons.terminal, hue: "#8CF5B0", name: "Terminal" },
        "org.codeberg.dnkl.footclient": { glyph: Icons.terminal, hue: "#8CF5B0", name: "Terminal" },
        "foot":                         { glyph: Icons.terminal, hue: "#8CF5B0", name: "Terminal" },
        "footclient":                   { glyph: Icons.terminal, hue: "#8CF5B0", name: "Terminal" },
        "firefox-esr":                  { glyph: Icons.globe,    hue: "#7AE7FF" },
        "firefox":                      { glyph: Icons.globe,    hue: "#7AE7FF" },
        "chromium":                     { glyph: Icons.globe,    hue: "#7AE7FF" }
    })

    // Apps without a usable icon get a monogram tile (`letter`) in a hue picked from the app id, so
    // two such apps still look different.
    readonly property var monogramHues: ["#7AB8FF", "#7AE7FF", "#8CF5B0", "#FFD66B", "#FFB86B", "#FF9BD2", "#B9A4FF"]
    function hueFor(s) {
        let h = 0
        for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0
        return monogramHues[Math.abs(h) % monogramHues.length]
    }
    function initial(s) { const m = (s || "").match(/[A-Za-z0-9]/); return m ? m[0].toUpperCase() : "?" }

    function decorate(e) {
        const k = known[e.id]
        const name = (k && k.name) ? k.name : e.name
        const icon = k ? "" : (e.icon ? Quickshell.iconPath(e.icon, true) : "")
        return {
            key: e.id,
            name: name,
            sub: e.genericName || e.comment || "App",
            glyph: k ? k.glyph : "",
            hue: k ? k.hue : (icon ? Theme.text3 : hueFor(e.id)),
            icon: icon,
            letter: initial(name),
            entry: e
        }
    }

    function byId(id) { return DesktopEntries.byId(id) }

    function launch(e, args) {
        if (!e) return
        if (desk && desk.route(e, args)) return            // runs inside the shown company

        let cmd = e.command.slice()
        if (args && args.length) cmd = cmd.concat(args)
        if (e.runInTerminal) cmd = (ownTerminal ? ["quasar-terminal", "-e"] : ["footclient", "-E", "--"]).concat(cmd)
        if (useScopes) {
            const unit = "app-quasar-" + e.id.replace(/[^A-Za-z0-9_.-]/g, "_") + "-" + Date.now()
            cmd = ["systemd-run", "--user", "--scope", "--quiet", "--collect", "--slice=app.slice", "--unit=" + unit, "--"].concat(cmd)
        }
        Quickshell.execDetached({ command: cmd, workingDirectory: e.workingDirectory || Quickshell.env("HOME") })
    }
    function launchId(id, args) {
        const e = byId(id)
        if (e) launch(e, args)
        return !!e
    }

    function search(q, limit) {
        const words = q.toLowerCase().split(/\s+/).filter(w => w.length)
        if (!words.length) return []
        const scored = []
        for (const e of listed) {
            const name = (e.name || "").toLowerCase()
            const hay = name + " " + (e.genericName || "") + " " + (e.comment || "") + " " + (e.keywords || []).join(" ") + " " + (e.categories || []).join(" ")
            const h = hay.toLowerCase()
            if (!words.every(w => h.includes(w))) continue
            const s = name.startsWith(words[0]) ? 0 : name.includes(words[0]) ? 1 : 2
            scored.push({ s, e })
        }
        scored.sort((a, b) => a.s - b.s || a.e.name.localeCompare(b.e.name))
        return scored.slice(0, limit || 6).map(x => decorate(x.e))
    }

    // ---- taskbar ------------------------------------------------------------------------------
    // Which desktop entry a window belongs to. heuristicLookup covers the exact id, its lowercase
    // form and StartupWMClass; `aliases` adds what real app ids look like when they are neither:
    // the reverse-DNS tail (app id "blender" -> org.blender.Blender), the Exec binary or a Flatpak's
    // --command, the Icon name and the Name. Earlier kinds win; rebuilt only when the entries change.
    readonly property var launchers: ["flatpak", "env", "sh", "bash", "python", "python3", "java", "systemd-run"]
    readonly property var aliases: {
        const m = Object.create(null)          // no inherited keys: an app id "constructor" must miss
        const add = (k, e) => { const l = (k || "").toLowerCase(); if (l && !(l in m)) m[l] = e }
        const shown = entries.filter(e => !e.noDisplay)
        for (const e of shown) add(e.id.split(".").pop(), e)
        for (const e of shown) {
            const c = e.command || []
            const fp = c.find(a => a.startsWith("--command="))
            const bin = fp ? fp.slice(10) : (c.length ? c[0].split("/").pop() : "")
            if (!launchers.includes(bin)) add(bin, e)
        }
        for (const e of shown) add(e.icon, e)
        for (const e of shown) add(e.name, e)
        return m
    }
    // foot and footclient are one Terminal: plain foot windows join the (pinned) footclient button.
    readonly property var groupAs: ({ "foot": "footclient", "org.codeberg.dnkl.foot": "org.codeberg.dnkl.footclient" })
    function entryFor(appId) {
        if (!appId) return null
        const e = DesktopEntries.heuristicLookup(appId) || aliases[appId.toLowerCase()]
                  || aliases[appId.split(".").pop().toLowerCase()] || null
        const g = e ? groupAs[e.id] : undefined
        return (g && byId(g)) || e
    }

    // A window no desktop entry claims: its title (or app id) and its app id's theme icon, else a monogram.
    function windowOnly(t, key) {
        const id = t.appId || ""
        const tail = id.split(".").pop()
        const icon = id ? (Quickshell.iconPath(id, true) || Quickshell.iconPath(id.toLowerCase(), true)) : ""
        return { key, name: t.title || tail || "Window", sub: "Window", glyph: "", hue: icon ? Theme.text3 : hueFor(id || key),
                 icon, letter: initial(tail || t.title), entry: null }
    }

    // One button per app: pins first (in order), then every other running app in the order its first
    // window appeared (mockup: pins.concat(running)). Dialogs (toplevels with a parent) fold into their
    // main window's button: they light it up while focused but aren't listed or counted.
    readonly property var taskModel: {
        // Desktop entries load asynchronously: depend on the list so pins resolve once it arrives.
        if (entries.length === 0) return []
        const items = []
        const byKey = Object.create(null)
        for (const id of pins) {
            const e = byId(id)
            if (!e || byKey[e.id]) continue
            if (ownTerminal && footIds.includes(e.id)) continue    // one Terminal button, Quasar's
            byKey[e.id] = Object.assign(decorate(e), { pinned: true, windows: [], focused: false })
            items.push(byKey[e.id])
        }
        for (const t of shown) {
            let main = t
            for (let i = 0; i < 8 && main.parent; i++) main = main.parent
            const e = entryFor(main.appId)
            const key = e ? e.id : "window:" + main.appId
            let it = byKey[key]
            if (!it) {
                it = byKey[key] = Object.assign(e ? decorate(e) : windowOnly(main, key), { pinned: false, windows: [], focused: false })
                items.push(it)
            }
            if (t === main) it.windows.push(t)
            if (t.activated) it.focused = true
        }
        for (const it of items) {
            it.count = it.windows.length
            it.running = it.count > 0
            it.minimized = it.running && it.windows.every(t => t.minimized)
        }
        return items
    }

    // Taskbar click (mockup taskClick, Windows behaviour): launch when not running; a single window
    // minimizes when it has focus, otherwise comes back (restored if minimized) with focus. With
    // several windows it returns false and the shell shows the window list to pick from.
    function taskClick(item) {
        if (!item) return true
        const w = item.windows || []
        if (!w.length) { if (item.entry) launch(item.entry); return true }
        if (w.length > 1) return false
        if (item.focused && !desktopActive && !w[0].minimized) w[0].minimized = true
        else focusWindow(w[0])
        return true
    }
    function focusWindow(t) {
        if (!t || !toplevels.includes(t)) return
        if (t.minimized) t.minimized = false
        t.activate()
    }
    // Windows by a short id that stays the same while the window lives (Command Deck's phones name
    // windows this way). Ids carry this shell's start, so a phone never closes the wrong window after the
    // shell restarts; closed windows drop out of the list as it grows.
    readonly property string winEpoch: (Date.now() % 46656).toString(36)
    // Changed in place (never reassigned), so bindings that call wid() don't loop on it.
    readonly property var _wins: ({ next: 0, list: [] })
    function wid(t) {
        let e = _wins.list.find(x => x.t === t)
        if (!e) {
            if (_wins.list.length > toplevels.length + 16) {
                const live = _wins.list.filter(x => toplevels.includes(x.t))
                _wins.list.length = 0
                for (const x of live) _wins.list.push(x)
            }
            _wins.next += 1
            e = { t: t, n: _wins.next }
            _wins.list.push(e)
        }
        return winEpoch + "-" + e.n
    }
    function win(id) {
        const m = /^([0-9a-z]+)-(\d+)$/.exec(String(id || ""))
        if (!m || m[1] !== winEpoch) return null
        const e = _wins.list.find(x => x.n === parseInt(m[2]))
        return e && shown.includes(e.t) ? e.t : null
    }

    function closeAll(item) { for (const t of ((item && item.windows) || [])) t.close() }
    function newWindow(item) { if (item && item.entry) launch(item.entry) }

    function showDesktop() { for (const t of shown) t.minimized = true }

    readonly property bool coveredByWindow: shown.some(t => t.fullscreen || (t.maximized && t.activated && !t.minimized))
    // One display's wallpaper is hidden: a full-screen or maximized window is on it. Per display, not
    // by focus (only one window is activated, whichever display it's on), so each display's animated
    // wallpaper pauses on its own (shell.qml).
    function coveredOn(screen) {
        if (!screen) return false
        return shown.some(t => !t.minimized && (t.fullscreen || t.maximized) && onScreen(t, screen))
    }
    function onScreen(t, screen) {
        const ss = t.screens
        if (!ss) return false
        for (let i = 0; i < ss.length; i++) if (ss[i] && ss[i].name === screen.name) return true
        return false
    }
}
