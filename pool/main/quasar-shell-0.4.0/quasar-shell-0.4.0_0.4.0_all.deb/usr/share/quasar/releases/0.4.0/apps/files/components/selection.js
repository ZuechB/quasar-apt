.pragma library

// Selection and hit-testing for a Files view. Pure JavaScript (tools/test-files-js.py runs it in a
// bare QJSEngine). A selection is
//   { sel: { path: true, … }, anchor: path | "", focus: path | "" }
// `paths` is what the view shows, in display order. anchor: where Shift ranges start; focus: the
// keyboard cursor (the last item clicked or moved to).

var CTRL = 0x04000000       // Qt.ControlModifier
var SHIFT = 0x02000000      // Qt.ShiftModifier

function empty() { return { sel: {}, anchor: "", focus: "" } }
function only(path) {
    var o = {}
    if (path) o[path] = true
    return { sel: o, anchor: path || "", focus: path || "" }
}
function count(s) { return Object.keys(s.sel).length }
function has(s, path) { return s.sel[path] === true }
// The selected paths in display order.
function list(s, paths) { return paths.filter(function (p) { return s.sel[p] === true }) }

function range(paths, a, b) {
    var lo = Math.min(a, b), hi = Math.max(a, b), o = {}
    for (var i = lo; i <= hi; i++) o[paths[i]] = true
    return o
}
function merge(a, b) {
    var o = {}, k
    for (k in a) o[k] = true
    for (k in b) o[k] = true
    return o
}
// Where a Shift range starts: the anchor, else the cursor, else `fallback`.
function anchorIndex(s, paths, fallback) {
    var a = paths.indexOf(s.anchor)
    if (a < 0) a = paths.indexOf(s.focus)
    return a < 0 ? fallback : a
}

// A click on paths[index]: plain = only it; Ctrl = toggle it; Shift = the range from the anchor;
// Ctrl+Shift = add that range.
function click(s, paths, index, mods) {
    var p = paths[index]
    if (p === undefined) return s
    var ctrl = (mods & CTRL) !== 0, shift = (mods & SHIFT) !== 0
    if (shift) {
        var a = anchorIndex(s, paths, index)
        var r = range(paths, a, index)
        return { sel: ctrl ? merge(s.sel, r) : r, anchor: paths[a], focus: p }
    }
    if (ctrl) {
        var t = merge(s.sel, {})
        if (t[p]) delete t[p]
        else t[p] = true
        return { sel: t, anchor: p, focus: p }
    }
    return only(p)
}

// A selection box over the items at `hits` (indices, in order). base: the selection when the box
// started; with Ctrl or Shift the box adds to it, otherwise it replaces it.
function band(base, paths, hits, mods) {
    var sel = (mods & (CTRL | SHIFT)) !== 0 ? merge(base.sel, {}) : {}
    for (var i = 0; i < hits.length; i++) sel[paths[hits[i]]] = true
    if (!hits.length) return { sel: sel, anchor: base.anchor, focus: base.focus }
    return { sel: sel, anchor: paths[hits[0]], focus: paths[hits[hits.length - 1]] }
}

function all(s, paths) {
    var o = {}
    for (var i = 0; i < paths.length; i++) o[paths[i]] = true
    return { sel: o, anchor: paths.length ? paths[0] : "", focus: s.focus || (paths.length ? paths[0] : "") }
}

// Ctrl+Space: toggle the item under the cursor.
function toggleFocus(s) {
    if (!s.focus) return s
    var t = merge(s.sel, {})
    if (t[s.focus]) delete t[s.focus]
    else t[s.focus] = true
    return { sel: t, anchor: s.focus, focus: s.focus }
}

// Arrow / Home / End / Page keys. k: "left" "right" "up" "down" "home" "end" "pageup" "pagedown".
// cols: items per row (1 in a list); page: rows per screen. Shift extends from the anchor, Ctrl moves
// the cursor without selecting. Returns the new selection, or null for any other key.
function key(s, paths, k, mods, cols, page) {
    var n = paths.length
    if (!n) return null
    cols = Math.max(1, cols || 1)
    page = Math.max(1, page || 1)
    var i = paths.indexOf(s.focus)
    var t
    if (i < 0) {
        if (["left", "right", "up", "down", "home", "end", "pageup", "pagedown"].indexOf(k) < 0) return null
        t = k === "end" ? n - 1 : 0
    } else {
        var row = Math.floor(i / cols), lastRow = Math.floor((n - 1) / cols)
        switch (k) {
        case "left": if (cols === 1) return null; t = Math.max(0, i - 1); break
        case "right": if (cols === 1) return null; t = Math.min(n - 1, i + 1); break
        case "up": t = row > 0 ? i - cols : i; break
        case "down": t = row < lastRow ? Math.min(n - 1, i + cols) : i; break   // a short last row: its last item
        case "home": t = 0; break
        case "end": t = n - 1; break
        case "pageup": t = Math.max(i % cols, i - cols * page); break
        case "pagedown": t = row < lastRow ? Math.min(n - 1, i + cols * page) : i; break
        default: return null
        }
    }
    var p = paths[t]
    if (mods & SHIFT) {
        var a = anchorIndex(s, paths, i < 0 ? t : i)
        var r = range(paths, a, t)
        return { sel: (mods & CTRL) ? merge(s.sel, r) : r, anchor: paths[a], focus: p }
    }
    if (mods & CTRL) return { sel: s.sel, anchor: s.anchor, focus: p }
    return only(p)
}

// Drop what's gone (after a refresh, a filter, a move); returns `s` itself when nothing changed.
function prune(s, paths) {
    var present = {}, i
    for (i = 0; i < paths.length; i++) present[paths[i]] = true
    var sel = {}, changed = false
    for (var p in s.sel) {
        if (present[p]) sel[p] = true
        else changed = true
    }
    var focus = present[s.focus] ? s.focus : "", anchor = present[s.anchor] ? s.anchor : ""
    if (!changed && focus === s.focus && anchor === s.anchor) return s
    return { sel: sel, anchor: anchor, focus: focus }
}

// Type to jump: the next name starting with `prefix` (any case), from index `from`, wrapping. -1: none.
function findPrefix(names, prefix, from) {
    var q = String(prefix).toLowerCase(), n = names.length
    if (!q || !n) return -1
    from = ((from % n) + n) % n
    for (var k = 0; k < n; k++) {
        var i = (from + k) % n
        if (String(names[i]).toLowerCase().indexOf(q) === 0) return i
    }
    return -1
}
// The typed text and where to look: one letter pressed again and again cycles through the names
// starting with it (from after the cursor); anything else searches from the cursor itself.
function typeAhead(buffer, names, focusIndex) {
    var same = buffer.length > 1 && buffer.split("").every(function (c) { return c === buffer[0] })
    var q = same ? buffer[0] : buffer
    var from = focusIndex < 0 ? 0 : (q.length === 1 ? focusIndex + 1 : focusIndex)
    return findPrefix(names, q, from)
}

// ---------------------------------------------------------------------------------------- geometry
// Content coordinates (the ListView's contentItem: item 0 at y 0).
// Grid: g = { cols, cellW, rowH, padX, tileW, tileH }. Tile c of row r covers
//   x: padX + c*cellW + (cellW - tileW)/2 … +tileW,  y: r*rowH … +tileH
function gridRect(g, index) {
    var r = Math.floor(index / g.cols), c = index % g.cols
    return { x: g.padX + c * g.cellW + (g.cellW - g.tileW) / 2, y: r * g.rowH, width: g.tileW, height: g.tileH }
}
// The tile under a point, or -1 (gaps and margins are empty space).
function gridAt(g, x, y, n) {
    if (y < 0) return -1
    var r = Math.floor(y / g.rowH), c = Math.floor((x - g.padX) / g.cellW)
    if (c < 0 || c >= g.cols) return -1
    var i = r * g.cols + c
    if (i >= n) return -1
    var t = gridRect(g, i)
    return x >= t.x && x < t.x + t.width && y >= t.y && y < t.y + t.height ? i : -1
}
function intersects(a, b) {
    return a.x < b.x + b.width && b.x < a.x + a.width && a.y < b.y + b.height && b.y < a.y + a.height
}
// Tiles a box { x, y, width, height } reaches into, in order. Like the desktop, the box has to get
// past a tile's 10px rim: grazing its edge doesn't count.
var RIM = 10
function gridHits(g, box, n) {
    var out = []
    if (box.width <= 0 && box.height <= 0) return out
    var r0 = Math.max(0, Math.floor(box.y / g.rowH)), r1 = Math.floor((box.y + box.height) / g.rowH)
    for (var r = r0; r <= r1; r++) {
        for (var c = 0; c < g.cols; c++) {
            var i = r * g.cols + c
            if (i >= n) return out
            var t = gridRect(g, i)
            if (intersects({ x: t.x + RIM, y: t.y + RIM, width: t.width - 2 * RIM, height: t.height - 2 * RIM }, box)) out.push(i)
        }
    }
    return out
}
// List: rows of rowH from y 0.
function listAt(rowH, y, n) {
    if (y < 0) return -1
    var i = Math.floor(y / rowH)
    return i < n ? i : -1
}
function listHits(rowH, box, n) {
    var out = []
    if (box.width <= 0 && box.height <= 0) return out
    var i0 = Math.max(0, Math.floor(box.y / rowH)), i1 = Math.min(n - 1, Math.floor((box.y + box.height) / rowH))
    for (var i = i0; i <= i1; i++) out.push(i)
    return out
}
// The box between two points.
function box(a, b) {
    return { x: Math.min(a.x, b.x), y: Math.min(a.y, b.y), width: Math.abs(b.x - a.x), height: Math.abs(b.y - a.y) }
}
