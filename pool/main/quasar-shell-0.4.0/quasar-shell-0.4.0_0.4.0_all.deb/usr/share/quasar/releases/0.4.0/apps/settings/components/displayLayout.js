// Settings › Arrange displays: the geometry behind the arrangement card (DisplayArrangement.qml) and
// the changes services/Displays.qml asks /usr/libexec/quasar/displays to make. Pure; tested by
// tools/test-displays-js.py.
// A rect is { name, x, y, w, h } in layout pixels: the mode's size, rotated, divided by the scale and
// truncated, exactly as wlroots places outputs (wlr_output_effective_resolution). Displays only touch:
// a dropped display snaps against a neighbour's edge, never overlaps one, and lines up with its edges
// when it's close; the layout's top-left is always 0,0.
.pragma library

var ROTATED = { "90": true, "270": true, "flipped-90": true, "flipped-270": true }
var ALIGN = 48                 // layout px: closer than this to a neighbour's edge lines up with it
var MIN_SHARED = 100           // layout px of shared edge (at least), so the pointer can cross

function logical(w, h, scale, transform) {
    if (ROTATED[transform]) { var t = w; w = h; h = t }
    var s = scale || 1
    return { w: Math.floor(w / s), h: Math.floor(h / s) }
}

// outputs: the helper's `state` outputs, or entries of a layout; only displays that are on.
function rects(outputs) {
    var out = []
    for (var i = 0; i < outputs.length; i++) {
        var o = outputs[i]
        if (!o || !o.enabled || !o.mode) continue
        var l = logical(o.mode[0], o.mode[1], o.scale, o.transform)
        out.push({ name: o.name, x: o.x || 0, y: o.y || 0, w: l.w, h: l.h })
    }
    return out
}

function find(rs, name) {
    for (var i = 0; i < rs.length; i++) if (rs[i].name === name) return rs[i]
    return null
}

function overlaps(a, b) { return a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h }

// They share a stretch of edge (a corner alone isn't enough to move the pointer across).
function touches(a, b) {
    var side = (a.x + a.w === b.x || b.x + b.w === a.x) && a.y < b.y + b.h && b.y < a.y + a.h
    var stack = (a.y + a.h === b.y || b.y + b.h === a.y) && a.x < b.x + b.w && b.x < a.x + a.w
    return side || stack
}

function clamp(v, lo, hi) { return hi < lo ? (lo + hi) / 2 : Math.max(lo, Math.min(hi, v)) }

// Everything shifted so the top-left display is at 0,0 (wlroots takes positions as given).
function normalize(rs) {
    if (!rs.length) return []
    var mx = Infinity, my = Infinity, i
    for (i = 0; i < rs.length; i++) { mx = Math.min(mx, rs[i].x); my = Math.min(my, rs[i].y) }
    var out = []
    for (i = 0; i < rs.length; i++) out.push({ name: rs[i].name, x: rs[i].x - mx, y: rs[i].y - my, w: rs[i].w, h: rs[i].h })
    return out
}

// Where `name` settles when dropped with its top-left at (x, y): against the nearest edge of another
// display (left, right, above or below it), sharing at least MIN_SHARED px of that edge, not
// overlapping any display, and lined up with that neighbour's edges when within ALIGN px.
// Returns { x, y } in the same coordinates; the only display left sits at 0,0.
function snap(rs, name, x, y) {
    var me = find(rs, name)
    if (!me) return { x: x, y: y }
    var others = rs.filter(function (r) { return r.name !== name })
    if (!others.length) return { x: 0, y: 0 }
    var best = null
    for (var i = 0; i < others.length; i++) {
        var o = others[i]
        var sharedV = Math.min(MIN_SHARED, me.h, o.h), sharedH = Math.min(MIN_SHARED, me.w, o.w)
        var cands = [
            { x: o.x - me.w, y: clamp(y, o.y - me.h + sharedV, o.y + o.h - sharedV), side: true },
            { x: o.x + o.w, y: clamp(y, o.y - me.h + sharedV, o.y + o.h - sharedV), side: true },
            { x: clamp(x, o.x - me.w + sharedH, o.x + o.w - sharedH), y: o.y - me.h, side: false },
            { x: clamp(x, o.x - me.w + sharedH, o.x + o.w - sharedH), y: o.y + o.h, side: false }
        ]
        for (var c = 0; c < cands.length; c++) {
            var p = cands[c]
            if (p.side) {               // line up tops, bottoms or centres
                if (Math.abs(p.y - o.y) <= ALIGN) p.y = o.y
                else if (Math.abs(p.y + me.h - (o.y + o.h)) <= ALIGN) p.y = o.y + o.h - me.h
                else if (Math.abs(p.y + me.h / 2 - (o.y + o.h / 2)) <= ALIGN) p.y = Math.round(o.y + (o.h - me.h) / 2)
            } else {
                if (Math.abs(p.x - o.x) <= ALIGN) p.x = o.x
                else if (Math.abs(p.x + me.w - (o.x + o.w)) <= ALIGN) p.x = o.x + o.w - me.w
                else if (Math.abs(p.x + me.w / 2 - (o.x + o.w / 2)) <= ALIGN) p.x = Math.round(o.x + (o.w - me.w) / 2)
            }
            p.x = Math.round(p.x); p.y = Math.round(p.y)
            var r = { name: name, x: p.x, y: p.y, w: me.w, h: me.h }
            var free = true
            for (var j = 0; j < others.length && free; j++) if (overlaps(r, others[j])) free = false
            if (!free) continue
            var d = (p.x - x) * (p.x - x) + (p.y - y) * (p.y - y)
            if (!best || d < best.d) best = { x: p.x, y: p.y, d: d }
        }
    }
    return best ? { x: best.x, y: best.y } : { x: me.x, y: me.y }
}

// `next` holds the same displays as `before`, some with a new size (resolution, scale, orientation)
// or turned on or off. Displays to the right of a changed one move with its right edge and those
// below it with its bottom edge, so neighbours stay touching. A display left floating (or overlapping)
// snaps to its nearest spot. Returns normalized rects.
function reflow(before, next) {
    var out = next.map(function (r) { return { name: r.name, x: r.x, y: r.y, w: r.w, h: r.h } })
    var i, j
    for (i = 0; i < out.length; i++) {
        var was = find(before, out[i].name)
        if (!was || (was.w === out[i].w && was.h === out[i].h)) continue
        var dw = out[i].w - was.w, dh = out[i].h - was.h
        for (j = 0; j < out.length; j++) {
            if (j === i) continue
            var o = find(before, out[j].name)
            if (!o) continue
            if (dw && o.x >= was.x + was.w) out[j].x += dw
            if (dh && o.y >= was.y + was.h) out[j].y += dh
        }
    }
    // Then nobody floats or overlaps: settle each misplaced display (nearest first) where it was headed.
    for (var pass = 0; pass < out.length; pass++) {
        var bad = -1
        for (i = 0; i < out.length && bad < 0; i++) {
            if (out.length < 2) break
            var alone = true, clash = false
            for (j = 0; j < out.length; j++) {
                if (j === i) continue
                if (overlaps(out[i], out[j])) clash = true
                if (touches(out[i], out[j])) alone = false
            }
            if (clash || alone) bad = i
        }
        if (bad < 0) break
        var s = snap(out, out[bad].name, out[bad].x, out[bad].y)
        out[bad].x = s.x; out[bad].y = s.y
    }
    return normalize(out)
}

// Where a display that's turned on goes: right of everything that's on, top-aligned.
function placeNew(rs, w, h) {
    var right = 0
    for (var i = 0; i < rs.length; i++) right = Math.max(right, rs[i].x + rs[i].w)
    return { x: right, y: 0 }
}

// Drawing the layout into a box of `width` × `height` with `pad` around it: { scale, ox, oy } maps a
// layout point p to (ox + p.x * scale, oy + p.y * scale). `room` (a fraction of the biggest display,
// default 1/4) is kept free on every side, so there's space to drop a display beside, above or below
// the others. Never bigger than 1/6 scale, so one small display doesn't fill the card.
function fit(rs, width, height, pad, room) {
    if (!rs.length) return { scale: 1, ox: width / 2, oy: height / 2 }
    var minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity, bigW = 0, bigH = 0
    for (var i = 0; i < rs.length; i++) {
        minX = Math.min(minX, rs[i].x); minY = Math.min(minY, rs[i].y)
        maxX = Math.max(maxX, rs[i].x + rs[i].w); maxY = Math.max(maxY, rs[i].y + rs[i].h)
        bigW = Math.max(bigW, rs[i].w); bigH = Math.max(bigH, rs[i].h)
    }
    var k = room === undefined ? 0.25 : room
    var bw = Math.max(1, maxX - minX), bh = Math.max(1, maxY - minY)
    var s = Math.min((width - 2 * pad) / (bw + 2 * k * bigW), (height - 2 * pad) / (bh + 2 * k * bigH), 1 / 6)
    return { scale: s, ox: (width - bw * s) / 2 - minX * s, oy: (height - bh * s) / 2 - minY * s }
}

// The display under a point of the card (in its fitted coordinates), or "".
function hit(rs, f, px, py) {
    for (var i = rs.length - 1; i >= 0; i--) {
        var r = rs[i]
        var x = f.ox + r.x * f.scale, y = f.oy + r.y * f.scale
        if (px >= x && px < x + r.w * f.scale && py >= y && py < y + r.h * f.scale) return r.name
    }
    return ""
}
