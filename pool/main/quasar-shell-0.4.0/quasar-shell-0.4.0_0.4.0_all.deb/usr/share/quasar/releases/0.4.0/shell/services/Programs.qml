import QtQuick
import Quickshell
import Quickshell.Io
import Quasar
import Quasar.Services

// Programs from files (.sh, .py, .exe built with .NET, .AppImage; other Windows files get an
// explanation): the shell's side of /usr/libexec/quasar/program, which does the looking, the
// launching and the remembering. This only asks.
//   open(path [, how])  a double-click on the desktop or in Files: a file the user already said yes to
//                       (and that hasn't changed since) runs straight away; how = "terminal" | "apps"
//   external(path)      from another app (xdg-open, the portal, fileop's other callers): always asks
// One question at a time, at most 5 waiting; nothing is queued while the screen is locked.
// "Get .NET N" installs the runtime's Store entry (dotnet-N / aspnetcore-N) through the Store's IPC
// and runs the program when the Store's jobs file says it's done.
Scope {
    id: root
    property var apps: null
    property bool locked: false
    signal toast(var t)

    readonly property string helper: Quickshell.env("QUASAR_PROGRAM") || "/usr/libexec/quasar/program"
    property var queue: []                 // [{ path, external, how }]
    property var current: null             // the question shown: inspect's JSON + { external, how }
    property bool inspecting: false
    property bool starting: false

    property bool gettingRuntime: false
    property real runtimeProgress: -1
    property string runtimeStatus: ""
    property string runtimeId: ""
    property double runtimeSince: 0

    // What the card needs about this PC (re-read whenever a question is shown).
    property bool textEditor: false
    property bool bottlesInstalled: false
    readonly property string runsIn: !current ? ""
        : current.company ? ((Companies.byId(current.company) || {}).name || current.company)
        : Companies.inCompany ? "Personal" : ""

    function open(path, how) { _enqueue(path, false, how || "") }
    function external(path) { _enqueue(path, true, "") }
    function runInTerminal(path) { _enqueue(path, false, "terminal") }

    function _enqueue(path, ext, how) {
        if (!path || locked) return
        if ((current && current.path === path) || queue.some(q => q.path === path)) return
        if (queue.length >= 5) return
        queue = queue.concat([{ path: path, external: ext, how: how }])
        _next()
    }
    function _next() {
        if (current || inspecting || starting || !queue.length) return
        const q = queue[0]
        queue = queue.slice(1)
        inspecting = true
        inspector.req = q
        inspector.run([helper, "inspect", q.path].concat(q.external ? ["--external"] : []))
    }
    onLockedChanged: if (locked) queue = []

    readonly property Cmd inspector: Cmd {
        property var req: null
        onFinished: (code) => root._inspected(inspector.req, inspector.lastLine)
    }
    function _inspected(req, line) {
        inspecting = false
        let info = null
        try { info = JSON.parse(line) } catch (e) { }
        if (!info || info.error) {
            toast({ title: (info && info.error) || "Couldn't open it", sub: FileKit.baseName(req.path),
                    glyph: Icons.alert, hue: Theme.amber })
        } else if (info.kind === "deb") {
            if (apps) apps.launchId("quasar-store", [info.path])
        } else if (info.canRun && req.how === "after-runtime") {
            _start(info, "run")                // the user asked for the runtime to run this
        } else if (info.allowed && !req.external) {
            _start(info, req.how === "terminal" ? "terminal" : req.how === "apps" && info.actions.indexOf("apps") >= 0 ? "apps" : "run")
        } else {
            textEditor = !!(apps && apps.byId("quasar-texteditor"))
            bottlesInstalled = !!DesktopEntries.byId("com.usebottles.bottles")
            current = Object.assign({}, info, { external: req.external, how: req.how })
        }
        Qt.callLater(_next)
    }

    function choose(action) {
        const c = current
        if (!c) return
        if (action === "runtime") return _getRuntime(c)
        if (gettingRuntime && action !== "cancel") return
        dismiss()
        if (action === "edit") { if (apps) apps.launchId("quasar-texteditor", [c.path]) }
        else if (action === "store") { if (apps) apps.launchId("quasar-store", ["search:" + ((c.detail || {}).missing || "")]) }
        else if (action === "bottles") {
            if (bottlesInstalled) Quickshell.execDetached(["/usr/libexec/quasar/fileop", "open-with", "com.usebottles.bottles", c.path])
            else if (apps) apps.launchId("quasar-store", ["app:com.usebottles.bottles"])
        }
        else if (action === "run" || action === "apps" || action === "terminal")
            _start(c, action === "run" && c.how === "terminal" ? "terminal" : action)
    }
    function dismiss() {
        current = null
        gettingRuntime = false
        runtimeId = ""
        storeIpc.stop()
        jobsPoll.stop()
        Qt.callLater(_next)
    }

    function _start(info, how) {
        starting = true
        starter.info = info
        starter.how = how
        starter.run([helper, "run", info.path, "--expect", info.key, "--how", how])
    }
    readonly property Cmd starter: Cmd {
        property var info: null
        property string how: ""
        onFinished: (code) => root._started(starter.info, starter.how, starter.lastLine)
    }
    function _started(info, how, line) {
        starting = false
        let r = null
        try { r = JSON.parse(line) } catch (e) { }
        if (r && r.ok) {
            if (how === "apps") toast({ title: "“" + info.name + "” is in Apps", sub: "Find it in the launcher next time",
                                        glyph: Icons.grid, hue: Theme.accent })
        } else if (r && r.reason === "changed") {
            // It changed after it was checked: look again, and ask again.
            queue = [{ path: info.path, external: true, how: "" }].concat(queue)
        } else {
            toast({ title: (r && r.error) || "Couldn't start it", sub: info.name, glyph: Icons.alert, hue: Theme.amber })
        }
        Qt.callLater(_next)
    }

    // Launcher › Remove from Apps on an AppImage that was added to Apps.
    function removeFromApps(id, label) {
        remover.label = label
        remover.run([helper, "unintegrate", id])
    }
    readonly property Cmd remover: Cmd {
        property string label: ""
        onFinished: (code) => root.toast(code === 0
            ? { title: remover.label + " was removed from Apps", sub: "Its file is in the Trash", glyph: Icons.trash, hue: Theme.text3 }
            : { title: "Couldn't remove " + remover.label, sub: "It may already be gone", glyph: Icons.alert, hue: Theme.amber })
    }

    // A program that failed in its first seconds (the launcher's watcher): offer Terminal to see why.
    function exited(b64) {
        let m = null
        try { m = JSON.parse(Qt.atob(b64)) } catch (e) { return }
        toast({ title: "“" + (m.name || "The program") + "” stopped right away",
                sub: "Click to run it in Terminal and see why", glyph: Icons.alert, hue: Theme.amber,
                runTerminal: m.path || "" })
    }

    // ---- getting a .NET runtime through the Store ---------------------------------------------------
    readonly property string runtimeName: current && current.detail
        ? ((current.detail.aspnet ? "ASP.NET Core " : ".NET ") + current.detail.major) : ""
    function _getRuntime(c) {
        if (gettingRuntime) return
        const d = c.detail || {}
        runtimeId = d.storeId || ((d.aspnet ? "aspnetcore-" : "dotnet-") + d.major)
        runtimeSince = Date.now()
        gettingRuntime = true
        runtimeProgress = -1
        runtimeStatus = "Opening the Store…"
        if (apps) apps.launchId("quasar-store", ["app:" + runtimeId])
        storeIpc.tries = 0
        storeIpc.start()
    }
    function _runtimeFailed(why) {
        gettingRuntime = false
        storeIpc.stop()
        jobsPoll.stop()
        runtimeStatus = ""
        toast({ title: "Couldn't get " + runtimeName, sub: why, glyph: Icons.alert, hue: Theme.amber })
    }
    // The Store answers once it's up (it may be starting): ask again for ~30 s.
    Timer {
        id: storeIpc
        property int tries: 0
        interval: 700; repeat: true
        onTriggered: {
            if (!root.gettingRuntime) { stop(); return }
            if (++tries > 40) { stop(); root._runtimeFailed("The Store didn't answer"); return }
            if (!ipcCmd.running) ipcCmd.run(["qs", "--path", "/usr/share/quasar/apps/store", "ipc", "call", "app", "install", root.runtimeId])
        }
    }
    Cmd {
        id: ipcCmd
        onFinished: (code) => {
            if (code !== 0 || !root.gettingRuntime) return       // not up yet: the timer asks again
            storeIpc.stop()
            const r = (ipcCmd.lastLine || "").trim()
            if (r === "queued" || r === "busy") { root.runtimeStatus = "Getting " + root.runtimeName + "…"; jobsPoll.start() }
            else if (r === "unknown") root._runtimeFailed("This version of Quasar doesn't offer it")
            else root._runtimeFailed("The Store can't install it right now")
        }
    }
    // The Store's jobs file (only the Store writes it): progress, then the result.
    FileView {
        id: jobsFile
        path: (Quickshell.env("XDG_RUNTIME_DIR") || "/tmp") + "/quasar-store-jobs.json"
        printErrors: false
        onLoaded: if (root.gettingRuntime) root._jobs(text())
    }
    Timer {
        id: jobsPoll
        interval: 1000; repeat: true
        property int ticks: 0
        onRunningChanged: if (running) ticks = 0
        onTriggered: {
            if (!root.gettingRuntime) { stop(); return }
            if (++ticks > 3600) { stop(); root._runtimeFailed("It took too long"); return }
            jobsFile.reload()
        }
    }
    function _jobs(text) {
        let data = null
        try { data = JSON.parse(text) } catch (e) { return }
        const job = (data.jobs || {})[runtimeId]
        if (job) {
            runtimeProgress = job.state === "busy" ? (job.progress || 0) : -1
            runtimeStatus = job.state === "queued" ? "Waiting for the Store…"
                : "Getting " + runtimeName + "… " + Math.round((job.progress || 0) * 100) + "%"
        }
        const res = (data.results || {})[runtimeId]
        if (!res || res.at < runtimeSince) return
        jobsPoll.stop()
        if (res.ok) {
            const c = current
            gettingRuntime = false
            current = null
            if (c) queue = [{ path: c.path, external: c.external, how: "after-runtime" }].concat(queue)
            Qt.callLater(_next)
        } else {
            _runtimeFailed(res.cancelled ? "It was cancelled" : (res.message || "The Store couldn't install it"))
        }
    }

    function stateJson() {
        return JSON.stringify({ current: current ? { path: current.path, kind: current.kind, reason: current.reason,
                                                     actions: current.actions, allowed: current.allowed } : null,
                                queued: queue.length, inspecting: inspecting, starting: starting,
                                gettingRuntime: gettingRuntime, runtime: runtimeId })
    }
}
