import QtQuick
import Quasar

// "Join other network…" (a hidden network: type its name and security) and the sign-in for a
// work/school (WPA2/WPA3-Enterprise) network from the list. Goes inside a Dialog; the host reads
// `valid` / `spec()` for its Join button. Pure view.
//   spec() -> { ssid, hidden, security: "open"|"psk"|"sae"|"enterprise", password, identity,
//               eap: "peap"|"ttls", domain, noCheck }
Column {
    id: root
    property bool hidden: true              // false: a listed Enterprise network (`ssid` given)
    property string ssid: ""
    property int security: 1                // hidden networks: 0 none · 1 password · 2 WPA3 only · 3 work or school
    property int method: 0                  // 0 PEAP (most networks, eduroam) · 1 TTLS
    property bool noCheck: false
    signal submitted()

    readonly property bool enterprise: !hidden || security === 3
    readonly property bool needsPassword: enterprise || security === 1 || security === 2
    readonly property string name: hidden ? nameField.text.trim() : ssid
    readonly property bool valid: name.length > 0 && name.length <= 32
        && (!needsPassword || (security === 1 && !enterprise ? passField.text.length >= 8 && passField.text.length <= 63 : passField.text.length > 0))
        && (!enterprise || (userField.text.trim().length > 0 && (noCheck || /^[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)+$/.test(domainField.text.trim()))))

    function reset(listedSsid) {
        hidden = !listedSsid
        ssid = listedSsid || ""
        security = 1; method = 0; noCheck = false
        nameField.text = ""; userField.text = ""; passField.text = ""; domainField.text = ""
    }
    function focusFirst() { (hidden ? nameField : userField).focusInput() }
    function clearSecrets() { passField.text = "" }
    function spec() {
        return { ssid: name, hidden: hidden, password: passField.text,
                 security: enterprise ? "enterprise" : ["open", "psk", "sae"][security],
                 identity: userField.text.trim(), eap: method === 1 ? "ttls" : "peap",
                 domain: domainField.text.trim(), noCheck: noCheck }
    }
    function submitIfValid() { if (valid) submitted() }

    width: parent ? parent.width : 380
    spacing: 10

    TextField { id: nameField; visible: root.hidden; width: parent.width; glyph: Icons.wifi; placeholder: "Network name"; onAccepted: root.submitIfValid() }
    Segmented {
        visible: root.hidden
        width: parent.width
        model: ["None", "Password", "WPA3 only", "Work or school"]
        currentIndex: root.security
        accessibleName: "Security"
        onPicked: (i) => root.security = i
    }
    TextField { id: userField; visible: root.enterprise; width: parent.width; glyph: Icons.user; placeholder: "Username (often your email)"; onAccepted: root.submitIfValid() }
    TextField {
        id: passField
        visible: root.needsPassword
        width: parent.width
        glyph: Icons.lock
        password: true
        placeholder: root.enterprise ? "Password" : "Network password"
        onAccepted: root.submitIfValid()
    }
    TextField {
        id: domainField
        visible: root.enterprise && !root.noCheck
        width: parent.width
        glyph: Icons.shield
        mono: true
        placeholder: "Server domain, e.g. radius.example.edu"
        onAccepted: root.submitIfValid()
    }
    Text {
        visible: root.enterprise
        width: parent.width
        wrapMode: Text.Wrap
        text: root.noCheck ? "Without the check, a fake hotspot with the same name could collect your password. Only use this if your IT department says so."
                           : "Your IT department or school gives you the server domain. Quasar checks the network's certificate against it, so a fake hotspot can't collect your password."
        font.family: Theme.fontUi; font.pointSize: Theme.pt(12); color: root.noCheck ? Theme.amber : Theme.textDim
    }
    Segmented {
        visible: root.enterprise
        width: parent.width
        model: ["PEAP (most networks)", "TTLS"]
        currentIndex: root.method
        accessibleName: "Sign-in method"
        onPicked: (i) => root.method = i
    }
    Row {
        visible: root.enterprise
        spacing: 10
        QSwitch { anchors.verticalCenter: parent.verticalCenter; checked: root.noCheck; accessibleName: "Don't check the server"; onToggled: root.noCheck = !root.noCheck }
        Text {
            anchors.verticalCenter: parent.verticalCenter
            text: "Don't check the server (unsafe)"
            font.family: Theme.fontUi; font.pointSize: Theme.pt(12.5); color: Theme.text3
        }
    }
}
