import QtQuick
import Quickshell
import Quasar
import Quasar.Services

// "<App> wants to receive connections": quasar-netguard tells us when the firewall refused a connection
// that an app of ours was listening for, and we ask. Allow goes through the firewall helper (pkexec:
// the polkit agent asks for the password unless it's remembered, or on the live USB); Not now snoozes
// that app until the session ends. Off with Settings › Firewall › Ask when an app is blocked.
//   current      the prompt on screen: { key, label, app, kind: "app"|"port", port, proto, from,
//                network: { uuid, name, home, state } | null, allowed }
//   notify(t)    a toast for the shell ({ title, sub, glyph })
// QUASAR_FIREWALL swaps the helper (tests), QUASAR_NETGUARD_SOCK the service's socket.
QtObject {
    id: root
    property bool enabled: Settings.firewallAsk !== false
    property var current: null
    property var queue: []
    property bool busy: false
    signal notify(var toast)

    readonly property string helper: Quickshell.env("QUASAR_FIREWALL") || ""
    property var client: null
    property int retries: 0

    readonly property Component _clientComponent: Component { NetGuardClient { } }

    function start() {
        if (!enabled || (client && !client.dead)) return
        if (client) client.destroy()
        client = _clientComponent.createObject(root)
        client.event.connect(root.received)
        client.lost.connect(root.later)
        client.request({ op: "subscribe" }, (r) => { if (r.ok) root.retries = 0; else root.later() })
    }
    function stop() {
        if (client) { client.destroy(); client = null }
        queue = []
        current = null
    }
    // The service may not be up yet (boot, a restart): try again, less and less often.
    function later() {
        if (!enabled) return
        retries++
        _retry.interval = Math.min(30000, 1000 * Math.pow(2, Math.min(retries, 5)))
        _retry.restart()
    }
    readonly property Timer _retry: Timer { onTriggered: root.start() }
    onEnabledChanged: enabled ? start() : stop()
    Component.onCompleted: start()

    function received(ev) {
        if (!enabled || !ev || ev.event !== "prompt" || typeof ev.key !== "string") return
        const same = (p) => p.key === ev.key && p.port === ev.port
        if ((current && same(current)) || queue.some(same)) return
        if (!current) show(ev)
        else queue = queue.concat([ev]).slice(-5)
    }
    function show(ev) {
        current = ev
        _timeout.restart()
    }
    function next() {
        _timeout.stop()
        busy = false
        current = queue.length ? queue[0] : null
        queue = queue.slice(1)
        if (current) _timeout.restart()
    }
    // Nobody answered: same as Not now, so the card doesn't sit there forever.
    readonly property Timer _timeout: Timer { interval: 60000; onTriggered: root.notNow() }

    // What the person sees the app as: its desktop entry when it has one.
    function appName(p) {
        if (!p) return ""
        const e = p.app ? DesktopEntries.byId(p.app) : null
        return (e && e.name) ? e.name : (p.label || p.app || "An app")
    }
    function appIcon(p) {
        const e = p && p.app ? DesktopEntries.byId(p.app) : null
        return e && e.icon ? Quickshell.iconPath(e.icon, true) : ""
    }

    function notNow() {
        if (!current) return
        if (client && !client.dead) client.request({ op: "snooze", key: current.key }, null)
        next()
    }

    function allow() {
        if (!current || busy) return
        const p = current
        const name = appName(p)
        const spec = p.kind === "app" && p.app
            ? { app: p.app, name: name }
            : { name: (name + " · port " + p.port).slice(0, 40), tcp: p.proto === "tcp" ? String(p.port) : "",
                udp: p.proto === "udp" ? String(p.port) : "" }
        if (p.network && !p.network.home && p.network.uuid) spec.home = p.network.uuid
        busy = true
        _cmd.prompt = p
        _cmd.name = name
        _cmd.run((helper ? [helper] : ["pkexec", "/usr/libexec/quasar/quasar-firewall"]).concat(["allow"]),
                 undefined, JSON.stringify(spec))
    }
    readonly property Cmd _cmd: Cmd {
        property var prompt: null
        property string name: ""
        onFinished: (code) => {
            const p = prompt
            if (code === 0) {
                root.notify({ title: name + " can receive connections",
                              sub: p && p.kind === "port" ? "Port " + p.port + ", from devices on your home networks."
                                                          : "From devices on your home networks.",
                              glyph: Icons.shield })
            } else if (code === 127) {
                root.notify({ title: "Your account can't change the firewall", sub: "Ask an administrator.", glyph: Icons.shield })
            } else if (code !== 126) {           // 126: the password sheet was closed
                const err = tail.find(l => l.startsWith("ERROR ")) || ""
                root.notify({ title: "The firewall didn't change", sub: err ? err.slice(6) : "Try again in Settings › Firewall.",
                              glyph: Icons.shield })
            }
            root.next()
        }
    }
}
