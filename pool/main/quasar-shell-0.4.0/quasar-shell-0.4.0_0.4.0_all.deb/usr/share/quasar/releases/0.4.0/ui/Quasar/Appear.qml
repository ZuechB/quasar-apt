import QtQuick

// Template "rowIn" entrance: content rises 8px and fades in (450ms, soft curve), staggered by
// `order` x 35ms (the first 12 items only; later ones appear at once). Runs when created; replay()
// runs it again on an item that stays (a Settings group kept across a page switch). Off with
// reduced motion.
Item {
    id: root
    property int order: 0
    property int stagger: 35
    property bool enabledAnim: !Theme.reduceMotion && order < 12
    default property alias content: inner.data

    function replay() { if (enabledAnim) anim.restart() }

    implicitWidth: inner.childrenRect.width
    implicitHeight: inner.childrenRect.height

    Item {
        id: inner
        width: root.width
        height: root.height
        opacity: root.enabledAnim ? 0 : 1
        transform: Translate { id: shift; y: root.enabledAnim ? 8 : 0 }
    }

    SequentialAnimation {
        id: anim
        running: root.enabledAnim
        PropertyAction { target: inner; property: "opacity"; value: 0 }
        PropertyAction { target: shift; property: "y"; value: 8 }
        PauseAnimation { duration: root.order * root.stagger }
        ParallelAnimation {
            NumberAnimation { target: inner; property: "opacity"; to: 1; duration: Motion.row; easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.soft }
            NumberAnimation { target: shift; property: "y"; to: 0; duration: Motion.row; easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.soft }
        }
    }
}
