import QtQuick
import Quickshell
import Quickshell.Io
import Quasar
import Quasar.Services

// .deb files in the Store. A file the user opened becomes a page: `program deb-info` reads its fields
// and apt's dry run (what it adds, what it would remove, what needs the internet), then a second pass
// its own icon and desktop entry. Packages installed from files (quasar-debfile's records, readable by
// everyone) show in Installed with Open and Remove.
// Entries are synthetic — id "deb:<package>", source "debfile", fromFile (never in search or the
// shelves) — and added only once the catalog has loaded (it replaces its list when it loads).
Scope {
    id: root
    property var catalog: null
    signal opened(string id)
    signal failed(string title, string message)
    // Entries came or went: the Store asks dpkg again (Installed only queries the packages it knew of).
    signal entriesChanged()
    readonly property string helper: Quickshell.env("QUASAR_PROGRAM") || "/usr/libexec/quasar/program"
    property string pending: ""

    function open(path) {
        if (!catalog || !catalog.ready) { pending = path; return }
        reader.path = path
        reader.run([helper, "deb-info", path])
    }
    Connections {
        target: root.catalog
        function onReadyChanged() {
            if (!root.catalog.ready) return
            root.refresh()
            if (root.pending) { const p = root.pending; root.pending = ""; root.open(p) }
        }
    }

    readonly property Cmd reader: Cmd {
        property string path: ""
        onFinished: (code) => {
            let d = null
            try { d = JSON.parse(reader.lastLine) } catch (e) { }
            if (!d || d.error || !d.name) {
                root.failed("This package can't be opened", (d && d.error) || FileKit.baseName(reader.path))
                return
            }
            const id = "deb:" + d.name
            root.catalog.putLocal(root.entry(d, root.catalog.byId(id)))
            root.entriesChanged()
            root.opened(id)
            iconReader.id = id
            iconReader.run([root.helper, "deb-info", d.path, "--icon"])
        }
    }
    readonly property Cmd iconReader: Cmd {
        property string id: ""
        onFinished: (code) => {
            let d = null
            try { d = JSON.parse(iconReader.lastLine) } catch (e) { return }
            const e = root.catalog.byId(iconReader.id)
            if (!e || d.error) return
            root.catalog.putLocal(Object.assign({}, e, { name: d.appName || e.name, desktopId: d.desktopId || e.desktopId || "",
                                                         icon: d.icon ? "file://" + d.icon : (e.icon || "") }))
        }
    }

    function entry(d, prev) {
        const keep = prev && prev.desktopId ? { name: prev.name, desktopId: prev.desktopId, icon: prev.icon } : {}
        return Object.assign({
            id: "deb:" + d.name, name: d.name, cat: "", glyph: "pkg", hue: "#B9A4FF",
            dev: String(d.maintainer || "").replace(/\s*<[^>]*>\s*$/, "") || "Unknown maker",
            blurb: d.summary || "", desc: d.description || "",
            home: /^https?:\/\/[^\s]+$/i.test(d.homepage || "") ? d.homepage : "",
            version: d.version, source: "debfile", fromFile: true, pkgs: [d.name],
            file: d.path, sha256: d.sha256, origin: d.origin || "", plan: d.plan || null, arch: d.arch,
            installedVersion: d.installed || "", older: !!d.older, same: !!d.same, essential: !!d.essential,
            size: { download: d.size, installed: d.installedSize }
        }, keep)
    }

    // ---- installed from files ---------------------------------------------------------------------
    // The records file may not exist yet (a FileView only watches a file that existed when it loaded),
    // so the Store also calls refresh() after every .deb job.
    FileView {
        path: Quickshell.env("QUASAR_DEBFILE_RECORDS") || "/var/lib/quasar/debfiles.json"
        watchChanges: true
        printErrors: false
        onFileChanged: reload()
        onLoaded: root.refresh()
    }
    function refresh() {
        if (!catalog || !catalog.ready) return
        if (lister.running) { lister.again = true; return }
        lister.run([helper, "deb-installed"])
    }
    readonly property Cmd lister: Cmd {
        property bool again: false
        onFinished: (code) => {
            let d = null
            try { d = JSON.parse(lister.lastLine) } catch (e) { }
            if (d) root._installed(d.packages || [])
            if (lister.again) { lister.again = false; root.refresh() }
        }
    }
    function _installed(list) {
        const names = list.map(p => "deb:" + p.name)
        for (const p of list) {
            const id = "deb:" + p.name
            const prev = catalog.byId(id)
            if (prev && prev.file) continue                 // an opened file's page keeps its details
            const ip = p.iconName ? Quickshell.iconPath(p.iconName, true) : ""
            catalog.putLocal({
                id: id, name: p.appName || p.name, dev: "Installed from a file", blurb: p.summary || "", cat: "",
                glyph: "pkg", hue: "#B9A4FF", source: "debfile", fromFile: true, pkgs: [p.name], version: p.version,
                desktopId: p.desktopId || "", icon: ip ? (ip.indexOf(":") > 0 ? ip : "file://" + ip) : "",
                installedVersion: p.version, same: true, addedSources: p.sources || [] })
        }
        // Removed since (and not an opened file, which can be installed again): gone from the Store.
        for (const a of catalog.apps.filter(a => a.source === "debfile" && !a.file && names.indexOf(a.id) < 0))
            catalog.dropLocal(a.id)
        entriesChanged()
    }
}
