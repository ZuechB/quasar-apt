.pragma library

// File helpers shared by the desktop and Files (`import Quasar` → FileKit). Pure JavaScript with no
// Qt objects, so tools/test-files-js.py runs it in a bare QJSEngine. Glyphs are Icons names
// (Icons.get(name) in QML); a null hue means "the default text colour".

// Case-insensitive "natural" order: "File 2" before "File 10".
function naturalCompare(a, b) {
    var ax = String(a).toLowerCase().match(/\d+|\D+/g) || []
    var bx = String(b).toLowerCase().match(/\d+|\D+/g) || []
    for (var i = 0; i < Math.min(ax.length, bx.length); i++) {
        var x = ax[i], y = bx[i]
        if (x === y) continue
        if (/^\d/.test(x) && /^\d/.test(y)) {
            var d = parseInt(x, 10) - parseInt(y, 10)
            if (d !== 0) return d
            continue
        }
        return x.localeCompare(y)
    }
    return ax.length - bx.length
}

// ---------------------------------------------------------------------------------------- kinds
// The template's Files kinds (KIND table) plus audio and code, matching the desktop's colours.
var KINDS = {
    dir:     { glyph: "folder", hue: "#7AB8FF", fill: "#2E7AB8FF" },
    image:   { glyph: "image",  hue: "#FF9BD2" },
    video:   { glyph: "video",  hue: "#FFB86B" },
    audio:   { glyph: "music",  hue: "#FF8FB1" },
    archive: { glyph: "pkg",    hue: "#B9A4FF" },
    package: { glyph: "pkg",    hue: "#B9A4FF" },
    sheet:   { glyph: "sheet",  hue: "#8CF5B0" },
    code:    { glyph: "code",   hue: "#B9A4FF" },
    program: { glyph: "cube",   hue: "#7AE7FF" },
    doc:     { glyph: "notes",  hue: "#FFD66B" },
    link:    { glyph: "link",   hue: null },
    file:    { glyph: "file",   hue: null }
}
var EXT = (function () {
    var m = {}
    function put(kind, list) { list.split(" ").forEach(function (e) { m[e] = kind }) }
    put("image", "png jpg jpeg gif bmp webp ico svg tiff tif heic avif")
    put("video", "mp4 mkv webm mov avi m4v")
    put("audio", "mp3 flac ogg opus wav m4a aac")
    put("archive", "zip 7z rar tar gz tgz xz txz bz2 tbz2 zst tzst")
    put("package", "deb rpm flatpakref iso img")
    put("program", "exe appimage msi bat cmd")
    put("sheet", "csv ods xls xlsx")
    put("code", "sh bash zsh py js ts cs java cpp c h html htm css scss rs go qml")
    put("doc", "txt md log json xml ini conf cfg yaml yml toml pdf odt doc docx rtf")
    put("link", "desktop url")
    return m
})()

// What opening a file does beyond showing it in an app: "program" for what the shell runs after
// asking (scripts, AppImages, .NET .exe files; other Windows files get an explanation there),
// "package" for a .deb the Store installs, "" for everything else. By name, not MIME type: file(1)
// calls a .sh without a #! line text/plain and an AppImage application/x-pie-executable like any
// program. The desktop, Files and fileop all route by this.
function openAs(name) {
    var s = suffixOf(name)
    if (/^(sh|py|exe|appimage|msi|bat|cmd)$/.test(s)) return "program"
    if (s === "deb") return "package"
    return ""
}

function suffixOf(name) {
    var i = String(name).lastIndexOf(".")
    return i > 0 ? String(name).slice(i + 1).toLowerCase() : ""
}

// The kind of a file by its name: "dir", "image", "doc", … ("file" when nothing matches).
function kindOf(name, isDir) {
    return isDir ? "dir" : (EXT[suffixOf(name)] || "file")
}
function look(kind) { return KINDS[kind] || KINDS.file }

// Archives that opening extracts next to themselves (fileop extract); packages are left alone.
function isArchiveName(name) {
    var low = String(name).toLowerCase()
    return /\.(zip|7z|rar|tar|gz|tgz|xz|txz|bz2|tbz2|zst|tzst)$/.test(low) && low.indexOf(".") > 0
}

// Pictures the grid draws as a thumbnail (Qt can decode them without plugins we don't ship).
function isPicture(name) { return /^(png|jpe?g|gif|bmp|webp)$/.test(suffixOf(name)) }

// ---------------------------------------------------------------------------------------- text
// "0 bytes", "1 byte", "512 bytes", "12 KB", "1.2 MB", "3.4 GB" (1000s, like the Store and GNOME).
function formatSize(n) {
    n = +n || 0
    if (n < 1000) return n === 1 ? "1 byte" : Math.round(n) + " bytes"
    var units = ["KB", "MB", "GB", "TB"], i = -1
    do { n /= 1000; i++ } while (n >= 1000 && i < units.length - 1)
    return (n < 10 ? n.toFixed(1).replace(/\.0$/, "") : Math.round(n)) + " " + units[i]
}

// "N item(s)"
function countText(n, word) {
    word = word || "item"
    return n + " " + word + (n === 1 ? "" : "s")
}

// ---------------------------------------------------------------------------------------- paths
function baseName(path) {
    var p = String(path).replace(/\/+$/, "")
    if (p === "") return "/"
    return p.slice(p.lastIndexOf("/") + 1)
}
function parentOf(path) {
    var p = String(path).replace(/\/+$/, "")
    var i = p.lastIndexOf("/")
    return i <= 0 ? "/" : p.slice(0, i)
}
function joinPath(dir, name) { return (dir === "/" ? "" : String(dir).replace(/\/+$/, "")) + "/" + name }
// Whether `path` is `dir` or inside it.
function within(path, dir) {
    var d = String(dir).replace(/\/+$/, "")
    return path === dir || String(path).indexOf(d + "/") === 0
}

// A local path as a file:// URL ("#", "?" and spaces in file names would otherwise break it).
function fileUrl(path) {
    return path ? "file://" + String(path).split("/").map(encodeURIComponent).join("/") : ""
}
// The local path of a file:// URL, or "" for anything else.
function localPath(u) {
    var m = /^file:\/\/(?:localhost)?(\/[^?#]*)$/.exec(String(u))
    if (!m) return ""
    try { return decodeURIComponent(m[1]) } catch (e) { return "" }
}
// text/uri-list for a drag: CRLF between entries and none at the end (Qt splits a string uri-list
// on CRLF only, and a trailing one adds an empty URL).
function uriList(paths) { return paths.map(fileUrl).join("\r\n") }

// A launch argument as a path: file:// decoded, "~" expanded; "" when it isn't a local path.
function argPath(arg, home) {
    var a = String(arg || "").trim()
    if (a === "") return ""
    if (a.indexOf("file:") === 0) return localPath(a)
    if (a === "~") return home
    if (a.indexOf("~/") === 0) return joinPath(home, a.slice(2))
    return a.charAt(0) === "/" ? a.replace(/\/+$/, "") || "/" : ""
}

// Breadcrumb parts of a folder: [{label, path}]. Inside home it starts at "Home", on an open drive
// at the drive (roots: [{path, label}], e.g. "/media/you/STICK" as "STICK"), elsewhere at "This PC"
// (the root). `names` may rename known folders ({path: label}), e.g. the Trash.
function crumbs(path, home, names, roots) {
    names = names || {}
    var out = []
    var start = within(path, home) ? home : "/"
    var label = start === "/" ? "This PC" : "Home"
    ;(roots || []).forEach(function (r) {
        if (r.path && within(path, r.path) && r.path.length > start.length) { start = r.path; label = r.label }
    })
    out.push({ label: names[start] || label, path: start })
    var rest = String(path).slice(start === "/" ? 1 : start.length).split("/").filter(function (s) { return s !== "" })
    var at = start
    rest.forEach(function (s) {
        at = joinPath(at, s)
        out.push({ label: names[at] || s, path: at })
    })
    return out
}

// ---------------------------------------------------------------------------------------- rows
var BIG_PICTURE = 20 * 1000 * 1000      // larger pictures get no thumbnail (decoding them stalls a grid)

// One item as Files shows it. mtime: milliseconds.
function row(name, path, isDir, size, mtime) {
    var kind = kindOf(name, isDir)
    var k = look(kind)
    return {
        name: name, path: path, isDir: !!isDir, size: isDir ? 0 : (+size || 0), mtime: +mtime || 0,
        hidden: String(name).charAt(0) === ".", kind: kind, glyph: k.glyph, hue: k.hue, fill: k.fill || "",
        archive: !isDir && isArchiveName(name),
        thumb: !isDir && isPicture(name) && (+size || 0) <= BIG_PICTURE ? fileUrl(path) : ""
    }
}

// rows: [{name, isDir, size, mtime, hidden, …}]. Folders first, then by key; ties by name.
function sortRows(rows, key, reversed) {
    var dir = reversed ? -1 : 1
    var byName = function (a, b) { return naturalCompare(a.name, b.name) }
    var cmp = key === "size" ? function (a, b) { return (a.size - b.size) || byName(a, b) }
            : key === "modified" ? function (a, b) { return (a.mtime - b.mtime) || byName(a, b) }
            : byName
    return rows.slice().sort(function (a, b) {
        if (a.isDir !== b.isDir) return a.isDir ? -1 : 1
        return dir * cmp(a, b)
    })
}

// Instant search: names containing every word of the query, any case.
function filterRows(rows, query) {
    var words = String(query || "").toLowerCase().split(/\s+/).filter(function (w) { return w !== "" })
    if (!words.length) return rows
    return rows.filter(function (r) {
        var n = r.name.toLowerCase()
        return words.every(function (w) { return n.indexOf(w) >= 0 })
    })
}
