import QtQuick
import Quasar

// Right-click menu over a terminal (template menu look: 12px radius, menu glass, hairline, 32px rows
// with a glyph, a label and the keyboard shortcut). Closes on a click outside or Esc.
//   items: [{ key, label, glyph, hint, enabled }, { sep: true }, …]
Item {
    id: root
    anchors.fill: parent
    property bool open: false
    property real menuX: 0
    property real menuY: 0
    property var items: []
    signal chosen(string key)
    signal dismissed()

    function show(x, y) { menuX = x; menuY = y; open = true; card.forceActiveFocus() }

    visible: open
    z: 900

    MouseArea {
        anchors.fill: parent
        acceptedButtons: Qt.AllButtons
        onPressed: root.dismissed()
    }

    Rectangle {
        id: card
        x: Math.max(6, Math.min(root.menuX, root.width - width - 6))
        y: root.menuY + height > root.height - 6 ? Math.max(6, root.menuY - height) : root.menuY
        width: 240
        height: col.implicitHeight + 12
        radius: 12
        color: Theme.menuBg
        border.width: 1
        border.color: Theme.white(0.1)
        Accessible.role: Accessible.PopupMenu
        Keys.onEscapePressed: root.dismissed()
        MouseArea { anchors.fill: parent }       // clicks between rows don't close it

        Column {
            id: col
            x: 6; y: 6
            width: parent.width - 12
            Repeater {
                model: root.items
                delegate: Item {
                    required property var modelData
                    width: col.width
                    height: modelData.sep ? 9 : 32
                    Rectangle {
                        visible: !!modelData.sep
                        anchors.centerIn: parent
                        width: parent.width - 12; height: 1
                        color: Theme.white(0.08)
                    }
                    Pressable {
                        visible: !modelData.sep
                        anchors.fill: parent
                        radius: 8; kind: "hov"
                        enabled: modelData.enabled !== false
                        opacity: enabled ? 1 : 0.4
                        accessibleName: modelData.label || ""
                        onClicked: root.chosen(modelData.key)
                        QIcon {
                            x: 10
                            anchors.verticalCenter: parent.verticalCenter
                            visible: !!modelData.glyph
                            path: modelData.glyph ? Icons[modelData.glyph] : ""
                            size: 15; strokeWidth: 1.9
                            color: Theme.textMuted
                        }
                        Text {
                            x: 34
                            anchors.verticalCenter: parent.verticalCenter
                            text: modelData.label || ""
                            font.family: Theme.fontUi; font.pixelSize: 13
                            color: Theme.text2
                        }
                        Text {
                            anchors { right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter }
                            text: modelData.hint || ""
                            font.family: Theme.fontMono; font.pointSize: Theme.pt(10.5)
                            color: Theme.textFaint
                        }
                    }
                }
            }
        }
    }
}
