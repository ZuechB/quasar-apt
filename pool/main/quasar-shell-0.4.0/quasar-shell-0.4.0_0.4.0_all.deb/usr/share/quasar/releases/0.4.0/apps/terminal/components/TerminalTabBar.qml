import QtQuick
import Quasar

// The Terminal's tabs, in the window's title bar: a chip per tab (title, an activity dot for output
// or a bell in a background tab, a close button), then "+" for a new tab. With one tab it reads like
// the template's plain title. Chips share the width between 120 and 220 px; beyond that the strip
// scrolls. Drag a chip to reorder, middle-click to close. Empty parts of the strip still drag the
// window (the title bar underneath handles those presses).
// Pure view over the window's tab model (roles: title, activity).
Item {
    id: root
    property var model: null               // ListModel: title (string), activity (0 none, 1 output, 2 bell)
    property int current: 0
    property bool active: true             // window focused: brighter titles
    property color accent: Theme.accent
    signal selected(int index)
    signal closeClicked(int index)
    signal newTabClicked()
    signal moved(int from, int to)

    readonly property int count: model ? model.count : 0
    readonly property bool single: count <= 1
    readonly property real gap: 4
    readonly property real plusW: 34
    readonly property real avail: Math.max(0, width - plusW - 6)
    readonly property real tabW: Math.max(120, Math.min(220, (avail - gap * Math.max(0, count - 1)) / Math.max(1, count)))

    function reveal() {
        if (single) return
        const x = current * (tabW + gap)
        if (x < strip.contentX) strip.contentX = x
        else if (x + tabW > strip.contentX + strip.width) strip.contentX = x + tabW - strip.width
    }
    onCurrentChanged: Qt.callLater(reveal)
    onCountChanged: Qt.callLater(reveal)

    Flickable {
        id: strip
        anchors.verticalCenter: parent.verticalCenter
        height: 30
        width: Math.min(row.width, root.avail)
        contentWidth: row.width
        contentHeight: height
        clip: row.width > root.avail
        interactive: row.width > root.avail
        boundsBehavior: Flickable.StopAtBounds
        flickableDirection: Flickable.HorizontalFlick

        Row {
            id: row
            spacing: root.gap
            move: Transition { NumberAnimation { properties: "x"; duration: Motion.dur(180); easing.type: Easing.OutCubic } }

            Repeater {
                model: root.model
                delegate: Item {
                    id: chip
                    required property int index
                    required property string title
                    required property int activity
                    readonly property bool isCurrent: index === root.current
                    readonly property bool showClose: !root.single && (isCurrent || hover.containsMouse)
                    readonly property bool showDot: activity > 0 && !isCurrent
                    width: root.single ? Math.min(root.avail, label.implicitWidth + 12) : root.tabW
                    height: 30
                    Accessible.role: Accessible.PageTab
                    Accessible.name: title
                    Accessible.selected: isCurrent

                    Rectangle {
                        anchors.fill: parent
                        radius: 9
                        visible: !root.single
                        color: chip.isCurrent ? Theme.white(0.09) : hover.containsMouse ? Theme.white(0.05) : "transparent"
                        border.width: chip.isCurrent ? 1 : 0
                        border.color: Theme.white(0.08)
                        Behavior on color { ColorAnimation { duration: Motion.dur(Motion.hover) } }
                    }
                    Rectangle {
                        visible: chip.showDot
                        x: 10
                        anchors.verticalCenter: parent.verticalCenter
                        width: 6; height: 6; radius: 3
                        color: chip.activity === 2 ? Theme.amber : root.accent
                    }
                    Text {
                        id: label
                        x: root.single ? 2 : chip.showDot ? 22 : 12
                        anchors.verticalCenter: parent.verticalCenter
                        width: root.single ? Math.min(implicitWidth, root.avail - 12)
                                           : chip.width - x - (chip.showClose ? 30 : 10)
                        text: chip.title
                        elide: Text.ElideRight
                        textFormat: Text.PlainText
                        font.family: Theme.fontUi
                        font.pixelSize: 13
                        font.weight: chip.isCurrent ? Font.DemiBold : Font.Medium
                        color: chip.isCurrent ? (root.active ? Theme.text : Theme.textDim) : Theme.textMuted
                        Behavior on color { ColorAnimation { duration: Motion.dur(300) } }
                    }

                    // Select on press, drag to reorder, middle-click to close. Disabled with a single
                    // tab, so the title area drags and double-click-maximizes the window as usual.
                    MouseArea {
                        id: hover
                        anchors.fill: parent
                        enabled: !root.single
                        hoverEnabled: true
                        acceptedButtons: Qt.LeftButton | Qt.MiddleButton
                        property real pressX: 0
                        property bool dragging: false
                        onPressed: (m) => {
                            pressX = m.x
                            dragging = false
                            if (m.button === Qt.LeftButton) root.selected(chip.index)
                        }
                        onPositionChanged: (m) => {
                            if (!pressed || !(m.buttons & Qt.LeftButton)) return
                            if (!dragging && Math.abs(m.x - pressX) > 8) dragging = true
                            if (!dragging) return
                            const px = mapToItem(row, m.x, 0).x
                            const slot = Math.max(0, Math.min(root.count - 1, Math.floor(px / (root.tabW + root.gap))))
                            if (slot !== chip.index) root.moved(chip.index, slot)
                        }
                        onReleased: dragging = false
                        onClicked: (m) => { if (m.button === Qt.MiddleButton) root.closeClicked(chip.index) }
                    }
                    Pressable {
                        visible: chip.showClose
                        anchors { right: parent.right; rightMargin: 5; verticalCenter: parent.verticalCenter }
                        width: 22; height: 22; radius: 6; kind: "hov"
                        accessibleName: "Close tab"
                        onClicked: root.closeClicked(chip.index)
                        QIcon { anchors.centerIn: parent; path: Icons.x; size: 12; strokeWidth: 2.2; color: Theme.textMuted }
                    }
                }
            }
        }
    }

    Pressable {
        id: plus
        x: strip.width + 4
        anchors.verticalCenter: parent.verticalCenter
        width: root.plusW; height: 30; radius: 8; kind: "hov"
        accessibleName: "New tab"
        onClicked: root.newTabClicked()
        QIcon { anchors.centerIn: parent; path: Icons.plus; size: 15; strokeWidth: 2; color: Theme.text3 }
    }
}
