.pragma library

// Store search and browsing over the whole catalog (all of Flathub: ~3,400 entries). Results are lists
// of ids, so the views never copy entries. Search keys are made once per entry, on the first search.

function _keys(a) {
    if (a._n === undefined) {
        a._n = String(a.name || "").toLowerCase()
        a._h = a._n + " " + String(a.dev || "").toLowerCase() + " " + a.id.toLowerCase() + " "
             + String(a.blurb || "").toLowerCase() + " " + String(a.keywords || "").toLowerCase()
    }
}

function _byName(x, y) { return x._n < y._n ? -1 : x._n > y._n ? 1 : 0 }

// Every word must appear in the name, developer, id, summary or keywords. Order: exact name, name
// starting with the query, a word of the name starting with it, every word in the name, the rest;
// within each, Quasar's picks, then verified developers, then the most installed.
function run(apps, query, limit) {
    const words = String(query || "").toLowerCase().split(/\s+/).filter(w => w !== "")
    if (!words.length) return []
    const phrase = words.join(" ")
    const hits = []
    for (let i = 0; i < apps.length; i++) {
        const a = apps[i]
        if (a.online || a.fromFile) continue          // a package opened from a file isn't a Store app
        _keys(a)
        let ok = true
        for (let w = 0; w < words.length; w++) if (a._h.indexOf(words[w]) < 0) { ok = false; break }
        if (!ok) continue
        const n = a._n
        let inName = true
        for (let w = 0; w < words.length; w++) if (n.indexOf(words[w]) < 0) { inName = false; break }
        const tier = n === phrase ? 0 : n.startsWith(phrase) ? 1
                   : inName && (" " + n).indexOf(" " + words[0]) >= 0 ? 2 : inName ? 3 : 4
        hits.push({ a: a, t: tier, i: i })
    }
    hits.sort((x, y) => x.t - y.t || (y.a.pick ? 1 : 0) - (x.a.pick ? 1 : 0) || (y.a.verified ? 1 : 0) - (x.a.verified ? 1 : 0)
                         || (y.a.rank || 0) - (x.a.rank || 0) || x.i - y.i)
    const out = []
    for (let k = 0; k < hits.length && k < (limit || 600); k++) out.push(hits[k].a.id)
    return out
}

// One category, optionally one chip, in an order: "rec" (the catalog's: picks first, then the most
// installed), "name" or "updated" (newest release first).
function category(apps, cat, chip, sort) {
    let list = []
    for (let i = 0; i < apps.length; i++) {
        const a = apps[i]
        if (a.cat !== cat || a.online) continue
        if (chip && (a.tags || []).indexOf(chip) < 0) continue
        list.push(a)
    }
    if (sort === "name") {
        for (const a of list) _keys(a)
        list.sort(_byName)
    } else if (sort === "updated") {
        list.sort((x, y) => (y.updated || 0) - (x.updated || 0))
    }
    return list.map(a => a.id)
}

// How many apps each chip of a category has (for its label), and the category's total.
function counts(apps, cat) {
    const out = { "": 0 }
    for (let i = 0; i < apps.length; i++) {
        const a = apps[i]
        if (a.cat !== cat || a.online) continue
        out[""]++
        for (const t of (a.tags || [])) out[t] = (out[t] || 0) + 1
    }
    return out
}
