import QtQuick
import Quasar
import "runtime.js" as RT

// Template Sites sidebar: 232px, accent "New site" button, SITES label, one row per site (glowing
// status dot, name, address), "No sites yet.", and the "Proxy and HTTPS" footer that opens the
// server page.
Item {
    id: root
    property var sites: []
    property string selectedId: ""
    property bool highlightNew: false
    property bool active: false
    property string proxyState: "inactive"
    property bool serverOpen: false
    signal openNew()
    signal select(string id)
    signal openServer()

    implicitWidth: 232

    function toneColor(t) {
        return t === "mint" ? Theme.mint : t === "amber" ? Theme.amber : t === "danger" ? Theme.danger
             : t === "accent" ? Theme.accent : Theme.textDim
    }

    Rectangle {
        anchors { top: parent.top; bottom: parent.bottom; right: parent.right }
        width: 1; color: Theme.white(0.05)
    }

    Column {
        id: top
        anchors { left: parent.left; right: parent.right; top: parent.top; margins: 10; topMargin: 12; rightMargin: 11 }
        spacing: 2

        Button {
            width: parent.width
            size: 40
            variant: "primary"
            text: "New site"
            glyph: Icons.plus
            enabled: root.active
            onClicked: root.openNew()
        }
        Item { width: 1; height: 10 }
        SectionLabel {
            text: "Sites"
            leftPadding: 10; topPadding: 8; bottomPadding: 6
        }
    }

    ListView {
        id: list
        anchors { left: parent.left; right: parent.right; top: top.bottom; bottom: footer.top; leftMargin: 10; rightMargin: 11 }
        clip: true
        spacing: 2
        boundsBehavior: Flickable.StopAtBounds
        model: root.sites
        delegate: Pressable {
            id: row
            required property var modelData
            readonly property var info: RT.status(modelData)
            readonly property bool current: !root.highlightNew && !root.serverOpen && modelData.id === root.selectedId
            readonly property color dot: root.toneColor(info.tone)
            width: list.width
            implicitHeight: 48
            kind: "hov"
            radius: 11
            color: current ? Theme.white(0.07) : "transparent"
            borderColor: current ? Theme.alpha(Theme.accent, 0.35) : "transparent"
            hoverBorderColor: borderColor
            accessibleName: modelData.name + ", " + info.label + ", " + modelData.hostname
            onClicked: root.select(modelData.id)

            Rectangle {
                id: dotR
                x: 10
                anchors.verticalCenter: parent.verticalCenter
                width: 9; height: 9; radius: 4.5
                color: row.dot
                Rectangle {
                    anchors.centerIn: parent
                    z: -1
                    width: 19; height: 19; radius: 9.5
                    color: Theme.alpha(row.dot, 0.16)
                    visible: row.info.live && Theme.profile > 0
                }
                SequentialAnimation on opacity {
                    running: row.info.live && Theme.ambientMotion && row.visible
                    loops: Animation.Infinite
                    alwaysRunToEnd: true
                    NumberAnimation { from: 1; to: 0.55; duration: 1100; easing.type: Easing.InOutSine }
                    NumberAnimation { from: 0.55; to: 1; duration: 1100; easing.type: Easing.InOutSine }
                }
            }
            Column {
                anchors { left: dotR.right; leftMargin: 10; right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter }
                spacing: 2
                Text {
                    width: parent.width
                    text: row.modelData.name
                    textFormat: Text.PlainText
                    elide: Text.ElideRight
                    font.family: Theme.fontUi; font.pixelSize: 13; font.weight: Font.DemiBold
                    color: Theme.text
                }
                Text {
                    width: parent.width
                    text: row.modelData.hostname
                    textFormat: Text.PlainText
                    elide: Text.ElideRight
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(11.5)
                    color: Theme.textFaint
                }
            }
        }
        footer: Text {
            visible: root.sites.length === 0
            height: visible ? implicitHeight + 4 : 0
            leftPadding: 10; topPadding: 2
            text: "No sites yet."
            font.family: Theme.fontUi; font.pixelSize: 12
            color: Theme.textFaint
        }
    }

    Pressable {
        id: footer
        anchors { left: parent.left; right: parent.right; bottom: parent.bottom; leftMargin: 6; rightMargin: 7; bottomMargin: 8 }
        implicitHeight: footCol.implicitHeight + 20
        kind: "hov"
        radius: 12
        color: root.serverOpen ? Theme.white(0.06) : "transparent"
        accessibleName: "Proxy and HTTPS, " + footState.text
        onClicked: root.openServer()

        Column {
            id: footCol
            anchors { left: parent.left; right: parent.right; top: parent.top; margins: 10; leftMargin: 14 }
            spacing: 5
            Row {
                spacing: 8
                QIcon { anchors.verticalCenter: parent.verticalCenter; path: Icons.shield; size: 14; color: Theme.mint }
                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: "Proxy and HTTPS"
                    font.family: Theme.fontUi; font.pixelSize: 12
                    color: Theme.text3
                }
            }
            Text {
                width: parent.width
                text: root.active ? "Caddy on ports 80 and 443. This PC trusts Quasar’s local certificates."
                                  : "Off. Nothing on this PC answers web requests."
                wrapMode: Text.WordWrap
                font.family: Theme.fontUi; font.pointSize: Theme.pt(11.5)
                lineHeight: 1.1
                color: Theme.textFaint
            }
            Row {
                spacing: 6
                readonly property color tone: !root.active ? Theme.textDim : root.proxyState === "active" ? Theme.mint
                                            : root.proxyState === "failed" ? Theme.danger : Theme.amber
                Rectangle { anchors.verticalCenter: parent.verticalCenter; width: 6; height: 6; radius: 3; color: parent.tone }
                Text {
                    id: footState
                    anchors.verticalCenter: parent.verticalCenter
                    text: !root.active ? "Turned off" : root.proxyState === "active" ? "Running"
                        : root.proxyState === "failed" ? "Stopped with an error" : "Starting"
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(11.5)
                    color: parent.tone
                }
            }
        }
    }
}
