#version 440
// "Graphite" wallpaper: dot grid (26px) + vignette. Static.
layout(location = 0) in vec2 qt_TexCoord0;
layout(location = 0) out vec4 fragColor;

layout(std140, binding = 0) uniform buf {
    mat4 qt_Matrix;
    float qt_Opacity;
    vec2 itemSize;
    vec2 screenSize;
    vec2 offset;
    vec4 accent;
    float time;
    float stars;
    float detail;
    float cornerRadius; // >0: mask to a rounded rect (glass backdrop)
};

float roundedMask(vec2 local, vec2 size, float r) {
    if (r <= 0.0) return 1.0;
    vec2 q = abs(local - 0.5 * size) - (0.5 * size - vec2(r));
    float d = length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;
    return clamp(0.5 - d, 0.0, 1.0);
}

void main() {
    vec2 px = qt_TexCoord0 * itemSize + offset;
    vec2 S = screenSize;
    vec3 col = vec3(0.0392, 0.0431, 0.0627);           // #0A0B10
    if (detail > 0.5) {
        vec2 g = mod(px, 26.0) - 13.0;                 // dot at each tile center
        float d = length(g);
        col = mix(col, vec3(1.0), 0.08 * clamp(1.2 - d, 0.0, 1.0));
    }
    // vignette: radial-gradient(ellipse at 50% 40%, transparent 30%, rgba(0,0,0,.65))
    vec2 q = (px - vec2(0.5, 0.4) * S) / (0.5 * S * 1.4142);
    float v = smoothstep(0.30, 1.0, length(q));
    col = mix(col, vec3(0.0), 0.65 * v);
    fragColor = vec4(col, 1.0) * roundedMask(qt_TexCoord0 * itemSize, itemSize, cornerRadius) * qt_Opacity;
}
