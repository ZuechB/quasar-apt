.pragma library
// Settings › Command Deck: hero and rows from the service's state (pure: the preview feeds it mock state).
//   st = { cfg: Settings.commandDeck, status: deckd's status | null, connected: bool (to deckd),
//          busy: "" | "enable" | "home" | "remove…", now: ms }
// Row keys: cd:screen · cd:files · cd:home · cd:rm:<id> · cd:disconnect · cd:removeAll · cd:unregister

function cfg(c) {
    var x = c || {}
    return { enabled: x.enabled === true, screen: x.screen !== false, files: x.files !== false }
}

// "just now", "5 minutes ago", "3 hours ago", "yesterday", "4 days ago", "on 12 Mar"
function ago(ts, now) {
    if (!ts) return ""
    var s = Math.max(0, (now - ts * 1000) / 1000)
    if (s < 90) return "just now"
    if (s < 3600) return Math.round(s / 60) + " minutes ago"
    if (s < 86400) { var h = Math.round(s / 3600); return h === 1 ? "an hour ago" : h + " hours ago" }
    var d = Math.round(s / 86400)
    if (d === 1) return "yesterday"
    if (d < 14) return d + " days ago"
    var dt = new Date(ts * 1000)
    return "on " + dt.getDate() + " " + ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"][dt.getMonth()]
}

// Can a phone connect right now? Then Settings shows the code.
function ready(st) {
    var s = st.status
    return cfg(st.cfg).enabled && !!st.connected && !!s && s.listening && !s.problem && !!s.url
}

function hero(st, ctx) {
    var c = cfg(st.cfg), s = st.status, t = ctx.theme
    var green = { fill: t.alpha(t.mint, 0.06), line: t.alpha(t.mint, 0.18), glow: "transparent" }
    var amber = { fill: t.alpha(t.amber, 0.06), line: t.alpha(t.amber, 0.2), glow: "transparent" }
    function card(base, extra) {
        var o = { glyph: ctx.icons.phone, iconBg: t.accent, iconFg: t.accentInk }
        for (var k in base) o[k] = base[k]
        for (var e in extra) o[e] = extra[e]
        return o
    }
    if (!c.enabled)
        return card({ iconBg: t.white(0.07), iconFg: t.text3 }, {
            title: "Use your phone as a remote",
            sub: "Open apps, see what's running, control the screen and send photos to this PC from your phone's browser. Only on your home network.",
            button: st.busy === "enable" ? "" : "Turn on", buttonPrimary: true, toggle: undefined, busy: st.busy === "enable" })
    var on = { toggle: true, checked: true, busy: st.busy === "disable" }
    if (!st.connected || !s)
        return card({}, Object.assign({ title: "Starting Command Deck…", sub: "This takes a moment." }, on))
    var p = s.problem
    if (p && p.code === "not-enabled")
        return card(amber, Object.assign({ title: "Finish turning it on",
                                           sub: "An administrator confirms it once: it lets phones on your home network reach this PC.",
                                           button: st.busy === "enable" ? "" : "Continue", buttonPrimary: true }, on))
    if (p && p.code === "not-home") {
        var net = s.network || {}
        return card(amber, Object.assign({ title: "Not on a home network",
                                           sub: net.name ? "Phones can only connect on a network you trust. Is " + net.name + " your home network?"
                                                         : "Connect to your home Wi-Fi or network cable, and phones can connect.",
                                           button: net.name && net.uuid && st.busy !== "home" ? "This is my home network" : "", buttonPrimary: true }, on))
    }
    if (p)
        return card(amber, Object.assign({ title: "Command Deck can't start", sub: p.message || "" }, on))
    if (!s.listening)
        return card(amber, Object.assign({ title: "Getting ready…", sub: "This takes a moment." }, on))
    var n = (s.devices || []).length, live = (s.screen || []).length, conn = (s.connected || []).length
    return card(green, Object.assign({
        title: live ? (live === 1 ? "A phone sees your screen" : live + " phones see your screen")
                    : conn ? (conn === 1 ? "A phone is connected" : conn + " phones are connected") : "Ready on " + ((s.network || {}).name || "your home network"),
        sub: live ? "It can see and control this PC's screen until you stop it or it leaves."
             : !conn && s.vm ? "This PC is a virtual machine: phones reach it only if its network adapter is bridged to your home network (Hyper-V: an External switch)."
             : n ? "Scan the code with another phone to add it, or open Command Deck on a phone you already paired."
               : "Point your phone's camera at the code below. Nothing is shared outside your home network.",
        button: live ? "Stop sharing" : "" }, on))
}

function deviceSub(d, s, now) {
    var conn = (s.connected || []).indexOf(d.id) >= 0, live = (s.screen || []).indexOf(d.id) >= 0
    if (live) return "Connected · sees the screen"
    if (conn) return "Connected now"
    return "Last used " + ago(d.lastSeen, now)
}

function groups(st, ctx) {
    var c = cfg(st.cfg), s = st.status, icons = ctx.icons, t = ctx.theme
    if (!c.enabled)
        return [{ label: "How it works", rows: [
            { key: "cd:how1", label: "Scan once, then it's there", sub: "Point the phone's camera at the code in Settings. Add it to the home screen like an app.", glyph: icons.phone },
            { key: "cd:how2", label: "Only on your home network", sub: "Phones elsewhere, and other people's networks, can't reach it.", glyph: icons.home || icons.wifi },
            { key: "cd:how3", label: "You always see it", sub: "A phone icon on the taskbar while a phone is connected, and a dot while it sees your screen.", glyph: icons.eye || icons.monitor }] }]
    if (!s) return []
    var devices = s.devices || []
    var rows = devices.map(function (d) {
        return { key: "cd:rm:" + d.id, label: d.name, sub: deviceSub(d, s, st.now || Date.now()), glyph: icons.phone,
                 trailing: "button", value: st.busy === "rm:" + d.id ? "…" : "Remove" }
    })
    if (!rows.length)
        rows.push({ key: "cd:none", label: "No phones yet", sub: ready(st) ? "Scan the code above with your phone's camera." : "Once Command Deck is ready, scan its code with your phone.", glyph: icons.phone })
    var out = [{ label: "Phones", rows: rows }]
    out.push({ label: "What phones can do", rows: [
        { key: "cd:screen", label: "See and control the screen", sub: s.engine === false ? "Not available on this PC" : "Also use the phone as a touchpad and keyboard",
          glyph: icons.monitor, trailing: s.engine === false ? "value" : "toggle", checked: c.screen, value: "—" },
        { key: "cd:files", label: "Send files to this PC", sub: "Photos and files land in Downloads", glyph: icons.download, trailing: "toggle", checked: c.files },
        { key: "cd:apps", label: "Open apps, see what's running, media and power", sub: "Always on for paired phones. Locked PC: only media, volume and power.", glyph: icons.grid }] })
    var net = s.network || {}
    out.push({ label: "Network", rows: [
        { key: "cd:home", label: net.name || "Not connected",
          sub: net.home ? "Home network: your phones can connect here" : net.name ? "Not a home network: phones can't connect here" : "Connect to your home network",
          glyph: icons.wifi, trailing: net.home ? "value" : net.name && net.uuid ? "button" : "none",
          value: net.home ? "Home" : (st.busy === "home" ? "…" : "This is my home network"), valueColor: net.home ? t.mint : t.textMuted }] })
    if (s.vm)       // a VM behind its host's NAT (Hyper-V's Default Switch, QEMU's user network) can't be reached
        out[out.length - 1].rows.push({ key: "cd:vm", label: "This PC is a virtual machine",
            sub: "Phones can reach it only if its network adapter is bridged to your home network (Hyper-V: an External virtual switch; VirtualBox: Bridged Adapter).",
            glyph: icons.alert })
    var adv = []
    if (s.url) adv.push({ key: "cd:address", label: "Address", sub: "Type it into a phone's browser if the camera can't read the code", trailing: "value", value: s.url })
    if ((s.connected || []).length) adv.push({ key: "cd:disconnect", label: "Disconnect phones", sub: "They can connect again from their side", trailing: "button", value: "Disconnect" })
    if (devices.length) adv.push({ key: "cd:removeAll", label: "Remove all phones", sub: "Each one has to scan the code again", trailing: "button", value: "Remove all" })
    adv.push({ key: "cd:unregister", label: "Take away Command Deck's access", sub: "Closes its way in through the firewall (an administrator confirms)", trailing: "button", value: st.busy === "unregister" ? "…" : "Take away" })
    out.push({ label: "Advanced", rows: adv })
    return out
}
