//@ pragma AppId quasar-services
// Quasar Services — what runs in the background, and the game and app servers you host (native Qt Quick
// app run by Quickshell, launched by /usr/bin/quasar-services). The engine is linux/system/services
// (each server runs as its own account, from the folder you picked); the protocol is its PROTOCOL.md:
//   reads    /usr/libexec/quasar/services-query          (this account, no password)
//   routine  pkexec /usr/libexec/quasar/quasar-services  (no password for administrators at the PC)
//   big      pkexec /usr/libexec/quasar/quasar-services-admin (password every time)
// Sites' rows use Sites' own helpers (sites-query, quasar-sites). Tests swap the helpers with
// QUASAR_SERVICES_QUERY / _HELPER / _ADMIN and QUASAR_SITES_QUERY / _HELPER
// (tools/fake-services-backend.sh). Deep links: quasar-services [add|every|svc/<id>|site/<id>|log|log/<key>]
import QtQuick
import Quickshell
import Quickshell.Io
import Quasar
import Quasar.Services
import "components"
import "services"
import "components/services.js" as S

ShellRoot {
    id: app

    Binding { target: Theme; property: "accent"; value: Settings.accent }
    Binding { target: Theme; property: "reduceMotion"; value: Settings.reduceMotion }
    Binding { target: Theme; property: "softwareRender"; value: Platform.softwareScene }
    Binding { target: Theme; property: "profile"; value: Platform.softwareRender ? 0 : (Settings.profile >= 0 ? Settings.profile : 1) }

    // ---- helpers -----------------------------------------------------------------------------------
    readonly property string queryExe: Quickshell.env("QUASAR_SERVICES_QUERY") || "/usr/libexec/quasar/services-query"
    readonly property string routineExe: Quickshell.env("QUASAR_SERVICES_HELPER") || ""
    readonly property string adminExe: Quickshell.env("QUASAR_SERVICES_ADMIN") || ""
    readonly property string sitesQueryExe: Quickshell.env("QUASAR_SITES_QUERY") || "/usr/libexec/quasar/sites-query"
    readonly property string sitesExe: Quickshell.env("QUASAR_SITES_HELPER") || ""
    readonly property string fileop: Quickshell.env("QUASAR_FILEOP") || "/usr/libexec/quasar/fileop"
    function q(args) { return [queryExe].concat(args) }
    function routine(args) { return (routineExe ? [routineExe] : ["pkexec", "/usr/libexec/quasar/quasar-services"]).concat(args) }
    function admin(args) { return (adminExe ? [adminExe] : ["pkexec", "/usr/libexec/quasar/quasar-services-admin"]).concat(args) }
    function sites(args) { return (sitesExe ? [sitesExe] : ["pkexec", "/usr/libexec/quasar/quasar-sites"]).concat(args) }
    function notify(title, body) { Quickshell.execDetached(["notify-send", "-a", "Services", "-i", "system-run", title, body || ""]) }
    readonly property string home: Quickshell.env("HOME") || ""

    // ---- state ---------------------------------------------------------------------------------------
    property var st: ({ items: [], lan: null, firewall: { on: true }, netguard: false, live: false })
    property bool loaded: false
    property string filter: "all"
    property string query: ""
    property string selectedKey: ""
    property bool adding: false
    property bool editing: false
    property var draft: null
    property bool inspecting: false
    property string inspectError: ""
    property bool saving: false
    property var formError: null
    property bool busy: false
    property var error: null               // { key, code, message, details }
    property var confirm: null             // { key, what: "remove" | "update" }
    property var updating: ({})            // key -> true: stopped for an update (banner)
    property var copy: null                // { key, running, percent, error }
    property var logs: []                  // the shown service's newest lines: [{ n, t (unix s), m, lvl, src?, unit? }]
    property int logSeq: 0
    // Every service on this PC (services-query units -f): raw rows by key, the selected one, the last full list.
    property var unitRows: ({})
    property string unitSelKey: ""
    property var unitsFull: null
    property string unitsError: ""
    property var stats: null
    property var players: null
    property bool guide: false
    property var dns: ({ checking: false, result: null })
    property real now: Date.now()

    readonly property var items: st.items || []
    readonly property var sel: S.selected(items, selectedKey)
    readonly property string selKey: sel ? sel.key : ""

    readonly property var model: ({
        items: items, now: now, filter: filter, query: query, selectedKey: selKey, loaded: loaded,
        live: !!st.live, lan: st.lan || null, firewall: st.firewall || { on: true }, netguard: !!st.netguard,
        adding: adding, editing: editing, draft: draft, inspecting: inspecting, inspectError: inspectError,
        saving: saving, formError: formError, busy: busy, error: error, confirm: confirm, updating: updating,
        copy: copy, logs: logs, stats: stats, players: players, guide: guide, dns: dns, home: home,
        drives: "/media/" + (Quickshell.env("USER") || ""),
        company: Companies.inCompany ? Companies.current : null,
        unitSelKey: unitSelKey, unitsFull: unitsFull, unitsError: unitsError
    })
    // Another service is shown: its own logs, numbers and checks.
    onSelKeyChanged: { players = null; stats = null; dns = { checking: false, result: null } }

    // ---- state: driven by systemd's signals (services-query watch), polled only if that isn't there ---
    property bool watchDown: false
    Stream {
        id: watchStream
        active: true
        cmd: app.q(["watch"])
        onEvent: (ev) => { if (ev.type === "state" || ev.type === "result") app.apply(ev) }
        onEnded: (code) => { app.watchDown = true; if (!app.loaded) app.refresh() }
    }
    // The main window can be hidden while console windows are open (they need fresh states and times too).
    readonly property bool anyWindow: win.visible || consoles.count > 0
    Timer {
        interval: 5000
        repeat: true
        running: app.watchDown && app.anyWindow
        triggeredOnStart: true
        onTriggered: app.refresh()
    }
    Timer {                                  // "Up 2h 5m", "last just now"
        interval: 5000
        repeat: true
        running: app.anyWindow
        onTriggered: app.now = Date.now()
    }
    Job {
        id: stateJob
        onDone: (ok, res) => { if (ok && res) app.apply(res); else app.loaded = true }
    }
    function refresh() { if (!stateJob.running) stateJob.start(q(["state"])) }
    function apply(res) {
        st = res
        loaded = true
        now = Date.now()
        // A server that runs again is no longer "stopped for an update".
        const up = Object.assign({}, updating)
        let changed = false
        for (const k in up) {
            const it = (res.items || []).find(x => x.key === k)
            if (!it || it.status === "running" || it.status === "starting") { delete up[k]; changed = true }
        }
        if (changed) updating = up
    }

    // ---- the selected service's logs, stats and players -------------------------------------------------
    readonly property bool everyShown: win.visible && filter === "pc" && !adding && !editing
    readonly property bool detailShown: win.visible && !adding && !editing && (filter === "pc" ? unitSelKey !== "" : !!sel)
    // The key whose newest lines the detail pane shows: the selected row, or in "Every service" the selected
    // unit (Quasar's own under their own keys, so a server still gets its players count).
    readonly property string logKey: {
        if (filter !== "pc") return selKey
        const r = unitRows[unitSelKey]
        const row = r ? S.everyRow(r, items) : null
        return row ? row.console : unitSelKey
    }
    onLogKeyChanged: logs = []
    function logCmd(key) {
        if (!key) return []
        if (key.indexOf("svc:") === 0) return q(["logs", key.slice(4), "-f"])          // + players
        if (key.indexOf("site:") === 0) return [sitesQueryExe, "logs", key.slice(5), "-f"]  // + requests
        return q(["journal", key, "-n", "200", "-f"])
    }
    Stream {
        id: logStream
        active: app.detailShown && !app.guide
        cmd: app.logCmd(app.logKey)
        onEvent: (ev) => {
            if (ev.type === "lines" || ev.type === "log") app.pushLines(S.linesOf(ev))
            else if (ev.type === "players") app.players = { now: ev.now || 0, max: ev.max || 0 }
        }
    }
    // One array change per batch: the model (and every binding on it) changes at most ~10 times a second.
    function pushLines(lines) {
        if (!lines || !lines.length) return
        const add = lines.slice(Math.max(0, lines.length - 200)).map(l => Object.assign({ n: ++logSeq }, l))
        const next = logs.concat(add)
        logs = next.length > 200 ? next.slice(next.length - 200) : next
    }

    // ---- every service on this PC (services-query units -f) ---------------------------------------------
    // Runs while that list shows, or while a console window is open (their titles and states).
    Stream {
        id: unitsStream
        active: app.everyShown || consoles.count > 0
        stdinEnabled: true
        cmd: app.q(["units", "-f"])
        onEvent: (ev) => {
            if (ev.type === "units") app.applyUnits(ev)
            else if (ev.type === "error") app.unitsError = ev.message || "Services couldn't list this PC's services."
        }
        onEnded: (code) => { if (code !== 0 && app.unitsError === "") app.unitsError = "Listing this PC's services stopped (code " + code + ")." }
    }
    onEveryShownChanged: if (everyShown && unitsError !== "") { unitsError = ""; unitsStream.restart() }
    function applyUnits(ev) {
        const rows = ev.full ? {} : Object.assign({}, unitRows)
        for (const k of ev.gone || []) delete rows[k]
        for (const r of ev.rows || []) rows[r.key] = r
        unitRows = rows
        unitsError = ""
        // For a list made later (the view is a Loader): the current list as one full event.
        unitsFull = { type: "units", full: true, rows: Object.keys(rows).map(k => rows[k]) }
        if (servicesView) servicesView.unitsEvent(ev)
    }
    // Names for the combined console's service column: Quasar's own rows' names, then systemd's descriptions.
    readonly property var unitNames: {
        const o = {}
        for (const k in unitRows) { const r = unitRows[k]; if (r.unit && r.name) o[r.unit] = r.name }
        for (const it of items) {
            if (!it.unit) continue
            o[it.unit] = it.name
            if (it.source === "server") o["quasar-svc-folder@" + it.id + ".service"] = it.name + " (its folder)"
        }
        return o
    }

    // ---- console windows: one per key ("*" = every service) ---------------------------------------------
    ListModel { id: consoles }
    function consoleIndex(key) {
        for (let i = 0; i < consoles.count; i++) if (consoles.get(i).ckey === key) return i
        return -1
    }
    function openConsole(key) {
        if (!key) return
        const i = consoleIndex(key)
        if (i >= 0) {
            // Already open: show it again (labwc focuses a window that's shown anew); its lines stay.
            const w = consoleInst.objectAt(i)
            if (w) { w.visible = false; w.visible = true }
            return
        }
        consoles.append({ ckey: key })
    }
    function closeConsole(key) {
        const i = consoleIndex(key)
        if (i >= 0) consoles.remove(i)
        if (consoles.count === 0 && !win.visible) Qt.quit()
    }
    // The row a console shows in its header: Services' own, or one of "Every service" (systemd's words only).
    function consoleItem(key) {
        if (!key || key === "*") return null
        const it = items.find(x => x.key === key)
        if (it) return it
        const r = unitRows[key]
        return r ? Object.assign({ source: "unit", actions: [] }, r) : null
    }
    function consoleCmd(key) {
        if (key === "*") return q(["journal", "--all", "-f"])
        if (key.indexOf("site:") === 0) return [sitesQueryExe, "logs", key.slice(5), "-f"]
        return q(["journal", key, "-f"])
    }
    // A line of the combined console -> its service's own console (Quasar's own under their keys).
    function consoleKeyOfLine(line) {
        const it = items.find(x => x.unit && x.unit === line.unit && !!x.user === !!line.user)
        if (it) return it.key
        return (line.user ? "userservice:" : "service:") + line.unit
    }
    function openTerminal(key) {
        const args = key === "*" ? [] : S.unitArgs(key, consoleItem(key))
        if (key !== "*" && !args.length) return
        Quickshell.execDetached(["quasar-terminal", "-e", "journalctl", "-f", "-n", "200"].concat(args))
    }
    Instantiator {
        id: consoleInst
        model: consoles
        delegate: LogWindow {
            item: app.consoleItem(ckey)
            cmd: app.consoleCmd(ckey)
            unitNames: app.unitNames
            busy: app.busy
            now: app.now
            onCloseWindow: (k) => app.closeConsole(k)
            onAct: (name, key) => app.handle(name, key)
            onOpenTerminal: (k) => app.openTerminal(k)
            onOpenUnit: (line) => app.openConsole(app.consoleKeyOfLine(line))
        }
    }
    Stream {
        id: statsStream
        active: app.detailShown && !!app.sel.server && (app.sel.status === "running" || app.sel.status === "starting")
        cmd: app.sel && app.sel.server ? app.q(["stats", app.sel.id, "-f"]) : []
        onEvent: (ev) => {
            if (ev.type !== "result") return
            const prev = app.stats
            const grew = ev.wan && (!prev || !prev.wan || ev.wan.packets > prev.wan.packets) && ev.wan.packets > 0
            const first = !prev || !prev.wan
            app.stats = Object.assign({}, ev, { wanAt: grew && !first ? Date.now() : (prev ? prev.wanAt || 0 : 0) })
        }
    }

    // ---- actions ---------------------------------------------------------------------------------------
    Job {
        id: action
        property var then: null
        onDone: (ok, res, err) => {
            const next = action.then
            action.then = null
            app.busy = false
            if (next) next(ok, res, err)
            app.refresh()
        }
    }
    function act(cmd, input, then) {
        if (action.running) return false
        busy = true
        action.then = then || null
        action.start(cmd, input)
        return true
    }
    function fail(key, err) {
        if (!err || err.code === "cancelled") { error = null; return }
        error = { key: key, code: err.code || "failed", message: err.message || "That didn’t work.", details: err.details || "" }
    }
    function itemOf(key) { return items.find(x => x.key === key) || null }

    // Start a server. A program that lost its execute permission (zips made on Windows) gets it back from
    // svc-prepare, before every start and when it's added.
    function startServer(it) {
        error = null
        act(routine(["start", it.id]), undefined, (ok, r, e) => {
            if (ok) { const up = Object.assign({}, updating); delete up[it.key]; updating = up }
            else fail(it.key, e)
        })
    }

    // The Add form: what's in the folder (inspect), then the spec to the admin helper.
    Job {
        id: inspectJob
        property string mode: "add"
        onDone: (ok, res, err) => {
            app.inspecting = false
            if (!ok || !res) { app.inspectError = err ? err.message : "Services couldn’t read that folder."; return }
            app.inspectError = ""
            if (inspectJob.mode === "edit" && app.draft) {
                const d = Object.assign({}, app.draft)
                d.path = res.path
                d.kind = res.kind
                d.problems = res.problems || []
                d.notes = res.notes || []
                d.executable = res.executable !== false
                d.flags = res.flags || []
                if (res.exec && !(d.exec || "").trim()) d.exec = res.exec
                app.draft = d
            } else {
                app.draft = S.draftFrom(res)
            }
        }
    }
    function expandHome(p) {
        p = (p || "").trim()
        if (p.startsWith("file://")) { try { p = decodeURIComponent(p.slice(7)) } catch (e) { p = p.slice(7) } }
        if (p === "") return ""
        p = p === "~" ? home : p.startsWith("~/") ? home + p.slice(1) : p.startsWith("/") ? p : home + "/" + p
        while (p.length > 1 && p.endsWith("/")) p = p.slice(0, -1)
        return p
    }
    function inspect(path, mode) {
        path = expandHome(path)
        if (!path) return
        if (draft && draft.path === path && !inspectError) return
        inspecting = true
        inspectError = ""
        inspectJob.mode = mode || "add"
        inspectJob.start(q(["inspect", path]))
    }
    // Settings: the flags the game's scripts read, for the chips. Quietly: no spinner, no error, nothing
    // else from inspect (the form's problems are the stored server's), and only while that form is open.
    Job {
        id: flagsJob
        onDone: (ok, res, err) => {
            if (!ok || !res || !app.editing || !app.draft || !app.draft.original || app.draft.original.key !== flagsJob.meta) return
            const d = Object.assign({}, app.draft)
            d.flags = res.flags || []
            app.draft = d
        }
    }
    Job {
        id: formJob
        property var then: null
        onDone: (ok, res, err) => {
            const t = formJob.then
            formJob.then = null
            if (t) t(ok, res, err)
            else app.saving = false
            app.refresh()
        }
    }
    function addService() {
        if (!draft || S.draftProblem(draft) !== "" || formJob.running) return
        saving = true
        formError = null
        const spec = S.spec(draft)
        formJob.then = (ok, res, err) => {
            saving = false
            if (!ok) { formError = err && err.code !== "cancelled" ? err : null; return }
            adding = false
            draft = null
            const sv = res && res.service
            selectedKey = sv ? sv.key : "svc:" + spec.id
            filter = "all"; query = ""
            notify(spec.name + " added", S.hasInternet(spec.ports) ? "Running. Set up internet play from its page." : "Running in the background now")
        }
        formJob.start(admin(["add"]), JSON.stringify(spec) + "\n")
    }
    function openSettings(it) {
        const s = it.server
        draft = {
            path: s.path, kind: s.engine, name: it.name, id: it.id, exec: s.exec, argsText: S.joinArgs(s.args || []),
            label: s.label || "", facts: s.facts || [], ports: (s.ports || []).map(p => ({ proto: p.proto, port: p.port, label: p.label || "", reach: p.reach })),
            players: s.players || null, manifest: false, executable: true, problems: [], notes: [],
            restart: !s.options || s.options.crashRestart !== false, memoryMax: s.options ? s.options.memoryMax || null : null,
            publicName: s["public"] ? s["public"].name || "" : "", publicVia: s["public"] ? s["public"].via || "" : "",
            flags: [], original: it
        }
        formError = null
        inspectError = ""
        editing = true
        adding = false
        guide = false
        if (s.engine === "unity" && s.path) flagsJob.start(q(["inspect", s.path]), undefined, "", it.key)
    }
    // Save: name, program, arguments and limits through the routine helper; the folder, ports and the
    // public name through the admin helper (it changes what's exposed: the password every time). New
    // ports take their arguments along (a -port that followed them): closing the password prompt then
    // changes neither, so the arguments never name a port the server isn't allowed to open.
    function saveSettings() {
        if (!draft || !draft.original || S.draftProblem(draft) !== "" || formJob.running) return
        const it = draft.original, s = it.server, d = draft
        const sp = S.spec(d)
        const routineSpec = {}
        if (sp.name !== it.name) routineSpec.name = sp.name
        if (sp.exec !== s.exec) routineSpec.exec = sp.exec
        if (JSON.stringify(sp.args) !== JSON.stringify(s.args || [])) routineSpec.args = sp.args
        const opts = s.options || {}
        if ((d.restart !== false) !== (opts.crashRestart !== false) || (d.memoryMax || null) !== (opts.memoryMax || null))
            routineSpec.options = { crashRestart: d.restart !== false, memoryMax: d.memoryMax || null, cpuWeight: opts.cpuWeight || null }
        const adminSpec = {}
        if (sp.path !== s.path) adminSpec.path = sp.path
        const oldPorts = (s.ports || []).map(p => ({ proto: p.proto, port: p.port, label: p.label || "", reach: p.reach }))
        if (JSON.stringify(sp.ports) !== JSON.stringify(oldPorts)) adminSpec.ports = sp.ports
        const oldPub = s["public"] || null
        if (JSON.stringify(sp["public"]) !== JSON.stringify(oldPub && oldPub.name ? { name: oldPub.name, via: oldPub.via || "" } : null)) adminSpec["public"] = sp["public"]
        if (adminSpec.ports && routineSpec.args) { adminSpec.args = routineSpec.args; delete routineSpec.args }
        saving = true
        formError = null
        const done = () => { saving = false; editing = false; draft = null; notify(sp.name + " saved", "") }
        const runAdmin = () => {
            if (Object.keys(adminSpec).length === 0) { done(); return }
            formJob.then = (ok, res, err) => { if (!ok) { saving = false; formError = err && err.code !== "cancelled" ? err : null; return } done() }
            formJob.start(admin(["update", it.id]), JSON.stringify(adminSpec) + "\n")
        }
        if (Object.keys(routineSpec).length === 0) { runAdmin(); return }
        formJob.then = (ok, res, err) => { if (!ok) { saving = false; formError = err && err.code !== "cancelled" ? err : null; return } runAdmin() }
        formJob.start(routine(["set", it.id]), JSON.stringify(routineSpec) + "\n")
    }

    // Update…: copy a new build into the server's folder (the old files to the Trash first), as the owner.
    Cmd {
        id: copyCmd
        property string key: ""
        onLine: (l) => {
            if (l.charAt(0) !== "{") return
            let o
            try { o = JSON.parse(l) } catch (e) { return }
            if (o.progress !== undefined && o.total)
                app.copy = { key: copyCmd.key, running: true, percent: Math.min(99, Math.round(100 * o.progress / o.total)), error: "" }
            else if (o.error) app.copy = Object.assign({}, app.copy, { error: "" + o.error })
        }
        onFinished: (code) => {
            const err = code === 0 ? "" : (app.copy && app.copy.error) || "The new build couldn’t be copied in. The old files are in the Trash."
            app.copy = { key: copyCmd.key, running: false, percent: code === 0 ? 100 : 0, error: err }
            if (code === 0) app.notify("New build copied in", "Press Start to run it")
        }
    }
    function copyIn(key, source, archive) {
        const it = itemOf(key)
        if (!it || !it.server || copyCmd.running) return
        copyCmd.key = key
        copy = { key: key, running: true, percent: 0, error: "" }
        copyCmd.run(S.copyCommand(it.server.path, source, archive, fileop))
    }

    Job {
        id: dnsJob
        onDone: (ok, res, err) => {
            app.dns = { checking: false, result: ok && res ? res : { verdict: "error", message: err ? err.message : "The check didn’t work.", chain: [], addresses: [] } }
        }
    }
    Job { id: readableJob; onDone: (ok, res, err) => app.refresh() }

    function openLink(it) {
        if (!it || !it.link) return
        Quickshell.execDetached(["quasar-" + it.link.app].concat(it.link.arg ? [it.link.arg] : []))
    }

    function handle(name, a, b, c) {
        const it = a && typeof a === "string" ? itemOf(a) : null
        switch (name) {
        case "filter": filter = a; break
        case "query": query = a || ""; break
        case "select":
            selectedKey = a; adding = false; editing = false; confirm = null; guide = false
            if (error && error.key !== a) error = null
            break
        case "toggle":
            if (!it) break
            error = null
            if (it.source === "site") {
                const on = !it.enabled
                act(sites(["set-option", it.id, "boot", on ? "on" : "off"]), undefined, (ok, r, e) => {
                    if (!ok) { fail(it.key, e); return }
                    act(sites([on ? "start" : "stop", it.id]), undefined, (ok2, r2, e2) => { if (!ok2) fail(it.key, e2) })
                })
            } else {
                act(routine([it.enabled ? "disable" : "enable", it.id]), undefined, (ok, r, e) => {
                    if (ok) notify(it.name + (it.enabled ? " turned off" : " turned on"), it.enabled ? "Stopped, and it won’t start on its own" : "Running, and it starts with the PC")
                    else fail(it.key, e)
                })
            }
            break
        case "openAdd": adding = true; editing = false; draft = null; inspectError = ""; formError = null; guide = false; confirm = null; break
        case "closeForm": adding = false; editing = false; draft = null; inspectError = ""; formError = null; break
        case "pick": inspect(a, b); break
        case "pathEdited": inspect(a, b); break
        case "draft": {
            const d = Object.assign({}, draft)
            if (a === "name") d.argsText = S.withName(draft, b)      // -name "…" follows the Name
            d[a] = b
            draft = d
            break
        }
        case "port": {
            const d = Object.assign({}, draft)
            if (b === "port") d.argsText = S.withPort(draft, a, c)   // -port … follows its row
            d.ports = (d.ports || []).map((p, i) => { if (i !== a) return p; const n = Object.assign({}, p); n[b] = c; return n })
            draft = d
            break
        }
        case "addFlag": { const d = Object.assign({}, draft); d.argsText = S.addFlag(draft, a); draft = d; break }
        case "listPort": {
            // The fix under a warning: list the port the arguments name (home network, like the suggestions).
            const d = Object.assign({}, draft)
            if ((d.ports || []).some(p => Number(p.port) === Number(b) && p.proto === a)) break
            d.ports = (d.ports || []).concat([{ proto: a, port: Number(b), label: "", reach: "home" }])
            draft = d
            break
        }
        case "addPort": {
            const d = Object.assign({}, draft)
            const used = (d.ports || []).map(p => Number(p.port))
            let port = 7777
            while (used.includes(port)) port++
            d.ports = (d.ports || []).concat([{ proto: "udp", port: port, label: "", reach: "home" }])
            draft = d
            break
        }
        case "removePort": { const d = Object.assign({}, draft); d.ports = (d.ports || []).filter((p, i) => i !== a); draft = d; break }
        case "add": addService(); break
        case "save": saveSettings(); break
        case "start":
            if (!it) break
            if (it.source === "site") { error = null; act(sites(["start", it.id]), undefined, (ok, r, e) => { if (!ok) fail(it.key, e) }) }
            else startServer(it)
            break
        case "stop":
            if (!it) break
            error = null
            act(it.source === "site" ? sites(["stop", it.id]) : routine(["stop", it.id]), undefined, (ok, r, e) => { if (!ok) fail(it.key, e) })
            break
        case "restart":
            if (!it) break
            error = null
            act(it.source === "site" ? sites(["restart", it.id]) : routine(["restart", it.id]), undefined, (ok, r, e) => {
                if (ok) notify(it.name + " restarted", ""); else fail(it.key, e)
            })
            break
        case "askUpdate": confirm = { key: a, what: "update" }; break
        case "update":
            if (!it) break
            error = null
            if (it.status !== "running" && it.status !== "starting") {
                const up = Object.assign({}, updating); up[it.key] = true; updating = up; confirm = null; break
            }
            act(routine(["stop", it.id]), undefined, (ok, r, e) => {
                confirm = null
                if (!ok) { fail(it.key, e); return }
                const up = Object.assign({}, updating); up[it.key] = true; updating = up
                copy = null
            })
            break
        case "copyIn": copyIn(a, b, c); break
        case "cancelConfirm": confirm = null; break
        case "askRemove": confirm = { key: a, what: "remove" }; break
        case "remove":
            if (!it) break
            act(admin(["remove", it.id]), undefined, (ok, r, e) => {
                confirm = null
                if (ok) { notify(it.name + " removed", "Its folder was not touched"); selectedKey = "" }
                else fail(it.key, e)
            })
            break
        case "openFolder": if (it && it.server) Quickshell.execDetached([fileop, "open", it.server.path]); break
        case "openData": if (it && it.server && it.server.data) Quickshell.execDetached([fileop, "open", it.server.data]); break
        case "openSettings": if (it && it.server) openSettings(it); break
        case "openLink": openLink(it); break
        case "openGuide": guide = true; dns = { checking: false, result: null }; break
        case "closeGuide": guide = false; break
        case "dnsCheck": dns = { checking: true, result: null }; dnsJob.start(q(["dns-check", b, "--public"])); break
        case "makeReadable":
            // The fallback when the folder can't be mounted for its account: readable by every account.
            if (it && it.server && !readableJob.running) readableJob.start(["chmod", "-R", "a+rX", "--", it.server.path])
            break
        case "dismissError": error = null; break
        case "openConsole": openConsole(a); break
        case "openTerminal": openTerminal(a); break
        case "selectUnit": unitSelKey = a || ""; break
        case "unitsRetry": unitsError = ""; unitsStream.restart(); break
        case "showMain": filter = "all"; query = ""; selectedKey = a; adding = false; editing = false; break
        }
    }

    // ---- deep links ------------------------------------------------------------------------------------
    //   quasar-services log            the live log of every service (a console window)
    //   quasar-services log/<key>      one service's console: svc:<id> site:<id> sys:<name> service:<unit>[,…]
    //                                  userservice:<unit> (the failure toast, the tray, Task Manager)
    //   quasar-services every          the list of every service on this PC
    // Started for a console, the main window stays hidden; it shows with the next plain `quasar-services`.
    readonly property bool startedForLog: S.logLink(Quickshell.env("QUASAR_APP_ARGS")) !== ""
    function navigateTo(arg) {
        arg = (arg || "").trim()
        const lk = S.logLink(arg)
        if (lk) openConsole(lk)
        else if (arg === "every") { filter = "pc"; adding = false; editing = false; guide = false }
        else if (arg === "add") handle("openAdd")
        else if (arg.startsWith("svc/")) { handle("select", "svc:" + arg.slice(4)) }
        else if (arg.startsWith("site/")) { handle("select", "site:" + arg.slice(5)) }
    }
    Component.onCompleted: navigateTo(Quickshell.env("QUASAR_APP_ARGS"))

    AppWindow {
        id: win
        appName: "services"
        title: "Services"
        glyph: Icons.cycle
        glyphColor: "#8CF5B0"
        defaultSize: Qt.size(1080, 690)
        visible: !app.startedForLog
        // Console windows still open: closing this one hides it; the last window closed quits the app.
        busy: consoles.count > 0
        // Template: the title, then "startup · scheduled · background" in small mono.
        titleItem: Item {
            Row {
                x: 3
                anchors.verticalCenter: parent.verticalCenter
                spacing: 9
                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: "Services"
                    font.family: Theme.fontUi; font.pixelSize: 13; font.weight: Font.DemiBold
                    color: win.focused ? Theme.text : Theme.textDim
                }
                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: "startup · scheduled · background"
                    font.family: Theme.fontMono; font.pixelSize: 11
                    color: "#5B6275"
                }
            }
        }
        ServicesView {
            id: servicesView
            anchors.fill: parent
            m: app.model
            onAct: (name, a, b, c) => app.handle(name, a, b, c)
        }
    }

    IpcHandler {
        target: "app"
        function open(arg: string): void {
            if (S.logLink(arg) !== "") app.openConsole(S.logLink(arg))
            else { app.navigateTo(arg); win.visible = true }
        }
        // Tests: the console windows and what each shows, as JSON.
        function consoles(): string {
            const out = []
            for (let i = 0; i < consoleInst.count; i++) { const w = consoleInst.objectAt(i); if (w) out.push(w.stateInfo()) }
            return JSON.stringify({ main: win.visible, consoles: out })
        }
    }
}
