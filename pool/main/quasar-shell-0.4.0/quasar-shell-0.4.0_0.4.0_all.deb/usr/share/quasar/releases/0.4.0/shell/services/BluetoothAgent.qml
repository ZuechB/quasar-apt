import QtQuick
import Quickshell
import Quickshell.Io
import Quickshell.Bluetooth
import Quasar

// The shell's side of Quasar's Bluetooth pairing agent (/usr/libexec/quasar/bt-agent, JSON lines): runs
// it whenever the PC has a Bluetooth adapter (registering needs no power, and BlueZ keeps no pairing
// keys without an agent), queues its questions as `request` for PairDialog and sends the answers back.
// Restarts the helper with a backoff if it dies. Settings asks `qs ipc call bluetooth agentReady`
// before it pairs. QUASAR_BT_AGENT swaps the helper (tools/fake-bt-agent.sh in tests).
Item {
    id: root
    visible: false

    readonly property string helper: Quickshell.env("QUASAR_BT_AGENT") || "/usr/libexec/quasar/bt-agent"
    readonly property bool wanted: Bluetooth.adapters.values.length > 0 || !!Quickshell.env("QUASAR_BT_AGENT")
    property bool ready: false
    // The question on screen: { event: "request"|"display", id, type, device: {path, address, name, icon, paired},
    // passkey, pin, uuid, entered } plus `mode` (PairDialog's) and `kind` (BtDevices.kind of its icon).
    property var request: null
    property var waiting: []
    property int failures: 0

    readonly property var requestDevice: request && request.device
        ? Bluetooth.devices.values.find(d => d && d.dbusPath === request.device.path) || null : null

    // ok/value: the answer to a request; for a displayed code "declined" cancels the pairing.
    function answer(ok, value) {
        const r = request
        if (!r) return
        if (r.event === "request")
            proc.write(JSON.stringify({ id: r.id, ok: ok, value: value || "" }) + "\n")
        else if (!ok && root.requestDevice)
            root.requestDevice.cancelPair()
        next()
    }
    function next() {
        request = waiting.length ? waiting[0] : null
        waiting = waiting.slice(1)
    }
    function enqueue(e) {
        e.mode = e.event === "display" ? "display-" + e.type : e.type
        e.kind = BtDevices.kind(e.device ? e.device.icon : "")
        // A displayed passkey repeats as keys are typed on the device: update it in place.
        if (e.event === "display" && request && request.event === "display" && request.device.path === e.device.path) {
            request = e
            return
        }
        if (request) waiting = waiting.concat([e])
        else request = e
    }
    function handle(line) {
        let e
        try { e = JSON.parse(line) } catch (x) { return }
        if (e.event === "ready") { ready = true; failures = 0 }
        else if (e.event === "unavailable") { ready = false; request = null; waiting = [] }
        else if (e.event === "cancel") { request = null; waiting = [] }
        else if (e.event === "request" || e.event === "display") enqueue(e)
    }
    function sync() {
        if (wanted && !proc.running && !restart.running) proc.running = true
        else if (!wanted && proc.running) proc.running = false
    }
    onWantedChanged: sync()
    Component.onCompleted: sync()

    // A displayed code is done once the device has paired.
    Connections {
        target: root.requestDevice
        ignoreUnknownSignals: true
        function onPairedChanged() {
            if (root.requestDevice && root.requestDevice.paired && root.request && root.request.event === "display")
                root.next()
        }
    }

    Process {
        id: proc
        command: [root.helper]
        stdinEnabled: true
        stdout: SplitParser { onRead: (line) => root.handle(line) }
        stderr: SplitParser { onRead: (line) => console.warn(line) }
        onExited: (code, status) => {
            root.ready = false
            root.request = null
            root.waiting = []
            if (root.wanted) {
                root.failures++
                restart.interval = Math.min(60000, 1000 * Math.pow(2, Math.min(root.failures, 6)))
                restart.restart()
            }
        }
    }
    Timer { id: restart; onTriggered: root.sync() }

    IpcHandler {
        target: "bluetooth"
        function agentReady(): bool { return root.ready }
    }
}
