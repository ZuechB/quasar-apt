import QtQuick
import Quickshell
import Quickshell.Io
import Quasar

// Tells the session the desktop is really on screen: once per shell start, shortly after the main display's
// wallpaper window swapped its first frame (a graphics driver that breaks Qt does so in the first frames).
// - $XDG_RUNTIME_DIR/quasar/shell-ready: shell-rescue's guard (quasar-shell-guard.service) waits for it after
//   sign-in and after every restart it makes; a shell that never writes it gets safe graphics. The text
//   console's repair hint reads it too.
// - /run/quasar/desktop-ready/u<uid>: quasar-boot-ok.path counts this start as good, so GRUB's menu stays
//   hidden next time (a start that never got here shows it, with safe graphics preselected).
// And, when this session runs on safe graphics because the desktop kept stopping (shell-rescue) or labwc
// couldn't start on the graphics card (quasar-session), one toast that says so, once per session.
Item {
    id: root
    visible: false
    signal toast(var t)

    property var window: null           // the main display's wallpaper window (a QQuickWindow)
    property bool done: false
    readonly property string runDir: Quickshell.env("XDG_RUNTIME_DIR") || ""
    readonly property string uid: { const m = runDir.match(/^\/run\/user\/(\d+)/); return m ? m[1] : "" }

    Connections {
        target: root.window
        enabled: !root.done
        function onFrameSwapped() { if (!settle.running) settle.start() }
    }
    Timer { id: settle; interval: 1500; onTriggered: root.mark() }

    function mark() {
        if (done || runDir === "")
            return
        done = true
        // One small shell: write both markers, and print the safe-graphics reason once per session.
        Quickshell.execDetached(["sh", "-c",
            'mkdir -p "$1/quasar" && date +%s > "$1/quasar/shell-ready"; ' +
            '[ -n "$2" ] && date +%s > "/run/quasar/desktop-ready/u$2" 2>/dev/null; true', "sh", runDir, uid])
        reasonCheck.running = true
    }

    // The reason file (quasar-render-fallback) and a once-per-session flag next to it.
    Process {
        id: reasonCheck
        command: ["sh", "-c", 'f="$1/quasar-render-fallback"; t="$1/quasar/fallback-shown"; ' +
                              '[ -s "$f" ] && [ ! -e "$t" ] && : > "$t" && cat "$f"; true', "sh", root.runDir]
        stdout: StdioCollector {
            onStreamFinished: {
                const why = text.trim()
                if (why !== "")
                    root.toast({ title: "Safe graphics is on", sub: why + " Drivers & Hardware has the details.",
                                 glyph: Icons.monitor, hue: Theme.amber, settings: "drivers" })
            }
        }
    }
}
