import QtQuick
import Quasar
import "displayLayout.js" as L

// Settings › Arrange displays: the displays that are on, as tiles at their places in the layout (the
// display's number, its name, and a strip for the main display's taskbar). Click a tile to pick it for
// the rows below; drag it to move the display: it snaps against a neighbour's edge, never overlaps one,
// and lines up with its edges when close (displayLayout.js); a ghost shows where it will land.
// Displays that are off are chips under the card. One MouseArea finds the tile from geometry: a
// DragHandler above it would take presses away (CLAUDE.md). Tiles are a keyed ListModel, so they glide
// to new places instead of being rebuilt. Pure view: the host applies `moved` and updates `outputs`.
Item {
    id: root
    property var outputs: []           // `displays state` outputs
    property string selected: ""
    property string mainName: ""
    property bool locked: false        // a tried change waits for Keep: no dragging meanwhile
    property color accent: Theme.accent
    signal chosen(string name)
    signal moved(string name, real x, real y)
    signal identifyClicked()

    implicitHeight: card.height + (offRow.visible ? offRow.implicitHeight + 14 : 0)

    readonly property var rs: L.rects(outputs || [])
    readonly property var off: (outputs || []).filter(o => !o.enabled)
    readonly property bool canDrag: !locked && rs.length > 1

    // Drag: the tile follows the pointer (layout coordinates of its top-left), the ghost shows its spot.
    property string dragName: ""
    property bool dragging: false
    property point dragAt: Qt.point(0, 0)
    property point grab: Qt.point(0, 0)        // where the tile was grabbed, in card pixels
    property var ghost: null                   // { x, y } snapped, layout coordinates
    // A dropped tile stays where it settled until the new layout arrives (no jump back meanwhile).
    property string heldName: ""
    property point heldAt: Qt.point(0, 0)
    onOutputsChanged: heldName = ""
    // On rs, not outputs: an outputs handler can run before the rs binding has caught up.
    onRsChanged: syncTiles()
    Timer { id: holdTimeout; interval: 2500; onTriggered: root.heldName = "" }   // the move was refused
    property string hoverName: ""

    function output(n) { return (outputs || []).find(o => o.name === n) || null }
    function snapFor(n, x, y) { return L.snap(rs, n, x, y) }

    ListModel { id: tiles }
    Component.onCompleted: syncTiles()
    function syncTiles() {
        const want = rs.map(r => r.name)
        for (let i = tiles.count - 1; i >= 0; i--) if (want.indexOf(tiles.get(i).name) < 0) tiles.remove(i)
        for (const n of want) {
            let have = false
            for (let i = 0; i < tiles.count && !have; i++) have = tiles.get(i).name === n
            if (!have) tiles.append({ name: n })
        }
    }

    Rectangle {
        id: card
        width: parent.width
        height: 320
        radius: 20
        color: Theme.white(0.035)
        border.width: 1
        border.color: Theme.white(0.07)

        Text {
            x: 18; y: 18
            width: card.width - 36 - identify.width - 12
            elide: Text.ElideRight
            text: root.locked ? "Keep or revert the change first, then you can move displays."
                : root.rs.length > 1 ? "Drag the displays to match where they sit on your desk."
                : (root.outputs || []).length > 1 ? "Turn on another display below to arrange them."
                : "Connect another display to arrange them."
            font.family: Theme.fontUi
            font.pointSize: Theme.pt(12.5)
            color: Theme.textMuted
        }
        Button {
            id: identify
            anchors { right: parent.right; rightMargin: 14; top: parent.top; topMargin: 12 }
            text: "Identify"
            variant: "outline"
            size: 30
            onClicked: root.identifyClicked()
        }

        Item {
            id: canvas
            x: 18; y: 52
            width: card.width - 36
            height: card.height - 52 - 18
            clip: true                                       // a tile dragged past the card stays inside it
            // Fitted to the layout as it is (not following a drag, which would make every tile jump).
            readonly property var f: L.fit(root.rs, width, height, 14)

            // Where the dragged display will land.
            Rectangle {
                visible: root.dragging && root.ghost !== null
                readonly property var r: L.find(root.rs, root.dragName)
                x: root.ghost && r ? canvas.f.ox + root.ghost.x * canvas.f.scale + 2 : 0
                y: root.ghost && r ? canvas.f.oy + root.ghost.y * canvas.f.scale + 2 : 0
                width: r ? r.w * canvas.f.scale - 4 : 0
                height: r ? r.h * canvas.f.scale - 4 : 0
                radius: 10
                color: Theme.alpha(root.accent, 0.07)
                border.width: 1
                border.color: Theme.alpha(root.accent, 0.55)
            }

            Repeater {
                model: tiles
                Item {
                    id: tile
                    required property string name
                    readonly property var r: L.find(root.rs, name) || ({ x: 0, y: 0, w: 1, h: 1 })
                    readonly property var o: root.output(name)
                    readonly property bool dragged: root.dragging && root.dragName === name
                    readonly property bool held: root.heldName === name
                    readonly property bool isSel: root.selected === name
                    readonly property bool isMain: root.mainName === name
                    readonly property bool hov: root.hoverName === name && !root.dragging
                    readonly property point at: dragged ? root.dragAt : held ? root.heldAt : Qt.point(r.x, r.y)
                    x: canvas.f.ox + at.x * canvas.f.scale
                    y: canvas.f.oy + at.y * canvas.f.scale
                    width: r.w * canvas.f.scale
                    height: r.h * canvas.f.scale
                    z: dragged ? 3 : isSel ? 2 : 1
                    Behavior on x { enabled: !tile.dragged; NumberAnimation { duration: Motion.dur(Motion.pop); easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.spring } }
                    Behavior on y { enabled: !tile.dragged; NumberAnimation { duration: Motion.dur(Motion.pop); easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.spring } }
                    Behavior on width { NumberAnimation { duration: Motion.dur(Motion.pop); easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.spring } }
                    Behavior on height { NumberAnimation { duration: Motion.dur(Motion.pop); easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.spring } }

                    Rectangle {
                        id: face
                        anchors { fill: parent; margins: 2 }          // a hairline gap where displays touch
                        radius: 10
                        scale: tile.dragged ? 1.03 : 1
                        Behavior on scale { NumberAnimation { duration: Motion.dur(260); easing.type: Easing.OutCubic } }
                        // Opaque while dragged: it passes over other displays, whose labels mustn't show through.
                        color: tile.dragged ? Qt.tint(Theme.windowOpaque, tile.isSel ? Theme.alpha(root.accent, 0.2) : Theme.white(0.12))
                             : tile.isSel ? Theme.alpha(root.accent, 0.16) : Theme.white(tile.hov ? 0.10 : 0.06)
                        border.width: tile.isSel ? 2 : 1
                        border.color: tile.isSel ? root.accent : Theme.white(tile.hov ? 0.24 : 0.14)
                        Behavior on color { ColorAnimation { duration: 160 } }

                        Column {
                            anchors.centerIn: parent
                            width: parent.width - 16
                            spacing: 2
                            Text {
                                anchors.horizontalCenter: parent.horizontalCenter
                                text: tile.o ? String(tile.o.number) : ""
                                font.family: Theme.fontDisplay
                                font.pixelSize: Math.max(14, Math.min(30, Math.round(face.height * 0.3)))
                                font.weight: Font.Medium
                                color: tile.isSel ? Theme.text : Theme.textMuted
                            }
                            Text {
                                width: parent.width
                                visible: face.height > 56
                                horizontalAlignment: Text.AlignHCenter
                                elide: Text.ElideRight
                                text: tile.o ? tile.o.label : tile.name
                                font.family: Theme.fontUi
                                font.pixelSize: 12
                                color: Theme.textMuted
                            }
                        }
                        Rectangle {                                  // the main display's taskbar
                            visible: tile.isMain
                            anchors { left: parent.left; right: parent.right; bottom: parent.bottom; margins: 7 }
                            height: 4
                            radius: 2
                            color: tile.isSel ? Theme.alpha(root.accent, 0.8) : Theme.white(0.38)
                        }
                    }
                }
            }

            MouseArea {
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: root.dragging ? Qt.ClosedHandCursor
                    : root.hoverName !== "" ? (root.canDrag ? Qt.OpenHandCursor : Qt.PointingHandCursor) : Qt.ArrowCursor
                property point pressAt: Qt.point(0, 0)
                property string pressName: ""
                onExited: root.hoverName = ""
                onPressed: (e) => {
                    pressAt = Qt.point(e.x, e.y)
                    pressName = L.hit(root.rs, canvas.f, e.x, e.y)
                    if (!pressName) return
                    const r = L.find(root.rs, pressName), f = canvas.f
                    root.grab = Qt.point(e.x - (f.ox + r.x * f.scale), e.y - (f.oy + r.y * f.scale))
                    root.chosen(pressName)
                }
                onPositionChanged: (e) => {
                    if (!pressed) { root.hoverName = L.hit(root.rs, canvas.f, e.x, e.y); return }
                    if (!pressName || !root.canDrag) return
                    if (!root.dragging && Math.abs(e.x - pressAt.x) < 4 && Math.abs(e.y - pressAt.y) < 4) return
                    const f = canvas.f
                    root.dragName = pressName
                    root.dragAt = Qt.point((e.x - root.grab.x - f.ox) / f.scale, (e.y - root.grab.y - f.oy) / f.scale)
                    root.dragging = true
                    root.ghost = L.snap(root.rs, pressName, root.dragAt.x, root.dragAt.y)
                }
                onReleased: (e) => {
                    if (root.dragging) {
                        const n = root.dragName
                        const p = L.snap(root.rs, n, root.dragAt.x, root.dragAt.y)
                        const r = L.find(root.rs, n)
                        root.heldName = n
                        root.heldAt = Qt.point(p.x, p.y)
                        holdTimeout.restart()
                        root.dragging = false
                        root.dragName = ""
                        root.ghost = null
                        if (r && (p.x !== r.x || p.y !== r.y)) root.moved(n, p.x, p.y)
                        else root.heldName = ""
                    }
                    pressName = ""
                }
                onCanceled: { root.dragging = false; root.dragName = ""; root.ghost = null; pressName = "" }
            }
        }
    }

    // Displays that are connected but off: pick one to turn it on (Use this display).
    Row {
        id: offRow
        visible: root.off.length > 0
        y: card.height + 14
        spacing: 8
        Text {
            anchors.verticalCenter: parent.verticalCenter
            text: "Not in use"
            font.family: Theme.fontMono
            font.pointSize: Theme.pt(10.5)
            font.letterSpacing: 1
            color: Theme.textDim
            rightPadding: 4
        }
        Repeater {
            model: root.off
            Pressable {
                id: chip
                required property var modelData
                readonly property bool isSel: root.selected === modelData.name
                kind: "chip"
                radius: 10
                width: chipText.implicitWidth + 24
                height: 32
                color: isSel ? Theme.alpha(root.accent, 0.14) : Theme.white(0.05)
                borderColor: isSel ? root.accent : Theme.white(0.10)
                accessibleName: modelData.label
                onClicked: root.chosen(modelData.name)
                Text {
                    id: chipText
                    anchors.centerIn: parent
                    text: chip.modelData.number + "  ·  " + chip.modelData.label
                    font.family: Theme.fontUi
                    font.pointSize: Theme.pt(12.5)
                    color: Theme.text
                }
            }
        }
    }
}
