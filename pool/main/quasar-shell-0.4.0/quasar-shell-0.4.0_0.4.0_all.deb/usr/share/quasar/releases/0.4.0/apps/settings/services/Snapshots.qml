import QtQuick
import Quickshell
import Quickshell.Io
import Quasar
import Quasar.Services

// Settings > Storage › Safety and the Snapshots page: btrfs snapshots through /usr/libexec/quasar/quasar-snapshot.
// - Reading: /run/quasar/snapshot-state.json (written in place by root after every change, apt's automatic
//   snapshots included, and at boot) and `quasar-snapshot status` (any user).
// - Make a snapshot / start one once: `pkexec quasar-snapshot create|boot-once`; an active administrator isn't
//   asked for a password (54-quasar-snapshot.rules).
// - Restore, cancel a waiting restore, delete, automatic snapshots off: `pkexec quasar-snapshot-admin`, which
//   asks every time.
//   QUASAR_SNAPSHOT=/path: a stand-in for both helpers (UI tests).
//   QUASAR_SNAPSHOT_STATE=/path: the state file to watch instead.
Scope {
    id: root
    property bool active: false              // Storage or the Snapshots page is shown
    property var st: null
    property string busy: ""                 // "create" | "auto" | "restore" | "delete" | "cancel" | "once"
    property string phase: ""
    property var ask: null                   // confirmation: { key, target, title, message, button, danger }
    property real now: Date.now() / 1000
    signal notify(var banner)
    signal pick(string title, var options, string current, var done, string message)
    signal openPage()

    readonly property string exe: Quickshell.env("QUASAR_SNAPSHOT") || ""
    readonly property string stateFile: Quickshell.env("QUASAR_SNAPSHOT_STATE") || "/run/quasar/snapshot-state.json"
    function helperCmd(args, admin) {
        return exe ? [exe].concat(args)
                   : ["pkexec", admin ? "/usr/libexec/quasar/quasar-snapshot-admin" : "/usr/libexec/quasar/quasar-snapshot"].concat(args)
    }

    readonly property var ctx: ({ busy: busy, phase: phase, now: now, icons: Icons, theme: Theme })
    readonly property var hero: SnapKit.hero(st, ctx)
    readonly property var groups: SnapKit.groups(st, ctx)
    readonly property var storageRows: SnapKit.storageRows(st, ctx)

    onActiveChanged: if (active) { now = Date.now() / 1000; refresh() }
    Timer { interval: 60000; running: root.active; repeat: true; onTriggered: root.now = Date.now() / 1000 }

    // ---- reading -----------------------------------------------------------------------------------
    property bool _again: false
    function refresh() {
        if (statusProc.running) { _again = true; return }
        statusProc.running = true
    }
    Process {
        id: statusProc
        command: [root.exe || "/usr/libexec/quasar/quasar-snapshot", "status"]
        stdout: StdioCollector { onStreamFinished: { try { root.st = JSON.parse(text) } catch (e) { } } }
        onExited: (code, status) => { if (root._again) { root._again = false; running = true } }
    }
    FileView {
        path: root.stateFile
        watchChanges: true
        printErrors: false
        onFileChanged: reload()
        onLoaded: { if (root.active && root.busy === "") root.refresh() }
    }

    // ---- changing ----------------------------------------------------------------------------------
    function heroActivated() {
        const s = SnapKit.state(st, ctx)
        if (s.kind === "pending") Platform.power("reboot")
        else if (s.kind === "booted") ask = SnapKit.restoreAsk(st, st.booted.id, now)
        else if (s.kind === "ready") run("create", ["create"], false, JSON.stringify({ description: "" }) + "\n")
    }
    function toggle(key) { activate(key) }
    function activate(key) {
        if (key === "snap:open") { root.openPage(); return }
        if (busy !== "" || !st || st.live || !st.btrfs) return
        if (key === "snap:auto") {
            if (st.auto) ask = { key: "autoOff", title: "Turn off automatic snapshots?", button: "Turn off", danger: true,
                                 message: "Updates then install without a snapshot first, so a bad one can't be undone from here." }
            else run("auto", ["auto", "on"], true)
        } else if (key === "snap:cancel") {
            run("cancel", ["cancel"], true)
        } else if (key.startsWith("snap:s:") || key.startsWith("snap:o:")) {
            const old = key.startsWith("snap:o:")
            const target = old ? key.slice(7) : parseInt(key.slice(7))
            const s = old ? null : SnapKit.find(st, target)
            pick(old ? "The system before a restore" : SnapKit.words(s), SnapKit.actions(st, key), "", (k) => root.chosen(k, target),
                 old ? "" : SnapKit.detail(s || {}, now))
        }
    }
    function chosen(k, target) {
        if (k === "restore") ask = SnapKit.restoreAsk(st, target, now)
        else if (k === "once") ask = { key: "once", target: target, button: "Restart now",
                                       title: "Start this snapshot once?",
                                       message: "Quasar restarts into the system as it was then, read-only: anything you change there is gone at the next restart, which starts today's system again. Save your work first: open apps close." }
        else if (k === "delete") ask = { key: "delete", target: target, button: "Delete", danger: true,
                                         title: typeof target === "string" ? "Delete the system from before the restore?" : "Delete this snapshot?",
                                         message: typeof target === "string" ? "The restore can't be undone after that." : "Its space is freed. It can't be brought back." }
    }
    function confirm() {
        const a = ask
        ask = null
        if (!a) return
        if (a.key === "restore") run("restore", ["restore", String(a.target)], true)
        else if (a.key === "delete") run("delete", ["delete", String(a.target)], true)
        else if (a.key === "autoOff") run("auto", ["auto", "off"], true)
        else if (a.key === "once") run("once", ["boot-once", String(a.target)], false)
    }

    // One change at a time. Closing the password sheet (126) says nothing.
    function run(key, args, admin, input) {
        busy = key
        phase = ""
        job.run(helperCmd(args, admin), undefined, input)
    }
    Cmd {
        id: job
        onLine: (l) => { if (l.startsWith("PHASE ")) root.phase = l.slice(6) }
        onFinished: (code) => {
            const key = root.busy
            root.busy = ""
            root.phase = ""
            if (code === 0) {
                if (key === "restore")
                    root.notify({ tone: "info", title: "Restart to finish restoring", restart: true, actionText: "Restart now",
                                  message: "The restored system starts next time. Save your work first." })
                else if (key === "once") Platform.power("reboot")
                else if (key === "create") root.notify({ tone: "success", title: "Snapshot made", message: "" })
                else if (key === "cancel") root.notify({ tone: "success", title: "Restore cancelled", message: "The system stays as it is." })
            } else if (code !== 126) {
                const err = job.details().split("\n").filter(l => l.startsWith("ERROR ")).map(l => l.slice(6)).pop()
                root.notify(code === 127
                    ? { tone: "error", title: "Your account can't change snapshots", message: "Ask an administrator." }
                    : { tone: code === 4 ? "info" : "error", title: err || "That didn't work", message: err ? "" : "Nothing was changed.",
                        details: job.details() })
            }
            root.refresh()
        }
    }
}
