import QtQuick
import Quasar
import "selection.js" as Sel

// One Files window's content (pure, previewable): the sidebar, the items (grid or list, ItemsView),
// the status bar, menus, inline rename, confirmations and messages. It owns where the window is
// (path, back/forward), the search and the selection. Everything that touches files goes out as
// request(action, args) to the window (services/FilesWindow.qml), which runs fileop and, for
// actions with a `done` callback, reports back. The title bar's Toolbar is wired by the window.
//
// request actions: open {rows} · window {path} · terminal {path} · setwall {path} · copy|cut {paths}
//   paste {dest} · canPaste · trash {paths} · restore {names} · deleteForever {names} · emptyTrash
//   extract {paths} · compress {paths} · rename {path, name, done(code, err, newPath)}
//   newfolder|newtext {dir, done(code, err, path)} · transfer {mode, dest, paths} · links {dest, urls, title}
//   cancel {id} (a job) · search {dir, query, hidden, onRow(obj), done(code, more)} · stopSearch
//   appsFor {path, done(obj)} · openWith {app, paths} · setDefault {app, mime, done(code, err)} · store
//   props {paths, onLine(obj), done()} · stopProps · mount {device, done(result, err)} · eject {device, done}
Item {
    id: root
    // ---- from the window ---------------------------------------------------------------------------
    property string home: "/home/you"
    property string trashPath: home + "/.local/share/Trash/files"
    property var rows: []                  // the folder's items (FileKit.row), any order
    property var trashRows: []             // the Trash's items (+ trashName, origin)
    property var info: null                // fileop info of `path`: {exists, dir, readable, writable, free, total}
    property bool loading: false
    property var places: []
    property var devices: []
    // A drive that goes away (unplugged, or unmounted by something else) takes its folders with it:
    // go Home, as GNOME does, instead of showing its empty mount point.
    property var _openDrives: []
    onDevicesChanged: {
        const now = devices.filter(d => d.mounted && d.path).map(d => d.path)
        const gone = _openDrives.filter(p => now.indexOf(p) < 0)
        _openDrives = now
        if (gone.some(p => FileKit.within(root.path, p))) root.go(root.home)
    }
    property real rootFree: -1
    property real rootTotal: -1
    property string viewMode: "grid"
    property bool showHidden: false
    property string sortKey: "name"
    property bool sortReversed: false
    property bool thumbs: true
    property bool clock24: false
    property bool windowActive: true
    property var jobs: []                  // file jobs running: [{ id, label, done, total, cancellable }]
    property bool canPaste: false
    property var thumbCache: null          // services/Thumbs.qml

    // ---- state -------------------------------------------------------------------------------------
    property string path: home
    readonly property bool isTrash: path === trashPath
    property var backStack: []
    property var forwardStack: []
    property string query: ""
    property alias selection: itemsView.selection
    readonly property alias itemsArea: itemsView     // previews and tests reach the items through this
    readonly property alias propertiesSheet: propsSheet
    readonly property alias defaultAppSheet: defaultSheet
    property string pendingSelect: ""      // select and show this path once it's listed
    property string pendingRename: ""      // start renaming this path once it's listed
    // Select and show `p` now if it's listed, else once it is (the listing may update before or after
    // the fileop that made it reports back).
    function selectSoon(p) {
        if (paths.indexOf(p) < 0) { pendingSelect = p; return }
        itemsView.selection = Sel.only(p)
        Qt.callLater(() => itemsView.reveal(p))
    }
    // A new folder or text file: rename it as soon as it's listed.
    function renameSoon(p) {
        if (paths.indexOf(p) < 0) { pendingRename = p; return }
        itemsView.selection = Sel.only(p)
        Qt.callLater(() => itemsView.beginRename(p))
    }
    property var pendingMany: []           // select these once all are listed (what a drop or paste brought)
    function selectWhenListed(list) { pendingMany = list.slice(); checkPending() }
    function checkPending() {
        if (!pendingMany.length || !pendingMany.every(p => paths.indexOf(p) >= 0)) return
        let s = Sel.empty()
        pendingMany.forEach(p => s = Sel.click(s, paths, paths.indexOf(p), Sel.CTRL))
        const first = pendingMany[0]
        pendingMany = []
        itemsView.selection = s
        Qt.callLater(() => itemsView.reveal(first))
    }

    signal request(string action, var args)
    signal settingChanged(string key, var value)
    signal navigated()                     // the window clears its search box

    readonly property var crumbs: isTrash ? [{ label: "Trash", path: trashPath }]
        : FileKit.crumbs(path, home, {}, devices.filter(d => d.path).map(d => ({ path: d.path, label: d.label })))
    readonly property string title: isTrash ? "Trash" : path === home ? "Home" : path === "/" ? "This PC" : FileKit.baseName(path)
    readonly property bool writable: !isTrash && (!info || info.writable !== false)

    // ---- search in subfolders (Enter in the search box; typing alone filters this folder) -----------
    property string searchFor: ""          // the words of the search shown ("" = none)
    property string searchIn: ""           // the folder it looks under
    property var searchRows: []
    property bool searching: false
    property bool searchMore: false        // it stopped at its limit
    property var _found: []                // results not shown yet (added a few times a second)
    readonly property bool isSearch: searchFor !== ""
    function plainPath(p) { return FileKit.within(p, home) ? "~" + p.slice(home.length) : p }
    function deepSearch() {
        const q = query.trim()
        if (!q || isTrash) return
        stopSearch()
        searchFor = q
        searchIn = path
        searchRows = []
        _found = []
        searchMore = false
        searching = true
        itemsView.selection = Sel.empty()
        itemsView.toTop()
        request("search", { dir: path, query: q, hidden: showHidden,
            onRow: (o) => {
                const r = FileKit.row(o.name, o.path, o.isDir, o.size, o.mtime)
                r.origin = root.plainPath(FileKit.parentOf(o.path))
                root._found.push(r)
                if (!flush.running) flush.start()
            },
            done: (code, more) => { root.flushFound(); root.searching = false; root.searchMore = !!more } })
    }
    function stopSearch() { if (searching) { request("stopSearch", {}); searching = false; flushFound() } }
    function endSearch() { stopSearch(); searchFor = ""; searchRows = []; _found = [] }
    function flushFound() { if (_found.length) { searchRows = searchRows.concat(_found); _found = [] } }
    Timer { id: flush; interval: 150; onTriggered: root.flushFound() }
    onQueryChanged: if (isSearch && query.trim() !== searchFor) endSearch()

    readonly property var source: isSearch ? searchRows : isTrash ? trashRows : (showHidden ? rows : rows.filter(r => !r.hidden))
    readonly property var shown: isSearch ? FileKit.sortRows(source, sortKey, sortReversed)
                                          : FileKit.filterRows(FileKit.sortRows(source, sortKey, sortReversed), query)
    readonly property var paths: shown.map(r => r.path)
    onPathsChanged: {
        itemsView.selection = Sel.prune(itemsView.selection, paths)
        if (pendingSelect && paths.indexOf(pendingSelect) >= 0) {
            itemsView.selection = Sel.only(pendingSelect)
            const p = pendingSelect
            pendingSelect = ""
            Qt.callLater(() => itemsView.reveal(p))
        }
        if (pendingRename && paths.indexOf(pendingRename) >= 0) {
            const p = pendingRename
            pendingRename = ""
            itemsView.selection = Sel.only(p)
            Qt.callLater(() => itemsView.beginRename(p))
        }
        if (itemsView.renamingPath && paths.indexOf(itemsView.renamingPath) < 0) itemsView.renamingPath = ""
        checkPending()
    }

    // ---- where the window is -----------------------------------------------------------------------
    function go(p) {
        if (!p || p === path) return
        backStack = backStack.concat([path])
        forwardStack = []
        setPath(p)
    }
    function setPath(p) {
        menu.close()
        endSearch()
        itemsView.renamingPath = ""
        itemsView.selection = Sel.empty()
        query = ""
        banner.title = ""
        pendingMany = []
        path = p
        itemsView.toTop()
        itemsView.forceActiveFocus()
        root.navigated()
        if (!Theme.reduceMotion && Theme.profile > 0) appear.restart()
    }
    function back() {
        if (!backStack.length) return
        const p = backStack[backStack.length - 1]
        backStack = backStack.slice(0, -1)
        forwardStack = forwardStack.concat([path])
        pendingSelect = path
        setPath(p)
    }
    function forward() {
        if (!forwardStack.length) return
        const p = forwardStack[forwardStack.length - 1]
        forwardStack = forwardStack.slice(0, -1)
        backStack = backStack.concat([path])
        setPath(p)
    }
    function up() {
        if (isTrash || path === "/") return
        const from = path
        go(FileKit.parentOf(path))
        pendingSelect = from                  // back where you came from
    }
    // A path typed into the breadcrumb (~ works); the window checks it exists.
    function typed(text) {
        const t = String(text).trim()
        const p = t === "~" ? home : t.startsWith("~/") ? FileKit.joinPath(home, t.slice(2)) : t.replace(/\/+$/, "") || "/"
        if (p.startsWith("/")) go(p)
        else showError("Type a folder's full path", "Like /home/you/Documents or ~/Documents")
    }

    // ---- what happens to items ---------------------------------------------------------------------
    function selectedRows() {
        const sel = itemsView.selection.sel
        return shown.filter(r => sel[r.path] === true)
    }
    function openItems(list) {
        if (isTrash || !list.length) return
        if (list.length === 1 && list[0].isDir) return go(list[0].path)
        request("open", { rows: list.slice(0, 12) })
    }
    function trashSelected() {
        const sel = selectedRows()
        if (!sel.length) return
        if (isTrash) return confirmDelete(sel)
        trashPaths(sel.map(r => r.path))
    }
    function startRename(p) { if (!isTrash && !isSearch) itemsView.beginRename(p) }
    // To the Trash; search results that went there leave the list (it isn't a live folder).
    function trashPaths(list) {
        request("trash", { paths: list, done: (code, lines) => {
            if (!root.isSearch) return
            const gone = {}
            lines.forEach(o => { if (o.trashed) gone[o.path] = true })
            root.searchRows = root.searchRows.filter(r => !gone[r.path])
        } })
    }
    function newItem(kind) {
        if (!writable) return
        request(kind === "folder" ? "newfolder" : "newtext", { dir: path, done: (code, err, made) => {
            if (code === 0 && made) root.renameSoon(made)
            else if (code !== 0) root.showError(err || "Couldn't make it")
        } })
    }
    function paste() { if (writable) request("paste", { dest: path }) }
    function toggleHidden() { settingChanged("hidden", !showHidden) }
    function setSort(key) {
        if (key === sortKey) settingChanged("reversed", !sortReversed)
        else { settingChanged("sort", key); settingChanged("reversed", false) }
    }
    function confirmDelete(sel) {
        if (!sel.length) return
        confirm.kind = "delete"
        confirm.names = sel.map(r => r.trashName)
        confirm.open = true
    }
    function confirmEmpty() {
        if (!trashRows.length) return
        confirm.kind = "empty"
        confirm.names = []
        confirm.open = true
    }

    // ---- messages ----------------------------------------------------------------------------------
    function showError(title, message) {
        banner.tone = "error"
        banner.title = title
        banner.message = message || ""
        bannerHide.restart()
    }
    function showInfo(title, message) {
        banner.tone = "info"
        banner.title = title
        banner.message = message || ""
        bannerHide.restart()
    }
    Timer { id: bannerHide; interval: 7000; onTriggered: banner.title = "" }

    // ---- drops -------------------------------------------------------------------------------------
    // Chromium puts a link's title in UTF-16 under text/x-moz-url; Firefox also offers _NETSCAPE_URL.
    function mozTitle(d) {
        let s = ""
        if (d.formats.indexOf("_NETSCAPE_URL") >= 0) s = d.getDataAsString("_NETSCAPE_URL")
        else if (d.formats.indexOf("text/x-moz-url") >= 0) {
            const b = new Uint8Array(d.getDataAsArrayBuffer("text/x-moz-url"))
            for (let i = 0; i + 1 < b.length; i += 2) s += String.fromCharCode(b[i] | (b[i + 1] << 8))
        }
        const lines = s.replace(/\0/g, "").split("\n")
        return lines.length > 1 ? lines[1].trim() : ""
    }
    // A drop on this window (dest: a folder, the Trash, or "" = the folder shown).
    //   From Files itself (this process): a move on the same drive, a copy onto another; Ctrl copies.
    //   From the desktop or another Files process (marked by their own types): the same.
    //   From other apps: a copy, unless the app proposes a move. Web links become shortcuts.
    function handleDrop(dest, d) {
        const formats = d.formats || []
        const ownFiles = formats.indexOf("application/x-quasar-files") >= 0
        const fromQuasar = ownFiles || formats.indexOf("application/x-quasar-desktop") >= 0
        let list = []
        if (ownFiles) { try { list = JSON.parse(d.getDataAsString("application/x-quasar-files")) || [] } catch (e) { list = [] } }
        if (!list.length) list = Array.from(d.urls || [], u => FileKit.localPath(String(u))).filter(p => p !== "")
        const webs = Array.from(d.urls || [], u => String(u)).filter(u => /^(https?|ftp):\/\//i.test(u))
        if (!list.length && !webs.length && d.hasText && /^(https?|ftp):\/\/\S+$/i.test(d.text.trim())) webs.push(d.text.trim())
        const target = dest || (isTrash ? trashPath : path)
        if (target === trashPath) {
            if (!list.length) { d.accepted = false; return }
            request("trash", { paths: list })
            d.accept(Qt.MoveAction)
            return
        }
        if (list.length) {
            const mode = d.source ? (d.proposedAction === Qt.CopyAction ? "copy" : "drop")
                       : fromQuasar ? "drop" : (d.proposedAction === Qt.MoveAction ? "move" : "copy")
            request("transfer", { mode: mode, dest: target, paths: list })
            d.accept(mode === "copy" ? Qt.CopyAction : Qt.MoveAction)
        } else if (webs.length) {
            request("links", { dest: target, urls: webs.slice(0, 8), title: mozTitle(d) })
            d.accept(Qt.CopyAction)
        } else {
            d.accepted = false
        }
    }

    // ---- open with, properties, drives --------------------------------------------------------------
    property var openWith: ({ mime: "", apps: [], loading: false })   // for the item menu, asked when it opens
    function openWithItems() {
        if (openWith.loading) return [{ key: "none", label: "Looking for apps…", glyph: Icons.clock }]
        if (!openWith.apps.length) return [{ key: "store", label: "Find an app in the Store", glyph: Icons.bag }]
        return openWith.apps.map(a => ({ key: "app:" + a.id, label: a.name, glyph: Icons.grid, checked: a["default"] }))
            .concat([{ sep: true }, { key: "defaultapp", label: "Change the default app…", glyph: Icons.sliders }])
    }
    function openProps(list) {
        if (!list.length) return
        propsSheet.items = []
        propsSheet.size = 0
        propsSheet.files = 0
        propsSheet.folders = 0
        propsSheet.counting = true
        propsSheet.open = true
        request("props", { paths: list,
            onLine: (o) => {
                if (o.item) propsSheet.items = propsSheet.items.concat([o.item])
                else if (o.size !== undefined) {
                    propsSheet.size = o.size
                    propsSheet.files = o.files
                    propsSheet.folders = o.folders
                    if (o.done) propsSheet.counting = false
                }
            },
            done: () => propsSheet.counting = false })
    }
    function mountDrive(device) {
        request("mount", { device: device, done: (res, err) => {
            if (res && res.path) root.go(res.path)
            else root.showError("Couldn't open the drive", err)
        } })
    }
    function ejectDrive(device) {
        const d = devices.find(x => x.device === device)
        const mount = d ? d.path : ""
        request("eject", { device: device, done: (res, err) => {
            if (!res) return root.showError("Couldn't eject the drive", err)
            if (mount && FileKit.within(root.path, mount)) root.go(root.home)
            root.showInfo("You can unplug “" + (res.label || (d ? d.label : "the drive")) + "” now", "")
        } })
    }

    // ---- menus -------------------------------------------------------------------------------------
    property string menuKind: ""           // item | background
    property var menuRows: []              // the items a menu acts on (taken when it opened)
    function showMenu(index, x, y) {
        menuKind = index >= 0 ? "item" : "background"
        menuRows = index >= 0 ? selectedRows() : []
        if (menuKind === "background" && !isTrash && !isSearch) request("canPaste", {})
        if (menuKind === "item" && !isTrash && menuRows.length && menuRows.every(r => !r.isDir)) {
            openWith = { mime: "", apps: [], loading: true }
            request("appsFor", { path: menuRows[0].path, done: (o) => root.openWith = Object.assign({ loading: false }, o) })
        }
        const p = itemsView.mapToItem(root, x, y)
        menu.show(p.x, p.y)
    }
    function itemMenu() {
        const sel = menuRows, n = sel.length
        if (!n) return []
        if (isTrash) return [
            { key: "restore", label: n > 1 ? "Restore " + n + " items" : "Restore", glyph: Icons.restore },
            { sep: true },
            { key: "delete", label: n > 1 ? "Delete " + n + " items forever" : "Delete forever", glyph: Icons.trash, hint: "Delete" }]
        const one = n === 1 ? sel[0] : null
        const how = one && !one.isDir ? FileKit.openAs(one.name) : ""
        const out = [{ key: "open", label: n > 1 ? "Open " + n + " items" : how === "program" ? "Run" : how === "package" ? "Install" : "Open",
                       glyph: Icons.open, hint: "Enter" }]
        if (how === "program") {          // the shell asks before anything runs (services/Programs.qml)
            if (/\.(sh|py)$/i.test(one.name)) out.push({ key: "edit", label: "Edit", glyph: Icons.pencil })
            out.push({ key: "runterm", label: "Run in Terminal", glyph: Icons.terminal })
            if (/\.appimage$/i.test(one.name)) out.push({ key: "toapps", label: "Add to Apps", glyph: Icons.grid })
        }
        if (sel.every(r => !r.isDir)) out.push({ key: "openwith", label: "Open with", glyph: Icons.grid, sub: openWithItems() })
        if (one && isSearch) out.push({ key: "showinfolder", label: "Show in its folder", glyph: Icons.folder })
        if (one && one.isDir) out.push({ key: "window", label: "Open in new window", glyph: Icons.square },
                                       { key: "terminal", label: "Open in Terminal", glyph: Icons.terminal })
        if (one && one.kind === "image" && !/\.ico$/i.test(one.name)) out.push({ key: "setwall", label: "Set as wallpaper", glyph: Icons.image })
        out.push({ sep: true },
                 { key: "cut", label: "Cut", glyph: Icons.scissors, hint: "Ctrl+X" },
                 { key: "copy", label: "Copy", glyph: Icons.copy, hint: "Ctrl+C" })
        if (one && !isSearch) out.push({ key: "rename", label: "Rename", glyph: Icons.pencil, hint: "F2" })
        out.push({ sep: true })
        if (sel.every(r => r.archive)) out.push({ key: "extract", label: "Extract here", glyph: Icons.pkg })
        out.push({ key: "compress", label: "Compress to .zip", glyph: Icons.layers },
                 { key: "properties", label: "Properties", glyph: Icons.info, hint: "Alt+Enter" },
                 { sep: true },
                 { key: "trash", label: n > 1 ? "Move " + n + " items to Trash" : "Move to Trash", glyph: Icons.trash, hint: n > 1 ? "" : "Delete" })
        return out
    }
    function backgroundMenu() {
        if (isTrash)
            return [{ key: "selectall", label: "Select all", glyph: Icons.check, hint: "Ctrl+A" }]
                   .concat(trashRows.length ? [{ sep: true }, { key: "empty", label: "Empty Trash", glyph: Icons.trash }] : [])
        let out = []
        if (writable) {
            out.push({ key: "new", label: "New", glyph: Icons.plus, sub: [
                { key: "newfolder", label: "Folder", glyph: Icons.folder },
                { key: "newtext", label: "Text document", glyph: Icons.notes }] })
            if (canPaste) out.push({ key: "paste", label: "Paste", glyph: Icons.paste, hint: "Ctrl+V" })
            out.push({ sep: true })
        }
        return out.concat([
            { key: "selectall", label: "Select all", glyph: Icons.check, hint: "Ctrl+A" },
            { key: "sort", label: "Sort by", glyph: Icons.sliders, sub: [
                { key: "sort:name", label: "Name", glyph: Icons.notes, checked: sortKey === "name" },
                { key: "sort:size", label: "Size", glyph: Icons.layers, checked: sortKey === "size" },
                { key: "sort:modified", label: "Modified", glyph: Icons.clock, checked: sortKey === "modified" },
                { sep: true },
                { key: "sort:reverse", label: "Reverse order", glyph: Icons.cycle, checked: sortReversed }] },
            { key: "hidden", label: "Show hidden files", glyph: Icons.eye, checked: showHidden },
            { sep: true },
            { key: "terminal", label: "Open Terminal here", glyph: Icons.terminal },
            { key: "folderprops", label: "Properties", glyph: Icons.info }])
    }
    function menuChosen(key) {
        const sel = menuRows
        const kind = menuKind
        menu.close()
        const pathsOf = (list) => list.map(r => r.path)
        if (key === "open") openItems(sel)
        else if (key === "window") request("window", { path: sel[0].path })
        else if (key === "terminal") request("terminal", { path: kind === "item" && sel.length === 1 && sel[0].isDir ? sel[0].path : path })
        else if (key === "setwall") request("setwall", { path: sel[0].path })
        else if (key === "edit") request("edit", { path: sel[0].path })
        else if (key === "runterm") request("runProgram", { path: sel[0].path, how: "terminal" })
        else if (key === "toapps") request("runProgram", { path: sel[0].path, how: "apps" })
        else if (key === "cut" || key === "copy") request(key, { paths: pathsOf(sel) })
        else if (key === "rename") startRename(sel[0].path)
        else if (key === "extract") request("extract", { paths: pathsOf(sel) })
        else if (key === "compress") request("compress", { paths: pathsOf(sel) })
        else if (key === "trash") trashPaths(pathsOf(sel))
        else if (key === "restore") request("restore", { names: sel.map(r => r.trashName) })
        else if (key === "delete") confirmDelete(sel)
        else if (key === "empty") confirmEmpty()
        else if (key === "newfolder") newItem("folder")
        else if (key === "newtext") newItem("text")
        else if (key === "paste") paste()
        else if (key === "selectall") itemsView.selection = Sel.all(itemsView.selection, paths)
        else if (key === "hidden") toggleHidden()
        else if (key === "sort:reverse") settingChanged("reversed", !sortReversed)
        else if (key.startsWith("sort:")) { settingChanged("sort", key.slice(5)) }
        else if (key.startsWith("app:")) request("openWith", { app: key.slice(4), paths: pathsOf(sel) })
        else if (key === "defaultapp") { defaultSheet.mime = openWith.mime; defaultSheet.kind = openWith.kind || ""; defaultSheet.apps = openWith.apps; defaultSheet.open = true }
        else if (key === "store") request("store", {})
        else if (key === "properties") openProps(pathsOf(sel))
        else if (key === "folderprops") openProps([path])
        else if (key === "showinfolder") {
            const p = sel[0].path, dir = FileKit.parentOf(p)
            pendingSelect = p
            if (dir === path) endSearch()
            else go(dir)
        }
        itemsView.forceActiveFocus()
    }

    // ---- layout ------------------------------------------------------------------------------------
    Sidebar {
        id: sidebar
        width: 190
        height: parent.height
        places: root.places
        devices: root.devices
        current: root.path
        trashPath: root.trashPath
        rootFree: root.rootFree
        rootTotal: root.rootTotal
        onPicked: (p) => root.go(p)
        onDropped: (p, d) => root.handleDrop(p, d)
        onMountRequested: (dev) => root.mountDrive(dev)
        onEjectRequested: (dev) => root.ejectDrive(dev)
    }

    Item {
        id: main
        anchors { left: sidebar.right; right: parent.right; top: parent.top; bottom: status.top }

        Banner {
            id: banner
            visible: title !== ""
            anchors { top: parent.top; left: parent.left; right: parent.right; margins: 10 }
            onDismissed: title = ""
        }

        ItemsView {
            id: itemsView
            anchors { top: banner.visible ? banner.bottom : parent.top; topMargin: banner.visible ? 4 : 0; left: parent.left; right: parent.right; bottom: parent.bottom }
            focus: true
            rows: root.shown
            paths: root.paths
            mode: root.viewMode
            kind: root.isTrash ? "trash" : root.isSearch ? "search" : "folder"
            thumbs: root.thumbs
            thumbCache: root.thumbCache
            clock24: root.clock24
            windowActive: root.windowActive
            sortKey: root.sortKey
            sortReversed: root.sortReversed
            onActivated: (i) => root.openItems([root.shown[i]])
            onContextRequested: (i, x, y) => root.showMenu(i, x, y)
            onDropRequested: (dest, d) => root.handleDrop(dest, d)
            onSortRequested: (key) => root.setSort(key)
            onRenameCancelled: { itemsView.renamingPath = ""; itemsView.forceActiveFocus() }
            onRenameAccepted: (p, text) => {
                const row = root.shown.find(r => r.path === p)
                const name = String(text).trim()
                if (!row || name === "" || name === row.name) { itemsView.renamingPath = ""; itemsView.forceActiveFocus(); return }
                root.request("rename", { path: p, name: name, done: (code, err, made) => {
                    if (code === 0) {
                        itemsView.renamingPath = ""
                        root.selectSoon(made || p)
                        itemsView.forceActiveFocus()
                    } else if (code === 2 || code === 4) {
                        itemsView.renameError = true
                        itemsView.focusRename()
                        root.showError(code === 2 ? "That name is already taken" : "That name can't be used",
                                       code === 4 ? "Names can't contain “/” or start or end with a space." : "")
                    } else {
                        itemsView.renamingPath = ""
                        root.showError(err || "Couldn't rename it")
                    }
                } })
            }
            onCommand: (name) => {
                const sel = root.selectedRows()
                if (name === "open") root.openItems(sel)
                else if (name === "trash" || name === "delete") root.trashSelected()
                else if (name === "rename") { if (sel.length === 1) root.startRename(sel[0].path) }
                else if (name === "copy" || name === "cut") { if (sel.length && !root.isTrash) root.request(name, { paths: sel.map(r => r.path) }) }
                else if (name === "paste") { if (!root.isTrash) root.paste() }
                else if (name === "up") root.up()
                else if (name === "back") root.back()
                else if (name === "forward") root.forward()
                else if (name === "properties") root.openProps(sel.length ? sel.map(r => r.path) : (root.isTrash ? [] : [root.path]))
                else if (name === "menu") { const p = itemsView.focusPoint(); root.showMenu(sel.length ? 0 : -1, p.x, p.y) }
            }
        }
        NumberAnimation { id: appear; target: itemsView; property: "opacity"; from: 0; to: 1; duration: Motion.dur(220) }

        // Nothing to show: an empty folder, an empty search, a folder that's gone or locked.
        Text {
            readonly property string text_: root.isSearch
                    ? (root.searchRows.length || root._found.length ? ""
                       : root.searching ? "Looking in " + FileKit.baseName(root.searchIn) + " and its folders…"
                       : "Nothing in " + FileKit.baseName(root.searchIn) + " or its folders matches “" + root.searchFor + "”.")
                : root.loading ? ""
                : root.isTrash ? (root.trashRows.length ? "" : "The Trash is empty.")
                : root.info && root.info.exists === false ? "This folder doesn't exist anymore."
                : root.info && root.info.readable === false ? "You don't have permission to open this folder."
                : root.source.length === 0 ? "This folder is empty."
                : root.shown.length === 0 && root.query !== "" ? "Nothing here matches “" + root.query + "”." : ""
            visible: text_ !== ""
            anchors { horizontalCenter: itemsView.horizontalCenter; top: itemsView.top; topMargin: (root.viewMode === "list" || root.isTrash || root.isSearch ? 30 : 0) + 60 }
            width: Math.min(itemsView.width - 40, implicitWidth)
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.Wrap
            text: text_
            textFormat: Text.PlainText
            font.family: Theme.fontUi; font.pointSize: Theme.pt(13.5)
            color: Theme.textDim
        }
    }

    // Status bar (template): what's here or what's selected; free space, or what's running.
    Item {
        id: status
        anchors { left: sidebar.right; right: parent.right; bottom: parent.bottom }
        height: 30
        Rectangle { width: parent.width; height: 1; color: Theme.white(0.05) }
        readonly property int selCount: Sel.count(itemsView.selection)
        readonly property real selBytes: {
            if (!selCount) return 0
            const sel = itemsView.selection.sel
            let n = 0
            for (let i = 0; i < root.shown.length; i++) { const r = root.shown[i]; if (sel[r.path] && !r.isDir) n += r.size }
            return n
        }
        Text {
            x: 14
            anchors.verticalCenter: parent.verticalCenter
            text: status.selCount ? status.selCount + " of " + FileKit.countText(root.shown.length) + " selected"
                                    + (status.selBytes > 0 ? " · " + FileKit.formatSize(status.selBytes) : "")
                : root.isSearch ? FileKit.countText(root.shown.length, "result") + (root.searchMore ? " (the first " + root.shown.length + ")" : "")
                : FileKit.countText(root.shown.length)
            font.family: Theme.fontUi; font.pointSize: Theme.pt(11.5)
            color: Theme.textDim
        }
        // What's running: the oldest file job (bytes copied, a stop button), else a search, else the
        // free space. Typing in the search box offers the search below this folder.
        readonly property var job: root.jobs.length ? root.jobs[0] : null
        Row {
            anchors { right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter }
            spacing: 8
            Spinner { visible: status.job !== null || root.searching; size: 13; anchors.verticalCenter: parent.verticalCenter }
            Text {
                anchors.verticalCenter: parent.verticalCenter
                text: status.job ? status.job.label
                    : root.searching ? "Searching…"
                    : root.query.trim() !== "" && !root.isSearch && !root.isTrash ? "Press Enter to look in every folder below"
                    : root.isTrash || root.isSearch ? ""
                    : root.info && root.info.free !== null && root.info.free !== undefined ? FileKit.formatSize(root.info.free) + " free" : ""
                font.family: Theme.fontUi; font.pointSize: Theme.pt(11.5)
                color: Theme.textDim
            }
            Rectangle {
                visible: status.job !== null && status.job.total > 0
                anchors.verticalCenter: parent.verticalCenter
                width: 110; height: 4; radius: 2
                color: Theme.white(0.1)
                Rectangle {
                    width: status.job && status.job.total > 0 ? Math.max(4, parent.width * Math.min(1, status.job.done / status.job.total)) : 0
                    height: parent.height; radius: 2
                    color: Theme.accent
                }
            }
            Text {
                visible: status.job !== null && status.job.total > 0
                anchors.verticalCenter: parent.verticalCenter
                text: status.job ? FileKit.formatSize(status.job.done) + " of " + FileKit.formatSize(status.job.total)
                                   + (root.jobs.length > 1 ? " · " + (root.jobs.length - 1) + " more" : "") : ""
                font.family: Theme.fontUi; font.pointSize: Theme.pt(11.5)
                color: Theme.textFaint
            }
            Pressable {
                visible: (status.job !== null && status.job.cancellable) || (status.job === null && root.searching)
                width: 22; height: 22; radius: 7
                anchors.verticalCenter: parent.verticalCenter
                accessibleName: status.job ? "Stop " + status.job.label : "Stop searching"
                onClicked: status.job ? root.request("cancel", { id: status.job.id }) : root.stopSearch()
                QIcon { anchors.centerIn: parent; path: Icons.x; size: 13; strokeWidth: 2; color: Theme.textMuted }
            }
            Pressable {
                visible: root.isTrash && root.trashRows.length > 0 && status.job === null
                width: emptyLabel.implicitWidth + 16; height: 22; radius: 7
                anchors.verticalCenter: parent.verticalCenter
                accessibleName: "Empty Trash"
                onClicked: root.confirmEmpty()
                Text {
                    id: emptyLabel
                    anchors.centerIn: parent
                    text: "Empty Trash"
                    font.family: Theme.fontUi; font.pointSize: Theme.pt(11.5); font.weight: Font.Medium
                    color: Theme.text3
                }
            }
        }
    }

    FileMenu {
        id: menu
        items: root.menuKind === "item" ? root.itemMenu() : root.menuKind === "background" ? root.backgroundMenu() : []
        onChosen: (key) => root.menuChosen(key)
        onDismissed: { menu.close(); itemsView.forceActiveFocus() }
    }

    // Deleting from the Trash can't be undone: ask once.
    Dialog {
        id: confirm
        property string kind: ""             // delete | empty
        property var names: []
        title: kind === "empty" ? "Empty the Trash?"
             : names.length > 1 ? "Delete " + names.length + " items forever?" : "Delete this item forever?"
        message: kind === "empty" ? FileKit.countText(root.trashRows.length) + " will be deleted for good. You can't undo this."
                                  : "You can't undo this."
        onDismissed: open = false
        buttons: [
            Button { text: "Cancel"; variant: "ghost"; onClicked: confirm.open = false },
            Button {
                text: confirm.kind === "empty" ? "Empty Trash" : "Delete forever"
                variant: "primary"; tone: Theme.danger
                onClicked: {
                    confirm.open = false
                    if (confirm.kind === "empty") root.request("emptyTrash", {})
                    else root.request("deleteForever", { names: confirm.names })
                }
            }
        ]
    }

    PropertiesSheet {
        id: propsSheet
        home: root.home
        clock24: root.clock24
        onDismissed: { open = false; if (counting) root.request("stopProps", {}); itemsView.forceActiveFocus() }
    }

    // "Change the default app…": which app opens files of this kind when they're double-clicked.
    ChoiceSheet {
        id: defaultSheet
        property string mime: ""
        property string kind: ""
        property var apps: []
        title: "Open " + (kind ? kind.replace(/ document$/, "") + " files" : "files like this") + " with"
        options: apps.map(a => ({ key: a.id, label: a.name, sub: a["default"] ? "The default now" : "" }))
        current: (apps.find(a => a["default"]) || { id: "" }).id
        onDismissed: open = false
        onChosen: (key) => {
            open = false
            const app = apps.find(a => a.id === key)
            root.request("setDefault", { app: key, mime: mime, done: (code, err) => {
                if (code === 0) root.showInfo((app ? app.name : key) + " now opens these files", mime)
                else root.showError("Couldn't change the default app", err)
            } })
        }
    }
}
